# Anvil/Forgeborn — A Deterministic Game Pipeline & NPC Simulation

This is a Rust-based game engine and content pipeline designed for a single-player, narrative-driven indie game. The architecture prioritizes **determinism**, **content authorship**, and **AI-assisted development** while maintaining strict boundaries between deterministic simulation and presentation.

## What is Forgeborn?

Forgeborn is a game about **inhabiting a world**, not conquering it. A procedurally-authored settlement populated by NPCs with continuous emotional and skill development. When catastrophes strike, they reverberate through the community's joy. When crops succeed, so does hope.

The gameplay loop: explore, understand the community's needs, watch consequences unfold over seasons.

## Project Structure

Anvil is organized into functional layers, separated by a **dependency firewall**:

```
PRESENTATION       anvil_bevy, anvil_streaming, anvil_demo
                   ↓ consumes
DETERMINISTIC      anvil_runtime, anvil_world, anvil_sim, anvil_physics,
                   anvil_assets, anvil_assets_pipeline, anvil_core, anvil_assembly
                   ↓ consumes
SEMANTICS          Human-authored content + LLM assistance (build-time only)
```

**Authority never moves upward:** presentation cannot invent simulation logic; deterministic crates cannot depend on rendering or networking.

### Core Crates

| Crate | Purpose | Dependencies |
|-------|---------|--------------|
| **anvil_core** | Domain types, validation, enums | `serde`, `thiserror` |
| **anvil_assets** | Asset catalogue, material resolution, external pipeline | Core + `flate2`, `chrono` |
| **anvil_world** | Deterministic world compiler (regions, connections, landmarks) | Core + Assets |
| **anvil_runtime** | Live simulation state, time, weather, snapshot/restore | Core + World + `glam` |
| **anvil_sim** | Gameplay systems (catastrophes, emotions, joy, NPC utility AI, skill learning, physics) | Core + World + Runtime + `rapier3d` |
| **anvil_streaming** | On-demand region loading and asset streaming | `tokio` + deterministic crates |
| **anvil_assembly** | World plan compilation, terrain generation, materialization | Core + World + noise generation |
| **anvil_bevy** | Rendering, atmosphere, particles, audio (Bevy integration) | `bevy` + deterministic crates |
| **anvil_demo** | Playable demo with UI, controls, streaming integration | Bevy + all above |

## Design Philosophy

Anvil is governed by **10 Commandments** enforced by gate scripts in CI:

1. **Dependency Firewall** — No Bevy, LLM, async, or network code in deterministic crates. Enforced by `scripts/check_firewall.sh`.
2. **Multi-Error Validation** — Every `validate()` function returns `ValidationErrors`, collecting all problems in one pass. Enforced by `scripts/check_validate_signature.sh`.
3. **No Production Panics Without Proof** — `unwrap()`, `panic!`, etc. require `// SAFETY:` comments justifying the invariant. Enforced by clippy `deny` on `expect_used`, `panic`, etc.
4. **File & Function Size Budgets** — Production files ≤ 500 lines, functions ≤ 50 lines, crates ≤ 5,000 lines. Enforced by `scripts/check_size.sh`.
5. **AI as Tool, Not Teammate** — AI-generated commits flagged with `[ai]` prefix and require explicit human review. Enforced by git hook + PR template.
6. **Document Every Decision** — `DECISIONS.md`, `ERROR_CODES.md`, and `ANVIL_PHILOSOPHY.md` are the constitution. Every public item has doc comments. Enforced by `#![deny(missing_docs)]` and `scripts/check_error_codes.sh`.
7. **Test at Every Level** — 80% statement coverage workspace-wide. Unit, integration, property, fuzz, and determinism tests. Enforced by `cargo llvm-cov`.
8. **Reproducible Builds** — `rust-toolchain.toml` + `Cargo.lock` committed. Byte-identical artifacts. Enforced by nightly determinism job.
9. **Observability** — Every error path emits structured logs. Operations > 50ms emit spans. Enforced by code review + clippy `let_underscore_must_use`.
10. **Bounded Slices** — Scope is sacred. New systems require philosophy amendment before code. Enforced by code review.

See `ANVIL_PHILOSOPHY.md` for full details including rationale, enforcement mechanisms, and performance budgets.

## Current Status

**Phase 3 Complete (Gameplay Systems)** — 2026-05-02

- ✅ Deterministic world compilation and streaming
- ✅ Catastrophe system (7 disaster types with spatial propagation)
- ✅ NPC emotional network (4-axis emotional state with social contagion)
- ✅ Joy catalyst system (settlements experience collective joy events)
- ✅ Utility-driven NPC AI (21 actions responding to needs)
- ✅ Diegetic skill progression (7 domains, fluency-based perceptibility)
- ✅ Incidental teaching (observation and guided correction)
- ✅ Age and time-of-day learning modifiers
- ✅ Children's foundation (5 child-specific actions)
- ✅ Deterministic physics (Rapier3D for player movement and catastrophes)
- ✅ Save format v7 with physics state serialization

**Gate Status:** All tests pass. Firewall holds. Zero warnings. 80%+ code coverage.

See `DECISIONS.md` for a detailed decision log of every architectural choice.

## Key Design Decisions

### Determinism First

Every simulation is reproducible: same world + same RNG seed = same outcome. This enables:
- Replayable catastrophes and community responses
- Reliable testing (no flaky "randomness" bugs)
- Cross-platform verification (detects silent float precision issues early)

Physics uses Rapier3D with fixed timestep (1/60s). RNG is xorshift64* for speed and reproducibility.

### No Networked Multiplayer

Forgeborn is about **inhabiting** a world, not sharing one. Lockstep networking with floating-point physics and emotional contagion is a research project, not a feature. The NPCs are the other people. (See Sprint 21 in `DECISIONS.md`.)

### Emotional Contagion + Joy Events

NPCs have a **4-axis emotional state:**
- **Security ↔ Threat** (spreads fastest; fear is contagious)
- **Belonging ↔ Isolation** (social bonds slow decay)
- **Agency ↔ Helplessness** (spreads slowest; self-efficacy is harder to transmit)
- **Satiation ↔ Desperation** (resource-driven)

Each axis filters different aspects of perception. Catastrophes trigger **Threat**. Harvest success triggers **Joy** (a meta-event where 60%+ of NPCs achieve high **Satiation** and **Security**).

### Skill + Perceptibility

NPCs learn through **practice** and **observation**. Fluency in a domain (1–6 levels) maps to **perceptibility modifiers:**
- **Halting** farmer: ~2x slower, ~77% yield
- **Expert** farmer: ~0.6x faster, 100% yield

This makes skill visible without UI: an expert's movements are fluid; a novice is clumsy.

### Hierarchical Asset Pipeline

Assets flow: **external vendor** (FBX/GLB) → **normalised GLB** → **texture payload** → **material assembly**. Each stage validates independently. Multi-error validation means one author roundtrip fixes all problems, not five.

Currently supports **NatureManufacture** (proprietary; not redistributable) and **CC0 fallbacks** (Kenney.nl, Freesound, AmbientCG). Set `ANVIL_USE_CC0_ASSETS=1` to use CC0 only.

## Getting Started

### Prerequisites

- Rust 1.75+ (pinned in `rust-toolchain.toml`)
- Linux, macOS, or Windows (CI matrix: x86_64 + aarch64)
- ~10 GB disk space (Cargo + build artifacts)

### Setup

```bash
# Run the setup script (installs system dependencies, verifies toolchain)
./scripts/setup.sh

# Run gates before any change
cargo check
cargo test --workspace
cargo clippy --workspace -- -D warnings
./scripts/check_firewall.sh
./scripts/check_size.sh
./scripts/check_error_codes.sh
```

### Running the Demo

```bash
# Start the demo (loads first streaming region, renders at 60 fps)
cargo run --release --bin anvil_demo

# With CC0 assets only
ANVIL_USE_CC0_ASSETS=1 cargo run --release --bin anvil_demo

# Run tests
cargo test --workspace

# Check code coverage
cargo llvm-cov --workspace --fail-under-lines 80
```

## Contributing & Code Review

**Read `AGENTS.md` first.** This is the discipline that holds the project together.

### Key Rules

1. **Gates are not suggestions.** Every PR must pass:
   - `cargo clippy --workspace -- -D warnings`
   - `cargo test --workspace`
   - All five gate scripts (`firewall`, `size`, `validate_signature`, `error_codes`, `placeholder_debt`)

2. **Validate returns `ValidationErrors`** — no exceptions. If you need to return errors from a `validate()` function, it must return `ValidationErrors`.

3. **File split at 500 lines.** Propose the split in the PR description before writing code.

4. **Panic requires `// SAFETY:` comment.** Prove the invariant. Code review will check.

5. **Error codes in `ERROR_CODES.md` first.** Register the code before using it in code.

6. **AI commits flagged with `[ai]`.** If you used AI assistance significantly, prefix the commit and check the "I have reviewed every AI-generated line" box in the PR template.

### What to Work On

See `PHASE_SPRINTS.md` for the sprint plan. Current phase: **Pre-Phase 4 (Infrastructure)** → **Phase 4 (Steam Release)** in Month 22.

Open placeholders in `PLACEHOLDER_DEBT.md` with scheduled review dates represent **deferred architectural decisions** — not abandoned work. If you want to tackle one, its review date is the deadline.

## Documentation

- **`ANVIL_PHILOSOPHY.md`** — The constitution. Read this first.
- **`DECISIONS.md`** — Decision log: every architectural choice and why.
- **`PHASE_SPRINTS.md`** — Sprint breakdown for Phases 2–5.
- **`GAME_DESIGN.md`** — Game design document preamble (GDD expands Phases 2–3).
- **`ERROR_CODES.md`** — Registry of all error codes (E0XX–E2XX).
- **`PLACEHOLDER_DEBT.md`** — Port-as-placeholder registry with review dates.
- **`FORGE_HARVEST_JOURNAL_PART1.md` & `PART2.md`** — Audit of ~17,500 lines ported from old Forge codebase.
- **`ASSET_REGISTRY.md`** — CC0 asset sources and licensing.
- **`INFRASTRUCTURE_EXCELLENCE.md`** — Infrastructure tasks, baselines, and observability.
- **`AGENTS.md`** — Instructions for AI assistants (mandatory reading).

## Performance Baselines

See `bench/REPORT.md` for measured baselines:

- **Catalogue resolve:** ~2–3 ms per query
- **World compile:** ~150–200 ms for 10-region world
- **Sim tick:** ~1.2 ms per tick (50 NPCs, all systems active)
- **Asset stream:** ~3.9–4.1 ms per 1,000 assets (LRU eviction)
- **Compile time:** 175 s (dev build, full workspace) — exceeds 120 s budget; nalgebra future compatibility issue

Regressions > 10% from baseline fail CI on dedicated benchmark runner.

## Licensing & Attribution

This project is **proprietary** (no public LICENSE yet). All code is original work or explicitly attributed ports from the Forge archive.

**Assets:** CC0-licensed alternatives in `assets/`. See `CREDITS.txt` and `ASSET_REGISTRY.md` for attribution.

**NatureManufacture assets** (if present in `vendor/`) are **not redistributable**. Set `ANVIL_USE_CC0_ASSETS=1` to use only CC0 assets.

## Questions?

- **Architecture/design:** See `DECISIONS.md` + `ANVIL_PHILOSOPHY.md`.
- **Sprint tasks:** See `PHASE_SPRINTS.md`.
- **Error codes:** See `ERROR_CODES.md`.
- **Placeholders:** See `PLACEHOLDER_DEBT.md`.
- **Game design:** See `GAME_DESIGN.md`.

For issues or PRs, include:
1. Which phase/sprint you're working on
2. Which gate scripts you've run
3. Test coverage (run `cargo llvm-cov`)
4. If AI-assisted, use `[ai]` prefix and check the PR box

---

**Last Updated:** 2026-05-03 — After Sprint PR-2 (Asset Foundation).

**Repository:** https://github.com/AgentAtelier/anvil

**Language Composition:** 56.2% Rust | 42.6% HTML | 0.8% Shell | 0.2% Python | 0.1% PowerShell | 0.1% CSS
