#![no_main]
use libfuzzer_sys::fuzz_target;

// Regression test: ensure the fuzz harness can successfully parse a valid FBX file.
// This confirms the harness loads correctly and can process real input.
use anvil_assets_pipeline::fbx::inspect_fbx_source;
use std::path::PathBuf;

fuzz_target!(|_data: &[u8]| {
    // Use a known-good FBX from the Emberwood vendor directory.
    // If the fuzzer is run with corpus files, this ensures we can at least
    // parse one valid file without panicking.
    let test_fbx = PathBuf::from(
        "/home/marc/RustroverProjects/Anvil/vendor/emberwood/models/architecture/bridge/board_01.FBX",
    );
    
    // This must not panic - it should either succeed or return an error.
    let result = inspect_fbx_source(&test_fbx);
    
    // We don't assert anything about success/failure since the file may not
    // exist in all environments. The important thing is no panic occurs.
    let _ = result;
});
