#![no_main]
use libfuzzer_sys::fuzz_target;

// The FBX parser is in anvil_assets_pipeline (fbx module).
// We want to exercise the conversion pipeline with arbitrary binary input.
use anvil_assets_pipeline::fbx::{convert_fbx_to_glb_bytes, inspect_fbx_source};

fuzz_target!(|data: &[u8]| {
    // Write the fuzzed data to a temporary file, then try to parse it.
    // Both functions must never panic, only return Result::Err on invalid input.
    let tmp = std::env::temp_dir().join(format!("fuzz_fbx_{}.fbx", std::process::id()));
    if let Err(_) = std::fs::write(&tmp, data) {
        return;
    }

    let tag = anvil_core::ArchetypeTag::new("fuzz_test_asset")
        .expect("fuzz tag should be valid");

    // These must not panic under any circumstances. The fuzzer only cares
    // about panics, timeouts, and out-of-memory — not about successful parsing.
    let _ = inspect_fbx_source(&tmp);
    let _ = convert_fbx_to_glb_bytes(&tmp, &tag);

    // Clean up the temporary file
    let _ = std::fs::remove_file(&tmp);
});
