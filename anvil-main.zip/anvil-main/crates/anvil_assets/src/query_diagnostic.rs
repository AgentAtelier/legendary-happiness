//! Query diagnostic types for catalogue resolution.

use anvil_core::ArchetypeTag;
use std::fmt;

/// Result of a failed catalogue query, explaining why no asset was found.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QueryDiagnostic {
    UnknownTag(ArchetypeTag),
    NoVariantMatch {
        tag: ArchetypeTag,
        tried: Vec<String>,
    },
}

impl std::fmt::Display for QueryDiagnostic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownTag(tag) => write!(f, "unknown archetype tag: {}", tag.as_str()),
            Self::NoVariantMatch { tag, tried } => {
                write!(
                    f,
                    "no material variant matched for tag '{}'. Tried: {}",
                    tag.as_str(),
                    if tried.is_empty() {
                        "no variant conditions evaluated".into()
                    } else {
                        tried.join(", ")
                    }
                )
            }
        }
    }
}
