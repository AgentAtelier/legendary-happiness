//! Fallback material data: [`MaterialFallback`], [`FallbackProvider`],
//! and the fallback table.

use crate::types::{AssetCategory, MaterialVariant};
use std::path::PathBuf;
use std::sync::{Arc, OnceLock};

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

/// Complete fallback override for a single material variant.
#[derive(Debug, Clone, PartialEq)]
pub struct MaterialFallback {
    /// Path to the albedo (diffuse) texture.
    pub albedo: Arc<PathBuf>,
    /// Path to the normal map texture.
    pub normal: Arc<PathBuf>,
    /// Roughness value (0.0 = smooth, 1.0 = rough).
    pub roughness: f32,
    /// Metallic value (0.0 = dielectric, 1.0 = metal).
    pub metallic: f32,
}

/// Returns the fallback table.
pub fn fallback_table() -> &'static Vec<(MaterialVariant, Arc<MaterialFallback>)> {
    static TABLE: OnceLock<Vec<(MaterialVariant, Arc<MaterialFallback>)>> = OnceLock::new();
    TABLE.get_or_init(|| {
        vec![
            (
                MaterialVariant::Charred,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/rock_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/rock_normal.png")),
                    roughness: 0.95,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Burned,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/rock_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/rock_normal.png")),
                    roughness: 0.95,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Volcanic,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/rock_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/rock_normal.png")),
                    roughness: 0.85,
                    metallic: 0.05,
                }),
            ),
            (
                MaterialVariant::Shattered,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/rock_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/rock_normal.png")),
                    roughness: 0.98,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Weathered,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/rock_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/rock_normal.png")),
                    roughness: 0.97,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Flooded,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/dirt_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/dirt_normal.png")),
                    roughness: 0.55,
                    metallic: 0.1,
                }),
            ),
            (
                MaterialVariant::Regrowth,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/grass_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/grass_normal.png")),
                    roughness: 0.90,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Parched,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/sand_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/sand_normal.png")),
                    roughness: 1.0,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Dead,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/sand_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/sand_normal.png")),
                    roughness: 1.0,
                    metallic: 0.0,
                }),
            ),
            (
                MaterialVariant::Bare,
                Arc::new(MaterialFallback {
                    albedo: Arc::new(PathBuf::from("textures/terrain/sand_albedo.png")),
                    normal: Arc::new(PathBuf::from("textures/terrain/sand_normal.png")),
                    roughness: 1.0,
                    metallic: 0.0,
                }),
            ),
        ]
    })
}

// ---------------------------------------------------------------------------
// Fallback provider trait
// ---------------------------------------------------------------------------

/// Pluggable source of fallback material data.
///
/// Implementations MUST return `None` for variants where the category
/// is not in [`AssetCategory::is_covered_family`], to prevent material
/// fallbacks on uncovered asset categories.
///
/// # Examples
///
/// ```rust,no_run
/// use anvil_assets::prelude::*;
/// use std::sync::Arc;
/// use std::path::PathBuf;
///
/// #[derive(Debug)]
/// struct MyFallbackProvider;
///
/// impl FallbackProvider for MyFallbackProvider {
///     fn textures(
///         &self,
///         category: AssetCategory,
///         variant: MaterialVariant,
///     ) -> Option<(Arc<PathBuf>, Arc<PathBuf>)> {
///         // Return custom fallback textures
///         Some((Arc::new(PathBuf::from("fallback_albedo.png")),
///               Arc::new(PathBuf::from("fallback_normal.png"))))
///     }
///     
///     fn pbr_scalars(&self, variant: MaterialVariant) -> Option<(f32, f32)> {
///         // Return custom roughness and metallic values
///         Some((0.5, 0.0))
///     }
/// }
/// ```
pub trait FallbackProvider: Send + Sync + std::fmt::Debug {
    /// Return fallback texture paths for a variant in the given category
    /// when no explicit catalogue override exists.
    fn textures(
        &self,
        category: AssetCategory,
        variant: MaterialVariant,
    ) -> Option<(Arc<PathBuf>, Arc<PathBuf>)>;

    /// Return fallback PBR scalars for a variant.
    fn pbr_scalars(&self, variant: MaterialVariant) -> Option<(f32, f32)>;
}

// ---------------------------------------------------------------------------
// Default provider
// ---------------------------------------------------------------------------

/// The built-in provider backed by the fallback table.
#[derive(Debug, Clone, Default)]
pub struct DefaultFallbackProvider;

impl FallbackProvider for DefaultFallbackProvider {
    fn textures(
        &self,
        category: AssetCategory,
        variant: MaterialVariant,
    ) -> Option<(Arc<PathBuf>, Arc<PathBuf>)> {
        if !category.is_covered_family() {
            return None;
        }
        get_fallback(variant).map(|fb| {
            // Use Arc::clone to avoid per-call allocation
            (Arc::clone(&fb.albedo), Arc::clone(&fb.normal))
        })
    }

    fn pbr_scalars(&self, variant: MaterialVariant) -> Option<(f32, f32)> {
        get_fallback(variant).map(|fb| (fb.roughness, fb.metallic))
    }
}

// ---------------------------------------------------------------------------
// Public helpers
// ---------------------------------------------------------------------------

/// Look up the `MaterialFallback` for a given variant.
pub fn get_fallback(variant: MaterialVariant) -> Option<&'static MaterialFallback> {
    // Linear search is acceptable for the fixed set of variants
    fallback_table()
        .iter()
        .find(|(v, _)| *v == variant)
        .map(|(_, fb)| &**fb)
}

/// Return the complete fallback table - useful for tooling.
pub fn get_fallback_table() -> &'static Vec<(MaterialVariant, Arc<MaterialFallback>)> {
    fallback_table()
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_material_variant_has_fallback() {
        let all_variants = [
            MaterialVariant::Burned,
            MaterialVariant::Dead,
            MaterialVariant::Bare,
            MaterialVariant::Regrowth,
            MaterialVariant::Charred,
            MaterialVariant::Flooded,
            MaterialVariant::Weathered,
            MaterialVariant::Shattered,
            MaterialVariant::Parched,
            MaterialVariant::Volcanic,
        ];

        for variant in all_variants {
            let fb = get_fallback(variant)
                .unwrap_or_else(|| panic!("missing fallback for {:?}", variant));
            assert!(!fb.albedo.as_os_str().is_empty(), "empty albedo for {:?}", variant);
            assert!(!fb.normal.as_os_str().is_empty(), "empty normal for {:?}", variant);
            assert!(fb.roughness.is_finite(), "bad roughness for {:?}", variant);
            assert!(fb.metallic.is_finite(), "bad metallic for {:?}", variant);
        }
    }

    #[test]
    fn covered_categories_get_textures() {
        let provider = DefaultFallbackProvider;
        assert!(provider
            .textures(AssetCategory::Decal, MaterialVariant::Charred)
            .is_none());
        assert!(provider
            .textures(AssetCategory::Landmark, MaterialVariant::Charred)
            .is_some());
    }
}
