//! Material coverage reporting for [`AssetCatalogue`].

use crate::types::{AssetCategory, BiomeTag, MaterialCondition, MaterialOverride};
use anvil_core::ArchetypeTag;
use std::str::FromStr;
use std::sync::Arc;

use super::AssetCatalogue;

/// Regression-lock audit report for material coverage gaps.
///
/// Used to identify missing material properties across the catalogue.
/// Each field contains a list of (asset_tag, variant_name) pairs that are missing
/// the corresponding property.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct MaterialCoverageReport {
    /// List of (asset_tag, variant_name) pairs missing explicit textures.
    pub missing_explicit_textures: Vec<(String, String)>,
    /// List of (asset_tag, variant_name) pairs missing ORM (Occlusion, Roughness, Metallic) textures.
    pub missing_orm_texture: Vec<(String, String)>,
    /// List of (asset_tag, variant_name) pairs missing color tint.
    pub missing_color_tint: Vec<(String, String)>,
    /// List of (asset_tag, variant_name) pairs missing emissive properties.
    pub missing_emissive: Vec<(String, String)>,
    /// List of (asset_tag, variant_name) pairs missing scalar PBR properties.
    pub missing_scalar_pbr: Vec<(String, String)>,
}

impl AssetCatalogue {
    // -----------------------------------------------------------
    // Family helpers
    // -----------------------------------------------------------

    /// Returns the biome aliases for a given terrain type.
    /// Used to find family-specific asset variants (e.g., "forest_tower" for TerrainType::Forest).
    pub fn biome_aliases_for(terrain: anvil_core::TerrainType) -> &'static [&'static str] {
        match terrain {
            anvil_core::TerrainType::Highlands => &["highlands", "mountain"],
            anvil_core::TerrainType::Forest => &["forest", "woodland"],
            anvil_core::TerrainType::Desert => &["desert", "arid"],
            anvil_core::TerrainType::Marsh => &["marsh", "fen"],
            anvil_core::TerrainType::Coast => &["coast", "coastal"],
            _ => &[],
        }
    }

    /// Finds an asset entry matching the given category, biome aliases, and base tags.
    /// Used for terrain-specific asset selection.
    pub fn find_family_variant(
        &self,
        category: AssetCategory,
        biome_aliases: &[&str],
        base_tags: &[&str],
    ) -> Option<&crate::types::AssetEntry> {
        for biome in biome_aliases {
            for base_tag in base_tags {
                let Ok(exact_tag) = ArchetypeTag::new(format!("{biome}_{base_tag}")) else {
                    continue;
                };
                if let Some(entry) = self.resolve(&exact_tag) {
                    return Some(entry);
                }
            }
        }
        let mut candidate_tags: Vec<ArchetypeTag> = self
            .entries
            .iter()
            .filter(|(tag, entry)| {
                if entry.metadata.category != category {
                    return false;
                }
                if !biome_aliases
                    .iter()
                    .filter_map(|biome| BiomeTag::from_str(biome).ok())
                    .any(|biome| entry.metadata.biome_tags.contains(&biome))
                {
                    return false;
                }
                base_tags
                    .iter()
                    .any(|base_tag| tag.as_str().ends_with(base_tag))
            })
            .map(|(tag, _)| tag.clone())
            .collect();
        candidate_tags.sort_by(|a, b| a.as_str().cmp(b.as_str()));
        candidate_tags
            .into_iter()
            .find_map(|tag| self.resolve(&tag))
    }

    // -----------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------

    fn variant_in_covered_state_family(
        category: &AssetCategory,
        condition: &MaterialCondition,
    ) -> bool {
        let is_covered_category = matches!(
            category,
            AssetCategory::Landmark
                | AssetCategory::ArchitectureKit
                | AssetCategory::TerrainDetail
        );
        if !is_covered_category {
            return false;
        }
        matches!(
            condition,
            MaterialCondition::Damage(_)
                | MaterialCondition::Vegetation(_)
                | MaterialCondition::Occupancy(_)
                | MaterialCondition::Reconstruction(_)
                | MaterialCondition::FactionPresence(_)
        )
    }

    // -----------------------------------------------------------
    // Validation and coverage
    // -----------------------------------------------------------

    /// Returns the validation errors collected during catalogue loading.
    pub fn validation_errors(&self) -> &anvil_core::ValidationErrors {
        &self.validation_errors
    }

    /// Validates that all referenced asset paths exist on disk.
    pub fn validate_paths(&self) -> Result<(), super::CatalogueError> {
        for catalogue_entry in self.entries.values() {
            let full_path = self.asset_root.join(&*catalogue_entry.entry.path);
            if !full_path.exists() {
                return Err(super::CatalogueError::ReferencedAssetNotFound {
                    tag: catalogue_entry.entry.tag.clone(),
                    path: full_path,
                });
            }
        }
        Ok(())
    }

    /// Returns a comprehensive report of material coverage gaps for regression-lock CI checks.
    pub fn material_coverage_report(&self) -> MaterialCoverageReport {
        let mut report = MaterialCoverageReport::default();
        for (tag, catalogue_entry) in &self.entries {
            let category = catalogue_entry.metadata.category.clone();
            for variant in &catalogue_entry.variants {
                if !Self::variant_in_covered_state_family(&category, &variant.condition) {
                    continue;
                }
                if variant.overrides.albedo_texture.is_none()
                    || variant.overrides.normal_texture.is_none()
                {
                    report
                        .missing_explicit_textures
                        .push((tag.as_str().to_string(), variant.material_key.to_string()));
                }
                if variant.overrides.roughness_metallic_texture.is_none() {
                    report
                        .missing_orm_texture
                        .push((tag.as_str().to_string(), variant.material_key.to_string()));
                }
                if variant.overrides.base_color_tint.is_none() {
                    report
                        .missing_color_tint
                        .push((tag.as_str().to_string(), variant.material_key.to_string()));
                }
                if variant.overrides.emissive.is_none() {
                    report
                        .missing_emissive
                        .push((tag.as_str().to_string(), variant.material_key.to_string()));
                }
                if variant.overrides.perceptual_roughness.is_none()
                    || variant.overrides.metallic.is_none()
                {
                    report
                        .missing_scalar_pbr
                        .push((tag.as_str().to_string(), variant.material_key.to_string()));
                }
            }
        }
        report.missing_explicit_textures.sort();
        report.missing_orm_texture.sort();
        report.missing_color_tint.sort();
        report.missing_emissive.sort();
        report.missing_scalar_pbr.sort();
        report
    }

    /// Returns variants missing explicit textures. Deprecated: use `material_coverage_report()` instead.
    #[deprecated(note = "use material_coverage_report() instead")]
    pub fn variants_missing_explicit_textures(&self) -> Vec<(String, String)> {
        self.material_coverage_report().missing_explicit_textures
    }

    /// Returns variants missing ORM textures. Deprecated: use `material_coverage_report()` instead.
    #[deprecated(note = "use material_coverage_report() instead")]
    pub fn variants_missing_orm_texture(&self) -> Vec<(String, String)> {
        self.material_coverage_report().missing_orm_texture
    }

    /// Returns variants missing color tint. Deprecated: use `material_coverage_report()` instead.
    #[deprecated(note = "use material_coverage_report() instead")]
    pub fn variants_missing_color_tint(&self) -> Vec<(String, String)> {
        self.material_coverage_report().missing_color_tint
    }

    /// Returns variants missing emissive properties. Deprecated: use `material_coverage_report()` instead.
    #[deprecated(note = "use material_coverage_report() instead")]
    pub fn variants_missing_emissive(&self) -> Vec<(String, String)> {
        self.material_coverage_report().missing_emissive
    }

    /// Returns variants missing scalar PBR properties. Deprecated: use `material_coverage_report()` instead.
    #[deprecated(note = "use material_coverage_report() instead")]
    pub fn variants_missing_scalar_pbr(&self) -> Vec<(String, String)> {
        self.material_coverage_report().missing_scalar_pbr
    }

    /// Returns all archetype tags whose metadata includes the given biome.
    pub fn tags_by_biome(&self, biome: crate::types::BiomeTag) -> Vec<&ArchetypeTag> {
        self.entries
            .iter()
            .filter(|(_, e)| e.metadata.biome_tags.contains(&biome))
            .map(|(tag, _)| tag)
            .collect()
    }

    /// Returns all archetype tags in the given asset category.
    pub fn tags_by_category(&self, category: AssetCategory) -> Vec<&ArchetypeTag> {
        self.entries
            .iter()
            .filter(|(_, e)| e.metadata.category == category)
            .map(|(tag, _)| tag)
            .collect()
    }

    /// Resolve only the mesh path, ignoring material overrides.
    pub fn resolve_mesh_path(&self, tag: &ArchetypeTag) -> Option<&Arc<std::path::PathBuf>> {
        self.entries.get(tag).map(|e| &e.entry.path)
    }

    /// Return the fallback material for a given category and variant.
    pub fn default_material_for(
        &self,
        category: AssetCategory,
        variant: super::super::types::MaterialVariant,
    ) -> MaterialOverride {
        let (albedo, normal) = self
            .fallback_provider
            .textures(category, variant)
            .map(|(a, n)| (Some(a), Some(n)))
            .unwrap_or((None, None));
        let (roughness, metallic) = self
            .fallback_provider
            .pbr_scalars(variant)
            .map(|(r, m)| (Some(r), Some(m)))
            .unwrap_or((None, None));
        MaterialOverride {
            albedo_texture: albedo,
            normal_texture: normal,
            roughness_metallic_texture: None,
            perceptual_roughness: roughness,
            metallic,
            base_color_tint: None,
            emissive: None,
        }
    }
}
