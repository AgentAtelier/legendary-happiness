//! Query resolution for [`AssetCatalogue`].

use crate::types::{
    AssetCategory, CatalogueQuery, MaterialConditionContext,
    MaterialOrigin, MaterialOverride, MaterialVariantContext, QueryDiagnostic,
    ResolutionContext, ResolvedAsset,
};
use anvil_core::{ArchetypeTag, DamageType, VegetationState};
use std::sync::Arc;

use super::AssetCatalogue;

impl AssetCatalogue {
    // -----------------------------------------------------------
    // Basic accessors
    // -----------------------------------------------------------

    /// Returns the catalogue version number.
    pub fn version(&self) -> u32 {
        self.version
    }

    /// Resolves an asset entry by archetype tag.
    pub fn resolve(&self, tag: &ArchetypeTag) -> Option<&crate::types::AssetEntry> {
        self.entries.get(tag).map(|e| &e.entry)
    }

    /// Resolves the first asset entry matching any of the given tags.
    pub fn resolve_first(&self, tags: &[ArchetypeTag]) -> Option<&crate::types::AssetEntry> {
        tags.iter()
            .find_map(|tag| self.entries.get(tag).map(|e| &e.entry))
    }

    /// Returns the metadata for an asset with the given tag, if it exists.
    pub fn metadata(&self, tag: &ArchetypeTag) -> Option<&crate::types::AssetMetadata> {
        self.entries.get(tag).map(|e| &e.metadata)
    }

    /// Returns a reference to the underlying entry map.
    pub fn entries(&self) -> &std::collections::HashMap<ArchetypeTag, super::CatalogueEntry> {
        &self.entries
    }

    /// Check if a path component is safe (no traversal, no empty segments)
    fn is_safe_path_component(component: &str) -> bool {
        !component.is_empty()
            && component != "."
            && component != ".."
            && !component.contains('/')
            && !component.contains('\\')
    }

    /// Returns the full filesystem path for an asset entry.
    pub fn full_path(&self, entry: &crate::types::AssetEntry) -> std::path::PathBuf {
        // Validate path components to prevent path traversal
        if let Some(path_str) = entry.path.to_str() {
            for part in path_str.split('/') {
                if !Self::is_safe_path_component(part) {
                    return self.asset_root.join("INVALID");
                }
            }
        }
        self.asset_root.join(&*entry.path)
    }

    // -----------------------------------------------------------
    // Resolution helpers
    // -----------------------------------------------------------

    /// The primary query resolution method.
    ///
    /// Resolves an asset by matching the tag and applying material variants,
    /// fallback textures, and PBR scalars based on the query conditions.
    pub fn resolve_query(&self, query: &CatalogueQuery) -> Option<ResolvedAsset> {
        let catalogue_entry = self.entries.get(&query.tag)?;

        // Construct context once outside the loop
        let ctx = MaterialConditionContext {
            damage_type: query.damage_type,
            vegetation_state: query.vegetation_state,
            occupancy_state: query.occupancy_state,
            reconstruction_state: query.reconstruction_state,
            faction_tags: Arc::clone(&query.faction_tags),
        };

        for variant in &catalogue_entry.variants {
            // Track if we use explicit overrides or fall back to defaults
            let (fallback_albedo, fallback_normal) = self
                .fallback_provider
                .textures(catalogue_entry.metadata.category.clone(), variant.variant)
                .map(|(a, n)| (Some(a), Some(n)))
                .unwrap_or((None, None));

            let (fallback_roughness, fallback_metallic) = self
                .fallback_provider
                .pbr_scalars(variant.variant)
                .map(|(r, m)| (Some(r), Some(m)))
                .unwrap_or((None, None));

            // Determine material origin based on whether explicit overrides exist
            let material_origin = if variant.overrides.albedo_texture.is_some()
                || variant.overrides.normal_texture.is_some()
                || variant.overrides.roughness_metallic_texture.is_some()
                || variant.overrides.perceptual_roughness.is_some()
                || variant.overrides.metallic.is_some()
                || variant.overrides.base_color_tint.is_some()
                || variant.overrides.emissive.is_some()
            {
                MaterialOrigin::Explicit
            } else {
                MaterialOrigin::Fallback
            };

            if variant.condition.matches_context(&ctx, &|key, dt, vs| {
                MaterialVariantContext {
                    material_key: String::new(),
                    damage_type: dt.cloned(),
                    vegetation_state: *vs,
                }
                .material_key(Some(key))
            }) {
                let overrides = MaterialOverride {
                    albedo_texture: variant.overrides.albedo_texture.clone().or(fallback_albedo),
                    normal_texture: variant.overrides.normal_texture.clone().or(fallback_normal),
                    roughness_metallic_texture: variant
                        .overrides
                        .roughness_metallic_texture
                        .clone(),
                    perceptual_roughness: variant
                        .overrides
                        .perceptual_roughness
                        .or(fallback_roughness),
                    metallic: variant.overrides.metallic.or(fallback_metallic),
                    base_color_tint: variant.overrides.base_color_tint,
                    emissive: variant.overrides.emissive,
                };

                return Some(ResolvedAsset {
                    mesh_path: variant
                        .mesh_path
                        .clone()
                        .unwrap_or_else(|| Arc::clone(&catalogue_entry.entry.path)),
                    material_key: Some(Arc::clone(&variant.material_key)),
                    variant: Some(variant.variant),
                    material: Some(overrides),
                    material_origin,
                });
            }
        }

        Some(ResolvedAsset {
            mesh_path: Arc::clone(&catalogue_entry.entry.path),
            material_key: None,
            variant: None,
            material: None,
            material_origin: MaterialOrigin::Fallback,
        })
    }

    /// Returns a diagnostic result explaining why resolution failed.
    ///
    /// Unlike `resolve_query` which returns `None` on failure, this method
    /// returns a `QueryDiagnostic` enum that explains the reason for failure,
    /// such as unknown tag, no matching variant, or unsupported condition.
    pub fn resolve_query_diagnostic(
        &self,
        query: &CatalogueQuery,
    ) -> Result<ResolvedAsset, QueryDiagnostic> {
        use crate::types::QueryDiagnostic;

        let catalogue_entry = self
            .entries
            .get(&query.tag)
            .ok_or_else(|| QueryDiagnostic::UnknownTag(query.tag.clone()))?;

        let mut tried = Vec::new();

        // Construct context once outside the loop
        let ctx = MaterialConditionContext {
            damage_type: query.damage_type,
            vegetation_state: query.vegetation_state,
            occupancy_state: query.occupancy_state,
            reconstruction_state: query.reconstruction_state,
            faction_tags: Arc::clone(&query.faction_tags),
        };

        for variant in &catalogue_entry.variants {
            tried.push(format!("{}", variant.condition));

            // Reuse the matching logic from resolve_query
            let matches = variant.condition.matches_context(&ctx, &|key, dt, vs| {
                MaterialVariantContext {
                    material_key: String::new(),
                    damage_type: dt.cloned(),
                    vegetation_state: *vs,
                }
                .material_key(Some(key))
            });

            if matches {
                // Build and return ResolvedAsset (same as resolve_query)
                let (fallback_albedo, fallback_normal) = self
                    .fallback_provider
                    .textures(catalogue_entry.metadata.category.clone(), variant.variant)
                    .map(|(a, n)| (Some(a), Some(n)))
                    .unwrap_or((None, None));

                let (fallback_roughness, fallback_metallic) = self
                    .fallback_provider
                    .pbr_scalars(variant.variant)
                    .map(|(r, m)| (Some(r), Some(m)))
                    .unwrap_or((None, None));

                // Determine material origin based on whether explicit overrides exist
                let material_origin = if variant.overrides.albedo_texture.is_some()
                    || variant.overrides.normal_texture.is_some()
                    || variant.overrides.roughness_metallic_texture.is_some()
                    || variant.overrides.perceptual_roughness.is_some()
                    || variant.overrides.metallic.is_some()
                    || variant.overrides.base_color_tint.is_some()
                    || variant.overrides.emissive.is_some()
                {
                    MaterialOrigin::Explicit
                } else {
                    MaterialOrigin::Fallback
                };

                let overrides = MaterialOverride {
                    albedo_texture: variant.overrides.albedo_texture.clone().or(fallback_albedo),
                    normal_texture: variant.overrides.normal_texture.clone().or(fallback_normal),
                    roughness_metallic_texture: variant
                        .overrides
                        .roughness_metallic_texture
                        .clone(),
                    perceptual_roughness: variant
                        .overrides
                        .perceptual_roughness
                        .or(fallback_roughness),
                    metallic: variant.overrides.metallic.or(fallback_metallic),
                    base_color_tint: variant.overrides.base_color_tint,
                    emissive: variant.overrides.emissive,
                };

                return Ok(ResolvedAsset {
                    mesh_path: variant
                        .mesh_path
                        .clone()
                        .unwrap_or_else(|| Arc::clone(&catalogue_entry.entry.path)),
                    material_key: Some(Arc::clone(&variant.material_key)),
                    variant: Some(variant.variant),
                    material: Some(overrides),
                    material_origin,
                });
            }
        }

        // No variant matched - return the basic asset with no material overrides
        Err(QueryDiagnostic::NoVariantMatch {
            tag: query.tag.clone(),
            tried,
        })
    }

    /// Resolves an asset by tag with explicit damage and vegetation state.
    /// A convenience wrapper around `resolve_query`.
    pub fn resolve_with_context(
        &self,
        tag: &ArchetypeTag,
        damage_type: Option<DamageType>,
        vegetation_state: VegetationState,
    ) -> Option<ResolvedAsset> {
        self.resolve_query(&CatalogueQuery {
            tag: tag.clone(),
            damage_type,
            vegetation_state,
            occupancy_state: None,
            reconstruction_state: None,
            faction_tags: Arc::from(Vec::<String>::new()),
        })
    }

    /// Resolves an asset by tag using a full material condition context.
    /// A convenience wrapper around `resolve_query`.
    pub fn resolve_with_state_context(
        &self,
        tag: &ArchetypeTag,
        context: &MaterialConditionContext,
    ) -> Option<ResolvedAsset> {
        self.resolve_query(&CatalogueQuery {
            tag: tag.clone(),
            damage_type: context.damage_type,
            vegetation_state: context.vegetation_state,
            occupancy_state: context.occupancy_state,
            reconstruction_state: context.reconstruction_state,
            faction_tags: context.faction_tags.clone(),
        })
    }

    /// Generates a material key string for the given resolution context.
    /// Used for fallback material selection.
    pub fn material_key_for_context(&self, context: &ResolutionContext) -> String {
        let biome = context
            .biome_tags
            .first()
            .map(|tag| tag.to_string())
            .unwrap_or_else(|| "generic".to_string());
        let category = match context.category {
            AssetCategory::Landmark => "landmark",
            AssetCategory::ArchitectureKit => "architecture_kit",
            AssetCategory::Vegetation => "vegetation",
            AssetCategory::Prop => "prop",
            AssetCategory::TerrainDetail => "terrain_detail",
            AssetCategory::Decal => "decal",
        };
        format!("{biome}_{category}")
    }
}
