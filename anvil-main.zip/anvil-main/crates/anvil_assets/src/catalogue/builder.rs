//! Builder for [`AssetCatalogue`].

use crate::defaults::{DefaultFallbackProvider, FallbackProvider};
use crate::types::{default_footprint, AssetEntry, AssetKind, AssetMetadata};
use anvil_core::ArchetypeTag;
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;

use super::{CatalogueEntry, AssetCatalogue};

/// Builder for [`AssetCatalogue`].
///
/// All fields are optional and have sensible defaults.
///
/// # Examples
///
/// ```rust,no_run
/// use anvil_assets::prelude::*;
/// use std::path::PathBuf;
/// use std::sync::Arc;
///
/// let catalogue = CatalogueBuilder::new()
///     .with_asset_root(PathBuf::from("assets"))
///     .with_version(1)
///     .entry(AssetEntry {
///         tag: ArchetypeTag::new("test_asset").expect("valid tag"),
///         path: Arc::new(PathBuf::from("test.glb")),
///         kind: AssetKind::Mesh,
///         tags: vec![],
///         footprint_radius: 1.0,
///     })
///     .build();
/// ```
#[derive(Default)]
pub struct CatalogueBuilder {
    entries: HashMap<ArchetypeTag, CatalogueEntry>,
    asset_root: PathBuf,
    version: u32,
    fallback_provider: Option<Arc<dyn FallbackProvider>>,
}

impl CatalogueBuilder {
    /// Creates a new builder with default values.
    pub fn new() -> Self {
        Self {
            entries: HashMap::new(),
            asset_root: PathBuf::from("."),
            version: 1,
            fallback_provider: None,
        }
    }

    /// Sets a custom fallback provider. If not set, defaults to `DefaultFallbackProvider`.
    /// Sets a custom fallback provider. If not set, defaults to `DefaultFallbackProvider`.
    pub fn with_fallback_provider(mut self, provider: Arc<dyn FallbackProvider>) -> Self {
        self.fallback_provider = Some(provider);
        self
    }

    /// Adds an asset entry to the catalogue.
    pub fn entry(mut self, entry: AssetEntry) -> Self {
        let tag = entry.tag.clone();
        let catalogue_entry = CatalogueEntry {
            entry,
            metadata: AssetMetadata::fallback(&tag),
            variants: Vec::new(),
        };
        self.entries.insert(tag, catalogue_entry);
        self
    }

    /// Sets the metadata for an existing or new entry with the given tag.
    pub fn metadata(mut self, tag: ArchetypeTag, meta: AssetMetadata) -> Self {
        let catalogue_entry = self
            .entries
            .entry(tag.clone())
            .or_insert_with(|| CatalogueEntry {
                entry: AssetEntry {
                    tag: tag.clone(),
                    path: Arc::new(PathBuf::new()),
                    kind: AssetKind::Mesh,
                    tags: vec![],
                    footprint_radius: default_footprint(),
                },
                metadata: AssetMetadata::fallback(&tag),
                variants: Vec::new(),
            });
        catalogue_entry.metadata = meta;
        self
    }

    /// Adds a material variant to an existing or new entry with the given tag.
    pub fn variant(mut self, tag: ArchetypeTag, variant: crate::types::MaterialVariantEntry) -> Self {
        let catalogue_entry = self
            .entries
            .entry(tag.clone())
            .or_insert_with(|| CatalogueEntry {
                entry: AssetEntry {
                    tag: tag.clone(),
                    path: Arc::new(PathBuf::new()),
                    kind: AssetKind::Mesh,
                    tags: vec![],
                    footprint_radius: default_footprint(),
                },
                metadata: AssetMetadata::fallback(&tag),
                variants: Vec::new(),
            });
        catalogue_entry.variants.push(variant);
        self
    }

    /// Sets the asset root directory for the catalogue.
    pub fn with_asset_root(mut self, root: PathBuf) -> Self {
        self.asset_root = root;
        self
    }

    /// Sets the catalogue version number.
    pub fn with_version(mut self, v: u32) -> Self {
        self.version = v;
        self
    }

    /// Build the catalogue, collecting validation errors but still returning it.
    pub fn build(self) -> AssetCatalogue {
        let mut validation_errors = Vec::new();
        for catalogue_entry in self.entries.values() {
            validation_errors.extend(catalogue_entry.entry.validate());
            validation_errors.extend(catalogue_entry.metadata.validate());
            for v in &catalogue_entry.variants {
                validation_errors.extend(v.validate());
            }
        }

        let fallback_provider = self
            .fallback_provider
            .unwrap_or_else(|| Arc::new(DefaultFallbackProvider));

        AssetCatalogue {
            entries: self.entries,
            asset_root: self.asset_root,
            version: self.version,
            validation_errors,
            fallback_provider,
        }
    }

    /// Build the catalogue, returning an error if validation fails.
    pub fn build_strict(self) -> Result<AssetCatalogue, super::CatalogueError> {
        let catalogue = self.build();
        if catalogue.validation_errors().is_empty() {
            Ok(catalogue)
        } else {
            Err(super::CatalogueError::ValidationFailed(
                catalogue.validation_errors().clone(),
            ))
        }
    }
}
