//! [`AssetCatalogue`] implementation: loading, resolution, family
//! helpers, and material coverage reports.

mod builder;
mod coverage;
mod loader;
mod query;

use anvil_core::{ArchetypeTag, ValidationErrors};
use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Arc;
use thiserror::Error;

use crate::defaults::FallbackProvider;
use crate::types::{AssetEntry, AssetMetadata, MaterialVariantEntry};

pub use builder::CatalogueBuilder;
pub use coverage::MaterialCoverageReport;

/// A single entry in the asset catalogue, bundling the asset entry,
/// its metadata, and any material variant overrides.
#[derive(Debug, Clone)]
pub struct CatalogueEntry {
    pub entry: AssetEntry,
    pub metadata: AssetMetadata,
    pub variants: Vec<MaterialVariantEntry>,
}

/// The central asset catalogue for the Anvil pipeline.
///
/// Use [`FallbackProvider`] as the plug-in for custom fallback textures.
///
/// # Examples
///
/// ```rust,no_run
/// use anvil_assets::prelude::*;
///
/// let catalogue = AssetCatalogue::from_entries(vec![]);
/// let tag = ArchetypeTag::new("highlands_standing_stone").expect("valid tag");
///
/// if let Some(asset) = catalogue.resolve(&tag) {
///     println!("Mesh: {:?}", asset.path);
/// }
/// ```
#[derive(Debug, Clone)]
pub struct AssetCatalogue {
    /// Map from archetype tag to catalogue entry.
    entries: HashMap<ArchetypeTag, CatalogueEntry>,
    /// The root directory for asset paths.
    pub asset_root: PathBuf,
    /// The catalogue version number.
    version: u32,
    /// Validation errors collected during loading.
    validation_errors: ValidationErrors,
    fallback_provider: Arc<dyn FallbackProvider>,
}

impl Default for AssetCatalogue {
    /// Creates an empty default catalogue with no entries.
    /// Useful as a fallback when catalogue loading fails.
    fn default() -> Self {
        Self {
            entries: HashMap::new(),
            asset_root: PathBuf::from("."),
            version: 1,
            validation_errors: ValidationErrors::new(),
            fallback_provider: Arc::new(crate::defaults::DefaultFallbackProvider),
        }
    }
}

impl AssetCatalogue {
    /// Returns a reference to the fallback provider.
    pub fn fallback_provider(&self) -> &Arc<dyn FallbackProvider> {
        &self.fallback_provider
    }

    /// Creates a new catalogue with a custom fallback provider.
    pub fn with_fallback(self, provider: Arc<dyn FallbackProvider>) -> Self {
        Self {
            entries: self.entries,
            asset_root: self.asset_root,
            version: self.version,
            validation_errors: self.validation_errors,
            fallback_provider: provider,
        }
    }

    /// Creates a new empty catalogue. Same as Default::default().
    pub fn new() -> Self {
        Self::default()
    }

    /// Check if the catalogue is empty (no entries).
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Returns a vector of all asset entries in the catalogue.
    pub fn asset_entries(&self) -> Vec<&AssetEntry> {
        self.entries.values().map(|e| &e.entry).collect()
    }

    /// Returns a cloned vector of all asset entries in the catalogue.
    /// Useful for serialization.
    pub fn asset_entries_cloned(&self) -> Vec<AssetEntry> {
        self.entries.values().map(|e| e.entry.clone()).collect()
    }

    /// Returns a vector of all catalogue entries (entry + metadata + variants).
    pub fn all_catalogue_entries(&self) -> Vec<(&ArchetypeTag, &CatalogueEntry)> {
        self.entries.iter().collect()
    }
}

/// Result type for manifest parsing.
pub type ParseManifestResult = Result<
    (u32, HashMap<ArchetypeTag, CatalogueEntry>, ValidationErrors),
    CatalogueError,
>;

/// Errors that can occur during catalogue operations.
#[derive(Debug, Error)]
#[non_exhaustive]
pub enum CatalogueError {
    /// Failed to read the catalogue file from disk.
    #[error("failed to read catalogue file: {0}")]
    IoError(#[from] std::io::Error),
    /// Failed to parse the catalogue JSON file.
    #[error("failed to parse catalogue JSON: {0}")]
    ParseError(#[from] serde_json::Error),
    /// The catalogue version is not supported by this version of the code.
    #[error("unsupported catalogue version: {0}")]
    UnsupportedVersion(u32),
    /// An archetype tag appears more than once in the catalogue.
    #[error("duplicate archetype tag: {0:?}")]
    DuplicateTag(ArchetypeTag),
    /// An asset referenced by an entry was not found on disk.
    #[error("referenced asset file not found: {path} (tag {tag:?})")]
    ReferencedAssetNotFound {
        /// The archetype tag of the missing asset.
        tag: ArchetypeTag,
        /// The filesystem path where the asset was expected to be found.
        path: PathBuf,
    },
    /// One or more catalogue entries failed validation.
    #[error("catalogue validation failed with {} errors", _0.len())]
    ValidationFailed(ValidationErrors),
}
