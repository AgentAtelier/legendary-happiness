//! Catalogue loading from JSON manifest files.

use crate::defaults::DefaultFallbackProvider;
use crate::types::{
    default_footprint, AssetCategory, AssetEntry, AssetKind, AssetMetadata, BiomeTag,
    MaterialOverride, MaterialVariantEntry,
};
use anvil_core::{ArchetypeTag, FailureClass, ValidationErrors};
use anvil_core::{error_buffer, push_validation_error};
use chrono::NaiveDate;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::str::FromStr;
use std::sync::Arc;

use super::{CatalogueEntry, CatalogueError, ParseManifestResult};

/// A single catalogue entry compatible with both V1 and V2 JSON.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ManifestEntry {
    pub tag: ArchetypeTag,
    /// In V1 the field is called `path`; V2 calls it `mesh_path`.
    #[serde(alias = "path")]
    pub mesh_path: PathBuf,
    pub kind: AssetKind,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default = "default_footprint_manifest")]
    pub footprint_radius: f32,
    #[serde(default)]
    pub display_name: String,
    #[serde(default)]
    pub category: Option<AssetCategory>,
    #[serde(default)]
    pub biome_tags: Vec<String>,
    #[serde(default)]
    pub faction_tags: Vec<String>,
    #[serde(default)]
    pub style_tags: Vec<String>,
    #[serde(default)]
    pub narrative_tags: Vec<String>,
    #[serde(default)]
    pub validated: bool,
    #[serde(default)]
    pub validation_date: Option<String>,
    #[serde(default)]
    pub material_variants: Vec<MaterialVariantEntry>,
}

fn default_footprint_manifest() -> f32 {
    default_footprint()
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ManifestEnvelope {
    pub version: u32,
    pub entries: Vec<ManifestEntry>,
}

/// Placeholder for a future V3 format.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct V3Manifest {
    pub version: u32,
}

impl ManifestEntry {
    /// Validate this raw entry before we convert it.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.tag.as_str().trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E044",
                "ManifestEntry",
                "tag",
                self.tag.as_str().to_string(),
                "archetype tag must not be empty"
            );
        }
        if self.mesh_path.as_os_str().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E045",
                "ManifestEntry",
                "mesh_path",
                self.mesh_path.display().to_string(),
                "mesh path must not be empty"
            );
        }
        if self.footprint_radius <= 0.0 {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E046",
                "ManifestEntry",
                "footprint_radius",
                self.footprint_radius.to_string(),
                "footprint_radius must be > 0"
            );
        }
        errors
    }
}

/// Parse a catalogue manifest (V1 or V2) into a single unified map.
pub fn parse_manifest(raw_value: serde_json::Value) -> ParseManifestResult {
    let version = raw_value
        .get("version")
        .and_then(|v| v.as_u64())
        .unwrap_or(1) as u32;

    let entries: Vec<ManifestEntry> = match version {
        1 | 2 => {
            let envelope: ManifestEnvelope = serde_json::from_value(raw_value)?;
            envelope.entries
        }
        3 => {
            let _v3: V3Manifest = serde_json::from_value(raw_value)?;
            return Err(CatalogueError::UnsupportedVersion(3));
        }
        other => return Err(CatalogueError::UnsupportedVersion(other)),
    };

    let mut asset_map = HashMap::new();
    let mut manifest_errors = error_buffer();

    for manifest_entry in entries {
        let entry_errors = manifest_entry.validate();
        manifest_errors.extend(entry_errors);

        if let Some(date_str) = &manifest_entry.validation_date {
            if date_str.trim().is_empty() {
                push_validation_error!(
                    manifest_errors,
                    FailureClass::Asset,
                    "E047",
                    "ManifestEntry",
                    "validation_date",
                    date_str.clone(),
                    "validation_date must not be empty or whitespace"
                );
            } else if NaiveDate::parse_from_str(date_str, "%Y-%m-%d").is_err() {
                push_validation_error!(
                    manifest_errors,
                    FailureClass::Asset,
                    "E047",
                    "ManifestEntry",
                    "validation_date",
                    date_str.clone(),
                    format!(
                        "validation_date '{}' is not a valid ISO date (YYYY-MM-DD)",
                        date_str
                    )
                );
            }
        }

        let tag = manifest_entry.tag.clone();

        if asset_map.contains_key(&tag) {
            return Err(CatalogueError::DuplicateTag(tag));
        }

        let asset_entry = AssetEntry {
            tag: tag.clone(),
            path: Arc::new(manifest_entry.mesh_path.clone()),
            kind: manifest_entry.kind,
            tags: manifest_entry.tags.clone(),
            footprint_radius: manifest_entry.footprint_radius,
        };

        let metadata = if version == 1 {
            AssetMetadata::fallback(&tag)
        } else {
            AssetMetadata {
                display_name: Arc::from(if manifest_entry.display_name.trim().is_empty() {
                    tag.as_str()
                } else {
                    manifest_entry.display_name.as_str()
                }),
                category: manifest_entry.category.unwrap_or(AssetCategory::Landmark),
                biome_tags: manifest_entry
                    .biome_tags
                    .iter()
                    .filter_map(|t| BiomeTag::from_str(t).ok())
                    .collect(),
                faction_tags: manifest_entry
                    .faction_tags
                    .iter()
                    .map(|s| Arc::from(s.as_str()))
                    .collect(),
                style_tags: manifest_entry
                    .style_tags
                    .iter()
                    .map(|s| Arc::from(s.as_str()))
                    .collect(),
                narrative_tags: manifest_entry
                    .narrative_tags
                    .iter()
                    .map(|s| Arc::from(s.as_str()))
                    .collect(),
                validated: manifest_entry.validated,
                validation_date: manifest_entry
                    .validation_date
                    .as_deref()
                    .and_then(|s| NaiveDate::parse_from_str(s, "%Y-%m-%d").ok()),
            }
        };

        let variants = if version == 2 && !manifest_entry.material_variants.is_empty() {
            manifest_entry
                .material_variants
                .into_iter()
                .map(|v| MaterialVariantEntry {
                    variant: v.variant,
                    material_key: v.material_key,
                    mesh_path: v.mesh_path,
                    condition: v.condition,
                    overrides: MaterialOverride {
                        albedo_texture: v.overrides.albedo_texture,
                        normal_texture: v.overrides.normal_texture,
                        roughness_metallic_texture: v.overrides.roughness_metallic_texture,
                        perceptual_roughness: v.overrides.perceptual_roughness,
                        metallic: v.overrides.metallic,
                        base_color_tint: v.overrides.base_color_tint,
                        emissive: v.overrides.emissive,
                    },
                })
                .collect()
        } else {
            Vec::new()
        };

        asset_map.insert(
            tag,
            CatalogueEntry {
                entry: asset_entry,
                metadata,
                variants,
            },
        );
    }

    Ok((version, asset_map, manifest_errors))
}

impl super::AssetCatalogue {
    /// Load a catalogue, failing if any entry, metadata, or variant fails validation.
    pub fn load_strict(
        manifest_path: &Path,
        asset_root: Option<&Path>,
    ) -> Result<Self, CatalogueError> {
        let catalogue = Self::load(manifest_path, asset_root)?;
        if catalogue.validation_errors().is_empty() {
            Ok(catalogue)
        } else {
            Err(CatalogueError::ValidationFailed(
                catalogue.validation_errors().clone(),
            ))
        }
    }

    /// Load a catalogue from a JSON manifest file.
    ///
    /// - `manifest_path`: Path to the catalogue JSON file
    /// - `asset_root`: Optional override for the asset root directory (defaults to manifest's parent)
    ///
    /// Collects validation errors but still returns the catalogue.
    /// Use `load_strict` to fail on any validation errors.
    pub fn load(manifest_path: &Path, asset_root: Option<&Path>) -> Result<Self, CatalogueError> {
        let content = std::fs::read_to_string(manifest_path)?;
        let root = asset_root.map(PathBuf::from).unwrap_or_else(|| {
            manifest_path
                .parent()
                .unwrap_or(Path::new("."))
                .to_path_buf()
        });

        let raw_value: serde_json::Value = serde_json::from_str(&content)?;
        let (version, entries, manifest_errors) = parse_manifest(raw_value)?;

        let mut validation_errors = manifest_errors;
        for entry in entries.values() {
            validation_errors.extend(entry.entry.validate());
            validation_errors.extend(entry.metadata.validate());
            for v in &entry.variants {
                validation_errors.extend(v.validate());
            }
        }

        Ok(Self {
            entries,
            asset_root: root,
            version,
            validation_errors,
            fallback_provider: Arc::new(DefaultFallbackProvider),
        })
    }

    /// Creates an `AssetCatalogue` from a vector of `AssetEntry` entries.
    ///
    /// Validates each entry and collects any validation errors.
    pub fn from_entries(entries: Vec<AssetEntry>) -> Self {
        let mut map = HashMap::new();
        let mut validation_errors = Vec::new();
        for entry in entries {
            let tag = entry.tag.clone();
            validation_errors.extend(entry.validate());
            map.insert(
                tag,
                CatalogueEntry {
                    entry: entry.clone(),
                    metadata: AssetMetadata::fallback(&entry.tag),
                    variants: Vec::new(),
                },
            );
        }
        Self {
            entries: map,
            asset_root: PathBuf::from("."),
            version: 1,
            validation_errors,
            fallback_provider: Arc::new(DefaultFallbackProvider),
        }
    }
}
