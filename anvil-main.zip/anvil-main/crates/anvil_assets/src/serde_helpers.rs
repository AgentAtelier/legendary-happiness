//! Serde helper functions for Arc types.

use serde::{ser::SerializeSeq, Deserialize, Deserializer, Serializer};
use std::path::PathBuf;
use std::sync::Arc;

// Serde helper functions for Arc<str>
pub fn serialize_arc_str<S: Serializer>(
    value: &Arc<str>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    serializer.serialize_str(value.as_ref())
}

pub fn deserialize_arc_str<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Arc<str>, D::Error> {
    let s: String = Deserialize::deserialize(deserializer)?;
    Ok(Arc::from(s))
}

// Serde helper functions for Option<Arc<str>>
pub fn serialize_option_arc_str<S: Serializer>(
    value: &Option<Arc<str>>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    match value {
        Some(v) => serializer.serialize_str(v.as_ref()),
        None => serializer.serialize_none(),
    }
}

pub fn deserialize_option_arc_str<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<Arc<str>>, D::Error> {
    Option::<String>::deserialize(deserializer).map(|s| s.map(Arc::from))
}

// Serde helper functions for Arc<PathBuf>
pub fn serialize_arc_pathbuf<S: Serializer>(
    value: &Arc<PathBuf>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    serializer.collect_str(&value.to_string_lossy())
}

pub fn deserialize_arc_pathbuf<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Arc<PathBuf>, D::Error> {
    let s: String = Deserialize::deserialize(deserializer)?;
    Ok(Arc::new(PathBuf::from(s)))
}

// Serde helper functions for Option<Arc<PathBuf>>
pub fn serialize_option_arc_pathbuf<S: Serializer>(
    value: &Option<Arc<PathBuf>>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    match value {
        Some(v) => serializer.collect_str(&v.to_string_lossy()),
        None => serializer.serialize_none(),
    }
}

pub fn deserialize_option_arc_pathbuf<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<Arc<PathBuf>>, D::Error> {
    Option::<String>::deserialize(deserializer).map(|s| s.map(|s| Arc::new(PathBuf::from(s))))
}

// Serde helper functions for Vec<Arc<str>>
pub fn serialize_arc_str_vec<S: Serializer>(
    values: &Vec<Arc<str>>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    let mut seq = serializer.serialize_seq(Some(values.len()))?;
    for value in values {
        seq.serialize_element(value.as_ref())?;
    }
    seq.end()
}

pub fn deserialize_arc_str_vec<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Vec<Arc<str>>, D::Error> {
    let vec: Vec<String> = Deserialize::deserialize(deserializer)?;
    Ok(vec.into_iter().map(Arc::from).collect())
}

// Serde helper for Arc<[String]>
pub fn serialize_arc_string_slice<S: Serializer>(
    values: &Arc<[String]>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    let mut seq = serializer.serialize_seq(Some(values.len()))?;
    for value in values.iter() {
        seq.serialize_element(value)?;
    }
    seq.end()
}

pub fn deserialize_arc_string_slice<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Arc<[String]>, D::Error> {
    let vec: Vec<String> = Deserialize::deserialize(deserializer)?;
    Ok(Arc::from(vec))
}
