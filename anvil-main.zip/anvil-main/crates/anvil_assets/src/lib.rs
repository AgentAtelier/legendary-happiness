#![deny(warnings)]
#![cfg_attr(not(test), deny(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::unreachable, clippy::todo))]
#![deny(missing_docs)]
//!
//! # anvil_assets
//!
//! Asset catalogue, material variant resolution, and prompt enrichment.
//!
//! This is a pure runtime library. For the external asset normalization
//! pipeline, see the `anvil_assets_pipeline` crate.
//!
//! ## Getting started
//!
//! Load a catalogue from a JSON file and resolve an asset query:
//!
//! ```rust,no_run
//! use anvil_assets::prelude::*;
//!
//! let tag = ArchetypeTag::new("highlands_ruin").expect("valid tag");
//! let catalogue = AssetCatalogue::from_entries(vec![]);
//! let query = CatalogueQuery::new(tag).with_damage(DamageType::Fire);
//! ```
//!
//! ## Extension points
//!
//! - **[`FallbackProvider`]** — customise fallback textures and PBR scalars
//! - **[`StyleProvider`]** — customise LLM prompt style suffixes
//!
//! ## Error handling
//!
//! This crate uses a simple, structured error system:
//!
//! - `ValidationErrors` — for catalogue and asset validation
//!   failures. Structured with error codes from `anvil_core`.

pub mod prelude {
    //! Re-exports the most common runtime types for convenience.
    //! Use `use anvil_assets::prelude::*;` to get started quickly.
    pub use crate::catalogue::{
        AssetCatalogue, CatalogueBuilder, CatalogueError, MaterialCoverageReport,
    };
    pub use crate::defaults::{
        DefaultFallbackProvider, FallbackProvider, MaterialFallback, fallback_table, get_fallback,
        get_fallback_table,
    };
    pub use crate::enrichment::{
        AssetRequestContractError, AssetRequestEnricher, DefaultStyleProvider,
        EnrichedAssetRequest, PromptTemplate, StyleProvider,
    };

    pub use crate::types::{
        AssetCategory, AssetEntry, AssetKind, AssetMetadata, BiomeTag, CatalogueQuery,
        MaterialCondition, MaterialConditionContext, MaterialOrigin, MaterialOverride,
        MaterialVariant, MaterialVariantContext, MaterialVariantEntry, QueryDiagnostic,
        ResolutionContext, ResolvedAsset,
    };
    // Re-export key anvil_core types so game code doesn't need to import anvil_core separately.
    pub use anvil_core::{
        ArchetypeTag, DamageType, SettlementOccupancyState, SettlementReconstructionState,
        TerrainType, VegetationState,
    };
}

mod catalogue;
mod defaults;
mod enrichment;
mod types;

pub use catalogue::{AssetCatalogue, CatalogueBuilder, CatalogueError, MaterialCoverageReport};
pub use defaults::{
    fallback_table, get_fallback, get_fallback_table, DefaultFallbackProvider,
    FallbackProvider, MaterialFallback,
};
pub use enrichment::{
    enrich_asset_request_spec, AssetRequestContractError, AssetRequestEnricher,
    DefaultStyleProvider, EnrichedAssetRequest, PromptTemplate, StyleProvider,
};
pub use types::{
    default_footprint,
    // Serde helpers for Arc types
    deserialize_arc_pathbuf,
    deserialize_arc_str,
    deserialize_arc_str_vec,
    deserialize_arc_string_slice,
    deserialize_option_arc_pathbuf,
    deserialize_option_arc_str,
    serialize_arc_pathbuf,
    serialize_arc_str,
    serialize_arc_str_vec,
    serialize_arc_string_slice,
    serialize_option_arc_pathbuf,
    serialize_option_arc_str,
    AssetCategory,
    AssetEntry,
    AssetKind,
    AssetMetadata,
    BiomeTag,
    CatalogueQuery,
    MaterialCondition,
    MaterialConditionContext,
    MaterialOrigin,
    MaterialOverride,
    MaterialVariant,
    MaterialVariantContext,
    MaterialVariantEntry,
    ParseMaterialVariantError,
    QueryDiagnostic,
    ResolutionContext,
    ResolvedAsset,
};
