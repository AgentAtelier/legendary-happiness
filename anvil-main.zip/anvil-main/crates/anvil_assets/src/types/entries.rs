//! Asset entry and metadata types.

use anvil_core::{ArchetypeTag, FailureClass, ValidationErrors};
use anvil_core::{error_buffer, push_validation_error};
use chrono::NaiveDate;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;

use super::biome::BiomeTag;
use super::serde::{
    default_footprint, deserialize_arc_pathbuf, deserialize_arc_str, deserialize_arc_str_vec,
    serialize_arc_pathbuf, serialize_arc_str, serialize_arc_str_vec,
};

/// The category of an asset in the catalogue.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum AssetKind {
    /// A 3D mesh asset (e.g., GLB, FBX).
    Mesh,
    /// A texture asset (e.g., PNG, JPG).
    Texture,
    /// A material definition with PBR properties.
    Material,
    /// An audio asset (e.g., WAV, OGG).
    Audio,
}

/// A single entry in the asset catalogue, referencing a source file.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AssetEntry {
    /// The archetype tag that identifies this asset (e.g., "highlands_tower_ruined").
    pub tag: ArchetypeTag,
    /// Filesystem path to the asset file, relative to the asset root.
    #[serde(
        deserialize_with = "deserialize_arc_pathbuf",
        serialize_with = "serialize_arc_pathbuf"
    )]
    pub path: Arc<PathBuf>,
    /// The kind of asset (mesh, texture, material, audio).
    pub kind: AssetKind,
    /// Free-form tags for additional categorization.
    #[serde(default)]
    pub tags: Vec<String>,
    /// The radius of the asset's footprint in world units. Used for placement and collision.
    #[serde(default = "default_footprint")]
    pub footprint_radius: f32,
}

/// The broad category of an asset for filtering and fallback selection.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum AssetCategory {
    /// A significant world feature (monument, ruin, tower, etc.).
    #[default]
    Landmark,
    /// A modular building or structure kit.
    ArchitectureKit,
    /// Flora and plant life assets.
    Vegetation,
    /// A standalone decor object.
    Prop,
    /// Small terrain-aligned details (rocks, pebbles, etc.).
    TerrainDetail,
    /// A surface decal.
    Decal,
}

impl AssetCategory {
    /// Returns `true` if assets of this category receive state-aware
    /// material fallback overrides (textures, PBR scalars).
    pub fn is_covered_family(&self) -> bool {
        matches!(
            self,
            AssetCategory::Landmark | AssetCategory::ArchitectureKit | AssetCategory::TerrainDetail
        )
    }
}

/// Metadata associated with an asset entry.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AssetMetadata {
    /// Human-readable display name for this asset.
    #[serde(
        deserialize_with = "deserialize_arc_str",
        serialize_with = "serialize_arc_str"
    )]
    pub display_name: Arc<str>,
    /// The broad category this asset belongs to.
    pub category: AssetCategory,
    /// Biome tags that this asset is suitable for (e.g., forest, desert, highlands).
    pub biome_tags: Vec<BiomeTag>,
    /// Faction tags associated with this asset.
    #[serde(
        deserialize_with = "deserialize_arc_str_vec",
        serialize_with = "serialize_arc_str_vec"
    )]
    pub faction_tags: Vec<Arc<str>>,
    /// Style tags describing the visual style of this asset.
    #[serde(
        deserialize_with = "deserialize_arc_str_vec",
        serialize_with = "serialize_arc_str_vec"
    )]
    pub style_tags: Vec<Arc<str>>,
    /// Narrative tags for storytelling purposes.
    #[serde(
        deserialize_with = "deserialize_arc_str_vec",
        serialize_with = "serialize_arc_str_vec"
    )]
    pub narrative_tags: Vec<Arc<str>>,
    /// Whether this asset has passed validation.
    pub validated: bool,
    /// The date this asset was validated, if applicable.
    pub validation_date: Option<NaiveDate>,
}

impl AssetMetadata {
    pub(crate) fn fallback(tag: &ArchetypeTag) -> Self {
        Self {
            display_name: Arc::from(tag.as_str()),
            category: AssetCategory::Landmark,
            biome_tags: Vec::new(),
            faction_tags: Vec::new(),
            style_tags: Vec::new(),
            narrative_tags: Vec::new(),
            validated: false,
            validation_date: None,
        }
    }

    /// Validates the metadata, returning a vector of validation errors.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.display_name.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E043",
                "AssetMetadata",
                "display_name",
                self.display_name.to_string(),
                "display_name must not be empty"
            );
        }
        errors
    }
}

impl AssetEntry {
    /// Validates the entry, returning a vector of validation errors.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.path.as_os_str().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E040",
                "AssetEntry",
                "path",
                self.path.to_string_lossy().to_string(),
                "asset path must not be empty"
            );
        }
        if self.footprint_radius <= 0.0 {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E041",
                "AssetEntry",
                "footprint_radius",
                self.footprint_radius.to_string(),
                "footprint_radius must be > 0"
            );
        }
        errors
    }
}

impl std::fmt::Display for AssetCategory {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            AssetCategory::Landmark => "landmark",
            AssetCategory::ArchitectureKit => "architecture_kit",
            AssetCategory::Vegetation => "vegetation",
            AssetCategory::Prop => "prop",
            AssetCategory::TerrainDetail => "terrain_detail",
            AssetCategory::Decal => "decal",
        };
        write!(f, "{}", s)
    }
}

impl std::fmt::Display for AssetKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            AssetKind::Mesh => "mesh",
            AssetKind::Texture => "texture",
            AssetKind::Material => "material",
            AssetKind::Audio => "audio",
        };
        write!(f, "{}", s)
    }
}
