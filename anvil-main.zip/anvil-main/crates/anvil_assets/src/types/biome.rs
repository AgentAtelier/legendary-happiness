//! Biome tag types.

use serde::{Deserialize, Serialize};

/// A tag identifying a biome type for asset categorization.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum BiomeTag {
    /// Coastal biome.
    Coast,
    /// Desert biome.
    Desert,
    /// Forest biome.
    Forest,
    /// Highlands biome.
    Highlands,
    /// Marsh biome.
    Marsh,
}

impl std::fmt::Display for BiomeTag {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            BiomeTag::Coast => "coast",
            BiomeTag::Desert => "desert",
            BiomeTag::Forest => "forest",
            BiomeTag::Highlands => "highlands",
            BiomeTag::Marsh => "marsh",
        };
        write!(f, "{}", s)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseBiomeError;

impl std::fmt::Display for ParseBiomeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid biome tag")
    }
}

impl std::str::FromStr for BiomeTag {
    type Err = ParseBiomeError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "coast" | "coastal" | "shore" | "beach" => Ok(BiomeTag::Coast),
            "desert" | "arid" => Ok(BiomeTag::Desert),
            "forest" | "woodland" => Ok(BiomeTag::Forest),
            "highlands" | "mountain" => Ok(BiomeTag::Highlands),
            "marsh" | "fen" => Ok(BiomeTag::Marsh),
            _ => Err(ParseBiomeError),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn biome_from_str() {
        assert_eq!("coast".parse::<BiomeTag>().ok(), Some(BiomeTag::Coast));
        assert_eq!("desert".parse::<BiomeTag>().ok(), Some(BiomeTag::Desert));
        assert_eq!("forest".parse::<BiomeTag>().ok(), Some(BiomeTag::Forest));
        assert_eq!("highlands".parse::<BiomeTag>().ok(), Some(BiomeTag::Highlands));
        assert_eq!("marsh".parse::<BiomeTag>().ok(), Some(BiomeTag::Marsh));
        assert!("invalid".parse::<BiomeTag>().is_err());
    }

    #[test]
    fn biome_display() {
        assert_eq!(format!("{}", BiomeTag::Coast), "coast");
        assert_eq!(format!("{}", BiomeTag::Desert), "desert");
        assert_eq!(format!("{}", BiomeTag::Forest), "forest");
        assert_eq!(format!("{}", BiomeTag::Highlands), "highlands");
        assert_eq!(format!("{}", BiomeTag::Marsh), "marsh");
    }
}
