//! Material variant and override types.

use anvil_core::{
    DamageType, FailureClass, SettlementOccupancyState, SettlementReconstructionState, ValidationErrors,
    VegetationState,
};
use anvil_core::{error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;


use super::biome::BiomeTag;
use super::entries::AssetCategory;
use super::serde::{
    deserialize_arc_str, deserialize_arc_string_slice,
    deserialize_option_arc_pathbuf, serialize_arc_str,
    serialize_arc_string_slice, serialize_option_arc_pathbuf,
};

/// Optional material-override fields shared by catalogue-side
/// `MaterialVariantEntry` and runtime-side `ResolvedAsset`.
///
/// Maps to Bevy `StandardMaterial` fields conceptually:
/// - `albedo_texture`: base color texture
/// - `normal_texture`: normal map
/// - `roughness_metallic_texture`: packed roughness/metallic texture
/// - `perceptual_roughness`: roughness value
/// - `metallic`: metallic value
/// - `tint`: color tint
/// - `emissive`: emissive color
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
pub struct MaterialOverride {
    /// Albedo (base color) texture path.
    #[serde(
        default,
        deserialize_with = "deserialize_option_arc_pathbuf",
        serialize_with = "serialize_option_arc_pathbuf"
    )]
    pub albedo_texture: Option<Arc<PathBuf>>,
    /// Normal map texture path.
    #[serde(
        default,
        deserialize_with = "deserialize_option_arc_pathbuf",
        serialize_with = "serialize_option_arc_pathbuf"
    )]
    pub normal_texture: Option<Arc<PathBuf>>,
    /// Packed roughness/metallic texture path.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub roughness_metallic_texture: Option<PathBuf>,
    /// Perceptual roughness value (0.0 = smooth, 1.0 = rough).
    #[serde(default)]
    pub perceptual_roughness: Option<f32>,
    /// Metallic value (0.0 = dielectric, 1.0 = metal).
    #[serde(default)]
    pub metallic: Option<f32>,
    /// Base color tint as RGBA.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub base_color_tint: Option<[f32; 4]>,
    /// Emissive color as RGB.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub emissive: Option<[f32; 3]>,
}

/// Context for resolving material variants based on asset category and biome.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ResolutionContext {
    /// The asset category being resolved.
    pub category: AssetCategory,
    /// The biome tags associated with the asset.
    pub biome_tags: Vec<BiomeTag>,
}

/// Context for material variant selection based on state.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MaterialVariantContext {
    /// The key identifying the material.
    pub material_key: String,
    /// The damage type affecting the asset.
    pub damage_type: Option<DamageType>,
    /// The vegetation state of the asset.
    pub vegetation_state: VegetationState,
}

/// Context for material condition matching.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct MaterialConditionContext {
    /// The damage type affecting the asset.
    pub damage_type: Option<DamageType>,
    /// The vegetation state of the asset.
    pub vegetation_state: VegetationState,
    /// The settlement occupancy state.
    pub occupancy_state: Option<SettlementOccupancyState>,
    /// The settlement reconstruction state.
    pub reconstruction_state: Option<SettlementReconstructionState>,
    /// The faction tags associated with the asset.
    #[serde(
        deserialize_with = "deserialize_arc_string_slice",
        serialize_with = "serialize_arc_string_slice"
    )]
    pub faction_tags: Arc<[String]>,
}

/// Condition under which a material variant should be used.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum MaterialCondition {
    /// Asset has a specific damage type.
    Damage(DamageType),
    /// Asset has a specific vegetation state.
    Vegetation(VegetationState),
    /// Settlement has a specific occupancy state.
    Occupancy(SettlementOccupancyState),
    /// Settlement has a specific reconstruction state.
    Reconstruction(SettlementReconstructionState),
    /// Asset is associated with a specific faction.
    FactionPresence(String),
    /// Manually specified condition.
    Manual(String),
}

/// A material variant entry in the catalogue, with optional overrides.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MaterialVariantEntry {
    /// The variant type (e.g., Burned, Dead, Weathered).
    pub variant: MaterialVariant,
    /// The key used to look up the material in the catalogue.
    #[serde(
        deserialize_with = "deserialize_arc_str",
        serialize_with = "serialize_arc_str"
    )]
    pub material_key: Arc<str>,
    /// Optional override mesh path for this variant.
    #[serde(
        default,
        deserialize_with = "deserialize_option_arc_pathbuf",
        serialize_with = "serialize_option_arc_pathbuf"
    )]
    pub mesh_path: Option<Arc<PathBuf>>,
    /// The condition under which this variant should be used.
    pub condition: MaterialCondition,
    /// Material property overrides for this variant.
    #[serde(default, flatten)]
    pub overrides: MaterialOverride,
}

/// The variant of a material, used for state-based material selection.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum MaterialVariant {
    /// Asset has been burned.
    Burned,
    /// Asset is dead/decomposed.
    Dead,
    /// Asset is bare (no vegetation).
    Bare,
    /// Asset is in a state of regrowth.
    Regrowth,
    /// Asset has been charred by fire.
    Charred,
    /// Asset has been flooded.
    Flooded,
    /// Asset is weathered by time.
    Weathered,
    /// Asset has been shattered.
    Shattered,
    /// Asset is parched/dry.
    Parched,
    /// Asset is volcanic in nature.
    Volcanic,
}

impl MaterialVariantEntry {
    /// Validates the variant entry, returning a vector of validation errors.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.material_key.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E042",
                "MaterialVariantEntry",
                "material_key",
                self.material_key.to_string(),
                "material_key must not be empty"
            );
        }
        errors
    }
}

impl std::fmt::Display for MaterialCondition {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            MaterialCondition::Damage(dt) => write!(f, "damage({})", dt),
            MaterialCondition::Vegetation(vs) => write!(f, "vegetation({})", vs),
            MaterialCondition::Occupancy(os) => write!(f, "occupancy({})", os),
            MaterialCondition::Reconstruction(rs) => write!(f, "reconstruction({})", rs),
            MaterialCondition::FactionPresence(tag) => write!(f, "faction_presence({})", tag),
            MaterialCondition::Manual(s) => write!(f, "manual({})", s),
        }
    }
}

impl MaterialCondition {
    /// Returns `true` if this condition matches the supplied context,
    /// using the provided resolver for `Manual` conditions.
    pub fn matches_context(
        &self,
        context: &MaterialConditionContext,
        resolve_material_key: &impl Fn(&str, Option<&DamageType>, &VegetationState) -> String,
    ) -> bool {
        match self {
            MaterialCondition::Damage(dt) => context.damage_type.as_ref() == Some(dt),
            MaterialCondition::Vegetation(vs) => &context.vegetation_state == vs,
            MaterialCondition::Occupancy(os) => context.occupancy_state == Some(*os),
            MaterialCondition::Reconstruction(rs) => context.reconstruction_state == Some(*rs),
            MaterialCondition::FactionPresence(tag) => {
                context.faction_tags.iter().any(|c| c == tag)
            }
            MaterialCondition::Manual(key) => {
                if context.faction_tags.is_empty() {
                    return resolve_material_key(
                        key,
                        context.damage_type.as_ref(),
                        &context.vegetation_state,
                    )
                    .starts_with(key);
                }
                resolve_material_key(key, context.damage_type.as_ref(), &context.vegetation_state)
                    .starts_with(key)
            }
        }
    }
}

impl From<(VegetationState, Option<DamageType>)> for MaterialVariant {
    fn from((state, damage): (VegetationState, Option<DamageType>)) -> Self {
        match state {
            VegetationState::Burned => MaterialVariant::Burned,
            VegetationState::Dead => MaterialVariant::Dead,
            VegetationState::Bare => MaterialVariant::Bare,
            VegetationState::Regrowth => MaterialVariant::Regrowth,
            VegetationState::Mature => match damage {
                Some(DamageType::Fire) => MaterialVariant::Charred,
                Some(DamageType::Flood) => MaterialVariant::Flooded,
                Some(DamageType::Erosion) => MaterialVariant::Weathered,
                Some(DamageType::Earthquake) => MaterialVariant::Shattered,
                Some(DamageType::Drought) => MaterialVariant::Parched,
                Some(DamageType::Volcanic) => MaterialVariant::Volcanic,
                None => MaterialVariant::Weathered,
                Some(_) => MaterialVariant::Weathered,
            },
            _ => MaterialVariant::Weathered,
        }
    }
}

impl MaterialVariant {
    /// Parse a material variant from its snake_case suffix (e.g. `"charred"`).
    pub fn from_suffix(suffix: &str) -> Option<Self> {
        match suffix.trim() {
            "burned" => Some(MaterialVariant::Burned),
            "dead" => Some(MaterialVariant::Dead),
            "bare" => Some(MaterialVariant::Bare),
            "regrowth" => Some(MaterialVariant::Regrowth),
            "charred" => Some(MaterialVariant::Charred),
            "flooded" => Some(MaterialVariant::Flooded),
            "weathered" => Some(MaterialVariant::Weathered),
            "shattered" => Some(MaterialVariant::Shattered),
            "parched" => Some(MaterialVariant::Parched),
            "volcanic" => Some(MaterialVariant::Volcanic),
            _ => None,
        }
    }
}

impl MaterialVariantContext {
    /// Determine the material variant for this context.
    pub fn resolve_variant(&self) -> Option<MaterialVariant> {
        match self.vegetation_state {
            VegetationState::Burned => Some(MaterialVariant::Burned),
            VegetationState::Dead => Some(MaterialVariant::Dead),
            VegetationState::Bare => Some(MaterialVariant::Bare),
            VegetationState::Regrowth => Some(MaterialVariant::Regrowth),
            VegetationState::Mature => match self.damage_type.as_ref() {
                Some(DamageType::Fire) => Some(MaterialVariant::Charred),
                Some(DamageType::Flood) => Some(MaterialVariant::Flooded),
                Some(DamageType::Erosion) => Some(MaterialVariant::Weathered),
                Some(DamageType::Earthquake) => Some(MaterialVariant::Shattered),
                Some(DamageType::Drought) => Some(MaterialVariant::Parched),
                Some(DamageType::Volcanic) => Some(MaterialVariant::Volcanic),
                None => None,
                Some(_) => None,
            },
            _ => None,
        }
    }

    /// Build a material key string.
    /// If `base` is `Some`, it is used as the key prefix; otherwise
    /// `"generic_landmark"` is used.
    pub fn material_key(&self, base: Option<&str>) -> String {
        let base = base.unwrap_or("generic_landmark");
        if let Some(variant) = self.resolve_variant() {
            format!("{}_{}", base, variant)
        } else {
            base.to_string()
        }
    }
}

impl std::fmt::Display for MaterialVariant {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            MaterialVariant::Burned => "burned",
            MaterialVariant::Dead => "dead",
            MaterialVariant::Bare => "bare",
            MaterialVariant::Regrowth => "regrowth",
            MaterialVariant::Charred => "charred",
            MaterialVariant::Flooded => "flooded",
            MaterialVariant::Weathered => "weathered",
            MaterialVariant::Shattered => "shattered",
            MaterialVariant::Parched => "parched",
            MaterialVariant::Volcanic => "volcanic",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing a material variant from a string fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseMaterialVariantError;

impl std::fmt::Display for ParseMaterialVariantError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid material variant suffix")
    }
}

impl std::str::FromStr for MaterialVariant {
    type Err = ParseMaterialVariantError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        MaterialVariant::from_suffix(s).ok_or(ParseMaterialVariantError)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_core::{DamageType, VegetationState};

    #[test]
    fn variant_from_vegetation_state() {
        assert_eq!(
            MaterialVariant::from((VegetationState::Burned, None)),
            MaterialVariant::Burned
        );
        assert_eq!(
            MaterialVariant::from((VegetationState::Dead, None)),
            MaterialVariant::Dead
        );
    }

    #[test]
    fn variant_from_state_and_damage() {
        let mature_fire: MaterialVariant = (VegetationState::Mature, Some(DamageType::Fire)).into();
        assert_eq!(mature_fire, MaterialVariant::Charred);

        let mature_none: MaterialVariant = (VegetationState::Mature, None).into();
        assert_eq!(mature_none, MaterialVariant::Weathered);
    }

    #[test]
    fn resolve_variant_from_context() {
        let ctx = MaterialVariantContext {
            material_key: "test".into(),
            damage_type: Some(DamageType::Flood),
            vegetation_state: VegetationState::Mature,
        };
        assert_eq!(ctx.resolve_variant(), Some(MaterialVariant::Flooded));

        let ctx = MaterialVariantContext {
            material_key: "test".into(),
            damage_type: None,
            vegetation_state: VegetationState::Regrowth,
        };
        assert_eq!(ctx.resolve_variant(), Some(MaterialVariant::Regrowth));
    }

    #[test]
    fn material_key_method() {
        let ctx = MaterialVariantContext {
            material_key: "highlands_landmark".into(),
            damage_type: Some(DamageType::Earthquake),
            vegetation_state: VegetationState::Mature,
        };
        assert_eq!(
            ctx.material_key(Some("highlands_landmark")),
            "highlands_landmark_shattered"
        );

        let ctx_no_damage = MaterialVariantContext {
            material_key: "".into(),
            damage_type: None,
            vegetation_state: VegetationState::Mature,
        };
        assert_eq!(ctx_no_damage.material_key(None), "generic_landmark");
    }

    #[test]
    fn from_suffix_works() {
        assert_eq!(
            MaterialVariant::from_suffix("charred"),
            Some(MaterialVariant::Charred)
        );
        assert_eq!(MaterialVariant::from_suffix("bogus"), None);
    }

    #[test]
    fn material_variant_from_str() {
        assert_eq!("charred".parse::<MaterialVariant>().ok(), Some(MaterialVariant::Charred));
        assert!("bogus".parse::<MaterialVariant>().is_err());
    }
}
