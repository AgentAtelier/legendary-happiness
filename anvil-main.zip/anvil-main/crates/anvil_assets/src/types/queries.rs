//! Query and resolution types.

use anvil_core::{
    ArchetypeTag, DamageType, SettlementOccupancyState, SettlementReconstructionState, VegetationState,
};
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;


use super::materials::{MaterialOverride, MaterialVariant};
use super::serde::{
    deserialize_arc_pathbuf, deserialize_arc_string_slice, deserialize_option_arc_str,
    serialize_arc_pathbuf, serialize_arc_string_slice, serialize_option_arc_str,
};

/// Enum indicating the origin of a material
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum MaterialOrigin {
    /// Material was explicitly specified in the catalogue
    Explicit,
    /// Material was derived from a fallback
    #[default]
    Fallback,
}

/// The result of resolving an [`super::AssetEntry`] via `AssetCatalogue::resolve_query`.
///
/// Contains the mesh path, optional material key, resolved material variant,
/// material overrides, and the origin of the material data.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResolvedAsset {
    /// Path to the mesh file.
    #[serde(
        deserialize_with = "deserialize_arc_pathbuf",
        serialize_with = "serialize_arc_pathbuf"
    )]
    pub mesh_path: Arc<PathBuf>,
    /// Optional key for the material in the catalogue.
    #[serde(
        default,
        deserialize_with = "deserialize_option_arc_str",
        serialize_with = "serialize_option_arc_str"
    )]
    pub material_key: Option<Arc<str>>,
    /// The resolved material variant, if any.
    pub variant: Option<MaterialVariant>,
    /// The resolved material override, if any.
    pub material: Option<MaterialOverride>,
    /// Whether the material came from an explicit source or a fallback.
    #[serde(default)]
    pub material_origin: MaterialOrigin,
}

/// A fully-specified asset query to the catalogue.
///
/// Use the builder methods (`with_damage`, `with_vegetation`, etc.) to construct queries.
///
/// # Examples
///
/// ```rust,no_run
/// use anvil_assets::prelude::*;
///
/// let query = CatalogueQuery::new(ArchetypeTag::new("highlands_ruin").expect("valid tag"))
///     .with_damage(DamageType::Fire)
///     .with_vegetation(VegetationState::Burned);
/// ```
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CatalogueQuery {
    /// The archetype tag to query for.
    pub tag: ArchetypeTag,
    /// The damage type to match (optional).
    pub damage_type: Option<DamageType>,
    /// The vegetation state to match. Defaults to Mature.
    pub vegetation_state: VegetationState,
    /// The settlement occupancy state to match (optional).
    pub occupancy_state: Option<SettlementOccupancyState>,
    /// The settlement reconstruction state to match (optional).
    pub reconstruction_state: Option<SettlementReconstructionState>,
    /// The faction tags to match.
    #[serde(
        default,
        deserialize_with = "deserialize_arc_string_slice",
        serialize_with = "serialize_arc_string_slice"
    )]
    pub faction_tags: Arc<[String]>,
}

impl CatalogueQuery {
    /// Creates a new query for the given archetype tag with default values.
    pub fn new(tag: ArchetypeTag) -> Self {
        Self {
            tag,
            damage_type: None,
            vegetation_state: VegetationState::Mature,
            occupancy_state: None,
            reconstruction_state: None,
            faction_tags: Arc::from(Vec::<String>::new()),
        }
    }

    /// Sets the damage type filter. Only assets matching this damage type will be returned.
    /// Default is `None` (no damage filtering).
    pub fn with_damage(mut self, damage_type: DamageType) -> Self {
        self.damage_type = Some(damage_type);
        self
    }

    /// Sets the vegetation state filter. Only assets matching this vegetation state will be returned.
    /// Default is `VegetationState::Mature`.
    pub fn with_vegetation(mut self, vegetation_state: VegetationState) -> Self {
        self.vegetation_state = vegetation_state;
        self
    }

    /// Sets the settlement occupancy state filter.
    /// Default is `None` (no occupancy filtering).
    pub fn with_occupancy(mut self, occupancy_state: SettlementOccupancyState) -> Self {
        self.occupancy_state = Some(occupancy_state);
        self
    }

    /// Sets the settlement reconstruction state filter.
    /// Default is `None` (no reconstruction filtering).
    pub fn with_reconstruction(
        mut self,
        reconstruction_state: SettlementReconstructionState,
    ) -> Self {
        self.reconstruction_state = Some(reconstruction_state);
        self
    }

    /// Sets the faction tags filter. Only assets matching these faction tags will be returned.
    /// Default is an empty list (no faction filtering).
    pub fn with_faction_tags(mut self, tags: Vec<String>) -> Self {
        self.faction_tags = Arc::from(tags.into_boxed_slice());
        self
    }
}

/// Explains why a catalogue query returned no result.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QueryDiagnostic {
    /// The queried archetype tag was not found in the catalogue.
    UnknownTag(ArchetypeTag),
    /// No material variant matched the query conditions.
    NoVariantMatch {
        /// The archetype tag that was queried.
        tag: ArchetypeTag,
        /// The variant names that were tried.
        tried: Vec<String>,
    },
}

impl std::fmt::Display for QueryDiagnostic {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::UnknownTag(tag) => write!(f, "unknown archetype tag: {}", tag.as_str()),
            Self::NoVariantMatch { tag, tried } => {
                write!(
                    f,
                    "no material variant matched for tag '{}'. Tried: {}",
                    tag.as_str(),
                    if tried.is_empty() {
                        "no variant conditions evaluated".into()
                    } else {
                        tried.join(", ")
                    }
                )
            }
        }
    }
}

impl std::fmt::Display for MaterialOrigin {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let s = match self {
            MaterialOrigin::Explicit => "explicit",
            MaterialOrigin::Fallback => "fallback",
        };
        write!(f, "{}", s)
    }
}
