//! Core data types: [`AssetEntry`], [`AssetCatalogue`], [`MaterialVariant`],
//! [`ResolvedAsset`], [`CatalogueQuery`], and supporting enums.

mod biome;
mod entries;
mod materials;
mod queries;
mod serde;

pub use biome::BiomeTag;
pub use entries::{
    AssetCategory, AssetEntry, AssetKind, AssetMetadata,
};
pub use materials::{
    MaterialCondition, MaterialConditionContext, MaterialOverride, MaterialVariant,
    MaterialVariantContext, MaterialVariantEntry, ParseMaterialVariantError,
    ResolutionContext,
};
pub use queries::{
    CatalogueQuery, MaterialOrigin, QueryDiagnostic, ResolvedAsset,
};
pub use serde::{
    default_footprint,
    // Serde helpers for Arc types
    deserialize_arc_pathbuf,
    deserialize_arc_str,
    deserialize_arc_str_vec,
    deserialize_arc_string_slice,
    deserialize_option_arc_pathbuf,
    deserialize_option_arc_str,
    serialize_arc_pathbuf,
    serialize_arc_str,
    serialize_arc_str_vec,
    serialize_arc_string_slice,
    serialize_option_arc_pathbuf,
    serialize_option_arc_str,
};
