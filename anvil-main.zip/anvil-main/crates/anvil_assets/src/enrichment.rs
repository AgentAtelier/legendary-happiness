//! Prompt enrichment: [`StyleProvider`], [`PromptTemplate`],
//! and [`AssetRequestEnricher`].

use anvil_core::{
    AnvilCoreError, AssetRequestFamily, AssetRequestSpec, ErrorCode, FailureClass, SemanticArtifact,
    TerrainType, ValidationErrors,
};
#[allow(unused_imports)]
use anvil_core::arche;
use serde::{Deserialize, Serialize};
use std::borrow::Cow;
use thiserror::Error;

/// An asset request that has been enriched with style suffixes.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EnrichedAssetRequest {
    /// The original asset request specification.
    pub spec: AssetRequestSpec,
    /// The style suffix added to the prompt.
    pub style_suffix: String,
    /// The final composed prompt string.
    pub composed_prompt: String,
}

// ---------------------------------------------------------------------------
// Error
// ---------------------------------------------------------------------------

/// Errors that can occur during asset request enrichment.
#[derive(Debug, Error)]
pub enum AssetRequestContractError {
    /// The asset request spec is invalid.
    #[error("asset request validation failed: {0}")]
    InvalidSpec(String),
}

// ---------------------------------------------------------------------------
// Style template data
// ---------------------------------------------------------------------------

/// One entry in the style‑suffix registry.
#[derive(Debug, Clone)]
struct StyleTemplate {
    family: AssetRequestFamily,
    biome: Option<TerrainType>,
    suffix: &'static str,
}

/// The complete style suffix lookup table.
static STYLE_TEMPLATES: &[StyleTemplate] = &[
    StyleTemplate {
        family: AssetRequestFamily::HeroLandmark,
        biome: Some(TerrainType::Desert),
        suffix: "stylized fantasy RPG hero landmark, weathered sandstone silhouette, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::HeroLandmark,
        biome: Some(TerrainType::Marsh),
        suffix: "stylized fantasy RPG hero landmark, damp weathered stone and moss accents, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::HeroLandmark,
        biome: None,
        suffix: "stylized fantasy RPG hero landmark, weathered medieval stone silhouette, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::ArchitectureKit,
        biome: None,
        suffix: "stylized fantasy RPG modular architecture kit piece, clean snap-friendly silhouette, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::Vegetation,
        biome: None,
        suffix: "stylized fantasy RPG vegetation asset, readable clustered foliage masses, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::Prop,
        biome: None,
        suffix: "stylized fantasy RPG prop asset, clear handheld scale cues, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::TerrainDetail,
        biome: None,
        suffix: "stylized fantasy RPG terrain detail asset, strong ground-contact silhouette, game-ready single object, no background",
    },
    StyleTemplate {
        family: AssetRequestFamily::Decal,
        biome: None,
        suffix: "stylized fantasy RPG decal source asset, high-contrast readable patterning, game-ready single object, no background",
    },
];

/// Find the appropriate style suffix for a given family and optional biome.
fn resolve_style_suffix(family: AssetRequestFamily, biome: Option<TerrainType>) -> &'static str {
    STYLE_TEMPLATES
        .iter()
        .find(|t| t.family == family && t.biome == biome)
        .map(|t| t.suffix)
        .or_else(|| {
            // Fallback: try the generic entry for this family (biome = None)
            STYLE_TEMPLATES
                .iter()
                .find(|t| t.family == family && t.biome.is_none())
                .map(|t| t.suffix)
        })
        .unwrap_or("stylized fantasy RPG asset, game-ready single object")
}

// ---------------------------------------------------------------------------
// Style provider trait
// ---------------------------------------------------------------------------

/// A source of style suffix strings.
///
/// Use this extension point to customise LLM prompt style suffixes.
///
/// # Examples
///
/// ```rust,no_run
/// use anvil_assets::prelude::*;
/// use anvil_core::{AssetRequestFamily, TerrainType};
/// use std::borrow::Cow;
///
/// struct MyStyleProvider;
///
/// impl StyleProvider for MyStyleProvider {
///     fn style_suffix(
///         &self,
///         family: AssetRequestFamily,
///         biome: Option<TerrainType>,
///     ) -> Cow<'static, str> {
///         Cow::Borrowed(" in a stylized fantasy art style")
///     }
/// }
/// ```
pub trait StyleProvider: Send + Sync {
    /// Return the style suffix to append for a given request context.
    fn style_suffix(
        &self,
        family: AssetRequestFamily,
        biome: Option<TerrainType>,
    ) -> Cow<'static, str>;
}

// ---------------------------------------------------------------------------
// Default provider
// ---------------------------------------------------------------------------

/// The built‑in provider backed by the static `STYLE_TEMPLATES` table.
#[derive(Debug, Clone, Default)]
pub struct DefaultStyleProvider;

impl StyleProvider for DefaultStyleProvider {
    fn style_suffix(
        &self,
        family: AssetRequestFamily,
        biome: Option<TerrainType>,
    ) -> Cow<'static, str> {
        Cow::Borrowed(resolve_style_suffix(family, biome))
    }
}

// ---------------------------------------------------------------------------
// Prompt template
// ---------------------------------------------------------------------------

/// A structured prompt ready for composition and validation.
///
/// Use `compose()` to generate the final prompt string, and `validate()`
/// to check prompt content validity.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PromptTemplate {
    /// The core prompt text.
    pub core: String,
    /// The style suffix to append to the core prompt.
    pub style_suffix: String,
    /// The asset family this template is for.
    pub family: AssetRequestFamily,
    /// The optional biome this template is specific to.
    pub biome: Option<TerrainType>,
}

impl PromptTemplate {
    /// Compose the final prompt string by concatenating core and style suffix.
    pub fn compose(&self) -> String {
        if self.core.ends_with(',') {
            format!("{} {}", self.core, self.style_suffix)
        } else {
            format!("{}, {}", self.core, self.style_suffix)
        }
    }

    /// Validate the prompt content (extends `AssetRequestSpec::validate`).
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = Vec::new();
        if self.core.trim().is_empty() {
            errors.push(AnvilCoreError::validation(
                FailureClass::Semantic,
                ErrorCode::new("E0001"),
                "AssetRequestContract",
                "core",
                self.core.clone(),
                "core prompt must not be empty",
            ));
        }
        if self.core.len() > 600 {
            errors.push(AnvilCoreError::validation(
                FailureClass::Semantic,
                ErrorCode::new("E0002"),
                "AssetRequestContract",
                "core",
                self.core.clone(),
                format!("core prompt exceeds 600 characters ({} chars)", self.core.len()),
            ));
        }
        // Optional: forbidden‑word check (empty list for now)
        let forbidden: &[&str] = &[];
        for word in forbidden {
            if self.core.contains(word) {
                errors.push(AnvilCoreError::validation(
                    FailureClass::Semantic,
                    ErrorCode::new("E0003"),
                    "AssetRequestContract",
                    "core",
                    self.core.clone(),
                    format!("core prompt contains forbidden word '{}'", word),
                ));
            }
        }
        errors
    }

    /// Create a synthetic example prompt for a given family (useful in tests).
    pub fn example(family: AssetRequestFamily) -> Self {
        let core = match family {
            AssetRequestFamily::HeroLandmark => "Broken watchtower with collapsed upper ring",
            AssetRequestFamily::ArchitectureKit => "Modular stone wall section with arrow slits",
            AssetRequestFamily::Vegetation => "Cluster of wind-swept pine saplings",
            AssetRequestFamily::Prop => "Rusty iron lantern with cracked glass",
            AssetRequestFamily::TerrainDetail => "Scattered pebbles and fallen leaves",
            AssetRequestFamily::Decal => "Faded mural of a forgotten deity on plaster",
            _ => "stylized fantasy RPG asset, game-ready single object",
        };
        let provider = DefaultStyleProvider;
        let suffix = provider.style_suffix(family, None).to_string();
        PromptTemplate {
            core: core.to_string(),
            style_suffix: suffix,
            family,
            biome: None,
        }
    }
}

impl std::fmt::Display for PromptTemplate {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.compose())
    }
}

// ---------------------------------------------------------------------------
// Enricher
// ---------------------------------------------------------------------------

/// Owns a [`StyleProvider`] and enriches request specs.
///
/// Use [`StyleProvider`] as the plug-in for custom style suffixes.
pub struct AssetRequestEnricher {
    style_provider: Box<dyn StyleProvider>,
}

impl Default for AssetRequestEnricher {
    fn default() -> Self {
        Self {
            style_provider: Box::new(DefaultStyleProvider),
        }
    }
}

impl AssetRequestEnricher {
    /// Create an enricher with the default style provider.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create an enricher with a custom style provider.
    pub fn with_provider(provider: Box<dyn StyleProvider>) -> Self {
        Self {
            style_provider: provider,
        }
    }

    /// Validate and enrich a request spec.
    pub fn enrich(
        &self,
        spec: &AssetRequestSpec,
    ) -> Result<EnrichedAssetRequest, AssetRequestContractError> {
        let validation_errors = spec.validate();
        if !validation_errors.is_empty() {
            let messages: Vec<String> = validation_errors.iter().map(|e| e.to_string()).collect();
            return Err(AssetRequestContractError::InvalidSpec(messages.join("; ")));
        }

        let style_suffix = self
            .style_provider
            .style_suffix(spec.asset_family, spec.biome_context)
            .into_owned();

        let template = PromptTemplate {
            core: spec.prompt_core.trim().to_string(),
            style_suffix,
            family: spec.asset_family,
            biome: spec.biome_context,
        };

        let template_errors = template.validate();
        if !template_errors.is_empty() {
            let messages: Vec<String> = template_errors.iter().map(|e| e.to_string()).collect();
            return Err(AssetRequestContractError::InvalidSpec(messages.join("; ")));
        }

        Ok(EnrichedAssetRequest {
            spec: spec.clone(),
            style_suffix: template.style_suffix.clone(),
            composed_prompt: template.compose(),
        })
    }
}

// ---------------------------------------------------------------------------
// Convenience function (backward‑compatible public API)
// ---------------------------------------------------------------------------

/// The original `enrich_asset_request_spec` entry point.
///
/// Uses the default `AssetRequestEnricher`. For custom style providers,
/// construct an `AssetRequestEnricher` directly and call its `enrich` method.
pub fn enrich_asset_request_spec(
    spec: &AssetRequestSpec,
) -> Result<EnrichedAssetRequest, AssetRequestContractError> {
    AssetRequestEnricher::default().enrich(spec)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_core::{AssetRequestFamily, AssetRequestSpec, TerrainType};

    #[test]
    fn default_enricher_injects_suffix() {
        let spec = AssetRequestSpec {
            asset_family: AssetRequestFamily::HeroLandmark,
            archetype_tag: arche!("highlands_watchtower"),
            biome_context: Some(TerrainType::Highlands),
            style_context: "northern stone".into(),
            prompt_core: "A stone tower on a hill".into(),
            quality_hint: None,
            source_hint: None,
        };
        let enriched = enrich_asset_request_spec(&spec).expect("enrich should succeed");
        assert!(enriched
            .composed_prompt
            .starts_with("A stone tower on a hill"));
        assert!(enriched
            .composed_prompt
            .contains("game-ready single object"));
    }

    #[test]
    fn custom_provider_works() {
        struct CustomProvider;
        impl StyleProvider for CustomProvider {
            fn style_suffix(
                &self,
                _family: AssetRequestFamily,
                _biome: Option<TerrainType>,
            ) -> std::borrow::Cow<'static, str> {
                std::borrow::Cow::Borrowed("custom style")
            }
        }
        let enricher = AssetRequestEnricher::with_provider(Box::new(CustomProvider));
        let spec = AssetRequestSpec {
            asset_family: AssetRequestFamily::Prop,
            archetype_tag: arche!("market_crate"),
            biome_context: None,
            style_context: "medieval".into(),
            prompt_core: "A wooden crate".into(),
            quality_hint: None,
            source_hint: None,
        };
        let enriched = enricher.enrich(&spec).expect("enrich should succeed");
        assert_eq!(enriched.composed_prompt, "A wooden crate, custom style");
    }

    #[test]
    fn validation_rejects_empty_core() {
        let spec = AssetRequestSpec {
            asset_family: AssetRequestFamily::Prop,
            archetype_tag: arche!("market_crate"),
            biome_context: None,
            style_context: "   ".into(),
            prompt_core: "   ".into(),
            quality_hint: None,
            source_hint: None,
        };
        let err = enrich_asset_request_spec(&spec).expect_err("should fail");
        assert!(err.to_string().contains("cannot be empty"));
    }

    #[test]
    fn example_prompt_is_valid() {
        let template = PromptTemplate::example(AssetRequestFamily::HeroLandmark);
        assert!(!template.compose().is_empty());
        assert!(template.validate().is_empty());
    }
}
