#![deny(warnings)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]
//!
//! Anvil CLI - Command-line tool for the Anvil asset pipeline.
//!
//! Processes NatureManufacture Forest Environment assets and generates
//! normalized GLB files for use in the Bevy-based anvil_demo.

use anvil_cli::commands::{run_normalize, run_sidecar};
use clap::{Parser, Subcommand};

/// Anvil CLI - Command-line tool for the Anvil asset pipeline
#[derive(Parser)]
#[command(name = "anvil_cli")]
#[command(version = "0.1.0")]
#[command(
    about = "Processes NatureManufacture Forest Environment assets and generates normalized GLB files"
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Normalize assets: process pilot, eligibility, staging, and batch manifests to generate GLB files
    Normalize,
    /// Run material sidecar and texture payload stages for Emberwood
    Sidecar,
}

fn main() {
    // Initialize logging
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    let cli = Cli::parse();

    let result = match cli.command {
        Commands::Normalize => run_normalize(),
        Commands::Sidecar => run_sidecar(),
    };

    if let Err(e) = result {
        eprintln!("{:#}", e);
        std::process::exit(1);
    }
}
