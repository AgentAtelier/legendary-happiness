//! Anvil CLI library - Command-line tool for the Anvil asset pipeline.
//!
//! This library provides the command implementations for processing NatureManufacture
//! Forest Environment assets and generating normalized GLB files.

pub mod commands;

pub use commands::{run_normalize, run_sidecar};
