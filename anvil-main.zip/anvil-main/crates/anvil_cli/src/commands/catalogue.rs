//! Catalogue generation utilities for CLI commands.

use anvil_assets::{AssetCategory, AssetKind, MaterialVariant};
use anvil_assets_pipeline::ExternalAssetNormalizationExecutionRecord;
use anvil_core::{ArchetypeTag, DamageType, VegetationState, repo_path};
use serde::Serialize;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use std::sync::Arc;

/// A manifest entry compatible with catalogue JSON V1/V2
#[derive(Serialize)]
pub struct CatalogueManifestEntry {
    tag: ArchetypeTag,
    #[serde(rename = "mesh_path")]
    path: PathBuf,
    kind: AssetKind,
    #[serde(default)]
    tags: Vec<String>,
    #[serde(default)]
    footprint_radius: f32,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    material_variants: Vec<CatalogueMaterialVariantEntry>,
}

/// Material variant entry for catalogue serialization - matches anvil_assets::MaterialVariantEntry
#[derive(Serialize)]
pub struct CatalogueMaterialVariantEntry {
    variant: MaterialVariant,
    material_key: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    mesh_path: Option<PathBuf>,
    condition: CatalogueMaterialCondition,
    #[serde(default, flatten)]
    overrides: CatalogueMaterialOverride,
}

/// Simplified material condition for catalogue serialization
#[derive(Serialize)]
#[serde(rename_all = "snake_case")]
pub enum CatalogueMaterialCondition {
    #[serde(rename = "damage")]
    Damage(String),
    #[serde(rename = "vegetation")]
    Vegetation(String),
}

/// Simplified material override for catalogue serialization
#[derive(Serialize, Default)]
pub struct CatalogueMaterialOverride {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    albedo_texture: Option<PathBuf>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    normal_texture: Option<PathBuf>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    roughness_metallic_texture: Option<PathBuf>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    perceptual_roughness: Option<f32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    metallic: Option<f32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    base_color_tint: Option<[f32; 4]>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    emissive: Option<[f32; 3]>,
}

/// Catalogue manifest envelope for V1/V2 JSON
#[derive(Serialize)]
pub struct CatalogueManifest {
    version: u32,
    entries: Vec<CatalogueManifestEntry>,
}

/// Generate material variants for a given category
/// Maps any category to TerrainDetail for NatureManufacture assets
/// since the fallback provider only covers Landmark, ArchitectureKit, and TerrainDetail
pub fn generate_material_variants(
    tag: &ArchetypeTag,
    category: &AssetCategory,
    fallback_provider: &Arc<dyn anvil_assets::FallbackProvider>,
) -> Vec<CatalogueMaterialVariantEntry> {
    // Map category to one that is covered by the fallback provider
    let covered_category = match category {
        AssetCategory::Landmark | AssetCategory::ArchitectureKit | AssetCategory::TerrainDetail => {
            category.clone()
        }
        AssetCategory::Vegetation | AssetCategory::Prop | AssetCategory::Decal => {
            AssetCategory::TerrainDetail
        }
        _ => AssetCategory::TerrainDetail,
    };

    // Define all damage types to generate variants for
    let damage_types = [
        DamageType::Fire,
        DamageType::Flood,
        DamageType::Earthquake,
        DamageType::Erosion,
        DamageType::Drought,
    ];

    // Define all vegetation states to generate variants for
    let vegetation_states = [
        VegetationState::Burned,
        VegetationState::Regrowth,
        VegetationState::Dead,
    ];

    let mut variants = Vec::new();

    // Generate damage variants
    for dt in &damage_types {
        let variant = match dt {
            DamageType::Fire => MaterialVariant::Charred,
            DamageType::Flood => MaterialVariant::Flooded,
            DamageType::Earthquake => MaterialVariant::Shattered,
            DamageType::Erosion => MaterialVariant::Weathered,
            DamageType::Drought => MaterialVariant::Parched,
            _ => MaterialVariant::Weathered,
        };

        // Get fallback textures for this variant
        if let Some((albedo, normal)) =
            fallback_provider.textures(covered_category.clone(), variant)
        {
            let (roughness, metallic) =
                fallback_provider.pbr_scalars(variant).unwrap_or((0.5, 0.0));

            variants.push(CatalogueMaterialVariantEntry {
                variant,
                material_key: format!("material_{}_{:?}", tag.as_str(), dt),
                mesh_path: None,
                condition: CatalogueMaterialCondition::Damage(format!("{:?}", dt).to_lowercase()),
                overrides: CatalogueMaterialOverride {
                    albedo_texture: Some(albedo.to_path_buf()),
                    normal_texture: Some(normal.to_path_buf()),
                    roughness_metallic_texture: None,
                    perceptual_roughness: Some(roughness),
                    metallic: Some(metallic),
                    base_color_tint: None,
                    emissive: None,
                },
            });
        }
    }

    // Generate vegetation variants
    for vs in &vegetation_states {
        let variant = match vs {
            VegetationState::Burned => MaterialVariant::Burned,
            VegetationState::Regrowth => MaterialVariant::Regrowth,
            VegetationState::Dead => MaterialVariant::Dead,
            _ => MaterialVariant::Dead,
        };

        // Get fallback textures for this variant
        if let Some((albedo, normal)) =
            fallback_provider.textures(covered_category.clone(), variant)
        {
            let (roughness, metallic) =
                fallback_provider.pbr_scalars(variant).unwrap_or((0.5, 0.0));

            variants.push(CatalogueMaterialVariantEntry {
                variant,
                material_key: format!("material_{}_{:?}", tag.as_str(), vs),
                mesh_path: None,
                condition: CatalogueMaterialCondition::Vegetation(
                    format!("{:?}", vs).to_lowercase(),
                ),
                overrides: CatalogueMaterialOverride {
                    albedo_texture: Some(albedo.to_path_buf()),
                    normal_texture: Some(normal.to_path_buf()),
                    roughness_metallic_texture: None,
                    perceptual_roughness: Some(roughness),
                    metallic: Some(metallic),
                    base_color_tint: None,
                    emissive: None,
                },
            });
        }
    }

    // Add a default variant that matches all other cases
    // This ensures every query gets a material override
    // Use "mature" vegetation state as the default since it's the most common
    if let Some((albedo, normal)) =
        fallback_provider.textures(covered_category.clone(), MaterialVariant::Regrowth)
    {
        let (roughness, metallic) = fallback_provider
            .pbr_scalars(MaterialVariant::Regrowth)
            .unwrap_or((0.5, 0.0));
        variants.push(CatalogueMaterialVariantEntry {
            variant: MaterialVariant::Regrowth,
            material_key: format!("material_{}_default", tag.as_str()),
            mesh_path: None,
            condition: CatalogueMaterialCondition::Vegetation("mature".to_string()),
            overrides: CatalogueMaterialOverride {
                albedo_texture: Some(albedo.to_path_buf()),
                normal_texture: Some(normal.to_path_buf()),
                roughness_metallic_texture: None,
                perceptual_roughness: Some(roughness),
                metallic: Some(metallic),
                base_color_tint: None,
                emissive: None,
            },
        });
    }

    variants
}

/// Build a catalogue entry from an execution record.
pub fn build_catalogue_entry(
    record: &ExternalAssetNormalizationExecutionRecord,
    fallback_provider: &Arc<dyn anvil_assets::FallbackProvider>,
) -> CatalogueManifestEntry {
    // Convert relative path to a PathBuf
    let relative_path = record
        .target_output_path
        .strip_prefix("assets/")
        .unwrap_or(&record.target_output_path);

    // Use the category from the execution record directly
    // All NatureManufacture assets are terrain detail except maybe some
    let category = record.category.clone();

    // Generate material variants for this entry
    let material_variants =
        generate_material_variants(&record.normalized_id, &category, fallback_provider);

    CatalogueManifestEntry {
        tag: record.normalized_id.clone(),
        path: PathBuf::from(relative_path),
        kind: AssetKind::Mesh,
        tags: Vec::new(),
        footprint_radius: 1.0,
        material_variants,
    }
}

/// Write the catalogue to disk.
#[allow(clippy::expect_used)]
pub fn write_catalogue(entries: Vec<CatalogueManifestEntry>) {
    let catalogue = CatalogueManifest {
        version: 2,
        entries,
    };

    let catalogue_json =
        serde_json::to_string_pretty(&catalogue).expect("Failed to serialize catalogue");

    let catalogue_path = repo_path!("assets/catalogue.json");
    let mut file = File::create(catalogue_path).expect("Failed to create catalogue file");
    file.write_all(catalogue_json.as_bytes())
        .expect("Failed to write catalogue");
}
