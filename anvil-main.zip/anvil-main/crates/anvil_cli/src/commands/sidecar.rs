//! Sidecar subcommand handler.

use anyhow::{Context, Result};
use std::path::PathBuf;

use anvil_assets_pipeline::{
    DefaultBatchCompositionPolicy, ExternalAssetMaterialSidecarManifest,
    ExternalAssetNormalizationBatchManifest, ExternalAssetNormalizationEligibilityManifest,
    ExternalAssetNormalizationExecutionManifest, ExternalAssetNormalizationStageManifest,
    ExternalAssetPilotManifest, ExternalAssetTexturePayloadReport, PipelineManifest,
};
use anvil_core::repo_path;

/// Run the sidecar command, processing material sidecar and texture payloads.
pub fn run_sidecar() -> Result<()> {
    // Load the pilot manifest
    let pilot_path = repo_path!("assets/external/naturemanufacture_forest_environment_pilot.json");
    let pilot = ExternalAssetPilotManifest::load(&pilot_path)
        .with_context(|| format!("Failed to load pilot manifest from {}", pilot_path.display()))?;

    // Load the eligibility manifest
    let eligibility_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_eligibility.json");
    let eligibility = ExternalAssetNormalizationEligibilityManifest::load(&eligibility_path)
        .with_context(|| {
            format!("Failed to load eligibility manifest from {}", eligibility_path.display())
        })?;

    // Load the staging manifest
    let staging_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_staging.json");
    let staging = ExternalAssetNormalizationStageManifest::load(&staging_path)
        .with_context(|| format!("Failed to load staging manifest from {}", staging_path.display()))?;

    // Load the batch manifest
    let batch_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_normalization_batch.json");
    let batch = ExternalAssetNormalizationBatchManifest::load(&batch_path)
        .with_context(|| format!("Failed to load batch manifest from {}", batch_path.display()))?;

    // Resolve the execution manifest using DefaultBatchCompositionPolicy
    let output_root = repo_path!("assets/external_normalized/naturemanufacture/");
    let policy = DefaultBatchCompositionPolicy;

    let (execution_manifest, _errors) = batch.resolve_execution_manifest_lenient(
        &pilot,
        &staging,
        &eligibility,
        &output_root,
        &policy,
    );

    // Load the execution manifest as a standalone for passing to resolve_report
    let execution_manifest_standalone = ExternalAssetNormalizationExecutionManifest {
        source_pack: execution_manifest.source_pack.clone(),
        batch_name: execution_manifest.batch_name.clone(),
        output_root: execution_manifest.output_root.clone(),
        records: execution_manifest.records.clone(),
    };

    // Load the material sidecar manifest
    let sidecar_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_material_sidecar.json");
    let sidecar = ExternalAssetMaterialSidecarManifest::load(&sidecar_path)
        .map_err(|e| anyhow::anyhow!("Failed to load material sidecar manifest from {}: {:?}", sidecar_path.display(), e))?;

    // Resolve the sidecar report
    let execution_report_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_execution.json");
    let sidecar_report_path = repo_path!(
        "assets/external/naturemanufacture_forest_environment_material_sidecar_report.json"
    );
    let sidecar_report = sidecar
        .resolve_report(
            &pilot,
            &staging,
            &eligibility,
            &execution_manifest_standalone,
            &execution_report_path,
            &sidecar_report_path,
        )
        .map_err(|e| anyhow::anyhow!("Failed to resolve sidecar report: {:?}", e))?;

    // Resolve the texture payload report from authority
    let texture_report_path = repo_path!(
        "assets/external/naturemanufacture_forest_environment_texture_payload_report.json"
    );
    let texture_payload_report = ExternalAssetTexturePayloadReport::resolve_from_authority(
        &sidecar_report,
        &sidecar,
        &pilot,
        &staging,
        &eligibility,
        &execution_manifest_standalone,
        &texture_report_path,
    )
    .map_err(|e| anyhow::anyhow!("Failed to resolve texture payload report: {:?}", e))?;

    // Get source root from the sidecar manifest
    let source_root = PathBuf::from(&sidecar.source_pack.source_root);

    // Stage files using the texture payload report
    let stage_errors = texture_payload_report.stage_files(&source_root);

    if !stage_errors.is_empty() {
        anyhow::bail!(
            "Stage files had {} errors: {}",
            stage_errors.len(),
            stage_errors.iter().map(|e| format!("  - {:?}", e)).collect::<Vec<_>>().join("\n")
        );
    }

    // Print summary
    let record_count = sidecar.records().len();
    let staged_file_count = texture_payload_report.records.len();

    println!("Sidecar pipeline completed successfully");
    println!("  Records processed: {}", record_count);
    println!("  Texture files staged: {}", staged_file_count);
    Ok(())
}
