//! Normalize subcommand handler.

use anyhow::Result;
use std::sync::Arc;

use crate::commands::catalogue::{build_catalogue_entry, write_catalogue};
use anvil_assets::DefaultFallbackProvider;
use anvil_assets_pipeline::{
    DefaultBatchCompositionPolicy, ExternalAssetNormalizationBatchManifest,
    ExternalAssetNormalizationEligibilityManifest, ExternalAssetNormalizationExecutionRecord,
    ExternalAssetPilotManifest, ExternalAssetNormalizationStageManifest, NormalizedGlb, PipelineManifest,
};
use anvil_core::repo_path;
use std::fs;

/// Run the normalize command, processing assets and generating GLB files.
pub fn run_normalize() -> Result<()> {
    // Load the pilot manifest
    let pilot_path = repo_path!("assets/external/naturemanufacture_forest_environment_pilot.json");
    let pilot = ExternalAssetPilotManifest::load(&pilot_path)
        .map_err(|e| anyhow::anyhow!("Failed to load pilot manifest from {}: {:?}", pilot_path.display(), e))?;

    // Load the eligibility manifest
    let eligibility_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_eligibility.json");
    let eligibility = ExternalAssetNormalizationEligibilityManifest::load(&eligibility_path)
        .map_err(|e| anyhow::anyhow!("Failed to load eligibility manifest from {}: {:?}", eligibility_path.display(), e))?;

    // Validate eligibility against pilot
    if eligibility.source_pack != pilot.source_pack {
        anyhow::bail!("Eligibility source_pack does not match pilot");
    }
    let pilot_ids: Vec<_> = pilot.records().iter().map(|r| &r.registration.normalized_id).collect();
    for elig_record in eligibility.records() {
        if !pilot_ids.contains(&&elig_record.normalized_id) {
            anyhow::bail!(
                "Eligibility record {} not found in pilot manifest",
                elig_record.normalized_id
            );
        }
    }

    // Load the staging manifest
    let staging_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_staging.json");
    let staging = ExternalAssetNormalizationStageManifest::load(&staging_path)
        .map_err(|e| anyhow::anyhow!("Failed to load staging manifest from {}: {:?}", staging_path.display(), e))?;

    // Validate staging against pilot + eligibility
    if staging.source_pack != pilot.source_pack {
        anyhow::bail!("Staging source_pack does not match pilot");
    }
    let eligibility_ids: Vec<_> = eligibility.records().iter().map(|r| &r.normalized_id).collect();
    for stage_record in staging.records() {
        if !pilot_ids.contains(&&stage_record.normalized_id) {
            anyhow::bail!(
                "Staging record {} not found in pilot manifest",
                stage_record.normalized_id
            );
        }
        if !eligibility_ids.contains(&&stage_record.normalized_id) {
            anyhow::bail!(
                "Staging record {} not found in eligibility manifest",
                stage_record.normalized_id
            );
        }
    }

    // Load the batch manifest
    let batch_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_normalization_batch.json");
    let batch = ExternalAssetNormalizationBatchManifest::load(&batch_path)
        .map_err(|e| anyhow::anyhow!("Failed to load batch manifest from {}: {:?}", batch_path.display(), e))?;

    // Resolve the execution manifest
    let output_root = repo_path!("assets/external_normalized/naturemanufacture/");
    let policy = DefaultBatchCompositionPolicy;

    let (execution_manifest, errors) = batch.resolve_execution_manifest_lenient(
        &pilot,
        &staging,
        &eligibility,
        &output_root,
        &policy,
    );

    if !errors.is_empty() {
        anyhow::bail!(
            "Execution manifest resolution had {} errors: {}",
            errors.len(),
            errors.iter().map(|e| format!("  - {}", e)).collect::<Vec<_>>().join("\n")
        );
    }

    // Process each execution record and build catalogue entries
    let mut processed_count = 0usize;
    let mut catalogue_entries = Vec::new();

    // Use default fallback provider for generating material variants
    let fallback_provider: Arc<dyn anvil_assets::FallbackProvider> =
        Arc::new(DefaultFallbackProvider);

    for record in execution_manifest.records() {
        process_record(record)
            .map_err(|e| anyhow::anyhow!("Failed to process {}: {}", record.normalized_id, e))?;
        processed_count += 1;
        // Build catalogue entry for this asset with material variants
        let entry = build_catalogue_entry(record, &fallback_provider);
        catalogue_entries.push(entry);
    }

    // Write catalogue
    write_catalogue(catalogue_entries);

    // Try to load material sidecar if it exists
    let sidecar_path =
        repo_path!("assets/external/naturemanufacture_forest_environment_material_sidecar.json");
    if sidecar_path.exists() {
        println!("Material sidecar manifest found: {}", sidecar_path.display());
    } else {
        println!("Material sidecar manifest not found, using fallback textures");
    }

    println!("Processed {} assets to {}", processed_count, output_root.display());
    Ok(())
}

fn process_record(record: &ExternalAssetNormalizationExecutionRecord) -> Result<(), String> {
    // Build normalized GLB from execution record
    let normalized_glb = NormalizedGlb::from_execution_record(record)
        .map_err(|e| format!("Failed to build normalized GLB: {}", e))?;

    // Determine output path - the actual_output_path is already computed by resolve_execution_manifest
    let output_path = &record.actual_output_path;

    // Create parent directories
    if let Some(parent) = output_path.parent() && !parent.exists() {
        fs::create_dir_all(parent)
            .map_err(|e| format!("Failed to create directory {}: {}", parent.display(), e))?;
    }

    // Write GLB bytes
    fs::write(output_path, &normalized_glb.bytes)
        .map_err(|e| format!("Failed to write GLB file {}: {}", output_path.display(), e))?;

    Ok(())
}
