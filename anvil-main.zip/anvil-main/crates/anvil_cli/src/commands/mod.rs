//! Subcommand handlers for the Anvil CLI.

pub mod catalogue;
pub mod normalize;
pub mod sidecar;

pub use normalize::run_normalize;
pub use sidecar::run_sidecar;
