//! Integration tests for anvil_cli commands.
//! 
//! These tests verify that run_normalize and run_sidecar return Result types.

use anvil_cli::commands;

#[test]
fn test_run_normalize_returns_result_type() {
    // Verify at compile time that run_normalize returns Result<(), anyhow::Error>
    // The fact that this compiles proves the return type is correct
    let _: Result<(), anyhow::Error> = commands::run_normalize();
}

#[test]
fn test_run_sidecar_returns_result_type() {
    // Verify at compile time that run_sidecar returns Result<(), anyhow::Error>
    let _: Result<(), anyhow::Error> = commands::run_sidecar();
}

#[test]
fn test_commands_module_exports() {
    // Verify the commands module exports the expected functions
    // If this compiles, the module exports are correct
    let _ = commands::run_normalize;
    let _ = commands::run_sidecar;
}
