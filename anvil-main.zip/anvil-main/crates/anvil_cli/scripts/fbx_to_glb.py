#!/usr/bin/env python3
"""
FBX to GLB conversion script for Anvil pipeline.

For actual FBX to GLB conversion, you have several options:

1. Blender (recommended):
   blender --background --python convert_fbx_to_glb.py -- <input.fbx> <output.glb>
   
2. Using pygltflib with FBX SDK (complex setup)

This script provides a simple wrapper that:
- Checks if input is already GLB and copies it
- Provides a framework for integration with actual conversion tools

Requires:
    pip install pygltflib  # For GLTF/GLB manipulation

Usage:
    python3 fbx_to_glb.py <input.fbx> <output.glb>
"""

import sys
import os
import shutil
from pathlib import Path

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 fbx_to_glb.py <input.fbx> <output.glb>", file=sys.stderr)
        sys.exit(1)
    
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    
    # Create output directory if needed
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Check if input exists
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)
    
    input_ext = input_path.suffix.lower()
    
    # If already GLB, just copy
    if input_ext == '.glb':
        print(f"Input is already GLB: {input_path}")
        shutil.copy2(str(input_path), str(output_path))
        print(f"Copied to: {output_path}")
        sys.exit(0)
    
    # If GLTF, convert to GLB
    if input_ext == '.gltf':
        convert_gltf_to_glb(input_path, output_path)
        sys.exit(0)
    
    # For FBX and other formats, try different conversion methods
    if input_ext in ['.fbx', '.fbx']:
        output_path_temp = output_path.with_suffix('.glb.tmp')
        
        # Try method 1: Blender
        if convert_with_blender(input_path, output_path_temp):
            output_path_temp.rename(output_path)
            print(f"Converted with Blender: {output_path}")
            sys.exit(0)
        
        # Try method 2: Direct copy as fallback (for testing)
        print(f"WARNING: No FBX converter found. Copying FBX as placeholder.", file=sys.stderr)
        shutil.copy2(str(input_path), str(output_path))
        print(f"Copied FBX to output (actual conversion needed): {output_path}")
        sys.exit(0)
    
    # Unknown format
    print(f"ERROR: Unsupported input format: {input_ext}", file=sys.stderr)
    sys.exit(1)

def convert_gltf_to_glb(input_path: Path, output_path: Path):
    """Convert GLTF to GLB using pygltflib."""
    try:
        from pygltflib import GLTF2
        
        print(f"Converting GLTF to GLB: {input_path} -> {output_path}")
        
        gltf = GLTF2().load(str(input_path))
        gltf.save(output_path)
        print(f"  Saved GLB: {output_path}")
    except ImportError:
        print("ERROR: pygltflib not installed. Install with: pip install pygltflib", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"ERROR: Failed to convert GLTF to GLB: {e}", file=sys.stderr)
        sys.exit(1)

def convert_with_blender(input_path: Path, output_path: Path) -> bool:
    """Try to convert using Blender's command-line interface."""
    import subprocess
    
    # Check if blender is available
    try:
        subprocess.run(['blender', '--version'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False
    
    print(f"Converting FBX to GLB using Blender: {input_path} -> {output_path}")
    
    # Create a simple Python script for Blender to execute
    blend_script = f"""
import bpy
import sys

input_path = sys.argv[-2]
output_path = sys.argv[-1]

# Clear existing objects
bpy.ops.wm.read_factory_settings(use_empty=True)

# Import FBX
try:
    bpy.ops.import_scene.fbx(filepath=input_path)
    print(f"Imported FBX: {{input_path}}")
except Exception as e:
    print(f"ERROR: Failed to import FBX: {{e}}", file=sys.stderr)
    sys.exit(1)

# Export as GLB
try:
    bpy.ops.export_scene.gltf(
        filepath=str(output_path),
        export_format='GLB',
        export_materials='EXPORT',
        export_textures=True
    )
    print(f"Exported GLB: {{output_path}}")
except Exception as e:
    print(f"ERROR: Failed to export GLB: {{e}}", file=sys.stderr)
    sys.exit(1)
"""
    
    # Save blend script to temp file
    script_path = output_path.with_suffix('.blend.py')
    try:
        script_path.write_text(blend_script)
        
        # Run Blender
        result = subprocess.run([
            'blender',
            '--background',
            '--python', str(script_path),
            str(input_path),
            str(output_path)
        ], capture_output=True, text=True)
        
        # Clean up temp script
        script_path.unlink()
        
        if result.returncode == 0:
            print(f"  Blender conversion successful")
            return True
        else:
            print(f"  Blender conversion failed: {result.stderr}", file=sys.stderr)
            return False
    except Exception as e:
        print(f"ERROR: Blender conversion failed: {e}", file=sys.stderr)
        if script_path.exists():
            script_path.unlink()
        return False

if __name__ == "__main__":
    main()
