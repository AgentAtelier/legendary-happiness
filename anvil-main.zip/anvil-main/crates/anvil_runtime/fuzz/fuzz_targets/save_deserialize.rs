#![no_main]
use libfuzzer_sys::fuzz_target;

fuzz_target!(|data: &[u8]| {
    // Must never panic on any input.
    let _ = serde_json::from_slice::<anvil_runtime::snapshot::SaveFile>(data);
});
