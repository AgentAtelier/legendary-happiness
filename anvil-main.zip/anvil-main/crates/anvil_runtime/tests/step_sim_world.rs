// Tests moved from crates/anvil_runtime/src/step.rs

use anvil_core::{AuthoredEntityId, ConnectionId, EntityKind, RegionId};
use anvil_runtime::Runtime;
use anvil_world::types::{AssetReferenceTable, AuthoredConnection, AuthoredEntity, Region, WorldMetadata};
use anvil_world::WorldAuthored;
use std::sync::Arc;

fn sample_world() -> WorldAuthored {
    WorldAuthored {
        regions: vec![Region {
            id: RegionId::new(0),
            name: "Test Region".to_string(),
            terrain_type: anvil_core::TerrainType::Highlands,
            mood: "calm".to_string(),
            style: anvil_core::StyleHints {
                palette: vec![],
                density: "medium".to_string(),
                atmosphere: "clear".to_string(),
            },
        }],
        entities: vec![AuthoredEntity {
            id: AuthoredEntityId::new(1),
            name: "Test Entity".to_string(),
            kind: EntityKind::Landmark,
            region: RegionId::new(0),
            archetype: anvil_core::arche!("test_archetype"),
            description: "Test description".to_string(),
        }],
        connections: vec![AuthoredConnection {
            id: ConnectionId::new(0),
            name: "Test Connection".to_string(),
            from_region: RegionId::new(0),
            to_region: RegionId::new(0),
            kind: anvil_core::ConnectionKind::Path,
            directionality: anvil_core::Directionality::Bidirectional,
            entity_id: AuthoredEntityId::new(1),
        }],
        history_events: Arc::new(vec![]),
        asset_refs: AssetReferenceTable { entries: vec![] },
        metadata: WorldMetadata {
            source_hash: "test".to_string(),
            compiler_version: "0.1.0".to_string(),
            history_events_digest: "".to_string(),
        },
        entity_index: std::collections::HashMap::new(),
        connection_index: std::collections::HashMap::new(),
        asset_ref_index: std::collections::HashMap::new(),
    }
}

#[test]
fn step_sim_world_advances_time() {
    use anvil_runtime::RuntimeCommand;
    
    let mut runtime = Runtime::new(sample_world());
    let initial_seconds = runtime.time.seconds_since_start;

    runtime.apply(&RuntimeCommand::Tick { dt_micros: 10_000_000 }).unwrap();

    assert!((runtime.time.seconds_since_start - initial_seconds - 10.0).abs() < 0.001);
}

#[test]
fn step_sim_world_advances_weather() {
    use anvil_runtime::RuntimeCommand;
    
    let mut runtime = Runtime::new(sample_world());
    let initial_phase_secs = runtime.weather.phase_remaining_secs;

    runtime.apply(&RuntimeCommand::Tick { dt_micros: 5_000_000 }).unwrap();

    // Weather should have been ticked
    assert!(runtime.weather.phase_remaining_secs < initial_phase_secs);
}

#[test]
fn step_sim_world_is_deterministic() {
    use anvil_runtime::RuntimeCommand;
    
    let world = sample_world();
    let mut a = Runtime::new(world.clone());
    let mut b = Runtime::new(world);

    a.apply(&RuntimeCommand::Tick { dt_micros: 5_000_000 }).unwrap();
    b.apply(&RuntimeCommand::Tick { dt_micros: 5_000_000 }).unwrap();

    assert_eq!(a.time.seconds_since_start, b.time.seconds_since_start);
}

#[test]
fn step_sim_world_with_zero_dt_is_noop() {
    use anvil_runtime::RuntimeCommand;
    
    let mut runtime = Runtime::new(sample_world());
    let initial_time = runtime.time.seconds_since_start;
    let initial_weather_phase = runtime.weather.phase_remaining_secs;

    runtime.apply(&RuntimeCommand::Tick { dt_micros: 0 }).unwrap();

    assert_eq!(runtime.time.seconds_since_start, initial_time);
    assert_eq!(runtime.weather.phase_remaining_secs, initial_weather_phase);
}
