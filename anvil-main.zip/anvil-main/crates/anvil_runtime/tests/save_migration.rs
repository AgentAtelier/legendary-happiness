//! Tests for save format migration (v6 → v8).

#![deny(warnings)]

use anvil_world::{hashing::history_events_digest, WorldAuthored};
use glam::Vec3;

#[test]
fn test_v6_fixture_loads_and_migrates() {
    // Read the v6 fixture
    let fixture_data = std::fs::read_to_string("tests/save_v6_fixture.json")
        .expect("Failed to read v6 fixture");

    // Parse and upgrade - should succeed and produce v8
    let save = anvil_runtime::snapshot::migration::parse_and_upgrade_save(fixture_data.as_bytes())
        .expect("Failed to parse and upgrade v6 fixture");

    // Verify it was upgraded to v8
    assert_eq!(save.format_version, 8);
    assert_eq!(save.world_hash, "test_world_v6_hash_12345");
    
    // Verify player position was preserved
    assert_eq!(save.player_position, Vec3::new(10.0, 5.0, 10.0));
    
    // Verify system_snapshots was initialized (from physics migration)
    assert!(!save.system_snapshots.is_empty() || save.system_snapshots.contains_key("PhysicsSystem"));
}

#[test]
fn test_v6_fixture_roundtrip_with_world() {
    // Create a world that matches the fixture
    let mut world = WorldAuthored::default();
    world.metadata.source_hash = "test_world_v6_hash_12345".to_string();
    world.metadata.compiler_version = "0.1.0".to_string();
    world.metadata.history_events_digest = history_events_digest(&[]);

    // Read the v6 fixture
    let fixture_data = std::fs::read_to_string("tests/save_v6_fixture.json")
        .expect("Failed to read v6 fixture");

    // Parse and upgrade
    let save = anvil_runtime::snapshot::migration::parse_and_upgrade_save(fixture_data.as_bytes())
        .expect("Failed to parse and upgrade");

    // Restore the runtime from the upgraded save
    let runtime = anvil_runtime::Runtime::restore_with_world(
        &serde_json::to_vec(&save).expect("Failed to serialize save"),
        world.clone(),
    )
    .expect("Failed to restore runtime");

    // Verify the runtime was restored correctly
    assert_eq!(runtime.world.metadata.source_hash, "test_world_v6_hash_12345");
    assert_eq!(runtime.time.seconds_since_start, 0.0);
    assert!((runtime.weather.temperature - 14.0).abs() < 0.001);
    
    // The player position from the save should have been used
    // (but the Runtime::restore_with_world ignores player_position, that's a known limitation)
}

#[test]
fn test_v6_to_v8_migration_initializes_system_snapshots() {
    // Read the v6 fixture
    let fixture_data = std::fs::read_to_string("tests/save_v6_fixture.json")
        .expect("Failed to read v6 fixture");

    // Parse and upgrade
    let save = anvil_runtime::snapshot::migration::parse_and_upgrade_save(fixture_data.as_bytes())
        .expect("Failed to parse and upgrade");

    // Verify system_snapshots was initialized (from physics migration)
    assert!(!save.system_snapshots.is_empty() || save.system_snapshots.contains_key("PhysicsSystem"));
}

#[test]
fn test_v8_save_with_system_snapshots_serializes_correctly() {
    use anvil_sim::PhysicsSystem;
    let world = WorldAuthored::default();
    let mut runtime = anvil_runtime::Runtime::new(world);
    
    // Register physics system and add some state
    let mut physics_system = PhysicsSystem::new();
    physics_system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);
    runtime.register_system(Box::new(physics_system));
    
    // Create a save
    let save = anvil_runtime::snapshot::format::SaveFile::from_runtime(&runtime, Vec3::new(10.0, 5.0, 10.0));
    
    // Verify it has system_snapshots
    assert!(!save.system_snapshots.is_empty());
    assert!(save.system_snapshots.contains_key("PhysicsSystem"));
    
    // Verify serialization works
    let json = serde_json::to_string(&save).expect("Failed to serialize save");
    assert!(json.contains("system_snapshots"));
    assert!(json.contains("PhysicsSystem"));
}

#[test]
fn test_v8_save_roundtrip() {
    use anvil_sim::{CatastropheSystem, JoySystem, NpcSystem, PhysicsSystem};
    
    let world = WorldAuthored::default();
    let mut runtime = anvil_runtime::Runtime::new(world);
    
    // Register all systems
    runtime.register_system(Box::new(NpcSystem::new()));
    runtime.register_system(Box::new(CatastropheSystem::new()));
    runtime.register_system(Box::new(JoySystem::new()));
    let mut physics_system = PhysicsSystem::new();
    physics_system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);
    runtime.register_system(Box::new(physics_system));
    
    // Create a save
    let save = anvil_runtime::snapshot::format::SaveFile::from_runtime(&runtime, Vec3::new(10.0, 5.0, 10.0));
    
    // Verify all systems are saved
    assert_eq!(save.system_snapshots.len(), 4);
    assert!(save.system_snapshots.contains_key("npc_system"));
    assert!(save.system_snapshots.contains_key("catastrophe_system"));
    assert!(save.system_snapshots.contains_key("joy_system"));
    assert!(save.system_snapshots.contains_key("PhysicsSystem"));
    
    // Roundtrip: deserialize and verify
    let json = serde_json::to_vec(&save).expect("Failed to serialize");
    let restored: anvil_runtime::snapshot::format::SaveFile = 
        serde_json::from_slice(&json).expect("Failed to deserialize");
    
    assert_eq!(restored.system_snapshots.len(), 4);
}
