// Source: Sprint 13 — Phase 2 gate integration test.
// Three-region streaming test with deterministic state hashes.

use anvil_assets::AssetCatalogue;
use anvil_core::{ConnectionSpec, RegionSpec};
use anvil_runtime::{Runtime, RuntimeCommand};
use anvil_world::compiler::compile_world;
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;

/// Get the workspace root directory.
fn workspace_root() -> PathBuf {
    std::env::current_dir()
        .unwrap()
        .ancestors()
        .nth(2)
        .unwrap()
        .to_path_buf()
}

/// Load a JSON file and deserialize it.
fn load_json<T: serde::de::DeserializeOwned>(path: &str) -> T {
    let full_path = workspace_root().join(path);
    let bytes = fs::read(&full_path).unwrap_or_else(|_| {
        panic!("Failed to read fixture file: {}", full_path.display())
    });
    serde_json::from_slice(&bytes).expect("Failed to parse fixture JSON")
}

/// Load the Emberwood catalogue.
fn load_catalogue() -> AssetCatalogue {
    let catalogue_path = workspace_root().join("assets/catalogue.json");
    AssetCatalogue::load(&catalogue_path, None).expect("Failed to load catalogue")
}

#[test]
fn test_three_region_streaming() {
    // 1. Load fixture JSONs
    let base = "crates/anvil_runtime/tests/fixtures";
    let highlands: RegionSpec = load_json(&format!("{}/regions/highlands.json", base));
    let forest: RegionSpec = load_json(&format!("{}/regions/forest.json", base));
    let coast: RegionSpec = load_json(&format!("{}/regions/coast.json", base));

    let h_to_f: ConnectionSpec = load_json(&format!("{}/connections/h_to_f.json", base));
    let f_to_c: ConnectionSpec = load_json(&format!("{}/connections/f_to_c.json", base));

    let specs = vec![highlands, forest, coast];
    let connections = vec![h_to_f, f_to_c];

    // 2. Load catalogue and compile world
    let catalogue = load_catalogue();
    let world = compile_world(&specs, &connections, &catalogue)
        .expect("Failed to compile world");

    // Assert 3 regions, 2 connections
    assert_eq!(world.regions.len(), 3, "Expected 3 regions");
    assert_eq!(world.connections.len(), 2, "Expected 2 connections");

    // Create a map from region names to IDs
    let region_name_to_id: HashMap<_, _> = world
        .regions
        .iter()
        .map(|r| (r.name.clone(), r.id))
        .collect();

    let highlands_id = region_name_to_id["Highlands"];
    let forest_id = region_name_to_id["Forest"];
    let coast_id = region_name_to_id["Coast"];

    // 3. Create Runtime and get initial hash H0
    let runtime = Runtime::new(world.clone());
    let h0 = runtime.state_hash();

    // 4. Apply LoadRegion(highlands), tick 60*16ms, verify hash changes
    let mut runtime = Runtime::new(world.clone());
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: highlands_id })
        .expect("Failed to load region");

    // Tick 60 * 16ms = 960ms = 0.96 seconds
    runtime
        .apply(&RuntimeCommand::Tick { dt_micros: 960_000 })
        .expect("Failed to tick");

    let h1 = runtime.state_hash();
    assert_ne!(h0, h1, "Hash must change after loading region and ticking");

    // 5. Apply UnloadRegion(highlands), verify hash returns to H0
    runtime
        .apply(&RuntimeCommand::UnloadRegion { id: highlands_id })
        .expect("Failed to unload region");

    let h0_again = runtime.state_hash();
    assert_eq!(
        h0, h0_again,
        "Hash must return to H0 after unloading region"
    );

    // 6. Load all three regions, get H2
    let mut runtime = Runtime::new(world.clone());
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: highlands_id })
        .expect("Failed to load highlands");
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: forest_id })
        .expect("Failed to load forest");
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: coast_id })
        .expect("Failed to load coast");

    let h2 = runtime.state_hash();
    assert_ne!(h0, h2, "Hash must differ with all regions loaded");

    // 7. Snapshot to bytes, restore, verify hash equals H2
    let snapshot_bytes = runtime.snapshot().expect("Failed to snapshot");

    let restored_runtime =
        Runtime::restore_with_world(&snapshot_bytes, world.clone())
            .expect("Failed to restore");

    let h2_restored = restored_runtime.state_hash();
    assert_eq!(
        h2, h2_restored,
        "Restored runtime must have same hash as original"
    );

    // Verify loaded regions are restored
    assert_eq!(
        runtime.loaded_regions.len(),
        restored_runtime.loaded_regions.len(),
        "Restored runtime must have same number of loaded regions"
    );
    for id in &runtime.loaded_regions {
        assert!(
            restored_runtime.loaded_regions.contains(id),
            "Restored runtime must contain all loaded regions"
        );
    }
}
