// Source: forge_sim/src/build.rs as of the Forge snapshot.
// 8-line build script - ported verbatim.

fn main() {
    // Empty build script - no custom build steps needed.
    // Kept as placeholder for future build-time code generation.
}
