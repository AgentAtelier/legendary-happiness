// Source: forge_sim/src/types.rs as of the Forge snapshot.
// Ported as foundation for anvil_runtime.

use serde::{Deserialize, Serialize};


/// Severity band for evidence / consequence visibility.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[non_exhaustive]
pub enum EvidenceSeverityBand {
    /// Barely detectable.
    Trace,
    /// Noticeable but subtle.
    Faint,
    /// Clearly visible.
    Pronounced,
    /// Impossible to miss.
    Severe,
}

/// Terrain height and texture data for runtime sampling.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Terrain {
    /// Height values in row-major order (z * width + x).
    pub heights: Vec<f32>,
    /// Grid width (number of vertices along the X axis).
    pub width: u32,
    /// Grid depth (number of vertices along the Z axis).
    pub depth: u32,
    /// Total world-space width (metres).
    pub world_width: f32,
    /// Total world-space depth (metres).
    pub world_depth: f32,
    /// Splat weights (RGBA-style) for each vertex, also row-major.
    /// Each entry is [grass, rock, dirt, sand] summing to 1.0.
    pub splat: Vec<[f32; 4]>,
}

impl Terrain {
    /// Returns the grid width (same as `width` for convenience).
    pub fn grid_width(&self) -> usize {
        self.width as usize
    }

    /// Returns the grid depth (same as `depth` for convenience).
    pub fn grid_depth(&self) -> usize {
        self.depth as usize
    }
}
