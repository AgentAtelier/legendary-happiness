// Source: forge_sim/src/weather.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use serde::{Deserialize, Serialize};

/// Minimum phase duration in seconds (prevents flickering).
const MIN_PHASE_SECONDS: f32 = 40.0;
/// Maximum phase duration in seconds.
const MAX_PHASE_SECONDS: f32 = 180.0;
/// Blend time between weather phases (seconds).
const TRANSITION_SECONDS: f32 = 20.0;

/// Deterministic low-quality hash for weather scheduling.
fn lcg_next(state: u32) -> u32 {
    state.wrapping_mul(1664525).wrapping_add(1013904223)
}

fn hash_to_f32(h: u32) -> f32 {
    (h >> 8) as f32 / 16_777_216.0 // 24-bit mantissa → [0, 1)
}

/// Discrete weather phases.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[derive(Default)]
pub enum WeatherPhase {
    /// Clear skies.
    #[default]
    Clear,
    /// Cloudy but no precipitation.
    Overcast,
    /// Rainfall.
    Rain,
    /// Thick fog reducing visibility.
    Fog,
    /// Heavy storm with potential lightning.
    Storm,
}

impl WeatherPhase {
    /// Duration of each weather phase in seconds.
    pub const PHASE_SECONDS: f32 = 12.0;

    /// Returns a human-readable label for this weather phase.
    pub fn label(self) -> &'static str {
        match self {
            WeatherPhase::Clear => "clear",
            WeatherPhase::Overcast => "overcast",
            WeatherPhase::Rain => "rain",
            WeatherPhase::Fog => "fog",
            WeatherPhase::Storm => "storm",
        }
    }

    /// Target wetness level [0, 1] for this phase.
    pub fn target_wetness(self) -> f32 {
        match self {
            WeatherPhase::Clear => 0.0,
            WeatherPhase::Overcast => 0.0,
            WeatherPhase::Rain => 0.65,
            WeatherPhase::Fog => 0.15,
            WeatherPhase::Storm => 1.0,
        }
    }

    /// Returns true if this weather phase produces precipitation.
    pub fn is_precipitating(self) -> bool {
        matches!(self, WeatherPhase::Rain | WeatherPhase::Storm)
    }

    /// Returns true if this weather phase can produce lightning.
    pub fn is_storm(self) -> bool {
        matches!(self, WeatherPhase::Storm)
    }

    /// Returns the base cloud cover fraction [0, 1] for this phase.
    pub fn cloud_cover(self) -> f32 {
        match self {
            WeatherPhase::Clear => 0.05,
            WeatherPhase::Overcast => 0.75,
            WeatherPhase::Rain => 0.88,
            WeatherPhase::Fog => 0.60,
            WeatherPhase::Storm => 1.0,
        }
    }

    /// Returns the base fog intensity [0, 1] for this phase.
    pub fn base_fog_intensity(self) -> f32 {
        match self {
            WeatherPhase::Clear => 0.0,
            WeatherPhase::Overcast => 0.05,
            WeatherPhase::Rain => 0.12,
            WeatherPhase::Fog => 0.55,
            WeatherPhase::Storm => 0.20,
        }
    }

    /// Deterministic derivation of the current weather phase from game time.
    pub fn from_game_time(time: &crate::time::GameTime) -> WeatherPhase {
        let seconds = time.seconds_since_start;
        if !seconds.is_finite() || seconds <= 0.0 || Self::PHASE_SECONDS <= 0.0 {
            return WeatherPhase::Clear;
        }
        let bucket = (seconds / Self::PHASE_SECONDS).floor() as i64;
        match bucket.rem_euclid(5) {
            0 => WeatherPhase::Clear,
            1 => WeatherPhase::Overcast,
            2 => WeatherPhase::Rain,
            3 => WeatherPhase::Fog,
            _ => WeatherPhase::Storm,
        }
    }
}

/// Full weather simulation state.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct WeatherSimulation {
    /// Ambient temperature in °C.
    pub temperature: f32,
    /// Relative humidity [0.0, 1.0].
    pub humidity: f32,
    /// Relative atmospheric pressure (hPa-like, reference ~1013).
    pub pressure: f32,
    /// Wind speed in m/s.
    pub wind_speed: f32,
    /// Wind direction in radians (0 = North/+Z, π/2 = East/+X).
    pub wind_direction: f32,
    /// Accumulated precipitation in mm since last dry period.
    pub accumulated_precipitation: f32,
    /// Current discrete weather phase.
    pub current_weather: WeatherPhase,
    /// Blend progress [0.0, 1.0] from `current_weather` toward `next_weather`.
    pub transition_progress: f32,
    /// Next weather phase (what we're blending toward).
    pub next_weather: WeatherPhase,
    /// Remaining seconds in the current phase (excluding transition overlap).
    pub phase_remaining_secs: f32,
    /// LCG state for deterministic phase scheduling.
    pub rng_state: u32,
}

impl Default for WeatherSimulation {
    fn default() -> Self {
        Self {
            temperature: 14.0,
            humidity: 0.45,
            pressure: 1013.0,
            wind_speed: 2.5,
            wind_direction: 0.0,
            accumulated_precipitation: 0.0,
            current_weather: WeatherPhase::Clear,
            transition_progress: 1.0,
            next_weather: WeatherPhase::Clear,
            phase_remaining_secs: 90.0,
            rng_state: 0x4d32_19af,
        }
    }
}

impl WeatherSimulation {
    /// Construct from a world seed for deterministic initial state.
    pub fn from_seed(seed: u64) -> Self {
        let mut rng = (seed ^ 0xdeadbeef_cafebabe) as u32;
        rng = lcg_next(rng);
        let initial_phase = match rng % 5 {
            0 => WeatherPhase::Clear,
            1 => WeatherPhase::Overcast,
            2 => WeatherPhase::Rain,
            3 => WeatherPhase::Fog,
            _ => WeatherPhase::Storm,
        };
        rng = lcg_next(rng);
        let phase_secs =
            MIN_PHASE_SECONDS + hash_to_f32(rng) * (MAX_PHASE_SECONDS - MIN_PHASE_SECONDS);
        rng = lcg_next(rng);

        Self {
            current_weather: initial_phase,
            next_weather: initial_phase,
            transition_progress: 1.0,
            phase_remaining_secs: phase_secs,
            rng_state: rng,
            ..Default::default()
        }
    }

    /// Blended wetness: interpolates between current and next target wetness.
    pub fn wetness(&self) -> f32 {
        let cur = self.current_weather.target_wetness();
        let nxt = self.next_weather.target_wetness();
        cur + (nxt - cur) * self.transition_progress
    }

    /// True when blended-in cloud cover exceeds the storm threshold.
    pub fn is_storm(&self) -> bool {
        self.current_weather.is_storm()
            || (self.next_weather.is_storm() && self.transition_progress > 0.5)
    }

    /// Blended cloud cover [0, 1].
    pub fn cloud_cover(&self) -> f32 {
        let cur = self.current_weather.cloud_cover();
        let nxt = self.next_weather.cloud_cover();
        cur + (nxt - cur) * self.transition_progress
    }

    /// Blended fog intensity [0, 1].
    pub fn fog_intensity(&self) -> f32 {
        let cur = self.current_weather.base_fog_intensity();
        let nxt = self.next_weather.base_fog_intensity();
        cur + (nxt - cur) * self.transition_progress
    }

    /// Wind vector (X, Z) components in world space (m/s).
    pub fn wind_vector(&self) -> (f32, f32) {
        let (sin, cos) = self.wind_direction.sin_cos();
        (sin * self.wind_speed, cos * self.wind_speed)
    }

    /// Pick the next weather phase using the deterministic LCG.
    fn schedule_next_phase(&mut self) {
        self.rng_state = lcg_next(self.rng_state);
        let next = match self.rng_state % 5 {
            0 => WeatherPhase::Clear,
            1 => WeatherPhase::Overcast,
            2 => WeatherPhase::Rain,
            3 => WeatherPhase::Fog,
            _ => WeatherPhase::Storm,
        };
        // Slight bias: avoid repeating exactly the same phase.
        let next = if next == self.current_weather {
            self.rng_state = lcg_next(self.rng_state);
            match self.rng_state % 4 {
                0 => WeatherPhase::Clear,
                1 => WeatherPhase::Overcast,
                2 => WeatherPhase::Rain,
                _ => WeatherPhase::Fog,
            }
        } else {
            next
        };
        self.next_weather = next;

        // Schedule phase duration.
        self.rng_state = lcg_next(self.rng_state);
        self.phase_remaining_secs = MIN_PHASE_SECONDS
            + hash_to_f32(self.rng_state) * (MAX_PHASE_SECONDS - MIN_PHASE_SECONDS);
    }

    /// Validate the weather simulation state.
    pub fn validate(&self) -> anvil_core::ValidationErrors {
        let mut errors = anvil_core::ValidationErrors::new();
        if !self.temperature.is_finite() {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E193",
                "WeatherSimulation",
                "temperature",
                self.temperature.to_string(),
                "temperature must be finite"
            );
        }
        if !self.humidity.is_finite() || self.humidity < 0.0 || self.humidity > 1.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E194",
                "WeatherSimulation",
                "humidity",
                self.humidity.to_string(),
                "humidity must be finite and in [0.0, 1.0]"
            );
        }
        if !self.pressure.is_finite() {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E195",
                "WeatherSimulation",
                "pressure",
                self.pressure.to_string(),
                "pressure must be finite"
            );
        }
        if !self.wind_speed.is_finite() || self.wind_speed < 0.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E196",
                "WeatherSimulation",
                "wind_speed",
                self.wind_speed.to_string(),
                "wind_speed must be finite and non-negative"
            );
        }
        if !self.accumulated_precipitation.is_finite() || self.accumulated_precipitation < 0.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E197",
                "WeatherSimulation",
                "accumulated_precipitation",
                self.accumulated_precipitation.to_string(),
                "accumulated_precipitation must be finite and non-negative"
            );
        }
        if !self.transition_progress.is_finite() || self.transition_progress < 0.0 || self.transition_progress > 1.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E198",
                "WeatherSimulation",
                "transition_progress",
                self.transition_progress.to_string(),
                "transition_progress must be finite and in [0.0, 1.0]"
            );
        }
        if !self.phase_remaining_secs.is_finite() || self.phase_remaining_secs < 0.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E199",
                "WeatherSimulation",
                "phase_remaining_secs",
                self.phase_remaining_secs.to_string(),
                "phase_remaining_secs must be finite and non-negative"
            );
        }
        errors
    }
}

/// Advance the weather simulation by `dt` seconds.
pub fn tick_weather(weather: &mut WeatherSimulation, dt: f32) {
    if dt <= 0.0 {
        return;
    }

    // Phase timer.
    weather.phase_remaining_secs -= dt;

    if weather.phase_remaining_secs <= TRANSITION_SECONDS
        && weather.transition_progress >= 1.0
    {
        // Begin transition to next phase.
        if weather.next_weather == weather.current_weather {
            weather.schedule_next_phase();
        }
        weather.transition_progress = 0.0;
    }

    // Advance blend.
    if weather.transition_progress < 1.0 {
        let blend_speed = 1.0 / TRANSITION_SECONDS;
        weather.transition_progress = (weather.transition_progress + blend_speed * dt).min(1.0);

        // When blend completes, commit the transition.
        if weather.transition_progress >= 1.0 {
            weather.current_weather = weather.next_weather;
            // Reset precipitation on clearing.
            if !weather.current_weather.is_precipitating() {
                weather.accumulated_precipitation = 0.0;
            }
            // Schedule next.
            weather.schedule_next_phase();
        }
    }

    // Drift wind direction slowly over time (deterministic low-frequency wobble).
    let wind_drift = (weather.accumulated_precipitation * 0.003 + dt * 0.008).min(0.05);
    let drift_sign = if weather.rng_state & 1 == 0 {
        1.0_f32
    } else {
        -1.0_f32
    };
    weather.wind_direction =
        (weather.wind_direction + drift_sign * wind_drift) % (2.0 * std::f32::consts::PI);

    // Wind speed responds to weather intensity.
    let target_wind = match weather.current_weather {
        WeatherPhase::Clear => 1.5,
        WeatherPhase::Overcast => 3.0,
        WeatherPhase::Rain => 5.0,
        WeatherPhase::Fog => 0.5,
        WeatherPhase::Storm => 12.0,
    };
    let wind_alpha = (dt * 0.3).min(1.0);
    weather.wind_speed += (target_wind - weather.wind_speed) * wind_alpha;

    // Temperature and humidity drift toward phase targets.
    let target_temp = match weather.current_weather {
        WeatherPhase::Clear => 18.0,
        WeatherPhase::Overcast => 13.0,
        WeatherPhase::Rain => 10.0,
        WeatherPhase::Fog => 8.0,
        WeatherPhase::Storm => 9.0,
    };
    let target_humidity = match weather.current_weather {
        WeatherPhase::Clear => 0.35,
        WeatherPhase::Overcast => 0.55,
        WeatherPhase::Rain => 0.80,
        WeatherPhase::Fog => 0.95,
        WeatherPhase::Storm => 0.90,
    };
    let slow_alpha = (dt * 0.05).min(1.0);
    weather.temperature += (target_temp - weather.temperature) * slow_alpha;
    weather.humidity += (target_humidity - weather.humidity) * slow_alpha;

    // Pressure: falls before storms, rises after clearing.
    let target_pressure = match weather.current_weather {
        WeatherPhase::Clear => 1018.0,
        WeatherPhase::Overcast => 1010.0,
        WeatherPhase::Rain => 1005.0,
        WeatherPhase::Fog => 1012.0,
        WeatherPhase::Storm => 995.0,
    };
    weather.pressure += (target_pressure - weather.pressure) * slow_alpha;
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        #[test]
        fn from_seed_is_deterministic(seed in any::<u64>()) {
            let a = WeatherSimulation::from_seed(seed);
            let b = WeatherSimulation::from_seed(seed);
            assert_eq!(a.current_weather, b.current_weather);
            assert_eq!(a.rng_state, b.rng_state);
        }
    }

    #[test]
    fn tick_weather_is_deterministic() {
        let mut a = WeatherSimulation::from_seed(42);
        let mut b = WeatherSimulation::from_seed(42);

        tick_weather(&mut a, 0.016);
        tick_weather(&mut b, 0.016);

        assert_eq!(a.current_weather, b.current_weather);
        assert!((a.wind_speed - b.wind_speed).abs() < 1e-4);
        assert!((a.humidity - b.humidity).abs() < 1e-4);
    }

    #[test]
    fn weather_phase_cycles_deterministically() {
        let mut weather = WeatherSimulation::from_seed(123);

        // Tick for a long time
        for _ in 0..1000 {
            tick_weather(&mut weather, 1.0);
        }

        // State should still be deterministic (same seed = same sequence)
        let mut weather2 = WeatherSimulation::from_seed(123);
        for _ in 0..1000 {
            tick_weather(&mut weather2, 1.0);
        }

        assert_eq!(weather.current_weather, weather2.current_weather);
    }

    #[test]
    fn wind_vector_matches_direction_and_speed() {
        let weather_north = WeatherSimulation {
            wind_speed: 5.0,
            wind_direction: 0.0, // North → (0, 5)
            ..Default::default()
        };
        let (wx, wz) = weather_north.wind_vector();
        assert!(wx.abs() < 0.001);
        assert!((wz - 5.0).abs() < 0.001);

        let weather_east = WeatherSimulation {
            wind_speed: 5.0,
            wind_direction: std::f32::consts::FRAC_PI_2, // East → (5, ~0)
            ..Default::default()
        };
        let (ex, ez) = weather_east.wind_vector();
        assert!((ex - 5.0).abs() < 0.001);
        assert!(ez.abs() < 0.001);
    }

    #[test]
    fn wetness_blends_between_phases() {
        let weather = WeatherSimulation {
            current_weather: WeatherPhase::Clear,
            next_weather: WeatherPhase::Rain,
            transition_progress: 0.5,
            ..Default::default()
        };

        let wet = weather.wetness();
        let expected = 0.5 * (0.0 + 0.65);
        assert!((wet - expected).abs() < 0.01);
    }

    #[test]
    fn storm_detection_triggers_at_half_blend() {
        let weather_40 = WeatherSimulation {
            current_weather: WeatherPhase::Clear,
            next_weather: WeatherPhase::Storm,
            transition_progress: 0.4,
            ..Default::default()
        };

        assert!(!weather_40.is_storm());

        let weather_60 = WeatherSimulation {
            current_weather: WeatherPhase::Clear,
            next_weather: WeatherPhase::Storm,
            transition_progress: 0.6,
            ..Default::default()
        };
        assert!(weather_60.is_storm());
    }
}
