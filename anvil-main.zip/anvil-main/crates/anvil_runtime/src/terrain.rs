// Source: forge_sim/src/terrain.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use crate::types::Terrain;

/// Sample terrain height at a given world position using bilinear interpolation.
/// Returns 0.0 if terrain data is empty or invalid.
pub fn sample_height(terrain: &Terrain, x: f32, z: f32) -> f32 {
    if terrain.heights.is_empty() || terrain.width == 0 || terrain.depth == 0 {
        return 0.0;
    }

    if terrain.width == 1 && terrain.depth == 1 {
        return terrain.heights[0];
    }

    let x_grid_max = (terrain.width.saturating_sub(1)) as f32;
    let z_grid_max = (terrain.depth.saturating_sub(1)) as f32;

    let x_norm = normalize_axis(x, terrain.world_width);
    let z_norm = normalize_axis(z, terrain.world_depth);

    let x_grid = x_norm * x_grid_max;
    let z_grid = z_norm * z_grid_max;

    let x0 = x_grid.floor() as usize;
    let z0 = z_grid.floor() as usize;
    let x1 = (x0 + 1).min(terrain.grid_width().saturating_sub(1));
    let z1 = (z0 + 1).min(terrain.grid_depth().saturating_sub(1));

    let tx = x_grid.fract();
    let tz = z_grid.fract();

    let h00 = height_at(terrain, x0, z0);
    let h10 = height_at(terrain, x1, z0);
    let h01 = height_at(terrain, x0, z1);
    let h11 = height_at(terrain, x1, z1);

    let top = lerp(h00, h10, tx);
    let bottom = lerp(h01, h11, tx);

    lerp(top, bottom, tz)
}

fn normalize_axis(value: f32, world_size: f32) -> f32 {
    if world_size <= f32::EPSILON {
        return 0.0;
    }

    (value / world_size).clamp(0.0, 1.0)
}

fn height_at(terrain: &Terrain, x: usize, z: usize) -> f32 {
    let width = terrain.grid_width();
    terrain.heights[z * width + x]
}

fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + ((b - a) * t)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sample_height_clamps_out_of_bounds() {
        let terrain = Terrain {
            heights: vec![1.0, 2.0, 3.0, 4.0],
            width: 2,
            depth: 2,
            world_width: 10.0,
            world_depth: 10.0,
            splat: vec![[1.0, 0.0, 0.0, 0.0]; 4],
        };

        let sampled = sample_height(&terrain, -100.0, -100.0);
        assert!((sampled - 1.0).abs() < 0.001);

        let sampled = sample_height(&terrain, 100.0, 100.0);
        assert!((sampled - 4.0).abs() < 0.001);
    }

    #[test]
    fn sample_height_interpolates_between_points() {
        let terrain = Terrain {
            heights: vec![0.0, 0.0, 10.0, 10.0],
            width: 2,
            depth: 2,
            world_width: 10.0,
            world_depth: 10.0,
            splat: vec![[1.0, 0.0, 0.0, 0.0]; 4],
        };

        let sampled = sample_height(&terrain, 5.0, 5.0);
        assert!((sampled - 5.0).abs() < 0.001);
    }

    #[test]
    fn sample_height_empty_terrain_returns_zero() {
        let terrain = Terrain {
            heights: vec![],
            width: 0,
            depth: 0,
            world_width: 10.0,
            world_depth: 10.0,
            splat: vec![],
        };
        assert_eq!(sample_height(&terrain, 5.0, 5.0), 0.0);
    }

    #[test]
    fn sample_height_single_point_returns_that_point() {
        let terrain = Terrain {
            heights: vec![42.0],
            width: 1,
            depth: 1,
            world_width: 10.0,
            world_depth: 10.0,
            splat: vec![[1.0, 0.0, 0.0, 0.0]],
        };
        assert!((sample_height(&terrain, 5.0, 5.0) - 42.0).abs() < 0.001);
    }
}
