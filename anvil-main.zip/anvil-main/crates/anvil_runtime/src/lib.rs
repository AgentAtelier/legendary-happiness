//! # anvil_runtime
//!
//! **Layer:** DETERMINISTIC
//!
//! **Purpose:** A tick-driven state machine that materialises a deterministic
//! `WorldAuthored` into a live runtime state. This crate provides the core
//! simulation loop, state snapshotting, and deterministic world interaction.
//!
//! **Main Types:**
//! - [`Runtime`] — central runtime state container
//! - [`RuntimeCommand`] — commands that drive the runtime forward
//! - [`RuntimeState`] — trait defining the runtime contract
//! - [`SaveFile`] — snapshot serialization format
//!
//! **Version Migration:** Save format version 7 introduced physics state serialization.
//! Previous versions are automatically upgraded during load.

// Source: forge_sim/src/lib.rs as of the Forge snapshot.
// Ported as foundation for anvil_runtime.

#![deny(warnings)]
#![deny(missing_docs)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

/// Game time management and advancement.
pub mod time;
/// Weather simulation system.
pub mod weather;
/// Region loading and unloading.
pub mod region;
/// Terrain data and sampling.
pub mod terrain;
/// Runtime invariants and validation.
pub mod invariants;
#[cfg(feature = "progression_trace")]
/// Progression tracing for debugging.
pub mod trace;
/// Snapshot serialization and deserialization.
pub mod snapshot;

/// Common type definitions.
pub mod types;

use anvil_core::ValidationErrors;
use anvil_sim::{
    CatastropheSystem, DeterministicRng, JoySystem, NpcSystem, PhysicsSystem, SimContext, SimError,
    SimEvent, SimSystem, WorldEnv, WorldRuntime,
};
use anvil_world::WorldAuthored;

use crate::time::GameTime;
use crate::weather::WeatherSimulation;

/// The central runtime state, layered on top of an immutable WorldAuthored.
pub struct Runtime {
    /// Game time state.
    pub time: GameTime,
    /// Weather simulation.
    pub weather: WeatherSimulation,
    /// The authored world (immutable reference data).
    pub world: WorldAuthored,
    /// Currently loaded regions. Using BTreeSet for sorted iteration in state_hash().
    pub loaded_regions: std::collections::BTreeSet<anvil_core::RegionId>,
    /// Simulation systems sorted by priority (highest first).
    pub systems: Vec<Box<dyn SimSystem>>,
    /// The mutable world runtime state for simulation systems.
    pub world_runtime: WorldRuntime,
    /// World environment data for simulation systems.
    pub world_env: WorldEnv,
    /// Deterministic RNG for simulation systems.
    pub rng: DeterministicRng,
    /// Events from the previous tick.
    pub events_in: Vec<SimEvent>,
    /// Events produced by the current tick.
    pub events_out: Vec<SimEvent>,
}

impl Runtime {
    /// Create a new runtime from an authored world.
    pub fn new(world: WorldAuthored) -> Self {
        Self {
            time: GameTime::default(),
            weather: WeatherSimulation::default(),
            world: world.clone(),
            loaded_regions: std::collections::BTreeSet::new(),
            systems: Vec::new(),
            world_runtime: WorldRuntime::new(world),
            world_env: WorldEnv::default(),
            rng: DeterministicRng::default(),
            events_in: Vec::new(),
            events_out: Vec::new(),
        }
    }

    /// Register a simulation system. Systems are stored in priority order (highest first).
    pub fn register_system(&mut self, system: Box<dyn SimSystem>) {
        // Insert the system in the correct position based on priority
        let priority = system.priority();
        let index = self.systems.partition_point(|s| s.priority() > priority);
        self.systems.insert(index, system);
    }

    /// Compute a deterministic hash of the runtime state.
    pub fn state_hash(&self) -> [u8; 32] {
        use serde_json::to_vec;
        
        let mut hasher = blake3::Hasher::new();
        hasher.update(self.world.metadata.source_hash.as_bytes());
        // BTreeSet iterates in sorted order, so no need for explicit sorting
        for id in &self.loaded_regions {
            hasher.update(&id.get().to_le_bytes());
        }
        // Include time state
        if let Ok(time_bytes) = to_vec(&self.time) {
            hasher.update(&time_bytes);
        }
        // Include RNG state
        if let Ok(rng_bytes) = to_vec(&self.rng) {
            hasher.update(&rng_bytes);
        }
        // Include system snapshots (which capture RNG-dependent state from systems)
        for (i, system) in self.systems.iter().enumerate() {
            if let Some(snapshot) = system.snapshot() {
                #[cfg(debug_assertions)]
                tracing::trace!(system = system.name(), index = i, len = snapshot.len());
                hasher.update(&snapshot);
            }
        }
        *hasher.finalize().as_bytes()
    }

    /// Apply a command to the runtime.
    pub fn apply(&mut self, cmd: &RuntimeCommand) -> Result<Vec<RuntimeEvent>, RuntimeError> {
        let mut events = Vec::new();

        match cmd {
            RuntimeCommand::Tick { dt_micros } => {
                let dt_seconds = *dt_micros as f32 / 1_000_000.0;
                crate::time::tick_time(&mut self.time, dt_seconds);
                crate::weather::tick_weather(&mut self.weather, dt_seconds);
                
                // Sync weather state to world_runtime for system access
                self.world_runtime.weather.temperature = self.weather.temperature;
                self.world_runtime.weather.humidity = self.weather.humidity;
                self.world_runtime.weather.pressure = self.weather.pressure;
                self.world_runtime.weather.wind_speed = self.weather.wind_speed;
                self.world_runtime.weather.accumulated_precipitation = self.weather.accumulated_precipitation;
                
                // Create simulation context and run all registered systems
                let tick = self.time.seconds_since_start.floor() as u64;
                let mut ctx = SimContext::new(
                    tick,
                    *dt_micros,
                    &mut self.rng,
                    &mut self.world_runtime,
                    &self.world_env,
                    &self.events_in,
                    &mut self.events_out,
                );
                
                // Run each system and collect errors
                for system in &mut self.systems {
                    if let Err(e) = system.tick(&mut ctx) {
                        events.push(RuntimeEvent::SystemError {
                            system_name: system.name(),
                            error: e,
                        });
                    }
                }
                
                // Swap event buffers for next tick
                self.events_in = std::mem::take(&mut self.events_out);
                
                events.push(RuntimeEvent::TickCompleted { tick });
            }
            RuntimeCommand::LoadRegion { id } => {
                self.loaded_regions.insert(*id);
            }
            RuntimeCommand::UnloadRegion { id } => {
                self.loaded_regions.remove(id);
            }
        }

        Ok(events)
    }

    /// Create a snapshot of the runtime state as bytes.
    pub fn snapshot(&self) -> Result<Vec<u8>, RuntimeError> {
        use crate::snapshot::format::SaveFile;
        use glam::Vec3;

        let save = SaveFile::from_runtime(self, Vec3::ZERO);
        save.save().map_err(RuntimeError::Snapshot)
    }

    /// Restore runtime state from snapshot bytes and a world.
    pub fn restore_with_world(bytes: &[u8], world: WorldAuthored) -> Result<Self, RuntimeError> {
        use crate::snapshot::format::{SaveError, SaveFile};

        let save: SaveFile = serde_json::from_slice(bytes)
            .map_err(|e| RuntimeError::Snapshot(SaveError::Deserialization(e)))?;

        // Verify world hash matches
        if save.world_hash != world.metadata.source_hash {
            return Err(RuntimeError::General(format!(
                "World hash mismatch: save has {}, world has {}",
                save.world_hash, world.metadata.source_hash
            )));
        }

        // Restore systems from snapshots
        // Create runtime with all systems registered
        let mut runtime = Self {
            time: save.time,
            weather: save.weather,
            world: world.clone(),
            loaded_regions: save.loaded_regions.into_iter().collect(),
            systems: Vec::new(),
            world_runtime: WorldRuntime::new(world),
            world_env: WorldEnv::default(),
            rng: save.rng,
            events_in: Vec::new(),
            events_out: Vec::new(),
        };

        // Restore systems from snapshots - only restore systems that were in the original snapshot
        // Register systems in a deterministic order for consistency
        let system_names = ["npc_system", "catastrophe_system", "joy_system", "PhysicsSystem"];
        
        for name in system_names.iter() {
            if let Some(bytes) = save.system_snapshots.get(*name) {
                // Find the system by name and restore it
                // For now, we create new systems and restore their state
                match *name {
                    "npc_system" => {
                        let mut system = anvil_sim::NpcSystem::new();
                        if let Err(e) = system.restore(bytes) {
                            tracing::warn!(system = name, "Failed to restore system: {}", e);
                        }
                        runtime.register_system(Box::new(system));
                    }
                    "catastrophe_system" => {
                        let mut system = anvil_sim::CatastropheSystem::new();
                        if let Err(e) = system.restore(bytes) {
                            tracing::warn!(system = name, "Failed to restore system: {}", e);
                        }
                        runtime.register_system(Box::new(system));
                    }
                    "joy_system" => {
                        let mut system = anvil_sim::JoySystem::new();
                        if let Err(e) = system.restore(bytes) {
                            tracing::warn!(system = name, "Failed to restore system: {}", e);
                        }
                        runtime.register_system(Box::new(system));
                    }
                    "PhysicsSystem" => {
                        let mut system = anvil_sim::PhysicsSystem::new();
                        if let Err(e) = system.restore(bytes) {
                            tracing::warn!(system = name, "Failed to restore system: {}", e);
                        }
                        runtime.register_system(Box::new(system));
                    }
                    _ => {}
                }
            }
            // If no snapshot exists for this system, don't create it - the original didn't have it either
        }

        Ok(runtime)
    }

    /// Validate the runtime state.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = ValidationErrors::new();
        errors.extend(self.time.validate());
        errors.extend(self.weather.validate());
        if let Some(physics) = self.physics_system() {
            errors.extend(physics.validate());
        }
        errors
    }

    /// Returns a reference to the NPC system, if registered.
    pub fn npc_system(&self) -> Option<&NpcSystem> {
        self.systems
            .iter()
            .find_map(|s| s.as_any().downcast_ref::<NpcSystem>())
    }

    /// Returns a reference to the catastrophe system, if registered.
    pub fn catastrophe_system(&self) -> Option<&CatastropheSystem> {
        self.systems
            .iter()
            .find_map(|s| s.as_any().downcast_ref::<CatastropheSystem>())
    }

    /// Returns a reference to the joy system, if registered.
    pub fn joy_system(&self) -> Option<&JoySystem> {
        self.systems
            .iter()
            .find_map(|s| s.as_any().downcast_ref::<JoySystem>())
    }

    /// Returns a reference to the physics system, if registered.
    pub fn physics_system(&self) -> Option<&PhysicsSystem> {
        self.systems
            .iter()
            .find_map(|s| s.as_any().downcast_ref::<PhysicsSystem>())
    }

    /// Returns a mutable reference to the NPC system, if registered.
    pub fn npc_system_mut(&mut self) -> Option<&mut NpcSystem> {
        self.systems
            .iter_mut()
            .find_map(|s| s.as_any_mut().downcast_mut::<NpcSystem>())
    }

    /// Returns a mutable reference to the catastrophe system, if registered.
    pub fn catastrophe_system_mut(&mut self) -> Option<&mut CatastropheSystem> {
        self.systems
            .iter_mut()
            .find_map(|s| s.as_any_mut().downcast_mut::<CatastropheSystem>())
    }

    /// Returns a mutable reference to the joy system, if registered.
    pub fn joy_system_mut(&mut self) -> Option<&mut JoySystem> {
        self.systems
            .iter_mut()
            .find_map(|s| s.as_any_mut().downcast_mut::<JoySystem>())
    }

    /// Returns a mutable reference to the physics system, if registered.
    pub fn physics_system_mut(&mut self) -> Option<&mut PhysicsSystem> {
        self.systems
            .iter_mut()
            .find_map(|s| s.as_any_mut().downcast_mut::<PhysicsSystem>())
    }
}

impl RuntimeState for Runtime {
    fn apply(&mut self, cmd: &RuntimeCommand) -> Result<Vec<RuntimeEvent>, RuntimeError> {
        Runtime::apply(self, cmd)
    }

    fn validate(&self) -> ValidationErrors {
        Runtime::validate(self)
    }
}

/// A command that drives the runtime forward by one or more ticks.
#[derive(Debug, Clone)]
#[non_exhaustive]
pub enum RuntimeCommand {
    /// Advance simulation by the specified time delta.
    Tick {
        /// Delta time in microseconds.
        dt_micros: u64
    },
    /// Load a region into the runtime.
    LoadRegion {
        /// The region ID to load.
        id: anvil_core::RegionId
    },
    /// Unload a region from the runtime.
    UnloadRegion {
        /// The region ID to unload.
        id: anvil_core::RegionId
    },
}

/// An event produced by the runtime in response to a command.
#[derive(Debug, Clone)]
#[non_exhaustive]
pub enum RuntimeEvent {
    /// A tick was completed successfully.
    TickCompleted {
        /// The tick number that was completed.
        tick: u64
    },
    /// A simulation system encountered an error during the tick.
    SystemError {
        /// The name of the system that produced the error.
        system_name: &'static str,
        /// The error that occurred.
        error: anvil_sim::SimError
    },
}

/// Errors the runtime can produce.
#[derive(Debug, thiserror::Error)]
pub enum RuntimeError {
    /// Failed to create or parse a snapshot.
    #[error("snapshot error: {0}")]
    Snapshot(#[from] crate::snapshot::SaveError),
    /// Failed to restore physics system state from snapshot.
    #[error("physics restore error: {0}")]
    PhysicsRestore(String),
    /// Failed to restore a simulation system from snapshot.
    #[error("system restore failed: system={system}, error={source}")]
    SystemRestore {
        /// The name of the system that failed to restore.
        system: String,
        /// The underlying error.
        source: SimError,
    },
    /// World hash mismatch between save file and provided world.
    #[error("world hash mismatch: save has {save_hash}, world has {world_hash}")]
    WorldHashMismatch {
        /// The hash of the save file.
        save_hash: String,
        /// The hash of the world.
        world_hash: String,
    },
    /// General runtime error not covered by other variants.
    #[error("runtime error: {0}")]
    General(String),
}

/// The RuntimeState trait defines the contract for a tick‑driven state.
pub trait RuntimeState: Send + Sync {
    /// Apply a command to the runtime state.
    fn apply(&mut self, cmd: &RuntimeCommand) -> Result<Vec<RuntimeEvent>, RuntimeError>;
    /// Validate the current state, returning all validation errors found.
    fn validate(&self) -> ValidationErrors;
}
