// Source: forge_sim/src/region.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use anvil_core::{ConnectionId, RegionId};
use anvil_world::WorldAuthored;
use glam::Vec3;

/// Resolve a region transition based on the current region, position, and connection.
/// Returns the new region ID if a valid transition is detected, or None if no transition should occur.
pub fn resolve_region_transition(
    current_region: Option<RegionId>,
    position: Vec3,
    world: &WorldAuthored,
    connection_id: Option<ConnectionId>,
) -> Option<RegionId> {
    // If no current region, try to find one for the position
    let Some(current) = current_region else {
        return current_region_for_position(world, position);
    };

    // If there's a specific connection to check, use it
    if let Some(conn_id) = connection_id {
        // Find the connection
        let conn = world.connections.iter().find(|c| c.id == conn_id);
        if let Some(conn) = conn {
            // Check if this connection links from the current region
            if conn.from_region == current {
                return Some(conn.to_region);
            } else if conn.to_region == current {
                return Some(conn.from_region);
            }
        }
        return None;
    }

    // Otherwise, find region by position
    let detected = current_region_for_position(world, position)?;

    if detected == current {
        return None;
    }

    // Check if there's a connection between current and detected regions
    let has_connection = world.connections.iter().any(|conn| {
        (conn.from_region == current && conn.to_region == detected)
            || (conn.from_region == detected && conn.to_region == current)
    });

    if has_connection {
        Some(detected)
    } else {
        None
    }
}

/// Get the current region for a given position.
/// Returns the first region if no spatial data is available (placeholder).
pub fn current_region_for_position(
    world: &WorldAuthored,
    _position: Vec3,
) -> Option<RegionId> {
    // Anvil regions don't have spatial bounds yet
    // This is a placeholder for future spatial indexing
    world.regions.first().map(|r| r.id)
}

/// Find a region by entity ID - returns the region the entity belongs to.
pub fn region_for_entity(
    world: &WorldAuthored,
    entity_id: anvil_core::AuthoredEntityId,
) -> Option<RegionId> {
    world
        .entities
        .iter()
        .find(|e| e.id == entity_id)
        .map(|e| e.region)
}

/// Get all regions in the world.
pub fn all_regions(world: &WorldAuthored) -> impl Iterator<Item = &anvil_world::types::Region> {
    world.regions.iter()
}

/// Find a region by its ID.
pub fn find_region(
    world: &WorldAuthored,
    region_id: RegionId,
) -> Option<&anvil_world::types::Region> {
    world.regions.iter().find(|r| r.id == region_id)
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_core::{AuthoredEntityId, Directionality, EntityKind};
    use anvil_world::types::{AssetReferenceTable, AuthoredConnection, AuthoredEntity, Region, WorldMetadata};

    fn sample_world() -> WorldAuthored {
        WorldAuthored {
            regions: vec![
                Region {
                    id: RegionId::new(0),
                    name: "First Region".to_string(),
                    terrain_type: anvil_core::TerrainType::Highlands,
                    mood: "calm".to_string(),
                    style: anvil_core::StyleHints {
                        palette: vec![],
                        density: "medium".to_string(),
                        atmosphere: "clear".to_string(),
                    },
                },
                Region {
                    id: RegionId::new(1),
                    name: "Second Region".to_string(),
                    terrain_type: anvil_core::TerrainType::Forest,
                    mood: "mysterious".to_string(),
                    style: anvil_core::StyleHints {
                        palette: vec![],
                        density: "medium".to_string(),
                        atmosphere: "clear".to_string(),
                    },
                },
            ],
            entities: vec![
                AuthoredEntity {
                    id: AuthoredEntityId::new(1),
                    name: "Entity 1".to_string(),
                    kind: EntityKind::Landmark,
                    region: RegionId::new(0),
                    archetype: anvil_core::arche!("test_archetype"),
                    description: "Test entity".to_string(),
                },
            ],
            connections: vec![
                AuthoredConnection {
                    id: ConnectionId::new(0),
                    name: "Connection 1".to_string(),
                    from_region: RegionId::new(0),
                    to_region: RegionId::new(1),
                    kind: anvil_core::ConnectionKind::Path,
                    directionality: Directionality::Bidirectional,
                    entity_id: AuthoredEntityId::new(1),
                },
            ],
            history_events: std::sync::Arc::new(vec![]),
            asset_refs: AssetReferenceTable { entries: vec![] },
            metadata: WorldMetadata {
                source_hash: "test".to_string(),
                compiler_version: "0.1.0".to_string(),
                history_events_digest: "".to_string(),
            },
            entity_index: std::collections::HashMap::new(),
            connection_index: std::collections::HashMap::new(),
            asset_ref_index: std::collections::HashMap::new(),
        }
    }

    #[test]
    fn find_region_returns_correct_region() {
        let world = sample_world();
        let region = find_region(&world, RegionId::new(0));
        assert!(region.is_some());
        assert_eq!(region.unwrap().id, RegionId::new(0));
    }

    #[test]
    fn find_region_returns_none_for_missing() {
        let world = sample_world();
        let region = find_region(&world, RegionId::new(999));
        assert!(region.is_none());
    }

    #[test]
    fn region_for_entity_returns_entity_region() {
        let world = sample_world();
        let region = region_for_entity(&world, AuthoredEntityId::new(1));
        assert_eq!(region, Some(RegionId::new(0)));
    }

    #[test]
    fn resolve_region_transition_follows_connection() {
        let world = sample_world();
        let transition = resolve_region_transition(
            Some(RegionId::new(0)),
            Vec3::new(0.0, 0.0, 0.0),
            &world,
            Some(ConnectionId::new(0)),
        );
        assert_eq!(transition, Some(RegionId::new(1)));
    }

    #[test]
    fn resolve_region_transition_returns_none_without_connection() {
        let world = sample_world();
        let transition = resolve_region_transition(
            Some(RegionId::new(0)),
            Vec3::new(0.0, 0.0, 0.0),
            &world,
            Some(ConnectionId::new(999)),
        );
        assert_eq!(transition, None);
    }

    #[test]
    fn all_regions_returns_all_regions() {
        let world = sample_world();
        let regions: Vec<_> = all_regions(&world).collect();
        assert_eq!(regions.len(), 2);
    }

    #[test]
    fn current_region_for_position_returns_first_region() {
        let world = sample_world();
        let region = current_region_for_position(&world, Vec3::new(100.0, 0.0, 100.0));
        assert_eq!(region, Some(RegionId::new(0)));
    }

    #[test]
    fn resolve_region_transition_with_no_current_region() {
        let world = sample_world();
        let transition = resolve_region_transition(
            None,
            Vec3::new(0.0, 0.0, 0.0),
            &world,
            None,
        );
        assert_eq!(transition, Some(RegionId::new(0)));
    }
}
