// Source: forge_sim/src/trace.rs as of the Forge snapshot.

//! Deterministic progression trace recorder.
//!
//! **Only compiled when the `progression_trace` feature is enabled.**
//! Traces are never serialized into save files — they live in a
//! thread-local in-memory buffer and are only accessible within the
//! process that recorded them.
//!
//! # Usage
//!
//! ```rust,no_run
//! # #[cfg(feature = "progression_trace")]
//! # {
//! use anvil_runtime::trace::{record, drain_trace, TraceEntry};
//!
//! // Record an event (called from transition sites):
//! record(TraceEntry::submission("entity_1", "fire", true));
//!
//! // Drain the trace buffer (e.g. in a test assertion):
//! let entries = drain_trace();
//! assert_eq!(entries[0].kind, "submission");
//! # }
//! ```
//!
//! # Safety contract
//!
//! - `Runtime` is never modified by this module.
//! - The trace buffer is not accessible from non-feature builds (zero-cost).
//! - Do not add `#[serde(skip)]`-gated trace fields to `Runtime` — that path leads to silent data leakage.

use std::cell::RefCell;

/// A single recorded progression transition entry.
#[derive(Debug, Clone, PartialEq)]
pub struct TraceEntry {
    /// A short identifier for the transition type, e.g. `"submission"`,
    /// `"route_follow_up"`, `"region_complete"`.
    pub kind: &'static str,
    /// Human-readable description of the transition.
    pub description: String,
    /// Sequence number within the current trace session (monotonically
    /// increasing, starts at 0). Enables determinism checks.
    pub seq: u64,
}

impl TraceEntry {
    /// Create a trace entry for a survey judgment submission.
    pub fn submission(entity_label: &str, diagnosis: &str, judged_correctly: bool) -> Self {
        Self::new(
            "submission",
            format!(
                "submitted {entity_label} as {diagnosis} (correct={})",
                judged_correctly
            ),
        )
    }

    /// Create a trace entry for a route follow-up activation.
    pub fn route_follow_up(source_label: &str, target_label: &str) -> Self {
        Self::new(
            "route_follow_up",
            format!("route follow-up: {source_label} → {target_label}"),
        )
    }

    /// Create a trace entry for a region completion.
    pub fn region_complete(region_id: u32, correct: usize, total: usize) -> Self {
        Self::new(
            "region_complete",
            format!("region {region_id} complete: {correct}/{total} correct"),
        )
    }

    /// Create a trace entry for an expedition completion.
    pub fn expedition_complete(total_regions: usize, total_landmarks: usize) -> Self {
        Self::new(
            "expedition_complete",
            format!("expedition complete: {total_regions} regions, {total_landmarks} landmarks"),
        )
    }

    fn new(kind: &'static str, description: String) -> Self {
        Self {
            kind,
            description,
            seq: next_seq(),
        }
    }
}

// ── Thread-local buffer ───────────────────────────────────────────────────────

thread_local! {
    static TRACE_BUFFER: RefCell<Vec<TraceEntry>> = const { RefCell::new(Vec::new()) };
    static SEQ_COUNTER: RefCell<u64> = const { RefCell::new(0) };
}

fn next_seq() -> u64 {
    SEQ_COUNTER.with(|c| {
        let seq = *c.borrow();
        *c.borrow_mut() = seq + 1;
        seq
    })
}

/// Record a single trace entry into the current thread's buffer.
///
/// No-ops when `progression_trace` feature is disabled (the entire
/// module is not compiled).
pub fn record(entry: TraceEntry) {
    TRACE_BUFFER.with(|buf| buf.borrow_mut().push(entry));
}

/// Drain all entries from the current thread's trace buffer and return them.
///
/// After this call the buffer is empty. Useful in tests to assert
/// the exact sequence of transitions.
pub fn drain_trace() -> Vec<TraceEntry> {
    TRACE_BUFFER.with(|buf| buf.borrow_mut().drain(..).collect())
}

/// Peek at the current trace without draining it.
///
/// Returns a snapshot clone of the buffer.
pub fn snapshot_trace() -> Vec<TraceEntry> {
    TRACE_BUFFER.with(|buf| buf.borrow().clone())
}

/// Clear the trace buffer without returning entries.
pub fn clear_trace() {
    TRACE_BUFFER.with(|buf| buf.borrow_mut().clear());
    SEQ_COUNTER.with(|c| *c.borrow_mut() = 0);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trace_record_and_drain_are_fifo() {
        clear_trace();
        record(TraceEntry::submission("e1", "fire", true));
        record(TraceEntry::route_follow_up("e1", "e2"));
        record(TraceEntry::region_complete(0, 2, 2));

        let entries = drain_trace();
        assert_eq!(entries.len(), 3);
        assert_eq!(entries[0].kind, "submission");
        assert_eq!(entries[1].kind, "route_follow_up");
        assert_eq!(entries[2].kind, "region_complete");
    }

    #[test]
    fn drain_clears_buffer() {
        clear_trace();
        record(TraceEntry::expedition_complete(3, 12));
        let _ = drain_trace();
        let after = drain_trace();
        assert!(after.is_empty(), "drain should empty the buffer");
    }

    #[test]
    fn seq_numbers_are_monotonically_increasing() {
        clear_trace();
        record(TraceEntry::submission("e1", "flood", false));
        record(TraceEntry::submission("e2", "stable", true));
        let entries = drain_trace();
        assert!(entries[0].seq < entries[1].seq);
    }

    #[test]
    fn snapshot_does_not_drain() {
        clear_trace();
        record(TraceEntry::region_complete(1, 3, 3));
        let snap = snapshot_trace();
        let second = snapshot_trace();
        assert_eq!(snap.len(), 1);
        assert_eq!(second.len(), 1, "snapshot must not drain");
        let _ = drain_trace();
    }

    #[test]
    fn clear_resets_seq_counter() {
        clear_trace();
        record(TraceEntry::submission("e1", "fire", true));
        clear_trace();
        record(TraceEntry::submission("e2", "fire", true));
        let entries = drain_trace();
        assert_eq!(entries[0].seq, 0);
    }
}
