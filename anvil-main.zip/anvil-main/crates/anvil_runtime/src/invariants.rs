// Source: forge_sim/src/invariants.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use anvil_core::{ValidationErrors, push_validation_error, FailureClass};
use std::fmt;

/// A single invariant failure detected during runtime validation.
#[derive(Debug, Clone, PartialEq)]
pub struct InvariantFailure {
    /// A short identifier for the failure type.
    pub kind: &'static str,
    /// Human-readable description of the failure.
    pub message: String,
}

impl fmt::Display for InvariantFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.kind, self.message)
    }
}

/// Validate runtime invariants and return a vector of failures.
/// An empty vector means all invariants passed.
pub fn validate_runtime_invariants(runtime: &crate::Runtime) -> Vec<InvariantFailure> {
    let mut failures = Vec::new();

    // Validate time invariants
    if !runtime.time.seconds_since_start.is_finite() {
        failures.push(InvariantFailure {
            kind: "time_invalid",
            message: format!("seconds_since_start is not finite: {}", runtime.time.seconds_since_start),
        });
    }

    if runtime.time.day_length_seconds < 0.0 {
        failures.push(InvariantFailure {
            kind: "time_invalid",
            message: format!("day_length_seconds is negative: {}", runtime.time.day_length_seconds),
        });
    }

    // Validate weather invariants
    if !runtime.weather.temperature.is_finite() {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("temperature is not finite: {}", runtime.weather.temperature),
        });
    }

    if !runtime.weather.humidity.is_finite() || runtime.weather.humidity < 0.0 || runtime.weather.humidity > 1.0 {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("humidity out of range [0, 1]: {}", runtime.weather.humidity),
        });
    }

    if !runtime.weather.pressure.is_finite() {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("pressure is not finite: {}", runtime.weather.pressure),
        });
    }

    if !runtime.weather.wind_speed.is_finite() || runtime.weather.wind_speed < 0.0 {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("wind_speed is negative or not finite: {}", runtime.weather.wind_speed),
        });
    }

    if !runtime.weather.wind_direction.is_finite() {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("wind_direction is not finite: {}", runtime.weather.wind_direction),
        });
    }

    if !runtime.weather.accumulated_precipitation.is_finite() 
        || runtime.weather.accumulated_precipitation < 0.0 {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("accumulated_precipitation is negative or not finite: {}", 
                runtime.weather.accumulated_precipitation),
        });
    }

    if runtime.weather.transition_progress < 0.0 || runtime.weather.transition_progress > 1.0 {
        failures.push(InvariantFailure {
            kind: "weather_invalid",
            message: format!("transition_progress out of range [0, 1]: {}", 
                runtime.weather.transition_progress),
        });
    }

    failures
}

/// Convert invariant failures to ValidationErrors for compatibility with anvil_core.
pub fn invariant_failures_to_validation_errors(failures: Vec<InvariantFailure>) -> ValidationErrors {
    let mut errors = anvil_core::ValidationErrors::new();
    for failure in failures {
        push_validation_error!(
            errors,
            FailureClass::Semantic,
            "E190",
            "Runtime",
            failure.kind,
            failure.message.clone(),
            &failure.message
        );
    }
    errors
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_core::RegionId;
    use anvil_world::types::{AssetReferenceTable, Region, WorldMetadata};

    fn sample_world() -> anvil_world::WorldAuthored {
        anvil_world::WorldAuthored {
            regions: vec![Region {
                id: RegionId::new(0),
                name: "Test Region".to_string(),
                terrain_type: anvil_core::TerrainType::Highlands,
                mood: "calm".to_string(),
                style: anvil_core::StyleHints {
                    palette: vec![],
                    density: "medium".to_string(),
                    atmosphere: "clear".to_string(),
                },
            }],
            entities: vec![],
            connections: vec![],
            history_events: std::sync::Arc::new(vec![]),
            asset_refs: AssetReferenceTable { entries: vec![] },
            metadata: WorldMetadata {
                source_hash: "test".to_string(),
                compiler_version: "0.1.0".to_string(),
                history_events_digest: "".to_string(),
            },
            entity_index: std::collections::HashMap::new(),
            connection_index: std::collections::HashMap::new(),
            asset_ref_index: std::collections::HashMap::new(),
        }
    }

    #[test]
    fn valid_runtime_passes_all_invariants() {
        let runtime = crate::Runtime::new(sample_world());
        let failures = validate_runtime_invariants(&runtime);
        assert!(failures.is_empty(), "Expected no failures for valid runtime");
    }

    #[test]
    fn invalid_time_seconds_detected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.time.seconds_since_start = f32::NAN;
        let failures = validate_runtime_invariants(&runtime);
        assert_eq!(failures.len(), 1);
        assert_eq!(failures[0].kind, "time_invalid");
    }

    #[test]
    fn negative_day_length_detected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.time.day_length_seconds = -10.0;
        let failures = validate_runtime_invariants(&runtime);
        assert_eq!(failures.len(), 1);
        assert_eq!(failures[0].kind, "time_invalid");
    }

    #[test]
    fn humidity_out_of_range_detected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.weather.humidity = 1.5;
        let failures = validate_runtime_invariants(&runtime);
        assert!(!failures.is_empty());
        let kinds: Vec<_> = failures.iter().map(|f| f.kind).collect();
        assert!(kinds.contains(&"weather_invalid"));
    }

    #[test]
    fn negative_wind_speed_detected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.weather.wind_speed = -1.0;
        let failures = validate_runtime_invariants(&runtime);
        assert!(!failures.is_empty());
        let kinds: Vec<_> = failures.iter().map(|f| f.kind).collect();
        assert!(kinds.contains(&"weather_invalid"));
    }

    #[test]
    fn transition_progress_out_of_range_detected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.weather.transition_progress = 1.5;
        let failures = validate_runtime_invariants(&runtime);
        assert!(!failures.is_empty());
        let kinds: Vec<_> = failures.iter().map(|f| f.kind).collect();
        assert!(kinds.contains(&"weather_invalid"));
    }

    #[test]
    fn multiple_failures_collected() {
        let mut runtime = crate::Runtime::new(sample_world());
        runtime.time.seconds_since_start = f32::NAN;
        runtime.weather.humidity = 1.5;
        runtime.weather.wind_speed = -1.0;
        let failures = validate_runtime_invariants(&runtime);
        assert!(failures.len() >= 2, "Expected at least 2 failures");
    }
}
