// Source: forge_sim/src/save.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use super::format::{SaveFile, SaveHistoryIntegrityReport};
use anvil_world::WorldAuthored;

/// Inspect the integrity of a save file's history.
///
/// Compares the save's history-events digest against the recomputed digest
/// to ensure internal consistency.
pub fn inspect_save_history_integrity(save: &SaveFile) -> SaveHistoryIntegrityReport {
    use anvil_world::hashing::history_events_digest;

    let recomputed_digest = history_events_digest(&save.history_events);
    let internally_consistent = save.history_events_digest == recomputed_digest;

    SaveHistoryIntegrityReport {
        format_version: save.format_version,
        history_event_count: save.history_events.len(),
        stored_history_events_digest: save.history_events_digest.clone(),
        recomputed_history_events_digest: recomputed_digest,
        internally_consistent,
    }
}

/// Validate that a save file is compatible with its authored world.
///
/// Returns Ok(()) if the save is valid for this world, or a SaveError describing
/// the mismatch.
pub fn validate_save_against_world(
    save: &SaveFile,
    world: &WorldAuthored,
) -> Result<(), super::format::SaveError> {
    use super::format::SaveError;

    // Check world hash match
    if save.world_hash != world.metadata.source_hash {
        return Err(SaveError::WorldHashMismatch {
            save: save.world_hash.clone(),
            current: world.metadata.source_hash.clone(),
        });
    }

    // Check history events digest
    let report = inspect_save_history_integrity(save);
    if !report.internally_consistent {
        return Err(SaveError::HistoryEventsInternalCorruption {
            stored: save.history_events_digest.clone(),
            recomputed: report.recomputed_history_events_digest,
        });
    }

    // Check against authored world's history digest
    if report.recomputed_history_events_digest != world.metadata.history_events_digest {
        return Err(SaveError::HistoryEventsDigestMismatch {
            save: report.recomputed_history_events_digest,
            current: world.metadata.history_events_digest.clone(),
        });
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_core::HistoryEvent;

    fn sample_world() -> WorldAuthored {
        use anvil_core::{DamageType, RegionId};
        use anvil_world::types::{AssetReferenceTable, Region, WorldMetadata};
        use anvil_world::hashing::history_events_digest;

        let events = vec![HistoryEvent {
            damage_type: DamageType::Earthquake,
            magnitude: 0.5,
            epicenter: [0.0, 0.0, 0.0],
            radius: 10.0,
            tick: 0,
        }];
        let digest = history_events_digest(&events);

        WorldAuthored {
            regions: vec![Region {
                id: RegionId::new(0),
                name: "Test Region".to_string(),
                terrain_type: anvil_core::TerrainType::Highlands,
                mood: "calm".to_string(),
                style: anvil_core::StyleHints {
                    palette: vec![],
                    density: "medium".to_string(),
                    atmosphere: "clear".to_string(),
                },
            }],
            entities: vec![],
            connections: vec![],
            history_events: std::sync::Arc::new(events),
            asset_refs: AssetReferenceTable { entries: vec![] },
            metadata: WorldMetadata {
                source_hash: "test_hash".to_string(),
                compiler_version: "0.1.0".to_string(),
                history_events_digest: digest,
            },
            entity_index: std::collections::HashMap::new(),
            connection_index: std::collections::HashMap::new(),
            asset_ref_index: std::collections::HashMap::new(),
        }
    }

    #[test]
    fn integrity_report_detects_corruption() {
        let world = sample_world();
        let runtime = crate::Runtime::new(world);
        let mut save = SaveFile::from_runtime(&runtime, glam::Vec3::ZERO);

        // Corrupt the digest
        save.history_events_digest = "corrupted".to_string();

        let report = inspect_save_history_integrity(&save);
        // The save's internal consistency should fail
        assert!(!report.internally_consistent);
    }

    #[test]
    fn validate_save_against_world_ok() {
        let world = sample_world();
        let runtime = crate::Runtime::new(world.clone());
        let save = SaveFile::from_runtime(&runtime, glam::Vec3::ZERO);

        let result = validate_save_against_world(&save, &world);
        assert!(result.is_ok());
    }

    #[test]
    fn validate_save_against_world_hash_mismatch() {
        use crate::snapshot::format::SaveError;

        let world = sample_world();
        let runtime = crate::Runtime::new(world.clone());
        let mut save = SaveFile::from_runtime(&runtime, glam::Vec3::ZERO);

        // Corrupt the world hash
        save.world_hash = "wrong_hash".to_string();

        let result = validate_save_against_world(&save, &world);
        assert!(matches!(result, Err(SaveError::WorldHashMismatch { .. })));
    }
}
