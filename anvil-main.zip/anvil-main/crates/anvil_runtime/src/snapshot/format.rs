// Source: forge_sim/src/save.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use std::collections::BTreeMap;

use anvil_core::RegionId;
use anvil_sim::DeterministicRng;
use glam::Vec3;
use serde::{Deserialize, Serialize};
use thiserror::Error;

/// Current save format version for Anvil. Starts at v6 (Forge was at v5).
/// v7 adds physics state from anvil_sim.
/// v8 adds system-keyed snapshots for all simulation systems.
/// v9 adds RNG state serialization.
pub const SAVE_FORMAT_VERSION: u32 = 9;
/// The previous stable format version (v7) for migration.
pub const SAVE_FORMAT_VERSION_V7: u32 = 7;
/// The previous stable format version (v6) for migration.
pub const SAVE_FORMAT_VERSION_V6: u32 = 6;
/// The Forge v5 format version for migration.
pub const SAVE_FORMAT_VERSION_V5: u32 = 5;

/// Report on the integrity of save file history events.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SaveHistoryIntegrityReport {
    /// Format version of the save file.
    pub format_version: u32,
    /// Number of history events in the save.
    pub history_event_count: usize,
    /// The stored history events digest from the save file.
    pub stored_history_events_digest: String,
    /// The recomputed history events digest.
    pub recomputed_history_events_digest: String,
    /// Whether the save's history is internally consistent.
    pub internally_consistent: bool,
}

impl SaveHistoryIntegrityReport {
    /// Generate audit lines for logging/reporting.
    pub fn audit_lines(&self) -> Vec<String> {
        vec![
            format!("  format_version: {}", self.format_version),
            format!("  history_event_count: {}", self.history_event_count),
            format!(
                "  stored_history_events_digest: {}",
                self.stored_history_events_digest
            ),
            format!(
                "  recomputed_history_events_digest: {}",
                self.recomputed_history_events_digest
            ),
            format!(
                "  save_history_internal_consistency: {}",
                if self.internally_consistent {
                    "ok"
                } else {
                    "FAIL"
                }
            ),
        ]
    }
}

/// Raw V5 save file structure (Forge format), used only by the migration layer.
/// Do not use this directly — call `parse_and_upgrade_save` instead.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SaveFileV5 {
    /// The save format version (always 5 for this struct).
    pub format_version: u32,
    /// Hash of the authored world this save belongs to.
    pub world_hash: String,
    /// History events recorded in this save session.
    #[serde(default)]
    pub history_events: Vec<anvil_core::HistoryEvent>,
    /// Digest of history_events computed at save time.
    #[serde(default)]
    pub history_events_digest: String,
    /// The region the player was in when the save was created.
    pub current_region: Option<RegionId>,
    /// The player's position as [x, y, z] when the save was created.
    pub player_position: [f32; 3],
}

impl SaveFileV5 {
    /// Convert player position from array to Vec3.
    pub fn player_position_vec3(&self) -> Vec3 {
        Vec3::new(
            self.player_position[0],
            self.player_position[1],
            self.player_position[2],
        )
    }
}

/// The current save file format for Anvil (v7).
/// Contains all state needed to restore a runtime session.
/// 
/// v7 adds physics state from anvil_sim.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SaveFile {
    /// Save format version.
    pub format_version: u32,
    /// Hash of the authored world this save belongs to.
    pub world_hash: String,
    /// History events recorded in this save session.
    #[serde(default)]
    pub history_events: Vec<anvil_core::HistoryEvent>,
    /// Digest of history_events computed at save time.
    #[serde(default)]
    pub history_events_digest: String,
    /// Time state at save time.
    pub time: crate::time::GameTime,
    /// Weather state at save time.
    pub weather: crate::weather::WeatherSimulation,
    /// Currently loaded regions at save time.
    #[serde(default)]
    pub loaded_regions: Vec<RegionId>,
    /// Current region the player is in.
    pub current_region: Option<RegionId>,
    /// Player position at save time.
    pub player_position: Vec3,
    /// Free-form notes attached at save time. Added in format version 6.
    #[serde(default)]
    pub notes: Option<String>,
    /// System snapshots at save time. Added in format version 8.
    /// Maps system name to its serialized state bytes.
    #[serde(default)]
    pub system_snapshots: BTreeMap<String, Vec<u8>>,
    /// RNG state at save time. Added in format version 9.
    #[serde(default)]
    pub rng: DeterministicRng,
}

impl SaveFile {
    /// Create a new save file from runtime state.
    pub fn from_runtime(runtime: &crate::Runtime, player_position: Vec3) -> Self {
        use anvil_world::hashing::history_events_digest;
        let digest = history_events_digest(&runtime.world.history_events);
        
        // Save all system snapshots
        let mut system_snapshots = BTreeMap::new();
        
        // Collect snapshots from all registered systems
        for system in &runtime.systems {
            if let Some(snapshot) = system.snapshot() {
                system_snapshots.insert(system.name().to_string(), snapshot);
            }
        }
        
        Self {
            format_version: SAVE_FORMAT_VERSION,
            world_hash: runtime.world.metadata.source_hash.clone(),
            history_events: (*runtime.world.history_events).clone(),
            history_events_digest: digest,
            time: runtime.time,
            weather: runtime.weather.clone(),
            loaded_regions: runtime.loaded_regions.iter().cloned().collect(),
            current_region: None,
            player_position,
            notes: None,
            system_snapshots,
            rng: runtime.rng.clone(),
        }
    }

    /// Serialize save file to bytes.
    pub fn save(&self) -> Result<Vec<u8>, SaveError> {
        serde_json::to_vec(self).map_err(SaveError::Serialization)
    }

    /// Serialize save file to bytes with pretty printing for debugging.
    /// This is useful for human inspection but produces larger files.
    #[cfg(debug_assertions)]
    pub fn save_pretty(&self) -> Result<Vec<u8>, SaveError> {
        serde_json::to_vec_pretty(self).map_err(SaveError::Serialization)
    }

    /// Generate a history integrity report for this save file.
    pub fn history_integrity_report(&self) -> SaveHistoryIntegrityReport {
        use anvil_world::hashing::history_events_digest;
        let recomputed_history_events_digest = history_events_digest(&self.history_events);
        let internally_consistent = self.history_events_digest == recomputed_history_events_digest;
        SaveHistoryIntegrityReport {
            format_version: self.format_version,
            history_event_count: self.history_events.len(),
            stored_history_events_digest: self.history_events_digest.clone(),
            recomputed_history_events_digest,
            internally_consistent,
        }
    }
}

/// Errors that can occur during save/load operations.
#[derive(Debug, Error)]
pub enum SaveError {
    /// Failed to serialize save data to JSON.
    #[error("failed to serialize save data: {0}")]
    Serialization(serde_json::Error),

    /// Failed to deserialize save data from JSON.
    #[error("failed to deserialize save data: {0}")]
    Deserialization(serde_json::Error),

    /// The save file references a world hash that doesn't match the current world.
    #[error("save references world hash {save:?} which does not match authored world {current:?}")]
    WorldHashMismatch {
        /// The world hash from the save file.
        save: String,
        /// The world hash from the current authored world.
        current: String
    },

    /// The history events digest in the save file doesn't match the computed digest.
    #[error("save data history events digest mismatch: save={save}, current={current}")]
    HistoryEventsDigestMismatch {
        /// The digest stored in the save file.
        save: String,
        /// The digest recomputed from the history events.
        current: String
    },

    /// The save file's history events are internally inconsistent.
    #[error("save file is internally corrupted: stored digest={stored}, recomputed={recomputed}")]
    HistoryEventsInternalCorruption {
        /// The digest stored in the save file.
        stored: String,
        /// The digest recomputed from the history events.
        recomputed: String
    },

    /// The save file format version doesn't match the expected version.
    #[error("save data format version mismatch: save={save}, current={current}")]
    FormatVersionMismatch {
        /// The format version of the save file.
        save: u32,
        /// The current expected format version.
        current: u32
    },
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn save_v6_roundtrip() {
        let world = anvil_world::WorldAuthored::default();
        let runtime = crate::Runtime::new(world);
        let save = SaveFile::from_runtime(&runtime, Vec3::new(1.0, 2.0, 3.0));

        let json = serde_json::to_string(&save).expect("serialize");
        let restored: SaveFile = serde_json::from_str(&json).expect("deserialize");

        assert_eq!(save.format_version, restored.format_version);
        assert_eq!(save.world_hash, restored.world_hash);
        assert_eq!(save.player_position, restored.player_position);
        assert_eq!(SAVE_FORMAT_VERSION, restored.format_version);
    }

    #[test]
    fn history_integrity_report_detects_corruption() {
        let world = anvil_world::WorldAuthored::default();
        let runtime = crate::Runtime::new(world);
        let mut save = SaveFile::from_runtime(&runtime, Vec3::ZERO);

        // Corrupt the digest
        save.history_events_digest = "corrupted".to_string();

        let report = save.history_integrity_report();
        assert!(!report.internally_consistent);
    }

    #[test]
    fn history_integrity_report_ok_when_consistent() {
        let world = anvil_world::WorldAuthored::default();
        let runtime = crate::Runtime::new(world);
        let save = SaveFile::from_runtime(&runtime, Vec3::ZERO);

        let report = save.history_integrity_report();
        assert!(report.internally_consistent);
        assert_eq!(report.format_version, SAVE_FORMAT_VERSION);
    }
}
