// Sources: forge_sim/src/save.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

/// Save file format definitions.
pub mod format;
/// Save file migration and upgrade logic.
pub mod migration;
/// Save file integrity checking.
pub mod integrity;
/// Serialization helpers for save file types.
pub mod serde_helpers;

pub use format::*;
pub use migration::*;
pub use integrity::*;
