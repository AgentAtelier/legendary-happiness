// Source: forge_sim/src/save.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

//! Custom serialization helpers for save file format migrations.
//!
//! This module exists as a placeholder for future migrations that may require
//! custom Serialize/Deserialize implementations. The Forge save.rs did not
//! contain any custom serialization helpers, so this module is currently empty.
//!
//! When adding custom serialization for a new format version:
//! 1. Add the helper function here
//! 2. Update the corresponding struct in format.rs to use it
//! 3. Document the migration in migration.rs

#[cfg(test)]
mod tests {
    #[test]
    fn placeholder_module_compiles() {
        // This test exists to ensure the module compiles correctly.
        // When custom helpers are added, add real tests here.
    }
}
