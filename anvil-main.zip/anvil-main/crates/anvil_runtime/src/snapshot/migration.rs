// Source: forge_sim/src/save.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use std::collections::BTreeMap;

use super::format::{SaveError, SaveFile, SAVE_FORMAT_VERSION, SAVE_FORMAT_VERSION_V6, SAVE_FORMAT_VERSION_V7};
use crate::time::GameTime;
use crate::weather::WeatherSimulation;
use anvil_sim::PhysicsSaveState;

/// Deserialize raw bytes into the current `SaveFile`, automatically upgrading
/// from any supported older format version.
///
/// Supported upgrade paths:
/// - V5 → V6: adds `time`, `weather`, and `notes: None`
/// - V6 → V7: adds `physics: None`
/// - V7 → V8: converts `physics` field to `system_snapshots`
///
/// Returns `SaveError::FormatVersionMismatch` for unsupported versions.
pub fn parse_and_upgrade_save(data: &[u8]) -> Result<SaveFile, SaveError> {
    // Peek at the version without deserializing the full struct.
    let value: serde_json::Value =
        serde_json::from_slice(data).map_err(SaveError::Deserialization)?;

    let version = value
        .get("format_version")
        .and_then(|v| v.as_u64())
        .map(|v| v as u32)
        .unwrap_or(0);

    // Apply progressive upgrades
    let value = if version < SAVE_FORMAT_VERSION {
        let mut value = value;
        if version < SAVE_FORMAT_VERSION_V6 {
            value = upgrade_to_v6(value)?;
        }
        if version < SAVE_FORMAT_VERSION_V7 {
            value = upgrade_to_v7(value)?;
        }
        if version < SAVE_FORMAT_VERSION {
            value = upgrade_to_v8(value)?;
        }
        value
    } else {
        value
    };

    serde_json::from_value(value).map_err(SaveError::Deserialization)
}

/// Upgrade a save from any version < V6 to V6.
fn upgrade_to_v6(value: serde_json::Value) -> Result<serde_json::Value, SaveError> {
    let mut value = value;
    // V5 → V6: add time, weather, notes
    if let Some(obj) = value.as_object_mut() {
        if !obj.contains_key("time") {
            obj.insert("time".to_string(), serde_json::json!(GameTime::default()));
        }
        if !obj.contains_key("weather") {
            obj.insert("weather".to_string(), serde_json::json!(WeatherSimulation::default()));
        }
        if !obj.contains_key("notes") {
            obj.insert("notes".to_string(), serde_json::json!(None::<String>));
        }
        obj.insert("format_version".to_string(), serde_json::json!(SAVE_FORMAT_VERSION_V6));
    }
    Ok(value)
}

/// Upgrade a save from any version < V7 to V7.
fn upgrade_to_v7(value: serde_json::Value) -> Result<serde_json::Value, SaveError> {
    let mut value = upgrade_to_v6(value)?;
    
    // V6 → V7: add physics
    if let Some(obj) = value.as_object_mut() {
        if !obj.contains_key("physics") {
            obj.insert("physics".to_string(), serde_json::json!(Some(PhysicsSaveState::default_with_ground_plane())));
        }
        obj.insert("format_version".to_string(), serde_json::json!(SAVE_FORMAT_VERSION_V7));
    }
    Ok(value)
}

/// Upgrade a save from any version < V8 to V8.
fn upgrade_to_v8(value: serde_json::Value) -> Result<serde_json::Value, SaveError> {
    let mut value = upgrade_to_v7(value)?;
    
    // V7 → V8: convert physics field to system_snapshots
    if let Some(obj) = value.as_object_mut() {
        let mut snapshots = BTreeMap::new();
        
        // Extract physics if present and convert to bytes
        if let Some(serde_json::Value::Object(physics_obj)) = obj.get("physics").cloned() {
            if !physics_obj.is_empty() {
                let bytes = serde_json::to_vec(&serde_json::Value::Object(physics_obj))
                    .map_err(SaveError::Serialization)?;
                snapshots.insert("PhysicsSystem".to_string(), bytes);
            }
        } else if let Some(physics_val) = obj.get("physics").cloned() {
            if !physics_val.is_null() {
                let bytes = serde_json::to_vec(&physics_val)
                    .map_err(SaveError::Serialization)?;
                snapshots.insert("PhysicsSystem".to_string(), bytes);
            }
        }
        
        // Remove old physics field and add system_snapshots
        obj.remove("physics");
        obj.insert("system_snapshots".to_string(), serde_json::json!(snapshots));
        obj.insert("format_version".to_string(), serde_json::json!(SAVE_FORMAT_VERSION));
    }
    Ok(value)
}

#[cfg(test)]
mod tests {
    use super::*;
    use glam::Vec3;

    #[test]
    fn parse_v8_save_directly() {
        let save = SaveFile {
            format_version: SAVE_FORMAT_VERSION,
            world_hash: "test_hash".to_string(),
            history_events: vec![],
            history_events_digest: "test_digest".to_string(),
            time: GameTime::default(),
            weather: WeatherSimulation::default(),
            loaded_regions: vec![],
            current_region: None,
            player_position: Vec3::ZERO,
            notes: None,
            system_snapshots: BTreeMap::new(),
            rng: anvil_sim::DeterministicRng::default(),
        };
        let json = serde_json::to_string(&save).unwrap();
        let result = parse_and_upgrade_save(json.as_bytes()).unwrap();
        assert_eq!(result.format_version, SAVE_FORMAT_VERSION);
    }
}
