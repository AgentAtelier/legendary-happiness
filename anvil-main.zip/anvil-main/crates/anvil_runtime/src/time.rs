// Source: forge_sim/src/time.rs as of the Forge snapshot.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use anvil_core::ValidationErrors;
use serde::{Deserialize, Serialize};

/// Deterministic game time state.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct GameTime {
    /// Total seconds elapsed since the game started.
    pub seconds_since_start: f32,
    /// Duration of a full day-night cycle in seconds.
    pub day_length_seconds: f32,
}

impl Default for GameTime {
    fn default() -> Self {
        Self {
            seconds_since_start: 0.0,
            day_length_seconds: 120.0,
        }
    }
}

impl GameTime {
    /// Returns a normalised phase in [0, 1] representing the progress through
    /// the current day cycle.
    pub fn day_phase(&self) -> f32 {
        if self.day_length_seconds <= 0.0 {
            return 0.0;
        }
        (self.seconds_since_start / self.day_length_seconds).fract()
    }

    /// Validate the game time state.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = ValidationErrors::new();
        if !self.seconds_since_start.is_finite() {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E191",
                "GameTime",
                "seconds_since_start",
                self.seconds_since_start.to_string(),
                "seconds_since_start must be finite"
            );
        }
        if !self.day_length_seconds.is_finite() || self.day_length_seconds <= 0.0 {
            anvil_core::push_validation_error!(
                errors,
                anvil_core::FailureClass::Structural,
                "E192",
                "GameTime",
                "day_length_seconds",
                self.day_length_seconds.to_string(),
                "day_length_seconds must be finite and positive"
            );
        }
        errors
    }
}

/// Advance game time by the given delta (in seconds).
/// Only positive deltas are applied; negative values are ignored.
pub fn tick_time(time: &mut GameTime, dt: f32) {
    if dt > 0.0 {
        time.seconds_since_start += dt;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tick_time_advances_deterministically() {
        let mut time = GameTime::default();
        tick_time(&mut time, 1.5);
        tick_time(&mut time, 2.5);
        assert!((time.seconds_since_start - 4.0).abs() < 0.0001);
    }

    #[test]
    fn day_phase_wraps() {
        let time = GameTime {
            seconds_since_start: 150.0,
            day_length_seconds: 120.0,
        };
        assert!((time.day_phase() - 0.25).abs() < 0.0001);
    }

    #[test]
    fn day_phase_zero_day_length_is_zero() {
        let time = GameTime {
            seconds_since_start: 500.0,
            day_length_seconds: 0.0,
        };
        assert_eq!(time.day_phase(), 0.0);
    }
}
