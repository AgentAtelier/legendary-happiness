//! Stress Tests for Determinism
//!
//! These tests verify that the simulation produces identical results
//! when run with the same seed, across different tick counts and scenarios.

use std::time::Instant;

use anvil_demo_core::{
    ashveil::{create_ashveil_sequencer, AshveilScenario},
    scenario::ScenarioDefinition,
    DEMO_SEED, DEMO_SEED_ALT,
};
use anvil_runtime::{Runtime, RuntimeCommand};

/// Time budget for determinism tests (milliseconds)
const DETERMINISM_TEST_BUDGET_MS: u128 = 5000;

/// Helper to create a runtime with the Ashveil world
fn create_ashveil_runtime() -> Runtime {
    use anvil_sim::settlement::{Settlement, SettlementId, Person, PersonId, FamilyId};
    use anvil_sim::NpcSystem;
    
    let scenario = AshveilScenario;
    let world = scenario.build_world();
    let mut runtime = Runtime::new(world);

    // Load the main region
    let ashveil_valley_id = anvil_core::RegionId::new(0);
    runtime
        .apply(&RuntimeCommand::LoadRegion {
            id: ashveil_valley_id,
        })
        .unwrap();

    // Create and register NpcSystem with minimal data
    let mut npc_system = NpcSystem::new();
    
    // Add a settlement
    let settlement = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Test Settlement".to_string(),
        ashveil_valley_id,
        10,
    );
    npc_system.add_settlement(settlement);
    
    // Add several people to ensure NPC evaluation produces different results
    for i in 1..=5 {
        let person = Person::new_simple(
            PersonId::new(i),
            format!("Test Person {}", i),
            FamilyId::new(1),
        );
        npc_system.add_person(person);
    }
    
    // Register the NpcSystem with the runtime
    runtime.register_system(Box::new(npc_system) as Box<dyn anvil_sim::SimSystem>);

    runtime
}

/// Helper to get state hash for comparison
fn get_state_hash(runtime: &Runtime) -> String {
    let hash = runtime.state_hash();
    hex::encode(hash)
}

// ============================================================================
// 1. Determinism Tests
// ============================================================================

/// Test that running simulation for 100 ticks with same seed produces identical results
#[test]
fn test_deterministic_simulation_100_ticks() {
    let start = Instant::now();

    // Create two identical runtimes with same seed
    let mut runtime_a = create_ashveil_runtime();
    let mut runtime_b = create_ashveil_runtime();

    // Reset both to same seed
    runtime_a.rng.reset(DEMO_SEED);
    runtime_b.rng.reset(DEMO_SEED);

    // Run both for 100 ticks
    let dt_micros = 1_000_000; // 1 second per tick
    for _ in 0..100 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }

    // Compare state hashes
    let hash_a = get_state_hash(&runtime_a);
    let hash_b = get_state_hash(&runtime_b);

    assert_eq!(
        hash_a, hash_b,
        "Simulation with same seed should produce identical state after 100 ticks"
    );

    let duration = start.elapsed();
    tracing::info!(
        "test_deterministic_simulation_100_ticks completed in {:?}",
        duration
    );

    // Performance check
    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that running simulation for 1000 ticks with same seed produces identical results
#[test]
fn test_deterministic_simulation_1000_ticks() {
    let start = Instant::now();

    // Create two identical runtimes with same seed
    let mut runtime_a = create_ashveil_runtime();
    let mut runtime_b = create_ashveil_runtime();

    // Reset both to same seed
    runtime_a.rng.reset(DEMO_SEED);
    runtime_b.rng.reset(DEMO_SEED);

    // Run both for 1000 ticks (use smaller dt for performance)
    let dt_micros = 100_000; // 0.1 second per tick
    for _ in 0..1000 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }

    // Compare state hashes
    let hash_a = get_state_hash(&runtime_a);
    let hash_b = get_state_hash(&runtime_b);

    assert_eq!(
        hash_a, hash_b,
        "Simulation with same seed should produce identical state after 1000 ticks"
    );

    let duration = start.elapsed();
    tracing::info!(
        "test_deterministic_simulation_1000_ticks completed in {:?}",
        duration
    );

    // Performance check (1000 ticks should complete in reasonable time)
    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that snapshot after 500 ticks is identical across runs
#[test]
fn test_deterministic_snapshot_500_ticks() {
    let start = Instant::now();

    // Create runtime and run for 500 ticks
    let mut runtime = create_ashveil_runtime();
    runtime.rng.reset(DEMO_SEED);

    let dt_micros = 100_000;
    for _ in 0..500 {
        runtime.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Take snapshot
    let snapshot_a = runtime.snapshot().expect("Failed to create snapshot");
    let hash_a = hex::encode(runtime.state_hash());

    // Create new runtime, run for 500 ticks with same seed
    let mut runtime2 = create_ashveil_runtime();
    runtime2.rng.reset(DEMO_SEED);

    for _ in 0..500 {
        runtime2.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Take second snapshot
    let snapshot_b = runtime2.snapshot().expect("Failed to create snapshot");
    let hash_b = hex::encode(runtime2.state_hash());

    // Snapshots should be identical
    assert_eq!(
        snapshot_a, snapshot_b,
        "Snapshots from same seed at same tick should be identical"
    );

    // Hashes should match
    assert_eq!(
        hash_a, hash_b,
        "State hashes should match for identical snapshots"
    );

    let duration = start.elapsed();
    tracing::info!(
        "test_deterministic_snapshot_500_ticks completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that different seeds produce different results
#[test]
fn test_deterministic_different_seeds_differ() {
    let start = Instant::now();

    // Run with seed A
    let mut runtime_a = create_ashveil_runtime();
    runtime_a.rng.reset(DEMO_SEED);

    let dt_micros = 100_000;
    for _ in 0..100 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }
    let hash_a = get_state_hash(&runtime_a);

    // Run with seed B
    let mut runtime_b = create_ashveil_runtime();
    runtime_b.rng.reset(DEMO_SEED_ALT);

    for _ in 0..100 {
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }
    let hash_b = get_state_hash(&runtime_b);

    // Hashes should be different
    assert_ne!(
        hash_a, hash_b,
        "Different seeds should produce different states"
    );

    let duration = start.elapsed();
    tracing::info!(
        "test_deterministic_different_seeds_differ completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that simulation state can be restored from snapshot and continues deterministically
#[test]
fn test_deterministic_snapshot_restore() {
    let start = Instant::now();

    // Run for 200 ticks
    let mut runtime = create_ashveil_runtime();
    runtime.rng.reset(DEMO_SEED);

    let dt_micros = 100_000;
    for _ in 0..200 {
        runtime.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    let hash_at_200 = get_state_hash(&runtime);

    // Take snapshot and save
    let snapshot = runtime.snapshot().expect("Failed to create snapshot");
    let world_clone = runtime.world.clone();

    // Restore from snapshot
    let mut restored = Runtime::restore_with_world(&snapshot, world_clone)
        .expect("Failed to restore from snapshot");

    // Hash should match
    let hash_restored = get_state_hash(&restored);
    assert_eq!(
        hash_at_200, hash_restored,
        "Restored runtime should have same hash as original"
    );

    // Continue running for 100 more ticks
    for _ in 0..100 {
        restored.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Run original for 100 more ticks
    for _ in 0..100 {
        runtime.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Hashes should still match
    let hash_original = get_state_hash(&runtime);
    let hash_restored_final = get_state_hash(&restored);
    assert_eq!(
        hash_original, hash_restored_final,
        "Runtime and restored runtime should diverge identically after restoration"
    );

    let duration = start.elapsed();
    tracing::info!(
        "test_deterministic_snapshot_restore completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

// ============================================================================
// 2. Data Comparison Tests
// ============================================================================

/// Test that NPC states are identical across deterministic runs
#[test]
fn test_determinism_npc_states() {
    let start = Instant::now();

    let mut runtime_a = create_ashveil_runtime();
    let mut runtime_b = create_ashveil_runtime();

    runtime_a.rng.reset(DEMO_SEED);
    runtime_b.rng.reset(DEMO_SEED);

    let dt_micros = 100_000;

    // Run for 50 ticks
    for _ in 0..50 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }

    // Compare NPC systems
    let npc_system_a = runtime_a.npc_system().expect("NPC system should exist");
    let npc_system_b = runtime_b.npc_system().expect("NPC system should exist");

    // Same number of persons
    assert_eq!(
        npc_system_a.persons.len(),
        npc_system_b.persons.len(),
        "Should have same number of persons"
    );

    // Same number of settlements
    assert_eq!(
        npc_system_a.settlements.len(),
        npc_system_b.settlements.len(),
        "Should have same number of settlements"
    );

    // Compare person IDs (order matters for determinism)
    for (a, b) in npc_system_a.persons.iter().zip(npc_system_b.persons.iter()) {
        assert_eq!(a.id, b.id, "Person IDs should match in order");
    }

    let duration = start.elapsed();
    tracing::info!("test_determinism_npc_states completed in {:?}", duration);

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that world state (weather, resources) is identical across runs
#[test]
fn test_determinism_world_state() {
    let start = Instant::now();

    let mut runtime_a = create_ashveil_runtime();
    let mut runtime_b = create_ashveil_runtime();

    runtime_a.rng.reset(DEMO_SEED);
    runtime_b.rng.reset(DEMO_SEED);

    let dt_micros = 100_000;

    for _ in 0..50 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }

    // Compare weather state
    assert_eq!(
        runtime_a.weather.temperature, runtime_b.weather.temperature,
        "Temperature should be identical"
    );
    assert_eq!(
        runtime_a.weather.humidity, runtime_b.weather.humidity,
        "Humidity should be identical"
    );
    assert_eq!(
        runtime_a.weather.wind_speed, runtime_b.weather.wind_speed,
        "Wind speed should be identical"
    );

    // Compare time
    assert_eq!(
        runtime_a.time.seconds_since_start, runtime_b.time.seconds_since_start,
        "Time should be identical"
    );

    let duration = start.elapsed();
    tracing::info!("test_determinism_world_state completed in {:?}", duration);

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that sequencer state is deterministic
#[test]
fn test_determinism_sequencer_state() {
    let start = Instant::now();

    let mut sequencer_a = create_ashveil_sequencer();
    let mut sequencer_b = create_ashveil_sequencer();

    // Advance both to same tick
    let ticks = vec![0, 100, 270, 600, 780, 1800, 2400, 2700, 3600];

    for tick in &ticks {
        sequencer_a.advance_to(*tick);
        sequencer_b.advance_to(*tick);

        assert_eq!(
            sequencer_a.current_tick(),
            sequencer_b.current_tick(),
            "Current tick should match at tick {}",
            tick
        );

        // Drain pending beats
        let pending_a = sequencer_a.drain_pending();
        let pending_b = sequencer_b.drain_pending();

        assert_eq!(
            pending_a.len(),
            pending_b.len(),
            "Should have same number of pending beats at tick {}",
            tick
        );
    }

    let duration = start.elapsed();
    tracing::info!(
        "test_determinism_sequencer_state completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < DETERMINISM_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}
