//! Stress Tests for Region Streaming
//!
//! These tests verify that region loading/unloading works correctly
//! with large numbers of regions and rapid transitions.

use std::time::Instant;

use anvil_assets::AssetCatalogue;
use anvil_core::{
    ConnectionKind, ConnectionSpec, Directionality, LandmarkKind, LandmarkSpec, RegionId,
    RegionSpec, StyleHints, TerrainType,
};
use anvil_runtime::{Runtime, RuntimeCommand};
use anvil_world::{compile_world, WorldAuthored};

use anvil_demo_core::{ashveil::world::ashveil_catalogue_entries, DEMO_SEED};

/// Time budget for region streaming tests (milliseconds)
const REGION_STREAMING_TEST_BUDGET_MS: u128 = 10000; // 10 seconds

/// Helper to create a large world with N regions
fn create_large_world(num_regions: usize) -> WorldAuthored {
    let mut regions = Vec::new();
    let mut connections = Vec::new();

    // Create a grid of regions
    let grid_size = ((num_regions as f64).sqrt() as usize).max(1);

    for i in 0..num_regions {
        let _row = i / grid_size;
        let _col = i % grid_size;

        regions.push(RegionSpec {
            name: format!("Region_{}", i),
            terrain_type: TerrainType::Forest,
            mood: "neutral".to_string(),
            landmarks: (0..3).map(|j| LandmarkSpec {
                name: match j % 3 {
                    0 => "settlement_small".to_string(),
                    1 => "standing_stone".to_string(),
                    _ => "tower_ruined".to_string(),
                },
                kind: match j % 3 {
                    0 => LandmarkKind::Settlement,
                    1 => LandmarkKind::Monument,
                    _ => LandmarkKind::Tower,
                },
                description: format!("Landmark {} in region {}", j, i),
            }).collect(),
            style_hints: StyleHints {
                palette: vec!["neutral_grey".to_string()],
                density: "medium".to_string(),
                atmosphere: "clear".to_string(),
            },
        });
    }

    // Create connections in a grid pattern
    for i in 0..num_regions {
        let _row = i / grid_size;
        let _col = i % grid_size;

        // Connect to right neighbor
        if _col < grid_size - 1 {
            let right = i + 1;
            if right < num_regions {
                connections.push(ConnectionSpec {
                    name: format!("Conn_{}_to_{}", i, right),
                    from_region: format!("Region_{}", i),
                    to_region: format!("Region_{}", right),
                    kind: ConnectionKind::Path,
                    directionality: Directionality::Bidirectional,
                });
            }
        }

        // Connect to bottom neighbor
        if _row < grid_size - 1 {
            let bottom = i + grid_size;
            if bottom < num_regions {
                connections.push(ConnectionSpec {
                    name: format!("Conn_{}_to_{}", i, bottom),
                    from_region: format!("Region_{}", i),
                    to_region: format!("Region_{}", bottom),
                    kind: ConnectionKind::Path,
                    directionality: Directionality::Bidirectional,
                });
            }
        }
    }

    // Use Ashveil catalogue which has entries like settlement_small, standing_stone, tower_ruined
    let catalogue = AssetCatalogue::from_entries(ashveil_catalogue_entries().clone());

    compile_world(&regions, &connections, &catalogue).expect("Failed to compile large world")
}

// ============================================================================
// 1. Region Streaming Tests
// ============================================================================

/// Test region streaming with 100 regions
#[test]
fn test_region_streaming_100_regions() {
    let start = Instant::now();

    // Create a world with 100 regions
    let world = create_large_world(100);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    // Initially no regions loaded
    assert_eq!(runtime.loaded_regions.len(), 0);

    // Load first 10 regions
    for i in 0..10 {
        let region_id = RegionId::new(i);
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();
    }

    assert_eq!(runtime.loaded_regions.len(), 10);

    // Simulate NPC moving: unload first 5, load next 5
    for i in 0..5 {
        let region_id = RegionId::new(i);
        runtime
            .apply(&RuntimeCommand::UnloadRegion { id: region_id })
            .unwrap();
    }

    for i in 10..15 {
        let region_id = RegionId::new(i);
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();
    }

    // Should have 10 regions loaded (5 unloaded, 5 loaded)
    assert_eq!(runtime.loaded_regions.len(), 10);

    // Verify correct regions are loaded
    for i in 5..15 {
        let region_id = RegionId::new(i);
        assert!(
            runtime.loaded_regions.contains(&region_id),
            "Region {} should be loaded",
            i
        );
    }

    for i in 0..5 {
        let region_id = RegionId::new(i);
        assert!(
            !runtime.loaded_regions.contains(&region_id),
            "Region {} should be unloaded",
            i
        );
    }

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_100_regions completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test NPC moving rapidly between regions
#[test]
fn test_region_streaming_boundary_crossing() {
    let start = Instant::now();

    // Create a simple world with 2 regions
    let regions = vec![
        RegionSpec {
            name: "Region_0".to_string(),
            terrain_type: TerrainType::Forest,
            mood: "peaceful".to_string(),
            landmarks: vec![],
            style_hints: StyleHints {
                palette: vec![],
                density: "medium".to_string(),
                atmosphere: "clear".to_string(),
            },
        },
        RegionSpec {
            name: "Region_1".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "mountainous".to_string(),
            landmarks: vec![],
            style_hints: StyleHints {
                palette: vec![],
                density: "medium".to_string(),
                atmosphere: "clear".to_string(),
            },
        },
    ];

    let connections = vec![ConnectionSpec {
        name: "Conn_0_1".to_string(),
        from_region: "Region_0".to_string(),
        to_region: "Region_1".to_string(),
        kind: ConnectionKind::Path,
        directionality: Directionality::Bidirectional,
    }];

    let catalogue = anvil_assets::AssetCatalogue::default();
    let world = compile_world(&regions, &connections, &catalogue).expect("Failed to compile world");

    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    // Load first region
    let region_0 = RegionId::new(0);
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: region_0 })
        .unwrap();
    assert_eq!(runtime.loaded_regions.len(), 1);

    // Rapidly switch between regions
    for _ in 0..100 {
        // Unload region 0, load region 1
        runtime
            .apply(&RuntimeCommand::UnloadRegion { id: region_0 })
            .unwrap();
        let region_1 = RegionId::new(1);
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_1 })
            .unwrap();
        assert_eq!(runtime.loaded_regions.len(), 1);
        assert!(runtime.loaded_regions.contains(&region_1));

        // Unload region 1, load region 0
        runtime
            .apply(&RuntimeCommand::UnloadRegion { id: region_1 })
            .unwrap();
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_0 })
            .unwrap();
        assert_eq!(runtime.loaded_regions.len(), 1);
        assert!(runtime.loaded_regions.contains(&region_0));
    }

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_boundary_crossing completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test region streaming stress with 100 regions and 50 NPCs
/// Note: This is a simplified version since we don't have full NPC simulation yet
#[test]
fn test_region_streaming_stress() {
    let start = Instant::now();

    // Create a world with 100 regions
    let world = create_large_world(100);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    // Load all regions
    for i in 0..100 {
        let region_id = RegionId::new(i);
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();
    }

    assert_eq!(runtime.loaded_regions.len(), 100);

    // Tick the simulation 1000 times
    let dt_micros = 10_000; // 0.01 second per tick for speed
    for _ in 0..1000 {
        runtime.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Verify all regions are still loaded
    assert_eq!(runtime.loaded_regions.len(), 100);

    // Unload all regions
    for i in 0..100 {
        let region_id = RegionId::new(i);
        runtime
            .apply(&RuntimeCommand::UnloadRegion { id: region_id })
            .unwrap();
    }

    assert_eq!(runtime.loaded_regions.len(), 0);

    let duration = start.elapsed();
    tracing::info!("test_region_streaming_stress completed in {:?}", duration);

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that loading the same region twice is idempotent
#[test]
fn test_region_streaming_idempotent_load() {
    let start = Instant::now();

    let world = create_large_world(10);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    let region_id = RegionId::new(0);

    // Load region once
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: region_id })
        .unwrap();
    assert_eq!(runtime.loaded_regions.len(), 1);

    // Load same region again
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: region_id })
        .unwrap();
    // Should still be 1 (idempotent)
    assert_eq!(runtime.loaded_regions.len(), 1);

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_idempotent_load completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that unloading a non-loaded region doesn't cause errors
#[test]
fn test_region_streaming_unload_non_loaded() {
    let start = Instant::now();

    let world = create_large_world(10);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    // Try to unload a region that isn't loaded
    let region_id = RegionId::new(5);
    runtime
        .apply(&RuntimeCommand::UnloadRegion { id: region_id })
        .unwrap();

    // Should succeed (no-op)
    assert_eq!(runtime.loaded_regions.len(), 0);

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_unload_non_loaded completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test region streaming with rapid load/unload cycles
#[test]
fn test_region_streaming_rapid_cycles() {
    let start = Instant::now();

    let world = create_large_world(20);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    // Rapidly cycle through all regions
    for cycle in 0..50 {
        let region_id = RegionId::new(cycle % 20);

        // Unload all first
        for i in 0..20 {
            let r = RegionId::new(i);
            runtime
                .apply(&RuntimeCommand::UnloadRegion { id: r })
                .unwrap();
        }

        // Load the target region
        runtime
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();

        assert_eq!(runtime.loaded_regions.len(), 1);
        assert!(runtime.loaded_regions.contains(&region_id));
    }

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_rapid_cycles completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

// ============================================================================
// 2. Region State Tests
// ============================================================================

/// Test that region state is preserved across load/unload cycles
#[test]
fn test_region_streaming_state_preservation() {
    let start = Instant::now();

    let world = create_large_world(5);
    let mut runtime = Runtime::new(world);
    runtime.rng.reset(DEMO_SEED);

    let region_id = RegionId::new(0);

    // Load region
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: region_id })
        .unwrap();

    // Tick a few times
    let dt_micros = 100_000;
    for _ in 0..10 {
        runtime.apply(&RuntimeCommand::Tick { dt_micros }).unwrap();
    }

    // Take snapshot of world state
    let world_before = runtime.world.clone();

    // Unload and reload
    runtime
        .apply(&RuntimeCommand::UnloadRegion { id: region_id })
        .unwrap();
    runtime
        .apply(&RuntimeCommand::LoadRegion { id: region_id })
        .unwrap();

    // World should be the same (region data is immutable)
    // The runtime world is the authored world which doesn't change
    assert_eq!(runtime.world.regions.len(), world_before.regions.len());

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_state_preservation completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}

/// Test that region loading is deterministic with same seed
#[test]
fn test_region_streaming_deterministic() {
    let start = Instant::now();

    let world = create_large_world(50);

    // Create two runtimes with same seed
    let mut runtime_a = Runtime::new(world.clone());
    let mut runtime_b = Runtime::new(world);

    runtime_a.rng.reset(DEMO_SEED);
    runtime_b.rng.reset(DEMO_SEED);

    // Load regions in same order
    for i in 0..20 {
        let region_id = RegionId::new(i);
        runtime_a
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::LoadRegion { id: region_id })
            .unwrap();
    }

    // Verify same regions loaded
    assert_eq!(runtime_a.loaded_regions, runtime_b.loaded_regions);

    // Tick both
    let dt_micros = 50_000;
    for _ in 0..50 {
        runtime_a
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
        runtime_b
            .apply(&RuntimeCommand::Tick { dt_micros })
            .unwrap();
    }

    // State hashes should match
    let hash_a = hex::encode(runtime_a.state_hash());
    let hash_b = hex::encode(runtime_b.state_hash());
    assert_eq!(hash_a, hash_b, "Streaming should be deterministic");

    let duration = start.elapsed();
    tracing::info!(
        "test_region_streaming_deterministic completed in {:?}",
        duration
    );

    assert!(
        duration.as_millis() < REGION_STREAMING_TEST_BUDGET_MS,
        "Test took too long: {:?}",
        duration
    );
}
