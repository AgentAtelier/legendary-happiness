#![deny(missing_docs)]
#![cfg_attr(
    not(test),
    deny(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::unreachable,
        clippy::todo,
    )
)]

//! # anvil_demo_core
//!
//! Core simulation definitions for the Ashveil at Dawn demo.
//!
//! This crate provides the pure-Rust simulation content for the demo:
//! - Scenario definitions (Ashveil world, NPCs, events)
//! - Beat sequencing system
//! - Asset provider abstraction
//!
//! **Architectural Invariant:** This crate must NEVER import Bevy.
//! All visualization and presentation logic lives in `anvil_demo`.

/// Asset provider abstraction for demo content.
pub mod asset;

/// Beat sequencing system for demo narrative control.
pub mod beat;

/// Ashveil scenario: world, NPCs, and events.
pub mod ashveil;

/// Scenario definition trait and implementations.
pub mod scenario;

// Re-export key types
pub use asset::{AssetProvider, ProceduralAssetProvider};
pub use beat::{Beat, BeatId, PendingBeat, SequencerState};
pub use scenario::ScenarioDefinition;

/// The demo seed used for the primary Ashveil demonstration.
pub const DEMO_SEED: u64 = 0x4D32_19AF_DEAD_BEEF;

/// Secondary seed for comparison in the dual-viewport demonstration.
pub const DEMO_SEED_ALT: u64 = 0x9F2E_14BD_8A3C_0071;

/// Number of simulation ticks per second at 10x speed (demo default).
pub const TICKS_PER_SECOND: u64 = 10;

/// Number of real-world seconds per simulation minute at 10x speed.
pub const REAL_SECONDS_PER_SIM_MINUTE: f32 = 6.0;

/// The tick at which the wildfire precursor signal becomes visible (minute 1 = 600 ticks at 10x).
pub const PRECURSOR_TICK: u64 = 600;

/// The tick at which the wildfire catastrophe event fires (minute 2:15 = 780 ticks at 10x).
pub const FIRE_IGNITION_TICK: u64 = 780;

/// The tick at which rain begins suppressing the fire (minute 4:30 = 2100 ticks at 10x).
pub const RAIN_START_TICK: u64 = 2100;

/// The tick at which Dak returns to help (minute 4:00 = 1800 ticks at 10x).
pub const DAK_RETURN_TICK: u64 = 1800;
