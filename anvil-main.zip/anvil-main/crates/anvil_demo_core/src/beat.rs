//! Beat Sequencing System
//!
//! Implements the beat-based narrative sequencing for the Ashveil demo.
//! Beats are pre-authored narrative moments that fire at specific ticks,
//! allowing the demo to coordinate camera, UI, and simulation events.

use serde::{Deserialize, Serialize};
use std::collections::VecDeque;
use std::fmt;

/// A unique identifier for a beat.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub struct BeatId(pub u32);

impl BeatId {
    /// Creates a new beat ID.
    pub fn new(id: u32) -> Self {
        Self(id)
    }

    /// Returns the numeric value of this beat ID.
    pub fn get(&self) -> u32 {
        self.0
    }
}

impl fmt::Display for BeatId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "beat_{}", self.0)
    }
}

/// A pre-authored narrative beat.
///
/// Beats are moments in the demo that trigger specific actions:
/// - Camera changes (spline keyframe advances)
/// - UI panel visibility changes
/// - Music stem crossfades
/// - Simulation events (catastrophe triggers, etc.)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Beat {
    /// Unique identifier for this beat.
    pub id: BeatId,
    /// Human-readable name for this beat.
    pub name: String,
    /// The tick at which this beat should fire.
    pub fire_tick: u64,
    /// Optional description of what this beat does.
    pub description: Option<String>,
    /// Whether this beat is a "major" beat that should be visible in the UI.
    pub is_major: bool,
    /// Optional data payload for beat-specific behavior.
    pub data: BeatData,
}

impl Beat {
    /// Creates a new beat with the given parameters.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        id: BeatId,
        name: impl Into<String>,
        fire_tick: u64,
        description: Option<&str>,
        is_major: bool,
        data: BeatData,
    ) -> Self {
        Self {
            id,
            name: name.into(),
            fire_tick,
            description: description.map(|s| s.to_string()),
            is_major,
            data,
        }
    }

    /// Returns true if this beat should fire at the given tick.
    pub fn should_fire(&self, current_tick: u64) -> bool {
        current_tick >= self.fire_tick
    }

    /// Returns true if this beat has already fired at the given tick.
    pub fn has_fired(&self, current_tick: u64) -> bool {
        current_tick > self.fire_tick
    }
}

/// Data payload for a beat.
///
/// Different variants carry different types of beat-specific information.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[non_exhaustive]
pub enum BeatData {
    /// No additional data.
    Empty,
    /// Camera should advance to a specific spline keyframe.
    CameraAdvance {
        /// Index of the keyframe to advance to.
        keyframe_index: usize,
    },
    /// UI panel should be shown or hidden.
    PanelToggle {
        /// Identifier of the panel to toggle.
        panel_id: String,
        /// Whether the panel should be visible.
        visible: bool,
    },
    /// Music stem should crossfade to a new state.
    MusicCrossfade {
        /// Name of the music stem to crossfade.
        stem: String,
        /// Target volume for the crossfade.
        target_volume: f32,
        /// Duration of the crossfade in milliseconds.
        duration_ms: u64,
    },
    /// A catastrophe event should be triggered.
    TriggerCatastrophe {
        /// Type of catastrophe to trigger.
        catastrophe_type: String,
        /// Magnitude of the catastrophe.
        magnitude: f32,
    },
    /// A specific NPC should be focused.
    FocusNpc {
        /// ID of the NPC to focus on.
        npc_id: u64,
    },
    /// The camera mode should change (scripted vs free).
    CameraModeChange {
        /// The camera mode to change to.
        mode: CameraMode,
    },
    /// Custom beat data as a string (for extensibility).
    Custom {
        /// Type of custom data.
        ty: String,
        /// The custom data payload.
        data: String,
    },
}

/// Camera mode for the demo.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[non_exhaustive]
pub enum CameraMode {
    /// Camera follows the scripted spline path.
    Scripted,
    /// Camera is in free-roam mode.
    Free,
}

impl Default for CameraMode {
    fn default() -> Self {
        Self::Scripted
    }
}

/// A beat that is pending to be processed.
///
/// Pending beats are queued by the core simulation and drained by the
/// Bevy-based presentation layer via events.
#[derive(Debug, Clone)]
pub struct PendingBeat {
    /// The beat to be processed.
    pub beat: Beat,
    /// The tick at which this beat was queued.
    pub queued_tick: u64,
}

impl PendingBeat {
    /// Creates a new pending beat.
    pub fn new(beat: Beat, queued_tick: u64) -> Self {
        Self { beat, queued_tick }
    }
}

/// The state of the beat sequencer.
///
/// This tracks which beats have fired, which are pending, and manages
/// the transition between scripted and free camera modes.
#[derive(Debug, Default)]
#[cfg_attr(feature = "bevy", derive(bevy_ecs::prelude::Resource))]
pub struct SequencerState {
    /// All beats in this scenario, sorted by fire_tick.
    beats: Vec<Beat>,
    /// Beats that have fired but not yet been processed by the presentation layer.
    pending: VecDeque<PendingBeat>,
    /// The current camera mode.
    camera_mode: CameraMode,
    /// The index of the current beat being processed.
    current_beat_index: usize,
    /// The last tick that was processed.
    last_tick: u64,
    /// Whether the sequencer is paused (e.g., in free camera mode).
    paused: bool,
}

impl SequencerState {
    /// Creates a new sequencer state with the given beats.
    pub fn new(beats: Vec<Beat>) -> Self {
        let mut beats = beats;
        // Sort beats by fire_tick to ensure sequential processing
        beats.sort_by_key(|b| b.fire_tick);
        Self {
            beats,
            pending: VecDeque::new(),
            camera_mode: CameraMode::Scripted,
            current_beat_index: 0,
            last_tick: 0,
            paused: false,
        }
    }

    /// Creates a new sequencer state with no beats.
    pub fn empty() -> Self {
        Self::new(Vec::new())
    }

    /// Adds a beat to the sequencer.
    pub fn add_beat(&mut self, beat: Beat) {
        self.beats.push(beat);
        self.beats.sort_by_key(|b| b.fire_tick);
    }

    /// Returns the current camera mode.
    pub fn camera_mode(&self) -> CameraMode {
        self.camera_mode
    }

    /// Sets the camera mode.
    pub fn set_camera_mode(&mut self, mode: CameraMode) {
        self.camera_mode = mode;
        self.paused = mode == CameraMode::Free;
    }

    /// Returns whether the sequencer is paused.
    pub fn is_paused(&self) -> bool {
        self.paused
    }

    /// Returns the current tick.
    pub fn current_tick(&self) -> u64 {
        self.last_tick
    }

    /// Advances the sequencer to the given tick.
    ///
    /// This checks all beats that should fire at or before the given tick
    /// and queues them as pending.
    pub fn advance_to(&mut self, tick: u64) {
        if self.paused {
            // Don't advance beats while paused, but still update the tick
            self.last_tick = tick;
            return;
        }

        // Process beats from the current index
        while self.current_beat_index < self.beats.len() {
            let beat = &self.beats[self.current_beat_index];
            
            if tick >= beat.fire_tick {
                // This beat should fire
                self.pending.push_back(PendingBeat::new(beat.clone(), tick));
                self.current_beat_index += 1;
            } else {
                // No more beats to process at this tick
                break;
            }
        }

        self.last_tick = tick;
    }

    /// Returns all pending beats and clears the queue.
    ///
    /// This is called by the presentation layer to drain pending beats
    /// for processing.
    pub fn drain_pending(&mut self) -> Vec<PendingBeat> {
        self.pending.drain(..).collect()
    }

    /// Returns the number of pending beats.
    pub fn pending_count(&self) -> usize {
        self.pending.len()
    }

    /// Returns the total number of beats.
    pub fn beat_count(&self) -> usize {
        self.beats.len()
    }

    /// Returns the next beat that will fire, if any.
    pub fn next_beat(&self) -> Option<&Beat> {
        self.beats.get(self.current_beat_index)
    }

    /// Returns all beats.
    pub fn all_beats(&self) -> &[Beat] {
        &self.beats
    }

    /// Resets the sequencer to the beginning.
    pub fn reset(&mut self) {
        self.pending.clear();
        self.current_beat_index = 0;
        self.last_tick = 0;
        self.paused = false;
    }

    /// Jumps to a specific beat index.
    ///
    /// This is useful for time-scrubbing in the replay panel.
    pub fn jump_to_beat(&mut self, beat_index: usize) {
        self.current_beat_index = beat_index.min(self.beats.len());
        self.pending.clear();
        // The tick will be updated on the next advance_to call
    }
}

/// Identifier for demo phases.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[non_exhaustive]
pub enum DemoPhase {
    /// Dawn over Ashveil (0:00-0:45)
    Dawn,
    /// Eastern Ridge streams in (0:45-1:30)
    RidgeStreamIn,
    /// Senne sees the fire (1:30-2:15)
    SenneSeesFire,
    /// The fire arrives (2:15-3:00)
    FireArrives,
    /// What the settlement does without instructions (3:00-4:00)
    SettlementResponse,
    /// What Dak's fear costs him (4:00-4:30)
    DaksFear,
    /// Rain changes everything (4:30-5:15)
    Rain,
    /// Determinism proven (5:15-5:45)
    Determinism,
    /// Ashveil stands (5:45-6:00)
    AshveilStands,
}

impl DemoPhase {
    /// Returns the starting tick for this phase.
    pub fn start_tick(&self) -> u64 {
        match self {
            DemoPhase::Dawn => 0,
            DemoPhase::RidgeStreamIn => 270,      // 0:45 at 10x = 45 * 6 = 270 ticks
            DemoPhase::SenneSeesFire => 600,     // 1:30 at 10x
            DemoPhase::FireArrives => 780,       // 2:15 at 10x
            DemoPhase::SettlementResponse => 1800, // 3:00 at 10x
            DemoPhase::DaksFear => 2400,         // 4:00 at 10x
            DemoPhase::Rain => 2700,            // 4:30 at 10x
            DemoPhase::Determinism => 3000,      // 5:15 at 10x
            DemoPhase::AshveilStands => 3300,    // 5:45 at 10x
        }
    }

    /// Returns the end tick for this phase.
    pub fn end_tick(&self) -> u64 {
        match self {
            DemoPhase::Dawn => 270,
            DemoPhase::RidgeStreamIn => 600,
            DemoPhase::SenneSeesFire => 780,
            DemoPhase::FireArrives => 1800,
            DemoPhase::SettlementResponse => 2400,
            DemoPhase::DaksFear => 2700,
            DemoPhase::Rain => 3000,
            DemoPhase::Determinism => 3300,
            DemoPhase::AshveilStands => 3600,
        }
    }

    /// Returns the phase for a given tick.
    pub fn from_tick(tick: u64) -> DemoPhase {
        if tick >= 3300 { DemoPhase::AshveilStands }
        else if tick >= 3000 { DemoPhase::Determinism }
        else if tick >= 2700 { DemoPhase::Rain }
        else if tick >= 2400 { DemoPhase::DaksFear }
        else if tick >= 1800 { DemoPhase::SettlementResponse }
        else if tick >= 780 { DemoPhase::FireArrives }
        else if tick >= 600 { DemoPhase::SenneSeesFire }
        else if tick >= 270 { DemoPhase::RidgeStreamIn }
        else { DemoPhase::Dawn }
    }

    /// Returns a description of this phase.
    pub fn description(&self) -> &'static str {
        match self {
            DemoPhase::Dawn => "Dawn over Ashveil",
            DemoPhase::RidgeStreamIn => "Eastern Ridge streams in",
            DemoPhase::SenneSeesFire => "Senne sees it",
            DemoPhase::FireArrives => "The fire arrives",
            DemoPhase::SettlementResponse => "What the settlement does without instructions",
            DemoPhase::DaksFear => "What Dak's fear costs him",
            DemoPhase::Rain => "Rain changes everything",
            DemoPhase::Determinism => "Determinism proven",
            DemoPhase::AshveilStands => "Ashveil stands",
        }
    }
}

impl fmt::Display for DemoPhase {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.description())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_beat_should_fire() {
        let beat = Beat::new(
            BeatId::new(1),
            "Test Beat",
            100,
            None,
            false,
            BeatData::Empty,
        );

        assert!(!beat.should_fire(99));
        assert!(beat.should_fire(100));
        assert!(beat.should_fire(101));
    }

    #[test]
    fn test_sequencer_advance() {
        let beats = vec![
            Beat::new(BeatId::new(1), "Beat 1", 100, None, false, BeatData::Empty),
            Beat::new(BeatId::new(2), "Beat 2", 200, None, false, BeatData::Empty),
            Beat::new(BeatId::new(3), "Beat 3", 300, None, false, BeatData::Empty),
        ];

        let mut sequencer = SequencerState::new(beats);

        // Advance to tick 50 - no beats should fire
        sequencer.advance_to(50);
        assert_eq!(sequencer.pending_count(), 0);

        // Advance to tick 100 - beat 1 should fire
        sequencer.advance_to(100);
        assert_eq!(sequencer.pending_count(), 1);

        // Advance to tick 200 - beat 2 should fire
        sequencer.advance_to(200);
        assert_eq!(sequencer.pending_count(), 2);

        // Drain and verify
        let pending = sequencer.drain_pending();
        assert_eq!(pending.len(), 2);
        assert_eq!(pending[0].beat.id.get(), 1);
        assert_eq!(pending[1].beat.id.get(), 2);
    }

    #[test]
    fn test_demo_phase_from_tick() {
        assert_eq!(DemoPhase::from_tick(0), DemoPhase::Dawn);
        assert_eq!(DemoPhase::from_tick(100), DemoPhase::Dawn);
        assert_eq!(DemoPhase::from_tick(600), DemoPhase::SenneSeesFire);
        assert_eq!(DemoPhase::from_tick(780), DemoPhase::FireArrives);
        assert_eq!(DemoPhase::from_tick(3600), DemoPhase::AshveilStands);
    }
}
