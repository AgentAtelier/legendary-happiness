//! Ashveil at Dawn Scenario
//!
//! This module contains the complete definition of the Ashveil demo scenario:
//! - World definition (regions, settlements, connections)
//! - NPC definitions (all 8 named characters)
//! - Initial state
//! - Beat sequencing

pub mod npcs;
pub mod world;

use crate::beat::{Beat, BeatData, BeatId, SequencerState};
use crate::scenario::ScenarioDefinition;
use crate::DEMO_SEED;
use anvil_sim::soul::{EmotionalAxes, EmotionalState};
use anvil_sim::skill::profile::SkillProfile;
use anvil_world::WorldAuthored;

/// The Ashveil scenario definition.
pub struct AshveilScenario;

impl ScenarioDefinition for AshveilScenario {
    fn id(&self) -> &'static str {
        "ashveil_at_dawn"
    }

    fn name(&self) -> &'static str {
        "Ashveil at Dawn"
    }

    fn description(&self) -> &'static str {
        "A six-minute guided performance of the Forgeborn simulation engine, \
         set in a single forest settlement on the morning a wildfire crests the eastern ridge."
    }

    fn seed(&self) -> u64 {
        DEMO_SEED
    }

    fn build_world(&self) -> WorldAuthored {
        world::build_ashveil_world()
    }

    fn duration_ticks(&self) -> u64 {
        3600 // 6 minutes at 10x speed
    }

    fn completion_tick(&self) -> u64 {
        3600
    }
}

/// Creates the sequencer state for the Ashveil demo.
///
/// This defines all the narrative beats that drive camera, UI, and music changes.
pub fn create_ashveil_sequencer() -> SequencerState {
    let beats = vec![
        // 0:00 - Dawn over Ashveil
        Beat::new(
            BeatId::new(1),
            "Dawn Establishing",
            0,
            Some("Establishing shot begins 600m above settlement"),
            true,
            BeatData::CameraAdvance { keyframe_index: 0 },
        ),
        
        // 0:45 - Eastern Ridge streams in
        Beat::new(
            BeatId::new(2),
            "Ridge Stream In",
            270,
            Some("Camera pulls out to 900m, eastern ridge becomes visible"),
            true,
            BeatData::CameraAdvance { keyframe_index: 1 },
        ),
        
        // 1:30 - Senne sees it
        Beat::new(
            BeatId::new(3),
            "Senne Sees Fire",
            600,
            Some("Cut to Senne at watchtower, she sees smoke on horizon"),
            true,
            BeatData::CameraAdvance { keyframe_index: 2 },
        ),
        
        // 2:15 - The fire arrives
        Beat::new(
            BeatId::new(4),
            "Fire Ignition",
            780,
            Some("Wildfire catastrophe event fires on eastern ridge"),
            true,
            BeatData::TriggerCatastrophe {
                catastrophe_type: "Wildfire".to_string(),
                magnitude: 0.72,
            },
        ),
        Beat::new(
            BeatId::new(5),
            "Fire Wide Shot",
            780,
            Some("Camera pulls out to 400m altitude, looking southeast"),
            false,
            BeatData::CameraAdvance { keyframe_index: 3 },
        ),
        
        // 3:00 - Three-shot sequence starts
        Beat::new(
            BeatId::new(6),
            "Shot 1: Yarra at Granary",
            1800,
            Some("Low angle behind Yarra at granary"),
            true,
            BeatData::CameraAdvance { keyframe_index: 4 },
        ),
        Beat::new(
            BeatId::new(7),
            "Shot 2: Maren at Commons",
            2040,
            Some("Wide shot of Elder Maren at commons"),
            true,
            BeatData::CameraAdvance { keyframe_index: 5 },
        ),
        Beat::new(
            BeatId::new(8),
            "Shot 3: Debris Physics",
            2280,
            Some("Physics beat: burning debris falls from ridge"),
            true,
            BeatData::CameraAdvance { keyframe_index: 6 },
        ),
        
        // 4:00 - Dak returns
        Beat::new(
            BeatId::new(9),
            "Dak Returns",
            2400,
            Some("Dak turns back and begins reinforcing the wall"),
            true,
            BeatData::FocusNpc { npc_id: 2 }, // Dak's ID
        ),
        
        // 4:30 - Rain begins
        Beat::new(
            BeatId::new(10),
            "Rain Begins",
            2700,
            Some("Weather transitions, fire begins to die down"),
            true,
            BeatData::CameraAdvance { keyframe_index: 7 },
        ),
        
        // 5:15 - Dual viewport
        Beat::new(
            BeatId::new(11),
            "Dual Viewport",
            3000,
            Some("Transition to dual-viewport layout for seed comparison"),
            true,
            BeatData::Custom {
                ty: "dual_viewport".to_string(),
                data: "SeedB:0x9F2E14BD8A3C0071".to_string(),
            },
        ),
        
        // 5:45 - Ashveil stands
        Beat::new(
            BeatId::new(12),
            "Ashveil Stands",
            3300,
            Some("Camera returns to live settlement, evening light"),
            true,
            BeatData::CameraAdvance { keyframe_index: 8 },
        ),
        
        // 6:00 - Demo complete
        Beat::new(
            BeatId::new(13),
            "Demo Complete",
            3600,
            Some("Forgeborn logo fades in"),
            true,
            BeatData::Empty,
        ),
    ];

    SequencerState::new(beats)
}

/// NPC IDs for the Ashveil scenario.
/// These are consistent across all runs of the scenario.
pub mod npc_ids {
    /// Elder Maren Ironbark - the matriarch of the settlement.
    pub const ELDER_MAREN: u64 = 1;
    /// Dak Voss - a skilled but fearful wanderer.
    pub const DAK_VOSS: u64 = 2;
    /// Senne Ironbark - Maren's daughter, with WeatherSense skills.
    pub const SENNE_IRONBARK: u64 = 3;
    /// Tibor Ironbark - Maren's son, apprentice woodcrafter.
    pub const TIBOR_IRONBARK: u64 = 4;
    /// Lora Vance - a generous wanderer with Foraging skills.
    pub const LORA_VANCE: u64 = 5;
    /// Cael Ironbark - a young child, Maren's grandchild.
    pub const CAEL_IRONBARK: u64 = 6;
    /// Yarra Keld - a stable but selfish stoneworker.
    pub const YARRA_KELD: u64 = 7;
    /// Pell Vance - an anxious wanderer with SocialWeaving skills.
    pub const PELL_VANCE: u64 = 8;
}

/// Family IDs for the Ashveil scenario.
pub mod family_ids {
    /// The Ironbark family - long-time settlers of Ashveil.
    pub const FAMILY_IRONBARK: u64 = 1001;
    /// The Wanderers family - recent arrivals to Ashveil.
    pub const FAMILY_WANDERERS: u64 = 1002;
}

/// Settlement IDs for the Ashveil scenario.
pub mod settlement_ids {
    /// The main settlement in Ashveil Valley.
    pub const ASHVEIL: u64 = 1;
}

/// Region IDs for the Ashveil scenario.
pub mod region_ids {
    /// The settlement's core, always loaded.
    pub const ASHVEIL_VALLEY: &str = "ashveil_valley";
    /// The fire's origin, streams in as the camera pulls back.
    pub const EASTERN_RIDGE: &str = "eastern_ridge";
    /// The evacuation route, streams in during crisis.
    pub const WESTERN_FORD: &str = "western_ford";
    /// Never loaded, present to show the world extends beyond the viewport.
    pub const DEEP_FOREST: &str = "deep_forest";
}

/// Helper to create a neutral emotional state.
pub fn neutral_emotional_state() -> EmotionalState {
    EmotionalState::new(EmotionalAxes::neutral())
}

/// Helper to create an empty skill profile.
pub fn empty_skill_profile() -> SkillProfile {
    SkillProfile::new()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ashveil_scenario_basic() {
        let scenario = AshveilScenario;
        
        assert_eq!(scenario.id(), "ashveil_at_dawn");
        assert_eq!(scenario.name(), "Ashveil at Dawn");
        assert_eq!(scenario.seed(), DEMO_SEED);
        assert_eq!(scenario.duration_ticks(), 3600);
    }

    #[test]
    fn test_ashveil_sequencer() {
        let sequencer = create_ashveil_sequencer();
        
        assert_eq!(sequencer.beat_count(), 13);
        assert_eq!(sequencer.all_beats().len(), 13);
    }
}
