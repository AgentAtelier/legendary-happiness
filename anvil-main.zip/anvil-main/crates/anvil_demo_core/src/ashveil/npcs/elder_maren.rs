//! Elder Maren Ironbark
//!
//! NPC Definition for Elder Maren from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** The steadiest person in the settlement. Her high cooperation_modifier
//! (derived from generosity and belonging 0.97) ensures her action scores for
//! organizing/coordinating outrank any personal-survival action. She will not flee
//! unless the settlement is fully lost.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Elder Maren Ironbark.
///
/// *Substrate:* `courage_fear: +0.88`, `generosity_selfishness: +0.91`, `stability_anxiety: +0.82`
/// She is the steadiest person in the settlement.
///
/// *Skill profile:* SocialWeaving **Expert** (7 affordances unlocked), WeatherSense **Competent**.
///
/// *Starting needs:* Sleep 0.94 (just woke), Food 0.67, Companionship 0.73, Joy 0.61.
///
/// *Role in demo:* Her high `cooperation_modifier` ensures her action scores for organizing/
/// coordinating outrank any personal-survival action. When the fire peaks, she will stand
/// at the commons and run SocialWeaving actions that raise nearby NPCs' `safety` scores.
/// She will not flee unless the settlement is fully lost.
pub fn create_elder_maren(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        0.88,   // courage_fear: +0.88 (courageous)
        0.91,   // generosity_selfishness: +0.91 (generous)
        0.82,   // stability_anxiety: +0.82 (stable)
    );

    let mut person = create_person_base(
        npc_ids::ELDER_MAREN,
        "Elder Maren Ironbark",
        family_ids::FAMILY_IRONBARK,
        70.0, // age 70 (Elder)
        substrate,
        settlement_id,
        Vec3::new(-10.0, 0.0, 5.0), // Position at commons
    );

    // Set initial needs (from DEMO_VISION.md)
    // These will be applied when the NPC system initializes
    // Sleep 0.94, Food 0.67, Companionship 0.73, Joy 0.61
    
    // Add memories - Maren has a long history with the settlement
    person.memories = vec![
        create_memory("Founding of Ashveil - I remember when we first built this settlement, 50 years ago.", 0.8, true),
        create_memory("Winter of Hardship - The winter when food ran low, but we endured together.", 0.7, true),
        create_memory("My Children - Senne and Tibor were such curious children. Now they have children of their own.", 0.9, true),
    ];

    // High belonging - she is the elder of the settlement
    person.belonging = 0.97;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_elder_maren_creation() {
        let maren = create_elder_maren(1);
        
        assert_eq!(maren.id.get(), npc_ids::ELDER_MAREN);
        assert_eq!(maren.name, "Elder Maren Ironbark");
        assert_eq!(maren.age.years(), 70.0);
        assert_eq!(maren.age_category, AgeCategory::Elder);
    }

    #[test]
    fn test_elder_maren_substrate() {
        let maren = create_elder_maren(1);
        
        // Check substrate values (with tolerance for floating point)
        assert!((maren.substrate.courage_fear - 0.88).abs() < 0.01);
        assert!((maren.substrate.generosity_selfishness - 0.91).abs() < 0.01);
        assert!((maren.substrate.stability_anxiety - 0.82).abs() < 0.01);
    }

    #[test]
    fn test_elder_maren_belonging() {
        let maren = create_elder_maren(1);
        
        // Maren has very high belonging as the settlement elder
        assert!((maren.belonging - 0.97).abs() < 0.01);
    }

    #[test]
    fn test_elder_maren_memories() {
        let maren = create_elder_maren(1);
        
        assert_eq!(maren.memories.len(), 3);
    }
}
