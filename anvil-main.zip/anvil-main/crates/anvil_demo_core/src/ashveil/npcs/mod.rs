//! NPC Definitions for Ashveil
//!
//! This module contains the definitions for all 8 named NPCs in the Ashveil demo.
//! Each NPC has a dedicated file with their substrate, skill profile, needs, and behavior.

pub mod cael_ironbark;
pub mod dak_voss;
pub mod elder_maren;
pub mod lora_vance;
pub mod pell_vance;
pub mod senne_ironbark;
pub mod tibor_ironbark;
pub mod yarra_keld;

use anvil_sim::age::Age;
use anvil_sim::settlement::{Connection, ConnectionLayer, Person, PersonId};
use anvil_sim::settlement::ids::FamilyId;
use anvil_sim::settlement::memory::Memory;
use anvil_sim::soul::{EmotionalAxes, EmotionalState, Substrate};
use anvil_sim::skill::profile::SkillProfile;
use glam::Vec3;

/// Re-exports all NPC creation functions.
pub use cael_ironbark::create_cael;
pub use dak_voss::create_dak;
pub use elder_maren::create_elder_maren;
pub use lora_vance::create_lora;
pub use pell_vance::create_pell;
pub use senne_ironbark::create_senne;
pub use tibor_ironbark::create_tibor;
pub use yarra_keld::create_yarra;

/// Creates all 8 NPCs for the Ashveil scenario.
///
/// Returns a vector of Persons with all the named characters.
pub fn create_all_npcs(settlement_id: u64) -> Vec<Person> {
    vec![
        create_elder_maren(settlement_id),
        create_dak(settlement_id),
        create_senne(settlement_id),
        create_tibor(settlement_id),
        create_lora(settlement_id),
        create_cael(settlement_id),
        create_yarra(settlement_id),
        create_pell(settlement_id),
    ]
}

/// Creates connections between NPCs based on their relationships.
///
/// This establishes the social graph for the Ashveil settlement.
/// Note: Connections are one-directional (from source to target).
pub fn create_npc_connections() -> Vec<Connection> {
    let mut connections = Vec::new();
    
    // Family Ironbark connections
    // Elder Maren is the matriarch
    connections.push(Connection::new(PersonId::new(3), ConnectionLayer::Family)); // Maren -> Senne
    connections.push(Connection::new(PersonId::new(4), ConnectionLayer::Family)); // Maren -> Tibor
    connections.push(Connection::new(PersonId::new(6), ConnectionLayer::Family)); // Maren -> Cael
    connections.push(Connection::new(PersonId::new(7), ConnectionLayer::Family)); // Maren -> Yarra
    
    // Senne and Tibor are siblings
    connections.push(Connection::new(PersonId::new(4), ConnectionLayer::Family)); // Senne -> Tibor
    connections.push(Connection::new(PersonId::new(6), ConnectionLayer::Family)); // Senne -> Cael
    
    // Tibor and Cael
    connections.push(Connection::new(PersonId::new(6), ConnectionLayer::Family)); // Tibor -> Cael
    
    // Family Wanderers connections
    connections.push(Connection::new(PersonId::new(5), ConnectionLayer::Family)); // Dak -> Lora
    connections.push(Connection::new(PersonId::new(8), ConnectionLayer::Family)); // Dak -> Pell
    connections.push(Connection::new(PersonId::new(8), ConnectionLayer::Family)); // Lora -> Pell
    
    // Cross-family connections (settlement proximity)
    connections.push(Connection::new(PersonId::new(2), ConnectionLayer::Village)); // Maren -> Dak
    connections.push(Connection::new(PersonId::new(5), ConnectionLayer::Village)); // Maren -> Lora
    connections.push(Connection::new(PersonId::new(2), ConnectionLayer::Village)); // Senne -> Dak
    connections.push(Connection::new(PersonId::new(5), ConnectionLayer::Village)); // Tibor -> Lora
    
    // Pell's anxiety makes him less connected
    // But he has a connection to Maren (she tries to include him)
    connections.push(Connection::new(PersonId::new(1), ConnectionLayer::Village)); // Pell -> Maren
    
    connections
}

/// Creates a person with common defaults for Ashveil NPCs.
///
/// This helper reduces boilerplate in the individual NPC creation functions.
pub fn create_person_base(
    id: u64,
    name: &str,
    family_id: u64,
    age_years: f32,
    substrate: Substrate,
    settlement_id: u64,
    position: Vec3,
) -> Person {
    let mut person = Person::new_simple(
        PersonId::new(id),
        name.to_string(),
        FamilyId::new(family_id),
    );
    let age = Age::from_years(age_years);
    person.age = age;
    person.age_category = age.to_age_category();
    person.substrate = substrate;
    person.emotional_state = EmotionalState::new(EmotionalAxes::neutral());
    person.connections = vec![];
    person.memories = vec![];
    person.skills = vec![];
    person.skill_profile = SkillProfile::new();
    person.current_action_id = None;
    person.current_action_remaining_ticks = 0;
    person.last_evaluation_tick = 0;
    person.settlement_id = settlement_id;
    person.belonging = 0.5;
    person.position = position;
    person
}

/// Helper to create a simple memory with an auto-generated event ID.
/// Uses a hash of the description to create a deterministic event ID.
pub fn create_memory(description: &str, vividness: f32, is_positive: bool) -> Memory {
    // Create a deterministic event ID from the description
    let mut hasher = blake3::Hasher::new();
    hasher.update(description.as_bytes());
    let hash = hasher.finalize();
    let event_id = u64::from_le_bytes(hash.as_bytes()[0..8].try_into().unwrap_or([0u8; 8]));
    
    Memory::new(
        if event_id == 0 { 1 } else { event_id }, // Ensure non-zero
        0, // age_ticks - will be updated by the simulation
        vividness,
        is_positive,
    )
}
