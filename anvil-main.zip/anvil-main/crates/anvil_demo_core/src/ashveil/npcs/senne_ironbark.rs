//! Senne Ironbark
//!
//! NPC Definition for Senne Ironbark from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Senne is at the watchtower at demo start because her WeatherSense skill score
//! for this time block is 1.0 (highest). At tick 600 (minute 1), `CatastropheSystem` emits
//! `PrecursorSignal { kind: SmokeOnHorizon, intensity: 0.31 }`. Only Senne qualifies
//! (perceptibility score 0.62 vs threshold 0.5). Senne's Safety need jumps from 0.79 to 0.43.
//! Her action re-evaluation produces: `warn_community` (SocialWeaving Halting).

use anvil_sim::settlement::Person;
use anvil_sim::skill::affordance::AffordanceId;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Senne Ironbark.
///
/// *Substrate:* `courage_fear: +0.55`, `generosity_selfishness: +0.71`, `stability_anxiety: +0.44`
///
/// *Skill profile:* WeatherSense **Smooth** (5 affordances: cloud-reading, wind-direction,
/// precipitation-sense, fire-sign recognition, weather-phase prediction). Husbandry **Competent**.
///
/// *Starting needs:* Sleep 0.87, Water 0.68, Safety 0.79. She slept well; water is her morning urgency.
///
/// *Role in demo:* She is at the watchtower at demo start. When the precursor signal fires,
/// she is the only NPC whose observation scoring selects it as perceptible. She warns the community.
pub fn create_senne(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        0.55,  // courage_fear: +0.55
        0.71,  // generosity_selfishness: +0.71
        0.44,  // stability_anxiety: +0.44
    );

    let mut person = create_person_base(
        npc_ids::SENNE_IRONBARK,
        "Senne Ironbark",
        family_ids::FAMILY_IRONBARK,
        28.0, // age 28 (Adult)
        substrate,
        settlement_id,
        Vec3::new(100.0, 180.0, 0.0), // Position at watchtower (eastern ridge)
    );

    // Add memories
    person.memories = vec![
        create_memory("Learning WeatherSense - Mother taught me to read the signs in the wind and clouds.", 0.7, true),
        create_memory("Storm Prediction - I predicted the storm that saved the harvest last year.", 0.6, true),
        create_memory("Watchtower Duty - This is my post. I watch the eastern ridge every morning.", 0.8, true),
    ];

    // Senne has WeatherSense Smooth - unlock all 5 WeatherSense affordances (IDs 50-54)
    // cloud_pattern_reading, wind_shift_detection, pressure_change_feel, frost_forecast, storm_distance_ear
    for id in 50..=54 {
        person.skill_profile.unlock(AffordanceId::new(id));
    }

    // Senne has good belonging as a member of the Ironbark family
    person.belonging = 0.88;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_senne_creation() {
        let senne = create_senne(1);
        
        assert_eq!(senne.id.get(), npc_ids::SENNE_IRONBARK);
        assert_eq!(senne.name, "Senne Ironbark");
        assert_eq!(senne.age.years(), 28.0);
        assert_eq!(senne.age_category, AgeCategory::Adult);
    }

    #[test]
    fn test_senne_substrate() {
        let senne = create_senne(1);
        
        assert!((senne.substrate.courage_fear - 0.55).abs() < 0.01);
        assert!((senne.substrate.generosity_selfishness - 0.71).abs() < 0.01);
        assert!((senne.substrate.stability_anxiety - 0.44).abs() < 0.01);
    }

    #[test]
    fn test_senne_position() {
        let senne = create_senne(1);
        
        // Senne starts at the watchtower on the eastern ridge
        // The ridge is at elevation 180m
        assert!((senne.position.y - 180.0).abs() < 0.1);
    }

    #[test]
    fn test_senne_belonging() {
        let senne = create_senne(1);
        
        assert!((senne.belonging - 0.88).abs() < 0.01);
    }
}
