//! Yarra Keld
//!
//! NPC Definition for Yarra Keld from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Yarra is calm, selfish-leaning, and excellent at stone. When settlement
//! structural integrity begins dropping, her action scoring responds. Her
//! `coping_modifier` for Stonework actions is elevated by the nonzero damage level.
//! She moves to the granary and runs `reinforce_mortared_joint` — this is the only
//! action in the demo that actively reduces `structural_damage` ticks. The granary
//! does not collapse. This matters: food stores survive.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Yarra Keld.
///
/// *Substrate:* `courage_fear: -0.31`, `generosity_selfishness: -0.44`, `stability_anxiety: +0.62`
/// (stable but self-oriented)
///
/// *Skill profile:* Stonework **Expert** (7 affordances: quarry-reading, mortar-mixing,
/// arch-key placement, crack-diagnosis, repointing, load-bearing assessment, rubble-sorting).
/// Belonging: 0.51.
///
/// *Starting needs:* Sleep 0.88, Food 0.61, Shelter 0.65.
///
/// *Role in demo:* When the fire starts damaging buildings, Yarra moves to the granary
/// and runs `reinforce_mortared_joint`, actively reducing structural damage. The granary
/// does not collapse because of her.
pub fn create_yarra(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        -0.31,  // courage_fear: -0.31 (somewhat fearful)
        -0.44,  // generosity_selfishness: -0.44 (selfish-leaning)
        0.62,   // stability_anxiety: +0.62 (stable)
    );

    let mut person = create_person_base(
        npc_ids::YARRA_KELD,
        "Yarra Keld",
        family_ids::FAMILY_IRONBARK,
        52.0, // age 52 (Adult)
        substrate,
        settlement_id,
        Vec3::new(8.0, 0.0, 8.0), // Position near the granary
    );

    // Add memories
    person.memories = vec![
        create_memory("Stonework Mastery - Stone doesn't lie. It either holds or it doesn't.", 0.8, true),
        create_memory("Granary Construction - I oversaw the building of the granary. It's my responsibility.", 0.9, true),
        create_memory("Storm Damage Repair - After the storm, I spent a week repointing the cracks.", 0.7, true),
    ];

    // Yarra's belonging is 0.51
    person.belonging = 0.51;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_yarra_creation() {
        let yarra = create_yarra(1);
        
        assert_eq!(yarra.id.get(), npc_ids::YARRA_KELD);
        assert_eq!(yarra.name, "Yarra Keld");
        assert_eq!(yarra.age.years(), 52.0);
        assert_eq!(yarra.age_category, AgeCategory::Adult);
    }

    #[test]
    fn test_yarra_substrate() {
        let yarra = create_yarra(1);
        
        assert!((yarra.substrate.courage_fear - (-0.31)).abs() < 0.01);
        assert!((yarra.substrate.generosity_selfishness - (-0.44)).abs() < 0.01);
        assert!((yarra.substrate.stability_anxiety - 0.62).abs() < 0.01);
    }

    #[test]
    fn test_yarra_belonging() {
        let yarra = create_yarra(1);
        
        // Yarra has belonging of 0.51
        assert!((yarra.belonging - 0.51).abs() < 0.01);
    }

    #[test]
    fn test_yarra_cooperation_modifier() {
        let yarra = create_yarra(1);
        
        // cooperation_modifier = (substrate.generosity_selfishness + 1.0) / 2.0
        // = (-0.44 + 1.0) / 2.0 = 0.56 / 2.0 = 0.28
        let cooperation = (yarra.substrate.generosity_selfishness + 1.0) / 2.0;
        assert!((cooperation - 0.28).abs() < 0.01);
    }
}
