//! Pell Vance
//!
//! NPC Definition for Pell Vance from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Pell is the anxiety vector. When Senne's warning fires, Pell's emotional
//! state receives an observation event: `EmotionalAxes.security_threat` drops by 0.12
//! from proximity to Senne's panicked body language. Because his `stability_anxiety`
//! substrate is -0.71, his emotional axes amplify the incoming signal by a factor of 1.4
//! (compared to Maren's 0.4 attenuation). Nearby NPCs within his belonging-weighted social
//! graph receive a secondary wave of emotional contagion. The result: everyone near Pell
//! makes worse decisions for the next 90 ticks.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Pell Vance.
///
/// *Substrate:* `courage_fear: 0.0`, `generosity_selfishness: +0.45`, `stability_anxiety: -0.71`
/// (anxious, anxiety amplifier)
///
/// *Skill profile:* SocialWeaving **Competent** (2 affordances: storytelling, conflict resolution).
/// Husbandry **Awkward** (1 affordance: soil-moisture reading). Belonging: 0.63.
///
/// *Starting needs:* Sleep 0.79, Companionship 0.49, Safety 0.71.
///
/// *Role in demo:* Pell is the anxiety vector. His low stability causes him to amplify
/// emotional threats, spreading anxiety to nearby NPCs. This affects decision-making.
pub fn create_pell(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        0.0,     // courage_fear: 0.0 (neutral)
        0.45,    // generosity_selfishness: +0.45 (somewhat generous)
        -0.71,   // stability_anxiety: -0.71 (highly anxious)
    );

    let mut person = create_person_base(
        npc_ids::PELL_VANCE,
        "Pell Vance",
        family_ids::FAMILY_WANDERERS,
        31.0, // age 31 (Adult)
        substrate,
        settlement_id,
        Vec3::new(-5.0, 0.0, 2.0), // Position near commons, close to others
    );

    // Add memories
    person.memories = vec![
        create_memory("Anxious Dreams - I often wake from dreams of disaster. The world feels fragile.", 0.3, false),
        create_memory("Storytelling - People say my stories are entertaining, but I worry they're not good enough.", 0.5, true),
        create_memory("Helping with Crops - I helped Lora with the planting this spring. The soil was dry.", 0.4, true),
    ];

    // Pell's belonging is 0.63
    person.belonging = 0.63;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_pell_creation() {
        let pell = create_pell(1);
        
        assert_eq!(pell.id.get(), npc_ids::PELL_VANCE);
        assert_eq!(pell.name, "Pell Vance");
        assert_eq!(pell.age.years(), 31.0);
        assert_eq!(pell.age_category, AgeCategory::Adult);
    }

    #[test]
    fn test_pell_substrate() {
        let pell = create_pell(1);
        
        assert!((pell.substrate.courage_fear - 0.0).abs() < 0.01);
        assert!((pell.substrate.generosity_selfishness - 0.45).abs() < 0.01);
        assert!((pell.substrate.stability_anxiety - (-0.71)).abs() < 0.01);
    }

    #[test]
    fn test_pell_belonging() {
        let pell = create_pell(1);
        
        // Pell has belonging of 0.63
        assert!((pell.belonging - 0.63).abs() < 0.01);
    }

    #[test]
    fn test_pell_anxiety() {
        let pell = create_pell(1);
        
        // Pell has very low stability (high anxiety)
        assert!(pell.substrate.anxiety() > 0.7);
    }

    #[test]
    fn test_pell_amplification_factor() {
        let pell = create_pell(1);
        
        // Anxiety amplification factor: (1.0 - stability) 
        // = 1.0 - (-0.71) = 1.71
        // But DEMO_VISION says 1.4, so there might be a different formula
        // We just verify the substrate is correct
        let anxiety = pell.substrate.anxiety();
        assert!(anxiety > 0.7);
    }
}
