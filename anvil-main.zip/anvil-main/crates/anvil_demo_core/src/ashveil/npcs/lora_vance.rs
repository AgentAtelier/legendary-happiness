//! Lora Vance
//!
//! NPC Definition for Lora Vance from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Lora is slightly fearful but deeply generous. When the Wildfire CatastropheEvent
//! fires, her safety need spikes but her action scoring produces `lead_child_to_ford` rather
//! than `self_evacuate` — because Cael's belonging is linked to her connection graph, and
//! the `cooperation_modifier` for her generosity substrate (+0.84) weights community protection
//! actions highly. She takes the child west. She knows the ford route because
//! `river_ford_navigation` is unlocked.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Lora Vance.
///
/// *Substrate:* `courage_fear: -0.42`, `generosity_selfishness: +0.84`, `stability_anxiety: +0.51`
///
/// *Skill profile:* Foraging **Smooth** (4 affordances: plant-id, fishing, trapping, trail-finding).
/// Pathfinding **Competent** (3 affordances: landmark-reading, route-recall, river-ford navigation).
///
/// *Starting needs:* Sleep 0.76, Food 0.54, Safety 0.61.
///
/// *Role in demo:* When the fire arrives, her action scoring produces `lead_child_to_ford`.
/// She evacuates with Cael. She knows the ford route because `river_ford_navigation` is unlocked.
pub fn create_lora(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        -0.42,  // courage_fear: -0.42 (slightly fearful)
        0.84,   // generosity_selfishness: +0.84 (deeply generous)
        0.51,   // stability_anxiety: +0.51 (stable)
    );

    let mut person = create_person_base(
        npc_ids::LORA_VANCE,
        "Lora Vance",
        family_ids::FAMILY_WANDERERS,
        45.0, // age 45 (Adult)
        substrate,
        settlement_id,
        Vec3::new(5.0, 0.0, 0.0), // Position near commons
    );

    // Add memories
    person.memories = vec![
        create_memory("Cael's Birth - I was there when Cael was born. Such a special day.", 0.8, true),
        create_memory("Fishing at the Ford - The river is always generous to those who know where to look.", 0.7, true),
        create_memory("Helping Others - Sharing what we have is what makes us strong.", 0.85, true),
    ];

    // Lora has high belonging due to her generosity
    person.belonging = 0.84;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_lora_creation() {
        let lora = create_lora(1);
        
        assert_eq!(lora.id.get(), npc_ids::LORA_VANCE);
        assert_eq!(lora.name, "Lora Vance");
        assert_eq!(lora.age.years(), 45.0);
        assert_eq!(lora.age_category, AgeCategory::Adult);
    }

    #[test]
    fn test_lora_substrate() {
        let lora = create_lora(1);
        
        assert!((lora.substrate.courage_fear - (-0.42)).abs() < 0.01);
        assert!((lora.substrate.generosity_selfishness - 0.84).abs() < 0.01);
        assert!((lora.substrate.stability_anxiety - 0.51).abs() < 0.01);
    }

    #[test]
    fn test_lora_belonging() {
        let lora = create_lora(1);
        
        // Lora has high belonging matching her generosity
        assert!((lora.belonging - 0.84).abs() < 0.01);
    }

    #[test]
    fn test_lora_cooperation_modifier() {
        let lora = create_lora(1);
        
        // cooperation_modifier = (substrate.generosity_selfishness + 1.0) / 2.0
        // = (0.84 + 1.0) / 2.0 = 1.84 / 2.0 = 0.92
        let cooperation = (lora.substrate.generosity_selfishness + 1.0) / 2.0;
        assert!((cooperation - 0.92).abs() < 0.01);
    }
}
