//! Cael Ironbark
//!
//! NPC Definition for Cael Ironbark from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Cael is a child — his action catalogue is limited (no Woodcraft, Stonework,
//! or WeatherSense domain actions unlock for children). His highest-scoring morning action
//! is always `play_near_commons` (Companionship). He is the emotional throughline. When the
//! fire is visible, he stops playing. He looks east. He does not run — his safety need has
//! not crossed the threshold yet. The viewer sees this a full thirty seconds before the
//! CatastropheEvent fires. He stands at the edge of the commons watching the smoke.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Cael Ironbark.
///
/// *Substrate:* `courage_fear: +0.21`, `generosity_selfishness: +0.55`, `stability_anxiety: +0.10`
///
/// *Skill profile:* All domains Halting. Belonging: 0.82.
///
/// *Starting needs:* Companionship 0.48, Sleep 0.89, Food 0.58.
///
/// *Role in demo:* He is a child. His action catalogue is limited. His highest-scoring
/// morning action is `play_near_commons`. When the fire becomes visible, he stops playing
/// and watches the smoke. He does not run.
pub fn create_cael(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        0.21,  // courage_fear: +0.21
        0.55,  // generosity_selfishness: +0.55
        0.10,  // stability_anxiety: +0.10
    );

    let mut person = create_person_base(
        npc_ids::CAEL_IRONBARK,
        "Cael Ironbark",
        family_ids::FAMILY_IRONBARK,
        8.0, // age 8 (Child)
        substrate,
        settlement_id,
        Vec3::new(0.0, 0.0, -3.0), // Position at the edge of the commons
    );

    // Add child memories
    person.memories = vec![
        create_memory("Playing with Tibor - Tibor taught me how to stack sticks to make a fort.", 0.6, true),
        create_memory("Mother's Stories - Maren tells the best stories about the old days.", 0.7, true),
        create_memory("The River - I like to watch the fish in the river.", 0.5, true),
    ];

    // Cael has high belonging for his age
    person.belonging = 0.82;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_cael_creation() {
        let cael = create_cael(1);
        
        assert_eq!(cael.id.get(), npc_ids::CAEL_IRONBARK);
        assert_eq!(cael.name, "Cael Ironbark");
        assert_eq!(cael.age.years(), 8.0);
        assert_eq!(cael.age_category, AgeCategory::Child);
    }

    #[test]
    fn test_cael_substrate() {
        let cael = create_cael(1);
        
        assert!((cael.substrate.courage_fear - 0.21).abs() < 0.01);
        assert!((cael.substrate.generosity_selfishness - 0.55).abs() < 0.01);
        assert!((cael.substrate.stability_anxiety - 0.10).abs() < 0.01);
    }

    #[test]
    fn test_cael_belonging() {
        let cael = create_cael(1);
        
        // Cael has belonging of 0.82
        assert!((cael.belonging - 0.82).abs() < 0.01);
    }

    #[test]
    fn test_cael_position() {
        let cael = create_cael(1);
        
        // Cael starts at the edge of the commons
        assert!((cael.position.z - (-3.0)).abs() < 0.1);
    }
}
