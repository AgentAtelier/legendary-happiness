//! Tibor Ironbark
//!
//! NPC Definition for Tibor Ironbark from DEMO_VISION.md §2 Named NPCs
//!
//! **Role:** Tibor is practicing Woodcraft near the long house — his morning time block
//! scores the Woodcraft action `timber_stack_reorder` at 0.71 (highest available).
//! At minute 2, he watches Dak run a Woodcraft action on the granary wall. The observation
//! learning loop fires: Tibor's `belonging` is 0.74 (above the community threshold), Dak is
//! in the same region, and the `next_f32()` roll comes up 0.18 (below the 0.25 observation
//! threshold). Tibor gains one observation credit toward unlocking `joint_cutting`.

use anvil_sim::settlement::Person;
use anvil_sim::soul::Substrate;
use glam::Vec3;
use super::{create_person_base, create_memory};
use crate::ashveil::{family_ids, npc_ids};

/// Creates Tibor Ironbark.
///
/// *Substrate:* `courage_fear: 0.0`, `generosity_selfishness: +0.62`, `stability_anxiety: -0.38`
/// (anxious but generous)
///
/// *Skill profile:* Woodcraft **Awkward** (1 affordance: timber felling). All other domains Halting.
/// Belonging: 0.74.
///
/// *Starting needs:* Sleep 0.81, Companionship 0.58, Food 0.62.
///
/// *Role in demo:* Tibor is practicing Woodcraft. When Dak evacuates and then returns, Tibor
/// watches him and may gain observation credits toward unlocking `joint_cutting`.
pub fn create_tibor(settlement_id: u64) -> Person {
    let substrate = Substrate::new(
        0.0,    // courage_fear: 0.0 (neutral)
        0.62,   // generosity_selfishness: +0.62 (generous)
        -0.38,  // stability_anxiety: -0.38 (anxious)
    );

    let mut person = create_person_base(
        npc_ids::TIBOR_IRONBARK,
        "Tibor Ironbark",
        family_ids::FAMILY_IRONBARK,
        19.0, // age 19 (Adult)
        substrate,
        settlement_id,
        Vec3::new(-15.0, 0.0, -5.0), // Position near the long house
    );

    // Add memories
    person.memories = vec![
        create_memory("Learning from Dak - Dak taught me how to stack timber properly.", 0.5, true),
        create_memory("Family Gathering - The whole family gathered for the harvest festival.", 0.6, true),
        create_memory("Anxious Night - I couldn't sleep, worrying about the storm.", 0.4, false),
    ];

    // Tibor's belonging is 0.74 as specified
    person.belonging = 0.74;

    person
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_sim::age::AgeCategory;

    #[test]
    fn test_tibor_creation() {
        let tibor = create_tibor(1);
        
        assert_eq!(tibor.id.get(), npc_ids::TIBOR_IRONBARK);
        assert_eq!(tibor.name, "Tibor Ironbark");
        assert_eq!(tibor.age.years(), 19.0);
        assert_eq!(tibor.age_category, AgeCategory::Adult);
    }

    #[test]
    fn test_tibor_substrate() {
        let tibor = create_tibor(1);
        
        assert!((tibor.substrate.courage_fear - 0.0).abs() < 0.01);
        assert!((tibor.substrate.generosity_selfishness - 0.62).abs() < 0.01);
        assert!((tibor.substrate.stability_anxiety - (-0.38)).abs() < 0.01);
    }

    #[test]
    fn test_tibor_belonging() {
        let tibor = create_tibor(1);
        
        // Tibor has belonging of 0.74 as specified
        assert!((tibor.belonging - 0.74).abs() < 0.01);
    }
}
