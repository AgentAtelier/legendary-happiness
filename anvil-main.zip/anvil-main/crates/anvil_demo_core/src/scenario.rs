//! Scenario Definition Trait
//!
//! Defines the contract for demo scenarios that can be loaded and run
//! by the simulation engine.

use anvil_sim::{DeterministicRng, SimSystem};
use anvil_world::WorldAuthored;
use std::fmt;

/// A scenario definition for the demo.
///
/// Implementations provide the complete authored world, initial simulation
/// state, and any scenario-specific systems or configurations.
pub trait ScenarioDefinition: Send + Sync {
    /// Returns the unique identifier for this scenario.
    fn id(&self) -> &'static str;

    /// Returns a human-readable name for this scenario.
    fn name(&self) -> &'static str;

    /// Returns a description of this scenario.
    fn description(&self) -> &'static str;

    /// Returns the seed to use for deterministic RNG in this scenario.
    ///
    /// This seed is used to initialize the DeterministicRng for the simulation.
    fn seed(&self) -> u64;

    /// Builds the authored world for this scenario.
    ///
    /// This world is compiled and loaded into the runtime.
    fn build_world(&self) -> WorldAuthored;

    /// Returns additional simulation systems that should be registered
    /// for this scenario.
    ///
    /// These systems are registered after the core systems (NpcSystem,
    /// CatastropheSystem, etc.) and run alongside them.
    fn systems(&self) -> Vec<Box<dyn SimSystem>> {
        Vec::new()
    }

    /// Called when the scenario is loaded, before simulation begins.
    ///
    /// Can be used to perform scenario-specific initialization.
    fn on_load(&self, _world: &WorldAuthored, _rng: &mut DeterministicRng) {}

    /// Returns the expected duration of this scenario in ticks.
    ///
    /// Used for progress tracking and sequencing.
    fn duration_ticks(&self) -> u64 {
        3600 // Default: 6 minutes at 10x speed
    }

    /// Returns the tick at which the scenario is considered "complete".
    ///
    /// This is typically when the main narrative beat finishes.
    fn completion_tick(&self) -> u64 {
        self.duration_ticks()
    }
}

impl fmt::Debug for dyn ScenarioDefinition {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ScenarioDefinition {{ id: {}, name: {}, seed: {} }}",
            self.id(),
            self.name(),
            self.seed()
        )
    }
}

/// A simple scenario loader that holds a scenario and provides access to it.
#[derive(Debug)]
pub struct ScenarioLoader {
    scenario: Box<dyn ScenarioDefinition>,
}

impl ScenarioLoader {
    /// Creates a new scenario loader with the given scenario.
    pub fn new(scenario: Box<dyn ScenarioDefinition>) -> Self {
        Self { scenario }
    }

    /// Returns the scenario ID.
    pub fn id(&self) -> &'static str {
        self.scenario.id()
    }

    /// Returns the scenario name.
    pub fn name(&self) -> &'static str {
        self.scenario.name()
    }

    /// Returns the scenario description.
    pub fn description(&self) -> &'static str {
        self.scenario.description()
    }

    /// Returns the scenario seed.
    pub fn seed(&self) -> u64 {
        self.scenario.seed()
    }

    /// Builds the world for this scenario.
    pub fn build_world(&self) -> WorldAuthored {
        self.scenario.build_world()
    }

    /// Returns additional systems for this scenario.
    pub fn systems(&self) -> Vec<Box<dyn SimSystem>> {
        self.scenario.systems()
    }

    /// Returns the scenario duration in ticks.
    pub fn duration_ticks(&self) -> u64 {
        self.scenario.duration_ticks()
    }

    /// Returns the completion tick.
    pub fn completion_tick(&self) -> u64 {
        self.scenario.completion_tick()
    }
}
