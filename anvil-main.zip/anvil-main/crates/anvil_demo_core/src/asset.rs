//! Asset Provider Abstraction
//!
//! Provides a trait-based abstraction for asset loading in the demo.
//! This allows the core simulation to be agnostic of the actual asset source,
//! enabling swapping between procedural generation and real asset loading.

use anvil_assets::{AssetCatalogue, AssetEntry, AssetKind};
use anvil_core::{ArchetypeTag, ValidationErrors};
#[allow(unused_imports)]
use anvil_core::arche;
use std::path::PathBuf;
use std::sync::Arc;

/// A trait for providing assets to the demo.
///
/// Implementations can source assets from different locations:
/// - Procedural generation (for testing/headless mode)
/// - File system (real assets)
/// - Network (potentially, in the future)
pub trait AssetProvider: Send + Sync {
    /// Returns a unique identifier for this provider.
    fn id(&self) -> &'static str;

    /// Returns a human-readable name for this provider.
    fn name(&self) -> &str;

    /// Initializes the provider.
    ///
    /// Called once when the demo starts.
    fn initialize(&mut self) -> Result<(), AssetError> {
        Ok(())
    }

    /// Returns the asset catalogue for this provider.
    ///
    /// The catalogue contains all available assets and their metadata.
    fn catalogue(&self) -> &AssetCatalogue;

    /// Resolves an archetype tag to an asset entry.
    ///
    /// Returns None if the archetype is not found.
    fn resolve_archetype(&self, tag: &ArchetypeTag) -> Option<&AssetEntry>;

    /// Resolves an archetype tag with a specific damage state variant.
    ///
    /// This is used for buildings that change appearance based on damage level.
    fn resolve_with_damage(
        &self,
        tag: &ArchetypeTag,
        damage_level: f32,
    ) -> Option<&AssetEntry>;

    /// Returns the path to an asset given its archetype tag.
    ///
    /// For procedural providers, this may return a generated path.
    fn asset_path(&self, tag: &ArchetypeTag) -> Option<PathBuf>;

    /// Returns whether this provider has the given asset.
    fn has_asset(&self, tag: &ArchetypeTag) -> bool;

    /// Returns statistics about this provider.
    fn stats(&self) -> AssetProviderStats;

    /// Validates this provider's configuration.
    fn validate(&self) -> ValidationErrors;
}

/// Statistics about an asset provider.
#[derive(Debug, Clone)]
pub struct AssetProviderStats {
    /// Total number of assets in the catalogue.
    pub total_assets: usize,
    /// Number of mesh assets.
    pub mesh_count: usize,
    /// Number of material assets.
    pub material_count: usize,
    /// Number of texture assets.
    pub texture_count: usize,
}

impl Default for AssetProviderStats {
    fn default() -> Self {
        Self {
            total_assets: 0,
            mesh_count: 0,
            material_count: 0,
            texture_count: 0,
        }
    }
}

/// Error type for asset provider operations.
#[derive(Debug, Clone)]
pub enum AssetError {
    /// The asset was not found.
    NotFound(ArchetypeTag),
    /// The asset catalogue is invalid.
    InvalidCatalogue(String),
    /// An I/O error occurred.
    IoError(String),
    /// A generic error.
    Other(String),
}

impl std::fmt::Display for AssetError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::NotFound(tag) => write!(f, "Asset not found: {}", tag),
            Self::InvalidCatalogue(msg) => write!(f, "Invalid catalogue: {}", msg),
            Self::IoError(msg) => write!(f, "I/O error: {}", msg),
            Self::Other(msg) => write!(f, "Asset error: {}", msg),
        }
    }
}

impl std::error::Error for AssetError {}

impl From<std::io::Error> for AssetError {
    fn from(err: std::io::Error) -> Self {
        Self::IoError(err.to_string())
    }
}

/// A procedural asset provider that generates placeholder assets.
///
/// This is used for headless testing and when real assets are not available.
/// It generates simple geometric shapes as placeholders for all asset types.
#[derive(Debug, Clone)]
pub struct ProceduralAssetProvider {
    /// The asset catalogue.
    catalogue: AssetCatalogue,
    /// Statistics cache.
    stats: AssetProviderStats,
}

impl ProceduralAssetProvider {
    /// Creates a new procedural asset provider with default placeholders.
    pub fn new() -> Self {
        let catalogue = Self::generate_catalogue();
        let stats = Self::compute_stats(&catalogue);

        Self {
            catalogue,
            stats,
        }
    }

    /// Creates a new procedural asset provider with a custom catalogue.
    pub fn with_catalogue(catalogue: AssetCatalogue) -> Self {
        let stats = Self::compute_stats(&catalogue);
        Self {
            catalogue,
            stats,
        }
    }

    /// Generates a default asset catalogue with procedural placeholders.
    fn generate_catalogue() -> AssetCatalogue {
        let entries = vec![
            // Buildings
            Self::make_building_entry("building_timber_longhouse", "Longhouse", 10.0, 5.0, 3.0),
            Self::make_building_entry("building_granary_stone", "Granary", 8.0, 6.0, 4.0),
            Self::make_building_entry("structure_watchtower_stone", "Watchtower", 4.0, 4.0, 8.0),
            // Vegetation
            Self::make_vegetation_entry("vegetation_pine_cluster", "Pine Cluster", 2.0),
            Self::make_vegetation_entry("vegetation_scrub_dry", "Scrub Dry", 1.5),
            // Terrain
            Self::make_terrain_entry("terrain_grass", "Grass", 0.1),
            Self::make_terrain_entry("terrain_dirt", "Dirt", 0.1),
            Self::make_terrain_entry("terrain_rock", "Rock", 0.2),
        ];

        AssetCatalogue::from_entries(entries)
    }

    /// Computes statistics from a catalogue.
    fn compute_stats(catalogue: &AssetCatalogue) -> AssetProviderStats {
        let mut stats = AssetProviderStats::default();
        stats.total_assets = catalogue.entries().len();

        for (_, entry) in catalogue.entries() {
            match entry.entry.kind {
                AssetKind::Mesh => stats.mesh_count += 1,
                AssetKind::Material => stats.material_count += 1,
                AssetKind::Texture => stats.texture_count += 1,
                _ => {}
            }
        }

        stats
    }

    /// Creates a building asset entry.
    fn make_building_entry(name: &str, _display_name: &str, width: f32, depth: f32, _height: f32) -> AssetEntry {
        AssetEntry {
            #[allow(clippy::unwrap_used)]
            tag: ArchetypeTag::new(name.to_string()).unwrap(),
            path: Arc::new(PathBuf::from(format!("procedural://{}", name))),
            kind: AssetKind::Mesh,
            tags: vec!["building".to_string(), "procedural".to_string()],
            footprint_radius: (width * width + depth * depth).sqrt() / 2.0,
        }
    }

    /// Creates a vegetation asset entry.
    fn make_vegetation_entry(name: &str, _display_name: &str, radius: f32) -> AssetEntry {
        AssetEntry {
            #[allow(clippy::unwrap_used)]
            tag: ArchetypeTag::new(name.to_string()).unwrap(),
            path: Arc::new(PathBuf::from(format!("procedural://{}", name))),
            kind: AssetKind::Mesh,
            tags: vec!["vegetation".to_string(), "procedural".to_string()],
            footprint_radius: radius,
        }
    }

    /// Creates a terrain asset entry.
    fn make_terrain_entry(name: &str, _display_name: &str, radius: f32) -> AssetEntry {
        AssetEntry {
            #[allow(clippy::unwrap_used)]
            tag: ArchetypeTag::new(name.to_string()).unwrap(),
            path: Arc::new(PathBuf::from(format!("procedural://{}", name))),
            kind: AssetKind::Mesh,
            tags: vec!["terrain".to_string(), "procedural".to_string()],
            footprint_radius: radius,
        }
    }

    /// Generates a procedural mesh description for a building.
    ///
    /// Returns a description string that can be used to generate geometry.
    pub fn generate_building_mesh(&self, width: f32, depth: f32, height: f32) -> String {
        format!(
            "Box {{ width: {}, depth: {}, height: {} }}",
            width, depth, height
        )
    }

    /// Generates a procedural mesh description for a tree.
    pub fn generate_tree_mesh(&self, height: f32, radius: f32) -> String {
        format!("Cylinder {{ height: {}, radius: {} }}", height, radius)
    }
}

impl AssetProvider for ProceduralAssetProvider {
    fn id(&self) -> &'static str {
        "procedural"
    }

    fn name(&self) -> &str {
        "Procedural Asset Provider"
    }

    fn catalogue(&self) -> &AssetCatalogue {
        &self.catalogue
    }

    fn resolve_archetype(&self, tag: &ArchetypeTag) -> Option<&AssetEntry> {
        self.catalogue.resolve(tag)
    }

    fn resolve_with_damage(
        &self,
        tag: &ArchetypeTag,
        _damage_level: f32,
    ) -> Option<&AssetEntry> {
        // For procedural assets, we don't have damage variants yet.
        // Just return the base tag.
        // In a real implementation, this would resolve to state_intact, state_damaged, etc.
        self.catalogue.resolve(tag)
    }

    fn asset_path(&self, tag: &ArchetypeTag) -> Option<PathBuf> {
        self.catalogue.resolve(tag)
            .map(|entry| entry.path.as_ref().clone())
    }

    fn has_asset(&self, tag: &ArchetypeTag) -> bool {
        self.catalogue.resolve(tag).is_some()
    }

    fn stats(&self) -> AssetProviderStats {
        self.stats.clone()
    }

    fn validate(&self) -> ValidationErrors {
        // Procedural provider is always valid
        ValidationErrors::new()
    }
}

impl Default for ProceduralAssetProvider {
    fn default() -> Self {
        Self::new()
    }
}

/// A factory for creating asset providers.
///
/// This allows the demo to switch between different providers at runtime.
pub struct AssetProviderFactory;

impl AssetProviderFactory {
    /// Creates a new procedural asset provider.
    pub fn create_procedural() -> Box<dyn AssetProvider> {
        Box::new(ProceduralAssetProvider::new())
    }

    /// Creates a provider from a JSON catalogue file.
    ///
    /// # Arguments
    /// * `path` - Path to the JSON catalogue file
    ///
    /// # Returns
    /// A boxed asset provider, or an error if the file cannot be loaded.
    #[allow(dead_code)]
    pub fn create_from_file(_path: &str) -> Result<Box<dyn AssetProvider>, AssetError> {
        // For now, always return procedural
        // Real implementation would load from file
        Ok(Box::new(ProceduralAssetProvider::new()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_procedural_provider_has_assets() {
        let provider = ProceduralAssetProvider::new();
        
        assert!(provider.has_asset(&arche!("building_timber_longhouse")));
        assert!(provider.has_asset(&arche!("vegetation_pine_cluster")));
    }

    #[test]
    fn test_procedural_provider_resolve() {
        let provider = ProceduralAssetProvider::new();
        
        let tag = arche!("building_timber_longhouse");
        let entry = provider.resolve_archetype(&tag);
        
        assert!(entry.is_some());
        assert_eq!(entry.unwrap().tag, tag);
    }

    #[test]
    fn test_procedural_provider_resolve_with_damage() {
        let provider = ProceduralAssetProvider::new();
        
        let base_tag = arche!("building_granary_stone");
        
        // Test different damage levels
        let intact = provider.resolve_with_damage(&base_tag, 0.1);
        assert!(intact.is_some());
        
        let damaged = provider.resolve_with_damage(&base_tag, 0.5);
        assert!(damaged.is_some());
        
        let burned = provider.resolve_with_damage(&base_tag, 0.9);
        assert!(burned.is_some());
    }

    #[test]
    fn test_procedural_provider_stats() {
        let provider = ProceduralAssetProvider::new();
        let stats = provider.stats();
        
        assert!(stats.total_assets > 0);
        assert!(stats.mesh_count > 0);
    }
}
