//! Integration Test for Sprint 18c
//!
//! Tests the integration of:
//! - Multi-axis emotional state (Task 1)
//! - Continuous age curves (Task 2)
//! - Sigmoid time curves (Task 3)
//! - Children's system foundation (Task 4)
//! - Integration hooks: age/time/emotion modifiers in practice/decay (Task 5)
//!
//! Test scenario: 20 NPCs, mixed ages (5-80), one settlement, 2000 ticks
//! Earthquake at tick 1000

use anvil_core::RegionId;
use anvil_sim::age::Age;
use anvil_sim::settlement::{Family, FamilyId, Person, PersonId, Settlement, SettlementId};
use anvil_sim::soul::{EmotionalState, Substrate};
use anvil_sim::system::NpcSystem;
use anvil_sim::{WorldEnv, SimContext, SimSystem, WorldRuntime, DeterministicRng};

/// Creates a test person with a specific age.
fn create_test_person(id: u64, name: &str, age_years: f32, settlement_id: u64) -> Person {
    use glam::Vec3;
    Person::new(
        PersonId::new(id),
        name.to_string(),
        FamilyId::new(1),
        Age::from_years(age_years),
        Substrate::neutral(),
        EmotionalState::neutral(),
        vec![],
        vec![],
        vec![],
        anvil_sim::skill::SkillProfile::new(),
        None,
        0,
        0,
        settlement_id,
        0.5,
        Vec3::ZERO,
    )
}

/// Creates a test settlement with 20 NPCs of mixed ages (5-80).
fn create_test_npc_system() -> NpcSystem {
    let settlement = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Test Settlement".to_string(),
        RegionId::new(1),
        20,
    );

    let mut settlement = settlement;
    settlement.food_store = 0.8;
    settlement.materials = 0.5;
    settlement.structural_integrity = 1.0;

    // Create 20 NPCs with ages from 5 to 80
    // Mix of children, adults, and elders
    let ages_years = vec![
        5.0, 6.0, 7.0, 8.0, 9.0,       // Children (5-12)
        15.0, 16.0, 20.0, 25.0, 30.0, 35.0, // Adults (13-64)
        40.0, 45.0, 50.0, 55.0, 60.0, // Middle-aged adults
        65.0, 70.0, 75.0, 80.0,       // Elders (65+)
    ];

    let mut persons = Vec::new();
    let mut family_members = Vec::new();

    for (i, age_years) in ages_years.into_iter().enumerate() {
        let person = create_test_person(i as u64 + 1, &format!("NPC_{}", i + 1), age_years, 1);
        persons.push(person);
        family_members.push(PersonId::new(i as u64 + 1));
    }

    let families = vec![Family::new(FamilyId::new(1), family_members)];

    let mut system = NpcSystem::new();
    system.settlements = vec![settlement];
    system.persons = persons;
    system.families = families;

    system
}

#[test]
fn test_sprint_18c_integration() {
    let mut system = create_test_npc_system();
    let mut world = WorldRuntime::new(anvil_world::WorldAuthored::default());
    let mut rng = DeterministicRng::new(42);

    // Initialize need satisfaction for all persons
    for person in &system.persons {
        let person_id = person.id.get();
        system.need_satisfaction.insert(person_id, [0.5; 7]);
    }

    // Record initial settlement state
    let initial_structural_integrity = system.settlements[0].structural_integrity;

    // Run simulation for 2000 ticks
    // Earthquake happens at tick 1000
    let earthquake_tick = 1000;

    for tick in 1..=2000 {
        let mut events_out = Vec::new();
        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(
            tick,
            1000,
            &mut rng,
            &mut world,
            &world_env,
            &[],
            &mut events_out,
        );

        // Trigger earthquake at tick 1000
        if tick == earthquake_tick {
            // Simulate earthquake damage
            system.settlements[0].structural_integrity = 0.5;
        }

        system.tick(&mut ctx).unwrap();
    }

    // ========================================================================
    // Assertion 1: Children (age < 13) exist in the population
    // ========================================================================
    let child_count = system.persons.iter()
        .filter(|p| p.age.to_age_category() == anvil_sim::age::AgeCategory::Child)
        .count();
    assert!(child_count >= 5, "Expected at least 5 children, got {}", child_count);

    // ========================================================================
    // Assertion 2: Elders (age >= 65) exist in the population
    // ========================================================================
    let elder_count = system.persons.iter()
        .filter(|p| p.age.to_age_category() == anvil_sim::age::AgeCategory::Elder)
        .count();
    assert!(elder_count >= 4, "Expected at least 4 elders, got {}", elder_count);

    // ========================================================================
    // Assertion 3: After earthquake, settlement structural integrity is reduced
    // ========================================================================
    assert!(
        system.settlements[0].structural_integrity < initial_structural_integrity,
        "Earthquake should have reduced structural integrity"
    );

    // ========================================================================
    // Assertion 4: Children have learning rate multipliers appropriate for their age
    // ========================================================================
    for person in &system.persons {
        let age_category = person.age.to_age_category();
        let learning_multiplier = person.age.learning_rate_multiplier();

        if age_category == anvil_sim::age::AgeCategory::Child {
            // Children (5-12) should have learning rate >= 0.5 and <= 2.0
            assert!(
                (0.5..=2.0).contains(&learning_multiplier),
                "Child age {} has unexpected learning rate multiplier: {}",
                person.age.days,
                learning_multiplier
            );
        } else if age_category == anvil_sim::age::AgeCategory::Adult {
            // Adults should have learning rate around 0.5-2.0 (peak at ~16-25)
            assert!(
                (0.4..=2.0).contains(&learning_multiplier),
                "Adult age {} has unexpected learning rate multiplier: {}",
                person.age.days,
                learning_multiplier
            );
        } else if age_category == anvil_sim::age::AgeCategory::Elder {
            // Elders should have reduced learning rate
            assert!(
                (0.3..1.0).contains(&learning_multiplier),
                "Elder age {} has unexpected learning rate multiplier: {}",
                person.age.days,
                learning_multiplier
            );
        }
    }

    // ========================================================================
    // Assertion 5: Physical capability varies by age
    // ========================================================================
    let mut found_low_physical = false;
    let mut found_high_physical = false;

    for person in &system.persons {
        let physical_cap = person.age.physical_capability();
        if physical_cap < 0.5 {
            found_low_physical = true;
        }
        if physical_cap >= 0.9 {
            found_high_physical = true;
        }
    }

    assert!(found_low_physical, "Expected some NPCs with low physical capability (children/elders)");
    assert!(found_high_physical, "Expected some NPCs with high physical capability (young adults)");

    // ========================================================================
    // Assertion 6: Time learning modifiers work correctly
    // ========================================================================
    use anvil_sim::time;
    use anvil_sim::skill::domain::SkillDomain;

    // Dawn (0.175) should give +20% for perception skills
    let dawn_modifier = time::time_learning_modifier(0.175, SkillDomain::WeatherSense);
    assert!(
        (dawn_modifier - 1.2).abs() < 0.05,
        "Dawn perception modifier should be ~1.2, got {}",
        dawn_modifier
    );

    // Midday (0.375) should give +10% for physical skills
    let midday_modifier = time::time_learning_modifier(0.375, SkillDomain::Woodcraft);
    assert!(
        (midday_modifier - 1.1).abs() < 0.05,
        "Midday physical modifier should be ~1.1, got {}",
        midday_modifier
    );

    // Night (0.85) should give 0.3x for all skills
    let night_modifier = time::time_learning_modifier(0.85, SkillDomain::Woodcraft);
    assert!(
        (night_modifier - 0.3).abs() < 0.05,
        "Night modifier should be ~0.3, got {}",
        night_modifier
    );
}
