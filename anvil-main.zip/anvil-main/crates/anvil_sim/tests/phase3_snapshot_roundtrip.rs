//! Phase 3 Snapshot/Restore Round-Trip Gate Test
//!
//! This test verifies that simulation state can be snapshotted and restored,
//! producing identical results to an uninterrupted simulation.
//!
//! # Test Structure
//!
//! - Run a 5,000-tick simulation with all Phase 3 systems
//! - At tick 2,500, take a full snapshot of all systems
//! - Restore from the snapshot into a fresh simulation
//! - Run the restored simulation for 2,500 more ticks
//! - Compare the state hash after 5,000 total ticks against the uninterrupted run
//! - Assert identical state hashes
//!
//! # Note
//!
//! Currently, only PhysicsSystem has full snapshot/restore support via SimSnapshot.
//! The other systems (NpcSystem, CatastropheSystem, JoySystem) store their state
//! in memory and are not serialized. This is a known gap in Phase 3 that should
//! be addressed before Phase 4. This test verifies the infrastructure that does
//! exist and provides a framework for testing additional systems as they gain
//! snapshot support.

use anvil_core::RegionId;
use anvil_sim::age::Age;
use anvil_sim::catastrophe::event::CatastropheType;
use anvil_sim::settlement::ids::{FamilyId, PersonId, SettlementId};
use anvil_sim::settlement::{Family, Person, Settlement};
use anvil_sim::soul::{EmotionalState, EmotionalAxes, Substrate};
use anvil_sim::system::catastrophe::CatastropheSystem;
use anvil_sim::system::joy::JoySystem;
use anvil_sim::system::npc::NpcSystem;
use anvil_sim::system::physics::PhysicsSystem;
use anvil_sim::{WorldEnv, DeterministicRng, SimContext, SimSystem, WorldRuntime};
use anvil_world::WorldAuthored;
use glam::Vec3;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

/// Number of ticks for the full simulation.
const NUM_TICKS: u64 = 5000;

/// Snapshot at the halfway point.
const SNAPSHOT_TICK: u64 = 2500;

/// Number of NPCs to create.
const NUM_NPCS: usize = 50;

/// Fixed physics time step.
const PHYSICS_STEP: f32 = 1.0 / 60.0;

/// Creates a deterministic world runtime.
fn create_world_runtime() -> WorldRuntime {
    WorldRuntime::new(WorldAuthored::default())
}

/// Creates a settlement with default values.
fn create_settlement(id: SettlementId, region_id: RegionId, population: u32) -> Settlement {
    Settlement::new_with_defaults(id, format!("Settlement {}", id.0), region_id, population)
}

/// Creates a family with default values.
fn create_family(id: FamilyId) -> Family {
    Family::new(id, Vec::new())
}

/// Creates a person with varied age, substrate, and emotional state.
#[allow(clippy::too_many_arguments)]
fn create_person(
    id: PersonId,
    name: String,
    family_id: FamilyId,
    age_years: f32,
    substrate: Substrate,
    emotional_axes: EmotionalAxes,
    settlement_id: u64,
    position: Vec3,
) -> Person {
    let age = Age::from_years(age_years);
    let emotional_state = EmotionalState::new(emotional_axes);

    Person::new(
        id,
        name,
        family_id,
        age,
        substrate,
        emotional_state,
        Vec::new(),
        Vec::new(),
        Vec::new(),
        anvil_sim::skill::profile::SkillProfile::new(),
        None,
        0,
        0,
        settlement_id,
        0.5, // belonging
        position,
    )
}

/// Simulates up to the snapshot tick and returns the state.
fn simulate_to_snapshot(seed: u64) -> (PhysicsSystem, Vec<u8>) {
    let mut rng = DeterministicRng::new(seed);
    let mut world = create_world_runtime();
    let mut events_out = vec![];

    // Create systems
    let mut physics_system = PhysicsSystem::new();
    let mut npc_system = NpcSystem::new();
    let mut catastrophe_system = CatastropheSystem::new();
    let mut joy_system = JoySystem::new();

    // Create settlement
    let settlement_id = SettlementId::new(1);
    let region_id = RegionId::new(1);
    let settlement = create_settlement(settlement_id, region_id, NUM_NPCS as u32);

    // Create families
    let family_id = FamilyId::new(1);
    let family = create_family(family_id);

    // Create NPCs with varied properties
    let mut persons = Vec::new();
    for i in 0..NUM_NPCS {
        let person_id = PersonId::new(i as u64 + 1);
        let age_years = 5.0 + (i as f32 / NUM_NPCS as f32) * 75.0;
        
        let substrate = Substrate::new(
            rng.next_f32_range(-1.0, 1.0),
            rng.next_f32_range(-1.0, 1.0),
            rng.next_f32_range(-1.0, 1.0),
        );

        let emotional_axes = EmotionalAxes::new(
            rng.next_f32_range(-1.0, 1.0),
            rng.next_f32_range(-1.0, 1.0),
            rng.next_f32_range(-1.0, 1.0),
            rng.next_f32_range(-1.0, 1.0),
        );

        // Generate a deterministic position for each NPC
        let angle = (i as f32 / NUM_NPCS as f32) * std::f32::consts::TAU;
        let radius = 10.0 + (i as f32 % 5.0);
        let position = Vec3::new(
            radius * angle.cos(),
            0.0,
            radius * angle.sin(),
        );

        let person = create_person(
            person_id,
            format!("Person {}", i + 1),
            family_id,
            age_years,
            substrate,
            emotional_axes,
            settlement_id.0,
            position,
        );
        persons.push(person);
    }

    // Add to systems
    npc_system.settlements.push(settlement.clone());
    npc_system.families.push(family.clone());
    npc_system.persons = persons.clone();

    joy_system.add_settlement(settlement);
    joy_system.persons = persons;
    joy_system.families.push(family);

    // Simulate to the snapshot tick
    for tick in 0..SNAPSHOT_TICK {
        let dt_micros = (PHYSICS_STEP * 1_000_000.0) as u64;
        events_out.clear();

        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(
            tick,
            dt_micros,
            &mut rng,
            &mut world,
            &world_env,
            &[],
            &mut events_out,
        );

        // Trigger catastrophes at specified ticks (before snapshot)
        if tick == 500 {
            let _event = catastrophe_system.trigger_catastrophe(
                CatastropheType::Flood,
                Vec3::new(0.0, 0.0, 0.0),
                0.5,
                100.0,
                tick,
            );
        }

        // Tick all systems
        let _ = physics_system.tick(&mut ctx);
        let _ = npc_system.tick(&mut ctx);
        let _ = catastrophe_system.tick(&mut ctx);
        let _ = joy_system.tick(&mut ctx);
    }

    // Take snapshot of physics system
    let snapshot_data = physics_system.snapshot().expect("Failed to snapshot physics");

    (physics_system, snapshot_data)
}

/// Computes a state hash from the physics system.
fn compute_physics_state_hash(physics_system: &PhysicsSystem) -> u64 {
    let mut hasher = DefaultHasher::new();
    
    // Hash player position if exists
    if let Some(pos) = physics_system.player_position() {
        pos.x.to_bits().hash(&mut hasher);
        pos.y.to_bits().hash(&mut hasher);
        pos.z.to_bits().hash(&mut hasher);
    }
    
    // Hash player velocity if exists
    if let Some(vel) = physics_system.player_velocity() {
        vel.x.to_bits().hash(&mut hasher);
        vel.y.to_bits().hash(&mut hasher);
        vel.z.to_bits().hash(&mut hasher);
    }
    
    // Hash gravity
    physics_system.gravity[0].to_bits().hash(&mut hasher);
    physics_system.gravity[1].to_bits().hash(&mut hasher);
    physics_system.gravity[2].to_bits().hash(&mut hasher);
    
    // Hash accumulated time
    physics_system.accumulated_time.to_bits().hash(&mut hasher);
    
    // Hash number of region colliders
    physics_system.region_colliders.len().hash(&mut hasher);
    
    hasher.finish()
}

#[test]
fn test_physics_snapshot_roundtrip_full_simulation() {
    let seed = 42;
    
    // Run to snapshot point
    let (mut original_physics, snapshot_data) = simulate_to_snapshot(seed);
    let hash_at_snapshot = compute_physics_state_hash(&original_physics);
    
    // Restore from snapshot
    let mut restored_physics = PhysicsSystem::new();
    restored_physics.restore(&snapshot_data).expect("Failed to restore physics");
    let hash_after_restore = compute_physics_state_hash(&restored_physics);
    
    // Hashes should match immediately after restore
    assert_eq!(
        hash_at_snapshot, hash_after_restore,
        "Physics state hash should match immediately after restore"
    );
    
    // Continue simulation from both states for remaining ticks
    let mut rng1 = DeterministicRng::new(seed);
    let mut rng2 = DeterministicRng::new(seed);
    let mut world1 = create_world_runtime();
    let mut world2 = create_world_runtime();
    let mut events_out = vec![];
    
    // Advance RNGs to the snapshot point
    for _ in 0..SNAPSHOT_TICK {
        rng1.next_u64();
        rng2.next_u64();
    }
    
    // Continue original simulation
    for tick in SNAPSHOT_TICK..NUM_TICKS {
        let dt_micros = (PHYSICS_STEP * 1_000_000.0) as u64;
        events_out.clear();
        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(
            tick,
            dt_micros,
            &mut rng1,
            &mut world1,
            &world_env,
            &[],
            &mut events_out,
        );
        let _ = original_physics.tick(&mut ctx);
    }
    
    // Continue restored simulation
    for tick in SNAPSHOT_TICK..NUM_TICKS {
        let dt_micros = (PHYSICS_STEP * 1_000_000.0) as u64;
        events_out.clear();
        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(
            tick,
            dt_micros,
            &mut rng2,
            &mut world2,
            &world_env,
            &[],
            &mut events_out,
        );
        let _ = restored_physics.tick(&mut ctx);
    }
    
    // Final state hashes should match
    let final_hash_original = compute_physics_state_hash(&original_physics);
    let final_hash_restored = compute_physics_state_hash(&restored_physics);
    
    assert_eq!(
        final_hash_original, final_hash_restored,
        "Physics state hash should match after full simulation"
    );
}

#[test]
fn test_snapshot_data_not_empty() {
    let seed = 42;
    let (physics_system, snapshot_data) = simulate_to_snapshot(seed);
    
    assert!(!snapshot_data.is_empty(), "Snapshot data should not be empty");
    assert!(snapshot_data.len() > 100, "Snapshot data should be substantial in size");
    
    // Verify we can restore
    let mut restored = PhysicsSystem::new();
    restored.restore(&snapshot_data).expect("Should be able to restore");
    assert_eq!(restored.name(), physics_system.name());
}
