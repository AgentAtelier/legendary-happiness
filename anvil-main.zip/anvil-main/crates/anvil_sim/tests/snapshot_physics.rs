//! Snapshot/restore round-trip tests for PhysicsSystem.

#![deny(warnings)]

use anvil_sim::{PhysicsSaveState, PhysicsSystem, SimSystem};
use glam::Vec3;

/// Helper to create a physics system with some state
fn create_physics_world_with_state() -> PhysicsSystem {
    let mut system = PhysicsSystem::new();
    
    // Create ground plane (already done by new())
    
    // Create player
    system.create_player(Vec3::new(0.0, 10.0, 0.0), 0.5, 1.8);
    
    // Create some terrain
    system.create_terrain_colliders(1, Vec3::new(100.0, 20.0, 100.0), 10.0, Vec3::new(0.0, -5.0, 0.0));
    system.create_terrain_colliders(2, Vec3::new(100.0, 20.0, 100.0), 10.0, Vec3::new(100.0, -5.0, 0.0));
    
    // Simulate a few steps so the player falls a bit
    for _ in 0..10 {
        system.step(1.0 / 60.0);
    }
    
    system
}

#[test]
fn test_physics_snapshot_roundtrip() {
    let original = create_physics_world_with_state();
    
    // Save the state
    let snapshot_data = original.snapshot().expect("Failed to snapshot");
    let mut restored = PhysicsSystem::new();
    restored.restore(&snapshot_data).expect("Failed to restore");
    
    // Verify basic properties match
    assert_eq!(restored.name(), original.name());
    assert_eq!(restored.priority(), original.priority());
    
    // Verify player was restored
    assert!(restored.player_handle().is_some());
    
    // Verify terrain colliders were restored
    assert_eq!(restored.region_colliders().len(), original.region_colliders().len());
    assert!(restored.region_colliders().contains_key(&1));
    assert!(restored.region_colliders().contains_key(&2));
    
    // Verify ground body/collider exist
    assert!(restored.ground_body_handle().is_some());
    assert!(restored.ground_collider_handle().is_some());
}

#[test]
fn test_physics_snapshot_preserves_gravity() {
    let mut original = create_physics_world_with_state();
    
    // Set custom gravity
    original.set_gravity(Vec3::new(0.0, -5.0, 0.0));
    
    // Save and restore
    let snapshot_data = original.snapshot().expect("Failed to snapshot");
    let mut restored = PhysicsSystem::new();
    restored.restore(&snapshot_data).expect("Failed to restore");
    
    // Verify gravity was preserved
    let restored_gravity = restored.gravity();
    assert!((restored_gravity.x - 0.0).abs() < 0.001);
    assert!((restored_gravity.y - (-5.0)).abs() < 0.001);
    assert!((restored_gravity.z - 0.0).abs() < 0.001);
}

#[test]
fn test_physics_snapshot_preserves_body_state() {
    let mut original = create_physics_world_with_state();
    
    // Simulate more so player has some velocity
    for _ in 0..20 {
        original.step(1.0 / 60.0);
    }
    
    let original_position = original.player_position().unwrap();
    let original_velocity = original.player_velocity().unwrap();
    
    // Save and restore
    let snapshot_data = original.snapshot().expect("Failed to snapshot");
    let mut restored = PhysicsSystem::new();
    restored.restore(&snapshot_data).expect("Failed to restore");
    
    let restored_position = restored.player_position().unwrap();
    let restored_velocity = restored.player_velocity().unwrap();
    
    // Positions should be close (within 0.01)
    assert!((original_position.x - restored_position.x).abs() < 0.01);
    assert!((original_position.y - restored_position.y).abs() < 0.01);
    assert!((original_position.z - restored_position.z).abs() < 0.01);
    
    // Velocities should be close (within 0.01)
    assert!((original_velocity.x - restored_velocity.x).abs() < 0.01);
    assert!((original_velocity.y - restored_velocity.y).abs() < 0.01);
    assert!((original_velocity.z - restored_velocity.z).abs() < 0.01);
}

#[test]
fn test_physics_save_state_creation() {
    let system = create_physics_world_with_state();
    
    let save_state = system.to_save_state();
    
    // Verify basic properties
    assert_eq!(save_state.physics_version, 1);
    assert!((save_state.gravity[0] - 0.0).abs() < 0.001);
    assert!((save_state.gravity[1] - (-9.81)).abs() < 0.001);
    assert!((save_state.gravity[2] - 0.0).abs() < 0.001);
    
    // Should have ground body
    assert!(save_state.ground_body_handle.is_some());
    
    // Should have rigid bodies (ground + player)
    assert!(save_state.rigid_bodies.len() >= 2);
    
    // Should have colliders (ground + player + 2 terrain)
    assert!(save_state.colliders.len() >= 4);
    
    // Should have player handle
    assert!(save_state.player_handle.is_some());
    
    // Should have region colliders
    assert!(save_state.region_colliders.contains_key(&1));
    assert!(save_state.region_colliders.contains_key(&2));
}

#[test]
fn test_physics_default_state() {
    let default = PhysicsSaveState::default_with_ground_plane();
    
    assert_eq!(default.physics_version, 1);
    assert!((default.gravity[0] - 0.0).abs() < 0.001);
    assert!((default.gravity[1] - (-9.81)).abs() < 0.001);
    assert!((default.gravity[2] - 0.0).abs() < 0.001);
    assert_eq!(default.accumulated_time, 0.0);
    assert!(default.rigid_bodies.is_empty());
    assert!(default.colliders.is_empty());
    assert!(default.region_colliders.is_empty());
    assert!(default.player_handle.is_none());
}

#[test]
fn test_physics_snapshot_with_multiple_bodies() {
    let mut system = PhysicsSystem::new();
    
    // Create player
    system.create_player(Vec3::new(0.0, 10.0, 0.0), 0.5, 1.8);
    
    // Create multiple terrain regions
    for i in 0..5 {
        system.create_terrain_colliders(
            i as u64,
            Vec3::new(50.0, 20.0, 50.0),
            10.0,
            Vec3::new(i as f32 * 100.0, -5.0, 0.0),
        );
    }
    
    // Save state
    let save_state = system.to_save_state();
    
    // Should have ground + player = 2 rigid bodies
    assert!(save_state.rigid_bodies.len() >= 2);
    
    // Should have ground + player + 5 terrain = 7+ colliders
    assert!(save_state.colliders.len() >= 7);
    
    // Should have 5 region colliders
    assert_eq!(save_state.region_colliders.len(), 5);
    
    // Roundtrip
    let snapshot_data = system.snapshot().expect("Failed to snapshot");
    let mut restored = PhysicsSystem::new();
    restored.restore(&snapshot_data).expect("Failed to restore");
    
    assert_eq!(restored.region_colliders().len(), 5);
}
