//! Skill System Determinism Test
//!
//! Sprint 18a Task 9: Verifies that the skill system produces deterministic results
//! given the same input sequence and RNG seed.
//!
//! Test procedure:
//! 1. Initialise 10 NPCs with fresh skill profiles (all maturities 0.0).
//! 2. Run 1,000 ticks with a fixed RNG seed.
//! 3. Execute a scripted sequence of actions per NPC.
//! 4. Record all maturity values and unlock events.
//! 5. Run a second identical simulation with the same seed.
//! 6. Assert all maturity values and unlock event sequences are byte-identical.

use anvil_core::RegionId;
use anvil_sim::{WorldEnv, DeterministicRng, NpcSystem, SimContext, SimEvent, SimSystem, WorldRuntime};
use anvil_sim::settlement::{FamilyId, Person, Settlement, SettlementId};
use anvil_sim::skill::SkillEvent;
use anvil_world::WorldAuthored;

/// Creates a test settlement.
fn create_test_settlement(id: u64) -> Settlement {
    Settlement::new_with_defaults(
        SettlementId::new(id),
        format!("Test Settlement {}", id),
        RegionId::new(0),
        50,
    )
}

/// Creates a test person with a scripted action pattern.
fn create_test_person(id: u64, family_id: u64, _action_pattern: Vec<u64>) -> Person {
    use anvil_sim::age::Age;
    use anvil_sim::soul::{EmotionalState, Substrate};
    use anvil_sim::skill::SkillProfile;
    use glam::Vec3;
    
    // Create a person with empty skill profile (will be initialized by NpcSystem)
    Person::new(
        anvil_sim::settlement::ids::PersonId::new(id),
        format!("Person {}", id),
        FamilyId::new(family_id),
        Age::from_years(20.0),
        Substrate::neutral(),
        EmotionalState::neutral(),
        vec![],
        vec![],
        vec![],
        SkillProfile::new(),
        None,
        0,
        0,
        0,
        0.5,
        Vec3::ZERO,
    )
}

/// Runs a simulation with the given RNG seed and returns the skill state.
fn run_simulation(seed: u64, num_ticks: u64) -> (NpcSystem, Vec<SkillEvent>) {
    let mut system = NpcSystem::new();
    
    // Create a settlement
    let settlement = create_test_settlement(1);
    system.add_settlement(settlement);
    
    // Create 10 NPCs
    for i in 0..10 {
        let person = create_test_person(i as u64 + 1, 1, vec![]);
        system.add_person(person);
    }
    
    // Set all NPCs to belong to settlement 1
    for person in &mut system.persons {
        person.settlement_id = 1;
    }
    
    // Track unlock events
    let mut all_skill_events = Vec::new();
    
    // Create world runtime
    let mut world = WorldRuntime::new(WorldAuthored::default());
    let mut rng = DeterministicRng::new(seed);
    
    // Run simulation for num_ticks
    for tick in 1..=num_ticks {
        let events_in: Vec<SimEvent> = Vec::new();
        let mut events_out: Vec<SimEvent> = Vec::new();
        
        // Manually trigger some actions for testing before creating context
        // For this determinism test, we'll have each NPC perform specific actions
        if tick % 100 == 0 {
            for person in system.persons.iter_mut() {
                // Assign an action based on RNG to ensure different seeds produce different results
                let action_idx = (rng.next_u64() % 5) as usize;
                let action_id = match action_idx {
                    0 => 1,  // Farm/Tend
                    1 => 2,  // Hunt
                    2 => 8,  // Build/Repair
                    3 => 17, // Tell Story
                    _ => 7,  // Fetch Water
                };
                
                // Start the action
                person.current_action_id = Some(action_id);
                person.current_action_remaining_ticks = 1; // Will complete next tick
            }
        }
        
        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(tick, 1000, &mut rng, &mut world, &world_env, &events_in, &mut events_out);
        
        // Tick the system
        system.tick(&mut ctx).unwrap();
        
        // Collect skill events
        all_skill_events.append(&mut system.pending_skill_events);
    }
    
    (system, all_skill_events)
}

#[test]
fn test_skill_system_determinism() {
    // Run first simulation with seed 42
    let seed = 42;
    let (system1, events1) = run_simulation(seed, 1000);
    
    // Extract maturity values from first run
    // Use BTreeMap for deterministic ordering (person_id, affordance_id) -> maturity
    use std::collections::BTreeMap;
    let mut maturities1: BTreeMap<(u64, u32), f32> = BTreeMap::new();
    for person in &system1.persons {
        for (affordance_id, state) in &person.skill_profile.maturities {
            maturities1.insert((person.id.get(), affordance_id.get()), state.maturity);
        }
    }
    
    // Extract unlock events from first run
    let mut unlock_events1: Vec<(u64, u32)> = Vec::new();
    for event in &events1 {
        if let SkillEvent::AffordanceUnlocked { person_id, affordance_id } = event {
            unlock_events1.push((person_id.get(), affordance_id.get()));
        }
    }
    unlock_events1.sort();
    
    // Run second simulation with same seed
    let (system2, events2) = run_simulation(seed, 1000);
    
    // Extract maturity values from second run
    let mut maturities2: BTreeMap<(u64, u32), f32> = BTreeMap::new();
    for person in &system2.persons {
        for (affordance_id, state) in &person.skill_profile.maturities {
            maturities2.insert((person.id.get(), affordance_id.get()), state.maturity);
        }
    }
    
    // Extract unlock events from second run
    let mut unlock_events2: Vec<(u64, u32)> = Vec::new();
    for event in &events2 {
        if let SkillEvent::AffordanceUnlocked { person_id, affordance_id } = event {
            unlock_events2.push((person_id.get(), affordance_id.get()));
        }
    }
    unlock_events2.sort();
    
    // Assert maturity values are identical
    assert_eq!(maturities1, maturities2, "Maturity values differ between runs");
    
    // Assert unlock events are identical
    assert_eq!(unlock_events1, unlock_events2, "Unlock events differ between runs");
    
    // Also verify that some learning happened
    assert!(!maturities1.is_empty(), "No maturity values recorded");
    
    // Check that at least some affordances were practiced
    let practiced_count = maturities1.values().filter(|&&m| m > 0.0).count();
    assert!(practiced_count > 0, "No affordances were practiced");
}

#[test]
fn test_skill_system_different_seeds_different_results() {
    // Run simulation with seed 42
    let (system1, _events1) = run_simulation(42, 1000);
    
    // Run simulation with seed 123
    let (system2, _events2) = run_simulation(123, 1000);
    
    // Extract maturity values
    use std::collections::BTreeMap;
    let mut maturities1: BTreeMap<(u64, u32), f32> = BTreeMap::new();
    for person in &system1.persons {
        for (affordance_id, state) in &person.skill_profile.maturities {
            maturities1.insert((person.id.get(), affordance_id.get()), state.maturity);
        }
    }
    
    let mut maturities2: BTreeMap<(u64, u32), f32> = BTreeMap::new();
    for person in &system2.persons {
        for (affordance_id, state) in &person.skill_profile.maturities {
            maturities2.insert((person.id.get(), affordance_id.get()), state.maturity);
        }
    }
    
    // Different seeds should produce different results
    // (unless by chance they're the same, which is very unlikely with 1000 ticks)
    assert_ne!(maturities1, maturities2, "Different seeds should produce different maturity values");
}

#[test]
fn test_skill_practice_deterministic() {
    use anvil_sim::skill::{SkillProfile, AffordanceId};
    use anvil_sim::skill::practice::apply_practice;
    use anvil_sim::skill::catalogue::affordance_catalogue;
    use anvil_sim::skill::event::{SkillEvent, ActionOutcome, ContextModifiers};
    use anvil_sim::settlement::ids::PersonId;
    
    let catalogue = affordance_catalogue();
    
    // Create two identical profiles
    let mut profile1 = SkillProfile::new();
    let mut profile2 = SkillProfile::new();
    
    // Add same affordances
    let affordance_id = AffordanceId::new(20); // soil_moisture_reading
    profile1.add_affordance(affordance_id);
    profile2.add_affordance(affordance_id);
    
    // Apply same practice event
    let event = SkillEvent::ActionCompleted {
        person_id: PersonId::new(1),
        affordance_id,
        outcome: ActionOutcome::Success,
        context_modifiers: ContextModifiers::new(),
    };
    
    apply_practice(&mut profile1, &event, &catalogue, 100);
    apply_practice(&mut profile2, &event, &catalogue, 100);
    
    // Maturity values should be identical
    let maturity1 = profile1.get_maturity_value(affordance_id);
    let maturity2 = profile2.get_maturity_value(affordance_id);
    assert_eq!(maturity1, maturity2, "Practice should produce deterministic maturity values");
    
    // Last practice tick should be identical
    let state1 = profile1.get_maturity(affordance_id).unwrap();
    let state2 = profile2.get_maturity(affordance_id).unwrap();
    assert_eq!(state1.last_practice_tick, state2.last_practice_tick);
}

#[test]
fn test_skill_decay_deterministic() {
    use anvil_sim::skill::{SkillProfile, AffordanceId, MaturityState};
    use anvil_sim::skill::practice::apply_decay;
    
    // Create two identical profiles with same maturity state
    let mut profile1 = SkillProfile::new();
    let mut profile2 = SkillProfile::new();
    
    let affordance_id = AffordanceId::new(20);
    
    let state = MaturityState {
        maturity: 0.8,
        peak_maturity: 0.8,
        last_practice_tick: 1000,
        last_failure_tick: 0,
    };
    
    profile1.maturities.insert(affordance_id, state);
    profile2.maturities.insert(affordance_id, state);
    
    // Apply decay at same tick
    apply_decay(&mut profile1, 3000, None);
    apply_decay(&mut profile2, 3000, None);
    
    // Maturity values should be identical after decay
    let maturity1 = profile1.get_maturity_value(affordance_id);
    let maturity2 = profile2.get_maturity_value(affordance_id);
    assert_eq!(maturity1, maturity2, "Decay should produce deterministic results");
}
