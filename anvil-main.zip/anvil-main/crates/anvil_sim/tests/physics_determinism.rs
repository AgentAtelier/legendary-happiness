//! Determinism canary test for Rapier physics integration.
//!
//! This test verifies that the physics simulation produces deterministic results
//! across runs with the same seed. This is critical for the project's determinism
//! guarantees.
//!
//! # Cross-Platform Requirement
//!
//! This test MUST be run on x86_64-linux, aarch64-linux (Steam Deck), and
//! aarch64-darwin before Phase 3 closes. If it fails on any platform, the
//! project must choose between:
//! - Fixed-point math
//! - A custom deterministic physics layer
//! - Restricting the platform matrix
//!
//! See ANVIL_STRATEGIC_ANALYSIS.md Phase 3 risk-retirement milestone.

use anvil_sim::system::physics::PhysicsSystem;
use anvil_sim::{WorldEnv, DeterministicRng, SimContext, SimSystem, WorldRuntime};
use anvil_world::WorldAuthored;
use glam::Vec3;
use rapier3d::dynamics::BodyStatus;

/// Number of ticks to simulate for the canary test.
const NUM_TICKS: u64 = 1000;

/// Record positions at every Nth tick.
const RECORD_INTERVAL: u64 = 100;

/// Number of dynamic bodies to create.
const NUM_BODIES: usize = 5;

/// Fixed physics time step - duplicated from physics.rs to avoid import issues
const PHYSICS_STEP: f32 = 1.0 / 60.0;

/// Creates a physics system with ground plane and 5 dynamic box bodies.
fn create_physics_world(seed: u64) -> PhysicsSystem {
    let mut system = PhysicsSystem::new();
    let mut rng = DeterministicRng::new(seed);

    // Create 5 dynamic bodies at varying heights
    // For determinism testing, we only need the bodies - collision is deterministic too
    // but simpler to just create bodies without colliders for this test
    for _ in 0..NUM_BODIES {
        // Use deterministic positions based on seed
        let x = rng.next_f32_range(-5.0, 5.0);
        let y = rng.next_f32_range(5.0, 15.0);
        let z = rng.next_f32_range(-5.0, 5.0);

        // Create dynamic body
        let body = rapier3d::dynamics::RigidBodyBuilder::new(BodyStatus::Dynamic)
            .translation(x, y, z)
            .build();
        system.rigid_body_set_mut().insert(body);
    }

    system
}

/// Simulates the physics system for a number of ticks and records positions.
/// Returns positions of the first dynamic body at each recording interval.
fn simulate_and_record(system: &mut PhysicsSystem, rng: &mut DeterministicRng) -> Vec<Vec3> {
    let mut positions = Vec::new();
    let mut dummy_world = WorldRuntime::new(WorldAuthored::default());

    let mut events_out = vec![];

    for tick in 0..NUM_TICKS {
        let dt_micros = (PHYSICS_STEP * 1_000_000.0) as u64;
        events_out.clear();

        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(
            tick,
            dt_micros,
            rng,
            &mut dummy_world,
            &world_env,
            &[],
            &mut events_out,
        );

        system.tick(&mut ctx).unwrap();

        // Record positions at intervals
        if tick % RECORD_INTERVAL == 0 {
            // Record position of first dynamic body
            let mut recorded = false;
            for (_, body) in system.rigid_body_set().iter() {
                if body.body_status() == BodyStatus::Dynamic {
                    let pos = body.position().translation;
                    positions.push(Vec3::new(pos.x, pos.y, pos.z));
                    recorded = true;
                    break;
                }
            }
            if !recorded {
                positions.push(Vec3::new(0.0, 0.0, 0.0));
            }
        }
    }

    positions
}

#[test]
fn test_determinism_same_seed_identical_results() {
    let seed = 42;

    // Run simulation twice with same seed
    let mut rng1 = DeterministicRng::new(seed);
    let mut system1 = create_physics_world(seed);

    let mut rng2 = DeterministicRng::new(seed);
    let mut system2 = create_physics_world(seed);

    let positions1 = simulate_and_record(&mut system1, &mut rng1);
    let positions2 = simulate_and_record(&mut system2, &mut rng2);

    // Positions must be identical
    assert_eq!(
        positions1, positions2,
        "Physics simulation must be deterministic with same seed"
    );
}

#[test]
fn test_determinism_different_seed_different_results() {
    let seed1 = 42;
    let seed2 = 123;

    // Run simulation with different seeds
    let mut rng1 = DeterministicRng::new(seed1);
    let mut system1 = create_physics_world(seed1);

    let mut rng2 = DeterministicRng::new(seed2);
    let mut system2 = create_physics_world(seed2);

    let positions1 = simulate_and_record(&mut system1, &mut rng1);
    let positions2 = simulate_and_record(&mut system2, &mut rng2);

    // Positions must differ (at least one position should be different)
    assert_ne!(
        positions1, positions2,
        "Physics simulation with different seeds must produce different results"
    );
}

#[test]
fn test_determinism_1000_ticks() {
    // This is the main canary test: run 1000 ticks and verify determinism
    let seed = 42;

    let mut rng1 = DeterministicRng::new(seed);
    let mut system1 = create_physics_world(seed);

    let mut rng2 = DeterministicRng::new(seed);
    let mut system2 = create_physics_world(seed);

    let positions1 = simulate_and_record(&mut system1, &mut rng1);
    let positions2 = simulate_and_record(&mut system2, &mut rng2);

    // Verify all recorded positions are identical
    assert_eq!(positions1.len(), positions2.len());
    for (index, (pos1, pos2)) in positions1.iter().zip(positions2.iter()).enumerate() {
        let tick = index as u64 * RECORD_INTERVAL;
        assert!(
            (pos1.x - pos2.x).abs() < 0.0001,
            "Position mismatch at tick {}: x coordinate differs (delta: {})",
            tick,
            pos1.x - pos2.x
        );
        assert!(
            (pos1.y - pos2.y).abs() < 0.0001,
            "Position mismatch at tick {}: y coordinate differs (delta: {})",
            tick,
            pos1.y - pos2.y
        );
        assert!(
            (pos1.z - pos2.z).abs() < 0.0001,
            "Position mismatch at tick {}: z coordinate differs (delta: {})",
            tick,
            pos1.z - pos2.z
        );
    }
}
