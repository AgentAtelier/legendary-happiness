//! Perceptibility Test
//!
//! Tests for Sprint 18b perceptibility system.
//! Verifies that NPCs with different fluency levels produce observably
//! different outcomes from the same action.
//!
//! Defined in Sprint 18b Task 7.

use anvil_sim::skill::affordance::AffordanceId;
use anvil_sim::skill::catalogue::affordance_catalogue;
use anvil_sim::skill::domain::SkillDomain;
use anvil_sim::skill::fluency::{FluencyLevel, FluencyLevelExt};
use anvil_sim::skill::perceptibility::PerceptibilityMapper;
use anvil_sim::skill::SkillProfile;

#[test]
fn test_fluency_level_derivation() {
    let catalogue = affordance_catalogue();

    // Test Halting (0 unlocked)
    let mut profile = SkillProfile::new();
    for id in catalogue.all_ids() {
        profile.add_affordance(id);
    }
    assert_eq!(
        profile.fluency_level(SkillDomain::Husbandry, &catalogue),
        FluencyLevel::Halting
    );

    // Test Awkward (1 unlocked)
    profile.unlock(AffordanceId::new(20));
    assert_eq!(
        profile.fluency_level(SkillDomain::Husbandry, &catalogue),
        FluencyLevel::Awkward
    );

    // Test Competent (2-3 unlocked)
    profile.unlock(AffordanceId::new(21));
    profile.unlock(AffordanceId::new(22));
    assert_eq!(
        profile.fluency_level(SkillDomain::Husbandry, &catalogue),
        FluencyLevel::Competent
    );

    // Test Smooth (4-5 unlocked)
    profile.unlock(AffordanceId::new(23));
    profile.unlock(AffordanceId::new(24));
    assert_eq!(
        profile.fluency_level(SkillDomain::Husbandry, &catalogue),
        FluencyLevel::Smooth
    );

    // Test Expert (6+ unlocked)
    profile.unlock(AffordanceId::new(25));
    profile.unlock(AffordanceId::new(26));
    profile.unlock(AffordanceId::new(27));
    assert_eq!(
        profile.fluency_level(SkillDomain::Husbandry, &catalogue),
        FluencyLevel::Expert
    );
}

#[test]
fn test_perceptibility_modifiers_for_husbandry() {
    let mapper = PerceptibilityMapper::new();

    // Test Husbandry Halting modifiers
    let halting = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Halting);
    assert_eq!(halting.action_duration_multiplier, 2.0);
    assert_eq!(halting.resource_waste_multiplier, 1.3);
    assert_eq!(halting.animation_state, "husbandry_halting");
    assert_eq!(halting.sound_profile, "farm_halting");

    // Test Husbandry Expert modifiers
    let expert = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Expert);
    assert_eq!(expert.action_duration_multiplier, 0.6);
    assert_eq!(expert.resource_waste_multiplier, 1.0);
    assert_eq!(expert.animation_state, "husbandry_expert");
    assert_eq!(expert.sound_profile, "farm_expert");
}

#[test]
fn test_perceptibility_modifiers_for_woodcraft() {
    let mapper = PerceptibilityMapper::new();

    // Test Woodcraft Halting modifiers
    let halting = mapper.get_modifiers(SkillDomain::Woodcraft, FluencyLevel::Halting);
    assert_eq!(halting.action_duration_multiplier, 2.0);
    assert_eq!(halting.resource_waste_multiplier, 1.3);
    assert_eq!(halting.animation_state, "woodcraft_halting");
    assert_eq!(halting.sound_profile, "wood_halting");

    // Test Woodcraft Expert modifiers
    let expert = mapper.get_modifiers(SkillDomain::Woodcraft, FluencyLevel::Expert);
    assert_eq!(expert.action_duration_multiplier, 0.6);
    assert_eq!(expert.resource_waste_multiplier, 1.0);
    assert_eq!(expert.animation_state, "woodcraft_expert");
    assert_eq!(expert.sound_profile, "wood_expert");
}

#[test]
fn test_deterministic_fluency_outcomes() {
    // Test that same inputs produce same outputs
    let mapper = PerceptibilityMapper::new();

    // Get Husbandry modifiers
    let halting_mods = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Halting);
    let expert_mods = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Expert);

    // Base action duration for Farm/Tend
    let base_duration: u64 = 60;
    let halting_duration = (base_duration as f32 * halting_mods.action_duration_multiplier).ceil() as u64;
    let expert_duration = (base_duration as f32 * expert_mods.action_duration_multiplier).ceil() as u64;

    // Base food production rate for Farm/Tend
    let base_rate: f32 = 0.002;
    let halting_yield = base_rate / halting_mods.resource_waste_multiplier;
    let expert_yield = base_rate / expert_mods.resource_waste_multiplier;

    // Assert that duration and yield differ measurably
    assert_ne!(halting_duration, expert_duration);
    assert_ne!(halting_yield, expert_yield);

    // Assert specific values match sprint requirements
    // Halting: ~2x duration
    assert!((halting_duration as f32 / base_duration as f32 - 2.0).abs() < 0.01);
    // Expert: ~0.6x duration
    assert!((expert_duration as f32 / base_duration as f32 - 0.6).abs() < 0.01);

    // Halting: ~76.9% yield (1/1.3 ≈ 0.769)
    assert!((halting_yield / base_rate - 0.769).abs() < 0.01);
    // Expert: ~100% yield
    assert!((expert_yield / base_rate - 1.0).abs() < 0.01);

    // Assert that the difference is deterministic
    // Running the same test again should produce the same results
    let halting_mods2 = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Halting);
    let expert_mods2 = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Expert);
    assert_eq!(halting_mods.action_duration_multiplier, halting_mods2.action_duration_multiplier);
    assert_eq!(expert_mods.action_duration_multiplier, expert_mods2.action_duration_multiplier);
}

#[test]
fn test_npc_halting_vs_expert_difference() {
    // This is the core test from Sprint 18b Task 7
    // NPC A: Halting (0 affordances unlocked) — action takes ~2x base duration, produces ~70% of base food
    // NPC B: Expert (6 affordances unlocked) — action takes ~0.6x base duration, produces ~100% of base food

    let mapper = PerceptibilityMapper::new();

    // Get Husbandry modifiers
    let halting_mods = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Halting);
    let expert_mods = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Expert);

    // Base action duration for Farm/Tend
    let base_duration: u64 = 60;
    let halting_duration = (base_duration as f32 * halting_mods.action_duration_multiplier).ceil() as u64;
    let expert_duration = (base_duration as f32 * expert_mods.action_duration_multiplier).ceil() as u64;

    // Base food production rate for Farm/Tend
    let base_rate: f32 = 0.002;
    let halting_yield = base_rate / halting_mods.resource_waste_multiplier;
    let expert_yield = base_rate / expert_mods.resource_waste_multiplier;

    // Assert that duration and yield differ measurably
    assert_ne!(halting_duration, expert_duration);
    assert_ne!(halting_yield, expert_yield);

    // Assert specific values match sprint requirements
    // Halting: ~2x duration, produces ~70% of base food
    assert!((halting_duration as f32 / base_duration as f32 - 2.0).abs() < 0.01);
    assert!((expert_duration as f32 / base_duration as f32 - 0.6).abs() < 0.01);

    // Halting: ~77% yield (1/1.3 ≈ 0.769)
    assert!((halting_yield / base_rate - 0.769).abs() < 0.01);
    // Expert: ~100% yield
    assert!((expert_yield / base_rate - 1.0).abs() < 0.01);
}

#[test]
fn test_all_fluency_levels_have_unique_modifiers() {
    let mapper = PerceptibilityMapper::new();

    // Test that each fluency level has unique duration and waste multipliers
    let levels = [
        FluencyLevel::Halting,
        FluencyLevel::Awkward,
        FluencyLevel::Competent,
        FluencyLevel::Smooth,
        FluencyLevel::Expert,
    ];

    let mut durations = Vec::new();
    let mut wastes = Vec::new();

    for level in levels {
        let mods = mapper.get_modifiers(SkillDomain::Husbandry, level);
        durations.push(mods.action_duration_multiplier);
        wastes.push(mods.resource_waste_multiplier);
    }

    // All duration multipliers should be unique
    for i in 0..durations.len() {
        for j in (i + 1)..durations.len() {
            assert_ne!(
                durations[i], durations[j],
                "Fluency levels should have unique duration multipliers"
            );
        }
    }

    // Waste multipliers should decrease as fluency increases
    // (Halting has highest waste, Expert has lowest)
    assert!(wastes[0] > wastes[1]); // Halting > Awkward
    assert!(wastes[1] > wastes[2]); // Awkward > Competent
    assert!(wastes[2] > wastes[3]); // Competent > Smooth
    assert!(wastes[3] >= wastes[4]); // Smooth >= Expert (Smooth and Expert both have 1.0)
}

#[test]
fn test_perceptibility_mapper_returns_modifiers_for_all_domains() {
    let mapper = PerceptibilityMapper::new();

    // Test that all domains have modifiers defined
    for domain in SkillDomain::all() {
        for level in [
            FluencyLevel::Halting,
            FluencyLevel::Awkward,
            FluencyLevel::Competent,
            FluencyLevel::Smooth,
            FluencyLevel::Expert,
        ] {
            let mods = mapper.get_modifiers(*domain, level);
            // Should have non-default values
            assert_ne!(mods.action_duration_multiplier, 0.0);
            assert_ne!(mods.resource_waste_multiplier, 0.0);
            assert!(!mods.animation_state.is_empty());
            assert!(!mods.sound_profile.is_empty());
        }
    }
}
