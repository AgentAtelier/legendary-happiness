//! Determinism test for NpcSystem.
//!
//! Verifies that NPC action selection is deterministic given the same seed and initial state.
//! Tests the core Sprint 17 functionality: Layered Soul, utility scoring, staggered evaluation.

use anvil_sim::{WorldEnv, 
    DeterministicRng, NpcSystem, SimContext, SimEvent, SimSystem, WorldRuntime,
    settlement::{Person, Settlement, SettlementId},
    skill::SkillProfile,
    soul::{EmotionalState, LayeredSoul, Substrate},
};
use anvil_core::RegionId;
use anvil_world::WorldAuthored;

/// Creates a test settlement with default values.
fn create_test_settlement(id: u64) -> Settlement {
    Settlement::new_with_defaults(
        SettlementId::new(id),
        format!("TestSettlement{}", id),
        RegionId::new(0),
        10,
    )
}

/// Creates a test person with the given parameters.
fn create_test_person(id: u64, mood: f32, substrate: Substrate) -> Person {
    use glam::Vec3;
    Person::new(
        anvil_sim::settlement::ids::PersonId::new(id),
        format!("Person{}", id),
        anvil_sim::settlement::ids::FamilyId::new(1),
        anvil_sim::age::Age::from_years(20.0),
        substrate,
        EmotionalState::from_mood(mood),
        vec![],
        vec![],
        vec![],
        SkillProfile::new(),
        None,
        0,
        0,
        0,
        0.5,
        Vec3::ZERO,
    )
}

#[test]
fn test_npc_system_deterministic_action_selection() {
    // Create two identical systems with the same seed
    let mut system1 = NpcSystem::new();
    let mut system2 = NpcSystem::new();

    // Add settlement
    let settlement = create_test_settlement(1);
    system1.add_settlement(settlement.clone());
    system2.add_settlement(settlement.clone());

    // Add 5 NPCs with identical state
    let substrate = Substrate::new(0.5, 0.5, 0.5);
    for i in 0..5 {
        let person = create_test_person(i as u64 + 1, 0.0, substrate);
        system1.add_person(person.clone());
        system2.add_person(person);
    }

    // Create contexts with the same seed
    let mut world1 = WorldRuntime::new(WorldAuthored::default());
    let mut rng1 = DeterministicRng::new(42);
    let events_in1: Vec<SimEvent> = Vec::new();
    let mut events_out1: Vec<SimEvent> = Vec::new();
    let world_env1 = WorldEnv::default();
    let mut ctx1 = SimContext::new(0, 1000, &mut rng1, &mut world1, &world_env1, &events_in1, &mut events_out1);

    let mut world2 = WorldRuntime::new(WorldAuthored::default());
    let mut rng2 = DeterministicRng::new(42);
    let events_in2: Vec<SimEvent> = Vec::new();
    let mut events_out2: Vec<SimEvent> = Vec::new();
    let world_env2 = WorldEnv::default();
    let mut ctx2 = SimContext::new(0, 1000, &mut rng2, &mut world2, &world_env2, &events_in2, &mut events_out2);

    // Evaluate NPCs in both systems using the public tick method
    system1.tick(&mut ctx1).unwrap();
    system2.tick(&mut ctx2).unwrap();

    // After ticking, the action selections should be identical
    for i in 0..5 {
        let action1 = system1.persons[i].current_action_id;
        let action2 = system2.persons[i].current_action_id;
        assert_eq!(action1, action2, 
            "NPC {} action selection differs between identical systems after tick", i + 1);
    }
}

#[test]
fn test_npc_system_deterministic_need_decay() {
    // Create two identical systems
    let mut system1 = NpcSystem::new();
    let mut system2 = NpcSystem::new();

    let settlement = create_test_settlement(1);
    system1.add_settlement(settlement.clone());
    system2.add_settlement(settlement.clone());

    let substrate = Substrate::new(0.3, -0.2, 0.8);
    for i in 0..3 {
        let person = create_test_person(i as u64 + 1, 0.5, substrate);
        system1.add_person(person.clone());
        system2.add_person(person);
    }

    // Set specific need satisfaction values
    for i in 0..3 {
        let person_id = (i + 1) as u64;
        system1.set_need_satisfaction(person_id, anvil_sim::needs::Need::Food, 0.8);
        system2.set_need_satisfaction(person_id, anvil_sim::needs::Need::Food, 0.8);
    }

    // Tick both systems with the same seed
    let mut world1 = WorldRuntime::new(WorldAuthored::default());
    let mut rng1 = DeterministicRng::new(12345);
    let events_in1: Vec<SimEvent> = Vec::new();
    let mut events_out1: Vec<SimEvent> = Vec::new();
    let world_env1 = WorldEnv::default();
    let mut ctx1 = SimContext::new(0, 1000, &mut rng1, &mut world1, &world_env1, &events_in1, &mut events_out1);
    
    let mut world2 = WorldRuntime::new(WorldAuthored::default());
    let mut rng2 = DeterministicRng::new(12345);
    let events_in2: Vec<SimEvent> = Vec::new();
    let mut events_out2: Vec<SimEvent> = Vec::new();
    let world_env2 = WorldEnv::default();
    let mut ctx2 = SimContext::new(0, 1000, &mut rng2, &mut world2, &world_env2, &events_in2, &mut events_out2);

    // Tick both systems
    system1.tick(&mut ctx1).unwrap();
    system2.tick(&mut ctx2).unwrap();

    // After ticking, the need satisfaction should be identical
    for i in 0..3 {
        let person_id = (i + 1) as u64;
        for need_idx in 0..7 {
            use anvil_sim::needs::Need;
            let need = match need_idx {
                0 => Need::Food,
                1 => Need::Water,
                2 => Need::Shelter,
                3 => Need::Safety,
                4 => Need::Sleep,
                5 => Need::Companionship,
                6 => Need::Joy,
                _ => panic!("Invalid need index"),
            };
            let sat1 = system1.get_need_satisfaction(person_id, need);
            let sat2 = system2.get_need_satisfaction(person_id, need);
            assert_eq!(sat1, sat2, 
                "Need satisfaction for NPC {} need {:?} differs after tick", i + 1, need);
        }
    }
}

#[test]
fn test_layered_soul_deterministic_generation() {
    // Create two identical souls with the same seed
    let soul1 = LayeredSoul::from_seed(42);
    let soul2 = LayeredSoul::from_seed(42);

    assert_eq!(soul1.substrate.courage_fear, soul2.substrate.courage_fear);
    assert_eq!(soul1.substrate.generosity_selfishness, soul2.substrate.generosity_selfishness);
    assert_eq!(soul1.substrate.stability_anxiety, soul2.substrate.stability_anxiety);
}

#[test]
fn test_utility_scoring_deterministic() {
    use anvil_sim::{
        actions::catalogue,
        needs::Need,
        soul::{EmotionalState, Substrate},
        utility::scoring::compute_utility_score,
    };

    // Create identical parameters
    let need_satisfaction = 0.5f32;
    let action = catalogue::action_by_id(1).unwrap(); // Farm/Tend
    let need = Need::Food;
    let skills: Vec<anvil_sim::settlement::skill::Skill> = vec![];
    let emotional_state = EmotionalState::from_mood(0.0);
    let substrate = Substrate::neutral();
    let time_of_day = 0.25f32; // Dawn
    let settlement_damage = 0.0f32;
    let settlement_aggregate_mood = 0.5f32;

    // Compute score twice with identical parameters
    let score1 = compute_utility_score(
        need_satisfaction,
        &action,
        need,
        &skills,
        &emotional_state,
        &substrate,
        time_of_day,
        settlement_damage,
        settlement_aggregate_mood,
    );

    let score2 = compute_utility_score(
        need_satisfaction,
        &action,
        need,
        &skills,
        &emotional_state,
        &substrate,
        time_of_day,
        settlement_damage,
        settlement_aggregate_mood,
    );

    assert_eq!(score1, score2, "Utility score should be deterministic");
}
