//! Target selection system for NPC actions.
//!
//! Implements the social priority model and target scoring as defined in
//! GAME_DESIGN_SECTION_4.md Section 4.5.

use crate::settlement::connection::ConnectionLayer;
use crate::settlement::ids::PersonId;
use crate::settlement::Person;
use anvil_core::ValidationErrors;

/// Target selection result for an action that requires a target.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TargetSelection {
    /// The selected target person ID.
    pub target_id: Option<PersonId>,
    /// The connection layer of the selected target.
    pub layer: Option<ConnectionLayer>,
}

impl TargetSelection {
    /// Creates a new target selection with a target.
    pub fn with_target(target_id: PersonId, layer: ConnectionLayer) -> Self {
        Self {
            target_id: Some(target_id),
            layer: Some(layer),
        }
    }

    /// Creates a new target selection with no target.
    pub fn none() -> Self {
        Self {
            target_id: None,
            layer: None,
        }
    }
}

/// Social priority model for target selection.
///
/// Defines the priority order for selecting targets:
/// 1. Family first (Layer 1) - always eligible
/// 2. Proximity second (Layer 2) - eligible when cooperation modifier > threshold
/// 3. Village third (Layer 3) - eligible when cooperation modifier is high
///
/// Defined in GAME_DESIGN_SECTION_4.md Section 4.5.1.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SocialPriority {
    /// Family layer - always eligible.
    Family,
    /// Proximity layer - eligible when cooperation modifier > threshold.
    Proximity,
    /// Village layer - eligible when cooperation modifier is high.
    Village,
}

impl SocialPriority {
    /// Returns the priority order (lower = higher priority).
    pub fn priority_order(&self) -> u8 {
        match self {
            SocialPriority::Family => 0,
            SocialPriority::Proximity => 1,
            SocialPriority::Village => 2,
        }
    }

    /// Checks if this priority layer is eligible given the cooperation modifier.
    ///
    /// Family is always eligible.
    /// Proximity is eligible when cooperation modifier > 0.5.
    /// Village is eligible when cooperation modifier > 0.8.
    pub fn is_eligible(&self, cooperation_modifier: f32) -> bool {
        match self {
            SocialPriority::Family => true,
            SocialPriority::Proximity => cooperation_modifier > 0.5,
            SocialPriority::Village => cooperation_modifier > 0.8,
        }
    }
}

/// Selects a target for the "Share Food" action.
///
/// Target: the hungriest connected NPC in the eligible layer.
///
/// Defined in GAME_DESIGN_SECTION_4.md Section 4.5.2.
pub fn select_share_food_target(
    npc: &Person,
    all_persons: &[Person],
    cooperation_modifier: f32,
) -> TargetSelection {
    select_target_by_need(
        npc,
        all_persons,
        cooperation_modifier,
        |person| person.emotional_state.mood(), // Use mood as proxy for hunger (lower = more hungry)
        false, // Lower is better (more hungry)
    )
}

/// Selects a target for the "Warn Others" action.
///
/// Target: the connected NPC with the lowest Safety need satisfaction.
///
/// Defined in GAME_DESIGN_SECTION_4.md Section 4.5.2.
pub fn select_warn_others_target(
    npc: &Person,
    all_persons: &[Person],
    cooperation_modifier: f32,
) -> TargetSelection {
    // For simplicity, we use mood as proxy for safety awareness
    // (lower mood = less aware = more in need of warning)
    select_target_by_need(
        npc,
        all_persons,
        cooperation_modifier,
        |person| person.emotional_state.mood(),
        false, // Lower is better (less aware)
    )
}

/// Selects a target for the "Gather Socially" action.
///
/// Target: the largest existing group of connected NPCs.
///
/// Defined in GAME_DESIGN_SECTION_4.md Section 4.5.2.
pub fn select_gather_socially_target(
    npc: &Person,
    all_persons: &[Person],
    _cooperation_modifier: f32,
) -> TargetSelection {
    // Find the largest group among connections
    // For now, we just select the first person in a family
    for conn in &npc.connections {
        if all_persons.iter().any(|p| p.id == conn.target) {
            return TargetSelection::with_target(conn.target, conn.layer);
        }
    }
    TargetSelection::none()
}

/// Generic function to select a target based on a need value.
///
/// Iterates through connections in priority order (Family -> Proximity -> Village)
/// and selects the target with the best (highest or lowest) need value.
pub fn select_target_by_need<F>(
    npc: &Person,
    all_persons: &[Person],
    cooperation_modifier: f32,
    need_fn: F,
    higher_is_better: bool,
) -> TargetSelection
where
    F: Fn(&Person) -> f32,
{
    // Group connections by layer
    let mut family_targets: Vec<PersonId> = Vec::new();
    let mut proximity_targets: Vec<PersonId> = Vec::new();
    let mut village_targets: Vec<PersonId> = Vec::new();

    for conn in &npc.connections {
        match conn.layer {
            ConnectionLayer::Family => family_targets.push(conn.target),
            ConnectionLayer::Proximity => proximity_targets.push(conn.target),
            ConnectionLayer::Village => village_targets.push(conn.target),
        }
    }

    // Try each priority layer in order
    for priority in [
        (SocialPriority::Family, &family_targets),
        (SocialPriority::Proximity, &proximity_targets),
        (SocialPriority::Village, &village_targets),
    ] {
        if !priority.0.is_eligible(cooperation_modifier) {
            continue;
        }

        if priority.1.is_empty() {
            continue;
        }

        // Find the best target in this layer
        let mut best_target: Option<(PersonId, f32, ConnectionLayer)> = None;

        for &target_id in priority.1 {
            if let Some(target) = all_persons.iter().find(|p| p.id == target_id) {
                let need_value = need_fn(target);

                match &mut best_target {
                    None => {
                        best_target = Some((target_id, need_value, priority.0.into()));
                    }
                    Some((_, best_value, _)) => {
                        if higher_is_better {
                            if need_value > *best_value {
                                *best_value = need_value;
                                best_target = Some((target_id, need_value, priority.0.into()));
                            }
                        } else {
                            if need_value < *best_value {
                                *best_value = need_value;
                                best_target = Some((target_id, need_value, priority.0.into()));
                            }
                        }
                    }
                }
            }
        }

        if let Some((target_id, _, layer)) = best_target {
            return TargetSelection::with_target(target_id, layer);
        }
    }

    TargetSelection::none()
}

impl From<SocialPriority> for ConnectionLayer {
    fn from(priority: SocialPriority) -> Self {
        match priority {
            SocialPriority::Family => ConnectionLayer::Family,
            SocialPriority::Proximity => ConnectionLayer::Proximity,
            SocialPriority::Village => ConnectionLayer::Village,
        }
    }
}

/// Validates the targeting module.
pub fn validate() -> ValidationErrors {
    Vec::new()
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::settlement::connection::Connection;
    use crate::settlement::ids::{FamilyId, PersonId};
    use crate::skill::SkillProfile;
    use crate::soul::{EmotionalState, Substrate};

    fn create_test_person(id: u64, mood: f32) -> Person {
        use glam::Vec3;
        Person::new(
            PersonId::new(id),
            format!("Person {}", id),
            FamilyId::new(1),
            crate::age::Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::from_mood(mood),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        )
    }

    fn create_test_person_with_connections(
        id: u64,
        mood: f32,
        connections: Vec<(u64, ConnectionLayer)>,
    ) -> Person {
        use glam::Vec3;
        let conn_vec: Vec<Connection> = connections
            .into_iter()
            .map(|(target, layer)| Connection::new(PersonId::new(target), layer))
            .collect();

        Person::new(
            PersonId::new(id),
            format!("Person {}", id),
            FamilyId::new(1),
            crate::age::Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::from_mood(mood),
            conn_vec,
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        )
    }

    #[test]
    fn test_social_priority_order() {
        assert_eq!(SocialPriority::Family.priority_order(), 0);
        assert_eq!(SocialPriority::Proximity.priority_order(), 1);
        assert_eq!(SocialPriority::Village.priority_order(), 2);
    }

    #[test]
    fn test_social_priority_eligibility() {
        // Family is always eligible
        assert!(SocialPriority::Family.is_eligible(0.0));
        assert!(SocialPriority::Family.is_eligible(0.5));
        assert!(SocialPriority::Family.is_eligible(1.0));

        // Proximity is eligible when cooperation > 0.5
        assert!(!SocialPriority::Proximity.is_eligible(0.4));
        assert!(SocialPriority::Proximity.is_eligible(0.6));
        assert!(SocialPriority::Proximity.is_eligible(1.0));

        // Village is eligible when cooperation > 0.8
        assert!(!SocialPriority::Village.is_eligible(0.7));
        assert!(!SocialPriority::Village.is_eligible(0.8));
        assert!(SocialPriority::Village.is_eligible(0.9));
    }

    #[test]
    fn test_target_selection_with_target() {
        let selection = TargetSelection::with_target(PersonId::new(1), ConnectionLayer::Family);
        assert_eq!(selection.target_id, Some(PersonId::new(1)));
        assert_eq!(selection.layer, Some(ConnectionLayer::Family));
    }

    #[test]
    fn test_target_selection_none() {
        let selection = TargetSelection::none();
        assert_eq!(selection.target_id, None);
        assert_eq!(selection.layer, None);
    }

    #[test]
    fn test_select_target_by_need_family_first() {
        let persons = vec![
            create_test_person(1, 0.1), // Very low mood (hungry)
            create_test_person(2, 0.5), // Medium mood
            create_test_person(3, 0.9), // High mood (not hungry)
        ];

        // NPC with family connection to person 1
        let npc = create_test_person_with_connections(
            10,
            0.5,
            vec![(1, ConnectionLayer::Family), (2, ConnectionLayer::Proximity)],
        );

        let selection = select_target_by_need(
            &npc,
            &persons,
            1.0, // High cooperation - all layers eligible
            |p| p.emotional_state.mood(),
            false, // Lower mood = more hungry = better target
        );

        assert_eq!(selection.target_id, Some(PersonId::new(1)));
    }

    #[test]
    fn test_select_target_by_need_priority_order() {
        let persons = vec![
            create_test_person(1, 0.1), // Very hungry, Family
            create_test_person(2, 0.0), // Even hungrier, but Proximity
        ];

        let npc = create_test_person_with_connections(
            10,
            0.5,
            vec![(1, ConnectionLayer::Family), (2, ConnectionLayer::Proximity)],
        );

        // With low cooperation, only Family is eligible
        let selection = select_target_by_need(
            &npc,
            &persons,
            0.4, // Low cooperation - only Family eligible
            |p| p.emotional_state.mood(),
            false,
        );

        // Should select person 1 (Family) even though person 2 is hungrier
        assert_eq!(selection.target_id, Some(PersonId::new(1)));
    }

    #[test]
    fn test_select_target_by_need_no_eligible() {
        let persons = vec![
            create_test_person(1, 0.5),
            create_test_person(2, 0.5),
        ];

        let npc = create_test_person_with_connections(
            10,
            0.5,
            vec![(1, ConnectionLayer::Village), (2, ConnectionLayer::Village)],
        );

        // With low cooperation, Village is not eligible
        let selection = select_target_by_need(
            &npc,
            &persons,
            0.4, // Low cooperation
            |p| p.emotional_state.mood(),
            false,
        );

        // Should return none since no eligible layers
        assert_eq!(selection.target_id, None);
    }

    #[test]
    fn test_select_target_by_need_higher_is_better() {
        let persons = vec![
            create_test_person(1, 0.9), // High mood
            create_test_person(2, 0.5), // Medium mood
            create_test_person(3, 0.1), // Low mood
        ];

        let npc = create_test_person_with_connections(
            10,
            0.5,
            vec![(1, ConnectionLayer::Family), (2, ConnectionLayer::Family), (3, ConnectionLayer::Family)],
        );

        let selection = select_target_by_need(
            &npc,
            &persons,
            1.0,
            |p| p.emotional_state.mood(),
            true, // Higher is better
        );

        // Should select person 1 (highest mood)
        assert_eq!(selection.target_id, Some(PersonId::new(1)));
    }

    #[test]
    fn test_social_priority_from_connection_layer() {
        assert_eq!(
            ConnectionLayer::from(SocialPriority::Family),
            ConnectionLayer::Family
        );
        assert_eq!(
            ConnectionLayer::from(SocialPriority::Proximity),
            ConnectionLayer::Proximity
        );
        assert_eq!(
            ConnectionLayer::from(SocialPriority::Village),
            ConnectionLayer::Village
        );
    }
}
