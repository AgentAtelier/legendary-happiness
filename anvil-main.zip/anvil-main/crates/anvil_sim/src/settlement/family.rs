//! Family type for settlement simulation.
//!
//! Defines the Family type as per GAME_DESIGN_SECTION_3.md Section 3.1.2.

use crate::settlement::ids::{FamilyId, PersonId};
 use anvil_core::{FailureClass, ValidationErrors, error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};

/// A family unit containing 2-7 members as defined in Section 3.1.2.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Family {
    /// Unique identifier for this family.
    pub id: FamilyId,
    /// The person IDs of family members. Must contain 2-7 members.
    pub members: Vec<PersonId>,
}

impl Family {
    /// Creates a new family.
    pub fn new(id: FamilyId, members: Vec<PersonId>) -> Self {
        Self { id, members }
    }

    /// Validates this family.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        errors.extend(self.id.validate());

        if self.members.len() < 2 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E158",
                "Family",
                "members",
                format!("{} members", self.members.len()),
                "family must have at least 2 members"
            );
        }

        if self.members.len() > 7 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E158",
                "Family",
                "members",
                format!("{} members", self.members.len()),
                "family must have at most 7 members"
            );
        }

        // Validate member IDs
        for member in &self.members {
            errors.extend(member.validate());
        }

        errors
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_family_validation() {
        let members = (0..5).map(|i| PersonId::new(i as u64 + 1)).collect();
        let family = Family::new(FamilyId::new(1), members);
        let errors = family.validate();
        assert!(errors.is_empty());
    }

    #[test]
    fn test_family_validation_too_few_members() {
        let family = Family::new(FamilyId::new(1), vec![PersonId::new(1)]);
        let errors = family.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E158");
    }

    #[test]
    fn test_family_validation_too_many_members() {
        let members = (0..8).map(|i| PersonId::new(i as u64 + 1)).collect();
        let family = Family::new(FamilyId::new(1), members);
        let errors = family.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E158");
    }
}
