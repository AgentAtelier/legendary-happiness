//! CatalystEvent type for joy celebration events.
//!
//! Defines the CatalystEvent as the symmetric counterpart to HistoryEvent
//! per GAME_DESIGN_SECTION_3.md Section 3.4.2.

use crate::settlement::ids::{CatalystEventId, PersonId, SettlementId};
 use anvil_core::{FailureClass, ValidationErrors, error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};
use std::fmt;

// ---------------------------------------------------------------------------
// CatalystKind
// ---------------------------------------------------------------------------

/// The kind of catalyst event that triggers joy as defined in Section 3.4.1.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum CatalystKind {
    /// A child is born.
    Birth,
    /// Food stores cross a sufficiency threshold.
    Harvest,
    /// Someone who was missing returns.
    Return,
    /// A building or infrastructure is completed.
    Construction,
    /// The season changes (e.g., winter to spring).
    SeasonTurn,
    /// A custom catalyst type for future expansion.
    Custom(String),
}

impl fmt::Display for CatalystKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CatalystKind::Birth => write!(f, "birth"),
            CatalystKind::Harvest => write!(f, "harvest"),
            CatalystKind::Return => write!(f, "return"),
            CatalystKind::Construction => write!(f, "construction"),
            CatalystKind::SeasonTurn => write!(f, "season_turn"),
            CatalystKind::Custom(s) => write!(f, "custom:{}", s),
        }
    }
}

// ---------------------------------------------------------------------------
// CatalystEvent
// ---------------------------------------------------------------------------

/// A catalyst event representing joy in the settlement simulation.
///
/// This is the symmetric counterpart to HistoryEvent as defined in
/// GAME_DESIGN_SECTION_3.md Section 3.4.2.
///
/// Emitted when both conditions for joy are met:
/// 1. Sufficient collective mood (60-70% of NPCs have mood > +0.3)
/// 2. A trigger event occurs (birth, harvest, return, construction, season turn)
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CatalystEvent {
    /// Unique identifier for this catalyst event.
    pub id: CatalystEventId,
    /// The kind of catalyst.
    pub kind: CatalystKind,
    /// The simulation tick when this event was triggered.
    pub tick: u64,
    /// The settlement this catalyst affects.
    pub settlement_id: SettlementId,
    /// The NPC who triggered this catalyst, if applicable.
    pub trigger_npc: Option<PersonId>,
    /// Optional link to the HistoryEvent (catastrophe) that preceded this joy.
    pub linked_history: Option<u64>,
    /// The magnitude of the celebration (0.0 to 1.0).
    /// Driven by the delta between the lowest recent mood and current mood.
    pub magnitude: f32,
}

impl CatalystEvent {
    /// Creates a new catalyst event.
    pub fn new(
        id: CatalystEventId,
        kind: CatalystKind,
        tick: u64,
        settlement_id: SettlementId,
        trigger_npc: Option<PersonId>,
        linked_history: Option<u64>,
        magnitude: f32,
    ) -> Self {
        Self {
            id,
            kind,
            tick,
            settlement_id,
            trigger_npc,
            linked_history,
            magnitude,
        }
    }

    /// Validates this catalyst event.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        errors.extend(self.id.validate());
        errors.extend(self.settlement_id.validate());

        if self.tick == 0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E160",
                "CatalystEvent",
                "tick",
                format!("{}", self.tick),
                "tick must be non-zero"
            );
        }

        if !self.magnitude.is_finite() || self.magnitude < 0.0 || self.magnitude > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E161",
                "CatalystEvent",
                "magnitude",
                format!("{}", self.magnitude),
                "magnitude must be in [0.0, 1.0]"
            );
        }

        if let Some(npc) = &self.trigger_npc {
            errors.extend(npc.validate());
        }

        errors
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_catalyst_kind_display() {
        assert_eq!(format!("{}", CatalystKind::Birth), "birth");
        assert_eq!(format!("{}", CatalystKind::Harvest), "harvest");
        assert_eq!(format!("{}", CatalystKind::Return), "return");
        assert_eq!(format!("{}", CatalystKind::Construction), "construction");
        assert_eq!(format!("{}", CatalystKind::SeasonTurn), "season_turn");
        assert_eq!(
            format!("{}", CatalystKind::Custom("test".to_string())),
            "custom:test"
        );
    }

    #[test]
    fn test_catalyst_event_validation() {
        let event = CatalystEvent::new(
            CatalystEventId::new(1),
            CatalystKind::Harvest,
            100,
            SettlementId::new(1),
            None,
            None,
            0.75,
        );
        let errors = event.validate();
        assert!(errors.is_empty(), "Valid catalyst event should have no errors");
    }

    #[test]
    fn test_catalyst_event_validation_zero_tick() {
        let event = CatalystEvent::new(
            CatalystEventId::new(1),
            CatalystKind::Harvest,
            0, // Invalid: zero tick
            SettlementId::new(1),
            None,
            None,
            0.75,
        );
        let errors = event.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E160");
    }

    #[test]
    fn test_catalyst_event_validation_invalid_magnitude() {
        let event = CatalystEvent::new(
            CatalystEventId::new(1),
            CatalystKind::Harvest,
            100,
            SettlementId::new(1),
            None,
            None,
            1.5, // Invalid: > 1.0
        );
        let errors = event.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E161");
    }
}
