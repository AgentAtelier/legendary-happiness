//! Settlement simulation types for Forgeborn.
//!
//! This module defines the core data types for settlements, people, and families
//! as specified in GAME_DESIGN_SECTION_3.md Sections 3.1, 3.3, 3.4, and 3.6,
//! and extended in Sprint 17 with GAME_DESIGN_SECTION_4.md.

pub mod catalyst;
pub mod connection;
pub mod family;
pub mod ids;
pub mod memory;
pub mod person;
pub mod settlement_type;
pub mod skill;

pub use catalyst::{CatalystEvent, CatalystKind};
pub use connection::{Connection, ConnectionLayer};
pub use family::Family;
pub use ids::{CatalystEventId, FamilyId, PersonId, SettlementId};
pub use memory::Memory;
pub use person::Person;
pub use settlement_type::Settlement;
pub use skill::Skill;
