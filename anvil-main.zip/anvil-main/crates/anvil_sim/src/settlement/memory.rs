//! NPC memory types for event recollection.
//!
//! Defines the Memory type as per GAME_DESIGN_SECTION_3.md Section 3.6.1.

 use anvil_core::{FailureClass, ValidationErrors, error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};

/// An NPC's memory of a past event as defined in Section 3.6.1.
///
/// Memories decay slowly over time, with recent memories being more vivid.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Memory {
    /// The event ID this memory refers to (HistoryEvent or CatalystEvent).
    /// Stored as a u64 to allow referencing either type.
    pub event_id: u64,
    /// The age of this memory in simulation ticks.
    pub age_ticks: u64,
    /// The vividness of this memory (0.0 to 1.0), decays over time.
    pub vividness: f32,
    /// Whether this memory is positive (true) or negative (false).
    pub is_positive: bool,
}

impl Memory {
    /// Creates a new memory.
    pub fn new(event_id: u64, age_ticks: u64, vividness: f32, is_positive: bool) -> Self {
        Self {
            event_id,
            age_ticks,
            vividness,
            is_positive,
        }
    }

    /// Validates this memory.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        if self.event_id == 0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E154",
                "Memory",
                "event_id",
                format!("{}", self.event_id),
                "event ID must be non-zero"
            );
        }

        if !self.vividness.is_finite() || self.vividness < 0.0 || self.vividness > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E155",
                "Memory",
                "vividness",
                format!("{}", self.vividness),
                "vividness must be in [0.0, 1.0]"
            );
        }

        errors
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_memory_validation() {
        let memory = Memory::new(1, 100, 0.8, true);
        let errors = memory.validate();
        assert!(errors.is_empty());
    }

    #[test]
    fn test_memory_validation_zero_event_id() {
        let memory = Memory::new(0, 100, 0.8, true);
        let errors = memory.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E154");
    }

    #[test]
    fn test_memory_validation_invalid_vividness() {
        let memory = Memory::new(1, 100, 1.5, true);
        let errors = memory.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E155");
    }
}
