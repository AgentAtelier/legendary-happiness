//! NPC Person type for settlement simulation.
//!
//! Defines the Person type as per GAME_DESIGN_SECTION_3.md Section 3.1.1
//! and extended with Layered Soul model from GAME_DESIGN_SECTION_4.md Section 4.1.

use crate::age::{Age, AgeCategory};
use crate::settlement::connection::Connection;
use crate::settlement::ids::{FamilyId, PersonId};
use crate::settlement::memory::Memory;
use crate::settlement::skill::Skill;
use crate::skill::SkillProfile;
use crate::soul::{EmotionalState, Substrate};
use anvil_core::{FailureClass, ValidationErrors, error_buffer, push_validation_error};
use glam::Vec3;
use serde::{Deserialize, Serialize};

/// A person (NPC) in the settlement simulation.
///
/// Extended in Sprint 17 to include the Layered Soul model:
/// - substrate: stable traits (courage/fear, generosity/selfishness, stability/anxiety)
/// - emotional_state: current mood with perception filter
///
/// The mood field is kept for backward compatibility but is now derived from
/// the emotional_state. The primary source is emotional_state.mood.
///
/// Defined in GAME_DESIGN_SECTION_3.md Section 3.1.1 and
/// GAME_DESIGN_SECTION_4.md Section 4.1.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Person {
    /// Unique identifier for this person.
    pub id: PersonId,
    /// The person's name.
    pub name: String,
    /// The family this person belongs to.
    pub family_id: FamilyId,
    /// The person's age in days (continuous age system, Sprint 18c).
    /// Replaces the discrete age_category for capability calculations.
    pub age: Age,
    /// The person's age category (Child, Adult, Elder).
    /// Kept for backward compatibility; derived from age field.
    pub age_category: AgeCategory,
    /// The person's substrate (Layer 1) - stable traits.
    pub substrate: Substrate,
    /// The person's emotional state (Layer 2) - current mood.
    /// The mood value from GAME_DESIGN_SECTION_3.md is now stored here.
    pub emotional_state: EmotionalState,
    /// Social connections to other NPCs.
    pub connections: Vec<Connection>,
    /// Memories of past events.
    pub memories: Vec<Memory>,
    /// Skills this person possesses (legacy placeholder, kept for backward compatibility).
    pub skills: Vec<Skill>,
    /// Skill profile tracking maturity and unlocked affordances for diegetic progression.
    /// Added in Sprint 18a.
    pub skill_profile: SkillProfile,
    /// The ID of the action currently being executed, if any.
    /// None means the NPC is idle or between actions.
    pub current_action_id: Option<u64>,
    /// The number of ticks remaining for the current action.
    /// 0 means the action is complete.
    pub current_action_remaining_ticks: u64,
    /// The last tick at which this NPC evaluated its action choices.
    /// Used for staggered re-evaluation (Design Constraint 13).
    pub last_evaluation_tick: u64,
    /// The settlement this person belongs to.
    pub settlement_id: u64,
    /// Belonging score for this NPC (0.0 to 1.0).
    /// Higher belonging means stronger connection to the settlement/community.
    /// Used for observation-based learning amplification in Sprint 18b.
    pub belonging: f32,
    /// The NPC's current position in the world (Sprint 22 - Phase 3 gate).
    /// This is a simulated position for determinism testing purposes.
    /// In a full implementation, NPCs would have physics bodies.
    pub position: Vec3,
}

impl Person {
    /// Creates a new person with full Layered Soul support.
    ///
    /// Sprint 18c: age is the primary age representation; age_category is derived
    /// from it for backward compatibility.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        id: PersonId,
        name: String,
        family_id: FamilyId,
        age: Age,
        substrate: Substrate,
        emotional_state: EmotionalState,
        connections: Vec<Connection>,
        memories: Vec<Memory>,
        skills: Vec<Skill>,
        skill_profile: SkillProfile,
        current_action_id: Option<u64>,
        current_action_remaining_ticks: u64,
        last_evaluation_tick: u64,
        settlement_id: u64,
        belonging: f32,
        position: Vec3,
    ) -> Self {
        Self {
            id,
            name,
            family_id,
            age,
            age_category: age.to_age_category(),
            substrate,
            emotional_state,
            connections,
            memories,
            skills,
            skill_profile,
            current_action_id,
            current_action_remaining_ticks,
            last_evaluation_tick,
            settlement_id,
            belonging,
            position,
        }
    }

    /// Creates a new person with default values for testing.
    ///
    /// This is a convenience constructor for tests that don't need to specify all fields.
    pub fn new_simple(id: PersonId, name: String, family_id: FamilyId) -> Self {
        Self::new(
            id,
            name,
            family_id,
            Age::from_years(20.0), // Default to young adult
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5, // Default belonging
            Vec3::ZERO, // Default position
        )
    }

    /// Returns the person's current mood (from emotional state).
    ///
    /// This is the mood value from GAME_DESIGN_SECTION_3.md.
    /// Computed as the average of all four emotional axes.
    pub fn mood(&self) -> f32 {
        self.emotional_state.mood()
    }

    /// Returns whether this person can perform actions requiring a specific age category.
    pub fn can_perform_age(&self, required: AgeCategory) -> bool {
        match required {
            AgeCategory::Child => self.age_category == AgeCategory::Child,
            AgeCategory::Adult => self.age_category == AgeCategory::Adult,
            AgeCategory::Elder => self.age_category == AgeCategory::Elder,
            AgeCategory::All => true,
        }
    }

    /// Returns whether this person is currently executing an action.
    pub fn is_executing_action(&self) -> bool {
        self.current_action_id.is_some() && self.current_action_remaining_ticks > 0
    }

    /// Validates this person.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        errors.extend(self.id.validate());
        errors.extend(self.family_id.validate());
        errors.extend(self.substrate.validate());
        errors.extend(self.emotional_state.validate());
        errors.extend(self.skill_profile.validate());

        if self.name.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E156",
                "Person",
                "name",
                self.name.clone(),
                "name cannot be empty"
            );
        }

        // Validate that mood is in range (via emotional_state validation)
        // The emotional_state.validate() already checks this, but we keep the error code
        let mood = self.emotional_state.mood();
        if !mood.is_finite() || !(-1.0..=1.0).contains(&mood) {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E157",
                "Person",
                "mood",
                format!("{}", mood),
                "mood must be in [-1.0, 1.0]"
            );
        }

        // Validate connections
        for conn in &self.connections {
            errors.extend(conn.validate());
        }

        // Validate memories
        for mem in &self.memories {
            errors.extend(mem.validate());
        }

        errors
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_person_validation() {
        let person = Person::new_simple(PersonId::new(1), "Test".to_string(), FamilyId::new(1));
        let errors = person.validate();
        assert!(errors.is_empty(), "Valid person should have no errors");
    }

    #[test]
    fn test_person_validation_empty_name() {
        let person = Person::new(
            PersonId::new(1),
            "".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        let errors = person.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E156");
    }

    #[test]
    fn test_person_validation_invalid_mood() {
        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::with_axes(1.5, 0.0, 0.0, 0.0), // Invalid: security > 1.0
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        let errors = person.validate();
        // E187 from EmotionalAxes validation (via EmotionalState)
        // Person mood() averages axes, so (1.5 + 0 + 0 + 0) / 4 = 0.375 which is valid
        // Only the axes validation catches the invalid value
        assert_eq!(errors.len(), 1);
        let error_codes: Vec<&str> = errors.iter().map(|e| e.code().as_str()).collect();
        assert!(error_codes.contains(&"E187"));
    }

    #[test]
    fn test_person_mood() {
        let emotional_state = EmotionalState::from_mood(0.5);
        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            emotional_state,
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        assert_eq!(person.mood(), 0.5);
    }

    #[test]
    fn test_person_can_perform_age() {
        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        assert!(person.can_perform_age(AgeCategory::Adult));
        assert!(person.can_perform_age(AgeCategory::All));
        assert!(!person.can_perform_age(AgeCategory::Child));
        assert!(!person.can_perform_age(AgeCategory::Elder));
    }

    #[test]
    fn test_person_is_executing_action() {
        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            Some(1), // Has an action
            30,      // 30 ticks remaining
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        assert!(person.is_executing_action());

        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            Some(1), // Has an action
            0,       // 0 ticks remaining (complete)
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        assert!(!person.is_executing_action());

        let person = Person::new(
            PersonId::new(1),
            "Test".to_string(),
            FamilyId::new(1),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::neutral(),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,    // No action
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        );
        assert!(!person.is_executing_action());
    }

    #[test]
    fn test_person_simple_constructor() {
        let person = Person::new_simple(PersonId::new(1), "Test".to_string(), FamilyId::new(1));
        assert_eq!(person.id, PersonId::new(1));
        assert_eq!(person.name, "Test");
        assert_eq!(person.family_id, FamilyId::new(1));
        assert_eq!(person.age_category, AgeCategory::Adult);
        assert_eq!(person.substrate.courage_fear, 0.0);
        assert_eq!(person.emotional_state.mood(), 0.0);
        assert!(person.skill_profile.is_empty());
    }
}
