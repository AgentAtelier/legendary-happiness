//! Settlement type for the simulation.
//!
//! Defines the Settlement type as per GAME_DESIGN_SECTION_3.md Section 3.1.1
//! and extended with economy pools from GAME_DESIGN_SECTION_4.md Section 4.2.

use crate::settlement::catalyst::CatalystEvent;
use crate::settlement::ids::SettlementId;
 use anvil_core::{FailureClass, RegionId, ValidationErrors, error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};

/// A settlement in the simulation.
///
/// Extended in Sprint 17 to include all four economy pools:
/// - food_store (from Sprint 16)
/// - water (new)
/// - materials (new)
/// - structural_integrity (from Sprint 16)
///
/// Defined in GAME_DESIGN_SECTION_3.md Section 3.1.1 and
/// GAME_DESIGN_SECTION_4.md Section 4.2.1.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Settlement {
    /// Unique identifier for this settlement.
    pub id: SettlementId,
    /// The settlement's name.
    pub name: String,
    /// The region this settlement belongs to.
    pub region_id: RegionId,
    /// Total NPC population.
    pub population: u32,
    /// Food store as a fraction of full capacity (0.0 to 1.0).
    pub food_store: f32,
    /// Water store as a fraction of full capacity (0.0 to 1.0).
    /// New in Sprint 17.
    pub water: f32,
    /// Materials store as a fraction of full capacity (0.0 to 1.0).
    /// Aggregated timber/stone/cloth/tools.
    /// New in Sprint 17.
    pub materials: f32,
    /// Structural integrity as a fraction of buildings intact (0.0 to 1.0).
    pub structural_integrity: f32,
    /// Aggregate mood derived from NPC moods (-1.0 to +1.0).
    pub aggregate_mood: f32,
    /// Average damage level (0.0 to 1.0) for coping modifier calculations.
    /// Derived from catastrophes and used by the utility scoring system.
    pub damage_level: f32,
    /// IDs of active catastrophes affecting this settlement.
    pub active_catastrophes: Vec<u64>,
    /// The active catalyst event if a celebration is in progress.
    pub active_catalyst: Option<CatalystEvent>,
}

impl Settlement {
    /// Creates a new settlement.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        id: SettlementId,
        name: String,
        region_id: RegionId,
        population: u32,
        food_store: f32,
        water: f32,
        materials: f32,
        structural_integrity: f32,
        aggregate_mood: f32,
        damage_level: f32,
        active_catastrophes: Vec<u64>,
        active_catalyst: Option<CatalystEvent>,
    ) -> Self {
        Self {
            id,
            name,
            region_id,
            population,
            food_store,
            water,
            materials,
            structural_integrity,
            aggregate_mood,
            damage_level,
            active_catastrophes,
            active_catalyst,
        }
    }

    /// Creates a new settlement with default economy pool values.
    #[allow(clippy::too_many_arguments)]
    pub fn new_with_defaults(
        id: SettlementId,
        name: String,
        region_id: RegionId,
        population: u32,
    ) -> Self {
        Self::new(
            id,
            name,
            region_id,
            population,
            0.5,  // food_store
            0.8,  // water
            0.3,  // materials
            1.0,  // structural_integrity
            0.0,  // aggregate_mood
            0.0,  // damage_level
            vec![],
            None,
        )
    }

    /// Validates this settlement.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        errors.extend(self.id.validate());

        if self.name.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E162",
                "Settlement",
                "name",
                self.name.clone(),
                "name cannot be empty"
            );
        }

        if self.population == 0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E163",
                "Settlement",
                "population",
                format!("{}", self.population),
                "population must be positive"
            );
        }

        if !self.food_store.is_finite() || self.food_store < 0.0 || self.food_store > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E164",
                "Settlement",
                "food_store",
                format!("{}", self.food_store),
                "food_store must be in [0.0, 1.0]"
            );
        }

        if !self.water.is_finite() || self.water < 0.0 || self.water > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E176",
                "Settlement",
                "water",
                format!("{}", self.water),
                "water must be in [0.0, 1.0]"
            );
        }

        if !self.materials.is_finite() || self.materials < 0.0 || self.materials > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E177",
                "Settlement",
                "materials",
                format!("{}", self.materials),
                "materials must be in [0.0, 1.0]"
            );
        }

        if !self.structural_integrity.is_finite()
            || self.structural_integrity < 0.0
            || self.structural_integrity > 1.0
        {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E165",
                "Settlement",
                "structural_integrity",
                format!("{}", self.structural_integrity),
                "structural_integrity must be in [0.0, 1.0]"
            );
        }

        if !self.aggregate_mood.is_finite()
            || self.aggregate_mood < -1.0
            || self.aggregate_mood > 1.0
        {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E166",
                "Settlement",
                "aggregate_mood",
                format!("{}", self.aggregate_mood),
                "aggregate_mood must be in [-1.0, 1.0]"
            );
        }

        if !self.damage_level.is_finite() || self.damage_level < 0.0 || self.damage_level > 1.0 {
            push_validation_error!(
                errors,
                FailureClass::Semantic,
                "E178",
                "Settlement",
                "damage_level",
                format!("{}", self.damage_level),
                "damage_level must be in [0.0, 1.0]"
            );
        }

        // Validate active catalyst if present
        if let Some(catalyst) = &self.active_catalyst {
            errors.extend(catalyst.validate());
        }

        errors
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_settlement_validation() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
            0.8,
            0.7,
            0.4,
            0.9,
            0.5,
            0.2,
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert!(errors.is_empty(), "Valid settlement should have no errors");
    }

    #[test]
    fn test_settlement_validation_zero_population() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            0, // Invalid: zero population
            0.8,
            0.7,
            0.4,
            0.9,
            0.5,
            0.2,
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E163");
    }

    #[test]
    fn test_settlement_validation_invalid_food_store() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
            1.5, // Invalid: > 1.0
            0.7,
            0.4,
            0.9,
            0.5,
            0.2,
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E164");
    }

    #[test]
    fn test_settlement_validation_invalid_water() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
            0.8,
            1.5, // Invalid: > 1.0
            0.4,
            0.9,
            0.5,
            0.2,
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E176");
    }

    #[test]
    fn test_settlement_validation_invalid_materials() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
            0.8,
            0.7,
            -0.1, // Invalid: < 0.0
            0.9,
            0.5,
            0.2,
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E177");
    }

    #[test]
    fn test_settlement_validation_invalid_damage_level() {
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
            0.8,
            0.7,
            0.4,
            0.9,
            0.5,
            1.5, // Invalid: > 1.0
            vec![],
            None,
        );
        let errors = settlement.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E178");
    }

    #[test]
    fn test_settlement_new_with_defaults() {
        let settlement = Settlement::new_with_defaults(
            SettlementId::new(1),
            "Testville".to_string(),
            RegionId::new(0),
            20,
        );
        assert_eq!(settlement.food_store, 0.5);
        assert_eq!(settlement.water, 0.8);
        assert_eq!(settlement.materials, 0.3);
        assert_eq!(settlement.structural_integrity, 1.0);
        assert_eq!(settlement.aggregate_mood, 0.0);
        assert_eq!(settlement.damage_level, 0.0);
    }
}
