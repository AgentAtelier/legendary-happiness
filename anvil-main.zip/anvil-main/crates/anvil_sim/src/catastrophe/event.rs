//! Catastrophe event types and state.
//!
//! This module defines the core event types for the catastrophe simulation
//! system as described in GAME_DESIGN_SECTION_3.md Section 3.2.

use anvil_core::DamageType;
use glam::Vec3;
use serde::{Deserialize, Serialize};
use std::fmt;

/// The position of a catastrophe epicentre in world space.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Epicentre {
    /// The world-space position of the epicentre.
    pub position: Vec3,
}

impl Epicentre {
    /// Creates a new epicentre at the given position.
    pub fn new(position: Vec3) -> Self {
        Self { position }
    }
}

/// The dominant consequence of a catastrophe.
///
/// Each catastrophe type has one dominant consequence as per
/// GAME_DESIGN_SECTION_3.md Section 3.2.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum Consequence {
    /// Primary loss of food stores and agricultural output (Flood, Drought).
    ResourceLoss,
    /// Primary damage to structures and infrastructure (Earthquake).
    StructuralDamage,
    /// Primary impact is displacement of population (Wildfire).
    Displacement,
    /// Primary impact is deaths by exposure (Blizzard).
    DeathsByExposure,
    /// Primary impact is sudden deaths from rapid event (Landslide).
    SuddenDeaths,
    /// Primary impact is crop and animal disease (Blight).
    CropAndAnimalDisease,
}

impl fmt::Display for Consequence {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Consequence::ResourceLoss => write!(f, "resource_loss"),
            Consequence::StructuralDamage => write!(f, "structural_damage"),
            Consequence::Displacement => write!(f, "displacement"),
            Consequence::DeathsByExposure => write!(f, "deaths_by_exposure"),
            Consequence::SuddenDeaths => write!(f, "sudden_deaths"),
            Consequence::CropAndAnimalDisease => write!(f, "crop_and_animal_disease"),
        }
    }
}

/// The type of catastrophe.
///
/// The seven catastrophe types defined in GAME_DESIGN_SECTION_3.md Section 3.2.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum CatastropheType {
    /// Water-based damage affecting low-lying areas.
    /// Dominant consequence: Resource loss.
    Flood,
    /// Ground shaking affecting structures.
    /// Dominant consequence: Structural damage.
    Earthquake,
    /// Fire spreading through flammable terrain.
    /// Dominant consequence: Displacement.
    Wildfire,
    /// Extreme cold and snow.
    /// Dominant consequence: Deaths by exposure.
    Blizzard,
    /// Extended period without precipitation.
    /// Dominant consequence: Slow resource depletion.
    Drought,
    /// Rock/earth movement on slopes.
    /// Dominant consequence: Sudden deaths.
    Landslide,
    /// Disease affecting crops and animals.
    /// Dominant consequence: Crop and animal disease.
    Blight,
}

impl CatastropheType {
    /// Returns the dominant consequence for this catastrophe type.
    pub fn dominant_consequence(&self) -> Consequence {
        match self {
            CatastropheType::Flood => Consequence::ResourceLoss,
            CatastropheType::Earthquake => Consequence::StructuralDamage,
            CatastropheType::Wildfire => Consequence::Displacement,
            CatastropheType::Blizzard => Consequence::DeathsByExposure,
            CatastropheType::Drought => Consequence::ResourceLoss,
            CatastropheType::Landslide => Consequence::SuddenDeaths,
            CatastropheType::Blight => Consequence::CropAndAnimalDisease,
        }
    }

    /// Returns the corresponding DamageType for compatibility with
    /// existing systems in anvil_core.
    pub fn to_damage_type(&self) -> DamageType {
        match self {
            CatastropheType::Flood => DamageType::Flood,
            CatastropheType::Earthquake => DamageType::Earthquake,
            CatastropheType::Wildfire => DamageType::Fire,
            CatastropheType::Blizzard => DamageType::Erosion, // Blizzard maps to erosion as closest match
            CatastropheType::Drought => DamageType::Drought,
            CatastropheType::Landslide => DamageType::Erosion,
            CatastropheType::Blight => DamageType::Erosion, // Blight maps to erosion as closest match
        }
    }

    /// Returns all catastrophe types.
    pub fn all() -> &'static [CatastropheType] {
        &[
            CatastropheType::Flood,
            CatastropheType::Earthquake,
            CatastropheType::Wildfire,
            CatastropheType::Blizzard,
            CatastropheType::Drought,
            CatastropheType::Landslide,
            CatastropheType::Blight,
        ]
    }
}

impl fmt::Display for CatastropheType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CatastropheType::Flood => write!(f, "flood"),
            CatastropheType::Earthquake => write!(f, "earthquake"),
            CatastropheType::Wildfire => write!(f, "wildfire"),
            CatastropheType::Blizzard => write!(f, "blizzard"),
            CatastropheType::Drought => write!(f, "drought"),
            CatastropheType::Landslide => write!(f, "landslide"),
            CatastropheType::Blight => write!(f, "blight"),
        }
    }
}

/// A catastrophe event in the simulation.
///
/// Represents a disaster that has occurred or is occurring in the world.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CatastropheEvent {
    /// Unique identifier for this event.
    pub id: u64,
    /// The type of catastrophe.
    pub catastrophe_type: CatastropheType,
    /// The magnitude of the event (0.0 to 1.0+).
    pub magnitude: f32,
    /// The radius of the affected area in world units.
    pub radius: f32,
    /// The epicentre of the event.
    pub epicentre: Epicentre,
    /// The simulation tick when this event was triggered.
    pub trigger_tick: u64,
    /// The dominant consequence of this event.
    pub consequence: Consequence,
    /// The set of positions affected by this event and their intensities.
    /// This is populated during spatial propagation.
    pub affected_areas: Vec<AffectedArea>,
}

impl CatastropheEvent {
    /// Creates a new catastrophe event.
    pub fn new(
        id: u64,
        catastrophe_type: CatastropheType,
        magnitude: f32,
        radius: f32,
        epicentre: Epicentre,
        trigger_tick: u64,
    ) -> Self {
        Self {
            id,
            catastrophe_type,
            magnitude,
            radius,
            epicentre,
            trigger_tick,
            consequence: catastrophe_type.dominant_consequence(),
            affected_areas: Vec::new(),
        }
    }

    /// Returns true if this event has completed spatial propagation.
    pub fn is_propagated(&self) -> bool {
        !self.affected_areas.is_empty()
    }
}

/// An area affected by a catastrophe and the intensity at that position.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct AffectedArea {
    /// The position of the affected area.
    pub position: Vec3,
    /// The intensity of the effect at this position (0.0 to 1.0).
    pub intensity: f32,
}

impl AffectedArea {
    /// Creates a new affected area.
    pub fn new(position: Vec3, intensity: f32) -> Self {
        Self { position, intensity }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_catastrophe_type_dominant_consequence() {
        assert_eq!(
            CatastropheType::Flood.dominant_consequence(),
            Consequence::ResourceLoss
        );
        assert_eq!(
            CatastropheType::Earthquake.dominant_consequence(),
            Consequence::StructuralDamage
        );
        assert_eq!(
            CatastropheType::Wildfire.dominant_consequence(),
            Consequence::Displacement
        );
        assert_eq!(
            CatastropheType::Blizzard.dominant_consequence(),
            Consequence::DeathsByExposure
        );
        assert_eq!(
            CatastropheType::Drought.dominant_consequence(),
            Consequence::ResourceLoss
        );
        assert_eq!(
            CatastropheType::Landslide.dominant_consequence(),
            Consequence::SuddenDeaths
        );
        assert_eq!(
            CatastropheType::Blight.dominant_consequence(),
            Consequence::CropAndAnimalDisease
        );
    }

    #[test]
    fn test_catastrophe_type_all() {
        let all = CatastropheType::all();
        assert_eq!(all.len(), 7);
        assert!(all.contains(&CatastropheType::Flood));
        assert!(all.contains(&CatastropheType::Earthquake));
        assert!(all.contains(&CatastropheType::Wildfire));
        assert!(all.contains(&CatastropheType::Blizzard));
        assert!(all.contains(&CatastropheType::Drought));
        assert!(all.contains(&CatastropheType::Landslide));
        assert!(all.contains(&CatastropheType::Blight));
    }

    #[test]
    fn test_catastrophe_event_creation() {
        let event = CatastropheEvent::new(
            1,
            CatastropheType::Flood,
            0.8,
            50.0,
            Epicentre::new(Vec3::new(0.0, 0.0, 0.0)),
            100,
        );
        assert_eq!(event.id, 1);
        assert_eq!(event.catastrophe_type, CatastropheType::Flood);
        assert!(!event.is_propagated());
        assert_eq!(event.consequence, Consequence::ResourceLoss);
    }

    #[test]
    fn test_affected_area_creation() {
        let area = AffectedArea::new(Vec3::new(10.0, 0.0, 5.0), 0.75);
        assert_eq!(area.position, Vec3::new(10.0, 0.0, 5.0));
        assert_eq!(area.intensity, 0.75);
    }
}
