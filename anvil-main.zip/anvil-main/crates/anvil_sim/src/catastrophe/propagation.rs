//! Spatial propagation of catastrophes.
//!
//! This module implements the spatial propagation rules described in
//! GAME_DESIGN_SECTION_3.md Section 3.2 for each catastrophe type.

use super::event::{AffectedArea, CatastropheEvent, CatastropheType};
use crate::DeterministicRng;
use glam::Vec3;

/// Defines how a catastrophe propagates through space.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[non_exhaustive]
pub enum PropagationModel {
    /// Flood: follows terrain height (lowest neighbours first).
    TerrainHeight,
    /// Wildfire: follows wind direction and dry vegetation.
    WindAndFuel,
    /// Earthquake: radial attenuation from epicentre.
    RadialAttenuation,
    /// Blizzard: region-wide, intensity varies with exposure.
    RegionWideExposure,
    /// Drought: region-wide, no spatial spread.
    RegionWide,
    /// Landslide: localised to the slope where triggered.
    LocalisedSlope,
    /// Blight: spreads via proximity to infected plants/animals.
    ProximitySpread,
}

impl PropagationModel {
    /// Returns the propagation model for a given catastrophe type.
    pub fn for_catastrophe(catastrophe_type: CatastropheType) -> Self {
        match catastrophe_type {
            CatastropheType::Flood => PropagationModel::TerrainHeight,
            CatastropheType::Earthquake => PropagationModel::RadialAttenuation,
            CatastropheType::Wildfire => PropagationModel::WindAndFuel,
            CatastropheType::Blizzard => PropagationModel::RegionWideExposure,
            CatastropheType::Drought => PropagationModel::RegionWide,
            CatastropheType::Landslide => PropagationModel::LocalisedSlope,
            CatastropheType::Blight => PropagationModel::ProximitySpread,
        }
    }
}

/// Spatial propagation state and logic.
///
/// This struct handles the deterministic spatial propagation of
/// catastrophes through the world.
#[derive(Debug, Clone)]
pub struct SpatialPropagation;

impl SpatialPropagation {
    /// Creates a new spatial propagation handler.
    pub fn new() -> Self {
        Self
    }

    /// Propagates a catastrophe event through space and returns the affected areas.
    ///
    /// This method uses the propagation model appropriate for the catastrophe type
    /// and the deterministic RNG to produce consistent results.
    ///
    /// # Arguments
    /// * `event` - The catastrophe event to propagate.
    /// * `_rng` - The deterministic RNG for reproducible results (currently unused, placeholder for future use).
    /// * `terrain_height_fn` - A function that returns the terrain height at a given position.
    /// * `wind_direction` - The current wind direction in radians.
    /// * `vegetation_density_fn` - A function that returns the vegetation density at a position.
    ///
    /// # Returns
    /// The event with its `affected_areas` field populated.
    pub fn propagate<F, G>(
        &self,
        mut event: CatastropheEvent,
        _rng: &mut DeterministicRng,
        terrain_height_fn: F,
        wind_direction: f32,
        vegetation_density_fn: G,
    ) -> CatastropheEvent
    where
        F: Fn(Vec3) -> f32,
        G: Fn(Vec3) -> f32,
    {
        let model = PropagationModel::for_catastrophe(event.catastrophe_type);
        // Generate candidate positions within the radius
        // For determinism, we use the RNG to generate a fixed number of samples
        const NUM_SAMPLES: usize = 100;
        let mut candidates = Vec::with_capacity(NUM_SAMPLES);

        // Use a simple deterministic sampling pattern
        // We'll generate samples in a grid-like pattern using the RNG for offset
        for i in 0..NUM_SAMPLES {
            // Simple hash-based distribution for determinism
            let angle = 2.0 * std::f32::consts::PI * (i as f32 / NUM_SAMPLES as f32);
            let distance = event.radius * ((i as f32 / NUM_SAMPLES as f32).sqrt());
            let offset_x = distance * angle.cos();
            let offset_z = distance * angle.sin();
            let position = Vec3::new(
                event.epicentre.position.x + offset_x,
                0.0,
                event.epicentre.position.z + offset_z,
            );
            candidates.push(position);
        }

        // Calculate intensity for each candidate based on propagation model
        let mut affected_areas = Vec::new();
        for position in candidates {
            let intensity = self.calculate_intensity(
                &event,
                position,
                &model,
                &terrain_height_fn,
                wind_direction,
                &vegetation_density_fn,
            );

            if intensity > 0.0 {
                affected_areas.push(AffectedArea::new(position, intensity));
            }
        }

        // Sort by intensity (descending) for predictable ordering
        affected_areas.sort_by(|a, b| b.intensity.partial_cmp(&a.intensity).unwrap_or(std::cmp::Ordering::Equal));

        event.affected_areas = affected_areas;
        event
    }

    /// Calculates the intensity of a catastrophe at a given position.
    fn calculate_intensity<F, G>(
        &self,
        event: &CatastropheEvent,
        position: Vec3,
        model: &PropagationModel,
        terrain_height_fn: &F,
        wind_direction: f32,
        vegetation_density_fn: &G,
    ) -> f32
    where
        F: Fn(Vec3) -> f32,
        G: Fn(Vec3) -> f32,
    {
        let distance = Vec3::new(
            position.x - event.epicentre.position.x,
            0.0,
            position.z - event.epicentre.position.z,
        ).length();

        if distance > event.radius {
            return 0.0;
        }

        let normalized_distance = distance / event.radius;

        match model {
            PropagationModel::TerrainHeight => {
                // Flood: follows terrain height (lowest neighbours first)
                // Lower terrain = higher intensity
                let epicentre_height = terrain_height_fn(event.epicentre.position);
                let position_height = terrain_height_fn(position);
                let height_diff = epicentre_height - position_height;
                // More positive height_diff = lower position = more flood intensity
                let height_factor = (height_diff / event.radius).clamp(0.0, 1.0);
                event.magnitude * (1.0 - normalized_distance) * (0.5 + height_factor)
            }
            PropagationModel::WindAndFuel => {
                // Wildfire: follows wind direction and dry vegetation
                let direction_vec = Vec3::new(
                    event.epicentre.position.x - position.x,
                    0.0,
                    event.epicentre.position.z - position.z,
                );
                let direction_vec = if direction_vec.length() > 0.0 {
                    direction_vec.normalize()
                } else {
                    Vec3::ZERO
                };

                // Dot product with wind direction (wind blows FROM direction)
                let wind_vec = Vec3::new(wind_direction.cos(), 0.0, wind_direction.sin());
                let wind_alignment = (direction_vec.dot(wind_vec) + 1.0) / 2.0;

                // Vegetation density factor (more fuel = more fire)
                let fuel_factor = vegetation_density_fn(position).clamp(0.0, 1.0);

                event.magnitude * (1.0 - normalized_distance) * wind_alignment * fuel_factor
            }
            PropagationModel::RadialAttenuation => {
                // Earthquake: radial attenuation from epicentre
                // Simple inverse square law attenuation
                if distance == 0.0 {
                    event.magnitude
                } else {
                    event.magnitude * (1.0 - normalized_distance.powi(2))
                }
            }
            PropagationModel::RegionWideExposure => {
                // Blizzard: region-wide, intensity varies with exposure
                // For now, use simple radial falloff
                // In a real implementation, this would check for shelter/obstructions
                event.magnitude * (1.0 - normalized_distance * 0.5)
            }
            PropagationModel::RegionWide => {
                // Drought: region-wide, no spatial spread
                // Uniform intensity across the entire radius
                event.magnitude
            }
            PropagationModel::LocalisedSlope => {
                // Landslide: localised to the slope where triggered
                // Higher intensity near epicentre, steep drop-off
                if normalized_distance < 0.3 {
                    event.magnitude * (1.0 - normalized_distance * 3.0).max(0.0)
                } else {
                    0.0
                }
            }
            PropagationModel::ProximitySpread => {
                // Blight: spreads via proximity to infected plants/animals
                // Simulates transmission between nearby entities
                if normalized_distance < 0.5 {
                    event.magnitude * (1.0 - normalized_distance * 2.0)
                } else {
                    0.0
                }
            }
        }
    }
}

impl Default for SpatialPropagation {
    fn default() -> Self {
        Self::new()
    }
}



#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_propagation_model_for_catastrophe() {
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Flood),
            PropagationModel::TerrainHeight
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Earthquake),
            PropagationModel::RadialAttenuation
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Wildfire),
            PropagationModel::WindAndFuel
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Blizzard),
            PropagationModel::RegionWideExposure
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Drought),
            PropagationModel::RegionWide
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Landslide),
            PropagationModel::LocalisedSlope
        );
        assert_eq!(
            PropagationModel::for_catastrophe(CatastropheType::Blight),
            PropagationModel::ProximitySpread
        );
    }

    #[test]
    fn test_spatial_propagation_creates_affected_areas() {
        let mut rng = DeterministicRng::new(42);
        use crate::catastrophe::Epicentre;
        let event = CatastropheEvent::new(
            1,
            CatastropheType::Earthquake,
            1.0,
            50.0,
            Epicentre::new(Vec3::new(0.0, 0.0, 0.0)),
            0,
        );

        let prop = SpatialPropagation::new();
        let terrain_fn = |_pos: Vec3| 0.0;
        let vegetation_fn = |_pos: Vec3| 0.5;

        let propagated = prop.propagate(event, &mut rng, terrain_fn, 0.0, vegetation_fn);
        assert!(!propagated.affected_areas.is_empty());
        assert!(propagated.is_propagated());
    }

    #[test]
    fn test_vec3_length() {
        let v = Vec3::new(3.0, 4.0, 0.0);
        assert!((v.length() - 5.0).abs() < 0.001);
    }

    #[test]
    fn test_vec3_normalize() {
        let v = Vec3::new(3.0, 4.0, 0.0);
        let normalized = v.normalize();
        // glam::Vec3::normalize() returns Vec3 (panics if length is 0)
        assert!((normalized.length() - 1.0).abs() < 0.001);
    }
}
