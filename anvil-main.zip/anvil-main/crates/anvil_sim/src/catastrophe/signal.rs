//! Precursor signals for catastrophes.
//!
//! This module implements the precursor signal system described in
//! GAME_DESIGN_SECTION_3.md Section 3.5.

use serde::{Deserialize, Serialize};
use std::fmt;

/// The kind of precursor signal.
///
/// Signals are categorized into three channels as per Section 3.5.1:
/// environmental, animal, and NPC-knowledge.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum SignalKind {
    /// Environmental signals: visible or measurable changes in the environment.
    /// Examples: rising water levels, temperature drops, dark clouds.
    Environmental,
    /// Animal signals: changes in animal behavior that indicate danger.
    /// Examples: animals fleeing, birds roosting at odd hours, dogs whining.
    Animal,
    /// NPC-knowledge signals: observations or statements by NPCs with relevant experience.
    /// Examples: elders mentioning past events, healers inspecting plants with concern.
    NpcKnowledge,
}

impl fmt::Display for SignalKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SignalKind::Environmental => write!(f, "environmental"),
            SignalKind::Animal => write!(f, "animal"),
            SignalKind::NpcKnowledge => write!(f, "npc_knowledge"),
        }
    }
}

/// A precursor signal emitted before a catastrophe occurs.
///
/// These signals warn players (and NPCs) about impending disasters.
/// The intensity and timing of signals are deterministic based on the
/// catastrophe type and the current simulation state.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PrecursorSignal {
    /// Unique identifier for this signal.
    pub id: u64,
    /// The kind of signal (environmental, animal, or NPC-knowledge).
    pub kind: SignalKind,
    /// The intensity of the signal (0.0 to 1.0).
    /// Higher intensity means the signal is more noticeable and urgent.
    pub intensity: f32,
    /// Human-readable description of the signal.
    pub description: String,
    /// The catastrophe type this signal is associated with.
    pub catastrophe_type: super::event::CatastropheType,
    /// The simulation tick when this signal was emitted.
    pub emit_tick: u64,
    /// The number of ticks until the catastrophe is expected to trigger.
    /// This is used to calculate signal intensity.
    pub ticks_until_catastrophe: u64,
}

impl PrecursorSignal {
    /// Creates a new precursor signal.
    pub fn new(
        id: u64,
        kind: SignalKind,
        intensity: f32,
        description: String,
        catastrophe_type: super::event::CatastropheType,
        emit_tick: u64,
        ticks_until_catastrophe: u64,
    ) -> Self {
        Self {
            id,
            kind,
            intensity,
            description,
            catastrophe_type,
            emit_tick,
            ticks_until_catastrophe,
        }
    }

    /// Returns true if this is an environmental signal.
    pub fn is_environmental(&self) -> bool {
        matches!(self.kind, SignalKind::Environmental)
    }

    /// Returns true if this is an animal signal.
    pub fn is_animal(&self) -> bool {
        matches!(self.kind, SignalKind::Animal)
    }

    /// Returns true if this is an NPC-knowledge signal.
    pub fn is_npc_knowledge(&self) -> bool {
        matches!(self.kind, SignalKind::NpcKnowledge)
    }
}

/// Typical precursor signals for each catastrophe type as per Section 3.5.
///
/// These are the default signals that can be customized per biome.
pub fn typical_signals(
    catastrophe_type: super::event::CatastropheType,
) -> &'static [(SignalKind, &'static str)] {
    match catastrophe_type {
        super::event::CatastropheType::Flood => &[
            (SignalKind::Environmental, "Prolonged rain"),
            (SignalKind::Environmental, "Rising river levels"),
            (SignalKind::Animal, "Frogs moving to high ground"),
            (
                SignalKind::NpcKnowledge,
                "Elders mentioning the year the river swallowed the bridge",
            ),
        ],
        super::event::CatastropheType::Earthquake => &[
            (SignalKind::Environmental, "Minor tremors"),
            (SignalKind::Animal, "Animals behaving erratically"),
            (SignalKind::Animal, "Dogs whining"),
            (SignalKind::NpcKnowledge, "Elder's trick knee aching"),
        ],
        super::event::CatastropheType::Wildfire => &[
            (
                SignalKind::Environmental,
                "Dry conditions lasting more than a season",
            ),
            (SignalKind::Environmental, "Smoke on the horizon"),
            (SignalKind::Environmental, "Wind shifting toward the village"),
            (SignalKind::Animal, "Animals fleeing in a consistent direction"),
        ],
        super::event::CatastropheType::Blizzard => &[
            (SignalKind::Environmental, "Sudden temperature drop"),
            (
                SignalKind::Environmental,
                "Sky taking on a particular grey-white",
            ),
            (SignalKind::Environmental, "Wind direction shifting north"),
            (
                SignalKind::NpcKnowledge,
                "NPCs who have survived blizzards before pulling their families indoors",
            ),
        ],
        super::event::CatastropheType::Drought => &[
            (SignalKind::Environmental, "No rain for N days"),
            (SignalKind::Environmental, "Soil visibly dry"),
            (SignalKind::NpcKnowledge, "NPCs commenting on the sky every morning"),
            (SignalKind::NpcKnowledge, "Elder saying we should have stored more"),
        ],
        super::event::CatastropheType::Landslide => &[
            (SignalKind::Environmental, "Rain on steep terrain"),
            (SignalKind::Environmental, "Visible cracks in hillsides"),
            (SignalKind::Environmental, "Loose stone falling from cliffs"),
            (SignalKind::Environmental, "The sound of creaking earth"),
        ],
        super::event::CatastropheType::Blight => &[
            (SignalKind::Environmental, "Dark spots on leaves"),
            (SignalKind::Animal, "Animals coughing"),
            (SignalKind::Environmental, "A specific smell"),
            (
                SignalKind::NpcKnowledge,
                "Healer inspecting plants with concern",
            ),
        ],
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::catastrophe::CatastropheType;

    #[test]
    fn test_precursor_signal_creation() {
        let signal = PrecursorSignal::new(
            1,
            SignalKind::Environmental,
            0.5,
            "Rising river levels".to_string(),
            CatastropheType::Flood,
            100,
            50,
        );
        assert_eq!(signal.id, 1);
        assert!(signal.is_environmental());
        assert!(!signal.is_animal());
        assert!(!signal.is_npc_knowledge());
    }

    #[test]
    fn test_typical_signals_flood() {
        let signals = typical_signals(CatastropheType::Flood);
        assert_eq!(signals.len(), 4);
        assert!(signals
            .iter()
            .any(|(kind, desc)| *kind == SignalKind::Environmental && *desc == "Prolonged rain"));
    }

    #[test]
    fn test_typical_signals_earthquake() {
        let signals = typical_signals(CatastropheType::Earthquake);
        assert!(signals
            .iter()
            .any(|(kind, desc)| *kind == SignalKind::Animal && *desc == "Animals behaving erratically"));
    }

    #[test]
    fn test_signal_kind_display() {
        assert_eq!(format!("{}", SignalKind::Environmental), "environmental");
        assert_eq!(format!("{}", SignalKind::Animal), "animal");
        assert_eq!(format!("{}", SignalKind::NpcKnowledge), "npc_knowledge");
    }
}
