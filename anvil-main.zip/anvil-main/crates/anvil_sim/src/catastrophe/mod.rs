//! Catastrophe simulation system.
//!
//! This module implements the catastrophe system described in GAME_DESIGN_SECTION_3.md
//! Section 3.2. It generalizes the weather simulation to handle all seven catastrophe
//! types: Flood, Earthquake, Wildfire, Blizzard, Drought, Landslide, and Blight.

pub mod event;
pub mod propagation;
pub mod signal;

pub use event::{AffectedArea, CatastropheEvent, CatastropheType, Consequence, Epicentre};
pub use propagation::{PropagationModel, SpatialPropagation};
pub use signal::{PrecursorSignal, SignalKind};
