//! Skill Practice and Decay
//!
//! Implements the practice curve (logistic growth) and decay (asymptotic with floor)
//! functions as specified in Sprint 18a design decisions.
//!
//! Practice: maturity_delta = base_rate * (1.0 - maturity) * deliberate_modifier
//! Decay: maturity = floor + (maturity - floor) * exp(-decay_rate * dt)
//! where floor = 0.2 * peak_maturity

use super::{AffordanceCatalogue, AffordanceId, MaturityState, SkillEvent, SkillProfile};
use crate::settlement::ids::PersonId;
use crate::skill::catalogue::{BASE_DECAY_RATE, BASE_PRACTICE_RATE, DECAY_GRACE_PERIOD_DAYS, TICKS_PER_DAY};
use crate::skill::event::ActionOutcome;

/// Deliberate practice modifier for unlocked affordances (normal practice).
pub const DELIBERATE_MODIFIER_NORMAL: f32 = 1.0;

/// Deliberate practice modifier for locked affordances (focused practice).
pub const DELIBERATE_MODIFIER_FOCUSED: f32 = 1.5;

/// Observation learning rate multiplier.
pub const OBSERVATION_RATE_MULTIPLIER: f32 = 0.15;

/// Default unlock threshold for affordances.
pub const DEFAULT_UNLOCK_THRESHOLD: f32 = 0.75;

/// Applies practice to a skill profile based on a skill event.
///
/// This implements the practice curve from Sprint 18a Design Decision 5:
/// maturity_delta = base_rate * (1.0 - maturity) * deliberate_modifier * age_modifier * emotion_modifier * time_modifier
///
/// For ActionCompleted with Success or Partial:
/// - Compute delta with all modifiers and add to maturity
/// - Clamp to [0.0, 1.0]
/// - Update peak_maturity if exceeded
/// - Set last_practice_tick to current_tick
/// - Check unlock condition
///
/// For ActionCompleted with Failure:
/// - Record last_failure_tick (for future breakthrough processing in 18b)
/// - No maturity change
///
/// For ObservationGained:
/// - Apply small maturity increment at reduced rate with modifiers
/// - Set last_practice_tick
///
/// For DecayTick:
/// - Call apply_decay
///
/// Sprint 18c: Integrates age, time-of-day, and emotional modifiers into practice.
pub fn apply_practice(
    profile: &mut SkillProfile,
    event: &SkillEvent,
    catalogue: &AffordanceCatalogue,
    current_tick: u64,
) -> Vec<SkillEvent> {
    let mut unlock_events = Vec::new();

    match event {
        SkillEvent::ActionCompleted {
            person_id: _,
            affordance_id,
            outcome,
            context_modifiers,
        } => {
            // Determine if this affordance is already unlocked
            let is_unlocked = profile.is_unlocked(*affordance_id);
            let deliberate_modifier = if is_unlocked {
                DELIBERATE_MODIFIER_NORMAL
            } else {
                DELIBERATE_MODIFIER_FOCUSED
            };

            // Get modifiers from context (Sprint 18c)
            let age_modifier = context_modifiers.age_learning_multiplier.unwrap_or(1.0);
            let emotion_modifier = context_modifiers.practice_quality_multiplier.unwrap_or(1.0);
            
            // Get time modifier if we have time_of_day and can determine the domain
            let time_modifier = if let (Some(tod), Some(affordance)) = (
                context_modifiers.time_of_day,
                catalogue.get(*affordance_id)
            ) {
                crate::time::time_learning_modifier(tod, affordance.domain)
            } else {
                1.0
            };

            // Only apply practice for Success or Partial outcomes
            if *outcome == ActionOutcome::Success || *outcome == ActionOutcome::Partial {
                // Get or create the maturity state for this affordance
                let state = profile.maturities.entry(*affordance_id).or_default();

                // Compute maturity delta with all modifiers (Sprint 18c)
                let maturity_delta = BASE_PRACTICE_RATE 
                    * (1.0 - state.maturity) 
                    * deliberate_modifier
                    * age_modifier
                    * emotion_modifier
                    * time_modifier;

                // Update maturity
                let new_maturity = (state.maturity + maturity_delta).clamp(0.0, 1.0);

                // Update peak maturity if this is a new high
                let new_peak = if new_maturity > state.peak_maturity {
                    new_maturity
                } else {
                    state.peak_maturity
                };

                // Update the state
                *state = MaturityState {
                    maturity: new_maturity,
                    peak_maturity: new_peak,
                    last_practice_tick: current_tick,
                    last_failure_tick: state.last_failure_tick,
                };

                // Check unlock condition
                if !is_unlocked && new_maturity >= catalogue.get(*affordance_id).map_or(0.75, |a| a.unlock_threshold) {
                    profile.unlocked.insert(*affordance_id);
                    unlock_events.push(SkillEvent::AffordanceUnlocked {
                        person_id: event.person_id(),
                        affordance_id: *affordance_id,
                    });
                }
            } else if *outcome == ActionOutcome::Failure {
                // Record failure for future breakthrough processing (Sprint 18b)
                let state = profile.maturities.entry(*affordance_id).or_default();
                *state = MaturityState {
                    maturity: state.maturity,
                    peak_maturity: state.peak_maturity,
                    last_practice_tick: state.last_practice_tick,
                    last_failure_tick: current_tick,
                };
            }
        }
        SkillEvent::ObservationGained {
            observer_id: _,
            demonstrator_id: _,
            affordance_id,
            context_modifiers,
        } => {
            // Get or create the maturity state for this affordance
            let state = profile.maturities.entry(*affordance_id).or_default();

            // Get modifiers from context (Sprint 18c)
            let age_modifier = context_modifiers.age_learning_multiplier.unwrap_or(1.0);
            let observation_emotion_modifier = context_modifiers.observation_rate_multiplier.unwrap_or(1.0);
            
            // Get time modifier if we have time_of_day and can determine the domain
            let time_modifier = if let (Some(tod), Some(affordance)) = (
                context_modifiers.time_of_day,
                catalogue.get(*affordance_id)
            ) {
                crate::time::time_learning_modifier(tod, affordance.domain)
            } else {
                1.0
            };

            // Apply small maturity increment at reduced rate with all modifiers (incidental learning)
            let observation_rate = BASE_PRACTICE_RATE * OBSERVATION_RATE_MULTIPLIER;
            let maturity_delta = observation_rate 
                * (1.0 - state.maturity)
                * age_modifier
                * observation_emotion_modifier
                * time_modifier;

            let new_maturity = (state.maturity + maturity_delta).clamp(0.0, 1.0);

            // Update peak maturity if this is a new high
            let new_peak = if new_maturity > state.peak_maturity {
                new_maturity
            } else {
                state.peak_maturity
            };

            // Update the state
            *state = MaturityState {
                maturity: new_maturity,
                peak_maturity: new_peak,
                last_practice_tick: current_tick,
                last_failure_tick: state.last_failure_tick,
            };

            // Check unlock condition
            let threshold = catalogue.get(*affordance_id).map_or(0.75, |a| a.unlock_threshold);
            if !profile.is_unlocked(*affordance_id) && new_maturity >= threshold {
                profile.unlocked.insert(*affordance_id);
                unlock_events.push(SkillEvent::AffordanceUnlocked {
                    person_id: event.person_id(),
                    affordance_id: *affordance_id,
                });
            }
        }
        SkillEvent::AffordanceUnlocked { .. } | SkillEvent::DecayTick { .. } => {
            // These event types are handled elsewhere
            // AffordanceUnlocked is an output, not an input for practice
            // DecayTick is handled by apply_decay
        }
    }

    unlock_events
}

/// Applies decay to all affordances in a skill profile.
///
/// This implements the decay function from Sprint 18a Design Decision 6:
/// maturity = floor + (maturity - floor) * exp(-decay_rate * dt * emotion_multiplier)
/// where:
/// - floor = 0.2 * peak_maturity (you never fully forget)
/// - decay_rate = BASE_DECAY_RATE
/// - dt = (current_tick - last_practice_tick) / TICKS_PER_DAY
/// - emotion_multiplier = emotional decay rate multiplier (Sprint 18c)
///
/// Decay only applies if dt > DECAY_GRACE_PERIOD_DAYS.
///
/// Unlocked affordances are NEVER removed from the unlocked set.
///
/// Sprint 18c: Integrates emotional modifiers into decay rate.
pub fn apply_decay(profile: &mut SkillProfile, current_tick: u64, emotion_decay_multiplier: Option<f32>) {
    let emotion_multiplier = emotion_decay_multiplier.unwrap_or(1.0);
    
    for (_affordance_id, state) in profile.maturities.iter_mut() {
        let dt = if TICKS_PER_DAY > 0 {
            (current_tick - state.last_practice_tick) as f32 / TICKS_PER_DAY as f32
        } else {
            0.0
        };

        // Only apply decay if grace period has passed
        if dt > DECAY_GRACE_PERIOD_DAYS {
            // Compute floor: you never fully forget
            let floor = 0.2 * state.peak_maturity;

            // Compute decay factor with emotional multiplier (Sprint 18c)
            // maturity = floor + (maturity - floor) * exp(-decay_rate * dt * emotion_multiplier)
            let effective_decay_rate = BASE_DECAY_RATE * emotion_multiplier;
            let decay_factor = (-effective_decay_rate * dt).exp();
            let new_maturity = floor + (state.maturity - floor) * decay_factor;

            // Clamp to valid range
            *state = MaturityState {
                maturity: new_maturity.clamp(0.0, 1.0),
                peak_maturity: state.peak_maturity,
                last_practice_tick: state.last_practice_tick,
                last_failure_tick: state.last_failure_tick,
            };
        }
    }
}

/// Checks if an affordance should be unlocked and emits the unlock event if so.
///
/// This is a separate function for explicit unlock checking after maturity changes.
/// Called automatically by apply_practice, but can also be called manually.
pub fn check_unlock(
    profile: &mut SkillProfile,
    affordance_id: AffordanceId,
    catalogue: &AffordanceCatalogue,
    person_id: PersonId,
) -> Option<SkillEvent> {
    if let Some(affordance) = catalogue.get(affordance_id) {
        let maturity = profile.get_maturity_value(affordance_id);
        if maturity >= affordance.unlock_threshold && !profile.is_unlocked(affordance_id) {
            profile.unlocked.insert(affordance_id);
            return Some(SkillEvent::AffordanceUnlocked {
                person_id,
                affordance_id,
            });
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::skill::affordance::Affordance;
    use crate::skill::domain::SkillDomain;

    fn create_test_catalogue() -> AffordanceCatalogue {
        let mut catalogue = AffordanceCatalogue::new();
        catalogue.add(Affordance::with_default_threshold(
            AffordanceId::new(1),
            SkillDomain::Husbandry,
            "soil_moisture_reading",
        ));
        catalogue.add(Affordance::with_default_threshold(
            AffordanceId::new(2),
            SkillDomain::Woodcraft,
            "grain_reading",
        ));
        catalogue
    }

    #[test]
    fn test_apply_practice_success() {
        use crate::settlement::ids::PersonId;
        use crate::skill::event::ContextModifiers;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        
        // Add the affordance with 0 maturity
        profile.add_affordance(affordance_id);

        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };

        let unlock_events = apply_practice(&mut profile, &event, &catalogue, 100);

        // Maturity should have increased
        let maturity = profile.get_maturity_value(affordance_id);
        assert!(maturity > 0.0);

        // Last practice tick should be updated
        let state = profile.get_maturity(affordance_id).unwrap();
        assert_eq!(state.last_practice_tick, 100);

        // Should not be unlocked yet (needs to reach threshold)
        assert!(!profile.is_unlocked(affordance_id));
        assert!(unlock_events.is_empty());
    }

    #[test]
    fn test_apply_practice_focused_when_locked() {
        use crate::settlement::ids::PersonId;
        use crate::skill::event::ContextModifiers;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        profile.add_affordance(affordance_id);

        // First practice with focused modifier (not yet unlocked)
        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };

        apply_practice(&mut profile, &event, &catalogue, 100);
        let maturity1 = profile.get_maturity_value(affordance_id);

        // Unlock it
        profile.unlock(affordance_id);

        // Second practice with normal modifier (now unlocked)
        let event2 = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };

        apply_practice(&mut profile, &event2, &catalogue, 200);
        let maturity2 = profile.get_maturity_value(affordance_id);

        // The first practice (focused) should have given more growth than the second (normal)
        // But we can't directly compare because maturity approaches 1.0 asymptotically
        // So just verify both increased maturity
        assert!(maturity2 > maturity1);
    }

    #[test]
    fn test_apply_practice_failure_records_failure() {
        use crate::settlement::ids::PersonId;
        use crate::skill::event::ContextModifiers;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        profile.add_affordance(affordance_id);

        let initial_maturity = profile.get_maturity_value(affordance_id);

        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Failure,
            context_modifiers: ContextModifiers::new(),
        };

        apply_practice(&mut profile, &event, &catalogue, 100);

        // Maturity should NOT have increased
        assert_eq!(profile.get_maturity_value(affordance_id), initial_maturity);

        // Last failure tick should be updated
        let state = profile.get_maturity(affordance_id).unwrap();
        assert_eq!(state.last_failure_tick, 100);
    }

    #[test]
    fn test_apply_practice_observation() {
        use crate::settlement::ids::PersonId;
        use crate::skill::event::ContextModifiers;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        profile.add_affordance(affordance_id);

        let event = SkillEvent::ObservationGained {
            observer_id: PersonId::new(1),
            demonstrator_id: PersonId::new(2),
            affordance_id,
            context_modifiers: ContextModifiers::new(),
        };

        apply_practice(&mut profile, &event, &catalogue, 100);

        // Maturity should have increased (but at reduced rate)
        let maturity = profile.get_maturity_value(affordance_id);
        assert!(maturity > 0.0);

        // Last practice tick should be updated
        let state = profile.get_maturity(affordance_id).unwrap();
        assert_eq!(state.last_practice_tick, 100);
    }

    #[test]
    fn test_apply_practice_unlock() {
        use crate::settlement::ids::PersonId;
        use crate::skill::event::ContextModifiers;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        profile.add_affordance(affordance_id);

        // Practice many times to reach unlock threshold
        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };

        // Apply practice many times
        for tick in 1..=100 {
            let unlock_events = apply_practice(&mut profile, &event, &catalogue, tick);
            if !unlock_events.is_empty() {
                // Unlock happened
                assert!(profile.is_unlocked(affordance_id));
                break;
            }
        }

        // Should eventually be unlocked
        // With focused modifier and base rate of 0.02, it takes about 39 iterations
        // to reach 0.75 threshold: 0.75 = 1 - (1 - 0.02*1.5)^n
        // Solving: (0.97)^n = 0.25, n = ln(0.25)/ln(0.97) ≈ 54.9
        assert!(profile.is_unlocked(affordance_id));
    }

    #[test]
    fn test_apply_decay_no_decay_within_grace_period() {
        let mut profile = SkillProfile::new();
        
        let affordance_id = AffordanceId::new(1);
        profile.maturities.insert(affordance_id, MaturityState {
            maturity: 0.8,
            peak_maturity: 0.8,
            last_practice_tick: 1000,
            last_failure_tick: 0,
        });

        // Current tick is within grace period (1 day = 1000 ticks)
        apply_decay(&mut profile, 1500, None); // Only 500 ticks passed, < 1000

        // Maturity should not have changed
        let maturity = profile.get_maturity_value(affordance_id);
        assert!((maturity - 0.8).abs() < 0.0001);
    }

    #[test]
    fn test_apply_decay_with_decay() {
        let mut profile = SkillProfile::new();
        
        let affordance_id = AffordanceId::new(1);
        profile.maturities.insert(affordance_id, MaturityState {
            maturity: 0.8,
            peak_maturity: 0.8,
            last_practice_tick: 0,
            last_failure_tick: 0,
        });

        // Current tick is well past grace period
        // dt = 2000 / 1000 = 2.0 days
        apply_decay(&mut profile, 2000, None);

        // Maturity should have decayed
        let maturity = profile.get_maturity_value(affordance_id);
        assert!(maturity < 0.8);

        // Floor should be 0.2 * peak = 0.2 * 0.8 = 0.16
        // maturity = 0.16 + (0.8 - 0.16) * exp(-0.1 * 2.0)
        // = 0.16 + 0.64 * exp(-0.2)
        // = 0.16 + 0.64 * 0.8187
        // = 0.16 + 0.524
        // = 0.684 (approximately)
        let expected = 0.16f32 + (0.8f32 - 0.16f32) * (-0.1f32 * 2.0f32).exp();
        assert!((maturity - expected).abs() < 0.001);
    }

    #[test]
    fn test_apply_decay_never_forgets_completely() {
        let mut profile = SkillProfile::new();
        
        let affordance_id = AffordanceId::new(1);
        profile.maturities.insert(affordance_id, MaturityState {
            maturity: 1.0,
            peak_maturity: 1.0,
            last_practice_tick: 0,
            last_failure_tick: 0,
        });

        // Decay for a long time
        apply_decay(&mut profile, 10000, None); // 10 days

        // Maturity should be approaching but not below floor
        let maturity = profile.get_maturity_value(affordance_id);
        let floor = 0.2 * 1.0; // 0.2
        assert!(maturity >= floor - 0.001); // Allow small floating point error
    }

    #[test]
    fn test_check_unlock() {
        use crate::settlement::ids::PersonId;
        
        let catalogue = create_test_catalogue();
        let mut profile = SkillProfile::new();

        let affordance_id = AffordanceId::new(1);
        let person_id = PersonId::new(1);
        
        // Set maturity just below threshold
        profile.maturities.insert(affordance_id, MaturityState {
            maturity: 0.74,
            peak_maturity: 0.74,
            last_practice_tick: 100,
            last_failure_tick: 0,
        });

        // Should not unlock
        let event = check_unlock(&mut profile, affordance_id, &catalogue, person_id);
        assert!(event.is_none());
        assert!(!profile.is_unlocked(affordance_id));

        // Increase maturity to just above threshold
        profile.maturities.insert(affordance_id, MaturityState {
            maturity: 0.76,
            peak_maturity: 0.76,
            last_practice_tick: 100,
            last_failure_tick: 0,
        });

        // Should unlock
        let event = check_unlock(&mut profile, affordance_id, &catalogue, person_id);
        assert!(event.is_some());
        assert!(profile.is_unlocked(affordance_id));
    }
}
