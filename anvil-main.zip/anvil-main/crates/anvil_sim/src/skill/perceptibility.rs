//! Perceptibility Mapping Framework
//!
//! Connects (SkillDomain, FluencyLevel) to perceptible gameplay effects:
//! - Animation states for visual feedback
//! - Action duration multipliers (lower fluency = slower)
//! - Resource waste multipliers (lower fluency = more waste)
//! - Sound profiles for audio feedback
//!
//! Sprint 18b implements duration and waste modifiers in NpcSystem.
//! Animation and audio are stored as string identifiers for future wiring.
//!
//! Defined in Sprint 18b design decisions.

use super::{FluencyLevel, SkillDomain};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Perceptibility modifiers for a (domain, fluency) combination.
///
/// These modifiers affect how actions are executed and perceived in the game world.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PerceptibilityModifiers {
    /// Animation state identifier that the renderer can use.
    /// Stored as String for future wiring to the Bevy layer.
    pub animation_state: String,
    /// Multiplier applied to action base duration.
    /// Higher values = longer duration (less skilled = slower).
    pub action_duration_multiplier: f32,
    /// Multiplier applied to resource waste.
    /// Higher values = more waste (less skilled = less efficient).
    pub resource_waste_multiplier: f32,
    /// Sound profile identifier for the audio system.
    /// Stored as String for future wiring.
    pub sound_profile: String,
}

impl Default for PerceptibilityModifiers {
    fn default() -> Self {
        Self {
            animation_state: "default".to_string(),
            action_duration_multiplier: 1.0,
            resource_waste_multiplier: 1.0,
            sound_profile: "default".to_string(),
        }
    }
}

impl PerceptibilityModifiers {
    /// Creates modifiers with all fields specified.
    pub fn new(
        animation_state: String,
        action_duration_multiplier: f32,
        resource_waste_multiplier: f32,
        sound_profile: String,
    ) -> Self {
        Self {
            animation_state,
            action_duration_multiplier,
            resource_waste_multiplier,
            sound_profile,
        }
    }
}

/// Static mapping from (SkillDomain, FluencyLevel) to PerceptibilityModifiers.
///
/// Uses a HashMap for efficient lookup. The mapping is defined once at
/// module load time and shared across all lookups.
pub struct PerceptibilityMapper {
    /// Inner map: domain -> (fluency -> modifiers)
    modifiers: HashMap<SkillDomain, HashMap<FluencyLevel, PerceptibilityModifiers>>,
}

impl Default for PerceptibilityMapper {
    fn default() -> Self {
        Self::new()
    }
}

impl PerceptibilityMapper {
    /// Creates a new perceptibility mapper with default mappings.
    pub fn new() -> Self {
        let mut modifiers: HashMap<SkillDomain, HashMap<FluencyLevel, PerceptibilityModifiers>> =
            HashMap::new();

        // Initialize mappings for each domain
        for domain in SkillDomain::all() {
            let domain_modifiers = Self::create_domain_mapping(*domain);
            modifiers.insert(*domain, domain_modifiers);
        }

        Self { modifiers }
    }

    /// Creates the modifier mapping for a specific domain.
    ///
    /// All domains share the same fluency-level modifiers, but have
    /// domain-specific animation states and sound profiles.
    fn create_domain_mapping(domain: SkillDomain) -> HashMap<FluencyLevel, PerceptibilityModifiers> {
        let mut mapping = HashMap::new();

        // Get domain-specific prefixes for animation and sound
        let (anim_prefix, sound_prefix) = match domain {
            SkillDomain::Woodcraft => ("woodcraft", "wood"),
            SkillDomain::Stonework => ("stonework", "stone"),
            SkillDomain::Husbandry => ("husbandry", "farm"),
            SkillDomain::Pathfinding => ("pathfinding", "nav"),
            SkillDomain::Foraging => ("foraging", "gather"),
            SkillDomain::WeatherSense => ("weather_sense", "weather"),
            SkillDomain::SocialWeaving => ("social_weaving", "social"),
        };

        // Halting: slow, wasteful
        mapping.insert(
            FluencyLevel::Halting,
            PerceptibilityModifiers::new(
                format!("{}_halting", anim_prefix),
                2.0,
                1.3,
                format!("{}_halting", sound_prefix),
            ),
        );

        // Awkward: somewhat slow, somewhat wasteful
        mapping.insert(
            FluencyLevel::Awkward,
            PerceptibilityModifiers::new(
                format!("{}_awkward", anim_prefix),
                1.5,
                1.2,
                format!("{}_awkward", sound_prefix),
            ),
        );

        // Competent: slightly slow, slightly wasteful
        mapping.insert(
            FluencyLevel::Competent,
            PerceptibilityModifiers::new(
                format!("{}_competent", anim_prefix),
                1.2,
                1.1,
                format!("{}_competent", sound_prefix),
            ),
        );

        // Smooth: normal speed, no waste
        mapping.insert(
            FluencyLevel::Smooth,
            PerceptibilityModifiers::new(
                format!("{}_smooth", anim_prefix),
                1.0,
                1.0,
                format!("{}_smooth", sound_prefix),
            ),
        );

        // Expert: fast, efficient
        mapping.insert(
            FluencyLevel::Expert,
            PerceptibilityModifiers::new(
                format!("{}_expert", anim_prefix),
                0.6,
                1.0,
                format!("{}_expert", sound_prefix),
            ),
        );

        mapping
    }

    /// Returns the perceptibility modifiers for a (domain, fluency) combination.
    pub fn get_modifiers(&self, domain: SkillDomain, fluency: FluencyLevel) -> PerceptibilityModifiers {
        self.modifiers
            .get(&domain)
            .and_then(|domain_map| domain_map.get(&fluency).cloned())
            .unwrap_or_default()
    }

    /// Returns only the action duration multiplier for a (domain, fluency) combination.
    pub fn get_duration_multiplier(&self, domain: SkillDomain, fluency: FluencyLevel) -> f32 {
        self.get_modifiers(domain, fluency).action_duration_multiplier
    }

    /// Returns only the resource waste multiplier for a (domain, fluency) combination.
    pub fn get_waste_multiplier(&self, domain: SkillDomain, fluency: FluencyLevel) -> f32 {
        self.get_modifiers(domain, fluency).resource_waste_multiplier
    }

    /// Returns the animation state for a (domain, fluency) combination.
    pub fn get_animation_state(&self, domain: SkillDomain, fluency: FluencyLevel) -> String {
        self.get_modifiers(domain, fluency).animation_state
    }

    /// Returns the sound profile for a (domain, fluency) combination.
    pub fn get_sound_profile(&self, domain: SkillDomain, fluency: FluencyLevel) -> String {
        self.get_modifiers(domain, fluency).sound_profile
    }
}

/// Global perceptibility mapper instance for convenient access.
pub fn global_perceptibility_mapper() -> &'static PerceptibilityMapper {
    use std::sync::OnceLock;
    static MAPPER: OnceLock<PerceptibilityMapper> = OnceLock::new();
    MAPPER.get_or_init(PerceptibilityMapper::new)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_modifier_mapping() {
        let mapper = PerceptibilityMapper::new();
        
        // Test Husbandry domain
        let husbandry_halting = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Halting);
        assert_eq!(husbandry_halting.action_duration_multiplier, 2.0);
        assert_eq!(husbandry_halting.resource_waste_multiplier, 1.3);
        assert_eq!(husbandry_halting.animation_state, "husbandry_halting");
        assert_eq!(husbandry_halting.sound_profile, "farm_halting");

        let husbandry_expert = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Expert);
        assert_eq!(husbandry_expert.action_duration_multiplier, 0.6);
        assert_eq!(husbandry_expert.resource_waste_multiplier, 1.0);
        assert_eq!(husbandry_expert.animation_state, "husbandry_expert");
        assert_eq!(husbandry_expert.sound_profile, "farm_expert");

        // Test Woodcraft domain
        let woodcraft_competent = mapper.get_modifiers(SkillDomain::Woodcraft, FluencyLevel::Competent);
        assert_eq!(woodcraft_competent.action_duration_multiplier, 1.2);
        assert_eq!(woodcraft_competent.resource_waste_multiplier, 1.1);
        assert_eq!(woodcraft_competent.animation_state, "woodcraft_competent");
        assert_eq!(woodcraft_competent.sound_profile, "wood_competent");
    }

    #[test]
    fn test_get_duration_multiplier() {
        let mapper = PerceptibilityMapper::new();
        assert_eq!(
            mapper.get_duration_multiplier(SkillDomain::Husbandry, FluencyLevel::Halting),
            2.0
        );
        assert_eq!(
            mapper.get_duration_multiplier(SkillDomain::Husbandry, FluencyLevel::Expert),
            0.6
        );
    }

    #[test]
    fn test_get_waste_multiplier() {
        let mapper = PerceptibilityMapper::new();
        assert_eq!(
            mapper.get_waste_multiplier(SkillDomain::Husbandry, FluencyLevel::Halting),
            1.3
        );
        assert_eq!(
            mapper.get_waste_multiplier(SkillDomain::Husbandry, FluencyLevel::Expert),
            1.0
        );
    }

    #[test]
    fn test_global_mapper() {
        let mapper = global_perceptibility_mapper();
        let modifiers = mapper.get_modifiers(SkillDomain::Husbandry, FluencyLevel::Smooth);
        assert_eq!(modifiers.action_duration_multiplier, 1.0);
        assert_eq!(modifiers.resource_waste_multiplier, 1.0);
    }
}
