//! Skill System Module
//!
//! Implements the skill infrastructure for Forgeborn as specified in Sprint 18a.
//! Contains skill domains, affordances, profiles, and practice/decay mechanics.
//!
//! Defined in GAME_DESIGN_SECTION_4.md Section 4.8 (Design Constraints).

pub mod affordance;
pub mod catalogue;
pub mod domain;
pub mod event;
pub mod fluency;
pub mod perceptibility;
pub mod practice;
pub mod profile;

pub use affordance::{Affordance, AffordanceId, MaturityState, ToolClass, PlaceTag, DEFAULT_UNLOCK_THRESHOLD};
pub use catalogue::{AffordanceCatalogue, AffordanceCatalogueError, BASE_DECAY_RATE, BASE_PRACTICE_RATE, DECAY_GRACE_PERIOD_DAYS, TICKS_PER_DAY, affordance_catalogue, load_affordance_catalogue};
pub use domain::SkillDomain;
pub use event::{ActionOutcome, ContextModifiers, SkillEvent};
pub use fluency::{FluencyLevel, FluencyLevelExt};
pub use perceptibility::{PerceptibilityMapper, PerceptibilityModifiers, global_perceptibility_mapper};
pub use practice::{apply_decay, apply_practice, check_unlock, DELIBERATE_MODIFIER_FOCUSED, DELIBERATE_MODIFIER_NORMAL, OBSERVATION_RATE_MULTIPLIER};
pub use profile::SkillProfile;
