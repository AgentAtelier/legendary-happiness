//! Affordance Catalogue
//!
//! Contains the complete catalogue of affordances organized by SkillDomain.
//! Each affordance is a discrete perceptual or action capability.
//!
//! Defined in Sprint 18a design decisions.

use anvil_core::repo_path;
use super::{Affordance, AffordanceId, SkillDomain};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use thiserror::Error;

/// Error type for affordance catalogue operations.
#[derive(Debug, Error)]
#[non_exhaustive]
pub enum AffordanceCatalogueError {
    /// Failed to read the catalogue file.
    #[error("failed to read affordances file: {0}")]
    IoError(#[from] std::io::Error),
    /// Failed to parse the catalogue JSON.
    #[error("failed to parse affordances JSON: {0}")]
    ParseError(#[from] serde_json::Error),
}

/// Loads the affordance catalogue from a JSON file.
///
/// Returns a `Result` so callers can decide whether to fail hard or
/// fall back to an empty catalogue.
pub fn load_affordance_catalogue() -> Result<AffordanceCatalogue, AffordanceCatalogueError> {
    let path = repo_path!("assets/sim/affordances.json");
    let bytes = std::fs::read(&path)?;
    let catalogue: AffordanceCatalogue = serde_json::from_slice(&bytes)?;
    Ok(catalogue)
}

/// Cached affordance catalogue (lazy initialization).
static AFFORDANCE_CATALOGUE_CACHE: std::sync::OnceLock<AffordanceCatalogue> = std::sync::OnceLock::new();

/// Returns the global affordance catalogue, loading from JSON on first use.
pub fn affordance_catalogue() -> &'static AffordanceCatalogue {
    AFFORDANCE_CATALOGUE_CACHE.get_or_init(|| {
        load_affordance_catalogue().expect("Failed to load affordance catalogue")
    })
}

/// Affordance catalogue - a static registry of all affordances.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AffordanceCatalogue {
    /// All affordances, keyed by ID.
    affordances: BTreeMap<AffordanceId, Affordance>,
    /// Affordances grouped by domain.
    by_domain: BTreeMap<SkillDomain, Vec<AffordanceId>>,
}

impl AffordanceCatalogue {
    /// Creates a new, empty catalogue.
    pub fn new() -> Self {
        Self {
            affordances: BTreeMap::new(),
            by_domain: BTreeMap::new(),
        }
    }

    /// Returns the affordance with the given ID.
    pub fn get(&self, id: AffordanceId) -> Option<&Affordance> {
        self.affordances.get(&id)
    }

    /// Returns all affordances in a specific domain.
    pub fn get_by_domain(&self, domain: SkillDomain) -> Vec<&Affordance> {
        self.by_domain
            .get(&domain)
            .map(|ids| ids.iter().filter_map(|&id| self.affordances.get(&id)).collect())
            .unwrap_or_default()
    }

    /// Returns all affordance IDs.
    pub fn all_ids(&self) -> Vec<AffordanceId> {
        self.affordances.keys().cloned().collect()
    }

    /// Returns the number of affordances in the catalogue.
    pub fn len(&self) -> usize {
        self.affordances.len()
    }

    /// Returns true if the catalogue is empty.
    pub fn is_empty(&self) -> bool {
        self.affordances.is_empty()
    }

    /// Adds an affordance to the catalogue.
    pub fn add(&mut self, affordance: Affordance) {
        let id = affordance.id;
        let domain = affordance.domain;
        self.affordances.insert(id, affordance);
        self.by_domain
            .entry(domain)
            .or_default()
            .push(id);
    }

    /// Returns an iterator over all affordances.
    pub fn iter(&self) -> impl Iterator<Item = (&AffordanceId, &Affordance)> {
        self.affordances.iter()
    }
}

impl Default for AffordanceCatalogue {
    fn default() -> Self {
        Self::new()
    }
}

/// Constants for skill system.
/// Number of simulation ticks in one game day.
pub const TICKS_PER_DAY: u64 = 1000;
/// Base rate at which practice increases maturity (per action completion).
pub const BASE_PRACTICE_RATE: f32 = 0.02;
/// Base rate at which skills decay when not practiced.
pub const BASE_DECAY_RATE: f32 = 0.1;
/// Number of days before skill decay begins after last practice.
pub const DECAY_GRACE_PERIOD_DAYS: f32 = 1.0;

/// Returns the global affordance catalogue (lazy initialization).
/// Returns the global affordance catalogue, loading from JSON on first use.
/// Deprecated: use `affordance_catalogue()` instead.
#[deprecated(note = "use affordance_catalogue() instead")]
pub fn global_catalogue() -> &'static AffordanceCatalogue {
    affordance_catalogue()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_catalogue_size() {
        let catalogue = affordance_catalogue();
        // 9 Woodcraft + 6 Stonework + 10 Husbandry + 5 Pathfinding + 8 Foraging + 5 WeatherSense + 7 SocialWeaving = 50
        assert_eq!(catalogue.len(), 50);
    }

    #[test]
    fn test_catalogue_get() {
        let catalogue = affordance_catalogue();
        let affordance = catalogue.get(AffordanceId::new(1));
        assert!(affordance.is_some());
        assert_eq!(affordance.unwrap().name, "grain_reading");
    }

    #[test]
    fn test_catalogue_get_by_domain() {
        let catalogue = affordance_catalogue();
        let woodcraft = catalogue.get_by_domain(SkillDomain::Woodcraft);
        assert_eq!(woodcraft.len(), 9);
    }

    #[test]
    fn test_affordance_catalogue() {
        let catalogue = affordance_catalogue();
        assert_eq!(catalogue.len(), 50);
    }

    // ============================================================
    // Playbook 5 - CI tests for JSON loading
    // ============================================================
    #[test]
    fn affordances_json_loads() {
        let catalogue = load_affordance_catalogue()
            .expect("affordances.json must be loadable");
        assert!(!catalogue.is_empty());
    }

    
}
