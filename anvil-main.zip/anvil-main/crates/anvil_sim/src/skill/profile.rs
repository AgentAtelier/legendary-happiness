//! Skill Profile
//!
//! Defines the SkillProfile struct that tracks skill maturity and unlocked
//! affordances for a Person.
//!
//! Defined in Sprint 18a design decisions.

use super::{AffordanceId, MaturityState};
use anvil_core::ValidationErrors;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;

use anvil_core::error_buffer;

/// A skill profile tracking maturity and unlocked affordances for a Person.
///
/// Contains per-affordance maturity tracking and a cached set of
/// currently unlocked affordances.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SkillProfile {
    /// Per-affordance maturity states, keyed by AffordanceId.
    pub maturities: BTreeMap<AffordanceId, MaturityState>,
    /// Cached set of unlocked affordance IDs for fast lookup.
    pub unlocked: BTreeSet<AffordanceId>,
}

impl SkillProfile {
    /// Creates a new, empty skill profile.
    pub fn new() -> Self {
        Self {
            maturities: BTreeMap::new(),
            unlocked: BTreeSet::new(),
        }
    }

    /// Creates a skill profile with all known affordances initialized to zero maturity.
    pub fn with_all_affordances(affordance_ids: Vec<AffordanceId>) -> Self {
        let maturities: BTreeMap<AffordanceId, MaturityState> = affordance_ids
            .into_iter()
            .map(|id| (id, MaturityState::new()))
            .collect();
        Self {
            maturities,
            unlocked: BTreeSet::new(),
        }
    }

    /// Returns the maturity state for an affordance, or None if not tracked.
    pub fn get_maturity(&self, affordance_id: AffordanceId) -> Option<MaturityState> {
        self.maturities.get(&affordance_id).copied()
    }

    /// Returns the maturity value for an affordance, or 0.0 if not tracked.
    pub fn get_maturity_value(&self, affordance_id: AffordanceId) -> f32 {
        self.maturities
            .get(&affordance_id)
            .map(|s| s.maturity)
            .unwrap_or(0.0)
    }

    /// Returns whether an affordance is unlocked.
    pub fn is_unlocked(&self, affordance_id: AffordanceId) -> bool {
        self.unlocked.contains(&affordance_id)
    }

    /// Returns all unlocked affordance IDs.
    pub fn unlocked_affordances(&self) -> Vec<AffordanceId> {
        self.unlocked.iter().cloned().collect()
    }

    /// Sets the maturity for an affordance.
    pub fn set_maturity(&mut self, affordance_id: AffordanceId, state: MaturityState) {
        self.maturities.insert(affordance_id, state);
    }

    /// Adds an affordance to the unlocked set.
    pub fn unlock(&mut self, affordance_id: AffordanceId) {
        self.unlocked.insert(affordance_id);
    }

    /// Adds an affordance to the profile with zero maturity.
    pub fn add_affordance(&mut self, affordance_id: AffordanceId) {
        self.maturities.entry(affordance_id).or_default();
    }

    /// Returns the number of tracked affordances.
    pub fn len(&self) -> usize {
        self.maturities.len()
    }

    /// Returns true if no affordances are tracked.
    pub fn is_empty(&self) -> bool {
        self.maturities.is_empty()
    }

    /// Validates this skill profile.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        for (affordance_id, state) in &self.maturities {
            errors.extend(state.validate());
            // Check that if unlocked, the maturity is valid
            if self.unlocked.contains(affordance_id) {
                // Unlocked affordances must have maturity >= some threshold
                // (but we don't enforce a specific threshold here, just that it's valid)
            }
        }

        errors
    }
}

impl Default for SkillProfile {
    fn default() -> Self {
        Self::new()
    }
}

impl fmt::Display for SkillProfile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "SkillProfile {{ tracked: {}, unlocked: {} }}",
            self.maturities.len(),
            self.unlocked.len()
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_skill_profile_new() {
        let profile = SkillProfile::new();
        assert!(profile.is_empty());
        assert!(profile.unlocked.is_empty());
    }

    #[test]
    fn test_skill_profile_with_all_affordances() {
        let affordance_ids = vec![
            AffordanceId::new(1),
            AffordanceId::new(2),
            AffordanceId::new(3),
        ];
        let profile = SkillProfile::with_all_affordances(affordance_ids);
        assert_eq!(profile.len(), 3);
        assert_eq!(profile.get_maturity_value(AffordanceId::new(1)), 0.0);
    }

    #[test]
    fn test_skill_profile_get_set_maturity() {
        let mut profile = SkillProfile::new();
        profile.add_affordance(AffordanceId::new(1));

        let state = MaturityState::with_maturity(0.5);
        profile.set_maturity(AffordanceId::new(1), state);

        let retrieved = profile.get_maturity(AffordanceId::new(1));
        assert!(retrieved.is_some());
        assert_eq!(retrieved.unwrap().maturity, 0.5);
    }

    #[test]
    fn test_skill_profile_unlock() {
        let mut profile = SkillProfile::new();
        assert!(!profile.is_unlocked(AffordanceId::new(1)));

        profile.unlock(AffordanceId::new(1));
        assert!(profile.is_unlocked(AffordanceId::new(1)));
    }

    #[test]
    fn test_skill_profile_unlocked_affordances() {
        let mut profile = SkillProfile::new();
        profile.unlock(AffordanceId::new(1));
        profile.unlock(AffordanceId::new(2));

        let unlocked = profile.unlocked_affordances();
        assert_eq!(unlocked.len(), 2);
    }

    #[test]
    fn test_skill_profile_validation() {
        let profile = SkillProfile::new();
        assert!(profile.validate().is_empty());

        let mut profile = SkillProfile::new();
        profile.add_affordance(AffordanceId::new(1));
        profile.set_maturity(
            AffordanceId::new(1),
            MaturityState {
                maturity: 0.5,
                peak_maturity: 0.5,
                last_practice_tick: 0,
                last_failure_tick: 0,
            },
        );
        assert!(profile.validate().is_empty());
    }

    #[test]
    fn test_skill_profile_display() {
        let profile = SkillProfile::new();
        let display = format!("{}", profile);
        assert!(display.contains("SkillProfile"));
        assert!(display.contains("tracked: 0"));
        assert!(display.contains("unlocked: 0"));
    }
}
