//! Fluency Levels
//!
//! Defines fluency levels derived from the number of unlocked affordances
//! in a skill domain. Fluency represents the overall proficiency in a domain.
//!
//! Defined in Sprint 18b design decisions.

use super::{AffordanceCatalogue, SkillDomain, SkillProfile};
use serde::{Deserialize, Serialize};
use std::fmt;

/// Fluency level - represents overall proficiency in a skill domain.
///
/// Derived from the number of unlocked affordances in that domain:
/// - Halting: 0 unlocked affordances
/// - Awkward: 1 unlocked affordance
/// - Competent: 2-3 unlocked affordances
/// - Smooth: 4-5 unlocked affordances
/// - Expert: 6+ unlocked affordances
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FluencyLevel {
    /// No affordances unlocked - cannot perform domain actions effectively.
    Halting,
    /// One affordance unlocked - basic, clumsy performance.
    Awkward,
    /// Two to three affordances unlocked - reliable, steady performance.
    Competent,
    /// Four to five affordances unlocked - fluid, efficient performance.
    Smooth,
    /// Six or more affordances unlocked - masterful, optimal performance.
    Expert,
}

impl fmt::Display for FluencyLevel {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            FluencyLevel::Halting => write!(f, "halting"),
            FluencyLevel::Awkward => write!(f, "awkward"),
            FluencyLevel::Competent => write!(f, "competent"),
            FluencyLevel::Smooth => write!(f, "smooth"),
            FluencyLevel::Expert => write!(f, "expert"),
        }
    }
}

impl FluencyLevel {
    /// Returns the fluency level for a given count of unlocked affordances.
    pub fn from_unlocked_count(count: usize) -> Self {
        match count {
            0 => FluencyLevel::Halting,
            1 => FluencyLevel::Awkward,
            2..=3 => FluencyLevel::Competent,
            4..=5 => FluencyLevel::Smooth,
            _ => FluencyLevel::Expert,
        }
    }

    /// Returns the numeric value for ordering (lower = worse, higher = better).
    pub fn as_score(&self) -> u8 {
        match self {
            FluencyLevel::Halting => 0,
            FluencyLevel::Awkward => 1,
            FluencyLevel::Competent => 2,
            FluencyLevel::Smooth => 3,
            FluencyLevel::Expert => 4,
        }
    }
}

/// Extension trait for SkillProfile to provide fluency level derivation.
pub trait FluencyLevelExt {
    /// Returns the fluency level for a given domain based on unlocked affordances.
    ///
    /// Counts how many affordances in the specified domain are unlocked and maps
    /// to a FluencyLevel according to the threshold mapping.
    fn fluency_level(&self, domain: SkillDomain, catalogue: &AffordanceCatalogue) -> FluencyLevel;
}

impl FluencyLevelExt for SkillProfile {
    fn fluency_level(&self, domain: SkillDomain, catalogue: &AffordanceCatalogue) -> FluencyLevel {
        // Get all affordances in the domain
        let domain_affordances = catalogue.get_by_domain(domain);
        
        // Count how many are unlocked
        let unlocked_count = domain_affordances
            .iter()
            .filter(|affordance| self.is_unlocked(affordance.id))
            .count();
        
        FluencyLevel::from_unlocked_count(unlocked_count)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::skill::affordance::AffordanceId;

    #[test]
    fn test_fluency_level_from_unlocked_count() {
        assert_eq!(FluencyLevel::from_unlocked_count(0), FluencyLevel::Halting);
        assert_eq!(FluencyLevel::from_unlocked_count(1), FluencyLevel::Awkward);
        assert_eq!(FluencyLevel::from_unlocked_count(2), FluencyLevel::Competent);
        assert_eq!(FluencyLevel::from_unlocked_count(3), FluencyLevel::Competent);
        assert_eq!(FluencyLevel::from_unlocked_count(4), FluencyLevel::Smooth);
        assert_eq!(FluencyLevel::from_unlocked_count(5), FluencyLevel::Smooth);
        assert_eq!(FluencyLevel::from_unlocked_count(6), FluencyLevel::Expert);
        assert_eq!(FluencyLevel::from_unlocked_count(10), FluencyLevel::Expert);
    }

    #[test]
    fn test_fluency_level_as_score() {
        assert_eq!(FluencyLevel::Halting.as_score(), 0);
        assert_eq!(FluencyLevel::Awkward.as_score(), 1);
        assert_eq!(FluencyLevel::Competent.as_score(), 2);
        assert_eq!(FluencyLevel::Smooth.as_score(), 3);
        assert_eq!(FluencyLevel::Expert.as_score(), 4);
    }

    #[test]
    fn test_fluency_level_display() {
        assert_eq!(format!("{}", FluencyLevel::Halting), "halting");
        assert_eq!(format!("{}", FluencyLevel::Awkward), "awkward");
        assert_eq!(format!("{}", FluencyLevel::Competent), "competent");
        assert_eq!(format!("{}", FluencyLevel::Smooth), "smooth");
        assert_eq!(format!("{}", FluencyLevel::Expert), "expert");
    }

    #[test]
    fn test_skill_profile_fluency_level() {
        let catalogue = crate::skill::catalogue::affordance_catalogue();
        let mut profile = SkillProfile::new();
        
        // Initialize with all affordances
        for id in catalogue.all_ids() {
            profile.add_affordance(id);
        }
        
        // With 0 unlocked, should be Halting for Husbandry (which has 8 affordances)
        assert_eq!(
            profile.fluency_level(SkillDomain::Husbandry, &catalogue),
            FluencyLevel::Halting
        );
        
        // Unlock 1 Husbandry affordance
        profile.unlock(AffordanceId::new(20)); // soil_moisture_reading
        assert_eq!(
            profile.fluency_level(SkillDomain::Husbandry, &catalogue),
            FluencyLevel::Awkward
        );
        
        // Unlock 2 more
        profile.unlock(AffordanceId::new(21)); // frost_sign_spotting
        profile.unlock(AffordanceId::new(22)); // pest_damage_id
        assert_eq!(
            profile.fluency_level(SkillDomain::Husbandry, &catalogue),
            FluencyLevel::Competent
        );
        
        // Unlock 4-5
        profile.unlock(AffordanceId::new(23)); // crop_ripeness_eye
        profile.unlock(AffordanceId::new(24)); // weed_id
        assert_eq!(
            profile.fluency_level(SkillDomain::Husbandry, &catalogue),
            FluencyLevel::Smooth
        );
        
        // Unlock 6+ (8 total in Husbandry)
        profile.unlock(AffordanceId::new(25)); // nutrient_deficiency_sight
        profile.unlock(AffordanceId::new(26)); // seed_viability_touch
        profile.unlock(AffordanceId::new(27)); // harvest_timing_sense
        assert_eq!(
            profile.fluency_level(SkillDomain::Husbandry, &catalogue),
            FluencyLevel::Expert
        );
    }
}
