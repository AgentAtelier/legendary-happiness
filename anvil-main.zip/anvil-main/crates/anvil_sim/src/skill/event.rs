//! Skill Events
//!
//! Defines events related to skill practice, observation, and progression.
//!
//! Defined in Sprint 18a design decisions.

use crate::settlement::ids::PersonId;
use serde::{Deserialize, Serialize};
use std::fmt;

use super::{AffordanceId, FluencyLevel};

/// Outcome of an action for skill practice purposes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum ActionOutcome {
    /// Action completed successfully.
    Success,
    /// Action completed with partial success.
    Partial,
    /// Action failed.
    Failure,
}

impl fmt::Display for ActionOutcome {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ActionOutcome::Success => write!(f, "success"),
            ActionOutcome::Partial => write!(f, "partial"),
            ActionOutcome::Failure => write!(f, "failure"),
        }
    }
}

/// Context modifiers for skill events.
///
/// These are stubbed for Sprint 18a and will be populated in Sprint 18c
/// with emotional state, age, time of day, etc.
/// Sprint 18b adds fluency_level for perceptibility modifiers.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ContextModifiers {
    /// Time of day [0.0, 1.0] for time-based learning modifiers (Sprint 18c).
    pub time_of_day: Option<f32>,
    /// Emotional state as mood [-1.0, 1.0] for backward compatibility (Sprint 18c).
    pub emotional_state: Option<f32>,
    /// Age learning rate multiplier from Age.learning_rate_multiplier() (Sprint 18c).
    pub age_learning_multiplier: Option<f32>,
    /// Practice quality multiplier from EmotionalAxes.practice_quality_multiplier() (Sprint 18c).
    pub practice_quality_multiplier: Option<f32>,
    /// Observation rate multiplier from EmotionalAxes.observation_rate_multiplier() (Sprint 18c).
    pub observation_rate_multiplier: Option<f32>,
    /// Fluency level for the action's domain (Sprint 18b).
    pub fluency_level: Option<FluencyLevel>,
}

impl ContextModifiers {
    /// Creates a new ContextModifiers with default (no modifier) values.
    pub fn new() -> Self {
        Self::default()
    }

    /// Returns the combined practice multiplier from age, emotion, and time.
    ///
    /// This multiplies together:
    /// - age_learning_multiplier (from Age::learning_rate_multiplier)
    /// - practice_quality_multiplier (from EmotionalAxes::practice_quality_multiplier)
    /// - time modifier (from time::time_learning_modifier, requires domain)
    ///
    /// Note: time modifier requires the skill domain, so it's computed separately.
    pub fn practice_multiplier(&self) -> f32 {
        let age = self.age_learning_multiplier.unwrap_or(1.0);
        let emotion = self.practice_quality_multiplier.unwrap_or(1.0);
        age * emotion
    }

    /// Returns the combined observation multiplier from age, emotion, and time.
    pub fn observation_multiplier(&self) -> f32 {
        let age = self.age_learning_multiplier.unwrap_or(1.0);
        let emotion = self.observation_rate_multiplier.unwrap_or(1.0);
        age * emotion
    }
}

/// Skill events emitted during simulation.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum SkillEvent {
    /// An action was completed, potentially improving skill maturity.
    ActionCompleted {
        /// The person who performed the action.
        person_id: PersonId,
        /// The affordance being exercised.
        affordance_id: AffordanceId,
        /// Whether the action succeeded, was partial, or failed.
        outcome: ActionOutcome,
        /// Context modifiers for future emotional/age/time integration.
        context_modifiers: ContextModifiers,
    },
    /// An NPC observed another NPC performing an action and learned from it.
    ObservationGained {
        /// The observer who learned.
        observer_id: PersonId,
        /// The demonstrator being observed.
        demonstrator_id: PersonId,
        /// The affordance being observed.
        affordance_id: AffordanceId,
        /// Context modifiers for observation learning (Sprint 18c).
        context_modifiers: ContextModifiers,
    },
    /// An affordance was unlocked for an NPC.
    AffordanceUnlocked {
        /// The person who unlocked the affordance.
        person_id: PersonId,
        /// The affordance that was unlocked.
        affordance_id: AffordanceId,
    },
    /// Decay tick event for skill maturity decay.
    DecayTick {
        /// The person whose skills are decaying.
        person_id: PersonId,
    },
}

impl SkillEvent {
    /// Returns the person ID associated with this event.
    pub fn person_id(&self) -> PersonId {
        match self {
            SkillEvent::ActionCompleted { person_id, .. } => *person_id,
            SkillEvent::ObservationGained { observer_id, .. } => *observer_id,
            SkillEvent::AffordanceUnlocked { person_id, .. } => *person_id,
            SkillEvent::DecayTick { person_id } => *person_id,
        }
    }

    /// Returns the affordance ID associated with this event, if any.
    pub fn affordance_id(&self) -> Option<AffordanceId> {
        match self {
            SkillEvent::ActionCompleted { affordance_id, .. } => Some(*affordance_id),
            SkillEvent::ObservationGained { affordance_id, .. } => Some(*affordance_id),
            SkillEvent::AffordanceUnlocked { affordance_id, .. } => Some(*affordance_id),
            SkillEvent::DecayTick { .. } => None,
        }
    }

    /// Returns whether this event is a practice event.
    pub fn is_practice(&self) -> bool {
        matches!(self, SkillEvent::ActionCompleted { .. })
    }

    /// Returns whether this event is an observation event.
    pub fn is_observation(&self) -> bool {
        matches!(self, SkillEvent::ObservationGained { .. })
    }

    /// Returns whether this event is an unlock event.
    pub fn is_unlock(&self) -> bool {
        matches!(self, SkillEvent::AffordanceUnlocked { .. })
    }

    /// Returns whether this event is a decay event.
    pub fn is_decay(&self) -> bool {
        matches!(self, SkillEvent::DecayTick { .. })
    }
}

impl fmt::Display for SkillEvent {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SkillEvent::ActionCompleted {
                person_id,
                affordance_id,
                outcome,
                ..
            } => write!(
                f,
                "ActionCompleted {{ person: {}, affordance: {}, outcome: {} }}",
                person_id, affordance_id, outcome
            ),
            SkillEvent::ObservationGained {
                observer_id,
                demonstrator_id,
                affordance_id,
                context_modifiers: _,
            } => write!(
                f,
                "ObservationGained {{ observer: {}, demonstrator: {}, affordance: {} }}",
                observer_id, demonstrator_id, affordance_id
            ),
            SkillEvent::AffordanceUnlocked {
                person_id,
                affordance_id,
            } => write!(
                f,
                "AffordanceUnlocked {{ person: {}, affordance: {} }}",
                person_id, affordance_id
            ),
            SkillEvent::DecayTick { person_id } => {
                write!(f, "DecayTick {{ person: {} }}", person_id)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::settlement::ids::PersonId;

    #[test]
    fn test_action_outcome_display() {
        assert_eq!(format!("{}", ActionOutcome::Success), "success");
        assert_eq!(format!("{}", ActionOutcome::Partial), "partial");
        assert_eq!(format!("{}", ActionOutcome::Failure), "failure");
    }

    #[test]
    fn test_skill_event_person_id() {
        let person_id = PersonId::new(1);
        let event = SkillEvent::ActionCompleted {
            person_id,
            affordance_id: AffordanceId::new(1),
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };
        assert_eq!(event.person_id(), person_id);
    }

    #[test]
    fn test_skill_event_affordance_id() {
        let affordance_id = AffordanceId::new(1);
        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id,
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };
        assert_eq!(event.affordance_id(), Some(affordance_id));

        let decay_event = SkillEvent::DecayTick {
            person_id: PersonId::new(1),
        };
        assert_eq!(decay_event.affordance_id(), None);
    }

    #[test]
    fn test_skill_event_is_methods() {
        let action_event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id: AffordanceId::new(1),
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };
        assert!(action_event.is_practice());
        assert!(!action_event.is_observation());
        assert!(!action_event.is_unlock());
        assert!(!action_event.is_decay());

        let observation_event = SkillEvent::ObservationGained {
            observer_id: PersonId::new(1),
            demonstrator_id: PersonId::new(2),
            affordance_id: AffordanceId::new(1),
            context_modifiers: ContextModifiers::new(),
        };
        assert!(!observation_event.is_practice());
        assert!(observation_event.is_observation());
        assert!(!observation_event.is_unlock());
        assert!(!observation_event.is_decay());
    }

    #[test]
    fn test_skill_event_display() {
        let event = SkillEvent::ActionCompleted {
            person_id: PersonId::new(1),
            affordance_id: AffordanceId::new(1),
            outcome: ActionOutcome::Success,
            context_modifiers: ContextModifiers::new(),
        };
        let display = format!("{}", event);
        assert!(display.contains("ActionCompleted"));
        assert!(display.contains("person: person#1"));
    }
}
