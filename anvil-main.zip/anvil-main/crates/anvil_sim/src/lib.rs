//! # anvil_sim
//!
//! Pure-Rust deterministic simulation. Owns time, faction state, AI,
//! weather, damage, vegetation evolution. Engine-free.
//!
//! ## Why this is the heart of the project
//!
//! Every interesting gameplay behaviour lives here. Bevy reads
//! `anvil_sim` state and emits visual entities; `anvil_sim` never reads
//! Bevy. This is the same boundary that distinguishes Forge's
//! catastrophic 18,991-line `forge_bevy/lib.rs` (which contained sim
//! logic) from Anvil's clean separation.

#![deny(warnings)]
#![deny(missing_docs)]
#![cfg_attr(
    not(test),
    deny(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::unreachable,
        clippy::todo,
    )
)]

use anvil_core::ValidationErrors;
use anvil_world::{WorldAuthored, WeatherState};
use serde::{Serialize, Deserialize};
use std::fmt;

pub mod actions;
pub mod age;
pub mod catastrophe;
pub mod needs;
pub mod settlement;
pub mod skill;
pub mod soul;
pub mod system;
pub mod targeting;
pub mod time;
pub mod utility;

/// Runtime world state for simulation.
/// 
/// This is a placeholder type that will be fully implemented in a later sprint.
/// For now, it wraps `WorldAuthored` as a stand-in.
#[derive(Default)]
pub struct WorldRuntime {
    /// The compiled world data.
    pub world: WorldAuthored,
    /// Weather state for catastrophe triggering and system access.
    pub weather: WeatherState,
}

impl WorldRuntime {
    /// Creates a new runtime world from an authored world.
    pub fn new(world: WorldAuthored) -> Self {
        Self {
            world,
            weather: WeatherState::default(),
        }
    }
}

/// World environment data for simulation systems.
/// Contains terrain and vegetation information that can be queried by systems.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct WorldEnv {
    /// Terrain heights indexed by region ID.
    pub terrain_heights: std::collections::HashMap<anvil_core::RegionId, f32>,
    /// Vegetation densities indexed by region ID.
    pub vegetation_densities: std::collections::HashMap<anvil_core::RegionId, f32>,
}

/// Deterministic random number generator for simulation.
/// 
/// Uses a simple deterministic hash function (xorshift64*) to produce
/// reproducible pseudo-random values from a seed.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DeterministicRng {
    /// Internal state of the RNG.
    state: u64,
}

impl Default for DeterministicRng {
    fn default() -> Self {
        // xorshift64* requires a non-zero seed. Use a fixed non-zero constant.
        // 0 is an absorbing state for xorshift64* (0 ^ (0>>12) = 0, etc.)
        Self::new(0x4d32_19af_dead_beef)
    }
}

impl DeterministicRng {
    /// Creates a new deterministic RNG with the given seed.
    pub fn new(seed: u64) -> Self {
        Self { state: seed }
    }

    /// Generates a deterministic u64 value and advances the state.
    /// This uses a simple xorshift64* algorithm for deterministic pseudo-randomness.
    pub fn next_u64(&mut self) -> u64 {
        let mut x = self.state;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.state = x;
        x.wrapping_mul(2685821657736338717u64)
    }

    /// Generates a deterministic f32 in range [0.0, 1.0).
    pub fn next_f32(&mut self) -> f32 {
        let bits = self.next_u64();
        // Use the upper 24 bits for the mantissa (gives good distribution in [0, 1))
        (bits >> 40) as f32 / 16_777_216.0
    }

    /// Generates a deterministic f32 in a custom range.
    pub fn next_f32_range(&mut self, min: f32, max: f32) -> f32 {
        min + (max - min) * self.next_f32()
    }

    /// Resets the RNG state to the given seed.
    pub fn reset(&mut self, seed: u64) {
        self.state = seed;
    }
}

/// A simulation event that can be passed between systems.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum SimEvent {
    /// A tick event signaling the simulation to advance.
    Tick {
        /// The delta time in microseconds for this tick.
        dt_micros: u64,
    },
    /// An action has been completed by an NPC.
    ActionCompleted {
        /// The ID of the person who completed the action.
        person_id: u64,
        /// The ID of the action that was completed.
        action_id: u64,
        /// The outcome of the action (Success, Partial, or Failure).
        outcome: crate::skill::event::ActionOutcome,
    },
}

impl SimEvent {
    /// Returns a description of the event type.
    pub fn kind(&self) -> &'static str {
        match self {
            Self::Tick { .. } => "tick",
            Self::ActionCompleted { .. } => "action_completed",
        }
    }
}

/// Context provided to simulation systems during ticking.
pub struct SimContext<'a> {
    /// The current simulation tick number.
    pub tick: u64,
    /// The delta time in microseconds for this tick.
    pub dt_micros: u64,
    /// The deterministic random number generator.
    pub rng: &'a mut DeterministicRng,
    /// The mutable world runtime state.
    pub world: &'a mut WorldRuntime,
    /// World environment data (terrain heights, vegetation densities).
    pub env: &'a WorldEnv,
    /// Events coming into this system from the previous tick.
    pub events_in: &'a [SimEvent],
    /// Events to be emitted by this system for the next tick.
    pub events_out: &'a mut Vec<SimEvent>,
}

impl<'a> SimContext<'a> {
    /// Creates a new simulation context.
    pub fn new(
        tick: u64,
        dt_micros: u64,
        rng: &'a mut DeterministicRng,
        world: &'a mut WorldRuntime,
        env: &'a WorldEnv,
        events_in: &'a [SimEvent],
        events_out: &'a mut Vec<SimEvent>,
    ) -> Self {
        Self {
            tick,
            dt_micros,
            rng,
            world,
            env,
            events_in,
            events_out,
        }
    }
}

/// A simulation system that can be ticked as part of the simulation loop.
///
/// All simulation systems must implement this trait to be integrated into
/// the simulation scheduler. Systems are ticked in priority order.
pub trait SimSystem: Send + Sync {
    /// Returns the unique name of this system.
    fn name(&self) -> &'static str;

    /// Returns the priority of this system. Higher priority systems
    /// are ticked before lower priority systems.
    fn priority(&self) -> u32;

    /// Advances the system state by one tick.
    ///
    /// # Arguments
    /// * `ctx` - The simulation context containing world state, RNG, and events.
    ///
    /// # Returns
    /// * `Ok(())` if the tick completed successfully.
    /// * `Err(SimError)` if an unrecoverable error occurred.
    fn tick(&mut self, ctx: &mut SimContext) -> Result<(), SimError>;

    /// Validates the system's internal state.
    ///
    /// Returns a vector of validation errors. An empty vector indicates
    /// the system is in a valid state.
    fn validate(&self) -> ValidationErrors;

    /// Serialize this system's state to a byte buffer.
    ///
    /// Returns `None` if the system has no persistent state to save.
    /// Override this in systems that maintain state across ticks
    /// (`NpcSystem`, `CatastropheSystem`, `JoySystem`, `PhysicsSystem`).
    fn snapshot(&self) -> Option<Vec<u8>> {
        None
    }

    /// Restore this system's state from a byte buffer produced by `snapshot()`.
    ///
    /// The default implementation succeeds without doing anything (matching the
    /// default `snapshot()` which returns `None`). Override in systems that
    /// override `snapshot()`. Returns `SimError::InvalidSnapshot` if the bytes
    /// cannot be parsed or if the restored state is inconsistent.
    fn restore(&mut self, _bytes: &[u8]) -> Result<(), SimError> {
        Ok(())
    }

    /// Returns a reference to this system as a trait object for downcasting.
    fn as_any(&self) -> &dyn std::any::Any;

    /// Returns a mutable reference to this system as a trait object for downcasting.
    fn as_any_mut(&mut self) -> &mut dyn std::any::Any;
}

/// A trait for types that can be serialized to and deserialized from
/// a snapshot byte representation.
pub trait SimSnapshot: Sized {
    /// Writes the snapshot to the provided byte buffer.
    fn write(&self, out: &mut Vec<u8>);

    /// Reads a snapshot from the provided byte slice.
    ///
    /// # Arguments
    /// * `bytes` - The byte slice containing the snapshot data.
    ///
    /// # Returns
    /// * `Ok(Self)` if the snapshot was read successfully.
    /// * `Err(SimError)` if the snapshot data was invalid.
    fn read(bytes: &[u8]) -> Result<Self, SimError>;
}

/// The error type for simulation operations.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum SimError {
    /// An invalid snapshot was encountered during deserialization.
    InvalidSnapshot(
        /// The error message describing why the snapshot is invalid.
        String,
    ),
    /// A system-specific error occurred.
    SystemError {
        /// The name of the simulation system that encountered the error.
        system: &'static str,
        /// A human-readable description of the error.
        message: String,
    },
}

impl fmt::Display for SimError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidSnapshot(msg) => write!(f, "Invalid snapshot: {}", msg),
            Self::SystemError { system, message } => {
                write!(f, "System error in {}: {}", system, message)
            }
        }
    }
}

impl std::error::Error for SimError {}

// Re-export the simulation systems from the system module
pub use system::{CatastropheSystem, JoySystem, NpcSystem, PhysicsSystem};
pub use system::physics_save::{ColliderSaveState, EntityHandle, PhysicsSaveState, RegionColliderMap, RigidBodySaveState};

#[cfg(test)]
mod tests {
    use super::*;

    /// A minimal test system for validation.
    struct TestSystem;

    impl SimSystem for TestSystem {
        fn name(&self) -> &'static str {
            "test_system"
        }

        fn priority(&self) -> u32 {
            0
        }

        fn tick(&mut self, _ctx: &mut SimContext) -> Result<(), SimError> {
            Ok(())
        }

        fn validate(&self) -> ValidationErrors {
            Vec::new()
        }

        fn as_any(&self) -> &dyn std::any::Any {
            self
        }

        fn as_any_mut(&mut self) -> &mut dyn std::any::Any {
            self
        }
    }

    #[test]
    fn test_system_trait_object_safety() {
        // Verify that SimSystem can be used as a trait object.
        let system: &dyn SimSystem = &TestSystem;
        assert_eq!(system.name(), "test_system");
        assert_eq!(system.priority(), 0);
        assert!(system.validate().is_empty());
    }

    #[test]
    fn test_sim_context_creation() {
        let mut world = WorldRuntime::default();
        let mut rng = DeterministicRng::new(42);
        let events_in: Vec<SimEvent> = Vec::new();
        let mut events_out: Vec<SimEvent> = Vec::new();
        let world_env = WorldEnv::default();

        let ctx = SimContext::new(0, 1000, &mut rng, &mut world, &world_env, &events_in, &mut events_out);
        assert_eq!(ctx.tick, 0);
        assert_eq!(ctx.dt_micros, 1000);
    }

    #[test]
    fn test_sim_error_display() {
        let err = SimError::InvalidSnapshot("corrupt data".to_string());
        assert_eq!(format!("{}", err), "Invalid snapshot: corrupt data");

        let err = SimError::SystemError {
            system: "test",
            message: "failed".to_string(),
        };
        assert_eq!(format!("{}", err), "System error in test: failed");
    }

    #[test]
    fn test_deterministic_rng_reproducibility() {
        let mut rng1 = DeterministicRng::new(12345);
        let mut rng2 = DeterministicRng::new(12345);

        assert_eq!(rng1.next_u64(), rng2.next_u64());
        assert_eq!(rng1.next_f32(), rng2.next_f32());

        let val1 = rng1.next_f32_range(10.0, 20.0);
        let val2 = rng2.next_f32_range(10.0, 20.0);
        assert!((val1 - val2).abs() < 0.001);
    }

    #[test]
    fn test_deterministic_rng_different_seeds() {
        let mut rng1 = DeterministicRng::new(12345);
        let mut rng2 = DeterministicRng::new(54321);

        assert_ne!(rng1.next_u64(), rng2.next_u64());
    }

    #[test]
    fn test_world_runtime_defaults() {
        // The new() method sets specific default values
        let world_with_values = WorldRuntime::new(WorldAuthored::default());
        assert_eq!(world_with_values.weather.temperature, 14.0);
        assert_eq!(world_with_values.weather.humidity, 0.45);
        assert_eq!(world_with_values.weather.pressure, 1013.0);
    }
}
