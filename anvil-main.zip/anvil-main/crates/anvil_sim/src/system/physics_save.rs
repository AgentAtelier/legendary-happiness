//! Physics save state types for serialization.
//!
//! This module provides the serialization types for saving and restoring
//! physics state across save/load cycles.

use rapier3d::dynamics::{BodyStatus, RigidBodyHandle};
use rapier3d::geometry::ColliderHandle;
use rapier3d::math::Vector;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Fixed physics time step in seconds for deterministic simulation.
pub const FIXED_PHYSICS_STEP: f32 = 1.0 / 60.0;

/// Handle to the player's physics entity.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct EntityHandle {
    /// The rigid body handle for the player.
    pub rigid_body_handle: RigidBodyHandle,
    /// The collider handle for the player.
    pub collider_handle: ColliderHandle,
}

impl EntityHandle {
    /// Creates a new entity handle from its component handles.
    pub fn new(rigid_body_handle: RigidBodyHandle, collider_handle: ColliderHandle) -> Self {
        Self {
            rigid_body_handle,
            collider_handle,
        }
    }
}

/// Mapping from region ID to terrain collider handles.
pub type RegionColliderMap = HashMap<u64, Vec<ColliderHandle>>;

/// Serialized state for a single rigid body.
///
/// This captures all the essential state needed to restore a rigid body
/// to its exact state at save time.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RigidBodySaveState {
    /// The handle for this rigid body.
    pub handle: RigidBodyHandle,
    /// The body status (Static, Kinematic, or Dynamic).
    pub body_status: BodyStatus,
    /// The position of the body's center of mass (x, y, z).
    pub position: [f32; 3],
    /// The linear velocity of the body (x, y, z).
    pub linvel: [f32; 3],
    /// The angular velocity of the body (x, y, z).
    pub angvel: [f32; 3],
    /// Whether the body is sleeping (not actively simulating).
    pub sleeping: bool,
}

impl RigidBodySaveState {
    /// Creates a new body save state from a rigid body.
    pub fn from_rigid_body(handle: RigidBodyHandle, body: &rapier3d::dynamics::RigidBody) -> Self {
        let pos = body.position();
        let linvel = body.linvel();
        let angvel = body.angvel();
        Self {
            handle,
            body_status: body.body_status(),
            position: [pos.translation.x, pos.translation.y, pos.translation.z],
            linvel: [linvel.x, linvel.y, linvel.z],
            angvel: [angvel.x, angvel.y, angvel.z],
            sleeping: body.is_sleeping(),
        }
    }

    /// Applies this saved state to a rigid body.
    pub fn to_rigid_body(&self, body: &mut rapier3d::dynamics::RigidBody) {
        use rapier3d::math::Isometry;
        body.set_position(
            Isometry::translation(self.position[0], self.position[1], self.position[2]),
            true,
        );
        body.set_linvel(
            Vector::new(self.linvel[0], self.linvel[1], self.linvel[2]),
            true,
        );
        body.set_angvel(
            Vector::new(self.angvel[0], self.angvel[1], self.angvel[2]),
            true,
        );
        if self.sleeping {
            body.sleep();
        } else {
            body.wake_up(true);
        }
    }
}

/// Serialized state for a single collider.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ColliderSaveState {
    /// The handle for this collider.
    pub handle: ColliderHandle,
    /// The parent rigid body handle, if any.
    pub parent_handle: Option<RigidBodyHandle>,
    /// The position offset from the parent body (x, y, z).
    pub position_offset: [f32; 3],
    /// The rotation offset from the parent body as a quaternion (x, y, z, w).
    pub rotation_offset: [f32; 4],
    /// The collider's shape type.
    pub shape_type: String,
    /// The half-extents for cuboid shapes (x, y, z).
    pub cuboid_half_extents: Option<[f32; 3]>,
    /// The radius and half-height for capsule shapes (radius, half_height).
    pub capsule_data: Option<[f32; 2]>,
    /// The radius for ball shapes.
    pub ball_radius: Option<f32>,
    /// Whether the collider is a sensor (doesn't cause collisions).
    pub is_sensor: bool,
}

impl ColliderSaveState {
    /// Creates a new collider save state from a collider.
    pub fn from_collider(
        handle: ColliderHandle,
        collider: &rapier3d::geometry::Collider,
    ) -> Self {
        let pos_wrt_parent = collider.position_wrt_parent();
        let shape = collider.shape();

        let (shape_type_name, cuboid_half_extents, capsule_data, ball_radius) = 
            if let Some(c) = shape.downcast_ref::<rapier3d::geometry::Cuboid>() {
                ("Cuboid".to_string(), Some([c.half_extents.x, c.half_extents.y, c.half_extents.z]), None, None)
            } else if let Some(b) = shape.downcast_ref::<rapier3d::geometry::Ball>() {
                ("Ball".to_string(), None, None, Some(b.radius))
            } else if let Some(c) = shape.downcast_ref::<rapier3d::geometry::Capsule>() {
                ("Capsule".to_string(), None, Some([c.radius, c.half_height()]), None)
            } else {
                ("Unknown".to_string(), None, None, None)
            };

        Self {
            handle,
            parent_handle: Some(collider.parent()),
            position_offset: [
                pos_wrt_parent.translation.x,
                pos_wrt_parent.translation.y,
                pos_wrt_parent.translation.z,
            ],
            rotation_offset: [0.0, 0.0, 0.0, 1.0],
            shape_type: shape_type_name,
            cuboid_half_extents,
            capsule_data,
            ball_radius,
            is_sensor: collider.is_sensor(),
        }
    }
}

/// Complete serializable physics state for save/load.
///
/// This struct captures all the physics state needed to restore
/// a PhysicsSystem to its exact state at save time.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PhysicsSaveState {
    /// The save format version for physics state.
    pub physics_version: u32,
    /// The gravity vector (x, y, z).
    pub gravity: [f32; 3],
    /// Accumulated time waiting to be simulated.
    pub accumulated_time: f32,
    /// The fixed physics time step.
    pub fixed_physics_step: f32,
    /// Saved state for all rigid bodies.
    pub rigid_bodies: Vec<RigidBodySaveState>,
    /// Saved state for all colliders.
    pub colliders: Vec<ColliderSaveState>,
    /// Mapping from region IDs to their terrain collider handles.
    pub region_colliders: RegionColliderMap,
    /// The player entity handle, if one exists.
    pub player_handle: Option<EntityHandle>,
    /// The ground body handle.
    pub ground_body_handle: Option<RigidBodyHandle>,
    /// The ground collider handle.
    pub ground_collider_handle: Option<ColliderHandle>,
}

impl PhysicsSaveState {
    /// Creates a default physics state (ground plane only, no dynamic bodies).
    ///
    /// This is used for migrating v6 saves which have no physics state.
    pub fn default_with_ground_plane() -> Self {
        Self {
            physics_version: 1,
            gravity: [0.0, -9.81, 0.0],
            accumulated_time: 0.0,
            fixed_physics_step: FIXED_PHYSICS_STEP,
            rigid_bodies: Vec::new(),
            colliders: Vec::new(),
            region_colliders: RegionColliderMap::new(),
            player_handle: None,
            ground_body_handle: None,
            ground_collider_handle: None,
        }
    }
}

impl Default for PhysicsSaveState {
    fn default() -> Self {
        Self::default_with_ground_plane()
    }
}
