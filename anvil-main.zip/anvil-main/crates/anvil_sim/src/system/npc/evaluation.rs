//! NPC Evaluation Module
//!
//! Contains the action evaluation, selection, and execution logic for the NPC system.
//! This includes:
//! - Utility-AI scoring pipeline (Sprint 17)
//! - Fluency-based duration/waste modifiers (Sprint 18b)
//! - Action execution and effect application

use super::{Action, Need, ResourceEffect, ResourcePool, STAGGER_INTERVAL};
use crate::actions::catalogue;
use crate::settlement::ids::PersonId;
use crate::settlement::{Person, Settlement};
use crate::skill::affordance::AffordanceId;
use crate::skill::event::{ActionOutcome, ContextModifiers, SkillEvent};
use crate::skill::fluency::FluencyLevel;
use crate::{SimContext};
use tracing::debug;

impl super::NpcSystem {
    /// Evaluates an NPC by index and selects their next action.
    ///
    /// This implements the full utility-AI scoring pipeline from GAME_DESIGN_SECTION_4.md Section 4.4.3:
    /// score = base_urgency(need)
    ///       * time_block_multiplier(action, current_time)
    ///       * skill_modifier(npc, action)
    ///       * perception_filter(npc.mood, need)
    ///       * substrate_weight(npc.substrate, action)
    ///       * coping_modifier(settlement.damage, action.coping_type)
    ///       * cooperation_modifier(settlement.aggregate_mood, action.communal_benefit)
    ///
    /// Sprint 18b: Also applies fluency-based duration and waste modifiers during action execution.
    pub fn evaluate_npc_by_index(&mut self, person_index: usize, tick: u64) -> Option<u64> {
        let person = &self.persons[person_index];
        let person_id = person.id.get();

        // Check if this person should evaluate on this tick (staggering)
        let last_eval = self.last_evaluation_ticks.get(&person_id).copied().unwrap_or(0);
        if tick != 0 && tick >= last_eval && (tick - last_eval) < STAGGER_INTERVAL {
            return person.current_action_id;
        }

        // Update last evaluation tick
        self.last_evaluation_ticks.insert(person_id, tick);

        // Get settlement for this person
        let settlement = self.settlements.first()?;

        // Find the most urgent unsatisfied need
        // Borrow the array directly instead of cloning - stack-allocated, zero-cost
        let needs = self.need_satisfaction.get(&person_id).unwrap_or(&[0.5; 7]);

        let mut best_action: Option<u64> = None;
        let mut best_score: f32 = f32::MIN;

        // Evaluate each need and its associated actions
        for need in Self::all_needs() {
            let idx = Self::need_index(*need);
            let satisfaction = needs[idx];

            // Skip Joy need - it cannot be directly satisfied by actions
            if *need == Need::Joy {
                continue;
            }

            // Get urgency
            let urgency = 1.0 - satisfaction;
            if urgency < 0.1 {
                continue; // Need is sufficiently satisfied
            }

            // Get actions for this need
            let actions = catalogue::actions_for_need(*need);

            for action in &actions {
                // Check age category
                if !person.can_perform_age(action.min_age_category) {
                    continue;
                }

                // Sprint 18c: Check physical capability
                // Person must have sufficient physical capability to perform the action
                if person.age.physical_capability() < action.min_physical_capability {
                    continue;
                }

                // Sprint 18b: Check agency filter
                // Low agency suppresses complex action attempts
                // Use agency axis directly for Sprint 18c
                if person.emotional_state.agency() < -0.3 {
                    // At very low agency, suppress major actions
                    if action.is_major {
                        continue;
                    }
                }

                // Compute utility score
                let score = self.compute_action_score(person, action, *need, satisfaction, settlement);

                if score > best_score {
                    best_score = score;
                    best_action = Some(action.id);
                }
            }
        }

        // If no action found, try to find any available action
        if best_action.is_none() {
            for action in catalogue::actions() {
                if person.can_perform_age(action.min_age_category)
                    && person.age.physical_capability() >= action.min_physical_capability
                {
                    best_action = Some(action.id);
                    break;
                }
            }
        }

        // Set the current action
        if let Some(action_id) = best_action {
            // Calculate duration before borrowing
            let duration = if let Some(_action) = catalogue::action_by_id(action_id) {
                self.get_fluency_modified_duration(person_id, action_id)
            } else {
                60 // Default duration
            };
            
            // Emit tracing event for action selection
            if let Some(action) = catalogue::action_by_id(action_id) {
                debug!(
                    target: "npc",
                    npc_id = person_id,
                    action_id = action_id,
                    action_name = action.name,
                    score = best_score,
                    tick = tick,
                    "NPC action selected"
                );
            }
            
            let person = &mut self.persons[person_index];
            person.current_action_id = Some(action_id);
            person.current_action_remaining_ticks = duration;
        }

        best_action
    }

    /// Computes the utility score for an action for a given person.
    fn compute_action_score(
        &self,
        person: &Person,
        action: &Action,
        need: Need,
        need_satisfaction: f32,
        settlement: &Settlement,
    ) -> f32 {
        use crate::utility::scoring::*;

        let base = base_urgency(need, need_satisfaction);
        let time = time_block_multiplier(action, self.time_of_day);
        let skill = skill_modifier(&person.skills, action);
        let perception = perception_filter(
            &person.emotional_state,
            need_satisfaction,
            person.substrate.stability_anxiety,
        );
        let substrate = substrate_weight(&person.substrate, action);
        let coping = coping_modifier(settlement.damage_level, action.coping_type);
        let cooperation = cooperation_modifier(settlement.aggregate_mood, action.communal_benefit);

        base * time * skill * perception * substrate * coping * cooperation
    }

    /// Executes actions for all NPCs.
    ///
    /// This method:
    /// 1. Decrements remaining ticks for current actions
    /// 2. Applies action effects when actions complete
    /// 3. Triggers observation learning when actions complete (Sprint 18b)
    /// 4. Triggers guided correction on failure (Sprint 18b)
    pub fn execute_actions(&mut self, ctx: &mut SimContext) {
        let tick = ctx.tick;

        for i in 0..self.persons.len() {
            let person = &mut self.persons[i];
            let _person_id = person.id.get();

            if let Some(action_id) = person.current_action_id
                && person.current_action_remaining_ticks > 0
            {
                person.current_action_remaining_ticks -= 1;

                // Check if action just completed
                if person.current_action_remaining_ticks == 0 {
                    self.apply_action_effects_by_index(i, action_id, tick, ctx);
                }
            }
        }
    }

    /// Applies the effects of a completed action for an NPC by index.
    ///
    /// Sprint 18b: Applies fluency-based waste multipliers to resource production/consumption.
    /// Sprint 18c: Applies children's economic dependence rules.
    pub fn apply_action_effects_by_index(
        &mut self,
        person_index: usize,
        action_id: u64,
        current_tick: u64,
        ctx: &mut SimContext,
    ) {
        let person_id = self.persons[person_index].id.get();
        let settlement_id = self.persons[person_index].settlement_id;
        let person = &self.persons[person_index];

        let action = catalogue::action_by_id(action_id);

        if let Some(action) = action {
            // Sprint 18b: Get waste multiplier based on fluency
            let waste_multiplier = self.get_fluency_waste_multiplier(person_id, action_id);

            // Determine action outcome based on fluency
            let outcome = self.determine_action_outcome(person_id, action_id, ctx);

            // Get person mood for context modifiers
            let person_mood = person.emotional_state.mood();

            // Sprint 18c: Check if this is a child for economic dependence
            let is_child = person.age_category == crate::age::AgeCategory::Child;
            let physical_capability = person.age.physical_capability();
            
            // Children cannot produce until physical_capability > 0.5
            let can_produce = !is_child || physical_capability > 0.5;

            // Apply resource effects
            if let Some(effect) = &action.resource_effect {
                let settlement_index = self
                    .settlements
                    .iter()
                    .position(|s| s.id.get() == settlement_id)
                    .unwrap_or(0);

                match effect {
                    ResourceEffect::Produce { pool, rate } => {
                        // Sprint 18c: Children produce nothing until physical_capability > 0.5
                        if !can_produce {
                            // Skip production for children who can't produce yet
                        } else {
                            // Apply waste multiplier: higher waste = lower effective rate
                            let effective_rate = rate / waste_multiplier;
                            let amount = effective_rate * 0.1; // Scale down for per-tick
                            self.apply_production(settlement_index, *pool, amount);
                        }
                    }
                    ResourceEffect::Consume { pool, rate } => {
                        // Sprint 18c: Children consume at 0.5x adult rate
                        let consumption_multiplier = if is_child { 0.5 } else { 1.0 };
                        // For consumption, waste makes it consume more
                        let effective_rate = *rate * waste_multiplier * consumption_multiplier;
                        let amount = effective_rate * 0.1;
                        self.apply_consumption(settlement_index, *pool, amount);
                    }
                }
            }

            // Satisfy the need associated with this action
            if let Some(needs) = self.need_satisfaction.get_mut(&person_id) {
                let action_need = action.primary_need;
                // Increase satisfaction based on action completion
                // Use waste multiplier: more waste = less satisfaction gained
                let satisfaction_increase = 0.1 / waste_multiplier;
                let idx = Self::need_index(action_need);
                needs[idx] = (needs[idx] + satisfaction_increase).min(1.0);
            }

            // Emit skill event
            if let Some(affordance_id) = action.primary_affordance_id {
                let person = &self.persons[person_index];
                
                let event = SkillEvent::ActionCompleted {
                    person_id: PersonId::new(person_id),
                    affordance_id,
                    outcome,
                    context_modifiers: ContextModifiers {
                        time_of_day: Some(self.time_of_day),
                        emotional_state: Some(person_mood),
                        age_learning_multiplier: Some(person.age.learning_rate_multiplier()),
                        practice_quality_multiplier: Some(person.emotional_state.axes.practice_quality_multiplier()),
                        observation_rate_multiplier: Some(person.emotional_state.axes.observation_rate_multiplier()),
                        fluency_level: Some(self.fluency_level_for_action(person_id, action_id)),
                    },
                };
                self.pending_skill_events.push(event);

                // Sprint 18b: Apply observation learning
                self.apply_observation_learning(person_index, action_id, current_tick, ctx);

                // Sprint 18b: Apply guided correction on failure
                if outcome == ActionOutcome::Failure {
                    self.apply_guided_correction(person_id, action_id, affordance_id, current_tick);
                }

                // Sprint 18b: Apply practice
                self.apply_practice_for_action(person_id, affordance_id, outcome, current_tick);
            }

            // Clear the action
            self.persons[person_index].current_action_id = None;
            self.persons[person_index].current_action_remaining_ticks = 0;

            // Emit action completed event
            self.emit_action_completed(person_id, action_id, outcome, ctx);
        }
    }

    /// Applies resource production to a settlement.
    pub fn apply_production(&mut self, settlement_index: usize, pool: ResourcePool, amount: f32) {
        if settlement_index >= self.settlements.len() {
            return;
        }

        let settlement = &mut self.settlements[settlement_index];
        let current = match pool {
            ResourcePool::Food => settlement.food_store,
            ResourcePool::Water => settlement.water,
            ResourcePool::Materials => settlement.materials,
            ResourcePool::StructuralIntegrity => settlement.structural_integrity,
        };

        let new_value = (current + amount).min(1.0);

        match pool {
            ResourcePool::Food => settlement.food_store = new_value,
            ResourcePool::Water => settlement.water = new_value,
            ResourcePool::Materials => settlement.materials = new_value,
            ResourcePool::StructuralIntegrity => settlement.structural_integrity = new_value,
        }
    }

    /// Applies resource consumption to a settlement.
    pub fn apply_consumption(&mut self, settlement_index: usize, pool: ResourcePool, amount: f32) {
        if settlement_index >= self.settlements.len() {
            return;
        }

        let settlement = &mut self.settlements[settlement_index];
        let current = match pool {
            ResourcePool::Food => settlement.food_store,
            ResourcePool::Water => settlement.water,
            ResourcePool::Materials => settlement.materials,
            ResourcePool::StructuralIntegrity => settlement.structural_integrity,
        };

        let new_value = (current - amount).max(0.0);

        match pool {
            ResourcePool::Food => settlement.food_store = new_value,
            ResourcePool::Water => settlement.water = new_value,
            ResourcePool::Materials => settlement.materials = new_value,
            ResourcePool::StructuralIntegrity => settlement.structural_integrity = new_value,
        }
    }

    /// Determines the outcome of an action based on fluency level (Sprint 18b).
    pub fn determine_action_outcome(
        &self,
        person_id: u64,
        action_id: u64,
        ctx: &mut SimContext,
    ) -> ActionOutcome {
        let fluency = self.fluency_level_for_action(person_id, action_id);

        // Higher fluency = higher success probability
        let success_probability = match fluency {
            FluencyLevel::Halting => 0.3,
            FluencyLevel::Awkward => 0.5,
            FluencyLevel::Competent => 0.75,
            FluencyLevel::Smooth => 0.9,
            FluencyLevel::Expert => 0.98,
        };

        // Use deterministic RNG for outcome determination
        let roll = ctx.rng.next_f32();

        if roll < success_probability {
            ActionOutcome::Success
        } else if roll < success_probability + 0.2 {
            ActionOutcome::Partial
        } else {
            ActionOutcome::Failure
        }
    }

    /// Applies practice for a completed action (Sprint 18a + 18b modifications).
    pub fn apply_practice_for_action(
        &mut self,
        person_id: u64,
        affordance_id: AffordanceId,
        outcome: ActionOutcome,
        current_tick: u64,
    ) {
        if let Some(person) = self.persons.iter_mut().find(|p| p.id.get() == person_id) {
            let event = SkillEvent::ActionCompleted {
                person_id: PersonId::new(person_id),
                affordance_id,
                outcome,
                context_modifiers: ContextModifiers::new(),
            };

            // Apply practice using the skill system
            use crate::skill::practice::apply_practice;
            let unlock_events = apply_practice(
                &mut person.skill_profile,
                &event,
                &self.catalogue,
                current_tick,
            );

            // Collect unlock events
            self.pending_skill_events.extend(unlock_events);
        }
    }
}
