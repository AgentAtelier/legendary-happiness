//! NPC Observation Module
//!
//! Contains the incidental teaching and guided correction logic for the NPC system.
//! This implements:
//! - Sprint 18b Task 5: Incidental teaching via co-performance
//! - Sprint 18b Task 6: Guided correction on failure

use super::{AffordanceId, OBSERVATION_DAILY_CAP, TICKS_PER_DAY};
use crate::actions::catalogue;
use crate::settlement::ids::PersonId;
use crate::skill::event::SkillEvent;
use crate::SimContext;

impl super::NpcSystem {
    /// Applies observation-based incidental teaching (Sprint 18b Task 5).
    ///
    /// When an NPC completes an action, nearby NPCs have a chance to observe and learn.
    /// - Base observation rate: 15%
    /// - Amplified by demonstrator's Belonging: +5% if belonging > 0.3, +10% if belonging > 0.7
    /// - Daily cap of 3 gains per (person, affordance)
    pub fn apply_observation_learning(&mut self, demonstrator_index: usize, action_id: u64, current_tick: u64, ctx: &mut SimContext) {
        let demonstrator_id = self.persons[demonstrator_index].id.get();
        let demonstrator_settlement_id = self.persons[demonstrator_index].settlement_id;
        let demonstrator_belonging = self.persons[demonstrator_index].belonging;

        // Get the action and its affordance
        let action = catalogue::action_by_id(action_id);
        let affordance_id = action.and_then(|a| a.primary_affordance_id);

        if let Some(affordance_id) = affordance_id {
            // Calculate observation rate multiplier based on demonstrator's belonging
            let base_rate = 0.15;
            let belonging_amplifier = if demonstrator_belonging > 0.7 {
                0.25
            } else if demonstrator_belonging > 0.3 {
                0.20
            } else {
                0.0
            };
            let observation_rate = base_rate + belonging_amplifier;

            // Check current day for cap tracking
            let current_day = current_tick / TICKS_PER_DAY;

            // If day changed, reset observation gains
            if current_day != self.current_day {
                self.current_day = current_day;
                self.observation_gains_today.clear();
            }

            // Find observers - for simplicity, we consider all NPCs in the same settlement
            // In a full implementation, this would be based on spatial proximity
            for observer_index in 0..self.persons.len() {
                if observer_index == demonstrator_index {
                    continue; // Skip self
                }

                let observer = &self.persons[observer_index];
                let observer_id = observer.id.get();

                // Check if observer is in the same settlement
                if observer.settlement_id != demonstrator_settlement_id {
                    continue;
                }

                // Check if observer is eligible (not already at cap for this affordance today)
                let gains_so_far = self
                    .observation_gains_today
                    .get(&(observer_id, affordance_id))
                    .copied()
                    .unwrap_or(0);

                if gains_so_far >= OBSERVATION_DAILY_CAP {
                    continue;
                }

                // Check if observer can observe this affordance (using cached values)
                if observer.belonging < -0.3 {
                    continue;
                }

                // Use deterministic RNG for observation check
                let roll = ctx.rng.next_f32();

                if roll < observation_rate {
                    let observer_person = &self.persons[observer_index];
                    
                    // Get emotional axes multipliers
                    let emotional_axes = &observer_person.emotional_state.axes;
                    
                    // Create and emit event with context modifiers (Sprint 18c)
                    let event = SkillEvent::ObservationGained {
                        observer_id: PersonId::new(observer_id),
                        demonstrator_id: PersonId::new(demonstrator_id),
                        affordance_id,
                        context_modifiers: crate::skill::event::ContextModifiers {
                            time_of_day: Some(self.time_of_day),
                            emotional_state: Some(observer_person.emotional_state.mood()),
                            age_learning_multiplier: Some(observer_person.age.learning_rate_multiplier()),
                            practice_quality_multiplier: Some(emotional_axes.practice_quality_multiplier()),
                            observation_rate_multiplier: Some(emotional_axes.observation_rate_multiplier()),
                            fluency_level: None,
                        },
                    };
                    
                    // Apply practice for observation (incidental learning) - must happen before push
                    use crate::skill::practice::apply_practice;
                    let _unlock_events = apply_practice(
                        &mut self.persons[observer_index].skill_profile,
                        &event,
                        &self.catalogue,
                        current_tick,
                    );
                    
                    // Emit event to pending queue
                    self.pending_skill_events.push(event);

                    // Increment observation gain counter
                    self.observation_gains_today
                        .entry((observer_id, affordance_id))
                        .and_modify(|c| *c += 1)
                        .or_insert(1);
                }
            }
        }
    }

    /// Applies guided correction on action failure (Sprint 18b Task 6).
    ///
    /// When an NPC fails an action near a higher-skilled NPC, they gain maturity at 2x rate.
    /// Conditions:
    /// - Failing NPC's Belonging > -0.5
    /// - Failing NPC's Agency > -0.5
    /// - There is a nearby NPC (same settlement) with the affordance unlocked
    /// - The skilled NPC's Belonging > -0.5
    ///
    /// The skilled NPC's current action is not interrupted — correction is a brief bark/gesture.
    /// Emits `SkillEvent::ObservationGained` (reuse; the observation infrastructure handles the maturity update).
    pub fn apply_guided_correction(
        &mut self,
        failing_person_id: u64,
        action_id: u64,
        affordance_id: AffordanceId,
        current_tick: u64,
    ) {
        use crate::skill::event::ContextModifiers;
        use crate::skill::event::SkillEvent;

        // Get the failing person
        let failing_index = match self.persons.iter().position(|p| p.id.get() == failing_person_id) {
            Some(idx) => idx,
            None => return,
        };

        let failing_person = &self.persons[failing_index];

        // Gate: Failing NPC's Belonging > -0.5
        if failing_person.belonging <= super::GUIDED_CORRECTION_BELONGING_THRESHOLD {
            return;
        }

        // Gate: Failing NPC's Agency > -0.5
        if failing_person.emotional_state.axes.agency_helplessness <= super::GUIDED_CORRECTION_BELONGING_THRESHOLD {
            return;
        }

        // Get the domain for this action
        let Some(_domain) = self.domain_for_action(action_id) else {
            return;
        };

        // Check that failing NPC does not have this affordance unlocked
        if failing_person.skill_profile.is_unlocked(affordance_id) {
            return; // Already unlocked, no guided correction needed
        }

        // Find potential mentors - NPCs in the same settlement with the affordance unlocked
        for potential_mentor in &self.persons {
            if potential_mentor.id.get() == failing_person_id {
                continue; // Skip self
            }

            // Proximity check: same settlement (proximity < 10 units proxy)
            if potential_mentor.settlement_id != failing_person.settlement_id {
                continue;
            }

            // Gate: Mentor's Belonging > -0.5
            if potential_mentor.belonging <= super::GUIDED_CORRECTION_BELONGING_THRESHOLD {
                continue;
            }

            // Check if mentor has the affordance unlocked
            if !potential_mentor.skill_profile.is_unlocked(affordance_id) {
                continue;
            }

            // Guided correction applies - emit ObservationGained event with 2x rate modifier
            // The practice infrastructure will handle the maturity update
            let event = SkillEvent::ObservationGained {
                observer_id: PersonId::new(failing_person_id),
                demonstrator_id: PersonId::new(potential_mentor.id.get()),
                affordance_id,
                context_modifiers: ContextModifiers {
                    time_of_day: Some(self.time_of_day),
                    emotional_state: Some(failing_person.emotional_state.mood()),
                    age_learning_multiplier: Some(failing_person.age.learning_rate_multiplier()),
                    practice_quality_multiplier: Some(super::GUIDED_CORRECTION_MULTIPLIER),
                    observation_rate_multiplier: Some(super::GUIDED_CORRECTION_MULTIPLIER),
                    fluency_level: None,
                },
            };

            // Apply practice with guided correction multiplier via observation
            // This reuses the observation infrastructure which applies learning
            use crate::skill::practice::apply_practice;
            let _unlock_events = apply_practice(
                &mut self.persons[failing_index].skill_profile,
                &event,
                &self.catalogue,
                current_tick,
            );

            // Emit the event to pending queue
            self.pending_skill_events.push(event);

            // Only apply once (first eligible mentor found)
            break;
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::age::Age;
    use crate::settlement::ids::{FamilyId, PersonId};
    use crate::settlement::Person;
    use crate::skill::affordance::AffordanceId;
    use crate::skill::catalogue::AffordanceCatalogue;
    use crate::skill::domain::SkillDomain;
    use crate::skill::SkillProfile;
    use crate::soul::{EmotionalAxes, EmotionalState, Substrate};
    use crate::system::npc::NpcSystem;

    fn create_test_person(id: u64, settlement_id: u64, belongs_to_settlement: bool) -> Person {
        use glam::Vec3;
        let belonging = if belongs_to_settlement { 0.8 } else { -0.6 };
        Person::new(
            PersonId::new(id),
            format!("TestPerson_{}", id),
            FamilyId::new(1),
            Age::from_years(25.0),
            Substrate::neutral(),
            EmotionalState::new(EmotionalAxes::neutral()),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            settlement_id,
            belonging,
            Vec3::ZERO,
        )
    }

    #[test]
    fn test_guided_correction_applies_when_conditions_met() {
        let mut system = NpcSystem::new();
        let settlement_id = 1;

        // Create failing NPC with Belonging > -0.5 and Agency > -0.5
        use glam::Vec3;
        let failing_person = Person::new(
            PersonId::new(1),
            "Failing".to_string(),
            FamilyId::new(1),
            Age::from_years(25.0),
            Substrate::neutral(),
            EmotionalState::new(EmotionalAxes::new(0.5, 0.5, 0.6, 0.5)), // Agency = 0.6 > -0.5
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            settlement_id,
            0.6, // Belonging > -0.5
            Vec3::ZERO,
        );

        // Create mentor NPC with Belonging > -0.5 and the affordance unlocked
        let mut mentor_person = create_test_person(2, settlement_id, true);
        // Unlock the affordance for the mentor
        mentor_person.skill_profile.add_affordance(AffordanceId::new(1));
        mentor_person.skill_profile.maturities.insert(
            AffordanceId::new(1),
            crate::skill::affordance::MaturityState::with_maturity(0.9),
        );
        mentor_person.skill_profile.unlock(AffordanceId::new(1));

        system.persons.push(failing_person);
        system.persons.push(mentor_person);
        system.catalogue = AffordanceCatalogue::new();
        system.catalogue.add(crate::skill::affordance::Affordance::with_default_threshold(
            AffordanceId::new(1),
            SkillDomain::Husbandry,
            "test_affordance",
        ));

        // Apply guided correction
        let action_id = 1;
        system.apply_guided_correction(1, action_id, AffordanceId::new(1), 100);

        // Check that the failing NPC gained some maturity
        let failing_profile = &system.persons[0].skill_profile;
        let maturity = failing_profile.get_maturity_value(AffordanceId::new(1));
        assert!(maturity > 0.0, "Guided correction should increase maturity");
    }

    #[test]
    fn test_guided_correction_blocked_by_low_belonging() {
        use glam::Vec3;
        let mut system = NpcSystem::new();
        let settlement_id = 1;

        // Create failing NPC with Belonging <= -0.5
        let failing_person = Person::new(
            PersonId::new(1),
            "Failing".to_string(),
            FamilyId::new(1),
            Age::from_years(25.0),
            Substrate::neutral(),
            EmotionalState::new(EmotionalAxes::neutral()),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            settlement_id,
            -0.6, // Belonging <= -0.5
            Vec3::ZERO,
        );

        system.persons.push(failing_person);
        system.catalogue = AffordanceCatalogue::new();

        // Apply guided correction - should be blocked
        system.apply_guided_correction(1, 1, AffordanceId::new(1), 100);

        // No events should be pending
        assert!(system.pending_skill_events.is_empty(), "Guided correction should be blocked by low belonging");
    }
}
