//! NPC System
//!
//! Implements the core NPC simulation system as specified in GAME_DESIGN_SECTION_3.md
//! Section 3.1.1 and extended with:
//! - Sprint 17: Layered Soul model, utility-AI action selection, staggering, targeting
//! - Sprint 18a: Skill profiles, practice/decay, affordance unlocking
//! - Sprint 18b: Fluency levels, perceptibility modifiers, incidental teaching, guided correction
//!
//! Defined in GAME_DESIGN_SECTION_3.md, GAME_DESIGN_SECTION_4.md, and Sprint 18 design decisions.

use crate::actions::catalogue;
use crate::actions::{Action, CopingType, ResourceEffect, ResourcePool, TimeBlock};
use crate::age::AgeCategory;
use crate::needs::Need;
use crate::settlement::ids::PersonId;
use crate::settlement::{Family, Person, Settlement};
use crate::skill::affordance::AffordanceId;
use crate::skill::catalogue::{AffordanceCatalogue, TICKS_PER_DAY};
use crate::skill::domain::SkillDomain;
use crate::skill::event::{ActionOutcome, SkillEvent};
use crate::skill::fluency::{FluencyLevel, FluencyLevelExt};
use crate::skill::perceptibility::PerceptibilityMapper;
use crate::{SimContext, SimError, SimEvent, SimSystem};
use anvil_core::{FailureClass, ValidationErrors};
use anvil_core::{error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, VecDeque};
use std::fmt;

pub mod evaluation;
pub mod observation;

/// Number of simulation ticks between staggered NPC evaluations.
/// This implements Design Constraint 13 (staggered evaluation).
const STAGGER_INTERVAL: u64 = 30;

/// Daily observation gain cap per (person, affordance).
const OBSERVATION_DAILY_CAP: u32 = 3;

/// Guided correction practice rate multiplier (2x normal rate).
const GUIDED_CORRECTION_MULTIPLIER: f32 = 2.0;

/// Minimum belonging threshold for guided correction eligibility.
const GUIDED_CORRECTION_BELONGING_THRESHOLD: f32 = -0.5;

/// The NPC simulation system.
///
/// This is the core system that manages NPC state and behaviour, including:
/// - Action selection via utility scoring
/// - Action execution with duration and resource effects
/// - Need satisfaction and decay
/// - Skill practice and decay (Sprint 18a)
/// - Fluency-based perceptibility modifiers (Sprint 18b)
/// - Incidental teaching via observation (Sprint 18b)
/// - Guided correction on failure (Sprint 18b)
#[derive(Serialize, Deserialize)]
pub struct NpcSystem {
    /// The settlements managed by this system.
    pub settlements: Vec<Settlement>,
    /// All persons in the simulation.
    pub persons: Vec<Person>,
    /// All families in the simulation.
    pub families: Vec<Family>,
    /// Track the last evaluation tick for each person (for staggering).
    pub last_evaluation_ticks: BTreeMap<u64, u64>,
    /// Track the last full evaluation tick.
    pub last_full_eval_tick: u64,
    /// Need satisfaction for each person and need.
    /// Map: person_id -> [f32; 7] where index corresponds to need via `need_index()`.
    /// Using a fixed-size array enables LLVM auto-vectorisation and eliminates
    /// heap allocations for need lookups.
    pub need_satisfaction: BTreeMap<u64, [f32; 7]>,
    /// The current time of day (0.0 to 1.0).
    pub time_of_day: f32,
    /// The global affordance catalogue (Sprint 18a).
    #[serde(skip)]
    pub catalogue: AffordanceCatalogue,
    /// The perceptibility mapper for fluency-based modifiers (Sprint 18b).
    #[serde(skip)]
    pub perceptibility_mapper: PerceptibilityMapper,
    /// Track observation gains per (person_id, affordance_id) per day (Sprint 18b).
    pub observation_gains_today: BTreeMap<(u64, AffordanceId), u32>,
    /// Current day number for observation cap tracking (Sprint 18b).
    pub current_day: u64,
    /// Pending skill events to be processed.
    pub pending_skill_events: Vec<SkillEvent>,
    /// Skill events emitted by this system for external consumption.
    pub emitted_skill_events: VecDeque<SkillEvent>,
}

impl NpcSystem {
    /// Creates a new NpcSystem with empty state.
    pub fn new() -> Self {
        Self {
            settlements: Vec::new(),
            persons: Vec::new(),
            families: Vec::new(),
            last_evaluation_ticks: BTreeMap::new(),
            last_full_eval_tick: 0,
            need_satisfaction: BTreeMap::new(),
            time_of_day: 0.25, // Start at mid-morning
            catalogue: AffordanceCatalogue::new(),
            perceptibility_mapper: PerceptibilityMapper::new(),
            observation_gains_today: BTreeMap::new(),
            current_day: 0,
            pending_skill_events: Vec::new(),
            emitted_skill_events: VecDeque::new(),
        }
    }

    /// Adds a settlement to the system.
    pub fn add_settlement(&mut self, settlement: Settlement) {
        self.settlements.push(settlement);
    }

    /// Adds a person to the system.
    pub fn add_person(&mut self, person: Person) {
        // Initialize need satisfaction for this person
        let person_id = person.id.get();
        self.persons.push(person);
        // Start with 50% satisfaction for all 7 needs
        self.need_satisfaction.insert(person_id, [0.5; 7]);
        // Initialize last evaluation tick
        let offset = (self.persons.len() as u64) % STAGGER_INTERVAL;
        self.last_evaluation_ticks.insert(person_id, offset);
    }

    /// Adds a family to the system.
    pub fn add_family(&mut self, family: Family) {
        self.families.push(family);
    }

    /// Sets the current time of day (0.0 to 1.0).
    pub fn set_time_of_day(&mut self, time: f32) {
        self.time_of_day = time.clamp(0.0, 1.0);
    }

    /// Returns the need satisfaction for a person and need.
    pub fn get_need_satisfaction(&self, person_id: u64, need: Need) -> f32 {
        self.need_satisfaction
            .get(&person_id)
            .map(|needs| needs[Self::need_index(need)])
            .unwrap_or(0.5) // Default to 50% if not initialized
    }

    /// Sets the need satisfaction for a person and need.
    pub fn set_need_satisfaction(&mut self, person_id: u64, need: Need, value: f32) {
        let clamped = value.clamp(0.0, 1.0);
        let idx = Self::need_index(need);
        self.need_satisfaction
            .entry(person_id)
            .or_insert([0.5; 7])
            [idx] = clamped;
    }

    /// Decays all needs for all persons based on their decay rates.
    pub fn decay_needs(&mut self, tick: u64) {
        // Decay is applied per-tick, but we skip decay on ticks where we don't evaluate
        // to avoid compounding too frequently
        if !tick.is_multiple_of(10) {
            return;
        }

        for person in &mut self.persons {
            let person_id = person.id.get();
            if let Some(needs) = self.need_satisfaction.get_mut(&person_id) {
                for need in Self::all_needs() {
                    let idx = Self::need_index(*need);
                    let decay_rate = need.decay_rate();
                    let decayed = (needs[idx] - decay_rate).max(0.0);
                    needs[idx] = decayed;
                }
            }
        }
    }

    /// Returns all needs in order.
    pub fn all_needs() -> &'static [Need] {
        &[
            Need::Food,
            Need::Water,
            Need::Shelter,
            Need::Safety,
            Need::Sleep,
            Need::Companionship,
            Need::Joy,
        ]
    }

    /// Returns the index of a need in the need satisfaction map.
    pub fn need_index(need: Need) -> usize {
        match need {
            Need::Food => 0,
            Need::Water => 1,
            Need::Shelter => 2,
            Need::Safety => 3,
            Need::Sleep => 4,
            Need::Companionship => 5,
            Need::Joy => 6,
        }
    }

    /// Returns the fluency level for a person and skill domain (Sprint 18b).
    pub fn fluency_level(&self, person_id: u64, domain: SkillDomain) -> FluencyLevel {
        if let Some(person) = self.persons.iter().find(|p| p.id.get() == person_id) {
            person.skill_profile.fluency_level(domain, &self.catalogue)
        } else {
            FluencyLevel::Halting
        }
    }

    /// Returns the skill domain for an action ID (Sprint 18b).
    pub fn domain_for_action(&self, action_id: u64) -> Option<SkillDomain> {
        catalogue::action_by_id(action_id)
            .and_then(|action| action.primary_affordance_id)
            .and_then(|affordance_id| {
                // Try self.catalogue first, then fall back to global
                // We clone the domain from the catalogue to avoid lifetime issues
                self.catalogue.get(affordance_id)
                    .map(|a| a.domain)
                    .or_else(|| {
                        let global = crate::skill::catalogue::affordance_catalogue();
                        global.get(affordance_id).map(|a| a.domain)
                    })
            })
    }

    /// Returns the fluency level for a person and action ID (Sprint 18b).
    pub fn fluency_level_for_action(&self, person_id: u64, action_id: u64) -> FluencyLevel {
        if let Some(domain) = self.domain_for_action(action_id) {
            self.fluency_level(person_id, domain)
        } else {
            FluencyLevel::Halting
        }
    }

    /// Returns the fluency-modified duration for an action (Sprint 18b).
    pub fn get_fluency_modified_duration(&self, person_id: u64, action_id: u64) -> u64 {
        let action = catalogue::action_by_id(action_id).unwrap_or_else(|| {
            // Default action if not found
            Action::new(
                action_id,
                "Unknown".to_string(),
                Need::Food,
                AgeCategory::Adult,
                true,
                true,
                CopingType::None,
                None,
                TimeBlock::Dawn,
                60,
                None,
                0.0, // min_physical_capability: default for unknown action
            )
        });

        let fluency = self.fluency_level_for_action(person_id, action_id);
        let domain = self.domain_for_action(action_id).unwrap_or(SkillDomain::Husbandry);

        let multiplier = self.perceptibility_mapper.get_duration_multiplier(domain, fluency);
        let modified = (action.duration_ticks as f32 * multiplier).ceil() as u64;
        modified.max(1) // Ensure at least 1 tick
    }

    /// Returns the fluency-modified waste multiplier for an action (Sprint 18b).
    pub fn get_fluency_waste_multiplier(&self, person_id: u64, action_id: u64) -> f32 {
        let fluency = self.fluency_level_for_action(person_id, action_id);
        let domain = self.domain_for_action(action_id).unwrap_or(SkillDomain::Husbandry);
        self.perceptibility_mapper.get_waste_multiplier(domain, fluency)
    }

    /// Evaluates a single NPC by PersonId.
    pub fn evaluate_npc(&mut self, person_id: PersonId, tick: u64) -> Option<u64> {
        let index = self.persons.iter().position(|p| p.id == person_id)?;
        self.evaluate_npc_by_index(index, tick)
    }

    /// Selects targets for actions that require them.
    pub fn select_targets(&mut self) {
        // For now, target selection is simple - we don't have many actions that need targets
        // In a full implementation, this would use the targeting module
    }

    /// Applies skill decay to all persons (Sprint 18a).
    /// 
    /// Sprint 18c: Includes emotional decay rate multipliers.
    pub fn apply_skill_decay(&mut self, current_tick: u64) {
        use crate::skill::practice::apply_decay;

        for person in &mut self.persons {
            // Get emotional decay multiplier from the person's emotional state
            let emotion_multiplier = Some(person.emotional_state.axes.decay_rate_multiplier());
            apply_decay(&mut person.skill_profile, current_tick, emotion_multiplier);
        }
    }

    /// Processes pending skill events and applies practice/decay.
    pub fn process_skill_events(&mut self, current_tick: u64) {
        // Apply decay periodically
        if current_tick.is_multiple_of(100) {
            self.apply_skill_decay(current_tick);
        }

        // Process pending skill events - drain directly into emitted_skill_events
        // Single pass, zero intermediate allocation
        self.emitted_skill_events.extend(self.pending_skill_events.drain(..));
    }

    /// Emits an action completed event for external systems.
    pub fn emit_action_completed(&mut self, person_id: u64, action_id: u64, outcome: ActionOutcome, ctx: &mut SimContext) {
        ctx.events_out.push(SimEvent::ActionCompleted {
            person_id,
            action_id,
            outcome,
        });
    }

    /// Emits an observation gained event.
    pub fn emit_observation_gained(&mut self, _observer_id: u64, _demonstrator_id: u64, _affordance_id: AffordanceId) {
        // This is a placeholder for future event system integration
    }

    /// Checks if an observer can observe a demonstrator's affordance (Sprint 18b).
    pub fn can_observe_affordance(
        &self,
        observer: &Person,
        _demonstrator: &Person,
        affordance_id: AffordanceId,
    ) -> bool {
        // Belonging isolation filter: low belonging reduces observation eligibility
        // If observer's belonging is very low (< -0.3), they're too isolated to learn
        if observer.belonging < -0.3 {
            return false;
        }

        // Check if the affordance is in a domain the observer could benefit from
        // For now, we allow observation of all affordances
        // In a full implementation, there might be additional constraints

        // The observer must not already be expert in this affordance's domain
        if let Some(affordance) = self.catalogue.get(affordance_id) {
            let _observer_fluency = observer.skill_profile.fluency_level(affordance.domain, &self.catalogue);
            // Even experts can observe and learn (maintenance, refinement)
        }

        true
    }

    /// Observation rate multiplier based on belonging (Sprint 18b).
    pub fn observation_rate_multiplier(belonging: f32) -> f32 {
        if belonging > 0.7 {
            1.25
        } else if belonging > 0.3 {
            1.20
        } else if belonging < -0.3 {
            0.5 // Isolation blocks teaching eligibility
        } else {
            1.0
        }
    }
}

impl SimSystem for NpcSystem {
    fn name(&self) -> &'static str {
        "npc_system"
    }

    fn priority(&self) -> u32 {
        // NPC system runs first (highest priority) to establish NPC actions
        // Other systems can then react to NPC state
        100
    }

    #[tracing::instrument(skip(self, ctx), fields(tick = ctx.tick))]
    fn tick(&mut self, ctx: &mut SimContext) -> Result<(), SimError> {
        let tick = ctx.tick;

        // Advance time of day
        self.time_of_day = (tick as f32 / TICKS_PER_DAY as f32) % 1.0;

        // Decay needs
        self.decay_needs(tick);

        // Process skill events (decay, etc.)
        self.process_skill_events(tick);

        // Evaluate NPCs (staggered)
        for i in 0..self.persons.len() {
            self.evaluate_npc_by_index(i, tick);
        }

        // Execute actions
        self.execute_actions(ctx);

        // Select targets for actions that need them
        self.select_targets();

        // Clear emitted skill events to prevent unbounded growth
        // (Wave 3: full event integration deferred; events already processed internally)
        self.emitted_skill_events.clear();

        Ok(())
    }

    fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        // Validate settlements
        for settlement in &self.settlements {
            errors.extend(settlement.validate());
        }

        // Validate persons
        for person in &self.persons {
            errors.extend(person.validate());
        }

        // Validate families
        for family in &self.families {
            errors.extend(family.validate());
        }

        // Validate need satisfaction values
        for needs in self.need_satisfaction.values() {
            for &satisfaction in needs.iter() {
                if !satisfaction.is_finite() || !(0.0..=1.0).contains(&satisfaction) {
                    push_validation_error!(
                        errors,
                        FailureClass::Semantic,
                        "E179",
                        "NpcSystem",
                        "need_satisfaction",
                        format!("{}", satisfaction),
                        "need satisfaction must be in [0.0, 1.0]"
                    );
                }
            }
        }

        errors
    }

    fn snapshot(&self) -> Option<Vec<u8>> {
        serde_json::to_vec(self).ok()
    }

    fn restore(&mut self, bytes: &[u8]) -> Result<(), SimError> {
        *self = serde_json::from_slice(bytes)
            .map_err(|e| SimError::InvalidSnapshot(format!("Failed to deserialize NpcSystem: {}", e)))?;
        Ok(())
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn std::any::Any {
        self
    }
}

impl Default for NpcSystem {
    fn default() -> Self {
        Self::new()
    }
}

impl fmt::Display for NpcSystem {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "NpcSystem {{ settlements: {}, persons: {}, families: {}, time_of_day: {:.2} }}",
            self.settlements.len(),
            self.persons.len(),
            self.families.len(),
            self.time_of_day
        )
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::age::Age;
    use crate::settlement::ids::{FamilyId, PersonId, SettlementId};
    use crate::skill::SkillProfile;
    use crate::soul::{EmotionalState, Substrate};
    use crate::{DeterministicRng, SimContext, SimEvent, WorldEnv, WorldRuntime};
    use anvil_core::RegionId;
    use anvil_world::WorldAuthored;

    fn create_test_settlement(id: u64) -> Settlement {
        Settlement::new_with_defaults(
            SettlementId::new(id),
            format!("TestSettlement{}", id),
            RegionId::new(0),
            10,
        )
    }

    fn create_test_person(id: u64, mood: f32, substrate: Substrate, settlement_id: u64) -> Person {
        use glam::Vec3;
        Person::new(
            PersonId::new(id),
            format!("Person{}", id),
            FamilyId::new(1),
            Age::from_years(20.0),
            substrate,
            EmotionalState::from_mood(mood),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            settlement_id,
            0.5,
            Vec3::ZERO,
        )
    }

    #[test]
    fn test_npc_system_creation() {
        let system = NpcSystem::new();
        assert_eq!(system.name(), "npc_system");
        assert_eq!(system.priority(), 100);
        assert!(system.validate().is_empty());
    }

    #[test]
    fn test_npc_system_add_settlement() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);
        assert_eq!(system.settlements.len(), 1);
    }

    #[test]
    fn test_npc_system_add_person() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        assert_eq!(system.persons.len(), 1);
        assert!(system.need_satisfaction.contains_key(&1));
    }

    #[test]
    fn test_npc_system_need_satisfaction() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // Default satisfaction should be 0.5
        assert_eq!(system.get_need_satisfaction(1, Need::Food), 0.5);

        // Set and get
        system.set_need_satisfaction(1, Need::Food, 0.8);
        assert_eq!(system.get_need_satisfaction(1, Need::Food), 0.8);

        // Clamping
        system.set_need_satisfaction(1, Need::Food, 1.5);
        assert_eq!(system.get_need_satisfaction(1, Need::Food), 1.0);

        system.set_need_satisfaction(1, Need::Food, -0.5);
        assert_eq!(system.get_need_satisfaction(1, Need::Food), 0.0);
    }

    #[test]
    fn test_npc_system_evaluate_npc() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // Set low satisfaction for food need
        system.set_need_satisfaction(1, Need::Food, 0.2);

        // Evaluate - should select a food-related action
        let action_id = system.evaluate_npc_by_index(0, 0);
        assert!(action_id.is_some());

        // The action should be related to food
        let action = catalogue::action_by_id(action_id.unwrap()).unwrap();
        assert_eq!(action.primary_need, Need::Food);
    }

    #[test]
    fn test_npc_system_time_of_day() {
        let mut system = NpcSystem::new();
        system.set_time_of_day(0.5);
        assert_eq!(system.time_of_day, 0.5);

        // Clamping
        system.set_time_of_day(1.5);
        assert_eq!(system.time_of_day, 1.0);

        system.set_time_of_day(-0.5);
        assert_eq!(system.time_of_day, 0.0);
    }

    #[test]
    fn test_fluency_level_derivation() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // With no unlocked affordances, should be Halting
        assert_eq!(
            system.fluency_level(1, SkillDomain::Husbandry),
            FluencyLevel::Halting
        );
    }

    #[test]
    fn test_domain_for_action() {
        let system = NpcSystem::new();

        // Farm/Tend -> Husbandry
        assert_eq!(
            system.domain_for_action(1),
            Some(SkillDomain::Husbandry)
        );

        // Build/Repair -> Woodcraft
        assert_eq!(
            system.domain_for_action(8),
            Some(SkillDomain::Woodcraft)
        );

        // Sleep -> No affordance, so None
        assert_eq!(system.domain_for_action(14), None);
    }

    #[test]
    fn test_fluency_level_for_action() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // Farm/Tend with no unlocked Husbandry affordances -> Halting
        assert_eq!(
            system.fluency_level_for_action(1, 1),
            FluencyLevel::Halting
        );
    }

    #[test]
    fn test_fluency_modified_duration() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // Farm/Tend has base duration of 60 ticks
        // With Halting fluency (2.0x multiplier): 60 * 2.0 = 120
        let duration = system.get_fluency_modified_duration(1, 1);
        assert_eq!(duration, 120);
    }

    #[test]
    fn test_npc_system_display() {
        let system = NpcSystem::new();
        let display = format!("{}", system);
        assert!(display.contains("NpcSystem"));
        assert!(display.contains("settlements: 0"));
        assert!(display.contains("persons: 0"));
    }

    #[test]
    fn test_npc_system_tick() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        let mut world = WorldRuntime::new(WorldAuthored::default());
        let mut rng = DeterministicRng::new(42);
        let events_in: Vec<SimEvent> = Vec::new();
        let mut events_out: Vec<SimEvent> = Vec::new();
        let world_env = WorldEnv::default();
        let mut ctx = SimContext::new(0, 1000, &mut rng, &mut world, &world_env, &events_in, &mut events_out);

        // Tick should not panic
        system.tick(&mut ctx).unwrap();

        // After tick, the person should have an action
        assert!(system.persons[0].current_action_id.is_some());
    }

    #[test]
    fn test_observation_rate_multiplier() {
        assert!((NpcSystem::observation_rate_multiplier(0.8) - 1.25).abs() < 0.001);
        assert!((NpcSystem::observation_rate_multiplier(0.5) - 1.20).abs() < 0.001);
        assert!((NpcSystem::observation_rate_multiplier(0.2) - 1.0).abs() < 0.001);
        assert!((NpcSystem::observation_rate_multiplier(-0.5) - 0.5).abs() < 0.001);
    }

    #[test]
    fn test_npc_system_validation() {
        let mut system = NpcSystem::new();
        let settlement = create_test_settlement(1);
        system.add_settlement(settlement);

        let substrate = Substrate::neutral();
        let person = create_test_person(1, 0.0, substrate, 1);
        system.add_person(person);

        // Set invalid need satisfaction
        system.need_satisfaction.entry(1).or_insert([0.5; 7])[0] = 1.5;

        let errors = system.validate();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].code().as_str(), "E179");
    }
}
