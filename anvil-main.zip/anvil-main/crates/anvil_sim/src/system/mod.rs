//! Simulation systems.
//!
//! This module contains the various simulation systems that implement
//! the `SimSystem` trait.

pub mod catastrophe;
pub mod joy;
pub mod npc;
pub mod physics;
pub mod physics_save;

pub use catastrophe::CatastropheSystem;
pub use joy::JoySystem;
pub use npc::NpcSystem;
pub use physics::PhysicsSystem;
pub use physics_save::{ColliderSaveState, EntityHandle, PhysicsSaveState, RegionColliderMap, RigidBodySaveState};
