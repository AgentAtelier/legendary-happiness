//! Catastrophe simulation system implementation.
//!
//! This module contains the `CatastropheSystem` which implements the catastrophe
//! simulation described in GAME_DESIGN_SECTION_3.md Section 3.2.

use crate::catastrophe;
use crate::{DeterministicRng, SimContext, SimError, SimSystem, ValidationErrors};
use glam::Vec3;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use tracing::{debug, info};

/// The catastrophe simulation system.
///
/// This system implements the catastrophe simulation described in
/// GAME_DESIGN_SECTION_3.md Section 3.2. It generalizes the weather
/// simulation to handle all seven catastrophe types and produces
/// deterministic catastrophe events.
#[derive(Serialize, Deserialize)]
pub struct CatastropheSystem {
    /// The next unique ID for catastrophe events.
    next_event_id: u64,
    /// The next unique ID for precursor signals.
    next_signal_id: u64,
    /// Active catastrophe events that are currently propagating or have recently occurred.
    pub active_events: Vec<catastrophe::CatastropheEvent>,
    /// Pending precursor signals that have been emitted but not yet processed.
    pub pending_signals: Vec<catastrophe::PrecursorSignal>,
    /// Cooldown periods for each catastrophe type to prevent spamming.
    /// Maps CatastropheType to the next tick when it can trigger.
    cooldowns: BTreeMap<catastrophe::CatastropheType, u64>,
    /// The current wind direction in radians.
    pub wind_direction: f32,
}

impl Default for CatastropheSystem {
    fn default() -> Self {
        Self::new()
    }
}

impl CatastropheSystem {
    /// Creates a new CatastropheSystem with default settings.
    pub fn new() -> Self {
        Self {
            next_event_id: 0,
            next_signal_id: 0,
            active_events: Vec::new(),
            pending_signals: Vec::new(),
            cooldowns: BTreeMap::new(),
            wind_direction: 0.0,
        }
    }

    /// Creates a new catastrophe event ID.
    pub fn next_event_id(&mut self) -> u64 {
        let id = self.next_event_id;
        self.next_event_id += 1;
        id
    }

    /// Creates a new signal ID.
    pub fn next_signal_id(&mut self) -> u64 {
        let id = self.next_signal_id;
        self.next_signal_id += 1;
        id
    }

    /// Checks if a catastrophe type is on cooldown.
    pub fn is_on_cooldown(&self, catastrophe_type: catastrophe::CatastropheType, current_tick: u64) -> bool {
        self.cooldowns
            .get(&catastrophe_type)
            .map(|&cooldown_tick| current_tick < cooldown_tick)
            .unwrap_or(false)
    }

    /// Sets a cooldown for a catastrophe type.
    pub fn set_cooldown(&mut self, catastrophe_type: catastrophe::CatastropheType, until_tick: u64) {
        self.cooldowns.insert(catastrophe_type, until_tick);
    }

    /// Generates precursor signals for an impending catastrophe.
    ///
    /// This method creates deterministic precursor signals based on the
    /// catastrophe type and the time until it triggers.
    pub fn generate_precursor_signals(
        &mut self,
        catastrophe_type: catastrophe::CatastropheType,
        trigger_tick: u64,
        current_tick: u64,
    ) {
        let ticks_until = trigger_tick.saturating_sub(current_tick);
        if ticks_until == 0 {
            return;
        }

        // Get typical signals for this catastrophe type
        let typical = catastrophe::signal::typical_signals(catastrophe_type);

        // Emit signals at different points in the countdown
        // For determinism, we use a simple pattern: emit one signal per typical signal
        // at a deterministic tick offset
        for (i, &(signal_kind, description)) in typical.iter().enumerate() {
            // Emit signal when we're about halfway through the countdown
            // (but not too close to the trigger)
            let emit_offset = ((ticks_until / 2) as f32 * (i as f32 + 1.0) / typical.len() as f32) as u64;
            let ticks_until_at_emit = ticks_until - emit_offset.min(ticks_until - 1);

            if current_tick + emit_offset <= trigger_tick {
                let intensity = if ticks_until_at_emit == 0 {
                    1.0
                } else {
                    1.0 - (ticks_until_at_emit as f32 / ticks_until as f32).powf(0.5)
                };

                let signal = catastrophe::PrecursorSignal::new(
                    self.next_signal_id(),
                    signal_kind,
                    intensity.clamp(0.0, 1.0),
                    description.to_string(),
                    catastrophe_type,
                    current_tick,
                    ticks_until_at_emit,
                );
                self.pending_signals.push(signal);
            }
        }
    }

    /// Triggers a new catastrophe event.
    ///
    /// This method creates a new catastrophe event with deterministic
    /// properties based on the RNG state.
    pub fn trigger_catastrophe(
        &mut self,
        catastrophe_type: catastrophe::CatastropheType,
        epicentre: Vec3,
        magnitude: f32,
        radius: f32,
        trigger_tick: u64,
    ) -> catastrophe::CatastropheEvent {
        let event = catastrophe::CatastropheEvent::new(
            self.next_event_id(),
            catastrophe_type,
            magnitude,
            radius,
            catastrophe::Epicentre::new(epicentre),
            trigger_tick,
        );

        // Propagate immediately for now (in a real implementation,
        // this would happen over multiple ticks)
        let mut rng = DeterministicRng::new(0); // Placeholder
        let prop = catastrophe::propagation::SpatialPropagation::new();
        // Create closures from WorldEnv data (Wave 4 will populate with real terrain data)
        // For now, use default values since the maps are empty
        let terrain_height_fn = |_pos: Vec3| -> f32 { 
            // Default to 0.0; Wave 4 will query from env.terrain_heights
            0.0 
        };
        let vegetation_density_fn = |_pos: Vec3| -> f32 { 
            // Default to 0.5; Wave 4 will query from env.vegetation_densities
            0.5 
        };
        let propagated = prop.propagate(
            event,
            &mut rng,
            terrain_height_fn,
            self.wind_direction,
            vegetation_density_fn,
        );

        self.active_events.push(propagated.clone());
        propagated
    }

    /// Attempts to trigger a catastrophe based on weather conditions and deterministic timing.
    ///
    /// Uses weather state from the world runtime to influence which catastrophe types
    /// are eligible to trigger, and uses the deterministic RNG to select among eligible
    /// types. This ensures that same seed → same tick → same catastrophe outcome.
    fn try_trigger_random_catastrophe(
        &mut self,
        ctx: &mut SimContext,
        current_tick: u64,
    ) -> Option<(catastrophe::CatastropheType, u64)> {
        // Get weather state from world runtime
        let temperature = ctx.world.weather.temperature;
        let humidity = ctx.world.weather.humidity;
        let pressure = ctx.world.weather.pressure;
        let wind_speed = ctx.world.weather.wind_speed;
        let accumulated_precipitation = ctx.world.weather.accumulated_precipitation;

        // Check each catastrophe type for eligibility based on weather conditions
        // Returns (catastrophe_type, countdown_ticks, eligibility_score) for eligible types
        let mut candidates: Vec<(catastrophe::CatastropheType, u64, f32)> = Vec::new();

        for &catastrophe_type in catastrophe::CatastropheType::all() {
            if self.is_on_cooldown(catastrophe_type, current_tick) {
                continue;
            }

            // Check weather conditions for this catastrophe type
            // Returns (countdown, eligibility_score) where score > 0 means eligible
            let (countdown, eligibility) = match catastrophe_type {
                catastrophe::CatastropheType::Flood => {
                    // Flood: triggered by high precipitation and rising water levels
                    let mut score = 0.0;
                    if accumulated_precipitation > 10.0 {
                        score += 0.5;
                    }
                    if humidity > 0.7 {
                        score += 0.5;
                    }
                    (50u64, score)
                }
                catastrophe::CatastropheType::Earthquake => {
                    // Earthquake: not directly weather-related, but can be triggered
                    // by pressure changes (barometric pressure drop before quakes)
                    let score = if pressure < 1000.0 { 0.3 } else { 0.0 };
                    (30u64, score)
                }
                catastrophe::CatastropheType::Wildfire => {
                    // Wildfire: triggered by dry conditions, low humidity, high temperature, high wind
                    let mut score = 0.0;
                    if temperature > 25.0 {
                        score += 0.4;
                    }
                    if humidity < 0.4 {
                        score += 0.4;
                    }
                    if wind_speed > 3.0 {
                        score += 0.2;
                    }
                    (40u64, score)
                }
                catastrophe::CatastropheType::Blizzard => {
                    // Blizzard: triggered by low temperature, high wind, and precipitation (snow)
                    let mut score = 0.0;
                    if temperature < 0.0 {
                        score += 0.4;
                    }
                    if wind_speed > 8.0 {
                        score += 0.4;
                    }
                    if humidity > 0.7 {
                        score += 0.2;
                    }
                    (60u64, score)
                }
                catastrophe::CatastropheType::Drought => {
                    // Drought: triggered by prolonged dry conditions
                    let mut score = 0.0;
                    if accumulated_precipitation < 1.0 {
                        score += 0.5;
                    }
                    if humidity < 0.3 {
                        score += 0.3;
                    }
                    if temperature > 20.0 {
                        score += 0.2;
                    }
                    (200u64, score) // Long countdown for drought
                }
                catastrophe::CatastropheType::Landslide => {
                    // Landslide: triggered by heavy rain (high accumulated precipitation)
                    // followed by temperature drop or pressure change
                    let mut score = 0.0;
                    if accumulated_precipitation > 15.0 {
                        score += 0.6;
                    }
                    if temperature < 5.0 || pressure < 1005.0 {
                        score += 0.4;
                    }
                    (25u64, score)
                }
                catastrophe::CatastropheType::Blight => {
                    // Blight: triggered by warm, humid conditions (ideal for fungal growth)
                    let mut score = 0.0;
                    if temperature > 15.0 && temperature < 30.0 {
                        score += 0.5;
                    }
                    if humidity > 0.65 {
                        score += 0.5;
                    }
                    (80u64, score)
                }
            };

            if eligibility > 0.0 {
                candidates.push((catastrophe_type, countdown, eligibility));
            }
        }

        if candidates.is_empty() {
            return None;
        }

        // Use deterministic RNG to select among candidates
        // This ensures same seed → same selection
        let mut local_rng = DeterministicRng::new(ctx.rng.state);

        // Calculate total eligibility
        let total_eligibility: f32 = candidates.iter().map(|&(_, _, el)| el).sum();

        // Generate a random value in [0, total_eligibility)
        let selection = local_rng.next_f32() * total_eligibility;

        // Select the candidate based on weighted eligibility
        let mut cumulative = 0.0f32;
        for &(catastrophe_type, countdown, eligibility) in &candidates {
            cumulative += eligibility;
            if selection < cumulative {
                // Set a cooldown to prevent immediate re-triggering
                // Cooldown is based on catastrophe severity
                let cooldown_ticks = match catastrophe_type {
                    catastrophe::CatastropheType::Flood => 500,
                    catastrophe::CatastropheType::Earthquake => 1000,
                    catastrophe::CatastropheType::Wildfire => 700,
                    catastrophe::CatastropheType::Blizzard => 800,
                    catastrophe::CatastropheType::Drought => 2000, // Long cooldown for drought
                    catastrophe::CatastropheType::Landslide => 400,
                    catastrophe::CatastropheType::Blight => 1500,
                };
                self.set_cooldown(catastrophe_type, current_tick + cooldown_ticks);

                return Some((catastrophe_type, countdown));
            }
        }

        // Fallback: select first candidate (shouldn't reach here due to floating point)
        // But if we do, use the first candidate
        if !candidates.is_empty() {
            let (catastrophe_type, countdown, _) = candidates[0];
            let cooldown_ticks = match catastrophe_type {
                catastrophe::CatastropheType::Flood => 500,
                catastrophe::CatastropheType::Earthquake => 1000,
                catastrophe::CatastropheType::Wildfire => 700,
                catastrophe::CatastropheType::Blizzard => 800,
                catastrophe::CatastropheType::Drought => 2000,
                catastrophe::CatastropheType::Landslide => 400,
                catastrophe::CatastropheType::Blight => 1500,
            };
            self.set_cooldown(catastrophe_type, current_tick + cooldown_ticks);

            return Some((catastrophe_type, countdown));
        }

        None
    }
}

impl SimSystem for CatastropheSystem {
    fn name(&self) -> &'static str {
        "catastrophe_system"
    }

    fn priority(&self) -> u32 {
        // High priority - catastrophes should be processed early
        // so other systems can react to them
        100
    }

    #[tracing::instrument(skip(self, ctx), fields(tick = ctx.tick))]
    fn tick(&mut self, ctx: &mut SimContext) -> Result<(), SimError> {
        let current_tick = ctx.tick;

        // Try to trigger a new catastrophe based on weather conditions
        if let Some((catastrophe_type, countdown_ticks)) = self.try_trigger_random_catastrophe(ctx, current_tick) {
            // Determine trigger tick based on countdown
            let trigger_tick = current_tick + countdown_ticks;

            // Generate precursor signals during the countdown period
            self.generate_precursor_signals(catastrophe_type, trigger_tick, current_tick);

            // Use deterministic RNG to generate epicentre position
            // This ensures same seed → same epicentre for same conditions
            let x = ctx.rng.next_f32_range(-500.0, 500.0);
            let z = ctx.rng.next_f32_range(-500.0, 500.0);
            let epicentre = Vec3::new(x, 0.0, z);

            // Magnitude varies deterministically based on weather intensity
            // Use weather factors to influence magnitude
            let weather_intensity = ctx.world.weather.humidity + ctx.world.weather.wind_speed / 10.0;
            let magnitude_base = ctx.rng.next_f32() * 0.7 + 0.3;
            let magnitude = (magnitude_base + weather_intensity * 0.3).clamp(0.1, 1.0);

            // Radius also influenced by weather and RNG
            let radius_base = ctx.rng.next_f32_range(20.0, 60.0);
            let radius = radius_base + ctx.world.weather.wind_speed * 2.0 + ctx.world.weather.accumulated_precipitation * 0.5;

            // Trigger the catastrophe immediately (the countdown was for tension/precursors)
            let event = self.trigger_catastrophe(
                catastrophe_type,
                epicentre,
                magnitude,
                radius.clamp(10.0, 100.0),
                trigger_tick,
            );

            // Emit tracing event for catastrophe trigger
            info!(
                target: "catastrophe",
                catastrophe_triggered = true,
                catastrophe_type = ?catastrophe_type,
                magnitude = magnitude,
                radius = radius.clamp(10.0, 100.0),
                epicentre_x = epicentre.x,
                epicentre_z = epicentre.z,
                tick = current_tick,
                "Catastrophe triggered"
            );

            debug!(
                target: "catastrophe",
                event_id = event.id,
                "Catastrophe event created"
            );

            // Emit the event as a SimEvent (for now, we'll use a custom event type)
            // In a full implementation, we'd have a CatastropheSimEvent variant
        }

        // Process pending signals - emit them to events_out
        // Convert precursor signals to SimEvents for other systems to consume
        for _signal in self.pending_signals.drain(..) {
            // In a full implementation, we'd push these as SimEvent variants
            // For now, we just track them in the system
        }

        Ok(())
    }

    fn validate(&self) -> ValidationErrors {
        let errors: ValidationErrors = Vec::new();

        // Validate that all active events have valid magnitudes
        for event in &self.active_events {
            if event.magnitude < 0.0 || event.magnitude > 2.0 {
                // In a full implementation, we'd use push_validation_error!
                // For now, we just collect simple errors
            }
        }

        errors
    }

    fn snapshot(&self) -> Option<Vec<u8>> {
        serde_json::to_vec(self).ok()
    }

    fn restore(&mut self, bytes: &[u8]) -> Result<(), SimError> {
        *self = serde_json::from_slice(bytes)
            .map_err(|e| SimError::InvalidSnapshot(format!("Failed to deserialize CatastropheSystem: {}", e)))?;
        Ok(())
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn std::any::Any {
        self
    }
}
