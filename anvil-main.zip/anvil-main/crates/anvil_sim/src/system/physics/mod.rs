//! Physics simulation system using Rapier3D.
//!
//! This module provides the `PhysicsSystem` which integrates Rapier3D physics
//! into the deterministic simulation layer. It manages rigid bodies, colliders,
//! and physics stepping with a fixed time step for determinism.

use bincode::{deserialize, serialize};
use crate::{SimContext, SimError, SimSystem, ValidationErrors};
use glam::Vec3;
use rapier3d::dynamics::{BodyStatus, CCDSolver, IntegrationParameters, JointSet, RigidBodyBuilder, RigidBodyHandle, RigidBodySet};
use rapier3d::geometry::{BroadPhase, ColliderBuilder, ColliderHandle, ColliderSet, NarrowPhase};
use rapier3d::math::Vector;
use rapier3d::pipeline::{EventHandler, PhysicsHooks, PhysicsPipeline};

use super::physics_save::{EntityHandle, FIXED_PHYSICS_STEP, PhysicsSaveState, RegionColliderMap};

/// Maximum number of physics substeps per simulation tick.
/// This prevents spiral of death from accumulating too much dt.
const MAX_SUBSTEPS: u32 = 4;

/// The physics simulation system.
///
/// Manages Rapier3D physics world including rigid bodies, colliders,
/// and deterministic physics stepping. This system lives in the
/// deterministic simulation layer and must not depend on any Bevy
/// or rendering code.
pub struct PhysicsSystem {
    /// The set of rigid bodies in the physics world.
    pub rigid_body_set: RigidBodySet,
    /// The set of colliders in the physics world.
    pub collider_set: ColliderSet,
    /// The set of joints in the physics world.
    joint_set: JointSet,
    /// The physics pipeline for collision detection and resolution.
    physics_pipeline: PhysicsPipeline,
    /// Gravity vector for the physics world (m/s^2).
    pub gravity: Vector<f32>,
    /// Integration parameters for the physics simulation.
    integration_parameters: IntegrationParameters,
    /// Broad phase for collision detection.
    broad_phase: BroadPhase,
    /// Narrow phase for collision resolution.
    narrow_phase: NarrowPhase,
    /// CCD solver for continuous collision detection.
    ccd_solver: CCDSolver,
    /// Accumulated time that needs to be simulated (in seconds).
    pub accumulated_time: f32,
    /// Handle to the player entity in the physics world.
    pub player_handle: Option<EntityHandle>,
    /// Mapping from region IDs to their terrain collider handles.
    pub region_colliders: RegionColliderMap,
    /// The ground plane rigid body and collider handles.
    pub ground_body_handle: Option<RigidBodyHandle>,
    /// The ground plane collider handle.
    pub ground_collider_handle: Option<ColliderHandle>,
}

impl Default for PhysicsSystem {
    fn default() -> Self {
        Self::new()
    }
}

impl PhysicsSystem {
    /// Creates a new `PhysicsSystem` with default settings.
    pub fn new() -> Self {
        let mut rigid_body_set = RigidBodySet::new();
        let mut collider_set = ColliderSet::new();

        // Create static rigid body for ground
        let ground_body = RigidBodyBuilder::new(BodyStatus::Static)
            .translation(0.0, -0.1, 0.0)
            .build();
        let ground_body_handle = rigid_body_set.insert(ground_body);

        // Create ground plane collider attached to the ground body
        let ground_collider = ColliderBuilder::cuboid(1000.0, 0.1, 1000.0)
            .build();
        let ground_collider_handle = collider_set.insert(ground_collider, ground_body_handle, &mut rigid_body_set);

        // Configure integration parameters for determinism
        let integration_parameters = IntegrationParameters {
            dt: FIXED_PHYSICS_STEP,
            ..Default::default()
        };

        Self {
            rigid_body_set,
            collider_set,
            joint_set: JointSet::new(),
            physics_pipeline: PhysicsPipeline::new(),
            gravity: Vector::new(0.0, -9.81, 0.0),
            integration_parameters,
            broad_phase: BroadPhase::new(),
            narrow_phase: NarrowPhase::new(),
            ccd_solver: CCDSolver::new(),
            accumulated_time: 0.0,
            player_handle: None,
            region_colliders: RegionColliderMap::new(),
            ground_body_handle: Some(ground_body_handle),
            ground_collider_handle: Some(ground_collider_handle),
        }
    }

    /// Creates the player physics entity and returns its handle.
    ///
    /// The player is a dynamic rigid body with a capsule collider that
    /// responds to gravity. This should be called once during initialization.
    ///
    /// # Returns
    /// The `EntityHandle` for the player entity.
    pub fn create_player(&mut self, position: Vec3, radius: f32, height: f32) -> EntityHandle {
        // Create capsule collider for player (capsule approximated as cylinder + spheres)
        // For simplicity, we use a cuboid as a placeholder; real capsule support
        // requires heightfield or compound collider
        let player_collider = ColliderBuilder::capsule_y(height / 2.0 - radius, radius)
            .translation(position.x, position.y, position.z)
            .build();

        // Create dynamic rigid body for player
        let player_body = RigidBodyBuilder::new(BodyStatus::Dynamic)
            .translation(position.x, position.y, position.z)
            .build();

        // Insert body first, then collider attached to it
        let body_handle = self.rigid_body_set.insert(player_body);
        let collider_handle = self.collider_set.insert(player_collider, body_handle, &mut self.rigid_body_set);

        let handle = EntityHandle::new(body_handle, collider_handle);
        self.player_handle = Some(handle);
        handle
    }

    /// Returns the player's current position, if the player exists.
    pub fn player_position(&self) -> Option<Vec3> {
        self.player_handle.and_then(|handle| {
            self.rigid_body_set.get(handle.rigid_body_handle).map(|body| {
                let pos = body.position();
                Vec3::new(pos.translation.x, pos.translation.y, pos.translation.z)
            })
        })
    }

    /// Returns the player's current linear velocity, if the player exists.
    pub fn player_velocity(&self) -> Option<Vec3> {
        self.player_handle.and_then(|handle| {
            self.rigid_body_set.get(handle.rigid_body_handle).map(|body| {
                let vel = body.linvel();
                Vec3::new(vel.x, vel.y, vel.z)
            })
        })
    }

    /// Creates terrain colliders for a region.
    ///
    /// For each loaded region, this generates static colliders from terrain
    /// height data. Currently creates a simple cuboid collider as a placeholder
    /// for the region's terrain. In a full implementation, this would sample
    /// the terrain height at grid points and create HeightField colliders.
    ///
    /// # Arguments
    /// * `region_id` - The ID of the region to create colliders for.
    /// * `size` - The size of the region in world units (width, depth).
    /// * `height` - The height of the terrain in world units.
    /// * `position` - The world position of the region's center.
    ///
    /// # Returns
    /// The list of collider handles created for this region.
    pub fn create_terrain_colliders(
        &mut self,
        region_id: u64,
        size: Vec3,
        height: f32,
        position: Vec3,
    ) -> Vec<ColliderHandle> {
        // Create a static rigid body for the terrain
        let terrain_body = RigidBodyBuilder::new(BodyStatus::Static)
            .translation(position.x, position.y, position.z)
            .build();
        let body_handle = self.rigid_body_set.insert(terrain_body);

        // Create a cuboid collider for the terrain (placeholder for heightfield)
        let terrain_collider = ColliderBuilder::cuboid(size.x / 2.0, height / 2.0, size.z / 2.0)
            .build();
        let collider_handle = self.collider_set.insert(terrain_collider, body_handle, &mut self.rigid_body_set);

        // Store the mapping from region ID to collider handles
        self.region_colliders.insert(region_id, vec![collider_handle]);

        vec![collider_handle]
    }

    /// Removes terrain colliders for a region.
    ///
    /// # Arguments
    /// * `region_id` - The ID of the region to remove colliders for.
    pub fn remove_terrain_colliders(&mut self, region_id: u64) {
        if let Some(handles) = self.region_colliders.remove(&region_id) {
            for handle in handles {
                self.collider_set.remove(handle, &mut self.rigid_body_set, true);
            }
        }
    }

    /// Applies earthquake physics effects.
    ///
    /// Creates temporary impulse forces on dynamic bodies within the affected area.
    /// The impulse magnitude is proportional to the catastrophe magnitude.
    ///
    /// # Arguments
    /// * `epicentre` - The world position of the earthquake epicentre.
    /// * `radius` - The radius of the affected area in world units.
    /// * `magnitude` - The magnitude of the earthquake (0.0 to 1.0+).
    pub fn apply_earthquake(&mut self, epicentre: Vec3, radius: f32, magnitude: f32) {
        let radius_squared = radius * radius;

        for (handle, body) in self.rigid_body_set.iter_mut() {
            // Only affect dynamic bodies
            if body.body_status() != BodyStatus::Dynamic {
                continue;
            }

            let pos = body.position().translation;
            let dx = pos.x - epicentre.x;
            let dy = pos.y - epicentre.y;
            let dz = pos.z - epicentre.z;
            let distance_squared = dx * dx + dy * dy + dz * dz;

            // Check if body is within the affected area
            if distance_squared > radius_squared {
                continue;
            }

            // Calculate impulse direction (away from epicentre, with some randomness)
            // For determinism, we use a simple hash-based pseudo-random direction
            let seed = handle.into_raw_parts().0 as u64;
            let mut rng_state = seed;
            // Simple deterministic pseudo-random for direction
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            let rand_x = (rng_state >> 33) as f32 / (1u64 << 31) as f32 * 2.0 - 1.0;
            rng_state = rng_state.wrapping_mul(6364136223846793005).wrapping_add(1);
            let rand_z = (rng_state >> 33) as f32 / (1u64 << 31) as f32 * 2.0 - 1.0;

            // Scale impulse by magnitude and inverse distance
            let distance = distance_squared.sqrt();
            let falloff = if distance > 0.0 { 1.0 - distance / radius } else { 1.0 };
            let impulse_scale = magnitude * falloff * 10.0; // Arbitrary scale factor

            // Apply impulse
            let impulse = Vector::new(rand_x * impulse_scale, 0.0, rand_z * impulse_scale);
            body.apply_impulse(impulse, true);
        }
    }

    /// Applies landslide physics effects.
    ///
    /// Creates kinematic bodies that move along slope vectors, pushing dynamic
    /// bodies on contact. The slope direction is determined by the epicentre.
    ///
    /// # Arguments
    /// * `epicentre` - The world position of the landslide origin.
    /// * `radius` - The radius of the affected area in world units.
    /// * `magnitude` - The magnitude of the landslide (0.0 to 1.0+).
    /// * `slope_direction` - The direction of the slope (normalized vector).
    ///
    /// # Returns
    /// The handles of the created landslide bodies.
    pub fn apply_landslide(
        &mut self,
        epicentre: Vec3,
        radius: f32,
        magnitude: f32,
        slope_direction: Vec3,
    ) -> Vec<RigidBodyHandle> {
        let mut handles = Vec::new();

        // Create a kinematic body for the landslide mass
        // This will push dynamic bodies as it moves
        let landslide_body = RigidBodyBuilder::new(BodyStatus::Kinematic)
            .translation(epicentre.x, epicentre.y, epicentre.z)
            .linvel(slope_direction.x * magnitude * 5.0, slope_direction.y * magnitude * 5.0, slope_direction.z * magnitude * 5.0)
            .build();

        let body_handle = self.rigid_body_set.insert(landslide_body);

        // Create a collider for the landslide mass
        let landslide_collider = ColliderBuilder::cuboid(radius, 2.0, radius)
            .build();
        let _collider_handle = self.collider_set.insert(landslide_collider, body_handle, &mut self.rigid_body_set);

        handles.push(body_handle);
        handles
    }

    /// Cleans up catastrophe physics bodies.
    ///
    /// Removes kinematic bodies created for landslides and other temporary effects.
    /// Also removes their associated colliders.
    ///
    /// # Arguments
    /// * `body_handles` - The handles of the bodies to remove.
    pub fn cleanup_catastrophe_bodies(&mut self, body_handles: Vec<RigidBodyHandle>) {
        for handle in body_handles {
            self.rigid_body_set.remove(handle, &mut self.collider_set, &mut self.joint_set);
        }
    }

    /// Advances the physics simulation by a fixed time step.
    ///
    /// This method accumulates dt and steps the physics in fixed increments
    /// for determinism. It uses a semi-fixed timestep approach where
    /// the simulation accumulates time and steps in FIXED_PHYSICS_STEP
    /// increments.
    ///
    /// # Arguments
    /// * `dt` - The delta time in seconds to advance.
    pub fn step(&mut self, dt: f32) {
        self.accumulated_time += dt;

        let mut steps_taken = 0;
        while self.accumulated_time >= FIXED_PHYSICS_STEP && steps_taken < MAX_SUBSTEPS {
            // Update the integration parameters dt for this step
            self.integration_parameters.dt = FIXED_PHYSICS_STEP;

            // Create default hooks and event handler - empty tuples implement the traits
            let hooks: &dyn PhysicsHooks = &();
            let events: &dyn EventHandler = &();

            self.physics_pipeline.step(
                &self.gravity,
                &self.integration_parameters,
                &mut self.broad_phase,
                &mut self.narrow_phase,
                &mut self.rigid_body_set,
                &mut self.collider_set,
                &mut self.joint_set,
                &mut self.ccd_solver,
                hooks,
                events,
            );
            self.accumulated_time -= FIXED_PHYSICS_STEP;
            steps_taken += 1;
        }
    }

    /// Returns the current gravity vector.
    pub fn gravity(&self) -> Vec3 {
        Vec3::new(self.gravity.x, self.gravity.y, self.gravity.z)
    }

    /// Returns the accumulated time.
    pub fn accumulated_time(&self) -> f32 {
        self.accumulated_time
    }

    /// Sets the gravity vector.
    pub fn set_gravity(&mut self, gravity: Vec3) {
        self.gravity = Vector::new(gravity.x, gravity.y, gravity.z);
    }

    /// Sets the accumulated time.
    pub fn set_accumulated_time(&mut self, time: f32) {
        self.accumulated_time = time;
    }

    /// Converts the physics system state to a save state.
    pub fn to_save_state(&self) -> super::physics_save::PhysicsSaveState {
        use super::physics_save::{ColliderSaveState, RigidBodySaveState};
        
        let rigid_bodies: Vec<RigidBodySaveState> = self
            .rigid_body_set
            .iter()
            .map(|(handle, body)| RigidBodySaveState::from_rigid_body(handle, body))
            .collect();

        let colliders: Vec<ColliderSaveState> = self
            .collider_set
            .iter()
            .map(|(handle, collider)| ColliderSaveState::from_collider(handle, collider))
            .collect();

        super::physics_save::PhysicsSaveState {
            physics_version: 1,
            gravity: [self.gravity.x, self.gravity.y, self.gravity.z],
            accumulated_time: self.accumulated_time,
            fixed_physics_step: FIXED_PHYSICS_STEP,
            rigid_bodies,
            colliders,
            region_colliders: self.region_colliders.clone(),
            player_handle: self.player_handle,
            ground_body_handle: self.ground_body_handle,
            ground_collider_handle: self.ground_collider_handle,
        }
    }

    /// Returns the handle to the player entity, if created.
    pub fn player_handle(&self) -> Option<EntityHandle> {
        self.player_handle
    }

    /// Returns the ground body handle.
    pub fn ground_body_handle(&self) -> Option<RigidBodyHandle> {
        self.ground_body_handle
    }

    /// Returns the ground collider handle.
    pub fn ground_collider_handle(&self) -> Option<ColliderHandle> {
        self.ground_collider_handle
    }

    /// Returns a reference to the rigid body set.
    pub fn rigid_body_set(&self) -> &RigidBodySet {
        &self.rigid_body_set
    }

    /// Returns a mutable reference to the rigid body set.
    pub fn rigid_body_set_mut(&mut self) -> &mut RigidBodySet {
        &mut self.rigid_body_set
    }

    /// Returns a reference to the collider set.
    pub fn collider_set(&self) -> &ColliderSet {
        &self.collider_set
    }

    /// Returns a mutable reference to the collider set.
    pub fn collider_set_mut(&mut self) -> &mut ColliderSet {
        &mut self.collider_set
    }

    /// Returns a reference to the region collider mapping.
    pub fn region_colliders(&self) -> &RegionColliderMap {
        &self.region_colliders
    }

    /// Returns a mutable reference to the region collider mapping.
    pub fn region_colliders_mut(&mut self) -> &mut RegionColliderMap {
        &mut self.region_colliders
    }

    /// Converts dt from microseconds to seconds.
    pub fn dt_micros_to_seconds(dt_micros: u64) -> f32 {
        dt_micros as f32 / 1_000_000.0
    }
}

mod sim_system;
