#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_physics_system_creation() {
        let system = PhysicsSystem::new();
        assert_eq!(system.name(), "PhysicsSystem");
        assert_eq!(system.priority(), 1);
        assert!(system.ground_body_handle.is_some());
        assert!(system.ground_collider_handle.is_some());
        assert!(!system.rigid_body_set().is_empty());
        assert!(!system.collider_set().is_empty());
    }

    #[test]
    fn test_physics_system_step() {
        let mut system = PhysicsSystem::new();
        let initial_body_count = system.rigid_body_set().len();
        let initial_collider_count = system.collider_set().len();

        // Step the physics
        system.step(1.0 / 60.0);

        // Counts should remain the same (no bodies added/removed)
        assert_eq!(system.rigid_body_set().len(), initial_body_count);
        assert_eq!(system.collider_set().len(), initial_collider_count);
    }

    #[test]
    fn test_dt_conversion() {
        assert!((PhysicsSystem::dt_micros_to_seconds(1_000_000) - 1.0).abs() < 0.0001);
        assert!((PhysicsSystem::dt_micros_to_seconds(500_000) - 0.5).abs() < 0.0001);
    }

    #[test]
    fn test_physics_system_validation() {
        let system = PhysicsSystem::new();
        let errors = system.validate();
        // A newly created system should have no validation errors
        assert!(errors.is_empty());
    }

    #[test]
    fn test_accumulated_time_handling() {
        let mut system = PhysicsSystem::new();

        // Step with less than FIXED_PHYSICS_STEP
        system.step(0.01);
        assert!(system.accumulated_time > 0.0);
        assert!(system.accumulated_time < FIXED_PHYSICS_STEP);

        // Step with exactly FIXED_PHYSICS_STEP
        let remaining = FIXED_PHYSICS_STEP - system.accumulated_time;
        system.step(remaining);
        assert!(system.accumulated_time.abs() < 0.0001);
    }

    #[test]
    fn test_player_creation() {
        let mut system = PhysicsSystem::new();
        assert!(system.player_handle().is_none());

        // Create player at position (0, 5, 0) with radius 0.5 and height 1.8
        let handle = system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);

        assert!(system.player_handle().is_some());
        assert_eq!(system.player_handle(), Some(handle));

        // Check player position
        let position = system.player_position().unwrap();
        assert!(position.x.abs() < 0.0001);
        assert!((position.y - 5.0).abs() < 0.0001);
        assert!(position.z.abs() < 0.0001);

        // Body count should have increased
        assert!(system.rigid_body_set().len() > 1);
        assert!(system.collider_set().len() > 1);
    }

    #[test]
    fn test_player_velocity_initial_zero() {
        let mut system = PhysicsSystem::new();
        system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);

        // Player should start with zero velocity
        let velocity = system.player_velocity().unwrap();
        assert!(velocity.x.abs() < 0.0001);
        assert!(velocity.y.abs() < 0.0001);
        assert!(velocity.z.abs() < 0.0001);
    }

    #[test]
    fn test_player_falls_under_gravity() {
        let mut system = PhysicsSystem::new();
        system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);

        // Simulate a few steps
        for _ in 0..10 {
            system.step(FIXED_PHYSICS_STEP);
        }

        // Player should have fallen due to gravity
        let position = system.player_position().unwrap();
        assert!(position.y < 5.0);

        // Player should have downward velocity
        let velocity = system.player_velocity().unwrap();
        assert!(velocity.y < 0.0);
    }

    #[test]
    fn test_terrain_collider_creation() {
        let mut system = PhysicsSystem::new();
        let initial_body_count = system.rigid_body_set().len();
        let initial_collider_count = system.collider_set().len();

        // Create terrain colliders for region 1
        let handles = system.create_terrain_colliders(1, Vec3::new(100.0, 20.0, 100.0), 10.0, Vec3::new(0.0, -5.0, 0.0));

        assert_eq!(handles.len(), 1);
        assert!(system.region_colliders().contains_key(&1));
        assert_eq!(system.rigid_body_set().len(), initial_body_count + 1);
        assert_eq!(system.collider_set().len(), initial_collider_count + 1);
    }

    #[test]
    fn test_terrain_collider_removal() {
        let mut system = PhysicsSystem::new();
        let initial_collider_count = system.collider_set().len();

        // Create and then remove terrain colliders
        system.create_terrain_colliders(1, Vec3::new(100.0, 20.0, 100.0), 10.0, Vec3::new(0.0, -5.0, 0.0));
        system.remove_terrain_colliders(1);

        assert!(!system.region_colliders().contains_key(&1));
        // Collider count should be back to initial
        assert_eq!(system.collider_set().len(), initial_collider_count);
    }

    #[test]
    fn test_player_stands_on_terrain() {
        let mut system = PhysicsSystem::new();

        // Create terrain at y = -5 with height 10 (so top is at y = 0)
        // cuboid with height 10 centered at y = -5 extends from y = -10 to y = 0
        system.create_terrain_colliders(1, Vec3::new(1000.0, 10.0, 1000.0), 10.0, Vec3::new(0.0, -5.0, 0.0));

        // Create player above the terrain (at y = 10)
        system.create_player(Vec3::new(0.0, 10.0, 0.0), 0.5, 1.8);

        // Simulate until player hits terrain
        for _ in 0..60 {
            system.step(FIXED_PHYSICS_STEP);
        }

        // Player should have hit the terrain and stopped falling
        // The terrain top is at y = 0, player capsule has radius 0.5
        // So player center should be at approximately y = 0 + 0.5 = 0.5
        // But we also have the player body itself which may add some offset
        let position = system.player_position().unwrap();
        // Just check that player hasn't fallen through the terrain (y < -10)
        assert!(position.y > -10.0);
    }

    #[test]
    fn test_snapshot_write() {
        use crate::SimSnapshot;

        // Create a minimal system and verify write doesn't panic
        let system = PhysicsSystem::new();
        let mut snapshot_data = Vec::new();
        system.write(&mut snapshot_data);
        assert!(!snapshot_data.is_empty());
    }

    #[test]
    fn test_snapshot_read() {
        use crate::SimSnapshot;

        // Verify read doesn’t panic with valid data
        let system = PhysicsSystem::new();
        let mut snapshot_data = Vec::new();
        system.write(&mut snapshot_data);
        let restored = PhysicsSystem::read(&snapshot_data).unwrap();
        assert_eq!(restored.name(), "PhysicsSystem");
    }

    #[test]
    fn test_earthquake_applies_impulse() {
        let mut system = PhysicsSystem::new();

        // Create player
        system.create_player(Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);

        // Apply earthquake at origin with large radius
        system.apply_earthquake(Vec3::new(0.0, 0.0, 0.0), 100.0, 0.5);

        // Player should have non-zero velocity after impulse
        let velocity = system.player_velocity().unwrap();
        // The velocity should be non-zero (impulse was applied)
        assert!(velocity.x.abs() > 0.0001 || velocity.z.abs() > 0.0001);
    }

    #[test]
    fn test_landslide_creates_bodies() {
        let mut system = PhysicsSystem::new();
        let initial_body_count = system.rigid_body_set().len();

        // Apply landslide
        let handles = system.apply_landslide(
            Vec3::new(0.0, 5.0, 0.0),
            10.0,
            0.5,
            Vec3::new(0.0, -1.0, 0.0), // slope down in y direction
        );

        assert_eq!(handles.len(), 1);
        assert_eq!(system.rigid_body_set().len(), initial_body_count + 1);

        // Cleanup
        system.cleanup_catastrophe_bodies(handles);
        assert_eq!(system.rigid_body_set().len(), initial_body_count);
    }

    #[test]
    fn test_landslide_pushes_player() {
        let mut system = PhysicsSystem::new();

        // Create terrain for player to stand on
        system.create_terrain_colliders(1, Vec3::new(1000.0, 10.0, 1000.0), 10.0, Vec3::new(0.0, -5.0, 0.0));

        // Create player on terrain
        system.create_player(Vec3::new(0.0, 10.0, 0.0), 0.5, 1.8);

        // Let player settle
        for _ in 0..10 {
            system.step(FIXED_PHYSICS_STEP);
        }

        let initial_position = system.player_position().unwrap();

        // Apply landslide pushing in positive x direction
        system.apply_landslide(
            Vec3::new(-10.0, 0.0, 0.0),
            5.0,
            0.5,
            Vec3::new(1.0, 0.0, 0.0),
        );

        // Simulate a few steps
        for _ in 0..10 {
            system.step(FIXED_PHYSICS_STEP);
        }

        let new_position = system.player_position().unwrap();
        // Player should have been pushed in the x direction
        assert!(new_position.x > initial_position.x - 0.1);
    }
}
