use super::*;
impl SimSystem for PhysicsSystem {
    fn name(&self) -> &'static str {
        "PhysicsSystem"
    }

    fn priority(&self) -> u32 {
        // Physics should run early in the tick, before systems that depend on positions.
        // Lower priority number = earlier execution.
        1
    }

    #[tracing::instrument(skip(self, ctx), fields(tick = ctx.tick))]
    fn tick(&mut self, ctx: &mut SimContext) -> Result<(), SimError> {
        let dt_seconds = Self::dt_micros_to_seconds(ctx.dt_micros);
        self.step(dt_seconds);
        Ok(())
    }

    fn validate(&self) -> ValidationErrors {
        let errors: ValidationErrors = Vec::new();

        // Physics system validation is minimal for now.
        // In a full implementation, we would validate:
        // - Ground body and collider exist
        // - Rigid body and collider sets are consistent
        // - All bodies have valid positions

        errors
    }

    fn snapshot(&self) -> Option<Vec<u8>> {
        // Create save state from system fields
        let rigid_bodies: Vec<super::super::physics_save::RigidBodySaveState> = self
            .rigid_body_set
            .iter()
            .map(|(handle, body)| super::super::physics_save::RigidBodySaveState::from_rigid_body(handle, body))
            .collect();

        let colliders: Vec<super::super::physics_save::ColliderSaveState> = self
            .collider_set
            .iter()
            .map(|(handle, collider)| super::super::physics_save::ColliderSaveState::from_collider(handle, collider))
            .collect();

        let save_state = PhysicsSaveState {
            physics_version: 1,
            gravity: [self.gravity.x, self.gravity.y, self.gravity.z],
            accumulated_time: self.accumulated_time,
            fixed_physics_step: FIXED_PHYSICS_STEP,
            rigid_bodies,
            colliders,
            region_colliders: self.region_colliders.clone(),
            player_handle: self.player_handle,
            ground_body_handle: self.ground_body_handle,
            ground_collider_handle: self.ground_collider_handle,
        };

        serialize(&save_state).ok()
    }

    fn restore(&mut self, bytes: &[u8]) -> Result<(), SimError> {
        let save_state: PhysicsSaveState = deserialize(bytes)
            .map_err(|e| {
                SimError::InvalidSnapshot(format!("Failed to deserialize physics state: {}", e))
            })?;

        self.gravity = Vector::new(save_state.gravity[0], save_state.gravity[1], save_state.gravity[2]);
        self.accumulated_time = save_state.accumulated_time;

        // Rebuild rigid bodies and colliders from save state
        let mut body_handle_map: std::collections::HashMap<RigidBodyHandle, RigidBodyHandle> = std::collections::HashMap::new();
        let mut collider_handle_map: std::collections::HashMap<ColliderHandle, ColliderHandle> = std::collections::HashMap::new();

        for body_state in &save_state.rigid_bodies {
            let body = RigidBodyBuilder::new(body_state.body_status)
                .translation(body_state.position[0], body_state.position[1], body_state.position[2])
                .linvel(body_state.linvel[0], body_state.linvel[1], body_state.linvel[2])
                .angvel(Vector::new(
                    body_state.angvel[0],
                    body_state.angvel[1],
                    body_state.angvel[2],
                ))
                .build();
            let new_handle = self.rigid_body_set.insert(body);
            body_handle_map.insert(body_state.handle, new_handle);
        }

        for collider_state in &save_state.colliders {
            let parent_handle = collider_state.parent_handle.and_then(|h| body_handle_map.get(&h));

            let mut collider_builder: ColliderBuilder;
            if let Some(half_extents) = collider_state.cuboid_half_extents {
                collider_builder = ColliderBuilder::cuboid(half_extents[0], half_extents[1], half_extents[2]);
            } else if let Some(capsule_data) = collider_state.capsule_data {
                collider_builder = ColliderBuilder::capsule_y(capsule_data[1], capsule_data[0]);
            } else if let Some(radius) = collider_state.ball_radius {
                collider_builder = ColliderBuilder::ball(radius);
            } else {
                collider_builder = ColliderBuilder::cuboid(0.1, 0.1, 0.1);
            }

            collider_builder = collider_builder
                .sensor(collider_state.is_sensor)
                .translation(
                    collider_state.position_offset[0],
                    collider_state.position_offset[1],
                    collider_state.position_offset[2],
                );

            let collider = collider_builder.build();
            if let Some(parent) = parent_handle {
                let new_handle = self
                    .collider_set
                    .insert(collider, *parent, &mut self.rigid_body_set);
                collider_handle_map.insert(collider_state.handle, new_handle);
            }
        }

        if let Some(player_handle) = save_state.player_handle
            && let (Some(new_body), Some(new_collider)) = (
                body_handle_map.get(&player_handle.rigid_body_handle),
                collider_handle_map.get(&player_handle.collider_handle),
            )
        {
            self.player_handle = Some(EntityHandle::new(*new_body, *new_collider));
        }
        if let Some(handle) = save_state.ground_body_handle {
            self.ground_body_handle = body_handle_map.get(&handle).copied();
        }
        if let Some(handle) = save_state.ground_collider_handle {
            self.ground_collider_handle = collider_handle_map.get(&handle).copied();
        }
        for (region_id, handles) in save_state.region_colliders {
            let new_handles: Vec<ColliderHandle> = handles
                .into_iter()
                .filter_map(|h| collider_handle_map.get(&h).copied())
                .collect();
            if !new_handles.is_empty() {
                self.region_colliders.insert(region_id, new_handles);
            }
        }

        Ok(())
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn std::any::Any {
        self
    }
}

