//! Joy System - Triggers catalyst events when conditions for joy are met.
//!
//! Implements the joy triggering logic as defined in GAME_DESIGN_SECTION_3.md
//! Section 3.4.1. Emits CatalystEvent when both conditions are met:
//! 1. Sufficient collective mood (60-70% of NPCs have mood > +0.3)
//! 2. A trigger event occurs

use crate::settlement::{
    CatalystEvent, CatalystEventId, CatalystKind, Family, Person, Settlement, SettlementId,
};
use crate::{SimContext, SimError, SimEvent, SimSystem, ValidationErrors};
use anvil_core::error_buffer;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use tracing::{debug, info, warn};

/// Threshold for sufficient collective mood (60% = 0.6).
const MOOD_THRESHOLD: f32 = 0.6;

/// Minimum mood for an NPC to count toward the threshold.
const INDIVIDUAL_MOOD_THRESHOLD: f32 = 0.3;

/// Food store threshold for harvest trigger (70% = 0.7).
const HARVEST_FOOD_THRESHOLD: f32 = 0.7;

/// Structural integrity threshold for construction complete trigger.
const CONSTRUCTION_THRESHOLD: f32 = 1.0;

/// The JoySystem implements catalyst event triggering logic.
#[derive(Serialize, Deserialize)]
pub struct JoySystem {
    /// The settlements managed by this system.
    pub settlements: Vec<Settlement>,
    /// All persons in the simulation.
    pub persons: Vec<Person>,
    /// All families in the simulation.
    pub families: Vec<Family>,
    /// The next catalyst event ID to assign.
    pub next_catalyst_id: u64,
    /// Track the lowest recent aggregate mood for magnitude calculation.
    /// Maps settlement_id to (lowest_mood, tick_when_recorded).
    pub lowest_mood_tracking: BTreeMap<u64, (f32, u64)>,
    /// Track the most recent history event for each settlement.
    /// Maps settlement_id to history_event_id.
    pub recent_history_events: BTreeMap<u64, u64>,
    /// Food store levels from previous tick for harvest detection.
    pub previous_food_stores: BTreeMap<u64, f32>,
    /// Structural integrity from previous tick for construction detection.
    pub previous_structural_integrity: BTreeMap<u64, f32>,
    /// All catalyst events that have been triggered (Sprint 22 - Phase 3 gate).
    /// This allows determinism tests to verify catalyst event triggering.
    pub triggered_catalysts: Vec<CatalystEvent>,
}

impl JoySystem {
    /// Creates a new JoySystem with empty state.
    pub fn new() -> Self {
        Self {
            settlements: Vec::new(),
            persons: Vec::new(),
            families: Vec::new(),
            next_catalyst_id: 1,
            lowest_mood_tracking: BTreeMap::new(),
            recent_history_events: BTreeMap::new(),
            previous_food_stores: BTreeMap::new(),
            previous_structural_integrity: BTreeMap::new(),
            triggered_catalysts: Vec::new(),
        }
    }

    /// Adds a settlement to the system.
    pub fn add_settlement(&mut self, settlement: Settlement) {
        self.settlements.push(settlement);
    }

    /// Adds a person to the system.
    pub fn add_person(&mut self, person: Person) {
        self.persons.push(person);
    }

    /// Adds a family to the system.
    pub fn add_family(&mut self, family: Family) {
        self.families.push(family);
    }

    /// Records a history event (catastrophe) that affected a settlement.
    pub fn record_history_event(&mut self, settlement_id: SettlementId, event_id: u64) {
        self.recent_history_events
            .insert(settlement_id.get(), event_id);
    }

    /// Gets persons belonging to a specific settlement.
    fn get_settlement_persons(&self, _settlement_id: SettlementId) -> Vec<&Person> {
        // For now, we assume all persons belong to the settlement.
        // In a more complete implementation, persons would have a settlement_id field.
        // This is a simplification for Sprint 16.
        self.persons.iter().collect()
    }

    /// Checks if Condition 1 is met: sufficient collective mood.
    /// 60-70% of the settlement's NPCs must have individual mood > +0.3.
    pub fn check_condition_1(&self, settlement_id: SettlementId) -> bool {
        let persons = self.get_settlement_persons(settlement_id);
        if persons.is_empty() {
            return false;
        }

        let happy_count = persons
            .iter()
            .filter(|p| p.mood() > INDIVIDUAL_MOOD_THRESHOLD)
            .count();
        let happy_ratio = happy_count as f32 / persons.len() as f32;

        happy_ratio >= MOOD_THRESHOLD
    }

    /// Checks if Condition 2 is met: a trigger event has occurred.
    ///
    /// Returns the kind of trigger if one occurred, or None.
    pub fn check_condition_2(&self, ctx: &mut SimContext, settlement: &Settlement) -> Option<CatalystKind> {
        // Check for simulated trigger events

        // Birth: population increase (simulated by checking if we should trigger)
        // For now, we'll handle this via explicit trigger

        // Harvest: food_store crosses the sufficiency threshold
        let prev_food = self
            .previous_food_stores
            .get(&settlement.id.get())
            .copied()
            .unwrap_or(0.0);
        if prev_food < HARVEST_FOOD_THRESHOLD && settlement.food_store >= HARVEST_FOOD_THRESHOLD {
            return Some(CatalystKind::Harvest);
        }

        // Construction complete: structural_integrity returns to 1.0
        let prev_integrity = self
            .previous_structural_integrity
            .get(&settlement.id.get())
            .copied()
            .unwrap_or(1.0);
        if prev_integrity < CONSTRUCTION_THRESHOLD
            && settlement.structural_integrity >= CONSTRUCTION_THRESHOLD
        {
            return Some(CatalystKind::Construction);
        }

        // Season turn: check if season changed in runtime
        // For now, we'll use a deterministic check based on tick
        // In a full implementation, this would come from anvil_runtime's time system
        if ctx.tick.is_multiple_of(1000) && ctx.tick > 0 {
            return Some(CatalystKind::SeasonTurn);
        }

        // Return: NPC who was missing comes back
        // For now, we'll handle this via explicit trigger

        // Birth: explicit trigger
        // For now, we'll handle this via explicit trigger

        None
    }

    /// Triggers a catalyst event for a settlement.
    /// Returns the catalyst event that was triggered.
    pub fn trigger_catalyst(
        &mut self,
        ctx: &mut SimContext,
        settlement: &Settlement,
        kind: CatalystKind,
        trigger_npc: Option<Person>,
    ) -> CatalystEvent {
        // Compute magnitude inline
        let settlement_id = settlement.id.get();
        let magnitude = if let Some((lowest_mood, _)) = self.lowest_mood_tracking.get(&settlement_id) {
            (settlement.aggregate_mood - lowest_mood).clamp(0.0, 1.0)
        } else {
            settlement.aggregate_mood.clamp(0.0, 1.0)
        };

        let linked_history = self
            .recent_history_events
            .get(&settlement_id)
            .copied();

        let trigger_npc_id = trigger_npc.map(|p| p.id);

        let catalyst = CatalystEvent::new(
            CatalystEventId::new(self.next_catalyst_id),
            kind,
            ctx.tick,
            settlement.id,
            trigger_npc_id,
            linked_history,
            magnitude,
        );

        self.next_catalyst_id += 1;

        // Store the triggered catalyst for determinism testing (Sprint 22)
        self.triggered_catalysts.push(catalyst.clone());

        // Also update the lowest mood tracking
        // After a catalyst, we reset the tracking to current mood
        self.lowest_mood_tracking
            .insert(settlement_id, (settlement.aggregate_mood, ctx.tick));

        catalyst
    }

    /// Explicitly triggers a birth catalyst for testing.
    pub fn trigger_birth(&mut self, ctx: &mut SimContext, settlement_id: SettlementId, parent: Person) {
        if let Some(settlement) = self
            .settlements
            .iter()
            .find(|s| s.id == settlement_id)
            .cloned()
            && self.check_condition_1(settlement_id)
        {
            self.trigger_catalyst(ctx, &settlement, CatalystKind::Birth, Some(parent));
        }
    }

    /// Explicitly triggers a return catalyst for testing.
    pub fn trigger_return(&mut self, ctx: &mut SimContext, settlement_id: SettlementId, returnee: Person) {
        if let Some(settlement) = self
            .settlements
            .iter()
            .find(|s| s.id == settlement_id)
            .cloned()
            && self.check_condition_1(settlement_id)
        {
            self.trigger_catalyst(ctx, &settlement, CatalystKind::Return, Some(returnee));
        }
    }
}

impl SimSystem for JoySystem {
    fn name(&self) -> &'static str {
        "joy_system"
    }

    fn priority(&self) -> u32 {
        // Joy system runs after catastrophe system (priority 100)
        // to allow it to respond to catastrophes
        50
    }

    #[tracing::instrument(skip(self, ctx), fields(tick = ctx.tick))]
    fn tick(&mut self, ctx: &mut SimContext) -> Result<(), SimError> {
        // Process action completed events for catalyst triggering
        for event in ctx.events_in {
            if let SimEvent::ActionCompleted {
                person_id,
                action_id: _,
                outcome,
            } = event
            {
                // Track action outcomes for potential catalyst triggers
                // For now, just log the event
                debug!(
                    target: "joy",
                    person_id,
                    outcome = format!("{}", outcome),
                    "Action completed"
                );
            }
        }

        // Store previous state for trigger detection
        for settlement in &self.settlements {
            let sid = settlement.id.get();
            let prev_food = self.previous_food_stores.get(&sid).copied().unwrap_or(0.5);
            let prev_integrity = self.previous_structural_integrity.get(&sid).copied().unwrap_or(1.0);
            
            // Check for resource pool threshold crossings
            if settlement.food_store > 0.5 && prev_food <= 0.5 {
                info!(
                    target: "joy",
                    settlement_id = sid,
                    food_store = settlement.food_store,
                    threshold = 0.5,
                    tick = ctx.tick,
                    "Food store crossed 0.5 threshold (high)"
                );
            } else if settlement.food_store > 0.2 && prev_food <= 0.2 {
                info!(
                    target: "joy",
                    settlement_id = sid,
                    food_store = settlement.food_store,
                    threshold = 0.2,
                    tick = ctx.tick,
                    "Food store crossed 0.2 threshold (medium)"
                );
            } else if settlement.food_store <= 0.2 && prev_food > 0.2 {
                warn!(
                    target: "joy",
                    settlement_id = sid,
                    food_store = settlement.food_store,
                    threshold = 0.2,
                    tick = ctx.tick,
                    "Food store crossed 0.2 threshold (low)"
                );
            }
            
            if settlement.structural_integrity > 0.9 && prev_integrity <= 0.9 {
                info!(
                    target: "joy",
                    settlement_id = sid,
                    structural_integrity = settlement.structural_integrity,
                    threshold = 0.9,
                    tick = ctx.tick,
                    "Structural integrity crossed 0.9 threshold"
                );
            } else if settlement.structural_integrity <= 0.1 && prev_integrity > 0.1 {
                warn!(
                    target: "joy",
                    settlement_id = sid,
                    structural_integrity = settlement.structural_integrity,
                    threshold = 0.1,
                    tick = ctx.tick,
                    "Structural integrity crossed 0.1 threshold (critical)"
                );
            }
            
            self.previous_food_stores
                .insert(sid, settlement.food_store);
            self.previous_structural_integrity
                .insert(sid, settlement.structural_integrity);
        }

        // Process each settlement by index to avoid borrow issues
        for i in 0..self.settlements.len() {
            let settlement = &self.settlements[i];
            let settlement_id = settlement.id.get();
            let current_mood = settlement.aggregate_mood;

            // Update lowest mood tracking (inlined to avoid borrow issues)
            if let Some((lowest_mood, _)) = self.lowest_mood_tracking.get_mut(&settlement_id) {
                if current_mood < *lowest_mood {
                    *lowest_mood = current_mood;
                }
            } else {
                self.lowest_mood_tracking.insert(settlement_id, (current_mood, 0));
            }

            // Check both conditions
            let cond1 = self.check_condition_1(settlement.id);
            let cond2 = self.check_condition_2(ctx, settlement);

            if cond1 && cond2.is_some() {
                // Both conditions met - trigger catalyst (inlined to avoid borrow issues)
                if let Some(kind) = cond2 {
                    // Compute magnitude
                    let magnitude = if let Some((lowest_mood, _)) = self.lowest_mood_tracking.get(&settlement_id) {
                        (settlement.aggregate_mood - lowest_mood).clamp(0.0, 1.0)
                    } else {
                        settlement.aggregate_mood.clamp(0.0, 1.0)
                    };

                    let linked_history = self.recent_history_events.get(&settlement_id).copied();

                    // Emit tracing event for catalyst before creating the event
                    info!(
                        target: "joy",
                        catalyst_triggered = true,
                        catalyst_kind = ?kind,
                        settlement_id = settlement_id,
                        magnitude = magnitude,
                        tick = ctx.tick,
                        "Catalyst triggered"
                    );

                    debug!(
                        target: "joy",
                        catalyst_id = self.next_catalyst_id,
                        "Catalyst event created"
                    );

                    let catalyst = CatalystEvent::new(
                        CatalystEventId::new(self.next_catalyst_id),
                        kind,
                        ctx.tick,
                        settlement.id,
                        None,
                        linked_history,
                        magnitude,
                    );

                    // Store the triggered catalyst for determinism testing (Sprint 22)
                    self.triggered_catalysts.push(catalyst.clone());

                    self.next_catalyst_id += 1;
                    self.lowest_mood_tracking.insert(settlement_id, (settlement.aggregate_mood, ctx.tick));
                }
            }
        }

        Ok(())
    }

    fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        // Validate settlements
        for settlement in &self.settlements {
            errors.extend(settlement.validate());
        }

        // Validate persons
        for person in &self.persons {
            errors.extend(person.validate());
        }

        // Validate families
        for family in &self.families {
            errors.extend(family.validate());
        }

        errors
    }

    fn snapshot(&self) -> Option<Vec<u8>> {
        serde_json::to_vec(self).ok()
    }

    fn restore(&mut self, bytes: &[u8]) -> Result<(), SimError> {
        *self = serde_json::from_slice(bytes)
            .map_err(|e| SimError::InvalidSnapshot(format!("Failed to deserialize JoySystem: {}", e)))?;
        Ok(())
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn std::any::Any {
        self
    }
}

impl Default for JoySystem {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::age::Age;
    use crate::settlement::{FamilyId, PersonId, SettlementId};
    use crate::skill::SkillProfile;
    use crate::soul::{EmotionalState, Substrate};
    use crate::{DeterministicRng, SimContext, WorldEnv, WorldRuntime};
    use anvil_world::WorldAuthored;


    fn create_test_person_with_mood(id: u64, name: &str, family_id: u64, mood: f32) -> Person {
        use glam::Vec3;
        Person::new(
            PersonId::new(id),
            name.to_string(),
            FamilyId::new(family_id),
            Age::from_years(20.0),
            Substrate::neutral(),
            EmotionalState::from_mood(mood),
            vec![],
            vec![],
            vec![],
            SkillProfile::new(),
            None,
            0,
            0,
            0,
            0.5,
            Vec3::ZERO,
        )
    }

    #[test]
    fn test_joy_system_creation() {
        let system = JoySystem::new();
        assert_eq!(system.name(), "joy_system");
        assert_eq!(system.priority(), 50);
        assert!(system.validate().is_empty());
    }

    #[test]
    fn test_condition_1_sufficient_mood() {
        let mut system = JoySystem::new();

        // Create a settlement
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.8,  // food_store
            0.7,  // water
            0.3,  // materials
            0.9,  // structural_integrity
            0.0,  // aggregate_mood
            0.0,  // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement);

        // Add persons with moods - 7 out of 10 have mood > 0.3
        for i in 0..10 {
            let mood = if i < 7 { 0.5 } else { -0.5 };
            let person = create_test_person_with_mood(
                i as u64 + 1,
                &format!("Person {}", i),
                1,
                mood,
            );
            system.add_person(person);
        }

        // Condition 1 should be met (7/10 = 70% > 60%)
        assert!(system.check_condition_1(SettlementId::new(1)));
    }

    #[test]
    fn test_condition_1_insufficient_mood() {
        let mut system = JoySystem::new();

        // Create a settlement
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.8,  // food_store
            0.7,  // water
            0.3,  // materials
            0.9,  // structural_integrity
            0.0,  // aggregate_mood
            0.0,  // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement);

        // Add persons with moods - 5 out of 10 have mood > 0.3
        for i in 0..10 {
            let mood = if i < 5 { 0.5 } else { -0.5 };
            let person = create_test_person_with_mood(
                i as u64 + 1,
                &format!("Person {}", i),
                1,
                mood,
            );
            system.add_person(person);
        }

        // Condition 1 should NOT be met (5/10 = 50% < 60%)
        assert!(!system.check_condition_1(SettlementId::new(1)));
    }

    #[test]
    fn test_harvest_trigger() {
        let mut system = JoySystem::new();

        // Create a settlement with food below threshold
        let settlement_below = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.6, // Below harvest threshold (food_store)
            0.7, // water
            0.3, // materials
            0.5, // structural_integrity
            0.0, // aggregate_mood
            0.0, // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement_below);

        // Store previous state
        system.previous_food_stores.insert(1, 0.6);

        // Create a settlement with food above threshold
        let settlement_above = Settlement::new(
            SettlementId::new(2),
            "Harvestville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.8, // Above harvest threshold (food_store)
            0.7, // water
            0.3, // materials
            0.5, // structural_integrity
            0.0, // aggregate_mood
            0.0, // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement_above);

        // Store previous state below threshold
        system.previous_food_stores.insert(2, 0.6);

        // Create context for check_condition_2
        {
            let mut world = WorldRuntime::new(WorldAuthored::default());
            let mut rng = DeterministicRng::new(42);
            let events_in: Vec<crate::SimEvent> = Vec::new();
            let mut events_out: Vec<crate::SimEvent> = Vec::new();
            let world_env = WorldEnv::default();
            let mut ctx = SimContext::new(100, 1000, &mut rng, &mut world, &world_env, &events_in, &mut events_out);
            let trigger = system.check_condition_2(&mut ctx, &system.settlements[1]);
            assert_eq!(trigger, Some(CatalystKind::Harvest));
        }
    }

    #[test]
    fn test_magnitude_calculation() {
        let mut system = JoySystem::new();

        // Track lowest mood at -0.6
        system.lowest_mood_tracking.insert(1, (-0.6, 0));

        // Create settlement with current mood of 0.4
        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.8,  // food_store
            0.8,  // water
            0.8,  // materials
            0.9,  // structural_integrity
            0.4,  // aggregate_mood (current mood)
            0.0,  // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement);

        // Compute magnitude manually for test
        let settlement_id = system.settlements[0].id.get();
        let magnitude = if let Some((lowest_mood, _)) = system.lowest_mood_tracking.get(&settlement_id) {
            (system.settlements[0].aggregate_mood - lowest_mood).clamp(0.0, 1.0)
        } else {
            system.settlements[0].aggregate_mood.clamp(0.0, 1.0)
        };
        assert!((magnitude - 1.0).abs() < 0.001); // 0.4 - (-0.6) = 1.0
    }

    #[test]
    fn test_trigger_catalyst_updates_tracking() {
        let mut system = JoySystem::new();

        // Track lowest mood at -0.6
        system.lowest_mood_tracking.insert(1, (-0.6, 0));

        let settlement = Settlement::new(
            SettlementId::new(1),
            "Testville".to_string(),
            anvil_core::RegionId::new(0),
            10,
            0.8,  // food_store
            0.8,  // water
            0.8,  // materials
            0.9,  // structural_integrity
            0.4,  // aggregate_mood
            0.0,  // damage_level
            vec![],
            None,
        );
        system.add_settlement(settlement);

        let settlement_id = system.settlements[0].id.get();
        let settlement_clone = system.settlements[0].clone();
        {
            let mut world = WorldRuntime::new(WorldAuthored::default());
            let mut rng = DeterministicRng::new(42);
            let events_in: Vec<crate::SimEvent> = Vec::new();
            let mut events_out: Vec<crate::SimEvent> = Vec::new();
            let world_env = WorldEnv::default();
            let mut ctx = SimContext::new(100, 1000, &mut rng, &mut world, &world_env, &events_in, &mut events_out);
            system.trigger_catalyst(&mut ctx, &settlement_clone, CatalystKind::Harvest, None);
        }

        // After catalyst, lowest mood should be updated to current mood (0.4)
        let (lowest, _) = system.lowest_mood_tracking.get(&settlement_id).unwrap();
        assert!((lowest - 0.4).abs() < 0.001);
    }
}
