// anvil_streaming — asset streaming I/O trait.
//
// This module defines the contract for on-demand asset loading.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use std::path::Path;

/// An opaque handle to a streamed asset.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AssetHandle(u64);

impl AssetHandle {
    /// Create a new asset handle from a raw ID.
    pub fn new(id: u64) -> Self {
        Self(id)
    }

    /// Get the raw ID of this handle.
    pub fn id(&self) -> u64 {
        self.0
    }
}

/// Streams assets from storage into memory, returning handles that
/// the presentation layer can use.
pub trait AssetStreamer: Send + Sync {
    /// Request that the asset at `path` be loaded.
    /// Returns `Ok(handle)` on success, or an `std::io::Error` if the asset
    /// cannot be loaded (e.g., file not found, permission denied).
    fn load(&self, path: &Path) -> Result<AssetHandle, std::io::Error>;

    /// Evict assets that have not been accessed in `max_age_ticks` ticks.
    fn evict(&self, max_age_ticks: u64);

    /// Number of assets currently loaded.
    fn loaded_count(&self) -> usize;
}

#[cfg(test)]
mod tests {
    use super::*;

    // Mock streamer for testing
    struct MockStreamer;

    impl AssetStreamer for MockStreamer {
        fn load(&self, _path: &Path) -> Result<AssetHandle, std::io::Error> {
            Ok(AssetHandle::new(1))
        }

        fn evict(&self, _max_age_ticks: u64) {}

        fn loaded_count(&self) -> usize {
            0
        }
    }

    #[test]
    fn asset_handle_creation() {
        let h1 = AssetHandle::new(42);
        let h2 = AssetHandle::new(42);
        assert_eq!(h1, h2);
        assert_eq!(h1.id(), 42);
    }

    #[test]
    fn mock_streamer_implements_trait() {
        let streamer = MockStreamer;
        let handle = streamer.load(Path::new("/test/asset.glb")).unwrap();
        assert_eq!(handle.id(), 1);
        assert_eq!(streamer.loaded_count(), 0);
    }
}
