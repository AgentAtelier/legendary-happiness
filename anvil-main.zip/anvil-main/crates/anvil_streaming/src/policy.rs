// Ported from forge_bevy/src/world/streaming.rs as of the Forge snapshot.
// Foundation port — the scheduling logic generalises.

use crate::streamer::AssetStreamer;
use crate::{RegionScheduler, WorldPos};
use anvil_core::RegionId;
use anvil_runtime::RuntimeCommand;
use std::path::PathBuf;
use std::sync::Arc;

/// A simple distance‑based streaming policy: load regions within
/// `load_radius` and unload those beyond `unload_radius`.
pub struct SimplePolicy {
    /// Distance within which regions should be loaded.
    pub load_radius: f32,
    /// Distance beyond which regions should be unloaded.
    pub unload_radius: f32,
    /// Set of currently loaded regions.
    loaded: std::collections::HashSet<RegionId>,
    /// Optional asset streamer for loading region assets.
    asset_streamer: Option<Arc<dyn AssetStreamer>>,
    /// Track which assets belong to which regions for eviction.
    region_assets: std::collections::HashMap<RegionId, Vec<PathBuf>>,
}

impl std::fmt::Debug for SimplePolicy {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SimplePolicy")
            .field("load_radius", &self.load_radius)
            .field("unload_radius", &self.unload_radius)
            .field("loaded", &self.loaded)
            .field("asset_streamer", &"<dyn AssetStreamer>")
            .field("region_assets", &self.region_assets)
            .finish()
    }
}

impl Clone for SimplePolicy {
    fn clone(&self) -> Self {
        Self {
            load_radius: self.load_radius,
            unload_radius: self.unload_radius,
            loaded: self.loaded.clone(),
            // Arc can be cloned, preserving the streamer
            asset_streamer: self.asset_streamer.clone(),
            region_assets: self.region_assets.clone(),
        }
    }
}

impl SimplePolicy {
    /// Create a new simple policy with the given radii.
    pub fn new(load_radius: f32, unload_radius: f32) -> Self {
        Self {
            load_radius,
            unload_radius,
            loaded: std::collections::HashSet::new(),
            asset_streamer: None,
            region_assets: std::collections::HashMap::new(),
        }
    }

    /// Create a new simple policy with an asset streamer.
    pub fn with_streamer(load_radius: f32, unload_radius: f32, streamer: Arc<dyn AssetStreamer>) -> Self {
        Self {
            load_radius,
            unload_radius,
            loaded: std::collections::HashSet::new(),
            asset_streamer: Some(streamer),
            region_assets: std::collections::HashMap::new(),
        }
    }

    /// Get the set of currently loaded regions.
    pub fn loaded_regions(&self) -> &std::collections::HashSet<RegionId> {
        &self.loaded
    }

    /// Manually add a region to the loaded set.
    pub fn add_loaded_region(&mut self, region: RegionId) {
        self.loaded.insert(region);
    }

    /// Manually remove a region from the loaded set.
    pub fn remove_loaded_region(&mut self, region: RegionId) {
        self.loaded.remove(&region);
    }

    /// Register assets that belong to a region.
    /// When the region is loaded, these assets will be loaded.
    pub fn register_region_assets(&mut self, region: RegionId, asset_paths: Vec<PathBuf>) {
        self.region_assets.insert(region, asset_paths);
    }

    /// Get the asset paths for a region.
    pub fn get_region_assets(&self, region: RegionId) -> Option<&Vec<PathBuf>> {
        self.region_assets.get(&region)
    }

    /// Set the asset streamer.
    pub fn set_asset_streamer(&mut self, streamer: Arc<dyn AssetStreamer>) {
        self.asset_streamer = Some(streamer);
    }

    /// Get a reference to the asset streamer, if any.
    pub fn asset_streamer(&self) -> Option<&dyn AssetStreamer> {
        self.asset_streamer.as_deref()
    }
}

impl RegionScheduler for SimplePolicy {
    fn tick(&mut self, _player_pos: WorldPos) -> Vec<RuntimeCommand> {
        // Stub: in later sprints, this will compute distances to every
        // region and issue LoadRegion / UnloadRegion commands.
        // For now, if we have an asset streamer, we can demonstrate the
        // integration by loading assets for any newly added regions.

        // For any regions that were just added (simulated), load their assets
        let commands = Vec::new();

        if let Some(streamer) = &self.asset_streamer {
            // This is a stub - in a real implementation, we'd determine
            // which regions should be loaded based on player_pos and load_radius
            // For now, we just demonstrate that the streamer can be used
            for region in &self.loaded {
                if let Some(assets) = self.region_assets.get(region) {
                    for asset_path in assets {
                        let _ = streamer.load(asset_path);
                    }
                }
            }
        }

        commands
    }
}

impl Default for SimplePolicy {
    fn default() -> Self {
        Self::new(100.0, 150.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn simple_policy_starts_empty() {
        let policy = SimplePolicy::new(100.0, 150.0);
        assert!(policy.loaded_regions().is_empty());
    }

    #[test]
    fn simple_policy_tick_returns_empty_vec() {
        let mut policy = SimplePolicy::new(100.0, 150.0);
        let cmds = policy.tick(WorldPos { x: 0.0, y: 0.0, z: 0.0 });
        assert!(cmds.is_empty());
    }

    #[test]
    fn add_and_remove_loaded_regions() {
        use anvil_core::RegionId;
        let mut policy = SimplePolicy::new(100.0, 150.0);

        let r1 = RegionId::new(1);
        let r2 = RegionId::new(2);

        policy.add_loaded_region(r1);
        assert!(policy.loaded_regions().contains(&r1));
        assert!(!policy.loaded_regions().contains(&r2));

        policy.add_loaded_region(r2);
        assert!(policy.loaded_regions().contains(&r1));
        assert!(policy.loaded_regions().contains(&r2));

        policy.remove_loaded_region(r1);
        assert!(!policy.loaded_regions().contains(&r1));
        assert!(policy.loaded_regions().contains(&r2));
    }

    use crate::fs_streamer::FsAssetStreamer;
    use std::sync::Arc;

    #[test]
    fn default_policy_has_sensible_radius() {
        let policy = SimplePolicy::default();
        assert!(policy.load_radius > 0.0);
        assert!(policy.unload_radius > policy.load_radius);
    }

    #[test]
    fn clone_preserves_asset_streamer() {
        let streamer = Arc::new(FsAssetStreamer::new()) as Arc<dyn AssetStreamer>;
        let policy = SimplePolicy::with_streamer(100.0, 150.0, Arc::clone(&streamer));
        
        let cloned = policy.clone();
        
        // Both should have streamers
        assert!(policy.asset_streamer().is_some());
        assert!(cloned.asset_streamer().is_some());
        
        // They should point to the same underlying streamer
        let policy_streamer = policy.asset_streamer().unwrap();
        let cloned_streamer = cloned.asset_streamer().unwrap();
        
        // Check Arc pointer equality
        let policy_ptr: *const dyn AssetStreamer = policy_streamer as *const _;
        let cloned_ptr: *const dyn AssetStreamer = cloned_streamer as *const _;
        assert_eq!(policy_ptr, cloned_ptr);
    }
}
