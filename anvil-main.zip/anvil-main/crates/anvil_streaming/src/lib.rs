//! # anvil_streaming
//!
//! **Layer:** PRESENTATION
//!
//! **Purpose:** On-demand region loading and asset streaming. This crate provides
//! the async boundary between deterministic simulation and Bevy rendering.
//!
//! **Architecture:** This crate sits above `anvil_runtime` (which it wraps) and
//! below `anvil_bevy`. It is the only crate that may legitimately depend on async I/O
//! (Tokio). It contains no Bevy dependencies.
//!
//! **Relationship to anvil_runtime:** Wraps `Runtime` to provide streaming capabilities
//! while maintaining deterministic simulation integrity.

#![deny(warnings)]
#![deny(missing_docs)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

/// Streaming policy definitions.
pub mod policy;

/// Asset streaming trait and implementations.
pub mod streamer;

/// Filesystem-based asset streamer.
pub mod fs_streamer;

use anvil_runtime::RuntimeCommand;

pub use streamer::{AssetHandle, AssetStreamer};
pub use fs_streamer::FsAssetStreamer;
pub use policy::SimplePolicy;

/// A position in world space, used to decide which regions to load.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WorldPos {
    /// X coordinate in world space.
    pub x: f32,
    /// Y coordinate in world space.
    pub y: f32,
    /// Z coordinate in world space.
    pub z: f32,
}

/// Decides which regions should be loaded or unloaded based on the
/// player's current position.
pub trait RegionScheduler: Send + Sync {
    /// Called each tick to determine which regions to load/unload.
    /// Returns a vector of runtime commands to execute.
    fn tick(&mut self, player_pos: WorldPos) -> Vec<RuntimeCommand>;
}
