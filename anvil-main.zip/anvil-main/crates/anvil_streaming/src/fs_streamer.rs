// Source: forge_bevy/src/world/streaming.rs as of the Forge snapshot.
// Ported as foundation.

#![deny(warnings)]
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use crate::streamer::{AssetHandle, AssetStreamer};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use parking_lot::Mutex;

/// A filesystem-backed asset streamer that loads files on demand.
pub struct FsAssetStreamer {
    /// Map of loaded assets by handle.
    assets: Mutex<HashMap<AssetHandle, FsAssetEntry>>,
    /// Counter for generating unique handle IDs.
    next_handle: Mutex<u64>,
    /// The current simulation tick.
    current_tick: Mutex<u64>,
    /// Counter for tracking when to run eviction (every EVICT_INTERVAL ticks).
    evict_counter: Mutex<u64>,
    /// Maximum age in ticks before an asset is evicted.
    max_age_ticks: u64,
}

/// How often to run eviction (in ticks).
const EVICT_INTERVAL: u64 = 60;

/// Default maximum age for assets before eviction (in ticks).
const DEFAULT_MAX_AGE_TICKS: u64 = 120;

/// Internal entry for a loaded asset.
struct FsAssetEntry {
    /// The path from which this asset was loaded.
    #[allow(dead_code)]
    path: PathBuf,
    /// The raw bytes of the asset.
    #[allow(dead_code)]
    bytes: Vec<u8>,
    /// The last tick at which this asset was accessed.
    last_accessed_tick: u64,
}

impl FsAssetStreamer {
    /// Create a new filesystem asset streamer.
    pub fn new() -> Self {
        Self {
            assets: Mutex::new(HashMap::new()),
            next_handle: Mutex::new(1),
            current_tick: Mutex::new(0),
            evict_counter: Mutex::new(0),
            max_age_ticks: DEFAULT_MAX_AGE_TICKS,
        }
    }

    /// Create a new filesystem asset streamer with a custom max age.
    pub fn with_max_age(max_age_ticks: u64) -> Self {
        Self {
            assets: Mutex::new(HashMap::new()),
            next_handle: Mutex::new(1),
            current_tick: Mutex::new(0),
            evict_counter: Mutex::new(0),
            max_age_ticks,
        }
    }

    /// Set the current simulation tick and potentially trigger eviction.
    /// Call this once per simulation tick.
    pub fn set_tick(&mut self, tick: u64) {
        let mut current_tick = self.current_tick.lock();
        let mut evict_counter = self.evict_counter.lock();

        *current_tick = tick;
        *evict_counter += 1;

        // Run eviction every EVICT_INTERVAL ticks
        if *evict_counter >= EVICT_INTERVAL {
            *evict_counter = 0;
            self.evict(self.max_age_ticks);
        }
    }

    /// Read a file from disk.
    fn read_file(path: &Path) -> std::io::Result<Vec<u8>> {
        std::fs::read(path)
    }

    /// Get the current tick count from the streamer's perspective.
    /// This is exposed for testing and integration purposes.
    pub fn current_tick(&self) -> u64 {
        let current_tick = self.current_tick.lock();
        *current_tick
    }

    /// Mark an asset as accessed at the current tick.
    pub fn touch(&self, handle: AssetHandle) {
        let mut assets = self.assets.lock();
        if let Some(entry) = assets.get_mut(&handle) {
            entry.last_accessed_tick = self.current_tick();
        }
    }
}

impl AssetStreamer for FsAssetStreamer {
    fn load(&self, path: &Path) -> Result<AssetHandle, std::io::Error> {
        // Generate a new handle ID
        let mut next_handle = self.next_handle.lock();
        let handle = AssetHandle::new(*next_handle);
        *next_handle += 1;

        // Load the file - return error if file cannot be read
        let bytes = Self::read_file(path)?;
        let entry = FsAssetEntry {
            path: path.to_path_buf(),
            bytes,
            last_accessed_tick: self.current_tick(),
        };
        let mut assets = self.assets.lock();
        assets.insert(handle, entry);

        Ok(handle)
    }

    fn evict(&self, max_age_ticks: u64) {
        let current_tick = self.current_tick();
        let mut assets = self.assets.lock();

        // Collect handles to evict
        let to_evict: Vec<AssetHandle> = assets
            .iter()
            .filter(|(_, entry)| {
                current_tick.saturating_sub(entry.last_accessed_tick) >= max_age_ticks
            })
            .map(|(handle, _)| *handle)
            .collect();

        // Remove evicted assets
        for handle in to_evict {
            assets.remove(&handle);
        }
    }

    fn loaded_count(&self) -> usize {
        let assets = self.assets.lock();
        assets.len()
    }
}

impl Default for FsAssetStreamer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    #[test]
    fn new_streamer_is_empty() {
        let streamer = FsAssetStreamer::new();
        assert_eq!(streamer.loaded_count(), 0);
    }

    #[test]
    fn load_creates_new_handle() {
        let streamer = FsAssetStreamer::new();
        // These paths don't exist, so load should return Err
        let result1 = streamer.load(Path::new("/nonexistent/file1.txt"));
        let result2 = streamer.load(Path::new("/nonexistent/file2.txt"));

        assert!(result1.is_err());
        assert!(result2.is_err());
        // Handles are only created on success, so count should be 0
        assert_eq!(streamer.loaded_count(), 0);
    }

    #[test]
    fn evict_removes_old_assets() {
        let streamer = FsAssetStreamer::new();

        // Load some assets - these will fail since paths don't exist
        let _h1 = streamer.load(Path::new("/nonexistent/a.txt"));
        let _h2 = streamer.load(Path::new("/nonexistent/b.txt"));

        // Both loads failed, so no handles were created
        assert_eq!(streamer.loaded_count(), 0);

        // Evict with max_age_ticks = 0 (everything is old)
        streamer.evict(0);

        assert_eq!(streamer.loaded_count(), 0);
    }

    #[test]
    fn evict_preserves_recent_assets() {
        let streamer = FsAssetStreamer::new();

        // Load an asset - this will fail since path doesn't exist
        let h1 = streamer.load(Path::new("/nonexistent/a.txt"));
        assert!(h1.is_err());
        // Since load failed, no handle was created
        assert_eq!(streamer.loaded_count(), 0);
    }

    #[test]
    fn default_streamer() {
        let streamer = FsAssetStreamer::default();
        assert_eq!(streamer.loaded_count(), 0);
    }
}
