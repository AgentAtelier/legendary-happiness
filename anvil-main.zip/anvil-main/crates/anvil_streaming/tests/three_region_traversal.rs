use anvil_core::RegionId;
use anvil_streaming::fs_streamer::FsAssetStreamer;
use anvil_streaming::policy::SimplePolicy;
use anvil_streaming::{RegionScheduler, WorldPos};
use std::path::PathBuf;
use std::sync::Arc;

#[test]
fn simple_policy_starts_empty() {
    let mut policy = SimplePolicy::new(100.0, 150.0);
    let cmds = policy.tick(WorldPos { x: 0.0, y: 0.0, z: 0.0 });
    assert!(cmds.is_empty());
}

#[test]
fn policy_with_streamer_loads_region_assets() {
    let streamer = Arc::new(FsAssetStreamer::new());
    let mut policy = SimplePolicy::with_streamer(100.0, 150.0, streamer);

    // Register some assets for a region
    let region = RegionId::new(1);
    let assets = vec![
        PathBuf::from("/test/mesh.glb"),
        PathBuf::from("/test/texture.png"),
    ];
    policy.register_region_assets(region, assets);

    // Add the region to loaded set
    policy.add_loaded_region(region);

    // Tick should load the assets
    let cmds = policy.tick(WorldPos { x: 0.0, y: 0.0, z: 0.0 });

    // Commands should be empty (stub implementation)
    assert!(cmds.is_empty());

    // The streamer's load will fail for nonexistent paths, so no handles are created
    // In a real implementation with actual files, we'd verify asset handles were created
    assert_eq!(policy.asset_streamer().unwrap().loaded_count(), 0);
}

#[test]
fn policy_evicts_assets() {
    let streamer = Arc::new(FsAssetStreamer::new());
    let policy = SimplePolicy::with_streamer(100.0, 150.0, streamer);

    // Load some assets - these will fail since paths don't exist
    let _h1 = policy.asset_streamer().unwrap().load(PathBuf::from("/nonexistent/a.txt").as_path());
    let _h2 = policy.asset_streamer().unwrap().load(PathBuf::from("/nonexistent/b.txt").as_path());

    // Both loads failed, so no handles were created
    assert_eq!(policy.asset_streamer().unwrap().loaded_count(), 0);

    // Evict with max_age_ticks = 0
    policy.asset_streamer().unwrap().evict(0);

    assert_eq!(policy.asset_streamer().unwrap().loaded_count(), 0);
}
