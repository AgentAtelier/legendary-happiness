use anvil_streaming::{AssetStreamer, FsAssetStreamer};
use criterion::{black_box, Criterion, criterion_group, criterion_main};

fn stream_1k(c: &mut Criterion) {
    // Create 1,000 tiny temp files
    let dir = tempfile::tempdir().unwrap();
    for i in 0..1000 {
        std::fs::write(dir.path().join(format!("asset_{i}.bin")), b"data").unwrap();
    }

    let streamer = FsAssetStreamer::new();

    c.bench_function("load_1k", |b| {
        b.iter(|| {
            for i in 0..1000 {
                let path = dir.path().join(format!("asset_{i}.bin"));
                let _ = streamer.load(black_box(&path));
            }
        })
    });
}

criterion_group!(benches, stream_1k);
criterion_main!(benches);
