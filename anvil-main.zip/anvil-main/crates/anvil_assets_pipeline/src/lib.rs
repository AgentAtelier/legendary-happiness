//! # anvil_assets_pipeline
//!
//! **Layer:** PIPELINE
//!
//! **Purpose:** Asset pipeline processing for external asset sources (FBX files).
//!
//! **Pipeline Stages:**
//! The pipeline processes assets through seven sequential stages:
//! 1. **FBX parse** — Parse raw FBX file data
//! 2. **pilot** — Extract metadata and structure
//! 3. **staging** — Prepare assets for eligibility checking
//! 4. **eligibility** — Determine if assets meet inclusion criteria
//! 5. **normalisation** — Standardize asset data formats
//! 6. **sidecar** — Generate companion metadata files
//! 7. **payload** — Create final asset payloads for ingestion
//!
//! **Key Trait:** [`PipelineManifest`] — defines the contract for pipeline implementations.

#![deny(warnings)]
#![deny(missing_docs)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

// Re-export the pipeline trait and error type
/// Pipeline manifest trait and error types.
pub mod pipeline;
pub use pipeline::{ManifestError, PipelineManifest};

// Vendor abstraction
/// Vendor trait for asset sources.
pub mod vendor;
/// Concrete vendor implementations.
pub mod vendors;
pub use vendor::Vendor;
pub use vendors::naturemanufacture::NatureManufactureVendor;

// External pipeline stages
/// FBX file parsing.
pub mod fbx;
/// Pilot manifest generation.
pub mod pilot;
/// Staging record preparation.
pub mod staging;
/// External pilot manifest handling.
pub mod external_pilot;
/// Eligibility classification.
pub mod eligibility;
/// External eligibility handling.
pub mod external_eligibility;
/// External staging.
pub mod external_staging;
/// Normalization processing.
pub mod normalization;
/// External normalization.
pub mod external_normalization;
/// Sidecar metadata generation.
pub mod sidecar;
/// External material sidecar generation.
pub mod external_material_sidecar;
/// Payload generation.
pub mod payload;
/// External texture payload handling.
pub mod external_texture_payload;

// Re-export the commonly used types from external_pilot
pub use external_pilot::{
    ExternalAssetFamily, ExternalAssetPackIdentity, ExternalAssetPilotManifest,
    ExternalAssetRegistration, ExternalAssetRegistrationBuilder,
    ExternalAssetSourceKind, ExternalAssetSourceRef, PackIdentityError, Provenance,
};
// Re-export the commonly used types from eligibility
pub use eligibility::{
    DefaultEligibilityClassifier, EligibilityClassifier, EligibilityStatus,
    ExternalAssetMaterialClass, ExternalAssetNormalizationEligibilityManifest,
    ExternalAssetNormalizedOutputKind, ExternalAssetSourceModelFormat,
    ExternalAssetTextureSetCompleteness, validate_eligibility_classifications,
};
// Re-export the commonly used types from external_staging
pub use external_staging::{
    ExternalAssetNormalizationStageManifest, StageAction, StagingRecordBuilder,
    validate_normalized_output_path,
};
// Re-export the commonly used types from normalization
pub use normalization::{
    BatchCompositionPolicy, BatchValidationErrors, DefaultBatchCompositionPolicy, NormalizedGlb,
    ExternalAssetNormalizationBatchManifest, ExternalAssetNormalizationExecutionManifest,
    ExternalAssetNormalizationExecutionRecord, ExternalAssetNormalizationExecutionStatus,
    NormalizationStageError,
    write_glb_to_writer,
};
// Re-export the commonly used types from sidecar
pub use sidecar::{
    ExternalAssetMaterialChannelSemantic, ExternalAssetMaterialSidecarManifest,
    ExternalAssetMaterialSidecarReport, MaterialSlotBindingBuilder,
};
// Re-export the commonly used types from payload
pub use payload::{
    ExternalAssetTexturePayloadReport, TexturePayloadRecordBuilder, output_texture_path,
};
// Re-export the commonly used types from fbx
pub use fbx::{
    convert_fbx_to_glb_bytes, inspect_fbx_source, ExternalFbxConversionError,
};

/// Prefix for external normalized output paths.
/// All normalized assets from the NatureManufacture vendor are stored under this path.
pub const EXTERNAL_NORMALIZED_OUTPUT_PREFIX: &str =
    "assets/external_normalized/naturemanufacture/";
