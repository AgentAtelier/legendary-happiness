//! Vendor trait abstraction for external asset pack providers.
//!
//! The Vendor trait abstracts over external asset pack providers.
//! NatureManufacture is the first implementation. Adding a second
//! vendor requires implementing this trait — no pipeline code changes.

use anvil_assets::AssetCategory;
use crate::external_eligibility::ExternalAssetMaterialClass;
use crate::pilot::ExternalAssetFamily;

/// Configuration for a single external asset vendor.
///
/// Implement this trait to add support for a new external asset provider.
pub trait Vendor: Send + Sync {
    /// Returns a stable identifier for this vendor, e.g. "naturemanufacture".
    fn id(&self) -> &'static str;

    /// Returns the path to the root of the vendor's extracted source files.
    fn source_root(&self) -> &'static str;

    /// Map a family name string to an `ExternalAssetFamily` variant.
    /// Returns `None` if the family is not provided by this vendor.
    fn resolve_family(&self, family_str: &str) -> Option<ExternalAssetFamily>;

    /// Returns the directory within the vendor root where source FBX files
    /// for a given family live (e.g. "models/trees").
    fn source_directory(&self, family: ExternalAssetFamily) -> &'static str;

    /// Returns the directory suffix for normalized output (e.g. "trees").
    fn output_directory(&self, family: ExternalAssetFamily) -> &'static str;

    /// Returns the default material class for eligibility classification.
    fn default_material_class(&self, family: ExternalAssetFamily) -> ExternalAssetMaterialClass;

    /// Returns whether assets of this family normally require an alpha cutout.
    fn alpha_cutout_required(&self, family: ExternalAssetFamily) -> bool;

    /// Returns the asset category for catalogue entries.
    fn asset_category(&self, family: ExternalAssetFamily) -> AssetCategory;
}
