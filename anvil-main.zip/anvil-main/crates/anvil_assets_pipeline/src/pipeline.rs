//! Pipeline manifest trait and shared error type for external
//! asset normalization.

use crate::ExternalAssetPackIdentity;
use anvil_core::ArchetypeTag;
use std::path::PathBuf;
use thiserror::Error;

/// Common error variants shared by all pipeline manifests.
#[derive(Debug, Error)]
pub enum ManifestError<S: std::error::Error + 'static> {
    /// An I/O error occurred while reading or writing manifest files.
    #[error("i/o error: {0}")]
    Io(std::io::Error),
    /// A JSON parsing error occurred.
    #[error("json parse error: {0}")]
    Parse(serde_json::Error),
    /// The manifest contains no records.
    #[error("manifest has no records")]
    EmptyManifest,
    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id: {0:?}")]
    DuplicateId(ArchetypeTag),
    /// Records are not sorted deterministically.
    #[error("manifest records are not deterministically ordered")]
    Unsorted,
    /// A required field is empty or whitespace-only.
    #[error("field '{0}' must not be blank")]
    BlankField(&'static str),
    /// The source manifest file was not found.
    #[error("source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),
    /// An error occurred while parsing or validating the pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(crate::external_pilot::PackIdentityError),
    /// A validation error from anvil_core.
    #[error("validation error: {0}")]
    ValidationError(anvil_core::AnvilCoreError),
    /// The source pack does not match the expected authority.
    #[error("source pack does not match authority")]
    SourcePackMismatch,
    /// A stage-specific error.
    #[error("{0}")]
    StageSpecific(S),
}

// Manual From implementations
impl<S: std::error::Error + 'static> From<std::io::Error> for ManifestError<S> {
    fn from(err: std::io::Error) -> Self {
        Self::Io(err)
    }
}

impl<S: std::error::Error + 'static> From<serde_json::Error> for ManifestError<S> {
    fn from(err: serde_json::Error) -> Self {
        Self::Parse(err)
    }
}

impl<S: std::error::Error + 'static> From<crate::external_pilot::PackIdentityError>
    for ManifestError<S>
{
    fn from(err: crate::external_pilot::PackIdentityError) -> Self {
        Self::PackIdentity(err)
    }
}

impl<S: std::error::Error + 'static> From<anvil_core::AnvilCoreError>
    for ManifestError<S>
{
    fn from(err: anvil_core::AnvilCoreError) -> Self {
        Self::ValidationError(err)
    }
}

// Manual PartialEq for ManifestError (io::Error and serde_json::Error use string comparison)
impl<S: std::error::Error + PartialEq + 'static> PartialEq for ManifestError<S> {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Io(a), Self::Io(b)) => a.to_string() == b.to_string(),
            (Self::Parse(a), Self::Parse(b)) => a.to_string() == b.to_string(),
            (Self::EmptyManifest, Self::EmptyManifest) => true,
            (Self::DuplicateId(a), Self::DuplicateId(b)) => a == b,
            (Self::Unsorted, Self::Unsorted) => true,
            (Self::BlankField(a), Self::BlankField(b)) => a == b,
            (Self::MissingSourceManifest(a), Self::MissingSourceManifest(b)) => a == b,
            (Self::PackIdentity(a), Self::PackIdentity(b)) => a == b,
            (Self::ValidationError(a), Self::ValidationError(b)) => a == b,
            (Self::SourcePackMismatch, Self::SourcePackMismatch) => true,
            (Self::StageSpecific(a), Self::StageSpecific(b)) => a == b,
            _ => false,
        }
    }
}

/// A pipeline manifest that can be loaded from a JSON file and structurally validated.
///
/// All pipeline manifests must implement this trait to provide common functionality
/// for loading, validating, and processing asset records.
pub trait PipelineManifest: Sized {
    /// The type of records contained in this manifest.
    type Record;
    /// The type of stage-specific errors that can occur during validation.
    type StageError: std::error::Error + PartialEq + 'static;

    /// Returns a slice of all records in this manifest.
    fn records(&self) -> &[Self::Record];
    /// Returns the pack identity for this manifest.
    fn source_pack(&self) -> &ExternalAssetPackIdentity;
    /// Extracts the archetype tag from a record for identification purposes.
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag;

    /// Stage-specific validation (implement per stage).
    /// Returns stage-specific errors not covered by structural validation.
    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>>;

    /// Structural validation common to all manifests.
    /// Checks for empty manifests, missing source files, duplicate IDs, and sorting.
    fn validate_structure(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        let records = self.records();

        if records.is_empty() {
            errors.push(ManifestError::EmptyManifest);
        }

        let pack_errors = self.source_pack().validate();
        for e in pack_errors {
            errors.push(ManifestError::ValidationError(e));
        }

        if !self.source_pack().source_manifest.exists() {
            errors.push(ManifestError::MissingSourceManifest(
                self.source_pack().source_manifest.clone(),
            ));
        }

        let mut seen = std::collections::BTreeSet::new();
        let mut previous: Option<&str> = None;
        for record in records {
            let id = self.record_id(record);
            if !seen.insert(id.as_str().to_string()) {
                errors.push(ManifestError::DuplicateId(id.clone()));
            }
            let current = id.as_str();
            if let Some(prev) = previous && prev > current {
                errors.push(ManifestError::Unsorted);
            }
            previous = Some(current);
        }

        errors
    }

    /// Full validation: structural + stage-specific.
    /// Returns all validation errors found.
    fn validate(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = self.validate_structure();
        errors.extend(self.validate_stage_specific());
        errors
    }

    /// Strict validation that returns Result instead of Vec.
    /// Returns Ok(()) if no errors, or Err with all errors if any were found.
    fn validate_strict(&self) -> Result<(), Vec<ManifestError<Self::StageError>>> {
        let errs = self.validate();
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }
}
