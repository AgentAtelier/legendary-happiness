//! Asset registration types for the pilot manifest.

use anvil_assets::{AssetCategory, AssetKind};
use anvil_core::path::repo_root_from_manifest;
use anvil_core::{ArchetypeTag, FailureClass, ValidationErrors};
use anvil_core::{error_buffer, push_validation_error};
use serde::{Deserialize, Serialize};
use std::env;
use std::fmt;
use std::str::FromStr;

/// Asset family classification for external assets.
#[non_exhaustive]
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetFamily {
    /// Tree models.
    Tree,
    /// Rock models.
    Rock,
    /// Ground cover (grasses, plants, etc.).
    GroundCover,
    /// Stumps, roots, and logs.
    StumpRootLog,
    /// Mushroom models.
    Mushroom,
    /// Ground texture sets.
    GroundTextureSet,
}

impl fmt::Display for ExternalAssetFamily {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::Tree => "tree",
            Self::Rock => "rock",
            Self::GroundCover => "ground_cover",
            Self::StumpRootLog => "stump_root_log",
            Self::Mushroom => "mushroom",
            Self::GroundTextureSet => "ground_texture_set",
        };
        write!(f, "{}", s)
    }
}

/// Source kind classification for external assets.
#[non_exhaustive]
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetSourceKind {
    /// 3D mesh asset.
    Mesh,
    /// Texture set asset.
    TextureSet,
}

impl fmt::Display for ExternalAssetSourceKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::Mesh => "mesh",
            Self::TextureSet => "texture_set",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing an invalid external asset family string.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetFamilyError;

impl fmt::Display for ParseExternalAssetFamilyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset family")
    }
}

impl std::error::Error for ParseExternalAssetFamilyError {}

impl FromStr for ExternalAssetFamily {
    type Err = ParseExternalAssetFamilyError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "tree" => Ok(Self::Tree),
            "rock" => Ok(Self::Rock),
            "ground_cover" => Ok(Self::GroundCover),
            "stump_root_log" => Ok(Self::StumpRootLog),
            "mushroom" => Ok(Self::Mushroom),
            "ground_texture_set" => Ok(Self::GroundTextureSet),
            _ => Err(ParseExternalAssetFamilyError),
        }
    }
}

/// Error returned when parsing an invalid external asset source kind string.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetSourceKindError;

impl fmt::Display for ParseExternalAssetSourceKindError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset source kind")
    }
}

impl std::error::Error for ParseExternalAssetSourceKindError {}

impl FromStr for ExternalAssetSourceKind {
    type Err = ParseExternalAssetSourceKindError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "mesh" => Ok(Self::Mesh),
            "texture_set" => Ok(Self::TextureSet),
            _ => Err(ParseExternalAssetSourceKindError),
        }
    }
}

#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", family)"]
pub fn external_asset_family_label(family: &ExternalAssetFamily) -> &'static str {
    match family {
        ExternalAssetFamily::Tree => "tree",
        ExternalAssetFamily::Rock => "rock",
        ExternalAssetFamily::GroundCover => "ground_cover",
        ExternalAssetFamily::StumpRootLog => "stump_root_log",
        ExternalAssetFamily::Mushroom => "mushroom",
        ExternalAssetFamily::GroundTextureSet => "ground_texture_set",
    }
}

#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", kind)"]
pub fn external_asset_source_kind_label(kind: &ExternalAssetSourceKind) -> &'static str {
    match kind {
        ExternalAssetSourceKind::Mesh => "mesh",
        ExternalAssetSourceKind::TextureSet => "texture_set",
    }
}

/// Unique identifier composed of vendor, pack name, and normalized ID.
/// Format: "vendor::pack_name::normalized_id"
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct Provenance(String);

impl Provenance {
    /// Create a new provenance identifier from its components.
    pub fn new(vendor: &str, pack_name: &str, normalized_id: &str) -> Self {
        Self(format!("{}::{}::{}", vendor, pack_name, normalized_id))
    }

    /// Returns the provenance as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for Provenance {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// Reference to a source file in an external asset pack.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetSourceRef {
    /// The kind of source file (mesh or texture set).
    pub source_kind: ExternalAssetSourceKind,
    /// The path to the source file relative to the pack root.
    pub source_file: String,
}

/// Identity information for an external asset pack.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetPackIdentity {
    /// Vendor name (e.g., "naturemanufacture").
    pub vendor: String,
    /// Name of the asset pack (e.g., "forest_pack").
    pub pack_name: String,
    /// Path to the root directory containing the pack's source files.
    pub source_root: PathBuf,
    /// Path to the pack's source manifest JSON file.
    pub source_manifest: PathBuf,
}

impl ExternalAssetPackIdentity {
    /// Resolves relative paths in source_root and source_manifest to absolute paths
    /// relative to the repository root. This allows manifest files to use relative paths
    /// that work across different machines.
    pub fn with_resolved_paths(self) -> Self {
        // Try to get the repo root. If we can't, keep the paths as-is.
        let repo_root: PathBuf = match repo_root_from_manifest(env!("CARGO_MANIFEST_DIR")) {
            Ok(root) => root,
            Err(_) => return self,
        };

        let source_root = if self.source_root.is_absolute() {
            self.source_root
        } else {
            repo_root.join(&self.source_root)
        };

        let source_manifest = if self.source_manifest.is_absolute() {
            self.source_manifest
        } else {
            repo_root.join(&self.source_manifest)
        };

        Self {
            vendor: self.vendor,
            pack_name: self.pack_name,
            source_root,
            source_manifest,
        }
    }

    /// Validates the pack identity fields.
    /// Returns validation errors for blank fields, relative paths, and missing files.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.vendor.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E053",
                "ExternalAssetPackIdentity",
                "vendor",
                self.vendor.clone(),
                "vendor must not be blank"
            );
        }
        if self.pack_name.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E054",
                "ExternalAssetPackIdentity",
                "pack_name",
                self.pack_name.clone(),
                "pack_name must not be blank"
            );
        }
        if !self.source_root.is_absolute() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E055",
                "ExternalAssetPackIdentity",
                "source_root",
                self.source_root.display().to_string(),
                "source_root must be an absolute path"
            );
        }
        if !self.source_manifest.is_absolute() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E056",
                "ExternalAssetPackIdentity",
                "source_manifest",
                self.source_manifest.display().to_string(),
                "source_manifest must be an absolute path"
            );
        }
        if !self.source_manifest.exists() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E057",
                "ExternalAssetPackIdentity",
                "source_manifest",
                self.source_manifest.display().to_string(),
                "source_manifest not found"
            );
        }
        errors
    }
}

use std::path::PathBuf;

/// Asset registration for external normalization pipeline.
/// Contains all metadata needed to process an external asset.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetRegistration {
    /// The pack identity this registration belongs to.
    pub source_pack: ExternalAssetPackIdentity,
    /// The normalized archetype tag for this asset.
    pub normalized_id: ArchetypeTag,
    /// Human-readable display name for this asset.
    pub display_name: String,
    /// The asset family classification.
    pub family: ExternalAssetFamily,
    /// The asset category.
    pub category: AssetCategory,
    /// The asset kind.
    pub kind: AssetKind,
    /// Source files that make up this asset.
    pub source_files: Vec<ExternalAssetSourceRef>,
    /// References to texture sets used by this asset.
    #[serde(default)]
    pub texture_set_refs: Vec<String>,
    /// Style tags for this asset.
    #[serde(default)]
    pub style_tags: Vec<String>,
    /// Compatibility tags for this asset.
    #[serde(default)]
    pub compatibility_tags: Vec<String>,
}

impl ExternalAssetRegistration {
    /// Create a new builder for constructing an ExternalAssetRegistration.
    pub fn builder() -> ExternalAssetRegistrationBuilder {
        ExternalAssetRegistrationBuilder::new()
    }

    /// Returns the provenance identifier for this registration.
    pub fn provenance(&self) -> Provenance {
        Provenance::new(
            &self.source_pack.vendor,
            &self.source_pack.pack_name,
            self.normalized_id.as_str(),
        )
    }

    /// Validates the registration fields.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.display_name.trim().is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E050",
                "ExternalAssetRegistration",
                "display_name",
                self.display_name.clone(),
                "display_name must not be empty"
            );
        }
        if self.source_files.is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E051",
                "ExternalAssetRegistration",
                "source_files",
                String::new(),
                "source_files must not be empty"
            );
        }
        for (i, source_ref) in self.source_files.iter().enumerate() {
            if source_ref.source_file.trim().is_empty() {
                push_validation_error!(
                    errors,
                    FailureClass::Asset,
                    "E052",
                    "ExternalAssetRegistration",
                    format!("source_files[{}].source_file", i),
                    source_ref.source_file.clone(),
                    "source_file must not be empty"
                );
            }
        }
        errors
    }
}

/// Builder for [`ExternalAssetRegistration`].
///
/// Required fields:
/// - `source_pack`
/// - `normalized_id`
/// - `family`
pub struct ExternalAssetRegistrationBuilder {
    /// The source pack identity (required).
    source_pack: Option<ExternalAssetPackIdentity>,
    /// The normalized ID (required).
    normalized_id: Option<ArchetypeTag>,
    /// The display name (defaults to normalized_id if empty).
    display_name: String,
    /// The family (required).
    family: Option<ExternalAssetFamily>,
    /// The category (defaults to Landmark).
    category: AssetCategory,
    /// The kind (defaults to Mesh).
    kind: AssetKind,
    /// Source file references.
    source_files: Vec<ExternalAssetSourceRef>,
    /// Texture set references.
    texture_set_refs: Vec<String>,
    /// Style tags.
    style_tags: Vec<String>,
    /// Compatibility tags.
    compatibility_tags: Vec<String>,
}

impl Default for ExternalAssetRegistrationBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl ExternalAssetRegistrationBuilder {
    /// Create a new empty builder.
    pub fn new() -> Self {
        Self {
            source_pack: None,
            normalized_id: None,
            display_name: String::new(),
            family: None,
            category: AssetCategory::Landmark,
            kind: AssetKind::Mesh,
            source_files: vec![],
            texture_set_refs: vec![],
            style_tags: vec![],
            compatibility_tags: vec![],
        }
    }

    /// Required. Sets the source pack identity.
    pub fn with_source_pack(mut self, pack: ExternalAssetPackIdentity) -> Self {
        self.source_pack = Some(pack);
        self
    }

    /// Required. Sets the normalized ID.
    pub fn with_normalized_id(mut self, id: ArchetypeTag) -> Self {
        self.normalized_id = Some(id);
        self
    }

    /// Sets the display name.
    pub fn with_display_name(mut self, name: String) -> Self {
        self.display_name = name;
        self
    }

    /// Required. Sets the family.
    pub fn with_family(mut self, family: ExternalAssetFamily) -> Self {
        self.family = Some(family);
        self
    }

    /// Sets the category.
    pub fn with_category(mut self, category: AssetCategory) -> Self {
        self.category = category;
        self
    }

    /// Sets the kind.
    pub fn with_kind(mut self, kind: AssetKind) -> Self {
        self.kind = kind;
        self
    }

    /// Adds a source file reference.
    pub fn add_source_file(mut self, source_ref: ExternalAssetSourceRef) -> Self {
        self.source_files.push(source_ref);
        self
    }

    /// Adds a texture set reference.
    pub fn add_texture_set_ref(mut self, ref_id: String) -> Self {
        self.texture_set_refs.push(ref_id);
        self
    }

    /// Build the ExternalAssetRegistration.
    /// Returns an error if any required field is missing.
    pub fn build(self) -> Result<ExternalAssetRegistration, String> {
        let normalized_id = self.normalized_id.ok_or_else(|| {
            "ExternalAssetRegistrationBuilder: normalized_id is required".to_string()
        })?;
        let source_pack = self.source_pack.ok_or_else(|| {
            "ExternalAssetRegistrationBuilder: source_pack is required".to_string()
        })?;
        let family = self
            .family
            .ok_or_else(|| "ExternalAssetRegistrationBuilder: family is required".to_string())?;

        Ok(ExternalAssetRegistration {
            source_pack,
            normalized_id: normalized_id.clone(),
            display_name: if self.display_name.is_empty() {
                normalized_id.as_str().to_string()
            } else {
                self.display_name
            },
            family,
            category: self.category,
            kind: self.kind,
            source_files: self.source_files,
            texture_set_refs: self.texture_set_refs,
            style_tags: self.style_tags,
            compatibility_tags: self.compatibility_tags,
        })
    }
}
