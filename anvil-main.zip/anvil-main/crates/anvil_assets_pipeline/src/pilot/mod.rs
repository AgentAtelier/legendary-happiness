//! External asset pilot manifest: the entry point for vendor asset registration.

/// Pilot manifest parsing and validation.
mod manifest;
/// Asset registration handling.
mod registration;

pub use manifest::{
    ExternalAssetIngestRecord, ExternalAssetPilotError, ExternalAssetPilotManifest,
    PackIdentityError, PilotStageError,
};
pub use registration::{
    ExternalAssetFamily, ExternalAssetPackIdentity, ExternalAssetRegistration,
    ExternalAssetRegistrationBuilder, ExternalAssetSourceKind, ExternalAssetSourceRef,
    ParseExternalAssetFamilyError, ParseExternalAssetSourceKindError, Provenance,
};
