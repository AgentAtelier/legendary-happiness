//! Pilot manifest and related types.

use crate::pipeline::{ManifestError, PipelineManifest};
use crate::pilot::registration::{ExternalAssetPackIdentity, ExternalAssetRegistration};
use anvil_core::ArchetypeTag;
use anvil_core::{error_buffer, push_validation_error, FailureClass, ValidationErrors};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;
use thiserror::Error;

/// Errors related to pack identity validation.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
pub enum PackIdentityError {
    /// A required field is empty or whitespace-only.
    #[error("field '{0}' must not be blank")]
    BlankField(&'static str),
    /// The source root path is relative, but must be absolute.
    #[error("source_root must be an absolute path")]
    RelativeSourceRoot,
    /// The source manifest path is relative, but must be absolute.
    #[error("source_manifest must be an absolute path")]
    RelativeManifest,
    /// The source manifest file does not exist.
    #[error("source_manifest not found: {0}")]
    ManifestNotFound(std::path::PathBuf),
}

/// Errors related to pilot stage validation.
#[derive(Debug, PartialEq, Eq, Error)]
pub enum PilotStageError {
    /// A record's pack identity does not match the manifest's pack identity.
    #[error("record {0} has mismatched pack identity")]
    PackMismatch(usize),
    /// A record has no source files listed.
    #[error("record {0} is missing source files")]
    MissingSourceFiles(usize),
    /// A record has an invalid source file reference.
    #[error("record {0} has invalid source file reference: {1}")]
    InvalidSourceFileReference(usize, String),
}

/// A single ingest record in the pilot manifest.
/// Each record represents one asset to be registered.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetIngestRecord {
    /// The asset registration data for this record.
    pub registration: ExternalAssetRegistration,
}

/// The pilot manifest - entry point for vendor asset registration.
/// This manifest lists all assets to be ingested from a vendor's source pack.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetPilotManifest {
    /// The pack identity this manifest belongs to.
    pub source_pack: ExternalAssetPackIdentity,
    /// All asset ingest records in this manifest.
    pub records: Vec<ExternalAssetIngestRecord>,
}

impl PipelineManifest for ExternalAssetPilotManifest {
    type Record = ExternalAssetIngestRecord;
    type StageError = PilotStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.registration.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for (index, record) in self.records.iter().enumerate() {
            if record.registration.source_pack != self.source_pack {
                errors.push(ManifestError::StageSpecific(PilotStageError::PackMismatch(
                    index,
                )));
            }
            if record.registration.source_files.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    PilotStageError::MissingSourceFiles(index),
                ));
            }
            for source_file in &record.registration.source_files {
                if source_file.source_file.trim().is_empty() {
                    errors.push(ManifestError::StageSpecific(
                        PilotStageError::InvalidSourceFileReference(
                            index,
                            "blank source file reference".to_string(),
                        ),
                    ));
                }
            }
        }
        errors
    }
}

/// Errors related to pilot manifest loading and validation.
#[derive(Debug, Error)]
pub enum ExternalAssetPilotError {
    /// Failed to read the manifest file.
    #[error("failed to read external asset pilot manifest: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the manifest JSON.
    #[error("failed to parse external asset pilot manifest: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The manifest contains no records.
    #[error("external asset pilot manifest has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id in external asset pilot manifest: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// Records are not sorted deterministically.
    #[error("external asset pilot manifest is not deterministically ordered")]
    UnsortedManifest,

    /// A required field in the source pack is blank.
    #[error("external asset pilot source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// A record's pack identity does not match the manifest's.
    #[error("external asset pilot record {0} has mismatched pack identity")]
    PackMismatch(usize),

    /// A record has no source files.
    #[error("external asset pilot record {0} is missing source files")]
    MissingSourceFiles(usize),

    /// A record has an invalid source file reference.
    #[error("external asset pilot record {0} has invalid source file reference: {1}")]
    InvalidSourceFileReference(usize, String),

    /// The source manifest file was not found.
    #[error("external asset pilot source manifest not found: {0}")]
    MissingSourceManifest(std::path::PathBuf),

    /// An error occurred validating the pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// Validation errors were found in the registration records.
    #[error("validation errors in registration")]
    RegistrationValidationErrors(Vec<anvil_core::AnvilCoreError>),
}

impl ExternalAssetPilotManifest {
    /// Load a pilot manifest from a JSON file at the given path.
    /// Resolves relative paths, sorts records, and validates the manifest.
    pub fn load(path: &Path) -> Result<Self, ExternalAssetPilotError> {
        let content = fs::read_to_string(path)?;
        let manifest: Self = serde_json::from_str(&content)?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        // Also resolve paths in all registration records
        for record in &mut manifest.records {
            record.registration.source_pack = record.registration.source_pack.clone().with_resolved_paths();
        }
        manifest.records.sort_by(|a, b| {
            a.registration
                .normalized_id
                .as_str()
                .cmp(b.registration.normalized_id.as_str())
        });
        let errors = manifest.validate();
        if !errors.is_empty() {
            return Err(ExternalAssetPilotError::RegistrationValidationErrors(
                errors,
            ));
        }
        Ok(manifest)
    }

    /// Validate the manifest structure and content.
    /// Returns all validation errors found, or an empty Vec if valid.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        if self.records.is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E058",
                "ExternalAssetPilotManifest",
                "records",
                format!("{} records", self.records.len()),
                "records must not be empty"
            );
            return errors;
        }

        let pack_errors = self.source_pack.validate();
        errors.extend(pack_errors);

        if errors.is_empty() && !self.source_pack.source_manifest.exists() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E059",
                "ExternalAssetPilotManifest",
                "source_manifest",
                self.source_pack.source_manifest.display().to_string(),
                "source_manifest not found"
            );
        }

        if errors.is_empty() {
            let manifest_text = match fs::read_to_string(&self.source_pack.source_manifest) {
                Ok(text) => text,
                Err(e) => {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E060",
                        "ExternalAssetPilotManifest",
                        "source_manifest",
                        self.source_pack.source_manifest.display().to_string(),
                        &format!("failed to read source_manifest: {}", e)
                    );
                    return errors;
                }
            };

            let mut seen = BTreeSet::new();
            let normalized_ids: BTreeSet<_> = self
                .records
                .iter()
                .map(|record| record.registration.normalized_id.as_str().to_string())
                .collect();
            let mut previous = None::<&str>;

            for (index, record) in self.records.iter().enumerate() {
                if record.registration.source_pack != self.source_pack {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E061",
                        "ExternalAssetPilotManifest",
                        &format!("records[{}]", index),
                        format!("{:?}", record.registration.source_pack),
                        "record has mismatched pack identity"
                    );
                }

                if record.registration.source_files.is_empty() {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E062",
                        "ExternalAssetPilotManifest",
                        &format!("records[{}]", index),
                        "",
                        "record is missing source files"
                    );
                }

                for source_file in &record.registration.source_files {
                    if source_file.source_file.trim().is_empty() {
                        push_validation_error!(
                            errors,
                            FailureClass::Asset,
                            "E063",
                            "ExternalAssetPilotManifest",
                            &format!("records[{}].source_files", index),
                            source_file.source_file.clone(),
                            "blank source file reference"
                        );
                    }

                    if !manifest_text.contains(&source_file.source_file) {
                        push_validation_error!(
                            errors,
                            FailureClass::Asset,
                            "E063",
                            "ExternalAssetPilotManifest",
                            &format!("records[{}].source_files", index),
                            source_file.source_file.clone(),
                            "source file not found in manifest"
                        );
                    }
                }

                if !seen.insert(record.registration.normalized_id.as_str().to_string()) {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E064",
                        "ExternalAssetPilotManifest",
                        "records",
                        record.registration.normalized_id.as_str().to_string(),
                        "duplicate normalized id"
                    );
                }

                let current = record.registration.normalized_id.as_str();
                if let Some(previous) = previous && previous > current {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E065",
                        "ExternalAssetPilotManifest",
                        "records",
                        current.to_string(),
                        "manifest is not deterministically ordered"
                    );
                }
                previous = Some(current);

                if record.registration.display_name.trim().is_empty() {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E066",
                        "ExternalAssetPilotManifest",
                        &format!("records[{}].display_name", index),
                        record.registration.display_name.clone(),
                        "display_name must not be blank"
                    );
                }

                // Collect registration validation errors
                let reg_errors = record.registration.validate();
                errors.extend(reg_errors);

                for texture_ref in &record.registration.texture_set_refs {
                    if !manifest_text.contains(texture_ref) && !normalized_ids.contains(texture_ref) {
                        push_validation_error!(
                            errors,
                            FailureClass::Asset,
                            "E067",
                            "ExternalAssetPilotManifest",
                            &format!("records[{}].texture_set_refs", index),
                            texture_ref.clone(),
                            "texture reference not found in manifest or normalized ids"
                        );
                    }
                }
            }
        }

        errors
    }

    /// Returns an iterator over all registration records in this manifest.
    pub fn registrations(&self) -> impl Iterator<Item = &ExternalAssetRegistration> {
        self.records.iter().map(|record| &record.registration)
    }

    /// Returns a map from normalized ID strings to registration records.
    pub fn registration_map(&self) -> std::collections::BTreeMap<&str, &ExternalAssetRegistration> {
        self.records
            .iter()
            .map(|r| (r.registration.normalized_id.as_str(), &r.registration))
            .collect()
    }
}
