//! External asset texture payload manifest.

mod errors;
mod manifest;
mod staging;

pub use errors::{
    ExternalAssetTexturePayloadError, TexturePayloadStageError, TexturePayloadValidationErrors,
};
pub use manifest::{
    ExternalAssetTexturePayloadOutputRecord, ExternalAssetTexturePayloadRecord,
    ExternalAssetTexturePayloadReport, ExternalAssetTexturePayloadStatus,
    TexturePayloadRecordBuilder, external_asset_texture_payload_status_label,
};
pub use staging::{output_texture_path};
