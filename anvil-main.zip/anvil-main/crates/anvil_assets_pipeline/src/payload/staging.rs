//! Staging logic for external asset texture payload.

use anvil_core::{arche, ArchetypeTag};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

use crate::{
    ExternalAssetFamily, ExternalAssetMaterialSidecarManifest,
    ExternalAssetNormalizationEligibilityManifest, ExternalAssetNormalizationExecutionManifest,
    ExternalAssetNormalizationStageManifest, ExternalAssetPilotManifest,
};

use super::errors::{ExternalAssetTexturePayloadError, TexturePayloadValidationErrors};
use super::manifest::{
    ExternalAssetTexturePayloadOutputRecord, ExternalAssetTexturePayloadRecord,
    ExternalAssetTexturePayloadReport, ExternalAssetTexturePayloadStatus,
};

/// Check if a path component is safe (no traversal, no empty segments).
/// Returns false if the component is empty, ".", "..", or contains path separators.
fn is_safe_path_component(component: &str) -> bool {
    !component.is_empty()
        && component != "."
        && component != ".."
        && !component.contains('/')
        && !component.contains('\\')
}

/// Create a path to a source asset file from a reference.
fn source_asset_file_path(source_root: &Path, source_texture_file_ref: &str) -> PathBuf {
    source_root.join(source_texture_file_ref)
}

/// Compute the normalized texture output path for a given source texture file.
/// Constructs the path based on the output root, family, normalized ID, and source file name.
pub fn output_texture_path(
    output_root: &Path,
    family: &ExternalAssetFamily,
    normalized_id: &ArchetypeTag,
    source_texture_file_ref: &str,
    vendor: &dyn crate::Vendor,
) -> Result<PathBuf, ExternalAssetTexturePayloadError> {
    let file_name = Path::new(source_texture_file_ref)
        .file_name()
        .ok_or_else(|| {
            ExternalAssetTexturePayloadError::InvalidStagedTextureOutput(
                normalized_id.clone(),
                format!(
                    "source_texture_file_ref has no file name: {}",
                    source_texture_file_ref
                ),
            )
        })?;
    let output_dir = vendor.output_directory(family.clone());
    Ok(output_root
        .join("textures")
        .join(output_dir)
        .join(normalized_id.as_str())
        .join(file_name))
}

/// Get the expected output prefix for texture files.
fn expected_output_prefix(output_root: &Path) -> PathBuf {
    output_root.join("textures")
}

impl ExternalAssetTexturePayloadReport {
    /// Resolve a texture payload report from a material sidecar authority report.
    /// Validates the material sidecar manifest against all authority manifests and constructs
    /// the texture payload records from the sidecar data.
    pub fn resolve_from_authority(
        material_sidecar_report: &crate::sidecar::ExternalAssetMaterialSidecarReport,
        manifest: &ExternalAssetMaterialSidecarManifest,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        execution: &ExternalAssetNormalizationExecutionManifest,
        report_path: &Path,
    ) -> Result<Self, ExternalAssetTexturePayloadError> {
        if material_sidecar_report.source_pack != pilot.source_pack
            || material_sidecar_report.source_pack != staging.source_pack
            || material_sidecar_report.source_pack != eligibility.source_pack
            || material_sidecar_report.source_pack != execution.source_pack
            || material_sidecar_report.source_pack != manifest.source_pack
        {
            return Err(ExternalAssetTexturePayloadError::SourcePackMismatch);
        }

        let resolved_sidecar = manifest
            .resolve_report(
                pilot,
                staging,
                eligibility,
                execution,
                &material_sidecar_report.execution_report_path,
                &material_sidecar_report.report_path,
            )
            .map_err(|_| {
                ExternalAssetTexturePayloadError::MaterialSidecarMismatch(
                    arche!("nm_forest_env_material_sidecar_batch"),
                )
            })?;
        if &resolved_sidecar != material_sidecar_report {
            return Err(ExternalAssetTexturePayloadError::MaterialSidecarMismatch(
                arche!("nm_forest_env_material_sidecar_batch"),
            ));
        }

        let mut records = Vec::with_capacity(material_sidecar_report.records.len());
        for record in &material_sidecar_report.records {
            let mut grouped: BTreeMap<String, ExternalAssetTexturePayloadOutputRecord> =
                BTreeMap::new();
            for slot_binding in &record.material_slot_bindings {
                for channel in &slot_binding.channel_mappings {
                    let output_path = output_texture_path(
                        &material_sidecar_report.output_root,
                        &record.family,
                        &record.normalized_id,
                        &channel.source_texture_file_ref,
                        &crate::vendors::naturemanufacture::NatureManufactureVendor,
                    )?;
                    let entry = grouped
                        .entry(channel.source_texture_file_ref.clone())
                        .or_insert_with(|| ExternalAssetTexturePayloadOutputRecord {
                            source_texture_bundle_refs: Vec::new(),
                            source_texture_file_ref: channel.source_texture_file_ref.clone(),
                            normalized_texture_output_path: output_path,
                            channel_semantics: Vec::new(),
                            status: ExternalAssetTexturePayloadStatus::Staged,
                            notes: Vec::new(),
                        });
                    if !entry
                        .source_texture_bundle_refs
                        .iter()
                        .any(|bundle| bundle == &channel.source_texture_bundle_ref)
                    {
                        entry
                            .source_texture_bundle_refs
                            .push(channel.source_texture_bundle_ref.clone());
                    }
                    if !entry.channel_semantics.contains(&channel.semantic) {
                        entry.channel_semantics.push(channel.semantic);
                    }
                    if !channel.notes.is_empty() {
                        entry.notes.extend(channel.notes.clone());
                    }
                }
            }
            let staged_texture_outputs = grouped.into_values().collect::<Vec<_>>();
            records.push(ExternalAssetTexturePayloadRecord {
                normalized_id: record.normalized_id.clone(),
                normalized_mesh_output_path: record.normalized_mesh_output_path.clone(),
                family: record.family.clone(),
                category: record.category.clone(),
                normalized_material_class: record.normalized_material_class,
                source_texture_bundle_refs: record.source_texture_bundle_refs.clone(),
                source_texture_file_refs: record.source_texture_file_refs.clone(),
                staged_texture_outputs,
                notes: record.notes.clone(),
                limitations: record.limitations.clone(),
            });
        }

        Ok(Self {
            source_pack: material_sidecar_report.source_pack.clone(),
            batch_name: material_sidecar_report.batch_name.clone(),
            material_sidecar_report_path: material_sidecar_report.report_path.clone(),
            execution_report_path: material_sidecar_report.execution_report_path.clone(),
            report_path: report_path.to_path_buf(),
            output_root: material_sidecar_report.output_root.clone(),
            records,
        })
    }

    /// Stage all texture files from source to their normalized output locations.
    /// Creates parent directories as needed and copies source files to their destinations.
    pub fn stage_files(&self, source_root: &Path) -> TexturePayloadValidationErrors {
        let output_prefix = expected_output_prefix(&self.output_root);
        let mut errors = TexturePayloadValidationErrors::new();

        for record in &self.records {
            for staged_texture in &record.staged_texture_outputs {
                for part in staged_texture.source_texture_file_ref.split('/') {
                    if !is_safe_path_component(part) {
                        errors.push(ExternalAssetTexturePayloadError::InvalidOutputPath(
                            record.normalized_id.clone(),
                            format!("unsafe path component: {}", part),
                        ));
                        continue;
                    }
                }
                let source_path =
                    source_asset_file_path(source_root, &staged_texture.source_texture_file_ref);
                if !source_path.exists() {
                    errors.push(ExternalAssetTexturePayloadError::MissingSourceTextureFile(
                        record.normalized_id.clone(),
                        staged_texture.source_texture_file_ref.clone(),
                    ));
                    continue;
                }
                if !staged_texture
                    .normalized_texture_output_path
                    .starts_with(&output_prefix)
                {
                    errors.push(ExternalAssetTexturePayloadError::InvalidOutputPath(
                        record.normalized_id.clone(),
                        staged_texture
                            .normalized_texture_output_path
                            .display()
                            .to_string(),
                    ));
                    continue;
                }
                if let Some(parent) = staged_texture.normalized_texture_output_path.parent()
                    && let Err(e) = fs::create_dir_all(parent) {
                        errors.push(ExternalAssetTexturePayloadError::IoError(e));
                        continue;
                    }
                if let Err(e) =
                    fs::copy(&source_path, &staged_texture.normalized_texture_output_path)
                {
                    errors.push(ExternalAssetTexturePayloadError::IoError(e));
                    continue;
                }
            }
        }

        errors
    }

    /// Stage all texture files, returning a strict result.
    /// Returns `Ok(())` if all files were staged successfully, or `Err` with the list of errors.
    pub fn stage_files_strict(
        &self,
        source_root: &Path,
    ) -> Result<(), TexturePayloadValidationErrors> {
        let errs = self.stage_files(source_root);
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }

    /// Validate that all staged texture files match their source files.
    /// Checks that each staged file exists and has the same bytes as its source.
    pub fn validate_staged_files(&self, source_root: &Path) -> TexturePayloadValidationErrors {
        let output_prefix = expected_output_prefix(&self.output_root);
        let mut errors = TexturePayloadValidationErrors::new();

        for record in &self.records {
            for staged_texture in &record.staged_texture_outputs {
                for part in staged_texture.source_texture_file_ref.split('/') {
                    if !is_safe_path_component(part) {
                        errors.push(ExternalAssetTexturePayloadError::InvalidOutputPath(
                            record.normalized_id.clone(),
                            format!("unsafe path component: {}", part),
                        ));
                        continue;
                    }
                }
                let source_path =
                    source_asset_file_path(source_root, &staged_texture.source_texture_file_ref);
                if !source_path.exists() {
                    errors.push(ExternalAssetTexturePayloadError::MissingSourceTextureFile(
                        record.normalized_id.clone(),
                        staged_texture.source_texture_file_ref.clone(),
                    ));
                    continue;
                }
                if !staged_texture
                    .normalized_texture_output_path
                    .starts_with(&output_prefix)
                {
                    errors.push(ExternalAssetTexturePayloadError::InvalidOutputPath(
                        record.normalized_id.clone(),
                        staged_texture
                            .normalized_texture_output_path
                            .display()
                            .to_string(),
                    ));
                    continue;
                }
                if !staged_texture.normalized_texture_output_path.exists() {
                    errors.push(
                        ExternalAssetTexturePayloadError::MissingStagedTextureOutput(
                            record.normalized_id.clone(),
                            staged_texture.source_texture_file_ref.clone(),
                        ),
                    );
                    continue;
                }
                let source_bytes = match fs::read(&source_path) {
                    Ok(b) => b,
                    Err(e) => {
                        errors.push(ExternalAssetTexturePayloadError::IoError(e));
                        continue;
                    }
                };
                let staged_bytes = match fs::read(&staged_texture.normalized_texture_output_path) {
                    Ok(b) => b,
                    Err(e) => {
                        errors.push(ExternalAssetTexturePayloadError::IoError(e));
                        continue;
                    }
                };
                if source_bytes != staged_bytes {
                    errors.push(ExternalAssetTexturePayloadError::StagedTextureMismatch(
                        record.normalized_id.clone(),
                        staged_texture.source_texture_file_ref.clone(),
                    ));
                }
            }
        }

        errors
    }

    /// Validate staged texture files, returning a strict result.
    /// Returns `Ok(())` if all files are valid, or `Err` with the list of errors.
    pub fn validate_staged_files_strict(
        &self,
        source_root: &Path,
    ) -> Result<(), TexturePayloadValidationErrors> {
        let errs = self.validate_staged_files(source_root);
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        ExternalAssetMaterialSidecarManifest, ExternalAssetNormalizationBatchManifest,
        ExternalAssetNormalizationEligibilityManifest, ExternalAssetNormalizationStageManifest,
        ExternalAssetPilotManifest,
    };
    use std::path::Path;

    fn repo_batch_manifest_path() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(
            "../../assets/external/naturemanufacture_forest_environment_normalization_batch.json",
        )
    }

    fn repo_material_sidecar_manifest_path() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(
            "../../assets/external/naturemanufacture_forest_environment_material_sidecar.json",
        )
    }

    fn repo_pilot_manifest_path() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../assets/external/naturemanufacture_forest_environment_pilot.json")
    }

    fn repo_eligibility_manifest_path() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../assets/external/naturemanufacture_forest_environment_eligibility.json")
    }

    fn repo_staging_manifest_path() -> PathBuf {
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../assets/external/naturemanufacture_forest_environment_staging.json")
    }

    #[test]
    fn loads_repo_candidate_texture_payload_from_material_sidecar_authority() {
        let Ok(pilot) = ExternalAssetPilotManifest::load(&repo_pilot_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(staging) = ExternalAssetNormalizationStageManifest::load(&repo_staging_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(eligibility) =
            ExternalAssetNormalizationEligibilityManifest::load(&repo_eligibility_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(batch) = ExternalAssetNormalizationBatchManifest::load(&repo_batch_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(execution) = batch
            .resolve_execution_manifest(
                &pilot,
                &staging,
                &eligibility,
                Path::new("/tmp/anvil-normalized"),
            )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(material_sidecar) =
            ExternalAssetMaterialSidecarManifest::load(&repo_material_sidecar_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(sidecar_report) = material_sidecar
            .resolve_report(
                &pilot,
                &staging,
                &eligibility,
                &execution,
                Path::new("/tmp/anvil-normalized/normalization_report.json"),
                Path::new("/tmp/anvil-normalized/material_sidecar_report.json"),
            )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        let Ok(payload) = ExternalAssetTexturePayloadReport::resolve_from_authority(
            &sidecar_report,
            &material_sidecar,
            &pilot,
            &staging,
            &eligibility,
            &execution,
            Path::new("/tmp/anvil-normalized/texture_payload_report.json"),
        )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        assert_eq!(payload.records.len(), 10);
        assert!(payload
            .records
            .iter()
            .all(|record| !record.staged_texture_outputs.is_empty()));
        assert!(payload
            .records
            .iter()
            .flat_map(|record| &record.staged_texture_outputs)
            .all(|output| !output.channel_semantics.is_empty()));
    }

    #[test]
    fn stages_and_validates_texture_payload_files_from_source_textures() {
        let Ok(temp_dir) = tempfile::tempdir() else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let output_root = temp_dir.path().join("external_normalized");
        let batch = repo_batch_manifest_path();
        let staging = repo_staging_manifest_path();
        let pilot = repo_pilot_manifest_path();
        let eligibility = repo_eligibility_manifest_path();
        let Ok(material_sidecar) =
            ExternalAssetMaterialSidecarManifest::load(&repo_material_sidecar_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(batch_manifest) =
            ExternalAssetNormalizationBatchManifest::load(&batch)
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(stage_manifest) =
            ExternalAssetNormalizationStageManifest::load(&staging)
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(pilot_manifest) = ExternalAssetPilotManifest::load(&pilot)
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(eligibility_manifest) =
            ExternalAssetNormalizationEligibilityManifest::load(&eligibility)
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(execution) = batch_manifest
            .resolve_execution_manifest(
                &pilot_manifest,
                &stage_manifest,
                &eligibility_manifest,
                &output_root,
            )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(sidecar_report) = material_sidecar
            .resolve_report(
                &pilot_manifest,
                &stage_manifest,
                &eligibility_manifest,
                &execution,
                Path::new("/tmp/anvil-normalized/normalization_report.json"),
                Path::new("/tmp/anvil-normalized/material_sidecar_report.json"),
            )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(payload) = ExternalAssetTexturePayloadReport::resolve_from_authority(
            &sidecar_report,
            &material_sidecar,
            &pilot_manifest,
            &stage_manifest,
            &eligibility_manifest,
            &execution,
            Path::new("/tmp/anvil-normalized/texture_payload_report.json"),
        )
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        let stage_errors = payload.stage_files(&material_sidecar.source_pack.source_root);
        assert!(
            stage_errors.is_empty(),
            "stage files errors: {:?}",
            stage_errors
        );
        let validate_errors =
            payload.validate_staged_files(&material_sidecar.source_pack.source_root);
        assert!(
            validate_errors.is_empty(),
            "validate staged files errors: {:?}",
            validate_errors
        );
    }
}
