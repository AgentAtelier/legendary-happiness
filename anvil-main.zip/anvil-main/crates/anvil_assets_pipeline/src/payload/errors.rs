//! Error types for external asset texture payload.

use anvil_core::ArchetypeTag;
use std::path::PathBuf;
use thiserror::Error;

use crate::external_pilot::PackIdentityError;

/// Validation errors for texture payload reports.
pub type TexturePayloadValidationErrors = Vec<ExternalAssetTexturePayloadError>;

/// Errors that can occur during the texture payload validation stage.
#[derive(Debug, PartialEq, Eq, Error)]
pub enum TexturePayloadStageError {
    /// The record does not match its corresponding material sidecar execution.
    #[error("record {0:?} does not match material sidecar execution")]
    MaterialSidecarMismatch(ArchetypeTag),
    /// The record's target output path does not match expectations.
    #[error("record {0:?} target output path mismatch")]
    OutputPathMismatch(ArchetypeTag),
    /// The record has no staged texture outputs.
    #[error("record {0:?} has no staged texture outputs")]
    MissingStagedTextures(ArchetypeTag),
    /// The record is missing a source texture file.
    #[error("record {0:?} has missing source texture file: {1}")]
    MissingSourceTextureFile(ArchetypeTag, String),
    /// The record has an invalid staged texture output.
    #[error("record {0:?} has invalid staged texture output: {1}")]
    InvalidStagedTextureOutput(ArchetypeTag, String),
    /// The record has an invalid output path.
    #[error("record {0:?} has invalid output path: {1}")]
    InvalidOutputPath(ArchetypeTag, String),
    /// The record's texture bundle references do not match.
    #[error("record {0:?} texture bundle refs mismatch")]
    TextureBundleMismatch(ArchetypeTag),
    /// The record's material class does not match expectations.
    #[error("record {0:?} material class mismatch")]
    MaterialClassMismatch(ArchetypeTag),
    /// The record is missing a staged texture output.
    #[error("record {0:?} missing staged texture output: {1}")]
    MissingStagedTextureOutput(ArchetypeTag, String),
    /// The staged texture does not match the source bytes.
    #[error("record {0:?} staged texture does not match source: {1}")]
    StagedTextureMismatch(ArchetypeTag, String),
}

/// Errors that can occur when loading or validating an external asset texture payload report.
#[derive(Debug, Error)]
pub enum ExternalAssetTexturePayloadError {
    /// Failed to read the report file from disk.
    #[error("failed to read external asset texture payload report: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the report JSON.
    #[error("failed to parse external asset texture payload report: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The report contains no records.
    #[error("external asset texture payload report has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the report.
    #[error("duplicate normalized id in external asset texture payload report: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// The report records are not sorted deterministically.
    #[error("external asset texture payload report is not deterministically ordered")]
    UnsortedManifest,

    /// A required source pack field is blank or missing.
    #[error("external asset texture payload source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// The source manifest file referenced by the report was not found.
    #[error("external asset texture payload source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),

    /// The source pack in the report does not match the pilot, staging, eligibility, execution, or material-sidecar manifests.
    #[error(
        "external asset texture payload source pack does not match pilot/staging/eligibility/execution/material-sidecar"
    )]
    SourcePackMismatch,

    /// An error occurred while validating pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// A record does not match its corresponding material-sidecar execution.
    #[error(
        "external asset texture payload record {0:?} does not match material-sidecar execution"
    )]
    MaterialSidecarMismatch(ArchetypeTag),

    /// A record's target output path does not match expectations.
    #[error("external asset texture payload record {0:?} target output path mismatch")]
    OutputPathMismatch(ArchetypeTag),

    /// A record has no staged texture outputs.
    #[error("external asset texture payload record {0:?} has no staged texture outputs")]
    MissingStagedTextures(ArchetypeTag),

    /// A record is missing a source texture file.
    #[error("external asset texture payload record {0:?} has missing source texture file: {1}")]
    MissingSourceTextureFile(ArchetypeTag, String),

    /// A record has an invalid staged texture output.
    #[error("external asset texture payload record {0:?} has invalid staged texture output: {1}")]
    InvalidStagedTextureOutput(ArchetypeTag, String),

    /// A record has an invalid normalized texture output path.
    #[error(
        "external asset texture payload record {0:?} has invalid normalized texture output path: {1}"
    )]
    InvalidOutputPath(ArchetypeTag, String),

    /// A record's texture bundle references do not match.
    #[error("external asset texture payload record {0:?} source texture bundle refs mismatch")]
    TextureBundleMismatch(ArchetypeTag),

    /// A record's material class does not match expectations.
    #[error("external asset texture payload record {0:?} material class mismatch")]
    MaterialClassMismatch(ArchetypeTag),

    /// A record is missing a staged texture output.
    #[error("external asset texture payload record {0:?} is missing staged texture output: {1}")]
    MissingStagedTextureOutput(ArchetypeTag, String),

    /// The staged texture output does not match the source bytes.
    #[error(
        "external asset texture payload record {0:?} staged texture output does not match source bytes: {1}"
    )]
    StagedTextureMismatch(ArchetypeTag, String),

    /// The report contains an asset from an unsupported family.
    #[error("unsupported external asset family: {0}")]
    UnsupportedFamily(String),
}
