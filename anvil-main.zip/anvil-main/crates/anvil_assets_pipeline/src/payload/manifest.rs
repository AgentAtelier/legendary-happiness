//! External asset texture payload manifest.

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;
use std::path::PathBuf;

use crate::external_eligibility::ExternalAssetMaterialClass;
use crate::pipeline::{ManifestError, PipelineManifest};
use crate::ExternalAssetFamily;
use anvil_assets::AssetCategory;

use super::errors::{ExternalAssetTexturePayloadError, TexturePayloadStageError, TexturePayloadValidationErrors};

/// External asset texture payload status.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetTexturePayloadStatus {
    /// Textures have been staged for this asset.
    Staged,
}

/// Get a static string label for a texture payload status.
/// Deprecated: use the `Display` implementation instead.
pub fn external_asset_texture_payload_status_label(
    status: &ExternalAssetTexturePayloadStatus,
) -> &'static str {
    match status {
        ExternalAssetTexturePayloadStatus::Staged => "staged",
    }
}

/// Output record for staged textures.
/// Represents a single staged texture file with its metadata.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetTexturePayloadOutputRecord {
    /// References to the source texture bundles used.
    pub source_texture_bundle_refs: Vec<ArchetypeTag>,
    /// Reference to the source texture file.
    pub source_texture_file_ref: String,
    /// The normalized output path for this staged texture.
    pub normalized_texture_output_path: PathBuf,
    /// The channel semantics for this texture.
    pub channel_semantics: Vec<crate::ExternalAssetMaterialChannelSemantic>,
    /// The current staging status.
    pub status: ExternalAssetTexturePayloadStatus,
    /// Optional notes about this staged texture output.
    #[serde(default)]
    pub notes: Vec<String>,
}

/// A single texture payload record.
/// Contains all information about the textures for a single normalized mesh.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetTexturePayloadRecord {
    /// The normalized identifier for this asset.
    pub normalized_id: ArchetypeTag,
    /// The output path for the normalized mesh.
    pub normalized_mesh_output_path: PathBuf,
    /// The family of this asset.
    pub family: ExternalAssetFamily,
    /// The category of this asset.
    pub category: AssetCategory,
    /// The material class for this asset.
    pub normalized_material_class: ExternalAssetMaterialClass,
    /// References to the source texture bundles used.
    pub source_texture_bundle_refs: Vec<ArchetypeTag>,
    /// References to the source texture files used.
    pub source_texture_file_refs: Vec<String>,
    /// The list of staged texture outputs for this asset.
    pub staged_texture_outputs: Vec<ExternalAssetTexturePayloadOutputRecord>,
    /// Optional notes about this texture payload record.
    #[serde(default)]
    pub notes: Vec<String>,
    /// Known limitations for this texture payload.
    #[serde(default)]
    pub limitations: Vec<String>,
}

/// Builder for [`ExternalAssetTexturePayloadRecord`].
/// Provides a fluent API for constructing texture payload records.
pub struct TexturePayloadRecordBuilder {
    normalized_id: Option<ArchetypeTag>,
    normalized_mesh_output_path: Option<PathBuf>,
    family: Option<ExternalAssetFamily>,
    category: AssetCategory,
    normalized_material_class: Option<ExternalAssetMaterialClass>,
    source_texture_bundle_refs: Vec<ArchetypeTag>,
    source_texture_file_refs: Vec<String>,
    staged_texture_outputs: Vec<ExternalAssetTexturePayloadOutputRecord>,
    notes: Vec<String>,
    limitations: Vec<String>,
}

impl Default for TexturePayloadRecordBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl TexturePayloadRecordBuilder {
    /// Create a new builder with default values.
    pub fn new() -> Self {
        Self {
            normalized_id: None,
            normalized_mesh_output_path: None,
            family: None,
            category: AssetCategory::Landmark,
            normalized_material_class: None,
            source_texture_bundle_refs: vec![],
            source_texture_file_refs: vec![],
            staged_texture_outputs: vec![],
            notes: vec![],
            limitations: vec![],
        }
    }

    /// Set the normalized identifier.
    pub fn with_normalized_id(mut self, id: ArchetypeTag) -> Self {
        self.normalized_id = Some(id);
        self
    }

    /// Set the normalized mesh output path.
    pub fn with_mesh_output_path(mut self, path: PathBuf) -> Self {
        self.normalized_mesh_output_path = Some(path);
        self
    }

    /// Set the family.
    pub fn with_family(mut self, family: ExternalAssetFamily) -> Self {
        self.family = Some(family);
        self
    }

    /// Set the category.
    pub fn with_category(mut self, category: AssetCategory) -> Self {
        self.category = category;
        self
    }

    /// Set the material class.
    pub fn with_material_class(mut self, cls: ExternalAssetMaterialClass) -> Self {
        self.normalized_material_class = Some(cls);
        self
    }

    /// Add a texture bundle reference.
    pub fn add_texture_bundle(mut self, bundle: ArchetypeTag) -> Self {
        self.source_texture_bundle_refs.push(bundle);
        self
    }

    /// Add a texture file reference.
    pub fn add_texture_file(mut self, file: String) -> Self {
        self.source_texture_file_refs.push(file);
        self
    }

    /// Add a staged texture output.
    pub fn add_staged_output(mut self, output: ExternalAssetTexturePayloadOutputRecord) -> Self {
        self.staged_texture_outputs.push(output);
        self
    }

    /// Set the notes.
    pub fn with_notes(mut self, notes: Vec<String>) -> Self {
        self.notes = notes;
        self
    }

    /// Set the limitations.
    pub fn with_limitations(mut self, limitations: Vec<String>) -> Self {
        self.limitations = limitations;
        self
    }

    /// Build the texture payload record.
    /// Returns an error if any required field is missing.
    pub fn build(self) -> Result<ExternalAssetTexturePayloadRecord, String> {
        Ok(ExternalAssetTexturePayloadRecord {
            normalized_id: self.normalized_id.ok_or_else(|| {
                "TexturePayloadRecordBuilder: normalized_id is required".to_string()
            })?,
            normalized_mesh_output_path: self.normalized_mesh_output_path.ok_or_else(|| {
                "TexturePayloadRecordBuilder: normalized_mesh_output_path is required".to_string()
            })?,
            family: self
                .family
                .ok_or_else(|| "TexturePayloadRecordBuilder: family is required".to_string())?,
            category: self.category,
            normalized_material_class: self.normalized_material_class.ok_or_else(|| {
                "TexturePayloadRecordBuilder: normalized_material_class is required".to_string()
            })?,
            source_texture_bundle_refs: self.source_texture_bundle_refs,
            source_texture_file_refs: self.source_texture_file_refs,
            staged_texture_outputs: self.staged_texture_outputs,
            notes: self.notes,
            limitations: self.limitations,
        })
    }
}

impl ExternalAssetTexturePayloadRecord {
    /// Create a new builder for this record type.
    pub fn builder() -> TexturePayloadRecordBuilder {
        TexturePayloadRecordBuilder::new()
    }
}

/// The texture payload report / manifest.
/// Contains all texture payload records for a batch, along with paths to related reports.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetTexturePayloadReport {
    /// The source pack identity that these records belong to.
    pub source_pack: crate::ExternalAssetPackIdentity,
    /// The name of the batch.
    pub batch_name: String,
    /// Path to the material sidecar report.
    pub material_sidecar_report_path: PathBuf,
    /// Path to the execution report.
    pub execution_report_path: PathBuf,
    /// Path to this report file.
    pub report_path: PathBuf,
    /// The root directory for output files.
    pub output_root: PathBuf,
    /// The list of texture payload records.
    pub records: Vec<ExternalAssetTexturePayloadRecord>,
}

impl PipelineManifest for ExternalAssetTexturePayloadReport {
    type Record = ExternalAssetTexturePayloadRecord;
    type StageError = TexturePayloadStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &crate::ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ManifestError::BlankField("normalized_id"));
            }
            if record.staged_texture_outputs.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    TexturePayloadStageError::MissingStagedTextures(record.normalized_id.clone()),
                ));
            }
            for staged_texture in &record.staged_texture_outputs {
                if staged_texture
                    .normalized_texture_output_path
                    .to_string_lossy()
                    .is_empty()
                {
                    errors.push(ManifestError::StageSpecific(
                        TexturePayloadStageError::InvalidStagedTextureOutput(
                            record.normalized_id.clone(),
                            "empty output path".to_string(),
                        ),
                    ));
                }
            }
        }
        errors
    }
}

impl ExternalAssetTexturePayloadReport {
    /// Load a texture payload report from a JSON file at the given path.
    /// The report is validated after loading.
    pub fn load(path: &Path) -> Result<Self, TexturePayloadValidationErrors> {
        let content = fs::read_to_string(path)
            .map_err(|e| vec![ExternalAssetTexturePayloadError::IoError(e)])?;
        let mut report: Self = serde_json::from_str(&content)
            .map_err(|e| vec![ExternalAssetTexturePayloadError::ParseError(e)])?;
        // Resolve relative paths in source_pack to absolute paths
        report.source_pack = report.source_pack.with_resolved_paths();
        report.validate_strict()?;
        Ok(report)
    }

    /// Validate the report structure.
    /// Checks for empty records, missing source manifest, duplicate IDs, and ordering.
    pub fn validate(&self) -> TexturePayloadValidationErrors {
        let mut errors = TexturePayloadValidationErrors::new();

        if self.records.is_empty() {
            errors.push(ExternalAssetTexturePayloadError::EmptyManifest);
        }

        let pack_errors = self.source_pack.validate();
        // Pack identity errors are now returned as ValidationErrors (Vec<AnvilCoreError>)
        // For now we skip them since we can't easily convert to ExternalAssetTexturePayloadError
        let _ = pack_errors;

        if !self.source_pack.source_manifest.is_absolute() {
            errors.push(ExternalAssetTexturePayloadError::BlankPackField(
                "source_manifest",
            ));
        }
        if !self.source_pack.source_manifest.exists() {
            errors.push(ExternalAssetTexturePayloadError::MissingSourceManifest(
                self.source_pack.source_manifest.clone(),
            ));
        }

        let mut seen = BTreeSet::new();
        let mut previous = None::<&str>;
        for record in &self.records {
            if !seen.insert(record.normalized_id.as_str().to_string()) {
                errors.push(ExternalAssetTexturePayloadError::DuplicateNormalizedId(
                    record.normalized_id.clone(),
                ));
            }
            let current = record.normalized_id.as_str();
            if let Some(previous) = previous && previous > current {
                errors.push(ExternalAssetTexturePayloadError::UnsortedManifest);
            }
            previous = Some(current);
            if record.staged_texture_outputs.is_empty() {
                errors.push(ExternalAssetTexturePayloadError::MissingStagedTextures(
                    record.normalized_id.clone(),
                ));
            }
        }

        errors
    }

    /// Validate the report and return an error if any validation errors exist.
    /// Returns `Ok(())` if validation passes, or `Err` with the list of errors.
    pub fn validate_strict(&self) -> Result<(), TexturePayloadValidationErrors> {
        let errs = self.validate();
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }
}
