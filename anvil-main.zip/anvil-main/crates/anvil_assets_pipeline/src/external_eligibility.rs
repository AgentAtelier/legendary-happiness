//! External asset eligibility manifest: classification and validation.
//!
//! This module has been split. See the `eligibility` module for the implementation.

pub use crate::eligibility::*;
