//! GLB build and validation for external asset normalization.

use crate::fbx::convert_fbx_to_glb_bytes;

use super::{ExternalAssetNormalizationExecutionError, ExternalAssetNormalizationExecutionRecord};

/// Internal function for building normalized GLB bytes
pub fn build_normalized_glb_bytes_internal(
    record: &ExternalAssetNormalizationExecutionRecord,
) -> Result<Vec<u8>, ExternalAssetNormalizationExecutionError> {
    let (bytes, _) = convert_fbx_to_glb_bytes(&record.source_asset_path, &record.normalized_id)?;
    Ok(bytes)
}

/// Internal function for validating normalized GLB bytes
pub fn validate_normalized_glb_bytes_internal(
    record: &ExternalAssetNormalizationExecutionRecord,
    bytes: &[u8],
) -> Result<(), ExternalAssetNormalizationExecutionError> {
    if bytes.len() < 20 || &bytes[..4] != b"glTF" || bytes[4..8] != 2u32.to_le_bytes() {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let json_chunk_len = u32::from_le_bytes(
        bytes[12..16]
            .try_into()
            .map_err(|_| ExternalAssetNormalizationExecutionError::InvalidGlb(
                record.normalized_id.clone(),
            ))?,
    ) as usize;
    if bytes.len() < 20 + json_chunk_len {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let json_chunk = &bytes[20..20 + json_chunk_len];
    let json_text = std::str::from_utf8(json_chunk).map_err(|_| {
        ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
    })?;
    let binary_chunk_offset = 20 + json_chunk_len;
    if bytes.len() < binary_chunk_offset + 8
        || &bytes[binary_chunk_offset + 4..binary_chunk_offset + 8] != b"BIN\0"
    {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let binary_chunk_len = u32::from_le_bytes(
        bytes[binary_chunk_offset..binary_chunk_offset + 4]
            .try_into()
            .map_err(|_| ExternalAssetNormalizationExecutionError::InvalidGlb(
                record.normalized_id.clone(),
            ))?,
    ) as usize;
    if binary_chunk_offset + 8 + binary_chunk_len > bytes.len() {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let json: serde_json::Value = serde_json::from_str(json_text).map_err(|_| {
        ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
    })?;
    let asset = json
        .get("asset")
        .and_then(|value| value.as_object())
        .ok_or_else(|| {
            ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
        })?;
    if asset.get("version").and_then(|value| value.as_str()) != Some("2.0") {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    if asset
        .get("generator")
        .and_then(|value| value.as_str())
        .map(|value| {
            value.contains(record.normalized_id.as_str())
                && value.contains(&record.source_asset_path.display().to_string())
        })
        != Some(true)
    {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let buffers = json
        .get("buffers")
        .and_then(|value| value.as_array())
        .ok_or_else(|| {
            ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
        })?;
    if buffers
        .first()
        .and_then(|buffer| buffer.get("byteLength"))
        .and_then(|value| value.as_u64())
        .map(|value| value as usize)
        != Some(binary_chunk_len)
    {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    let accessors = json
        .get("accessors")
        .and_then(|value| value.as_array())
        .ok_or_else(|| {
            ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
        })?;
    let meshes = json
        .get("meshes")
        .and_then(|value| value.as_array())
        .ok_or_else(|| {
            ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
        })?;
    if meshes.is_empty() {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }

    let materials = json.get("materials").and_then(|value| value.as_array());
    match record.material_slot_count {
        0 => {
            if materials.is_some_and(|value| !value.is_empty()) {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }
        }
        expected_slots => {
            if materials.map(|value| value.len()) != Some(expected_slots) {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }
        }
    }

    let mut primitive_count = 0usize;
    for mesh in meshes {
        let primitives = mesh
            .get("primitives")
            .and_then(|value| value.as_array())
            .ok_or_else(|| {
                ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
            })?;
        if primitives.is_empty() {
            return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                record.normalized_id.clone(),
            ));
        }
        primitive_count += primitives.len();
        for primitive in primitives {
            let attributes = primitive
                .get("attributes")
                .and_then(|value| value.as_object())
                .ok_or_else(|| {
                    ExternalAssetNormalizationExecutionError::InvalidGlb(
                        record.normalized_id.clone(),
                    )
                })?;
            let position_index = attributes
                .get("POSITION")
                .and_then(|value| value.as_u64())
                .ok_or_else(|| {
                    ExternalAssetNormalizationExecutionError::InvalidGlb(record.normalized_id.clone())
                })? as usize;
            if position_index >= accessors.len() {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }

            let normal_present = attributes.get("NORMAL").is_some();
            if record.has_normals != normal_present {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }
            if let Some(normal_index) = attributes.get("NORMAL").and_then(|value| value.as_u64())
                && normal_index as usize >= accessors.len()
            {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }

            let uv_present = attributes.get("TEXCOORD_0").is_some();
            if record.has_uv0 != uv_present {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }
            if let Some(uv_index) = attributes
                .get("TEXCOORD_0")
                .and_then(|value| value.as_u64())
                && uv_index as usize >= accessors.len()
            {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }

            let material_present = primitive.get("material").is_some();
            if record.material_slot_count == 0 {
                if material_present {
                    return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                        record.normalized_id.clone(),
                    ));
                }
            } else if !material_present {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }

            let indices = primitive
                .get("indices")
                .and_then(|value| value.as_u64())
                .ok_or_else(|| {
                    ExternalAssetNormalizationExecutionError::InvalidGlb(
                        record.normalized_id.clone(),
                    )
                })? as usize;
            if indices >= accessors.len() {
                return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
                    record.normalized_id.clone(),
                ));
            }
        }
    }

    if primitive_count != record.submesh_count {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    if record.source_vertex_count == 0
        || record.source_triangle_count == 0
        || record.source_geometry_name.trim().is_empty()
    {
        return Err(ExternalAssetNormalizationExecutionError::InvalidGlb(
            record.normalized_id.clone(),
        ));
    }
    Ok(())
}

// Re-export internal functions as public for backward compatibility (deprecated)
#[allow(dead_code)]
#[deprecated = "Use NormalizedGlb::from_execution_record instead"]
/// Build normalized GLB bytes from an execution record.
/// Deprecated: use `NormalizedGlb::from_execution_record` instead, which also validates the bytes.
pub fn build_normalized_glb_bytes(
    record: &ExternalAssetNormalizationExecutionRecord,
) -> Result<Vec<u8>, ExternalAssetNormalizationExecutionError> {
    build_normalized_glb_bytes_internal(record)
}

#[allow(dead_code)]
#[deprecated = "Use NormalizedGlb::from_execution_record instead"]
/// Validate normalized GLB bytes against an execution record.
/// Deprecated: use `NormalizedGlb::from_execution_record` instead, which builds and validates the bytes.
pub fn validate_normalized_glb_bytes(
    record: &ExternalAssetNormalizationExecutionRecord,
    bytes: &[u8],
) -> Result<(), ExternalAssetNormalizationExecutionError> {
    validate_normalized_glb_bytes_internal(record, bytes)
}

/// Write GLB bytes to a writer, enabling streaming writes for large GLB files.
/// Writes the entire byte slice to the writer and returns the number of bytes written.
pub fn write_glb_to_writer<W: std::io::Write>(
    writer: &mut W,
    bytes: &[u8],
) -> Result<usize, std::io::Error> {
    writer.write_all(bytes)?;
    Ok(bytes.len())
}
