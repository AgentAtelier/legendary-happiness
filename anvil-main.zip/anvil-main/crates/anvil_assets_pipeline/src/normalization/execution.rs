//! Execution manifest resolution for external asset normalization.

use crate::external_pilot::ExternalAssetPilotManifest;
use crate::external_staging::ExternalAssetNormalizationStageManifest;
use crate::pipeline::{ManifestError, PipelineManifest};
use crate::ExternalAssetFamily;
use crate::{ExternalAssetNormalizationEligibilityManifest, ExternalAssetSourceRef};
use anvil_assets::AssetCategory;
use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::fmt;
use thiserror::Error;

use super::{
    BatchCompositionPolicy, BatchValidationErrors, DefaultBatchCompositionPolicy,
    ExternalAssetNormalizationBatchManifest, NormalizationStageError,
};

/// The execution status of an external asset normalization record.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetNormalizationExecutionStatus {
    /// The normalization has been planned but not yet executed.
    Planned,
    /// The normalization has been completed.
    Completed,
}

impl fmt::Display for ExternalAssetNormalizationExecutionStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::Planned => "planned",
            Self::Completed => "completed",
        };
        write!(f, "{}", s)
    }
}

/// Get a static string label for an execution status.
/// Deprecated: use the `Display` implementation instead.
#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", status)"]
pub fn external_asset_normalization_execution_status_label_impl(
    status: &ExternalAssetNormalizationExecutionStatus,
) -> &'static str {
    match status {
        ExternalAssetNormalizationExecutionStatus::Planned => "planned",
        ExternalAssetNormalizationExecutionStatus::Completed => "completed",
    }
}

/// A record of an external asset normalization execution.
/// Contains all information needed to execute the normalization, including source paths,
/// geometry metadata, and the target output location.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationExecutionRecord {
    /// The normalized identifier for this asset.
    pub normalized_id: ArchetypeTag,
    /// The reference to the source asset.
    pub source_asset_ref: ExternalAssetSourceRef,
    /// The absolute path to the source asset file.
    pub source_asset_path: PathBuf,
    /// The name of the source geometry.
    pub source_geometry_name: String,
    /// The number of vertices in the source geometry.
    pub source_vertex_count: usize,
    /// The number of triangles in the source geometry.
    pub source_triangle_count: usize,
    /// Whether the source geometry has UV channel 0.
    pub has_uv0: bool,
    /// Whether the source geometry has normals.
    pub has_normals: bool,
    /// The number of material slots in the source geometry.
    pub material_slot_count: usize,
    /// The number of submeshes in the source geometry.
    pub submesh_count: usize,
    /// The family of this asset.
    pub family: ExternalAssetFamily,
    /// The category of this asset.
    pub category: AssetCategory,
    /// The kind of normalized output this asset will produce.
    pub target_normalized_kind: crate::ExternalAssetNormalizedOutputKind,
    /// The target output path for the normalized asset.
    pub target_output_path: PathBuf,
    /// The actual output path where the normalized asset will be written.
    pub actual_output_path: PathBuf,
    /// References to texture bundles used by this asset.
    #[serde(default)]
    pub texture_bundle_refs: Vec<ArchetypeTag>,
    /// Notes about fidelity issues detected during inspection.
    #[serde(default)]
    pub fidelity_notes: Vec<String>,
    /// The current execution status.
    pub status: ExternalAssetNormalizationExecutionStatus,
    /// Optional notes about this execution record.
    #[serde(default)]
    pub notes: Vec<String>,
}

/// A manifest containing all execution records for a normalization batch.
/// This manifest is produced by resolving the batch manifest against the staging and eligibility manifests.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationExecutionManifest {
    /// The source pack identity that these execution records belong to.
    pub source_pack: crate::ExternalAssetPackIdentity,
    /// The name of the batch being executed.
    pub batch_name: String,
    /// The root directory for output files.
    pub output_root: PathBuf,
    /// The list of execution records, one per asset to be normalized.
    pub records: Vec<ExternalAssetNormalizationExecutionRecord>,
}

impl PipelineManifest for ExternalAssetNormalizationExecutionManifest {
    type Record = ExternalAssetNormalizationExecutionRecord;
    type StageError = NormalizationStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &crate::ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ManifestError::BlankField("normalized_id"));
            }
            if record.source_asset_path.to_string_lossy().is_empty() {
                errors.push(ManifestError::StageSpecific(
                    NormalizationStageError::MissingSourceAssetPath(
                        record.source_asset_path.display().to_string(),
                    ),
                ));
            }
            if record.source_vertex_count == 0 {
                errors.push(ManifestError::BlankField("source_vertex_count"));
            }
        }
        errors
    }
}

/// Errors that can occur during normalization execution.
#[derive(Debug, Error)]
pub enum ExternalAssetNormalizationExecutionError {
    /// Failed to write the normalized GLB file.
    #[error("failed to write normalized glb: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to serialize the normalization report.
    #[error("failed to serialize normalization report: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The execution record produced invalid GLB bytes.
    #[error("external asset normalization execution record {0:?} has invalid GLB bytes")]
    InvalidGlb(ArchetypeTag),

    /// FBX to GLB conversion failed.
    #[error("fbx conversion failed: {0}")]
    FbxConversion(#[from] crate::fbx::ExternalFbxConversionError),
}

impl ExternalAssetNormalizationBatchManifest {
    /// Resolve an execution manifest from this batch manifest (strict mode).
    /// Fails on any validation error. Uses the default batch composition policy.
    pub fn resolve_execution_manifest(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        output_root: &Path,
    ) -> Result<ExternalAssetNormalizationExecutionManifest, super::ExternalAssetNormalizationBatchError>
    {
        #[allow(deprecated)]
        self.validate_against_stage_and_eligibility(pilot, staging, eligibility)?;

        let (manifest, errors) = self.resolve_execution_manifest_lenient(
            pilot,
            staging,
            eligibility,
            output_root,
            &DefaultBatchCompositionPolicy,
        );

        if !errors.is_empty() {
            // Return the first error for strict mode
            // SAFETY: errors is non-empty because we checked !errors.is_empty() above.
            #[allow(clippy::unwrap_used)]
            let first = errors.into_iter().next().unwrap();
            return Err(first);
        }

        Ok(manifest)
    }

    /// Resolve an execution manifest from this batch manifest (lenient mode).
    /// Collects all validation errors and returns a partial manifest with the records
    /// that could be resolved successfully.
    pub fn resolve_execution_manifest_lenient(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        output_root: &Path,
        policy: &dyn BatchCompositionPolicy,
    ) -> (
        ExternalAssetNormalizationExecutionManifest,
        BatchValidationErrors,
    ) {
        let mut errors = Vec::new();

        // First validate
        errors.extend(self.validate_against_stage_and_eligibility_with_policy(
            pilot,
            staging,
            eligibility,
            policy,
        ));

        if !errors.is_empty() {
            // Return empty manifest with errors if validation failed
            return (
                ExternalAssetNormalizationExecutionManifest {
                    source_pack: self.source_pack.clone(),
                    batch_name: self.batch_name.clone(),
                    output_root: output_root.to_path_buf(),
                    records: vec![],
                },
                errors,
            );
        }

        let staging_by_id: BTreeMap<_, _> = staging
            .records
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();

        let mut records = Vec::with_capacity(self.records.len());
        for selection in &self.records {
            let stage_record = staging_by_id
                .get(selection.normalized_id.as_str())
                .ok_or_else(|| {
                    super::ExternalAssetNormalizationBatchError::MissingSelection(
                        selection.normalized_id.clone(),
                    )
                });
            let stage_record = match stage_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let relative_output = stage_record
                .target_output_path
                .strip_prefix(crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX)
                .unwrap_or(&stage_record.target_output_path);
            let actual_output_path = output_root.join(relative_output);

            let first_source_file = match stage_record.source_files.first() {
                Some(sf) => sf,
                None => {
                    errors.push(super::ExternalAssetNormalizationBatchError::MissingSourceFiles(
                        selection.normalized_id.clone(),
                    ));
                    continue;
                }
            };

            let source_asset_path = match resolve_source_asset_path(
                &self.source_pack.source_root,
                &crate::vendors::naturemanufacture::NatureManufactureVendor,
                &stage_record.family,
                first_source_file,
            ) {
                Ok(p) => p,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            // Make FBX inspection non-fatal
            let source_summary = match crate::fbx::inspect_fbx_source(&source_asset_path) {
                Ok(s) => s,
                Err(e) => {
                    errors.push(super::ExternalAssetNormalizationBatchError::FbxInspection(e));
                    continue;
                }
            };

            let mut fidelity_notes = Vec::new();
            if !source_summary.has_uv0 {
                fidelity_notes.push("uv0 absent or unsupported in source".to_string());
            }
            if !source_summary.has_normals {
                fidelity_notes.push("normals absent or unsupported in source".to_string());
            }
            if source_summary.material_slot_count == 0 {
                fidelity_notes.push("material slots absent or unsupported in source".to_string());
            }

            records.push(ExternalAssetNormalizationExecutionRecord {
                normalized_id: stage_record.normalized_id.clone(),
                source_asset_ref: first_source_file.clone(),
                source_asset_path: source_asset_path.clone(),
                source_geometry_name: source_summary.geometry_name,
                source_vertex_count: source_summary.vertex_count,
                source_triangle_count: source_summary.triangle_count,
                has_uv0: source_summary.has_uv0,
                has_normals: source_summary.has_normals,
                material_slot_count: source_summary.material_slot_count,
                submesh_count: source_summary.submesh_count,
                family: stage_record.family.clone(),
                category: stage_record.category.clone(),
                target_normalized_kind: stage_record.target_output_kind,
                target_output_path: stage_record.target_output_path.clone(),
                actual_output_path,
                texture_bundle_refs: stage_record.texture_bundle_refs.clone(),
                fidelity_notes,
                status: ExternalAssetNormalizationExecutionStatus::Planned,
                notes: selection.notes.clone(),
            });
        }

        (
            ExternalAssetNormalizationExecutionManifest {
                source_pack: self.source_pack.clone(),
                batch_name: self.batch_name.clone(),
                output_root: output_root.to_path_buf(),
                records,
            },
            errors,
        )
    }
}

/// Check if a path component is safe (no traversal, no empty segments).
/// Returns false if the component is empty, ".", "..", or contains path separators.
fn is_safe_path_component(component: &str) -> bool {
    !component.is_empty()
        && component != "."
        && component != ".."
        && !component.contains('/')
        && !component.contains('\\')
}

/// Resolve a source asset reference to an absolute file path.
/// Validates that the path is safe (no traversal) and exists within the source root.
fn resolve_source_asset_path(
    source_root: &Path,
    vendor: &dyn crate::Vendor,
    family: &ExternalAssetFamily,
    source_ref: &ExternalAssetSourceRef,
) -> Result<PathBuf, super::ExternalAssetNormalizationBatchError> {
    // Validate path components to prevent path traversal
    for part in source_ref.source_file.split('/') {
        if !is_safe_path_component(part) {
            return Err(
                super::ExternalAssetNormalizationBatchError::MissingSourceAssetPath(format!(
                    "unsafe path component: {}",
                    part
                )),
            );
        }
    }
    let relative = Path::new(vendor.source_directory(family.clone()));
    let full_path = source_root.join(relative).join(&source_ref.source_file);
    // Verify path stays within source_root using canonicalize
    let canonical_full = full_path.canonicalize().map_err(|e| {
        super::ExternalAssetNormalizationBatchError::MissingSourceAssetPath(format!(
            "failed to canonicalize path {}: {}",
            full_path.display(),
            e
        ))
    })?;
    let canonical_root = source_root.canonicalize().map_err(|e| {
        super::ExternalAssetNormalizationBatchError::MissingSourceAssetPath(format!(
            "failed to canonicalize source_root: {}",
            e
        ))
    })?;
    if !canonical_full.starts_with(&canonical_root) {
        return Err(
            super::ExternalAssetNormalizationBatchError::MissingSourceAssetPath(format!(
                "path {} escapes source_root {}",
                full_path.display(),
                source_root.display()
            )),
        );
    }
    if !full_path.exists() {
        return Err(
            super::ExternalAssetNormalizationBatchError::MissingSourceAssetPath(
                full_path.display().to_string(),
            ),
        );
    }
    Ok(full_path)
}
