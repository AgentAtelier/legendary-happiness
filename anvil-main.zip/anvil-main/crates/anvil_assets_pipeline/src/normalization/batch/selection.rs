use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};

/// A selection of an external asset for normalization batching.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationBatchSelection {
    /// The normalized identifier for the selected asset.
    pub normalized_id: ArchetypeTag,
    /// Optional notes about this selection.
    #[serde(default)]
    pub notes: Vec<String>,
}
