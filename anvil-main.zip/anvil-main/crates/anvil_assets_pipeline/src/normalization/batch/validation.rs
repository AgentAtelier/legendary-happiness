use crate::normalization::batch::manifest::ExternalAssetNormalizationBatchError;

/// Collection of batch validation errors.
pub type BatchValidationErrors = Vec<ExternalAssetNormalizationBatchError>;
