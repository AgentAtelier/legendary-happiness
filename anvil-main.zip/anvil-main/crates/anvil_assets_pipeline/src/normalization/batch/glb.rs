use anvil_core::ArchetypeTag;
use crate::normalization::glb::{build_normalized_glb_bytes_internal, validate_normalized_glb_bytes_internal};
use crate::normalization::{ExternalAssetNormalizationExecutionError, ExternalAssetNormalizationExecutionRecord};

/// A validated normalized GLB asset.
pub struct NormalizedGlb {
    /// The binary GLB data.
    pub bytes: Vec<u8>,
    /// The normalized identifier for this asset.
    pub normalized_id: ArchetypeTag,
    /// The name of the source geometry.
    pub source_geometry_name: String,
    /// The number of vertices in the source geometry.
    pub vertex_count: usize,
    /// The number of triangles in the source geometry.
    pub triangle_count: usize,
}

impl NormalizedGlb {
    /// Create a validated normalized GLB from an execution record.
    /// Builds the GLB bytes and validates them against the execution record.
    pub fn from_execution_record(
        record: &ExternalAssetNormalizationExecutionRecord,
    ) -> Result<Self, ExternalAssetNormalizationExecutionError> {
        let bytes = build_normalized_glb_bytes_internal(record)?;
        validate_normalized_glb_bytes_internal(record, &bytes)?;
        Ok(Self {
            bytes,
            normalized_id: record.normalized_id.clone(),
            source_geometry_name: record.source_geometry_name.clone(),
            vertex_count: record.source_vertex_count,
            triangle_count: record.source_triangle_count,
        })
    }
}
