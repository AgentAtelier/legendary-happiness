//! Batch manifest and validation for external asset normalization.

pub mod glb;
pub mod manifest;
pub mod policy;
pub mod selection;
pub mod validation;

pub use glb::NormalizedGlb;
pub use manifest::{ExternalAssetNormalizationBatchError, ExternalAssetNormalizationBatchManifest};
pub use policy::{BatchCompositionPolicy, DefaultBatchCompositionPolicy};
pub use selection::ExternalAssetNormalizationBatchSelection;
pub use validation::BatchValidationErrors;
