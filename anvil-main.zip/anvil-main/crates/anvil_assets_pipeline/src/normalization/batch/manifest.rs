use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};
use thiserror::Error;
use anvil_core::{error_buffer, push_validation_error, FailureClass, ValidationErrors};
use anvil_core::ArchetypeTag;
use serde::Serialize;
use serde::Deserialize;
use crate::external_pilot::{ExternalAssetPilotManifest, PackIdentityError};
use crate::fbx::ExternalFbxConversionError;
use crate::pipeline::{ManifestError, PipelineManifest};
use crate::ExternalAssetNormalizationStageManifest;
use crate::normalization::batch::policy::DefaultBatchCompositionPolicy;
use crate::{ExternalAssetNormalizationEligibilityManifest, ExternalAssetNormalizedOutputKind};
use crate::normalization::NormalizationStageError;
use crate::normalization::batch::policy::BatchCompositionPolicy;
use crate::normalization::batch::selection::ExternalAssetNormalizationBatchSelection;
use crate::normalization::batch::validation::BatchValidationErrors;

/// Manifest for a batch of external asset normalization records.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationBatchManifest {
    /// The source pack identity that these batch records belong to.
    pub source_pack: crate::ExternalAssetPackIdentity,
    /// The name of this batch.
    pub batch_name: String,
    /// The list of asset selections in this batch.
    pub records: Vec<ExternalAssetNormalizationBatchSelection>,
}

impl PipelineManifest for ExternalAssetNormalizationBatchManifest {
    type Record = ExternalAssetNormalizationBatchSelection;
    type StageError = NormalizationStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &crate::ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ManifestError::BlankField("normalized_id"));
            }
        }
        errors
    }
}

/// Errors that can occur when loading or validating an external asset normalization batch manifest.
#[derive(Debug, Error)]
pub enum ExternalAssetNormalizationBatchError {
    /// Failed to read the manifest file from disk.
    #[error("failed to read external asset normalization batch manifest: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the manifest JSON.
    #[error("failed to parse external asset normalization batch manifest: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The manifest contains no records.
    #[error("external asset normalization batch manifest has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id in external asset normalization batch manifest: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// The manifest records are not sorted deterministically.
    #[error("external asset normalization batch manifest is not deterministically ordered")]
    UnsortedManifest,

    /// A required source pack field is blank or missing.
    #[error("external asset normalization batch source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// The source manifest file referenced by the batch manifest was not found.
    #[error("external asset normalization batch source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),

    /// The source pack in the batch manifest does not match the pilot, staging, or eligibility manifests.
    #[error(
        "external asset normalization batch source pack does not match pilot/staging/eligibility"
    )]
    SourcePackMismatch,

    /// A batch selection references an asset that is not in the staging or eligibility manifests.
    #[error("external asset normalization batch missing normalized id: {0:?}")]
    MissingSelection(ArchetypeTag),

    /// A batch record's family composition does not match the expected first-pass composition.
    #[error(
        "external asset normalization batch record {0:?} family does not match expected first-pass composition"
    )]
    FamilyCompositionMismatch(ArchetypeTag),

    /// A batch record's target kind does not match its eligibility classification.
    #[error(
        "external asset normalization batch record {0:?} target kind does not match eligibility"
    )]
    TargetKindMismatch(ArchetypeTag),

    /// A batch record references an asset that is not eligible for normalization.
    #[error("external asset normalization batch record {0:?} is not eligible for normalization")]
    IneligibleRecord(ArchetypeTag),

    /// A batch record has no source files.
    #[error("external asset normalization batch record {0:?} has no source files")]
    MissingSourceFiles(ArchetypeTag),

    /// A source asset path referenced by a batch record was not found.
    #[error("external asset normalization batch source asset path not found: {0}")]
    MissingSourceAssetPath(String),

    /// FBX inspection failed for a batch record.
    #[error("fbx inspection failed: {0}")]
    FbxInspection(#[from] ExternalFbxConversionError),

    /// A batch record has an invalid output path.
    #[error("external asset normalization batch record {0:?} has invalid output path: {1}")]
    InvalidOutputPath(ArchetypeTag, String),

    /// The batch size does not match the expected size from the composition policy.
    #[error("batch size mismatch: expected {expected} but got {actual}")]
    WrongBatchSize { 
        /// The expected batch size from the composition policy.
        expected: usize, 
        /// The actual number of records in the batch.
        actual: usize 
    },

    /// An error occurred while validating pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// The batch contains an asset from an unsupported family.
    #[error("unsupported external asset family: {0}")]
    UnsupportedFamily(String),
}

impl ExternalAssetNormalizationBatchManifest {
    /// Load a batch manifest from a JSON file at the given path.
    /// The manifest is validated and records are sorted by normalized ID.
    pub fn load(path: &Path) -> Result<Self, ExternalAssetNormalizationBatchError> {
        let content = fs::read_to_string(path)?;
        let manifest: Self = serde_json::from_str(&content)?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        manifest
            .records
            .sort_by(|a, b| a.normalized_id.as_str().cmp(b.normalized_id.as_str()));
        let errors = manifest.validate();
        if !errors.is_empty() {
            // Convert ValidationErrors to ExternalAssetNormalizationBatchError
            return Err(ExternalAssetNormalizationBatchError::UnsortedManifest);
        }
        Ok(manifest)
    }

    /// Validate the manifest structure.
    /// Checks for empty records, missing source manifest, duplicate IDs, and ordering.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        if self.records.is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E075",
                "ExternalAssetNormalizationBatchManifest",
                "records",
                "empty",
                "records must not be empty"
            );
            return errors;
        }

        let pack_errors = self.source_pack.validate();
        errors.extend(pack_errors);

        if errors.is_empty() && !self.source_pack.source_manifest.exists() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E076",
                "ExternalAssetNormalizationBatchManifest",
                "source_manifest",
                self.source_pack.source_manifest.display().to_string(),
                "source_manifest not found"
            );
        }

        if errors.is_empty() {
            let mut seen = BTreeSet::new();
            let mut previous = None::<&str>;
            for selection in &self.records {
                if !seen.insert(selection.normalized_id.as_str().to_string()) {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E077",
                        "ExternalAssetNormalizationBatchManifest",
                        "records",
                        selection.normalized_id.as_str().to_string(),
                        "duplicate normalized id"
                    );
                }
                let current = selection.normalized_id.as_str();
                if let Some(previous) = previous && previous > current {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E078",
                        "ExternalAssetNormalizationBatchManifest",
                        "records",
                        current.to_string(),
                        "manifest is not deterministically ordered"
                    );
                }
                previous = Some(current);
            }
        }

        errors
    }

    /// Validate this manifest against pilot, staging, and eligibility manifests with a composition policy.
    /// Checks that source packs match, all selections have corresponding records, eligibility status,
    /// family composition matches the policy, and all paths are valid.
    pub fn validate_against_stage_and_eligibility_with_policy(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        policy: &dyn BatchCompositionPolicy,
    ) -> BatchValidationErrors {
        let mut errors = Vec::new();

        if self.source_pack != pilot.source_pack
            || self.source_pack != staging.source_pack
            || self.source_pack != eligibility.source_pack
        {
            errors.push(ExternalAssetNormalizationBatchError::SourcePackMismatch);
            return errors;
        }

        if !self.source_pack.source_manifest.exists() {
            errors.push(ExternalAssetNormalizationBatchError::MissingSourceManifest(
                self.source_pack.source_manifest.clone(),
            ));
            return errors;
        }

        let pilot_map = pilot.registration_map();
        let staging_by_id: BTreeMap<_, _> = staging
            .records
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();
        let eligibility_by_id: BTreeMap<_, _> = eligibility
            .records()
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();

        if self.records.len() != policy.max_batch_size() {
            errors.push(ExternalAssetNormalizationBatchError::WrongBatchSize {
                expected: policy.max_batch_size(),
                actual: self.records.len(),
            });
        }

        let mut family_counts: BTreeMap<String, usize> = BTreeMap::new();

        for selection in &self.records {
            let staging_record = staging_by_id
                .get(selection.normalized_id.as_str())
                .ok_or_else(|| {
                    ExternalAssetNormalizationBatchError::MissingSelection(
                        selection.normalized_id.clone(),
                    )
                });
            let staging_record = match staging_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let eligibility_record = eligibility_by_id
                .get(selection.normalized_id.as_str())
                .ok_or_else(|| {
                    ExternalAssetNormalizationBatchError::MissingSelection(
                        selection.normalized_id.clone(),
                    )
                });
            let eligibility_record = match eligibility_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let pilot_registration =
                pilot_map
                    .get(selection.normalized_id.as_str())
                    .ok_or_else(|| {
                        ExternalAssetNormalizationBatchError::MissingSelection(
                            selection.normalized_id.clone(),
                        )
                    });
            let pilot_registration = match pilot_registration {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            if !eligibility_record.status.is_eligible() {
                errors.push(ExternalAssetNormalizationBatchError::IneligibleRecord(
                    selection.normalized_id.clone(),
                ));
            }
            if eligibility_record.target_normalized_kind != staging_record.target_output_kind {
                errors.push(ExternalAssetNormalizationBatchError::TargetKindMismatch(
                    selection.normalized_id.clone(),
                ));
            }
            if staging_record.source_files.is_empty() {
                errors.push(ExternalAssetNormalizationBatchError::MissingSourceFiles(
                    selection.normalized_id.clone(),
                ));
            }
            if pilot_registration.source_files != staging_record.source_files
                || pilot_registration.family != staging_record.family
                || pilot_registration.category != staging_record.category
            {
                errors.push(
                    ExternalAssetNormalizationBatchError::FamilyCompositionMismatch(
                        selection.normalized_id.clone(),
                    ),
                );
            }
            if staging_record.target_output_kind != ExternalAssetNormalizedOutputKind::StaticMeshGlb
                && staging_record.target_output_kind
                    != ExternalAssetNormalizedOutputKind::TextureSetBundle
            {
                errors.push(ExternalAssetNormalizationBatchError::TargetKindMismatch(
                    selection.normalized_id.clone(),
                ));
            }
            if !staging_record
                .target_output_path
                .to_string_lossy()
                .starts_with(crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX)
            {
                errors.push(ExternalAssetNormalizationBatchError::InvalidOutputPath(
                    selection.normalized_id.clone(),
                    staging_record.target_output_path.display().to_string(),
                ));
            }

            *family_counts
                .entry(format!("{}", staging_record.family))
                .or_insert(0) += 1;
        }

        // Validate family composition against policy
        let expected_families = policy.expected_family_counts();
        for (family, expected_count) in &expected_families {
            let family_str = format!("{}", family);
            if family_counts.get(&family_str) != Some(expected_count) {
                // family_str is only used for error identification; a real ArchetypeTag is not required here.
                errors.push(
                    ExternalAssetNormalizationBatchError::FamilyCompositionMismatch(
                        ArchetypeTag::missing(),
                    ),
                );
            }
        }

        errors
    }

    /// Validate against pilot and eligibility manifests.
    /// Deprecated: use `validate_against_stage_and_eligibility_with_policy` with `DefaultBatchCompositionPolicy` instead.
    #[deprecated = "Use validate_against_stage_and_eligibility_with_policy with DefaultBatchCompositionPolicy"]
    pub fn validate_against_stage_and_eligibility(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
    ) -> Result<(), ExternalAssetNormalizationBatchError> {
        let errors = self.validate_against_stage_and_eligibility_with_policy(
            pilot,
            staging,
            eligibility,
            &DefaultBatchCompositionPolicy,
        );
        if errors.is_empty() {
            Ok(())
        } else {
            // SAFETY: errors is non-empty because we checked !errors.is_empty() above.
            #[allow(clippy::unwrap_used)]
            let first = errors.into_iter().next().unwrap();
            Err(first)
        }
    }

    /// Validate against pilot, staging, and eligibility manifests with policy, returning a strict result.
    /// Returns `Ok(())` if validation passes, or `Err` with the list of validation errors.
    pub fn validate_against_stage_and_eligibility_strict(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        policy: &dyn BatchCompositionPolicy,
    ) -> Result<(), BatchValidationErrors> {
        let errors = self.validate_against_stage_and_eligibility_with_policy(
            pilot,
            staging,
            eligibility,
            policy,
        );
        if errors.is_empty() {
            Ok(())
        } else {
            Err(errors)
        }
    }
}
