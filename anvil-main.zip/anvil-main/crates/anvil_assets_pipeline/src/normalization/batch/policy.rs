use std::collections::BTreeMap;
use crate::ExternalAssetFamily;

/// Policy for composing normalization batches.
pub trait BatchCompositionPolicy: Send + Sync {
    /// Returns the expected count of records per family.
    fn expected_family_counts(&self) -> BTreeMap<ExternalAssetFamily, usize>;
    /// Returns the maximum batch size.
    fn max_batch_size(&self) -> usize;
}

/// Default batch composition policy for NatureManufacture assets.
/// Defines the expected family counts and maximum batch size for NM asset batches.
pub struct DefaultBatchCompositionPolicy;

impl BatchCompositionPolicy for DefaultBatchCompositionPolicy {
    fn expected_family_counts(&self) -> BTreeMap<ExternalAssetFamily, usize> {
        let mut map = BTreeMap::new();
        map.insert(ExternalAssetFamily::GroundCover, 3);
        map.insert(ExternalAssetFamily::Mushroom, 2);
        map.insert(ExternalAssetFamily::Rock, 1);
        map.insert(ExternalAssetFamily::StumpRootLog, 3);
        map.insert(ExternalAssetFamily::Tree, 1);
        map
    }

    fn max_batch_size(&self) -> usize {
        10
    }
}

