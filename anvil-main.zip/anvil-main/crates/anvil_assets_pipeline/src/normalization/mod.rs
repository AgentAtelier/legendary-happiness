//! External asset normalization manifest: FBX to glTF/glb conversion and validation.

mod batch;
mod execution;
mod glb;

/// Module for batch composition policies and validation.
pub use batch::{
    BatchCompositionPolicy, BatchValidationErrors, DefaultBatchCompositionPolicy, NormalizedGlb,
    ExternalAssetNormalizationBatchError, ExternalAssetNormalizationBatchManifest,
    ExternalAssetNormalizationBatchSelection,
};
/// Module for execution records and manifests.
pub use execution::{
    ExternalAssetNormalizationExecutionError, ExternalAssetNormalizationExecutionManifest,
    ExternalAssetNormalizationExecutionRecord, ExternalAssetNormalizationExecutionStatus,
};
/// Module for GLB building and validation.
#[allow(deprecated)]
pub use glb::{
    build_normalized_glb_bytes, validate_normalized_glb_bytes, write_glb_to_writer,
};

use anvil_core::ArchetypeTag;
use thiserror::Error;

/// Errors that can occur during the normalization stage.
#[derive(Debug, PartialEq, Eq, Error)]
#[non_exhaustive]
pub enum NormalizationStageError {
    /// A required batch selection is missing for the given asset.
    #[error("missing selection: {0:?}")]
    MissingSelection(ArchetypeTag),
    /// The family composition for the given asset does not match expectations.
    #[error("family composition mismatch: {0:?}")]
    FamilyCompositionMismatch(ArchetypeTag),
    /// The target kind for the given asset does not match expectations.
    #[error("target kind mismatch: {0:?}")]
    TargetKindMismatch(ArchetypeTag),
    /// The given asset record is not eligible for normalization.
    #[error("record {0:?} is not eligible for normalization")]
    IneligibleRecord(ArchetypeTag),
    /// The given asset record has no source files.
    #[error("record {0:?} has no source files")]
    MissingSourceFiles(ArchetypeTag),
    /// The source asset path for normalization was not found.
    #[error("source asset path not found: {0}")]
    MissingSourceAssetPath(String),
    /// FBX inspection failed for the given reason.
    #[error("fbx inspection failed: {0}")]
    FbxInspection(String),
    /// The batch size does not match the expected size.
    #[error("wrong batch size: expected {expected}, actual {actual}")]
    WrongBatchSize { 
        /// The expected batch size.
        expected: usize, 
        /// The actual batch size.
        actual: usize 
    },
}
