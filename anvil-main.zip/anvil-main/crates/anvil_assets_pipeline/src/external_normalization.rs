//! External asset normalization manifest: FBX to glTF/glb conversion and validation.
//!
//! This module has been split. See the `normalization` module for the implementation.

pub use crate::normalization::*;
