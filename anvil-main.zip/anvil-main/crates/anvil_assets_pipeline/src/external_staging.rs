//! External asset staging manifest: staging decisions and output paths.
//!
//! This module has been split. See the `staging` module for the implementation.

pub use crate::staging::*;
