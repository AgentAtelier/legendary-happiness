//! External asset pilot manifest: the entry point for vendor asset registration.
//!
//! This module has been split. See the `pilot` module for the implementation.

pub use crate::pilot::*;
