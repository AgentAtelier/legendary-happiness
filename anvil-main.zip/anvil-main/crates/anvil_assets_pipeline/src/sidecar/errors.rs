//! Error types for external asset material sidecar manifests.

use crate::external_pilot::PackIdentityError;

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use thiserror::Error;

/// Validation errors for material sidecar manifests.
pub type SidecarValidationErrors = Vec<ExternalAssetMaterialSidecarError>;

/// Errors that can occur during the material sidecar validation stage.
#[derive(Debug, PartialEq, Eq, Serialize, Deserialize, Error)]
pub enum SidecarStageError {
    /// The record does not match its corresponding execution resolution.
    #[error("record {0:?} does not match execution resolution")]
    ExecutionMismatch(ArchetypeTag),
    /// The record's target output path does not match expectations.
    #[error("record {0:?} target output path mismatch")]
    OutputPathMismatch(ArchetypeTag),
    /// The record's material class does not match expectations.
    #[error("record {0:?} material class mismatch")]
    MaterialClassMismatch(ArchetypeTag),
    /// The record's texture bundle references do not match.
    #[error("record {0:?} texture bundle refs mismatch")]
    TextureBundleMismatch(ArchetypeTag),
    /// The record has no source texture files.
    #[error("record {0:?} has no source texture files")]
    MissingSourceTextureFiles(ArchetypeTag),
    /// The record is missing a source texture file.
    #[error("record {0:?} has missing source texture file: {1}")]
    MissingSourceTextureFile(ArchetypeTag, String),
    /// The record has an invalid slot binding.
    #[error("record {0:?} has invalid slot binding: {1}")]
    InvalidSlotBinding(ArchetypeTag, String),
    /// The record is missing a required channel.
    #[error("record {0:?} missing required channel: {1}")]
    MissingRequiredChannel(ArchetypeTag, &'static str),
    /// The record has an invalid material entry ID.
    #[error("record {0:?} invalid material entry id: {1}")]
    InvalidMaterialEntryId(ArchetypeTag, String),
}

/// Errors that can occur when loading or validating an external asset material sidecar manifest.
#[derive(Debug, Error)]
pub enum ExternalAssetMaterialSidecarError {
    /// Failed to read the manifest file from disk.
    #[error("failed to read external asset material sidecar manifest: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the manifest JSON.
    #[error("failed to parse external asset material sidecar manifest: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The manifest contains no records.
    #[error("external asset material sidecar manifest has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id in external asset material sidecar manifest: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// The manifest records are not sorted deterministically.
    #[error("external asset material sidecar manifest is not deterministically ordered")]
    UnsortedManifest,

    /// A required source pack field is blank or missing.
    #[error("external asset material sidecar source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// The source manifest file referenced by the sidecar manifest was not found.
    #[error("external asset material sidecar source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),

    /// The source pack in the sidecar manifest does not match the pilot, staging, eligibility, or execution manifests.
    #[error(
        "external asset material sidecar source pack does not match pilot/staging/eligibility/execution"
    )]
    SourcePackMismatch,

    /// An error occurred while validating pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// A record does not match its corresponding execution resolution.
    #[error("external asset material sidecar record {0:?} does not match execution resolution")]
    ExecutionMismatch(ArchetypeTag),

    /// A record's target output path does not match expectations.
    #[error("external asset material sidecar record {0:?} target output path mismatch")]
    OutputPathMismatch(ArchetypeTag),

    /// A record's material class does not match expectations.
    #[error("external asset material sidecar record {0:?} material class mismatch")]
    MaterialClassMismatch(ArchetypeTag),

    /// A record's texture bundle references do not match.
    #[error("external asset material sidecar record {0:?} source texture bundle refs mismatch")]
    TextureBundleMismatch(ArchetypeTag),

    /// A record has no source texture files.
    #[error("external asset material sidecar record {0:?} has no source texture files")]
    MissingSourceTextureFiles(ArchetypeTag),

    /// A record is missing a source texture file.
    #[error("external asset material sidecar record {0:?} has missing source texture file: {1}")]
    MissingSourceTextureFile(ArchetypeTag, String),

    /// A record has an invalid slot binding.
    #[error("external asset material sidecar record {0:?} has invalid slot binding: {1}")]
    InvalidSlotBinding(ArchetypeTag, String),

    /// A record is missing a required channel semantic.
    #[error(
        "external asset material sidecar record {0:?} is missing required channel semantic: {1}"
    )]
    MissingRequiredChannel(ArchetypeTag, String),

    /// A record has an invalid material entry ID.
    #[error(
        "external asset material sidecar record {0:?} has invalid normalized material entry id: {1}"
    )]
    InvalidMaterialEntryId(ArchetypeTag, String),
}
