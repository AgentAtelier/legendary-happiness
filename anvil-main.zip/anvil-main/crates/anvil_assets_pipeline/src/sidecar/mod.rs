//! External asset material sidecar manifest module.

mod authority;
mod errors;
mod manifest;
mod report;
mod types;

pub use errors::{
    ExternalAssetMaterialSidecarError, SidecarStageError, SidecarValidationErrors,
};
pub use manifest::ExternalAssetMaterialSidecarManifest;
pub use report::ExternalAssetMaterialSidecarReport;
pub use types::{
    ExternalAssetMaterialChannelMapping, ExternalAssetMaterialChannelSemantic,
    ExternalAssetMaterialSidecarRecord, MaterialSlotBindingBuilder,
    ExternalAssetMaterialSlotBinding,
};
