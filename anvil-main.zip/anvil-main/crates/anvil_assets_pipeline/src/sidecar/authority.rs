//! Authority validation for external asset material sidecar manifests.

use anvil_core::arche;
use std::collections::{BTreeMap, BTreeSet};
use std::path::Path;

use crate::{
    ExternalAssetNormalizationEligibilityManifest,
    ExternalAssetNormalizationExecutionManifest, ExternalAssetNormalizationStageManifest,
    ExternalAssetPilotManifest,
};

use super::{ExternalAssetMaterialSidecarError, SidecarValidationErrors};
use super::types::ExternalAssetMaterialChannelSemantic;

impl super::ExternalAssetMaterialSidecarManifest {
    /// Validate this manifest against authority manifests (pilot, staging, eligibility, execution).
    /// Checks that all records match across manifests and that all references are consistent.
    pub fn validate_against_authority(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        execution: &ExternalAssetNormalizationExecutionManifest,
    ) -> SidecarValidationErrors {
        let mut errors = SidecarValidationErrors::new();

        if self.source_pack != pilot.source_pack
            || self.source_pack != staging.source_pack
            || self.source_pack != eligibility.source_pack
            || self.source_pack != execution.source_pack
        {
            errors.push(ExternalAssetMaterialSidecarError::SourcePackMismatch);
            return errors;
        }

        let pilot_map = pilot.registration_map();
        let staging_by_id: BTreeMap<_, _> = staging
            .records
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();
        let eligibility_by_id: BTreeMap<_, _> = eligibility
            .records()
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();
        let execution_by_id: BTreeMap<_, _> = execution
            .records
            .iter()
            .map(|record| (record.normalized_id.as_str().to_string(), record))
            .collect();

        let sidecar_ids: BTreeSet<_> = self
            .records
            .iter()
            .map(|record| record.normalized_id.as_str().to_string())
            .collect();
        let execution_ids: BTreeSet<_> = execution
            .records
            .iter()
            .map(|record| record.normalized_id.as_str().to_string())
            .collect();
        if sidecar_ids != execution_ids {
            errors.push(ExternalAssetMaterialSidecarError::ExecutionMismatch(
                arche!("nm_forest_env_material_sidecar_batch"),
            ));
        }

        for record in &self.records {
            let pilot_registration =
                pilot_map.get(record.normalized_id.as_str()).ok_or_else(|| {
                    ExternalAssetMaterialSidecarError::ExecutionMismatch(
                        record.normalized_id.clone(),
                    )
                });
            let pilot_registration = match pilot_registration {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let staging_record =
                staging_by_id
                    .get(record.normalized_id.as_str())
                    .ok_or_else(|| {
                        ExternalAssetMaterialSidecarError::ExecutionMismatch(
                            record.normalized_id.clone(),
                        )
                    });
            let staging_record = match staging_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let eligibility_record = eligibility_by_id
                .get(record.normalized_id.as_str())
                .ok_or_else(|| {
                    ExternalAssetMaterialSidecarError::ExecutionMismatch(
                        record.normalized_id.clone(),
                    )
                });
            let eligibility_record = match eligibility_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            let execution_record = execution_by_id
                .get(record.normalized_id.as_str())
                .ok_or_else(|| {
                    ExternalAssetMaterialSidecarError::ExecutionMismatch(
                        record.normalized_id.clone(),
                    )
                });
            let execution_record = match execution_record {
                Ok(r) => r,
                Err(e) => {
                    errors.push(e);
                    continue;
                }
            };

            if pilot_registration.family != record.family
                || pilot_registration.category != record.category
                || pilot_registration.source_files != staging_record.source_files
            {
                errors.push(ExternalAssetMaterialSidecarError::ExecutionMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if staging_record.target_output_path != record.normalized_mesh_output_path
                || execution_record.target_output_path != record.normalized_mesh_output_path
            {
                errors.push(ExternalAssetMaterialSidecarError::OutputPathMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if eligibility_record.likely_material_class != record.normalized_material_class {
                errors.push(ExternalAssetMaterialSidecarError::MaterialClassMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if staging_record.texture_bundle_refs != record.source_texture_bundle_refs
                || execution_record.texture_bundle_refs != record.source_texture_bundle_refs
            {
                errors.push(ExternalAssetMaterialSidecarError::TextureBundleMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if execution_record.material_slot_count != record.material_slot_bindings.len()
                || execution_record.submesh_count != record.material_slot_bindings.len()
            {
                errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                    record.normalized_id.clone(),
                    "slot count does not match execution".to_string(),
                ));
            }

            let mut seen_slots = BTreeSet::new();
            for (expected_index, slot_binding) in record.material_slot_bindings.iter().enumerate() {
                if slot_binding.material_slot_index != expected_index {
                    errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                        record.normalized_id.clone(),
                        format!(
                            "expected slot index {expected_index} but found {}",
                            slot_binding.material_slot_index
                        ),
                    ));
                }
                if !seen_slots.insert(slot_binding.material_slot_index) {
                    errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                        record.normalized_id.clone(),
                        format!("duplicate slot index {}", slot_binding.material_slot_index),
                    ));
                }
                if slot_binding.primitive_indices != vec![slot_binding.material_slot_index] {
                    errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                        record.normalized_id.clone(),
                        "primitive indices must mirror the slot index for the bounded first pass"
                            .to_string(),
                    ));
                }
                if slot_binding.material_class != record.normalized_material_class {
                    errors.push(ExternalAssetMaterialSidecarError::MaterialClassMismatch(
                        record.normalized_id.clone(),
                    ));
                }
                if slot_binding
                    .normalized_material_entry_id
                    .as_str()
                    .trim()
                    .is_empty()
                {
                    errors.push(ExternalAssetMaterialSidecarError::InvalidMaterialEntryId(
                        record.normalized_id.clone(),
                        "blank normalized material entry id".to_string(),
                    ));
                }
                if slot_binding.channel_mappings.is_empty() {
                    errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                        record.normalized_id.clone(),
                        format!(
                            "slot {} has no channel mappings",
                            slot_binding.material_slot_index
                        ),
                    ));
                }

                let mut semantic_seen = BTreeSet::new();
                let mut previous_semantic = None::<ExternalAssetMaterialChannelSemantic>;
                for channel in &slot_binding.channel_mappings {
                    if channel.source_texture_bundle_ref.as_str().trim().is_empty() {
                        errors.push(ExternalAssetMaterialSidecarError::TextureBundleMismatch(
                            record.normalized_id.clone(),
                        ));
                    }
                    if !record
                        .source_texture_bundle_refs
                        .iter()
                        .any(|bundle| bundle == &channel.source_texture_bundle_ref)
                    {
                        errors.push(ExternalAssetMaterialSidecarError::TextureBundleMismatch(
                            record.normalized_id.clone(),
                        ));
                    }
                    if channel.source_texture_file_ref.trim().is_empty() {
                        errors.push(ExternalAssetMaterialSidecarError::MissingSourceTextureFile(
                            record.normalized_id.clone(),
                            "blank texture file reference".to_string(),
                        ));
                    }
                    let texture_path = self
                        .source_pack
                        .source_root
                        .join(&channel.source_texture_file_ref);
                    if !texture_path.exists() {
                        errors.push(ExternalAssetMaterialSidecarError::MissingSourceTextureFile(
                            record.normalized_id.clone(),
                            channel.source_texture_file_ref.clone(),
                        ));
                    }
                    if !record
                        .source_texture_file_refs
                        .iter()
                        .any(|reference| reference == &channel.source_texture_file_ref)
                    {
                        errors.push(ExternalAssetMaterialSidecarError::MissingSourceTextureFile(
                            record.normalized_id.clone(),
                            channel.source_texture_file_ref.clone(),
                        ));
                    }
                    if !semantic_seen.insert(channel.semantic) {
                        errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                            record.normalized_id.clone(),
                            format!("duplicate channel semantic {}", channel.semantic),
                        ));
                    }
                    if let Some(previous) = previous_semantic && previous > channel.semantic {
                        errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                            record.normalized_id.clone(),
                            "channel mappings are not deterministically ordered".to_string(),
                        ));
                    }
                    previous_semantic = Some(channel.semantic);
                }

                let required_channels = record
                    .normalized_material_class
                    .required_channels(eligibility_record.alpha_cutout_required);
                let channel_semantics: BTreeSet<_> = slot_binding
                    .channel_mappings
                    .iter()
                    .map(|m| m.semantic)
                    .collect();
                for req in &required_channels {
                    if !channel_semantics.contains(req) {
                        errors.push(ExternalAssetMaterialSidecarError::MissingRequiredChannel(
                            record.normalized_id.clone(),
                            req.to_string(),
                        ));
                    }
                }
            }

            let has_alpha_cutout = record.material_slot_bindings.iter().any(|slot_binding| {
                slot_binding.channel_mappings.iter().any(|channel| {
                    matches!(
                        channel.semantic,
                        ExternalAssetMaterialChannelSemantic::AlphaCutout
                    )
                })
            });
            if eligibility_record.alpha_cutout_required && !has_alpha_cutout {
                errors.push(ExternalAssetMaterialSidecarError::MissingRequiredChannel(
                    record.normalized_id.clone(),
                    ExternalAssetMaterialChannelSemantic::AlphaCutout.to_string(),
                ));
            }
        }

        errors
    }

    /// Validate this manifest against authority manifests, returning a strict result.
    /// Returns `Ok(())` if validation passes, or `Err` with the list of errors.
    pub fn validate_against_authority_strict(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        execution: &ExternalAssetNormalizationExecutionManifest,
    ) -> Result<(), SidecarValidationErrors> {
        let errs = self.validate_against_authority(pilot, staging, eligibility, execution);
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }

    /// Resolve a material sidecar report from this manifest and the authority manifests.
    /// Validates the manifest against all authority manifests and produces a report.
    pub fn resolve_report(
        &self,
        pilot: &ExternalAssetPilotManifest,
        staging: &ExternalAssetNormalizationStageManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
        execution: &ExternalAssetNormalizationExecutionManifest,
        execution_report_path: &Path,
        report_path: &Path,
    ) -> Result<super::report::ExternalAssetMaterialSidecarReport, SidecarValidationErrors> {
        self.validate_against_authority_strict(pilot, staging, eligibility, execution)?;
        Ok(super::report::ExternalAssetMaterialSidecarReport {
            source_pack: self.source_pack.clone(),
            batch_name: self.batch_name.clone(),
            report_path: report_path.to_path_buf(),
            execution_report_path: execution_report_path.to_path_buf(),
            output_root: execution.output_root.clone(),
            records: self.records.clone(),
            warnings: vec![],
        })
    }
}
