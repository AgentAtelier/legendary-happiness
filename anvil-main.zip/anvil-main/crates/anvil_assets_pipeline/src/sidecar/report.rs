//! External asset material sidecar report.

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

use super::types::ExternalAssetMaterialSidecarRecord;
use crate::ExternalAssetPackIdentity;

/// A report containing validated external asset material sidecar data.
/// This is the output of validating a material sidecar manifest against authority manifests.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetMaterialSidecarReport {
    /// The source pack identity that these records belong to.
    pub source_pack: ExternalAssetPackIdentity,
    /// The name of the batch.
    pub batch_name: String,
    /// Path to this report file.
    pub report_path: PathBuf,
    /// Path to the execution report.
    pub execution_report_path: PathBuf,
    /// The root directory for output files.
    pub output_root: PathBuf,
    /// The list of validated material sidecar records.
    pub records: Vec<ExternalAssetMaterialSidecarRecord>,
    /// Any warnings generated during validation.
    #[serde(default)]
    pub warnings: Vec<String>,
}
