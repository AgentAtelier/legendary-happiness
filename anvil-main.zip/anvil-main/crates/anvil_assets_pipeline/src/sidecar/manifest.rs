//! External asset material sidecar manifest.

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;

use crate::pipeline::{ManifestError, PipelineManifest};
use crate::ExternalAssetPackIdentity;

use super::{ExternalAssetMaterialSidecarError, SidecarStageError, SidecarValidationErrors};
use super::types::ExternalAssetMaterialSidecarRecord;

/// Manifest for external asset material sidecar data.
/// Contains material configurations for all normalized meshes in a batch.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetMaterialSidecarManifest {
    /// The source pack identity that these sidecar records belong to.
    pub source_pack: ExternalAssetPackIdentity,
    /// The name of the batch.
    pub batch_name: String,
    /// The list of material sidecar records, one per normalized mesh.
    pub records: Vec<ExternalAssetMaterialSidecarRecord>,
}

impl PipelineManifest for ExternalAssetMaterialSidecarManifest {
    type Record = ExternalAssetMaterialSidecarRecord;
    type StageError = SidecarStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ManifestError::BlankField("normalized_id"));
            }
            if record.normalized_mesh_output_path.is_absolute()
                || !record
                    .normalized_mesh_output_path
                    .to_string_lossy()
                    .starts_with(crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX)
            {
                errors.push(ManifestError::StageSpecific(
                    SidecarStageError::OutputPathMismatch(record.normalized_id.clone()),
                ));
            }
            if record.source_texture_bundle_refs.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    SidecarStageError::TextureBundleMismatch(record.normalized_id.clone()),
                ));
            }
            if record.source_texture_file_refs.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    SidecarStageError::MissingSourceTextureFiles(record.normalized_id.clone()),
                ));
            }
            if record.material_slot_bindings.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    SidecarStageError::InvalidSlotBinding(
                        record.normalized_id.clone(),
                        "missing slot bindings".to_string(),
                    ),
                ));
            }
        }
        errors
    }
}

impl ExternalAssetMaterialSidecarManifest {
    /// Load a material sidecar manifest from a JSON file at the given path.
    /// The manifest is validated and records are sorted by normalized ID.
    pub fn load(path: &Path) -> Result<Self, SidecarValidationErrors> {
        let content = fs::read_to_string(path)
            .map_err(|e| vec![ExternalAssetMaterialSidecarError::IoError(e)])?;
        let manifest: Self = serde_json::from_str(&content)
            .map_err(|e| vec![ExternalAssetMaterialSidecarError::ParseError(e)])?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        manifest
            .records
            .sort_by(|a, b| a.normalized_id.as_str().cmp(b.normalized_id.as_str()));
        manifest.validate_strict()?;
        Ok(manifest)
    }

    /// Validate the manifest structure.
    /// Checks for empty records, missing source manifest, duplicate IDs, ordering,
    /// and record-level validation (output paths, texture references, slot bindings).
    pub fn validate(&self) -> SidecarValidationErrors {
        let mut errors = SidecarValidationErrors::new();

        if self.records.is_empty() {
            errors.push(ExternalAssetMaterialSidecarError::EmptyManifest);
            return errors;
        }

        let pack_errors = self.source_pack.validate();
        // Pack identity errors are now returned as ValidationErrors (Vec<AnvilCoreError>)
        // For now we skip them since we can't easily convert to ExternalAssetMaterialSidecarError
        let _ = pack_errors;

        if !self.source_pack.source_manifest.is_absolute() {
            errors.push(ExternalAssetMaterialSidecarError::BlankPackField(
                "source_manifest",
            ));
        }
        if !self.source_pack.source_manifest.exists() {
            errors.push(ExternalAssetMaterialSidecarError::MissingSourceManifest(
                self.source_pack.source_manifest.clone(),
            ));
        }

        let mut seen = BTreeSet::new();
        let mut previous = None::<&str>;
        for record in &self.records {
            if !seen.insert(record.normalized_id.as_str().to_string()) {
                errors.push(ExternalAssetMaterialSidecarError::DuplicateNormalizedId(
                    record.normalized_id.clone(),
                ));
            }
            let current = record.normalized_id.as_str();
            if let Some(previous) = previous && previous > current {
                errors.push(ExternalAssetMaterialSidecarError::UnsortedManifest);
            }
            previous = Some(current);

            if record.normalized_mesh_output_path.is_absolute()
                || !record
                    .normalized_mesh_output_path
                    .to_string_lossy()
                    .starts_with(crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX)
            {
                errors.push(ExternalAssetMaterialSidecarError::OutputPathMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if record.source_texture_bundle_refs.is_empty() {
                errors.push(ExternalAssetMaterialSidecarError::TextureBundleMismatch(
                    record.normalized_id.clone(),
                ));
            }
            if record.source_texture_file_refs.is_empty() {
                errors.push(
                    ExternalAssetMaterialSidecarError::MissingSourceTextureFiles(
                        record.normalized_id.clone(),
                    ),
                );
            }
            if record.material_slot_bindings.is_empty() {
                errors.push(ExternalAssetMaterialSidecarError::InvalidSlotBinding(
                    record.normalized_id.clone(),
                    "missing slot bindings".to_string(),
                ));
            }
        }

        errors
    }

    /// Validate the manifest and return an error if any validation errors exist.
    /// Returns `Ok(())` if validation passes, or `Err` with the list of errors.
    pub fn validate_strict(&self) -> Result<(), SidecarValidationErrors> {
        let errs = self.validate();
        if errs.is_empty() {
            Ok(())
        } else {
            Err(errs)
        }
    }
}
