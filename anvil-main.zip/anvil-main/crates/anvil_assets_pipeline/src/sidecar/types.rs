//! External asset material sidecar types: enums and structs.

use serde::{Deserialize, Serialize};
use std::fmt;

use crate::external_eligibility::ExternalAssetMaterialClass;

/// Semantic meaning of a material channel in the external asset pipeline.
/// These semantics determine how texture data is interpreted and used in rendering.
#[non_exhaustive]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetMaterialChannelSemantic {
    /// Base color (albedo) texture channel.
    BaseColor,
    /// Normal map texture channel.
    Normal,
    /// Packed mask texture channel (typically contains metallic, roughness, AO).
    PackedMask,
    /// Opacity texture channel.
    Opacity,
    /// Alpha cutout texture channel for transparency masking.
    AlphaCutout,
}

impl fmt::Display for ExternalAssetMaterialChannelSemantic {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::BaseColor => "base_color",
            Self::Normal => "normal",
            Self::PackedMask => "packed_mask",
            Self::Opacity => "opacity",
            Self::AlphaCutout => "alpha_cutout",
        };
        write!(f, "{}", s)
    }
}

/// A mapping of a material channel to its source texture.
/// Describes which source texture file provides data for a specific channel semantic.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetMaterialChannelMapping {
    /// The semantic meaning of this channel.
    pub semantic: ExternalAssetMaterialChannelSemantic,
    /// Reference to the source texture bundle containing this channel's data.
    pub source_texture_bundle_ref: anvil_core::ArchetypeTag,
    /// Reference to the specific file within the texture bundle.
    pub source_texture_file_ref: String,
    /// Optional notes about this channel mapping.
    #[serde(default)]
    pub notes: Vec<String>,
}

/// A binding of a material slot to its channels and properties.
/// Describes how a single material slot is configured, including which textures
/// are used for each channel semantic.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetMaterialSlotBinding {
    /// The index of this material slot within the mesh.
    pub material_slot_index: usize,
    /// The indices of primitives that use this material slot.
    pub primitive_indices: Vec<usize>,
    /// The normalized material entry identifier for this slot.
    pub normalized_material_entry_id: anvil_core::ArchetypeTag,
    /// The material class for this slot.
    pub material_class: ExternalAssetMaterialClass,
    /// The list of channel mappings for this material slot.
    #[serde(default)]
    pub channel_mappings: Vec<ExternalAssetMaterialChannelMapping>,
    /// Optional notes about this material slot binding.
    #[serde(default)]
    pub notes: Vec<String>,
}

impl ExternalAssetMaterialSlotBinding {
    /// Create a new builder for this type.
    pub fn builder() -> MaterialSlotBindingBuilder {
        MaterialSlotBindingBuilder::new()
    }
}

/// Builder for [`ExternalAssetMaterialSlotBinding`].
///
/// Required fields:
/// - `material_slot_index`
/// - `normalized_material_entry_id`
/// - `material_class`
#[derive(Default)]
pub struct MaterialSlotBindingBuilder {
    material_slot_index: Option<usize>,
    primitive_indices: Vec<usize>,
    normalized_material_entry_id: Option<anvil_core::ArchetypeTag>,
    material_class: Option<ExternalAssetMaterialClass>,
    channel_mappings: Vec<ExternalAssetMaterialChannelMapping>,
    notes: Vec<String>,
}

impl MaterialSlotBindingBuilder {
    /// Create a new builder with default values.
    pub fn new() -> Self {
        Self {
            material_slot_index: None,
            primitive_indices: vec![],
            normalized_material_entry_id: None,
            material_class: None,
            channel_mappings: vec![],
            notes: vec![],
        }
    }

    /// Required. Sets the material slot index.
    pub fn with_slot_index(mut self, idx: usize) -> Self {
        self.material_slot_index = Some(idx);
        self
    }

    /// Sets the primitive indices for this material slot.
    pub fn with_primitive_indices(mut self, indices: Vec<usize>) -> Self {
        self.primitive_indices = indices;
        self
    }

    /// Add a primitive index to this material slot.
    pub fn add_primitive(mut self, idx: usize) -> Self {
        self.primitive_indices.push(idx);
        self
    }

    /// Required. Sets the normalized material entry ID.
    pub fn with_material_entry_id(mut self, id: anvil_core::ArchetypeTag) -> Self {
        self.normalized_material_entry_id = Some(id);
        self
    }

    /// Required. Sets the material class.
    pub fn with_material_class(mut self, cls: ExternalAssetMaterialClass) -> Self {
        self.material_class = Some(cls);
        self
    }

    /// Add a channel mapping to this material slot.
    pub fn add_channel_mapping(mut self, mapping: ExternalAssetMaterialChannelMapping) -> Self {
        self.channel_mappings.push(mapping);
        self
    }

    /// Set the notes for this material slot.
    pub fn with_notes(mut self, notes: Vec<String>) -> Self {
        self.notes = notes;
        self
    }

    /// Build the material slot binding.
    /// Returns an error if any required field is missing.
    pub fn build(self) -> Result<ExternalAssetMaterialSlotBinding, String> {
        Ok(ExternalAssetMaterialSlotBinding {
            material_slot_index: self.material_slot_index.ok_or_else(|| {
                "MaterialSlotBindingBuilder: material_slot_index is required".to_string()
            })?,
            primitive_indices: self.primitive_indices,
            normalized_material_entry_id: self.normalized_material_entry_id.ok_or_else(|| {
                "MaterialSlotBindingBuilder: normalized_material_entry_id is required".to_string()
            })?,
            material_class: self.material_class.ok_or_else(|| {
                "MaterialSlotBindingBuilder: material_class is required".to_string()
            })?,
            channel_mappings: self.channel_mappings,
            notes: self.notes,
        })
    }
}

/// A record in the external asset material sidecar manifest.
/// Contains all information about how materials are configured for a normalized mesh.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetMaterialSidecarRecord {
    /// The normalized identifier for this asset.
    pub normalized_id: anvil_core::ArchetypeTag,
    /// The output path for the normalized mesh.
    pub normalized_mesh_output_path: std::path::PathBuf,
    /// The family of this asset.
    pub family: crate::ExternalAssetFamily,
    /// The category of this asset.
    pub category: anvil_assets::AssetCategory,
    /// The material class for this asset.
    pub normalized_material_class: ExternalAssetMaterialClass,
    /// References to the source texture bundles used by this asset.
    pub source_texture_bundle_refs: Vec<anvil_core::ArchetypeTag>,
    /// References to the source texture files used by this asset.
    pub source_texture_file_refs: Vec<String>,
    /// The material slot bindings for this asset.
    pub material_slot_bindings: Vec<ExternalAssetMaterialSlotBinding>,
    /// Optional notes about this material sidecar record.
    #[serde(default)]
    pub notes: Vec<String>,
    /// Known limitations for this material configuration.
    #[serde(default)]
    pub limitations: Vec<String>,
}
