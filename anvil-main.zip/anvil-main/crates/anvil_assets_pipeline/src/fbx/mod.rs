//! FBX file parsing and GLB conversion.
//!
//! This module provides a complete pipeline for parsing FBX binary files
//! and converting them to GLTF/GLB format.
//!
//! # Submodules
//!
//! - [`crate::fbx::accessors`] — Helper functions for extracting typed data from FBX nodes
//! - [`crate::fbx::parser`] — Low-level FBX binary format parsing
//! - [`crate::fbx::geometry`] — Geometry extraction, triangulation, and layer element sampling
//! - [`crate::fbx::glb`] — GLB conversion and serialization

use thiserror::Error;

/// Helper functions for extracting typed data from FBX nodes.
pub mod accessors;
/// Geometry extraction, triangulation, and layer element sampling.
pub mod geometry;
/// GLB conversion and serialization.
pub mod glb;
/// Low-level FBX binary format parsing.
pub mod parser;

/// Error type for FBX conversion operations.
#[derive(Debug, Error)]
pub enum ExternalFbxConversionError {
    /// Failed to read the FBX source file.
    #[error("failed to read FBX source: {0}")]
    Io(#[from] std::io::Error),

    /// The source file is not a valid binary FBX file (wrong header).
    #[error("fbx source is not a binary FBX file")]
    InvalidHeader,

    /// The FBX file is incomplete or truncated.
    #[error("fbx source is truncated")]
    Truncated,

    /// An FBX array exceeds the maximum allowed size.
    #[error("FBX array too large ({0} elements)")]
    ArrayTooLarge(usize),

    /// The FBX file exceeds the maximum allowed size (256 MB).
    #[error("FBX file too large ({0} bytes, max 256 MB)")]
    FileTooLarge(u64),

    /// The FBX file contains a property type that is not supported.
    #[error("fbx source contains unsupported property type {0:?}")]
    UnsupportedPropertyType(u8),

    /// The FBX file uses an array encoding that is not supported.
    #[error("fbx source contains unsupported array encoding {0}")]
    UnsupportedArrayEncoding(u32),

    /// The FBX geometry is missing required vertex or polygon index data.
    #[error("fbx source geometry is missing vertices or polygon indices")]
    MissingGeometryData,

    /// The vertex array has an invalid length.
    #[error("fbx source geometry contains an invalid vertex array length")]
    InvalidVertexArray,

    /// The polygon index sequence is invalid (e.g., wrong format).
    #[error("fbx source geometry contains an invalid polygon index sequence")]
    InvalidPolygonIndexSequence,

    /// The FBX file contains no geometry nodes.
    #[error("fbx source did not contain any geometry nodes")]
    MissingGeometry,

    /// Failed to serialize GLB JSON metadata.
    #[error("failed to serialize glb json: {0}")]
    Json(#[from] serde_json::Error),

    /// The conversion produced an invalid GLB buffer.
    #[error("fbx conversion produced invalid glb buffer")]
    InvalidGlb,
}

// Re-export public types and functions from submodules
pub use accessors::{child_int32_array, child_string, child_vec2_array, child_vec3_array, fbx_property_string};
pub use geometry::{
    append_padded, compute_bounds, collect_geometry_nodes, expand_polygon_values,
    expand_polygon_vertex_values, geometry_display_name, geometry_materials, geometry_normals,
    geometry_polygon_indices, geometry_uv0, geometry_vertices, positions_from_vertices,
    polygon_vertices, triangulate_polygon, ExternalFbxConversionSummary, ExternalFbxMesh,
    ExternalFbxPrimitive, LayerElement, LayerMappingMode, LayerReferenceMode, PrimitiveBuildData,
};
pub use glb::{convert_fbx_to_glb_bytes, inspect_fbx_source};
pub use parser::{FbxDocument, FbxNode, FbxProperty, Reader};
