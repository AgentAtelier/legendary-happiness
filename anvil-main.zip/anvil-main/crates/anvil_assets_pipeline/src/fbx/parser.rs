//! FBX binary parser — low-level FBX format reading.
//!
//! This module handles the FBX binary format parsing including:
//! - Binary chunk reading via [`Reader`]
//! - Property decoding via [`crate::fbx::parser::parse_property`]
//! - Node tree construction via [`crate::fbx::parser::parse_node`]
//! - Document parsing via [`crate::fbx::parser::parse_fbx_document`]

use flate2::read::ZlibDecoder;
use std::io::Read;

use crate::fbx::ExternalFbxConversionError;

/// Security limits for FBX parsing to prevent resource exhaustion attacks.
const MAX_ARRAY_LEN: usize = 16_000_000; // 16M elements
const MAX_DECOMPRESSED: u64 = 512 * 1024 * 1024; // 512 MB
const MAX_DEPTH: usize = 256;
const MAX_NODE_PROPERTIES: usize = 1_000_000; // 1M properties per node
const MAX_PROPERTY_LIST_LEN: usize = 1_000_000_000; // 1B bytes property list
const MAX_NAME_LEN: usize = 65_535; // Max for read_string safety

/// Internal FBX document representation — root of the node hierarchy.
/// This is the top-level container for all parsed FBX data.
#[derive(Debug, Clone, PartialEq)]
pub struct FbxDocument {
    /// All top-level nodes in the FBX document.
    pub nodes: Vec<FbxNode>,
}

/// A node in the FBX scene hierarchy.
/// Nodes form a tree structure representing the FBX scene graph.
#[derive(Debug, Clone, PartialEq)]
pub struct FbxNode {
    /// The name of this node.
    pub name: String,
    /// Properties attached to this node.
    pub properties: Vec<FbxProperty>,
    /// Child nodes of this node.
    pub children: Vec<FbxNode>,
}

/// A typed property value from an FBX node.
/// FBX properties can be scalar values, strings, or arrays of various types.
#[derive(Debug, Clone, PartialEq)]
pub enum FbxProperty {
    /// Boolean scalar value.
    Bool(bool),
    /// 16-bit signed integer.
    Int16(i16),
    /// 32-bit signed integer.
    Int32(i32),
    /// 64-bit signed integer.
    Int64(i64),
    /// 32-bit floating point.
    Float(f32),
    /// 64-bit floating point.
    Double(f64),
    /// UTF-8 string.
    String(String),
    /// Raw binary data.
    Raw(Vec<u8>),
    /// Array of boolean values.
    BoolArray(Vec<bool>),
    /// Array of 32-bit integers.
    Int32Array(Vec<i32>),
    /// Array of 64-bit integers.
    Int64Array(Vec<i64>),
    /// Array of 32-bit floats.
    FloatArray(Vec<f32>),
    /// Array of 64-bit floats.
    DoubleArray(Vec<f64>),
}

/// Low-level byte reader for FBX binary format.
/// Provides position-tracked reading of FBX binary data.
pub struct Reader<'a> {
    /// The underlying byte data.
    data: &'a [u8],
    /// Current read position.
    pos: usize,
}

impl<'a> Reader<'a> {
    /// Create a new reader at the specified position in the data.
    pub fn new(data: &'a [u8], pos: usize) -> Self {
        Self { data, pos }
    }

    /// Returns the number of bytes remaining to be read.
    fn remaining(&self) -> usize {
        self.data.len().saturating_sub(self.pos)
    }

    /// Read exactly `len` bytes from the current position.
    fn read_exact(&mut self, len: usize) -> Result<&'a [u8], ExternalFbxConversionError> {
        if self.remaining() < len {
            return Err(ExternalFbxConversionError::Truncated);
        }
        let start = self.pos;
        self.pos += len;
        Ok(&self.data[start..start + len])
    }

    /// Read a single byte (u8) from the current position.
    fn read_u8(&mut self) -> Result<u8, ExternalFbxConversionError> {
        Ok(*self
            .read_exact(1)?
            .first()
            .ok_or(ExternalFbxConversionError::Truncated)?)
    }

    /// Read a 32-bit unsigned integer (little-endian) from the current position.
    fn read_u32(&mut self) -> Result<u32, ExternalFbxConversionError> {
        let bytes = self.read_exact(4)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(u32::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_i16(&mut self) -> Result<i16, ExternalFbxConversionError> {
        let bytes = self.read_exact(2)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(i16::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_i32(&mut self) -> Result<i32, ExternalFbxConversionError> {
        let bytes = self.read_exact(4)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(i32::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_i64(&mut self) -> Result<i64, ExternalFbxConversionError> {
        let bytes = self.read_exact(8)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(i64::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_f32(&mut self) -> Result<f32, ExternalFbxConversionError> {
        let bytes = self.read_exact(4)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(f32::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_f64(&mut self) -> Result<f64, ExternalFbxConversionError> {
        let bytes = self.read_exact(8)?;
        #[allow(clippy::expect_used)]
        // SAFETY: read_exact(N) returns exactly N bytes or propagates Err above.
        Ok(f64::from_le_bytes(bytes.try_into().expect("slice length")))
    }

    fn read_string(&mut self, len: usize) -> Result<String, ExternalFbxConversionError> {
        let bytes = self.read_exact(len)?;
        Ok(String::from_utf8_lossy(bytes).to_string())
    }
}

/// Parse a typed array of elements from the FBX binary stream.
pub fn parse_array_bytes<T, F>(
    reader: &mut Reader<'_>,
    element_size: usize,
    mut decode: F,
) -> Result<Vec<T>, ExternalFbxConversionError>
where
    F: FnMut(&[u8]) -> Result<T, ExternalFbxConversionError>,
{
    let array_len = reader.read_u32()? as usize;
    if array_len > MAX_ARRAY_LEN {
        return Err(ExternalFbxConversionError::ArrayTooLarge(array_len));
    }
    let encoding = reader.read_u32()?;
    let compressed_len = reader.read_u32()? as usize;
    let raw_bytes = match encoding {
        0 => reader.read_exact(array_len * element_size)?.to_vec(),
        1 => {
            let compressed = reader.read_exact(compressed_len)?;
            let decoder = ZlibDecoder::new(compressed);
            let mut decompressed = Vec::with_capacity(array_len * element_size);
            let mut limited = decoder.take(MAX_DECOMPRESSED + 1);
            limited.read_to_end(&mut decompressed)?;
            if decompressed.len() as u64 > MAX_DECOMPRESSED {
                return Err(ExternalFbxConversionError::ArrayTooLarge(
                    decompressed.len(),
                ));
            }
            decompressed
        }
        other => return Err(ExternalFbxConversionError::UnsupportedArrayEncoding(other)),
    };
    if raw_bytes.len() != array_len * element_size {
        return Err(ExternalFbxConversionError::Truncated);
    }
    let mut values = Vec::with_capacity(array_len);
    for chunk in raw_bytes.chunks_exact(element_size) {
        values.push(decode(chunk)?);
    }
    Ok(values)
}

/// Decode a single FBX property from the binary stream.
pub fn parse_property(reader: &mut Reader<'_>) -> Result<FbxProperty, ExternalFbxConversionError> {
    let property_type = reader.read_u8()?;
    match property_type as char {
        'C' => Ok(FbxProperty::Bool(reader.read_u8()? != 0)),
        'Y' => Ok(FbxProperty::Int16(reader.read_i16()?)),
        'I' => Ok(FbxProperty::Int32(reader.read_i32()?)),
        'L' => Ok(FbxProperty::Int64(reader.read_i64()?)),
        'F' => Ok(FbxProperty::Float(reader.read_f32()?)),
        'D' => Ok(FbxProperty::Double(reader.read_f64()?)),
        // 64-bit integer encoded as 32-bit (legacy FBX)
        'e' => Ok(FbxProperty::Int32(reader.read_i32()?)),
        'S' => {
            let len = reader.read_u32()? as usize;
            Ok(FbxProperty::String(reader.read_string(len)?))
        }
        'R' => {
            let len = reader.read_u32()? as usize;
            Ok(FbxProperty::Raw(reader.read_exact(len)?.to_vec()))
        }
        'b' => Ok(FbxProperty::BoolArray(parse_array_bytes(
            reader,
            1,
            |bytes| Ok(bytes[0] != 0),
        )?)),
        'i' => Ok(FbxProperty::Int32Array(parse_array_bytes(
            reader,
            4,
            |bytes| {
                #[allow(clippy::expect_used)]
                Ok(i32::from_le_bytes(bytes.try_into().expect("slice length")))
            },
        )?)),
        'l' => Ok(FbxProperty::Int64Array(parse_array_bytes(
            reader,
            8,
            |bytes| {
                #[allow(clippy::expect_used)]
                Ok(i64::from_le_bytes(bytes.try_into().expect("slice length")))
            },
        )?)),
        'f' => Ok(FbxProperty::FloatArray(parse_array_bytes(
            reader,
            4,
            |bytes| {
                #[allow(clippy::expect_used)]
                Ok(f32::from_le_bytes(bytes.try_into().expect("slice length")))
            },
        )?)),
        'd' => Ok(FbxProperty::DoubleArray(parse_array_bytes(
            reader,
            8,
            |bytes| {
                #[allow(clippy::expect_used)]
                Ok(f64::from_le_bytes(bytes.try_into().expect("slice length")))
            },
        )?)),
        other => Err(ExternalFbxConversionError::UnsupportedPropertyType(
            other as u8,
        )),
    }
}

/// Parse a single FBX node from the binary stream.
pub fn parse_node(
    reader: &mut Reader<'_>,
    version: u32,
    depth: usize,
) -> Result<Option<FbxNode>, ExternalFbxConversionError> {
    // FBX version gate: 7.5+ uses extended offsets not yet supported
    if version >= 7500 {
        return Err(ExternalFbxConversionError::InvalidHeader);
    }
    if depth > MAX_DEPTH {
        return Err(ExternalFbxConversionError::Truncated);
    }
    let end_offset = reader.read_u32()? as usize;
    let num_properties = reader.read_u32()? as usize;
    let _property_list_len = reader.read_u32()? as usize;
    let name_len = reader.read_u8()? as usize;
    if end_offset == 0 && num_properties == 0 && name_len == 0 {
        return Ok(None);
    }
    // Bounds checks to prevent OOM attacks
    if num_properties > MAX_NODE_PROPERTIES {
        return Err(ExternalFbxConversionError::Truncated);
    }
    if _property_list_len > MAX_PROPERTY_LIST_LEN {
        return Err(ExternalFbxConversionError::Truncated);
    }
    if name_len > MAX_NAME_LEN {
        return Err(ExternalFbxConversionError::Truncated);
    }
    let name = reader.read_string(name_len)?;
    let mut properties = Vec::with_capacity(num_properties);
    for _ in 0..num_properties {
        properties.push(parse_property(reader)?);
    }
    let mut children = Vec::new();
    let max_children = MAX_NODE_PROPERTIES; // Same limit for children
    while reader.pos < end_offset && children.len() < max_children {
        if reader.remaining() >= 13
            && reader.data[reader.pos..reader.pos + 13]
                .iter()
                .all(|byte| *byte == 0)
        {
            reader.pos += 13;
            break;
        }
        match parse_node(reader, version, depth + 1)? {
            Some(child) => children.push(child),
            None => break,
        }
    }
    if reader.pos < end_offset {
        reader.pos = end_offset;
    }
    Ok(Some(FbxNode {
        name,
        properties,
        children,
    }))
}

/// Parse the entire FBX document from bytes.
pub fn parse_fbx_document(bytes: &[u8]) -> Result<FbxDocument, ExternalFbxConversionError> {
    const HEADER: &[u8] = b"Kaydara FBX Binary  \0\x1a\0";
    if bytes.len() < HEADER.len() + 4 || !bytes.starts_with(HEADER) {
        return Err(ExternalFbxConversionError::InvalidHeader);
    }
    #[allow(clippy::expect_used)]
    let version = u32::from_le_bytes(bytes[23..27].try_into().expect("header has version"));
    let mut reader = Reader::new(bytes, 27);
    let mut nodes = Vec::new();
    while reader.remaining() > 13 {
        let slice = &reader.data[reader.pos..reader.pos + 13];
        if slice.iter().all(|byte| *byte == 0) {
            break;
        }
        match parse_node(&mut reader, version, 0)? {
            Some(node) => nodes.push(node),
            None => break,
        }
    }
    Ok(FbxDocument { nodes })
}
