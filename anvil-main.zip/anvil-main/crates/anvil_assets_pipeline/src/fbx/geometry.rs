//! FBX geometry extraction — vertex, normal, UV, and index extraction.
//!
//! This module handles extracting geometric data from parsed FBX nodes,
//! including polygon triangulation and layer element sampling.

use crate::fbx::accessors::{child_int32_array, child_string, child_vec2_array, child_vec3_array, fbx_property_string};
use crate::fbx::parser::{FbxNode, FbxProperty};
use crate::fbx::ExternalFbxConversionError;

/// A single renderable primitive extracted from FBX geometry.
/// Represents a submesh with a specific material slot.
#[derive(Debug, Clone, PartialEq)]
pub struct ExternalFbxPrimitive {
    /// The material slot index for this primitive, if any.
    pub material_slot: Option<usize>,
    /// Vertex positions as [x, y, z] arrays.
    pub positions: Vec<[f32; 3]>,
    /// Vertex normals as [x, y, z] arrays, if present.
    pub normals: Option<Vec<[f32; 3]>>,
    /// Vertex UV coordinates as [u, v] arrays, if present.
    pub uvs: Option<Vec<[f32; 2]>>,
    /// Triangle indices for this primitive.
    pub indices: Vec<u32>,
}

/// A mesh containing one or more primitives (submeshes by material).
#[derive(Debug, Clone, PartialEq)]
pub struct ExternalFbxMesh {
    /// The name of this mesh.
    pub name: String,
    /// All primitives (submeshes) in this mesh.
    pub primitives: Vec<ExternalFbxPrimitive>,
}

/// Summary statistics for FBX conversion results.
#[derive(Debug, Clone, PartialEq)]
pub struct ExternalFbxConversionSummary {
    /// Name of the geometry that was converted.
    pub geometry_name: String,
    /// Total number of geometry nodes processed.
    pub geometry_count: usize,
    /// Total number of vertices across all primitives.
    pub vertex_count: usize,
    /// Total number of triangles across all primitives.
    pub triangle_count: usize,
    /// Whether UV channel 0 is present.
    pub has_uv0: bool,
    /// Whether normals are present.
    pub has_normals: bool,
    /// Number of unique material slots.
    pub material_slot_count: usize,
    /// Number of submeshes (primitives).
    pub submesh_count: usize,
}

/// How layer element values are mapped to geometry.
/// Describes how FBX layer data maps to vertices/polygons.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LayerMappingMode {
    /// Each polygon-vertex pair gets a unique value.
    ByPolygonVertex,
    /// Each polygon gets a single value (all vertices in the polygon share it).
    ByPolygon,
    /// Each control point (vertex) gets a single value.
    ByControlPoint,
    /// All geometry uses the same value.
    AllSame,
    /// Unknown mapping mode.
    Unknown,
}

/// How layer element values are referenced.
/// Describes the indexing method for layer data.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LayerReferenceMode {
    /// Values are stored directly.
    Direct,
    /// Values are stored as indices into a direct array.
    IndexToDirect,
    /// Unknown reference mode.
    Unknown,
}

/// A layer element (normal, UV, material) with its mapping and reference modes.
/// FBX stores geometry data in layers with flexible mapping and referencing.
#[derive(Debug, Clone, PartialEq)]
pub struct LayerElement<T> {
    /// How values are mapped to geometry.
    pub mapping: LayerMappingMode,
    /// How values are referenced.
    pub reference: LayerReferenceMode,
    /// Direct value storage.
    pub direct: Vec<T>,
    /// Index array for indexed access, if applicable.
    pub indices: Option<Vec<usize>>,
}

/// Internal builder for accumulating primitive data during triangulation.
/// Used to construct primitives incrementally as polygons are processed.
#[derive(Debug, Default, Clone)]
pub struct PrimitiveBuildData {
    /// The material slot index for this primitive.
    pub material_slot: Option<usize>,
    /// Accumulated vertex positions.
    pub positions: Vec<[f32; 3]>,
    /// Accumulated vertex normals, if present.
    pub normals: Option<Vec<[f32; 3]>>,
    /// Accumulated vertex UVs, if present.
    pub uvs: Option<Vec<[f32; 2]>>,
    /// Accumulated triangle indices.
    pub indices: Vec<u32>,
}

impl PrimitiveBuildData {
    /// Create a new builder with the specified material slot.
    pub fn new(material_slot: Option<usize>) -> Self {
        Self {
            material_slot,
            positions: Vec::new(),
            normals: None,
            uvs: None,
            indices: Vec::new(),
        }
    }

    /// Add a vertex to this primitive.
    /// If normals or UVs are not present, they are initialized.
    /// Missing normal/UV values are filled with zeros.
    pub fn push_vertex(
        &mut self,
        position: [f32; 3],
        normal: Option<[f32; 3]>,
        uv: Option<[f32; 2]>,
    ) {
        let index = self.positions.len() as u32;
        self.positions.push(position);
        if let Some(normal) = normal {
            self.normals.get_or_insert_with(Vec::new).push(normal);
        } else if let Some(normals) = self.normals.as_mut() {
            normals.push([0.0, 0.0, 0.0]);
        }
        if let Some(uv) = uv {
            self.uvs.get_or_insert_with(Vec::new).push(uv);
        } else if let Some(uvs) = self.uvs.as_mut() {
            uvs.push([0.0, 0.0]);
        }
        self.indices.push(index);
    }
}

/// Get a display name for a geometry node.
/// Tries to extract the name property, falls back to a generated name.
pub fn geometry_display_name(node: &FbxNode, index: usize) -> String {
    node.properties
        .iter()
        .find_map(fbx_property_string)
        .filter(|value| {
            value
                .chars()
                .all(|ch| ch.is_ascii_graphic() || ch.is_ascii_whitespace())
        })
        .map(|value| value.trim().to_string())
        .unwrap_or_else(|| format!("geometry_{index}"))
}

/// Extract vertex positions (as f64) from a Geometry node.
/// Returns the Vertices child node's DoubleArray property if present.
pub fn geometry_vertices(node: &FbxNode) -> Option<&[f64]> {
    node.children.iter().find_map(|child| {
        if child.name == "Vertices" {
            child
                .properties
                .first()
                .and_then(|property| match property {
                    FbxProperty::DoubleArray(values) => Some(values.as_slice()),
                    _ => None,
                })
        } else {
            None
        }
    })
}

/// Extract polygon vertex indices from a Geometry node.
/// Returns the PolygonVertexIndex child node's Int32Array property if present.
pub fn geometry_polygon_indices(node: &FbxNode) -> Option<&[i32]> {
    node.children.iter().find_map(|child| {
        if child.name == "PolygonVertexIndex" {
            child
                .properties
                .first()
                .and_then(|property| match property {
                    FbxProperty::Int32Array(values) => Some(values.as_slice()),
                    _ => None,
                })
        } else {
            None
        }
    })
}

/// Recursively collect all Geometry nodes from the FBX document.
/// Stops at MAX_DEPTH to prevent stack overflow on malformed files.
pub fn collect_geometry_nodes<'a>(
    node: &'a FbxNode,
    geometries: &mut Vec<&'a FbxNode>,
    depth: usize,
) {
    const MAX_DEPTH: usize = 256;
    if depth > MAX_DEPTH {
        return;
    }
    if node.name == "Geometry" {
        geometries.push(node);
    }
    for child in &node.children {
        collect_geometry_nodes(child, geometries, depth + 1);
    }
}

/// Parse a LayerElement from an FBX node.
/// Extracts mapping mode, reference mode, direct values, and indices.
/// Returns None if the element is not found or cannot be parsed.
pub fn child_layer_element<T: Clone>(
    node: &FbxNode,
    element_name: &str,
    value_name: &str,
    index_name: Option<&str>,
    decode: fn(&FbxNode, &str) -> Option<Vec<T>>,
) -> Option<LayerElement<T>> {
    node.children.iter().find_map(|child| {
        if child.name != element_name {
            return None;
        }
        let mapping = match child_string(child, "MappingInformationType")
            .as_deref()
            .unwrap_or("Unknown")
        {
            "ByPolygonVertex" => LayerMappingMode::ByPolygonVertex,
            "ByPolygon" => LayerMappingMode::ByPolygon,
            "ByControlPoint" | "ByVertice" => LayerMappingMode::ByControlPoint,
            "AllSame" => LayerMappingMode::AllSame,
            _ => LayerMappingMode::Unknown,
        };
        let reference = match child_string(child, "ReferenceInformationType")
            .as_deref()
            .unwrap_or("Unknown")
        {
            "Direct" => LayerReferenceMode::Direct,
            "IndexToDirect" => LayerReferenceMode::IndexToDirect,
            _ => LayerReferenceMode::Unknown,
        };
        let direct = decode(child, value_name)?;
        let indices = index_name
            .and_then(|name| child_int32_array(child, name))
            .map(|values: Vec<i32>| {
                values
                    .into_iter()
                    .map(|value: i32| value.max(0) as usize)
                    .collect::<Vec<usize>>()
            });
        Some(LayerElement {
            mapping,
            reference,
            direct,
            indices,
        })
    })
}

/// Extract the normal layer from a Geometry node.
/// Returns LayerElementNormal data with mapping and reference info.
pub fn geometry_normals(node: &FbxNode) -> Option<LayerElement<[f32; 3]>> {
    child_layer_element(
        node,
        "LayerElementNormal",
        "Normals",
        Some("NormalsIndex"),
        child_vec3_array,
    )
}

/// Extract the UV layer from a Geometry node.
/// Returns LayerElementUV data for the first UV channel.
pub fn geometry_uv0(node: &FbxNode) -> Option<LayerElement<[f32; 2]>> {
    child_layer_element(
        node,
        "LayerElementUV",
        "UV",
        Some("UVIndex"),
        child_vec2_array,
    )
}

/// Extract the material layer from a Geometry node.
/// Returns LayerElementMaterial data with material slot indices.
pub fn geometry_materials(node: &FbxNode) -> Option<LayerElement<i32>> {
    child_layer_element(
        node,
        "LayerElementMaterial",
        "Materials",
        Some("MaterialsIndex"),
        child_int32_array,
    )
}

/// Convert FBX polygon indices into a list of polygons (vertex index lists).
/// FBX uses negative indices to mark polygon boundaries.
pub fn polygon_vertices(
    polygon_indices: &[i32],
) -> Result<Vec<Vec<u32>>, ExternalFbxConversionError> {
    let mut polygons = Vec::new();
    let mut polygon = Vec::new();
    for raw in polygon_indices {
        let value = if *raw < 0 {
            // unsigned_abs avoids overflow when raw == i32::MIN
            raw.unsigned_abs() as usize - 1
        } else {
            *raw as usize
        };
        polygon.push(value as u32);
        if *raw < 0 {
            if polygon.len() < 3 {
                return Err(ExternalFbxConversionError::InvalidPolygonIndexSequence);
            }
            polygons.push(std::mem::take(&mut polygon));
        }
    }
    if !polygon.is_empty() {
        return Err(ExternalFbxConversionError::InvalidPolygonIndexSequence);
    }
    Ok(polygons)
}

/// Triangulate a polygon into triangles using fan triangulation.
/// Assumes the polygon is convex. Returns triangles as arrays of three vertex indices.
pub fn triangulate_polygon(
    polygon: &[u32],
) -> Result<Vec<[usize; 3]>, ExternalFbxConversionError> {
    if polygon.len() < 3 {
        return Err(ExternalFbxConversionError::InvalidPolygonIndexSequence);
    }
    let mut triangles = Vec::with_capacity(polygon.len().saturating_sub(2));
    for index in 1..polygon.len() - 1 {
        triangles.push([0, index, index + 1]);
    }
    Ok(triangles)
}

/// Sample a layer element at a specific logical index.
pub fn sample_layer_element<T: Clone>(layer: &LayerElement<T>, logical_index: usize) -> Option<T> {
    let direct_index = match layer.reference {
        LayerReferenceMode::Direct => logical_index,
        LayerReferenceMode::IndexToDirect => layer
            .indices
            .as_ref()
            .and_then(|indices| indices.get(logical_index).copied())
            .unwrap_or(logical_index),
        LayerReferenceMode::Unknown => return None,
    };
    layer.direct.get(direct_index).cloned()
}

/// Sample a layer element at a polygon vertex position.
pub fn sample_polygon_vertex_layer<T: Clone>(
    layer: &LayerElement<T>,
    polygon_index: usize,
    polygon_vertex_index: usize,
    control_point_index: usize,
) -> Option<T> {
    let logical_index = match layer.mapping {
        LayerMappingMode::ByPolygonVertex => polygon_vertex_index,
        LayerMappingMode::ByPolygon => polygon_index,
        LayerMappingMode::ByControlPoint | LayerMappingMode::AllSame => control_point_index,
        LayerMappingMode::Unknown => return None,
    };
    sample_layer_element(layer, logical_index)
}

/// Sample a layer element at a polygon level.
pub fn sample_polygon_layer<T: Clone>(layer: &LayerElement<T>, polygon_index: usize) -> Option<T> {
    let logical_index = match layer.mapping {
        LayerMappingMode::ByPolygon | LayerMappingMode::ByPolygonVertex => polygon_index,
        LayerMappingMode::ByControlPoint | LayerMappingMode::AllSame => 0,
        LayerMappingMode::Unknown => return None,
    };
    sample_layer_element(layer, logical_index)
}

/// Expand polygon vertex values for a single polygon.
pub fn expand_polygon_vertex_values<T: Clone>(
    layer: &LayerElement<T>,
    polygon_index: usize,
    polygon: &[u32],
) -> Option<Vec<T>> {
    let mut values = Vec::with_capacity(polygon.len());
    for (polygon_vertex_index, control_point) in polygon.iter().enumerate() {
        values.push(sample_polygon_vertex_layer(
            layer,
            polygon_index,
            polygon_vertex_index,
            *control_point as usize,
        )?);
    }
    Some(values)
}

/// Expand polygon values for all polygons.
pub fn expand_polygon_values<T: Clone>(
    layer: &LayerElement<T>,
    polygon_count: usize,
) -> Option<Vec<T>> {
    let mut values = Vec::with_capacity(polygon_count);
    for polygon_index in 0..polygon_count {
        values.push(sample_polygon_layer(layer, polygon_index)?);
    }
    Some(values)
}

/// Convert f64 vertex positions to f32.
pub fn positions_from_vertices(
    vertices: &[f64],
) -> Result<Vec<[f32; 3]>, ExternalFbxConversionError> {
    if !vertices.len().is_multiple_of(3) {
        return Err(ExternalFbxConversionError::InvalidVertexArray);
    }
    Ok(vertices
        .chunks_exact(3)
        .map(|chunk| [chunk[0] as f32, chunk[1] as f32, chunk[2] as f32])
        .collect())
}

/// Append bytes to a buffer with 4-byte alignment padding.
pub fn append_padded(buffer: &mut Vec<u8>, bytes: &[u8]) -> usize {
    let offset = buffer.len();
    buffer.extend_from_slice(bytes);
    while !buffer.len().is_multiple_of(4) {
        buffer.push(0);
    }
    offset
}

/// Compute the bounding box of a set of positions.
pub fn compute_bounds(positions: &[[f32; 3]]) -> ([f32; 3], [f32; 3]) {
    let mut min = [f32::INFINITY; 3];
    let mut max = [f32::NEG_INFINITY; 3];
    for position in positions {
        for axis in 0..3 {
            min[axis] = min[axis].min(position[axis]);
            max[axis] = max[axis].max(position[axis]);
        }
    }
    (min, max)
}
