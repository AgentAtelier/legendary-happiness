//! FBX to GLB conversion — GLTF/GLB assembly and serialization.
//!
//! This module handles the conversion of parsed FBX geometry into GLB binary format,
//! including inspection and full conversion pipelines.

use anvil_core::ArchetypeTag;
use serde_json::json;
use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::Path;

use crate::fbx::geometry::{
    append_padded, compute_bounds, collect_geometry_nodes, expand_polygon_values,
    expand_polygon_vertex_values, geometry_display_name, geometry_materials, geometry_normals,
    geometry_polygon_indices, geometry_uv0, geometry_vertices, positions_from_vertices,
    polygon_vertices, triangulate_polygon,
    ExternalFbxConversionSummary, ExternalFbxMesh, ExternalFbxPrimitive, PrimitiveBuildData,
};
use crate::fbx::parser::parse_fbx_document;
use crate::fbx::ExternalFbxConversionError;

/// Maximum FBX file size (256 MB).
const MAX_FBX_FILE_SIZE: u64 = 256 * 1024 * 1024;

/// Inspect an FBX file and return summary statistics without full conversion.
pub fn inspect_fbx_source(
    source_path: &Path,
) -> Result<ExternalFbxConversionSummary, ExternalFbxConversionError> {
    let metadata = std::fs::metadata(source_path)?;
    if metadata.len() > MAX_FBX_FILE_SIZE {
        return Err(ExternalFbxConversionError::FileTooLarge(metadata.len()));
    }
    let bytes = fs::read(source_path)?;
    let document = parse_fbx_document(&bytes)?;
    let mut geometries = Vec::new();
    for node in &document.nodes {
        collect_geometry_nodes(node, &mut geometries, 0);
    }
    if geometries.is_empty() {
        return Err(ExternalFbxConversionError::MissingGeometry);
    }

    let mut geometry_name = String::new();
    let mut vertex_count = 0usize;
    let mut triangle_count = 0usize;
    let mut has_uv0 = true;
    let mut has_normals = true;
    let mut material_slot_count = 0usize;
    let mut submesh_count = 0usize;
    for (index, node) in geometries.iter().enumerate() {
        let vertices = geometry_vertices(node).ok_or(ExternalFbxConversionError::MissingGeometryData)?;
        let polygon_indices = geometry_polygon_indices(node)
            .ok_or(ExternalFbxConversionError::MissingGeometryData)?;
        let positions = positions_from_vertices(vertices)?;
        let polygons = polygon_vertices(polygon_indices)?;
        let normals_layer = geometry_normals(node);
        let uv_layer = geometry_uv0(node);
        let materials_layer = geometry_materials(node);
        geometry_name = geometry_display_name(node, index);
        vertex_count += positions.len();
        triangle_count += polygons
            .iter()
            .map(|polygon| polygon.len().saturating_sub(2))
            .sum::<usize>();
        has_normals &= normals_layer
            .as_ref()
            .map(|layer| {
                polygons.iter().enumerate().all(|(polygon_index, polygon)| {
                    expand_polygon_vertex_values(layer, polygon_index, polygon).is_some()
                })
            })
            .unwrap_or(false);
        has_uv0 &= uv_layer
            .as_ref()
            .map(|layer| {
                polygons.iter().enumerate().all(|(polygon_index, polygon)| {
                    expand_polygon_vertex_values(layer, polygon_index, polygon).is_some()
                })
            })
            .unwrap_or(false);
        if let Some(layer) = materials_layer.as_ref() {
            let slots = expand_polygon_values(layer, polygons.len())
                .map(|values| {
                    values
                        .into_iter()
                        .map(|value| value.max(0) as usize)
                        .collect::<BTreeSet<_>>()
                })
                .unwrap_or_default();
            material_slot_count += slots.len();
            submesh_count += slots.len().max(1);
        } else {
            submesh_count += 1;
        }
    }

    Ok(ExternalFbxConversionSummary {
        geometry_name,
        geometry_count: geometries.len(),
        vertex_count,
        triangle_count,
        has_uv0,
        has_normals,
        material_slot_count,
        submesh_count,
    })
}

/// Convert an FBX file to GLB bytes with full geometry extraction and triangulation.
pub fn convert_fbx_to_glb_bytes(
    source_path: &Path,
    normalized_id: &ArchetypeTag,
) -> Result<(Vec<u8>, ExternalFbxConversionSummary), ExternalFbxConversionError> {
    let metadata = std::fs::metadata(source_path)?;
    if metadata.len() > MAX_FBX_FILE_SIZE {
        return Err(ExternalFbxConversionError::FileTooLarge(metadata.len()));
    }
    let bytes = fs::read(source_path)?;
    let document = parse_fbx_document(&bytes)?;
    let mut geometries = Vec::new();
    for node in &document.nodes {
        collect_geometry_nodes(node, &mut geometries, 0);
    }
    if geometries.is_empty() {
        return Err(ExternalFbxConversionError::MissingGeometry);
    }

    let mut meshes = Vec::new();
    let mut summary = ExternalFbxConversionSummary {
        geometry_name: String::new(),
        geometry_count: geometries.len(),
        vertex_count: 0,
        triangle_count: 0,
        has_uv0: true,
        has_normals: true,
        material_slot_count: 0,
        submesh_count: 0,
    };
    for (index, node) in geometries.iter().enumerate() {
        let vertices = geometry_vertices(node).ok_or(ExternalFbxConversionError::MissingGeometryData)?;
        let polygon_indices = geometry_polygon_indices(node)
            .ok_or(ExternalFbxConversionError::MissingGeometryData)?;
        let positions = positions_from_vertices(vertices)?;
        let polygons = polygon_vertices(polygon_indices)?;
        let normals_layer = geometry_normals(node);
        let uv_layer = geometry_uv0(node);
        let materials_layer = geometry_materials(node);
        summary.geometry_name = geometry_display_name(node, index);
        summary.vertex_count += positions.len();
        summary.triangle_count += polygons
            .iter()
            .map(|polygon| polygon.len().saturating_sub(2))
            .sum::<usize>();

        let has_geometry_normals = normals_layer
            .as_ref()
            .map(|layer| {
                polygons.iter().enumerate().all(|(polygon_index, polygon)| {
                    expand_polygon_vertex_values(layer, polygon_index, polygon).is_some()
                })
            })
            .unwrap_or(false);
        let has_geometry_uv0 = uv_layer
            .as_ref()
            .map(|layer| {
                polygons.iter().enumerate().all(|(polygon_index, polygon)| {
                    expand_polygon_vertex_values(layer, polygon_index, polygon).is_some()
                })
            })
            .unwrap_or(false);
        summary.has_normals &= has_geometry_normals;
        summary.has_uv0 &= has_geometry_uv0;

        let polygon_materials = materials_layer.as_ref().and_then(|layer| {
            expand_polygon_values(layer, polygons.len()).map(|values| {
                values
                    .into_iter()
                    .map(|value| value.max(0) as usize)
                    .collect::<Vec<_>>()
            })
        });
        let mut primitive_builders: BTreeMap<Option<usize>, PrimitiveBuildData> = BTreeMap::new();
        for (polygon_index, polygon) in polygons.iter().enumerate() {
            let material_slot = polygon_materials
                .as_ref()
                .and_then(|values| values.get(polygon_index).copied());
            let primitive = primitive_builders
                .entry(material_slot)
                .or_insert_with(|| PrimitiveBuildData::new(material_slot));
            let polygon_normals = normals_layer
                .as_ref()
                .and_then(|layer| expand_polygon_vertex_values(layer, polygon_index, polygon));
            let polygon_uvs = uv_layer
                .as_ref()
                .and_then(|layer| expand_polygon_vertex_values(layer, polygon_index, polygon));
            for triangle in triangulate_polygon(polygon)? {
                for polygon_vertex_index in triangle {
                    let control_point = polygon[polygon_vertex_index] as usize;
                    let position = positions
                        .get(control_point)
                        .copied()
                        .ok_or(ExternalFbxConversionError::MissingGeometryData)?;
                    let normal = polygon_normals
                        .as_ref()
                        .and_then(|values| values.get(polygon_vertex_index).copied());
                    let uv = polygon_uvs
                        .as_ref()
                        .and_then(|values| values.get(polygon_vertex_index).copied());
                    primitive.push_vertex(position, normal, uv);
                }
            }
        }

        let primitives = primitive_builders
            .into_values()
            .map(|primitive| ExternalFbxPrimitive {
                material_slot: primitive.material_slot,
                positions: primitive.positions,
                normals: primitive.normals,
                uvs: primitive.uvs,
                indices: primitive.indices,
            })
            .collect::<Vec<_>>();
        summary.material_slot_count += primitives
            .iter()
            .filter(|primitive| primitive.material_slot.is_some())
            .count();
        summary.submesh_count += primitives.len();
        meshes.push(ExternalFbxMesh {
            name: summary.geometry_name.clone(),
            primitives,
        });
    }

    let mut binary = Vec::new();
    let mut buffer_views = Vec::new();
    let mut accessors = Vec::new();
    let mut meshes_json = Vec::new();
    let mut materials_json = Vec::new();
    let mut nodes_json = Vec::new();
    for mesh in &meshes {
        let mut primitive_jsons = Vec::new();
        for primitive in &mesh.primitives {
            let position_offset = append_padded(
                &mut binary,
                &primitive
                    .positions
                    .iter()
                    .flat_map(|position| position.iter().flat_map(|value| value.to_le_bytes()))
                    .collect::<Vec<_>>(),
            );
            let indices_offset = append_padded(
                &mut binary,
                &primitive
                    .indices
                    .iter()
                    .flat_map(|index| index.to_le_bytes())
                    .collect::<Vec<_>>(),
            );
            let (min, max) = compute_bounds(&primitive.positions);
            let position_view = buffer_views.len();
            buffer_views.push(json!({
                "buffer": 0,
                "byteOffset": position_offset,
                "byteLength": primitive.positions.len() * 3 * 4,
                "target": 34962,
            }));
            let index_view = buffer_views.len();
            buffer_views.push(json!({
                "buffer": 0,
                "byteOffset": indices_offset,
                "byteLength": primitive.indices.len() * 4,
                "target": 34963,
            }));
            let position_accessor = accessors.len();
            accessors.push(json!({
                "bufferView": position_view,
                "byteOffset": 0,
                "componentType": 5126,
                "count": primitive.positions.len(),
                "type": "VEC3",
                "min": [min[0], min[1], min[2]],
                "max": [max[0], max[1], max[2]],
            }));
            let index_accessor = accessors.len();
            accessors.push(json!({
                "bufferView": index_view,
                "byteOffset": 0,
                "componentType": 5125,
                "count": primitive.indices.len(),
                "type": "SCALAR",
            }));

            let normal_accessor = if let Some(normals) = &primitive.normals {
                let normal_offset = append_padded(
                    &mut binary,
                    &normals
                        .iter()
                        .flat_map(|normal| normal.iter().flat_map(|value| value.to_le_bytes()))
                        .collect::<Vec<_>>(),
                );
                let normal_view = buffer_views.len();
                buffer_views.push(json!({
                    "buffer": 0,
                    "byteOffset": normal_offset,
                    "byteLength": normals.len() * 3 * 4,
                    "target": 34962,
                }));
                let accessor = accessors.len();
                accessors.push(json!({
                    "bufferView": normal_view,
                    "byteOffset": 0,
                    "componentType": 5126,
                    "count": normals.len(),
                    "type": "VEC3",
                }));
                Some(accessor)
            } else {
                None
            };

            let uv_accessor = if let Some(uvs) = &primitive.uvs {
                let uv_offset = append_padded(
                    &mut binary,
                    &uvs.iter()
                        .flat_map(|uv| uv.iter().flat_map(|value| value.to_le_bytes()))
                        .collect::<Vec<_>>(),
                );
                let uv_view = buffer_views.len();
                buffer_views.push(json!({
                    "buffer": 0,
                    "byteOffset": uv_offset,
                    "byteLength": uvs.len() * 2 * 4,
                    "target": 34962,
                }));
                let accessor = accessors.len();
                accessors.push(json!({
                    "bufferView": uv_view,
                    "byteOffset": 0,
                    "componentType": 5126,
                    "count": uvs.len(),
                    "type": "VEC2",
                }));
                Some(accessor)
            } else {
                None
            };

            let mut attributes = json!({
                "POSITION": position_accessor,
            });
            if let Some(normal_accessor) = normal_accessor {
                attributes["NORMAL"] = json!(normal_accessor);
            }
            if let Some(uv_accessor) = uv_accessor {
                attributes["TEXCOORD_0"] = json!(uv_accessor);
            }

            let mut primitive_json = json!({
                "attributes": attributes,
                "indices": index_accessor,
                "mode": 4,
            });
            if let Some(material_slot) = primitive.material_slot {
                let material_index = materials_json.len();
                materials_json.push(json!({
                    "name": format!("{}_material_{}", mesh.name, material_slot),
                    "pbrMetallicRoughness": {
                        "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                        "metallicFactor": 0.0,
                        "roughnessFactor": 1.0,
                    },
                }));
                primitive_json["material"] = json!(material_index);
            }
            primitive_jsons.push(primitive_json);
        }
        nodes_json.push(json!({
            "mesh": meshes_json.len(),
            "name": mesh.name,
        }));
        meshes_json.push(json!({
            "name": mesh.name,
            "primitives": primitive_jsons,
        }));
    }

    let document_json = json!({
        "asset": {
            "version": "2.0",
            "generator": format!(
                "Anvil naturemanufacture normalization: {} from {}",
                normalized_id.as_str(),
                source_path.display()
            ),
        },
        "buffers": [{
            "byteLength": binary.len(),
        }],
        "bufferViews": buffer_views,
        "accessors": accessors,
        "meshes": meshes_json,
        "materials": materials_json,
        "nodes": nodes_json,
        "scenes": [{
            "nodes": (0..nodes_json.len()).collect::<Vec<_>>(),
        }],
        "scene": 0,
    });

    let mut json_bytes = serde_json::to_vec(&document_json)?;
    while json_bytes.len() % 4 != 0 {
        json_bytes.push(b' ');
    }
    while binary.len() % 4 != 0 {
        binary.push(0);
    }

    let total_len = 12 + 8 + json_bytes.len() + 8 + binary.len();
    let total_len_u32 =
        u32::try_from(total_len).map_err(|_| ExternalFbxConversionError::InvalidGlb)?;
    let json_chunk_len =
        u32::try_from(json_bytes.len()).map_err(|_| ExternalFbxConversionError::InvalidGlb)?;
    let binary_chunk_len =
        u32::try_from(binary.len()).map_err(|_| ExternalFbxConversionError::InvalidGlb)?;
    let mut glb = Vec::with_capacity(total_len);
    glb.extend_from_slice(b"glTF");
    glb.extend_from_slice(&2u32.to_le_bytes());
    glb.extend_from_slice(&total_len_u32.to_le_bytes());
    glb.extend_from_slice(&json_chunk_len.to_le_bytes());
    glb.extend_from_slice(b"JSON");
    glb.extend_from_slice(&json_bytes);
    glb.extend_from_slice(&binary_chunk_len.to_le_bytes());
    glb.extend_from_slice(b"BIN\0");
    glb.extend_from_slice(&binary);

    Ok((glb, summary))
}
