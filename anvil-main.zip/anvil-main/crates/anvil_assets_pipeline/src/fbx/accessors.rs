//! FBX node child accessors — helper functions for extracting typed data from FBX nodes.
//!
//! This module provides functions to extract specific property types from child nodes
//! by name, handling the various FBX property encodings.

use crate::fbx::parser::{FbxNode, FbxProperty};

/// Extract a string value from an FBX property.
pub fn fbx_property_string(property: &FbxProperty) -> Option<&str> {
    match property {
        FbxProperty::String(value) => Some(value.as_str()),
        _ => None,
    }
}

/// Get a string value from a named child node.
pub fn child_string(node: &FbxNode, name: &str) -> Option<String> {
    node.children.iter().find_map(|child| {
        if child.name == name {
            child
                .properties
                .first()
                .and_then(fbx_property_string)
                .map(|value: &str| value.trim().to_string())
        } else {
            None
        }
    })
}

/// Get an int32 array from a named child node.
/// Handles both Int32Array and Int64Array property types.
pub fn child_int32_array(node: &FbxNode, name: &str) -> Option<Vec<i32>> {
    node.children.iter().find_map(|child| {
        if child.name == name {
            child
                .properties
                .first()
                .and_then(|property| match property {
                    FbxProperty::Int32Array(values) => Some(values.clone()),
                    FbxProperty::Int64Array(values) => {
                        Some(values.iter().map(|value| *value as i32).collect::<Vec<_>>())
                    }
                    _ => None,
                })
        } else {
            None
        }
    })
}

/// Get a Vec3 array from a named child node.
/// Handles both FloatArray and DoubleArray property types.
/// Returns None if the array length is not a multiple of 3.
pub fn child_vec3_array(node: &FbxNode, name: &str) -> Option<Vec<[f32; 3]>> {
    node.children.iter().find_map(|child| {
        if child.name == name {
            child
                .properties
                .first()
                .and_then(|property| match property {
                    FbxProperty::FloatArray(values) => {
                        if values.len() % 3 != 0 {
                            None
                        } else {
                            Some(
                                values
                                    .chunks_exact(3)
                                    .map(|chunk| [chunk[0], chunk[1], chunk[2]])
                                    .collect(),
                            )
                        }
                    }
                    FbxProperty::DoubleArray(values) => {
                        if values.len() % 3 != 0 {
                            None
                        } else {
                            Some(
                                values
                                    .chunks_exact(3)
                                    .map(|chunk| {
                                        [chunk[0] as f32, chunk[1] as f32, chunk[2] as f32]
                                    })
                                    .collect(),
                            )
                        }
                    }
                    _ => None,
                })
        } else {
            None
        }
    })
}

/// Get a Vec2 array from a named child node.
/// Handles both FloatArray and DoubleArray property types.
/// Returns None if the array length is not a multiple of 2.
pub fn child_vec2_array(node: &FbxNode, name: &str) -> Option<Vec<[f32; 2]>> {
    node.children.iter().find_map(|child| {
        if child.name == name {
            child
                .properties
                .first()
                .and_then(|property| match property {
                    FbxProperty::FloatArray(values) => {
                        if values.len() % 2 != 0 {
                            None
                        } else {
                            Some(
                                values
                                    .chunks_exact(2)
                                    .map(|chunk| [chunk[0], chunk[1]])
                                    .collect(),
                            )
                        }
                    }
                    FbxProperty::DoubleArray(values) => {
                        if values.len() % 2 != 0 {
                            None
                        } else {
                            Some(
                                values
                                    .chunks_exact(2)
                                    .map(|chunk| [chunk[0] as f32, chunk[1] as f32])
                                    .collect(),
                            )
                        }
                    }
                    _ => None,
                })
        } else {
            None
        }
    })
}
