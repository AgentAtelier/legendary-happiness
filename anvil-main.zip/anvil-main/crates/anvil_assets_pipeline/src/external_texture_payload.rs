//! External asset texture payload manifest.
//!
//! This module has been split. See the `payload` module for the implementation.

pub use crate::payload::*;
