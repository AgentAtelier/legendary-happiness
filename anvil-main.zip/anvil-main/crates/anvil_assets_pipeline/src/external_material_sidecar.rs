//! External asset material sidecar manifest.
//!
//! This module has been split. See the `sidecar` module for the implementation.

pub use crate::sidecar::*;
