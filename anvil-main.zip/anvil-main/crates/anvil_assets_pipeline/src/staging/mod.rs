//! External asset staging manifest: staging decisions and output paths.

mod manifest;
mod record;

pub use manifest::{
    ExternalAssetNormalizationStageError, ExternalAssetNormalizationStageManifest,
    StagingStageError, StagingValidationErrors, validate_normalized_output_path,
};
pub use record::{ExternalAssetNormalizationStageRecord, StageAction, StagingRecordBuilder};
