//! Staging record types.

use crate::pilot::ExternalAssetFamily;
use crate::ExternalAssetSourceRef;
use anvil_assets::AssetCategory;
use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use std::fmt;
use std::path::PathBuf;

/// Action to take for a staged asset during the normalization pipeline.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
pub enum StageAction {
    /// Proceed with normalization - asset is ready for processing.
    #[serde(rename = "proceed")]
    Proceed,
    /// Blocked with reasons - asset cannot be processed.
    #[serde(rename = "blocked")]
    Blocked {
        /// List of reasons why this asset is blocked.
        reasons: Vec<String>
    },
    /// Needs manual review with hint - asset requires human inspection.
    #[serde(rename = "needs_review")]
    NeedsReview {
        /// Hint about what needs review.
        hint: String
    },
}

impl StageAction {
    /// Returns true if this action indicates the asset is ready for normalization.
    pub fn is_ready(&self) -> bool {
        matches!(self, StageAction::Proceed)
    }

    /// Returns the list of blockers if this action is Blocked, or empty slice otherwise.
    pub fn blockers(&self) -> &[String] {
        match self {
            StageAction::Blocked { reasons } => reasons.as_slice(),
            _ => &[],
        }
    }
}

impl fmt::Display for StageAction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Proceed => write!(f, "proceed"),
            Self::Blocked { reasons } => write!(f, "blocked ({})", reasons.join(", ")),
            Self::NeedsReview { hint } => write!(f, "needs_review ({})", hint),
        }
    }
}

/// A record in the normalization staging manifest.
/// Represents an asset that has been staged for normalization processing.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationStageRecord {
    /// The normalized archetype tag for this asset.
    pub normalized_id: ArchetypeTag,
    /// The asset family classification.
    pub family: ExternalAssetFamily,
    /// The asset category.
    pub category: AssetCategory,
    /// Source files that make up this asset.
    pub source_files: Vec<ExternalAssetSourceRef>,
    /// References to texture bundles used by this asset.
    #[serde(default)]
    pub texture_bundle_refs: Vec<ArchetypeTag>,
    /// The kind of output to produce.
    pub target_output_kind: crate::ExternalAssetNormalizedOutputKind,
    /// The target output path for the normalized asset.
    pub target_output_path: PathBuf,
    /// The staging action for this record.
    pub action: StageAction,
    /// Optional notes about this record.
    #[serde(default)]
    pub notes: Vec<String>,
}

impl ExternalAssetNormalizationStageRecord {
    /// Create a new builder for constructing a staging record.
    pub fn builder() -> StagingRecordBuilder {
        StagingRecordBuilder::new()
    }
}

/// Builder for [`ExternalAssetNormalizationStageRecord`].
///
/// Required fields:
/// - `normalized_id`
/// - `family`
/// - `target_output_path`
pub struct StagingRecordBuilder {
    /// The normalized ID (required).
    normalized_id: Option<ArchetypeTag>,
    /// The family (required).
    family: Option<ExternalAssetFamily>,
    /// The category (defaults to Landmark).
    category: AssetCategory,
    /// Source file references.
    source_files: Vec<ExternalAssetSourceRef>,
    /// Texture bundle references.
    texture_bundle_refs: Vec<ArchetypeTag>,
    /// The output kind (defaults to StaticMeshGlb).
    target_output_kind: crate::ExternalAssetNormalizedOutputKind,
    /// The target output path (required).
    target_output_path: Option<PathBuf>,
    /// The staging action (defaults to Proceed).
    action: StageAction,
    /// Notes about this record.
    notes: Vec<String>,
}

impl Default for StagingRecordBuilder {
    fn default() -> Self {
        Self::new()
    }
}

impl StagingRecordBuilder {
    /// Create a new empty builder.
    pub fn new() -> Self {
        Self {
            normalized_id: None,
            family: None,
            category: AssetCategory::Landmark,
            source_files: vec![],
            texture_bundle_refs: vec![],
            target_output_kind: crate::ExternalAssetNormalizedOutputKind::StaticMeshGlb,
            target_output_path: None,
            action: StageAction::Proceed,
            notes: vec![],
        }
    }

    /// Required. Sets the normalized ID.
    pub fn with_normalized_id(mut self, id: ArchetypeTag) -> Self {
        self.normalized_id = Some(id);
        self
    }

    /// Required. Sets the family.
    pub fn with_family(mut self, family: ExternalAssetFamily) -> Self {
        self.family = Some(family);
        self
    }

    /// Sets the category.
    pub fn with_category(mut self, category: AssetCategory) -> Self {
        self.category = category;
        self
    }

    /// Adds a source file reference.
    pub fn add_source_file(mut self, sf: ExternalAssetSourceRef) -> Self {
        self.source_files.push(sf);
        self
    }

    /// Adds a texture bundle reference.
    pub fn add_texture_bundle(mut self, tb: ArchetypeTag) -> Self {
        self.texture_bundle_refs.push(tb);
        self
    }

    /// Sets the target output kind.
    pub fn with_target_output_kind(mut self, kind: crate::ExternalAssetNormalizedOutputKind) -> Self {
        self.target_output_kind = kind;
        self
    }

    /// Required. Sets the target output path.
    pub fn with_target_output_path(mut self, path: PathBuf) -> Self {
        self.target_output_path = Some(path);
        self
    }

    /// Sets the staging action.
    pub fn with_action(mut self, action: StageAction) -> Self {
        self.action = action;
        self
    }

    /// Sets the notes.
    pub fn with_notes(mut self, notes: Vec<String>) -> Self {
        self.notes = notes;
        self
    }

    /// Build the staging record.
    /// Returns an error if any required field is missing.
    pub fn build(self) -> Result<ExternalAssetNormalizationStageRecord, String> {
        Ok(ExternalAssetNormalizationStageRecord {
            normalized_id: self
                .normalized_id
                .ok_or_else(|| "StagingRecordBuilder: normalized_id is required".to_string())?,
            family: self
                .family
                .ok_or_else(|| "StagingRecordBuilder: family is required".to_string())?,
            category: self.category,
            source_files: self.source_files,
            texture_bundle_refs: self.texture_bundle_refs,
            target_output_kind: self.target_output_kind,
            target_output_path: self.target_output_path.ok_or_else(|| {
                "StagingRecordBuilder: target_output_path is required".to_string()
            })?,
            action: self.action,
            notes: self.notes,
        })
    }
}
