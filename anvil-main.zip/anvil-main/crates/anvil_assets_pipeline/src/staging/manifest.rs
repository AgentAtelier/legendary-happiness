//! Staging manifest and related types.

use crate::external_pilot::PackIdentityError;
use crate::pipeline::{ManifestError, PipelineManifest};
use crate::staging::record::ExternalAssetNormalizationStageRecord;
use crate::{
    ExternalAssetFamily, ExternalAssetNormalizationEligibilityManifest,
    ExternalAssetNormalizedOutputKind, ExternalAssetPilotManifest,
};
use anvil_core::ArchetypeTag;
use anvil_core::{error_buffer, push_validation_error, FailureClass, ValidationErrors};
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fs;
use std::path::{Path, PathBuf};
use thiserror::Error;

/// Validation errors for staging manifests
pub type StagingValidationErrors = Vec<ExternalAssetNormalizationStageError>;

/// Errors that can occur during the staging validation phase.
#[derive(Debug, PartialEq, Eq, Error)]
pub enum StagingStageError {
    /// The record's target kind does not match its eligibility classification.
    #[error("record {0} target kind does not match eligibility")]
    TargetKindMismatch(usize),
    /// The record's family or category does not match its pilot registration.
    #[error("record {0} family/category does not match pilot registration")]
    RegistrationMismatch(usize),
    /// The record is not eligible for staging.
    #[error("record {0} is not eligible for staging")]
    IneligibleRecord(usize),
    /// The record has blocked status but no reasons are provided.
    #[error("record {0} has blocked status without reasons")]
    BlockedWithoutReasons(usize),
}

/// A manifest containing all records for the external asset normalization staging phase.
/// This manifest tracks which assets are ready to be converted from their source format
/// (e.g., FBX) to the normalized output format (e.g., GLB).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationStageManifest {
    /// The source pack identity that these staging records belong to.
    pub source_pack: crate::ExternalAssetPackIdentity,
    /// The list of staging records, one per asset to be normalized.
    pub records: Vec<ExternalAssetNormalizationStageRecord>,
}

impl PipelineManifest for ExternalAssetNormalizationStageManifest {
    type Record = ExternalAssetNormalizationStageRecord;
    type StageError = StagingStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &crate::ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for (index, record) in self.records.iter().enumerate() {
            // Validate source files
            if record.source_files.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    StagingStageError::IneligibleRecord(index),
                ));
            }

            // Validate output path
            let path_errors = validate_normalized_output_path(&record.target_output_path);
            if !path_errors.is_empty() {
                errors.push(ManifestError::StageSpecific(
                    StagingStageError::RegistrationMismatch(index),
                ));
            }
        }
        errors
    }
}

/// Errors that can occur when loading or validating an external asset normalization staging manifest.
#[derive(Debug, Error)]
pub enum ExternalAssetNormalizationStageError {
    /// Failed to read the manifest file from disk.
    #[error("failed to read external asset normalization staging manifest: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the manifest JSON.
    #[error("failed to parse external asset normalization staging manifest: {0}")]
    ParseError(#[from] serde_json::Error),

    /// The manifest contains no records.
    #[error("external asset normalization staging manifest has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id in external asset normalization staging manifest: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// The manifest records are not sorted deterministically.
    #[error("external asset normalization staging manifest is not deterministically ordered")]
    UnsortedManifest,

    /// A required source pack field is blank or missing.
    #[error("external asset normalization staging source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// The source manifest file referenced by the staging manifest was not found.
    #[error("external asset normalization staging source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),

    /// The source pack identity in a record does not match the manifest's source pack.
    #[error("external asset normalization staging record {0:?} has mismatched pack identity")]
    PackMismatch(usize),

    /// An error occurred while validating pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// A record references a source file that does not exist or is invalid.
    #[error(
        "external asset normalization staging record {0:?} has invalid source file reference: {1}"
    )]
    InvalidSourceFileReference(usize, String),

    /// A record references a texture bundle that does not exist or is invalid.
    #[error(
        "external asset normalization staging record {0:?} has invalid texture bundle reference: {1}"
    )]
    InvalidTextureBundleReference(usize, String),

    /// A record has an invalid output path.
    #[error("external asset normalization staging record {0:?} has invalid output path: {1}")]
    InvalidOutputPath(usize, String),

    /// A record's target kind does not match its eligibility classification.
    #[error(
        "external asset normalization staging record {0:?} target kind does not match eligibility"
    )]
    TargetKindMismatch(usize),

    /// A record's family or category does not match its pilot registration.
    #[error(
        "external asset normalization staging record {0:?} family or category does not match pilot registration"
    )]
    RegistrationMismatch(usize),

    /// A record references an asset that is not eligible for staging.
    #[error("external asset normalization staging record {0:?} is not eligible for staging")]
    IneligibleRecord(usize),
}

impl PartialEq for ExternalAssetNormalizationStageError {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::EmptyManifest, Self::EmptyManifest) => true,
            (Self::UnsortedManifest, Self::UnsortedManifest) => true,
            (Self::DuplicateNormalizedId(a), Self::DuplicateNormalizedId(b)) => a == b,
            (Self::BlankPackField(a), Self::BlankPackField(b)) => a == b,
            (Self::MissingSourceManifest(a), Self::MissingSourceManifest(b)) => a == b,
            (Self::PackMismatch(a), Self::PackMismatch(b)) => a == b,
            (Self::IoError(a), Self::IoError(b)) => a.to_string() == b.to_string(),
            (Self::ParseError(a), Self::ParseError(b)) => a.to_string() == b.to_string(),
            (Self::PackIdentity(a), Self::PackIdentity(b)) => a.to_string() == b.to_string(),
            (
                Self::InvalidSourceFileReference(a_idx, a_msg),
                Self::InvalidSourceFileReference(b_idx, b_msg),
            ) => a_idx == b_idx && a_msg == b_msg,
            (
                Self::InvalidTextureBundleReference(a_idx, a_msg),
                Self::InvalidTextureBundleReference(b_idx, b_msg),
            ) => a_idx == b_idx && a_msg == b_msg,
            (Self::InvalidOutputPath(a_idx, a_path), Self::InvalidOutputPath(b_idx, b_path)) => {
                a_idx == b_idx && a_path == b_path
            }
            (Self::TargetKindMismatch(a), Self::TargetKindMismatch(b)) => a == b,
            (Self::RegistrationMismatch(a), Self::RegistrationMismatch(b)) => a == b,
            (Self::IneligibleRecord(a), Self::IneligibleRecord(b)) => a == b,
            _ => false,
        }
    }
}

impl Eq for ExternalAssetNormalizationStageError {}

/// Validate a normalized output path for correctness.
/// Checks that the path is not absolute and starts with the expected prefix.
pub fn validate_normalized_output_path(path: &Path) -> ValidationErrors {
    let mut errors = error_buffer();
    if path.is_absolute() {
        push_validation_error!(
            errors,
            FailureClass::Asset,
            "E073",
            "NormalizedOutputPath",
            "path",
            path.display().to_string(),
            "path must not be absolute"
        );
    }
    let path_str = path.to_string_lossy();
    if !path_str.starts_with(crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX) {
        push_validation_error!(
            errors,
            FailureClass::Asset,
            "E074",
            "NormalizedOutputPath",
            "path",
            path.display().to_string(),
            &format!(
                "path must start with {}",
                crate::EXTERNAL_NORMALIZED_OUTPUT_PREFIX
            )
        );
    }
    errors
}

impl ExternalAssetNormalizationStageManifest {
    /// Load a staging manifest from a JSON file at the given path.
    /// The manifest is validated and records are sorted by normalized ID.
    pub fn load(path: &Path) -> Result<Self, ExternalAssetNormalizationStageError> {
        let content = fs::read_to_string(path)?;
        let manifest: Self = serde_json::from_str(&content)?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        manifest
            .records
            .sort_by(|a, b| a.normalized_id.as_str().cmp(b.normalized_id.as_str()));
        let errors = manifest.validate();
        if !errors.is_empty() {
            // Convert ValidationErrors to ExternalAssetNormalizationStageError
            // by returning UnsortedManifest as a proxy error
            return Err(ExternalAssetNormalizationStageError::UnsortedManifest);
        }
        Ok(manifest)
    }

    /// Validate the manifest's internal consistency.
    /// Checks for empty records, missing source manifest, duplicate IDs, and ordering.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();

        if self.records.is_empty() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E068",
                "ExternalAssetNormalizationStageManifest",
                "records",
                "empty",
                "records must not be empty"
            );
            return errors;
        }

        let pack_errors = self.source_pack.validate();
        errors.extend(pack_errors);

        if errors.is_empty() && !self.source_pack.source_manifest.exists() {
            push_validation_error!(
                errors,
                FailureClass::Asset,
                "E069",
                "ExternalAssetNormalizationStageManifest",
                "source_manifest",
                self.source_pack.source_manifest.display().to_string(),
                "source_manifest not found"
            );
        }

        if errors.is_empty() {
            let mut seen = BTreeSet::new();
            let mut previous = None::<&str>;
            for (index, record) in self.records.iter().enumerate() {
                if !seen.insert(record.normalized_id.as_str().to_string()) {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E070",
                        "ExternalAssetNormalizationStageManifest",
                        "records",
                        record.normalized_id.as_str().to_string(),
                        "duplicate normalized id"
                    );
                }
                let current = record.normalized_id.as_str();
                if let Some(previous) = previous && previous > current {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E071",
                        "ExternalAssetNormalizationStageManifest",
                        "records",
                        current.to_string(),
                        "manifest is not deterministically ordered"
                    );
                }
                previous = Some(current);

                // Validate source files
                if record.source_files.is_empty() {
                    push_validation_error!(
                        errors,
                        FailureClass::Asset,
                        "E072",
                        "ExternalAssetNormalizationStageManifest",
                        &format!("records[{}].source_files", index),
                        "",
                        "record is missing source files"
                    );
                }

                // Validate output path
                let path_errors = validate_normalized_output_path(&record.target_output_path);
                if !path_errors.is_empty() {
                    errors.extend(path_errors);
                }

                // Validate blocked status has reasons
                // (enforced by StageAction type, no manual check needed)
            }
        }

        errors
    }

    /// Validate this manifest against the pilot manifest and eligibility manifest.
    /// Checks that source packs match, source files are valid, families and categories match,
    /// target kinds match eligibility, and all eligibility requirements are satisfied.
    pub fn validate_against_pilot_and_eligibility(
        &self,
        pilot: &ExternalAssetPilotManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
    ) -> StagingValidationErrors {
        let mut errors = Vec::new();

        if self.source_pack != pilot.source_pack || self.source_pack != eligibility.source_pack {
            errors.push(ExternalAssetNormalizationStageError::PackMismatch(0));
            return errors;
        }

        let pilot_map = pilot.registration_map();
        let eligibility_map: std::collections::BTreeMap<_, _> = eligibility
            .records()
            .iter()
            .map(|record| (record.normalized_id.as_str(), record))
            .collect();

        for (index, record) in self.records.iter().enumerate() {
            let pilot_registration = pilot_map
                .get(record.normalized_id.as_str())
                .ok_or(ExternalAssetNormalizationStageError::IneligibleRecord(index));
            let Ok(pilot_registration) = pilot_registration else {
                errors.push(ExternalAssetNormalizationStageError::IneligibleRecord(index));
                continue;
            };

            let eligibility_record = eligibility_map
                .get(record.normalized_id.as_str())
                .ok_or(ExternalAssetNormalizationStageError::IneligibleRecord(index));
            let Ok(eligibility_record) = eligibility_record else {
                errors.push(ExternalAssetNormalizationStageError::IneligibleRecord(index));
                continue;
            };

            // Check source files match
            if pilot_registration.source_files != record.source_files {
                errors.push(ExternalAssetNormalizationStageError::RegistrationMismatch(
                    index,
                ));
            }

            // Check family and category match
            if pilot_registration.family != record.family
                || pilot_registration.category != record.category
            {
                errors.push(ExternalAssetNormalizationStageError::RegistrationMismatch(
                    index,
                ));
            }

            // Check target kind matches eligibility
            if eligibility_record.target_normalized_kind != record.target_output_kind {
                errors.push(ExternalAssetNormalizationStageError::TargetKindMismatch(
                    index,
                ));
            }

            // Check eligibility status
            if !eligibility_record.status.is_eligible() {
                errors.push(ExternalAssetNormalizationStageError::IneligibleRecord(
                    index,
                ));
            }

            // Validate source file references against pilot manifest
            for source_ref in &record.source_files {
                if !pilot.source_pack.source_manifest.exists() {
                    errors.push(ExternalAssetNormalizationStageError::MissingSourceManifest(
                        pilot.source_pack.source_manifest.clone(),
                    ));
                    continue;
                }
                let manifest_text = match fs::read_to_string(&pilot.source_pack.source_manifest) {
                    Ok(text) => text,
                    Err(_) => {
                        errors.push(ExternalAssetNormalizationStageError::MissingSourceManifest(
                            pilot.source_pack.source_manifest.clone(),
                        ));
                        continue;
                    }
                };
                if !manifest_text.contains(&source_ref.source_file) {
                    errors.push(
                        ExternalAssetNormalizationStageError::InvalidSourceFileReference(
                            index,
                            source_ref.source_file.clone(),
                        ),
                    );
                }
            }

            // Validate texture bundle references
            for texture_bundle_ref in &record.texture_bundle_refs {
                let texture_bundle_id = texture_bundle_ref.as_str();
                let Some(pilot_texture_registration) = pilot_map.get(texture_bundle_id) else {
                    errors.push(
                        ExternalAssetNormalizationStageError::InvalidTextureBundleReference(
                            index,
                            texture_bundle_ref.as_str().to_string(),
                        ),
                    );
                    continue;
                };

                let Some(texture_eligibility) = eligibility_map.get(texture_bundle_id) else {
                    errors.push(
                        ExternalAssetNormalizationStageError::InvalidTextureBundleReference(
                            index,
                            texture_bundle_ref.as_str().to_string(),
                        ),
                    );
                    continue;
                };

                if pilot_texture_registration.family != ExternalAssetFamily::GroundTextureSet {
                    errors.push(
                        ExternalAssetNormalizationStageError::InvalidTextureBundleReference(
                            index,
                            texture_bundle_ref.as_str().to_string(),
                        ),
                    );
                }
                if texture_eligibility.target_normalized_kind
                    != ExternalAssetNormalizedOutputKind::TextureSetBundle
                {
                    errors.push(
                        ExternalAssetNormalizationStageError::InvalidTextureBundleReference(
                            index,
                            texture_bundle_ref.as_str().to_string(),
                        ),
                    );
                }
            }
        }

        errors
    }

    /// Strict validation against pilot and eligibility manifests.
    /// Returns `Ok(())` if validation passes, or `Err` with the list of errors.
    pub fn validate_against_pilot_and_eligibility_strict(
        &self,
        pilot: &ExternalAssetPilotManifest,
        eligibility: &ExternalAssetNormalizationEligibilityManifest,
    ) -> Result<(), StagingValidationErrors> {
        let errors = self.validate_against_pilot_and_eligibility(pilot, eligibility);
        if errors.is_empty() {
            Ok(())
        } else {
            Err(errors)
        }
    }
}
