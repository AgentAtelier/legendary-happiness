//! External asset eligibility manifest: classification and validation.

mod part1;
mod part2a;
mod part2b;

pub use part1::*;
pub use part2a::*;
pub use part2b::*;
