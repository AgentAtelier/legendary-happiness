//! External asset eligibility manifest: classifies registered assets
//! for normalization eligibility (part 1 - enums).

use serde::{Deserialize, Serialize};
use std::fmt;

/// The source format of an external asset's model data.
#[non_exhaustive]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetSourceModelFormat {
    /// FBX format - Autodesk Filmbox format for 3D models.
    Fbx,
    /// A set of texture files without geometry.
    TextureSet,
}

impl fmt::Display for ExternalAssetSourceModelFormat {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::Fbx => "fbx",
            Self::TextureSet => "texture_set",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing an `ExternalAssetSourceModelFormat` from a string fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetSourceModelFormatError;

impl fmt::Display for ParseExternalAssetSourceModelFormatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset source model format")
    }
}

impl std::error::Error for ParseExternalAssetSourceModelFormatError {}

impl std::str::FromStr for ExternalAssetSourceModelFormat {
    type Err = ParseExternalAssetSourceModelFormatError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "fbx" => Ok(Self::Fbx),
            "texture_set" => Ok(Self::TextureSet),
            _ => Err(ParseExternalAssetSourceModelFormatError),
        }
    }
}

/// Get a static string label for a source model format.
/// Deprecated: use the `Display` implementation instead.
#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", format)"]
pub fn external_asset_source_model_format_label(
    format: &ExternalAssetSourceModelFormat,
) -> &'static str {
    match format {
        ExternalAssetSourceModelFormat::Fbx => "fbx",
        ExternalAssetSourceModelFormat::TextureSet => "texture_set",
    }
}

/// The kind of normalized output that an external asset will produce.
#[non_exhaustive]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetNormalizedOutputKind {
    /// A static mesh in GLB format.
    StaticMeshGlb,
    /// A bundle of textures.
    TextureSetBundle,
}

impl fmt::Display for ExternalAssetNormalizedOutputKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::StaticMeshGlb => "static_mesh_glb",
            Self::TextureSetBundle => "texture_set_bundle",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing an `ExternalAssetNormalizedOutputKind` from a string fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetNormalizedOutputKindError;

impl fmt::Display for ParseExternalAssetNormalizedOutputKindError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset normalized output kind")
    }
}

impl std::error::Error for ParseExternalAssetNormalizedOutputKindError {}

impl std::str::FromStr for ExternalAssetNormalizedOutputKind {
    type Err = ParseExternalAssetNormalizedOutputKindError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "static_mesh_glb" => Ok(Self::StaticMeshGlb),
            "texture_set_bundle" => Ok(Self::TextureSetBundle),
            _ => Err(ParseExternalAssetNormalizedOutputKindError),
        }
    }
}

/// Get a static string label for a normalized output kind.
/// Deprecated: use the `Display` implementation instead.
#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", kind)"]
pub fn external_asset_normalized_output_kind_label(
    kind: &ExternalAssetNormalizedOutputKind,
) -> &'static str {
    match kind {
        ExternalAssetNormalizedOutputKind::StaticMeshGlb => "static_mesh_glb",
        ExternalAssetNormalizedOutputKind::TextureSetBundle => "texture_set_bundle",
    }
}

/// Classification of an external asset's material for rendering purposes.
/// Determines which material channels are required and how the asset should be rendered.
#[non_exhaustive]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetMaterialClass {
    /// Foliage assets that use alpha cutout transparency.
    FoliageCutout,
    /// Ground cover assets that use alpha cutout transparency.
    GroundCoverCutout,
    /// Solid rock assets with no transparency.
    RockSolid,
    /// Root and log assets.
    RootLog,
    /// Fungal assets (mushrooms, etc.).
    Fungal,
    /// Ground texture assets.
    GroundTexture,
}

impl fmt::Display for ExternalAssetMaterialClass {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::FoliageCutout => "foliage_cutout",
            Self::GroundCoverCutout => "ground_cover_cutout",
            Self::RockSolid => "rock_solid",
            Self::RootLog => "root_log",
            Self::Fungal => "fungal",
            Self::GroundTexture => "ground_texture",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing an `ExternalAssetMaterialClass` from a string fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetMaterialClassError;

impl fmt::Display for ParseExternalAssetMaterialClassError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset material class")
    }
}

impl std::error::Error for ParseExternalAssetMaterialClassError {}

impl std::str::FromStr for ExternalAssetMaterialClass {
    type Err = ParseExternalAssetMaterialClassError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "foliage_cutout" => Ok(Self::FoliageCutout),
            "ground_cover_cutout" => Ok(Self::GroundCoverCutout),
            "rock_solid" => Ok(Self::RockSolid),
            "root_log" => Ok(Self::RootLog),
            "fungal" => Ok(Self::Fungal),
            "ground_texture" => Ok(Self::GroundTexture),
            _ => Err(ParseExternalAssetMaterialClassError),
        }
    }
}

/// Get a static string label for a material class.
/// Deprecated: use the `Display` implementation instead.
#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", class)"]
pub fn external_asset_material_class_label(class: &ExternalAssetMaterialClass) -> &'static str {
    match class {
        ExternalAssetMaterialClass::FoliageCutout => "foliage_cutout",
        ExternalAssetMaterialClass::GroundCoverCutout => "ground_cover_cutout",
        ExternalAssetMaterialClass::RockSolid => "rock_solid",
        ExternalAssetMaterialClass::RootLog => "root_log",
        ExternalAssetMaterialClass::Fungal => "fungal",
        ExternalAssetMaterialClass::GroundTexture => "ground_texture",
    }
}

impl ExternalAssetMaterialClass {
    /// Returns the required channel semantics for this material class.
    pub fn required_channels(
        &self,
        alpha_cutout_required: bool,
    ) -> Vec<crate::external_material_sidecar::ExternalAssetMaterialChannelSemantic> {
        use crate::external_material_sidecar::ExternalAssetMaterialChannelSemantic as Ch;
        let mut channels = vec![Ch::BaseColor, Ch::Normal];
        match self {
            Self::FoliageCutout | Self::GroundCoverCutout | Self::Fungal => {
                channels.push(Ch::PackedMask);
                if alpha_cutout_required {
                    channels.push(Ch::AlphaCutout);
                }
            }
            Self::RockSolid | Self::RootLog => {
                channels.push(Ch::PackedMask);
            }
            Self::GroundTexture => {}
        }
        channels
    }
}

/// The completeness status of a texture set's files.
#[non_exhaustive]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExternalAssetTextureSetCompleteness {
    /// All expected texture files are present.
    Complete,
    /// Texture completeness is not applicable for this asset type.
    NotApplicable,
    /// Some expected texture files are missing.
    Missing,
}

impl fmt::Display for ExternalAssetTextureSetCompleteness {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Self::Complete => "complete",
            Self::NotApplicable => "not_applicable",
            Self::Missing => "missing",
        };
        write!(f, "{}", s)
    }
}

/// Error returned when parsing an `ExternalAssetTextureSetCompleteness` from a string fails.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseExternalAssetTextureSetCompletenessError;

impl fmt::Display for ParseExternalAssetTextureSetCompletenessError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid external asset texture set completeness")
    }
}

impl std::error::Error for ParseExternalAssetTextureSetCompletenessError {}

impl std::str::FromStr for ExternalAssetTextureSetCompleteness {
    type Err = ParseExternalAssetTextureSetCompletenessError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.trim() {
            "complete" => Ok(Self::Complete),
            "not_applicable" => Ok(Self::NotApplicable),
            "missing" => Ok(Self::Missing),
            _ => Err(ParseExternalAssetTextureSetCompletenessError),
        }
    }
}

/// Get a static string label for a texture set completeness status.
/// Deprecated: use the `Display` implementation instead.
#[allow(dead_code)]
#[deprecated = "Use Display instead: format!(\"{}\", completeness)"]
pub fn external_asset_texture_set_completeness_label(
    completeness: &ExternalAssetTextureSetCompleteness,
) -> &'static str {
    match completeness {
        ExternalAssetTextureSetCompleteness::Complete => "complete",
        ExternalAssetTextureSetCompleteness::NotApplicable => "not_applicable",
        ExternalAssetTextureSetCompleteness::Missing => "missing",
    }
}

/// Status of eligibility for normalization.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
pub enum EligibilityStatus {
    /// Asset is eligible for normalization.
    #[serde(rename = "eligible")]
    Eligible,
    /// Asset is not eligible for normalization, with reasons explaining why.
    #[serde(rename = "not_eligible")]
    NotEligible { 
        /// The list of reasons why this asset is not eligible for normalization.
        reasons: Vec<String> 
    },
}

impl EligibilityStatus {
    /// Returns true if this asset is eligible for normalization.
    pub fn is_eligible(&self) -> bool {
        matches!(self, EligibilityStatus::Eligible)
    }

    /// Returns the list of reasons why this asset is not eligible.
    /// Returns an empty slice if the asset is eligible.
    pub fn reasons(&self) -> &[String] {
        match self {
            EligibilityStatus::Eligible => &[],
            EligibilityStatus::NotEligible { reasons } => reasons,
        }
    }
}

impl fmt::Display for EligibilityStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            EligibilityStatus::Eligible => write!(f, "eligible"),
            EligibilityStatus::NotEligible { reasons } => {
                write!(f, "not_eligible")?;
                if !reasons.is_empty() {
                    write!(f, " (reasons: {})", reasons.join(", "))?;
                }
                Ok(())
            }
        }
    }
}

