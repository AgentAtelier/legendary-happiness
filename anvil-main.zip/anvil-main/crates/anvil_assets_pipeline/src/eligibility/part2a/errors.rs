use anvil_core::ArchetypeTag;
use std::path::PathBuf;
use thiserror::Error;
use crate::external_pilot::PackIdentityError;

/// Errors that can occur during the eligibility validation stage.
#[derive(Debug, PartialEq, Eq, Error)]
pub enum EligibilityStageError {
    /// A record's classification does not match the expected value.
    #[error("record {0:?} classification mismatch: {1}")]
    ClassificationMismatch(ArchetypeTag, &'static str),
    /// A record is marked as eligible but has blocking conditions.
    #[error("record {0:?} is eligible but has blockers")]
    EligibleButBlocked(ArchetypeTag),
    /// A record is marked as ineligible but has no blocking reasons.
    #[error("record {0:?} is ineligible but has no blockers")]
    IneligibleWithoutBlockers(ArchetypeTag),
    /// The eligibility manifest does not cover all pilot IDs or has unexpected IDs.
    #[error("pilot coverage mismatch: missing={missing:?} unexpected={unexpected:?}")]
    PilotCoverageMismatch {
        /// The list of pilot IDs that are missing from the eligibility manifest.
        missing: Vec<ArchetypeTag>,
        /// The list of IDs in the eligibility manifest that are not in the pilot.
        unexpected: Vec<ArchetypeTag>,
    },
}

/// Error type for eligibility manifest loading and validation.
#[derive(Debug, Error)]
pub enum ExternalAssetNormalizationEligibilityError {
    /// Failed to read the manifest file from disk.
    #[error("failed to read external asset normalization eligibility manifest: {0}")]
    IoError(#[from] std::io::Error),

    /// Failed to parse the manifest JSON.
    #[error("failed to parse external asset normalization eligibility manifest: {0}")]
    ParseError(String),

    /// The manifest contains no records.
    #[error("external asset normalization eligibility manifest has no records")]
    EmptyManifest,

    /// A normalized ID appears more than once in the manifest.
    #[error("duplicate normalized id in external asset normalization eligibility manifest: {0:?}")]
    DuplicateNormalizedId(ArchetypeTag),

    /// The manifest records are not sorted deterministically.
    #[error("external asset normalization eligibility manifest is not deterministically ordered")]
    UnsortedManifest,

    /// A required source pack field is blank or missing.
    #[error("external asset normalization eligibility source pack field is blank: {0}")]
    BlankPackField(&'static str),

    /// The source manifest file referenced by the eligibility manifest was not found.
    #[error("external asset normalization eligibility source manifest not found: {0}")]
    MissingSourceManifest(PathBuf),

    /// An error occurred while validating pack identity.
    #[error("pack identity error: {0}")]
    PackIdentity(#[from] PackIdentityError),

    /// The source pack in the eligibility manifest does not match the pilot manifest.
    #[error("external asset normalization eligibility source pack does not match pilot")]
    SourcePackMismatch,

    /// The eligibility manifest does not cover all pilot IDs or has unexpected IDs.
    #[error(
        "external asset normalization eligibility manifest does not cover pilot ids: missing={missing:?} unexpected={unexpected:?}"
    )]
    PilotCoverageMismatch {
        /// The list of pilot IDs that are missing from the eligibility manifest.
        missing: Vec<ArchetypeTag>,
        /// The list of IDs in the eligibility manifest that are not in the pilot.
        unexpected: Vec<ArchetypeTag>,
    },

    /// A record references a pilot ID that does not exist.
    #[error("pilot record not found for {0:?}")]
    MissingPilotRecord(ArchetypeTag),

    /// A record's classification does not match the expected value.
    #[error(
        "external asset normalization eligibility classification mismatch for {normalized_id:?}: {field}"
    )]
    ClassificationMismatch {
        /// The normalized ID of the record with the classification mismatch.
        normalized_id: ArchetypeTag,
        /// The field that has the classification mismatch.
        field: &'static str,
    },
}


