//! External asset eligibility manifest: classification and validation (part 2).

/// Trait for classifying asset eligibility.
pub mod classifier;
/// Default implementation of the eligibility classifier.
pub mod default_classifier;
/// Error types for the eligibility stage.
pub mod errors;
/// Manifest types for the eligibility stage.
pub mod manifest;
/// Record types for the eligibility stage.
pub mod record;
/// Validation helpers for the eligibility stage.
pub mod validation;

pub use classifier::EligibilityClassifier;
pub use default_classifier::DefaultEligibilityClassifier;
pub use errors::{EligibilityStageError, ExternalAssetNormalizationEligibilityError};
pub use manifest::{ExternalAssetNormalizationEligibilityManifest, validate_eligibility_classifications};
pub use record::ExternalAssetNormalizationEligibilityRecord;
pub use validation::EligibilityValidationErrors;
