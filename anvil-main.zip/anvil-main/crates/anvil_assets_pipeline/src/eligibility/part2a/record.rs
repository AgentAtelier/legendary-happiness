use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use crate::ExternalAssetSourceModelFormat;
use crate::ExternalAssetTextureSetCompleteness;
use crate::ExternalAssetMaterialClass;
use crate::ExternalAssetNormalizedOutputKind;
use crate::EligibilityStatus;

/// processed through the normalization pipeline.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationEligibilityRecord {
    /// The normalized identifier for this asset.
    pub normalized_id: ArchetypeTag,
    /// The source format of the asset's model data.
    pub source_model_format: ExternalAssetSourceModelFormat,
    /// The completeness status of the asset's texture set.
    pub source_texture_set_completeness: ExternalAssetTextureSetCompleteness,
    /// Whether this asset requires alpha cutout transparency.
    pub alpha_cutout_required: bool,
    /// The likely material class for this asset based on its family and vendor rules.
    pub likely_material_class: ExternalAssetMaterialClass,
    /// The kind of normalized output this asset will produce.
    pub target_normalized_kind: ExternalAssetNormalizedOutputKind,
    /// The eligibility status for this asset.
    pub status: EligibilityStatus,
    /// Optional notes about this eligibility classification.
    #[serde(default)]
    pub notes: Vec<String>,
}
