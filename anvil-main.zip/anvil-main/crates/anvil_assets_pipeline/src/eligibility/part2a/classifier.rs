use crate::ExternalAssetRegistration;
use crate::eligibility::part2a::record::ExternalAssetNormalizationEligibilityRecord;

/// Trait for classifying asset eligibility for normalization.
pub trait EligibilityClassifier: Send + Sync {
    /// Classify a registration and return its eligibility record.
    /// 
    /// The classifier examines the registration's family, kind, and other properties,
    /// combined with vendor-specific rules, to determine the asset's eligibility
    /// for normalization.
    fn classify(
        &self,
        registration: &ExternalAssetRegistration,
        vendor: &dyn crate::Vendor,
    ) -> ExternalAssetNormalizationEligibilityRecord;
}
