use crate::{
    ExternalAssetRegistration, ExternalAssetSourceModelFormat,
    ExternalAssetTextureSetCompleteness,
    ExternalAssetNormalizedOutputKind, EligibilityStatus,
};
use crate::eligibility::part2a::classifier::EligibilityClassifier;
use crate::eligibility::part2a::record::ExternalAssetNormalizationEligibilityRecord;

/// Default classifier that uses family and kind to determine eligibility.
/// This implementation provides sensible defaults based on the asset's family
/// and kind, combined with vendor-specific material classification.
pub struct DefaultEligibilityClassifier;

impl EligibilityClassifier for DefaultEligibilityClassifier {
    fn classify(
        &self,
        registration: &ExternalAssetRegistration,
        vendor: &dyn crate::Vendor,
    ) -> ExternalAssetNormalizationEligibilityRecord {
        use crate::ExternalAssetFamily::*;

        let source_model_format = match registration.kind {
            anvil_assets::AssetKind::Texture => ExternalAssetSourceModelFormat::TextureSet,
            anvil_assets::AssetKind::Mesh | anvil_assets::AssetKind::Material | anvil_assets::AssetKind::Audio => {
                ExternalAssetSourceModelFormat::Fbx
            }
            _ => ExternalAssetSourceModelFormat::Fbx,
        };
        let source_texture_set_completeness = match registration.family {
            GroundTextureSet => ExternalAssetTextureSetCompleteness::NotApplicable,
            _ => ExternalAssetTextureSetCompleteness::Complete,
        };
        let target_normalized_kind = match registration.family {
            GroundTextureSet => ExternalAssetNormalizedOutputKind::TextureSetBundle,
            _ => ExternalAssetNormalizedOutputKind::StaticMeshGlb,
        };

        ExternalAssetNormalizationEligibilityRecord {
            normalized_id: registration.normalized_id.clone(),
            source_model_format,
            source_texture_set_completeness,
            alpha_cutout_required: vendor.alpha_cutout_required(registration.family.clone()),
            likely_material_class: vendor.default_material_class(registration.family.clone()),
            target_normalized_kind,
            status: EligibilityStatus::Eligible,
            notes: Vec::new(),
        }
    }
}
