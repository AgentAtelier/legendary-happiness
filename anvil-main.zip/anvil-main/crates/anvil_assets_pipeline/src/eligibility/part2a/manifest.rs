use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;
use anvil_core::{ArchetypeTag};
use crate::pipeline::{ManifestError, PipelineManifest};
use crate::external_pilot::{ExternalAssetPilotManifest};
use crate::eligibility::part2a::classifier::EligibilityClassifier;
use crate::eligibility::part2a::default_classifier::DefaultEligibilityClassifier;
use crate::eligibility::part2a::errors::{EligibilityStageError, ExternalAssetNormalizationEligibilityError};
use crate::eligibility::part2a::record::ExternalAssetNormalizationEligibilityRecord;
use crate::eligibility::part2a::validation::EligibilityValidationErrors;

/// Manifest for external asset normalization eligibility classification.
///
/// Contains eligibility records for all external assets in a source pack.
/// Use [`EligibilityClassifier`] as the plug-in for custom classification rules.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationEligibilityManifest {
    /// The source pack identity that these eligibility records belong to.
    pub source_pack: crate::ExternalAssetPackIdentity,
    /// The list of eligibility records, one per asset.
    records: Vec<ExternalAssetNormalizationEligibilityRecord>,
}

impl PipelineManifest for ExternalAssetNormalizationEligibilityManifest {
    type Record = ExternalAssetNormalizationEligibilityRecord;
    type StageError = EligibilityStageError;

    fn records(&self) -> &[Self::Record] {
        &self.records
    }
    fn source_pack(&self) -> &crate::ExternalAssetPackIdentity {
        &self.source_pack
    }
    fn record_id<'a>(&self, record: &'a Self::Record) -> &'a ArchetypeTag {
        &record.normalized_id
    }

    fn validate_stage_specific(&self) -> Vec<ManifestError<Self::StageError>> {
        let mut errors = Vec::new();
        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ManifestError::BlankField("normalized_id"));
            }
        }
        errors
    }
}

impl ExternalAssetNormalizationEligibilityManifest {
    /// Get a reference to all eligibility records in this manifest.
    pub fn records(&self) -> &[ExternalAssetNormalizationEligibilityRecord] {
        &self.records
    }

    /// Load and validate the manifest from a JSON file.
    /// Records are sorted by normalized ID and validation is performed.
    pub fn load(path: &Path) -> Result<Self, ExternalAssetNormalizationEligibilityError> {
        let content = fs::read_to_string(path)
            .map_err(ExternalAssetNormalizationEligibilityError::IoError)?;
        let manifest: Self = serde_json::from_str(&content)
            .map_err(|e| ExternalAssetNormalizationEligibilityError::ParseError(e.to_string()))?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        manifest
            .records
            .sort_by(|a, b| a.normalized_id.as_str().cmp(b.normalized_id.as_str()));
        manifest.validate_strict()?;
        Ok(manifest)
    }

    /// Load the manifest from a JSON file without failing on validation errors.
    /// This is stricter than `load` in that it always validates, but it returns the manifest
    /// even if validation fails (the caller should check validation separately).
    pub fn load_strict(path: &Path) -> Result<Self, ExternalAssetNormalizationEligibilityError> {
        let content = fs::read_to_string(path)
            .map_err(ExternalAssetNormalizationEligibilityError::IoError)?;
        let manifest: Self = serde_json::from_str(&content)
            .map_err(|e| ExternalAssetNormalizationEligibilityError::ParseError(e.to_string()))?;
        let mut manifest = manifest;
        // Resolve relative paths in source_pack to absolute paths
        manifest.source_pack = manifest.source_pack.with_resolved_paths();
        manifest
            .records
            .sort_by(|a, b| a.normalized_id.as_str().cmp(b.normalized_id.as_str()));
        Ok(manifest)
    }

    /// Validate the manifest structure.
    /// Checks for empty records, missing source manifest, duplicate IDs, and ordering.
    /// Does not perform classification validation against the pilot manifest.
    pub fn validate(&self) -> EligibilityValidationErrors {
        let mut errors = EligibilityValidationErrors::new();

        if self.records.is_empty() {
            errors.push(ExternalAssetNormalizationEligibilityError::EmptyManifest);
            return errors;
        }

        let _pack_errors = self.source_pack.validate();
        // Pack identity errors are now returned as ValidationErrors (Vec<AnvilCoreError>)
        // For now we skip them since we can't easily convert to ExternalAssetNormalizationEligibilityError

        if !self.source_pack.source_manifest.exists() {
            errors.push(
                ExternalAssetNormalizationEligibilityError::MissingSourceManifest(
                    self.source_pack.source_manifest.clone(),
                ),
            );
            return errors;
        }

        let mut seen = BTreeSet::new();
        let mut previous = None::<&str>;

        for record in &self.records {
            if record.normalized_id.as_str().trim().is_empty() {
                errors.push(ExternalAssetNormalizationEligibilityError::BlankPackField(
                    "normalized_id",
                ));
            }

            if !seen.insert(record.normalized_id.as_str().to_string()) {
                errors.push(
                    ExternalAssetNormalizationEligibilityError::DuplicateNormalizedId(
                        record.normalized_id.clone(),
                    ),
                );
            }

            let current = record.normalized_id.as_str();
            if let Some(previous) = previous && previous > current {
                errors.push(ExternalAssetNormalizationEligibilityError::UnsortedManifest);
            }
            previous = Some(current);
        }

        errors
    }

    /// Validate the manifest and return an error if any validation errors exist.
    /// Returns `Ok(())` if validation passes, or `Err` with the first validation error.
    pub fn validate_strict(&self) -> Result<(), ExternalAssetNormalizationEligibilityError> {
        let errors = self.validate();
        if errors.is_empty() {
            Ok(())
        } else {
            // Return the first error for convenience
            // SAFETY: errors is non-empty because we checked !errors.is_empty() above.
            let first = errors
                .0
                .into_iter()
                .next()
                .expect("errors is non-empty; checked above");
            Err(first)
        }
    }

    /// Validate eligibility classifications against the pilot manifest using the default classifier.
    pub fn validate_against_pilot(
        &self,
        pilot: &ExternalAssetPilotManifest,
        vendor: &dyn crate::Vendor,
    ) -> EligibilityValidationErrors {
        self.validate_against_pilot_with_classifier(pilot, &DefaultEligibilityClassifier, vendor)
    }

    /// Validate eligibility classifications against the pilot manifest with a custom classifier.
    /// This allows for custom classification rules beyond the default implementation.
    pub fn validate_against_pilot_with_classifier(
        &self,
        pilot: &ExternalAssetPilotManifest,
        classifier: &dyn EligibilityClassifier,
        vendor: &dyn crate::Vendor,
    ) -> EligibilityValidationErrors {
        let mut errors = EligibilityValidationErrors::new();

        if self.source_pack != pilot.source_pack {
            errors.push(ExternalAssetNormalizationEligibilityError::SourcePackMismatch);
            return errors;
        }

        errors.extend(validate_eligibility_classifications(
            self, pilot, classifier, vendor,
        ));

        errors
    }

}

/// Validate that eligibility classifications match the expected values from the classifier.
/// Checks that all assets in the eligibility manifest have classifications that match
/// what the classifier would produce from the pilot manifest registrations.
pub fn validate_eligibility_classifications(
    manifest: &ExternalAssetNormalizationEligibilityManifest,
    pilot: &ExternalAssetPilotManifest,
    classifier: &dyn EligibilityClassifier,
    vendor: &dyn crate::Vendor,
) -> Vec<ExternalAssetNormalizationEligibilityError> {
    let mut errors = Vec::new();

    let pilot_map = pilot.registration_map();

    let self_ids: BTreeSet<&str> = manifest
        .records
        .iter()
        .map(|record| record.normalized_id.as_str())
        .collect();
    let pilot_ids: BTreeSet<&str> = pilot_map.keys().copied().collect();

    let missing: Vec<ArchetypeTag> = pilot_ids
        .difference(&self_ids)
        .filter_map(|&id| pilot_map.get(id).map(|r| r.normalized_id.clone()))
        .collect();
    let unexpected: Vec<ArchetypeTag> = self_ids
        .difference(&pilot_ids)
        .filter_map(|&id| {
            manifest
                .records
                .iter()
                .find(|record| record.normalized_id.as_str() == id)
                .map(|record| record.normalized_id.clone())
        })
        .collect();

    if !missing.is_empty() || !unexpected.is_empty() {
        errors.push(
            ExternalAssetNormalizationEligibilityError::PilotCoverageMismatch {
                missing,
                unexpected,
            },
        );
    }

    for record in &manifest.records {
        let Some(registration) = pilot_map.get(record.normalized_id.as_str()) else {
            errors.push(
                ExternalAssetNormalizationEligibilityError::MissingPilotRecord(
                    record.normalized_id.clone(),
                ),
            );
            continue;
        };
        let expected = classifier.classify(registration, vendor);

        if record.source_model_format != expected.source_model_format {
            errors.push(
                ExternalAssetNormalizationEligibilityError::ClassificationMismatch {
                    normalized_id: record.normalized_id.clone(),
                    field: "source_model_format",
                },
            );
        }
        if record.source_texture_set_completeness != expected.source_texture_set_completeness {
            errors.push(
                ExternalAssetNormalizationEligibilityError::ClassificationMismatch {
                    normalized_id: record.normalized_id.clone(),
                    field: "source_texture_set_completeness",
                },
            );
        }
        if record.alpha_cutout_required != expected.alpha_cutout_required {
            errors.push(
                ExternalAssetNormalizationEligibilityError::ClassificationMismatch {
                    normalized_id: record.normalized_id.clone(),
                    field: "alpha_cutout_required",
                },
            );
        }
        if record.likely_material_class != expected.likely_material_class {
            errors.push(
                ExternalAssetNormalizationEligibilityError::ClassificationMismatch {
                    normalized_id: record.normalized_id.clone(),
                    field: "likely_material_class",
                },
            );
        }
        if record.target_normalized_kind != expected.target_normalized_kind {
            errors.push(
                ExternalAssetNormalizationEligibilityError::ClassificationMismatch {
                    normalized_id: record.normalized_id.clone(),
                    field: "target_normalized_kind",
                },
            );
        }
    }

    errors
}
