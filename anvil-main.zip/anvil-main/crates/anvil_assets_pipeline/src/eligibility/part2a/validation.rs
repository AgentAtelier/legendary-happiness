use std::fmt;

use crate::eligibility::part2a::errors::ExternalAssetNormalizationEligibilityError;

/// Collection of eligibility validation errors.
#[derive(Debug)]
pub struct EligibilityValidationErrors(pub Vec<ExternalAssetNormalizationEligibilityError>);

impl EligibilityValidationErrors {
    /// Create a new empty collection of validation errors.
    pub fn new() -> Self {
        Self(Vec::new())
    }

    /// Returns true if there are no validation errors.
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Returns the number of validation errors.
    pub fn len(&self) -> usize {
        self.0.len()
    }

    /// Add a validation error to the collection.
    pub fn push(&mut self, error: ExternalAssetNormalizationEligibilityError) {
        self.0.push(error);
    }

    /// Extend the collection with multiple validation errors.
    pub fn extend(
        &mut self,
        errors: impl IntoIterator<Item = ExternalAssetNormalizationEligibilityError>,
    ) {
        self.0.extend(errors);
    }
}

impl fmt::Display for EligibilityValidationErrors {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if self.0.is_empty() {
            return write!(f, "No validation errors");
        }
        writeln!(f, "Validation errors ({}):", self.0.len())?;
        for (i, error) in self.0.iter().enumerate() {
            writeln!(f, "  {}. {}", i + 1, error)?;
        }
        Ok(())
    }
}

impl std::error::Error for EligibilityValidationErrors {}

impl From<Vec<ExternalAssetNormalizationEligibilityError>> for EligibilityValidationErrors {
    fn from(errors: Vec<ExternalAssetNormalizationEligibilityError>) -> Self {
        Self(errors)
    }
}

impl From<ExternalAssetNormalizationEligibilityError> for EligibilityValidationErrors {
    fn from(error: ExternalAssetNormalizationEligibilityError) -> Self {
        Self(vec![error])
    }
}

