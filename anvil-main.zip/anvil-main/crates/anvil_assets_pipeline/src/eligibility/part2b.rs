//! External asset eligibility manifest: classification and validation (part 2b).

use crate::ExternalAssetRegistration;

use super::part2a::*;


impl PartialEq for ExternalAssetNormalizationEligibilityError {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::EmptyManifest, Self::EmptyManifest) => true,
            (Self::UnsortedManifest, Self::UnsortedManifest) => true,
            (Self::SourcePackMismatch, Self::SourcePackMismatch) => true,
            (Self::DuplicateNormalizedId(a), Self::DuplicateNormalizedId(b)) => a == b,
            (Self::BlankPackField(a), Self::BlankPackField(b)) => a == b,
            (Self::MissingSourceManifest(a), Self::MissingSourceManifest(b)) => a == b,
            (Self::IoError(a), Self::IoError(b)) => a.to_string() == b.to_string(),
            (Self::ParseError(a), Self::ParseError(b)) => a == b,
            (Self::PackIdentity(a), Self::PackIdentity(b)) => a.to_string() == b.to_string(),
            (
                Self::PilotCoverageMismatch {
                    missing: a_missing,
                    unexpected: a_unexpected,
                },
                Self::PilotCoverageMismatch {
                    missing: b_missing,
                    unexpected: b_unexpected,
                },
            ) => a_missing == b_missing && a_unexpected == b_unexpected,
            (
                Self::ClassificationMismatch {
                    normalized_id: a_id,
                    field: a_field,
                },
                Self::ClassificationMismatch {
                    normalized_id: b_id,
                    field: b_field,
                },
            ) => a_id == b_id && a_field == b_field,
            (Self::MissingPilotRecord(a), Self::MissingPilotRecord(b)) => a == b,
            _ => false,
        }
    }
}

impl Eq for ExternalAssetNormalizationEligibilityError {}

/// Generate expected eligibility record for a registration
#[allow(dead_code)]
#[deprecated = "Use DefaultEligibilityClassifier.classify() instead"]
pub fn expected_eligibility_for_registration(
    registration: &ExternalAssetRegistration,
    vendor: &dyn crate::Vendor,
) -> ExternalAssetNormalizationEligibilityRecord {
    DefaultEligibilityClassifier.classify(registration, vendor)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::eligibility::{
        EligibilityStatus, ExternalAssetMaterialClass, ExternalAssetNormalizedOutputKind,
        ExternalAssetSourceModelFormat, ExternalAssetTextureSetCompleteness,
    };
    use crate::external_pilot::ExternalAssetPilotManifest;
    use crate::pipeline::PipelineManifest;
    use crate::vendors::naturemanufacture::NatureManufactureVendor;
    use crate::ExternalAssetFamily;
    use anvil_assets::AssetCategory;
    use anvil_assets::AssetKind;
    use anvil_core::ArchetypeTag;
    use anvil_core::repo_path;
    use std::io::Write;
    use std::path::PathBuf;
    use tempfile::NamedTempFile;

    fn test_vendor() -> NatureManufactureVendor {
        NatureManufactureVendor
    }

    fn repo_manifest_path() -> PathBuf {
        repo_path!("assets/external/naturemanufacture_forest_environment_eligibility.json")
    }

    fn repo_pilot_manifest_path() -> PathBuf {
        repo_path!("assets/external/naturemanufacture_forest_environment_pilot.json")
    }

    fn dummy_pack() -> crate::ExternalAssetPackIdentity {
        crate::ExternalAssetPackIdentity {
            vendor: "Test".into(),
            pack_name: "TestPack".into(),
            source_root: PathBuf::from("/tmp"),
            source_manifest: PathBuf::from("/tmp/manifest.txt"),
        }
    }

    fn dummy_registration(
        family: ExternalAssetFamily,
        kind: AssetKind,
    ) -> ExternalAssetRegistration {
        ExternalAssetRegistration::builder()
            .with_source_pack(dummy_pack())
            .with_normalized_id(anvil_core::arche!("test_asset"))
            .with_display_name("Test Asset".into())
            .with_family(family)
            .with_kind(kind)
            .with_category(AssetCategory::Landmark)
            .build()
            .unwrap()
    }

    fn make_manifest(
        source_pack: crate::ExternalAssetPackIdentity,
        records: Vec<ExternalAssetNormalizationEligibilityRecord>,
    ) -> ExternalAssetNormalizationEligibilityManifest {
        // We need to use serde to construct the manifest since records is private
        use serde_json::json;
        let records_json: Vec<_> = records
            .into_iter()
            .map(|r| {
                json!({
                    "normalized_id": r.normalized_id,
                    "source_model_format": r.source_model_format,
                    "source_texture_set_completeness": r.source_texture_set_completeness,
                    "alpha_cutout_required": r.alpha_cutout_required,
                    "likely_material_class": r.likely_material_class,
                    "target_normalized_kind": r.target_normalized_kind,
                    "status": r.status,
                    "notes": r.notes,
                })
            })
            .collect();
        let json = json!({
            "source_pack": {
                "vendor": source_pack.vendor,
                "pack_name": source_pack.pack_name,
                "source_root": source_pack.source_root.to_string_lossy(),
                "source_manifest": source_pack.source_manifest.to_string_lossy(),
            },
            "records": records_json,
        });
        serde_json::from_value(json).expect("valid manifest json")
    }

    #[test]
    fn loads_repo_candidate_eligibility_manifest_and_validates_against_pilot() {
        let Ok(pilot) = ExternalAssetPilotManifest::load(&repo_pilot_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(eligibility) =
            ExternalAssetNormalizationEligibilityManifest::load(&repo_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        let errors = eligibility.validate_against_pilot(&pilot, &test_vendor());
        assert!(errors.is_empty(), "expected no errors, got: {}", errors);

        assert_eq!(eligibility.records().len(), 18);
        assert!(eligibility
            .records()
            .iter()
            .all(|record| matches!(record.status, EligibilityStatus::Eligible)));
        assert_eq!(
            eligibility.records()[0].normalized_id.as_str(),
            "nm_forest_env_ground_cover_fern_01_1"
        );
        assert_eq!(
            eligibility
                .records()
                .last()
                .expect("last eligibility")
                .normalized_id
                .as_str(),
            "nm_forest_env_tree_beech_tree_04"
        );
        assert_eq!(
            eligibility.records()[0].target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
    }

    #[test]
    fn eligibility_manifest_load_is_deterministic() {
        let Ok(first) = ExternalAssetNormalizationEligibilityManifest::load(&repo_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(second) = ExternalAssetNormalizationEligibilityManifest::load(&repo_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        assert_eq!(first, second);
    }

    #[test]
    fn eligibility_manifest_rejects_duplicate_normalized_ids() {
        let mut source_manifest = NamedTempFile::new().expect("temp source manifest");
        std::io::Write::write_all(&mut source_manifest, b"foo.fbx\n")
            .expect("write source manifest");

        let source_pack = crate::ExternalAssetPackIdentity {
            vendor: "Test".into(),
            pack_name: "TestPack".into(),
            source_root: PathBuf::from("/tmp"),
            source_manifest: source_manifest.path().to_path_buf(),
        };
        let record = ExternalAssetNormalizationEligibilityRecord {
            normalized_id: ArchetypeTag::new("nm_forest_env_tree_beech_tree_00_a")
                .expect("valid tag"),
            source_model_format: ExternalAssetSourceModelFormat::Fbx,
            source_texture_set_completeness: ExternalAssetTextureSetCompleteness::Complete,
            alpha_cutout_required: true,
            likely_material_class: ExternalAssetMaterialClass::FoliageCutout,
            target_normalized_kind: ExternalAssetNormalizedOutputKind::StaticMeshGlb,
            status: EligibilityStatus::Eligible,
            notes: vec![],
        };
        let manifest = make_manifest(source_pack, vec![record.clone(), record]);

        let errors = manifest.validate();
        assert!(!errors.is_empty());
        assert!(errors.0.iter().any(|e| matches!(
            e,
            ExternalAssetNormalizationEligibilityError::DuplicateNormalizedId(_)
        )));
    }

    #[test]
    fn eligibility_manifest_requires_full_pilot_coverage() {
        let Ok(pilot) = ExternalAssetPilotManifest::load(&repo_pilot_manifest_path()) else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };
        let Ok(eligibility) =
            ExternalAssetNormalizationEligibilityManifest::load(&repo_manifest_path())
        else {
            eprintln!("Skipping: vendor fixtures not available");
            return;
        };

        // Create a new manifest with one record removed
        let mut records = eligibility.records().to_vec();
        records.pop();
        let manifest = make_manifest(eligibility.source_pack().clone(), records);

        let errors = manifest.validate_against_pilot(&pilot, &test_vendor());
        assert!(!errors.is_empty());
        assert!(errors.0.iter().any(|e| matches!(
            e,
            ExternalAssetNormalizationEligibilityError::PilotCoverageMismatch { .. }
        )));
    }

    #[test]
    fn tree_is_foliage_cutout() {
        let reg = dummy_registration(ExternalAssetFamily::Tree, AssetKind::Mesh);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::FoliageCutout
        );
        assert!(record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn rock_is_solid() {
        let reg = dummy_registration(ExternalAssetFamily::Rock, AssetKind::Mesh);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::RockSolid
        );
        assert!(!record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn ground_cover_is_cutout() {
        let reg = dummy_registration(ExternalAssetFamily::GroundCover, AssetKind::Mesh);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::GroundCoverCutout
        );
        assert!(record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn mushroom_is_fungal() {
        let reg = dummy_registration(ExternalAssetFamily::Mushroom, AssetKind::Mesh);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::Fungal
        );
        assert!(record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn stump_root_log_is_root_log() {
        let reg = dummy_registration(ExternalAssetFamily::StumpRootLog, AssetKind::Mesh);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::RootLog
        );
        assert!(!record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::StaticMeshGlb
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn ground_texture_set_is_texture_bundle() {
        let reg = dummy_registration(ExternalAssetFamily::GroundTextureSet, AssetKind::Texture);
        let record = DefaultEligibilityClassifier.classify(&reg, &test_vendor());
        assert_eq!(
            record.likely_material_class,
            ExternalAssetMaterialClass::GroundTexture
        );
        assert!(!record.alpha_cutout_required);
        assert_eq!(
            record.target_normalized_kind,
            ExternalAssetNormalizedOutputKind::TextureSetBundle
        );
        assert_eq!(
            record.source_model_format,
            ExternalAssetSourceModelFormat::TextureSet
        );
        assert_eq!(
            record.source_texture_set_completeness,
            ExternalAssetTextureSetCompleteness::NotApplicable
        );
        assert!(matches!(record.status, EligibilityStatus::Eligible));
    }

    #[test]
    fn eligibility_status_display() {
        assert_eq!(format!("{}", EligibilityStatus::Eligible), "eligible");
        assert_eq!(
            format!(
                "{}",
                EligibilityStatus::NotEligible {
                    reasons: vec!["reason1".to_string(), "reason2".to_string()]
                }
            ),
            "not_eligible (reasons: reason1, reason2)"
        );
        assert_eq!(
            format!("{}", EligibilityStatus::NotEligible { reasons: vec![] }),
            "not_eligible"
        );
    }

    #[test]
    fn eligibility_status_is_eligible() {
        assert!(EligibilityStatus::Eligible.is_eligible());
        assert!(!EligibilityStatus::NotEligible {
            reasons: vec!["test".to_string()]
        }
        .is_eligible());
    }

    #[test]
    fn validate_strict_returns_error_on_validation_failure() {
        let mut source_manifest = NamedTempFile::new().expect("temp source manifest");
        Write::write_all(&mut source_manifest, b"foo.fbx\n").expect("write source manifest");

        let _pack = dummy_pack();
        let manifest = make_manifest(dummy_pack(), vec![]);

        let result = manifest.validate_strict();
        assert!(result.is_err());
    }

}
