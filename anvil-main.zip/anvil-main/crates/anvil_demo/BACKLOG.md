# anvil_demo — Backlog

Ideas that are worth doing but are not part of the current cap list.
Move items into the cap list only when a previous milestone is complete.

* Sound — verify AssetKind::Audio entries resolve; log "would play X" instead of playing audio.
* Weather system integration — cycle vegetation/damage states over time.
* NPC spawning with faction‑aware material resolution.
* Asset hot‑reloading — watch catalogue file for changes.
* Performance overlay — frame‑time breakdown, allocation counters.
* Compare explicit vs fallback material side‑by‑side.
