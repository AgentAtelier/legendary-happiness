//! Determinism regression tests for snapshot/restore.
//!
//! These tests ensure that snapshot/restore produces identical state hashes,
//! catching any non-deterministic serialization issues (e.g., HashMap iteration order).

use anvil_core::RegionId;
use anvil_sim::{
    CatastropheSystem, JoySystem, NpcSystem, SimSystem,
    settlement::{Settlement, SettlementId},
};

#[test]
fn test_catastrophe_system_snapshot_determinism() {
    // Test that CatastropheSystem snapshots are deterministic with BTreeMap
    use anvil_sim::catastrophe::CatastropheType;
    
    let mut system1 = CatastropheSystem::new();
    let mut system2 = CatastropheSystem::new();
    
    // Add some cooldowns to both systems using public API
    system1.set_cooldown(CatastropheType::Flood, 100);
    system1.set_cooldown(CatastropheType::Earthquake, 200);
    
    system2.set_cooldown(CatastropheType::Flood, 100);
    system2.set_cooldown(CatastropheType::Earthquake, 200);
    
    let snap1 = system1.snapshot().expect("Failed to snapshot system1");
    let snap2 = system2.snapshot().expect("Failed to snapshot system2");
    
    assert_eq!(snap1, snap2, "CatastropheSystem snapshots must match with same cooldowns");
}

#[test]
fn test_joy_system_snapshot_determinism() {
    // Test that JoySystem snapshots are deterministic with BTreeMap
    let mut system1 = JoySystem::new();
    let mut system2 = JoySystem::new();
    
    // Add some data to both systems
    system1.lowest_mood_tracking.insert(1, (0.5, 100));
    system1.recent_history_events.insert(1, 1);
    
    system2.lowest_mood_tracking.insert(1, (0.5, 100));
    system2.recent_history_events.insert(1, 1);
    
    let snap1 = system1.snapshot().expect("Failed to snapshot system1");
    let snap2 = system2.snapshot().expect("Failed to snapshot system2");
    
    assert_eq!(snap1, snap2, "JoySystem snapshots must match with same data");
}

#[test]
fn test_npc_system_snapshot_determinism() {
    // Test that NpcSystem snapshots are deterministic with BTreeMap
    let mut system1 = NpcSystem::new();
    let mut system2 = NpcSystem::new();
    
    // Add same data to both
    let settlement1 = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Test".to_string(),
        RegionId::new(0),
        10,
    );
    let settlement2 = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Test".to_string(),
        RegionId::new(0),
        10,
    );
    
    system1.add_settlement(settlement1);
    system2.add_settlement(settlement2);
    
    let snap1 = system1.snapshot().expect("Failed to snapshot system1");
    let snap2 = system2.snapshot().expect("Failed to snapshot system2");
    
    assert_eq!(snap1, snap2, "NpcSystem snapshots must match with same data");
}

#[test]
fn test_empty_systems_snapshot_determinism() {
    // Test that empty system snapshots are deterministic
    let system1 = CatastropheSystem::new();
    let system2 = CatastropheSystem::new();
    
    let snap1 = system1.snapshot().expect("Failed to snapshot system1");
    let snap2 = system2.snapshot().expect("Failed to snapshot system2");
    
    assert_eq!(snap1, snap2, "Empty CatastropheSystem snapshots must match");
    
    let joy1 = JoySystem::new();
    let joy2 = JoySystem::new();
    
    let joy_snap1 = joy1.snapshot().expect("Failed to snapshot joy1");
    let joy_snap2 = joy2.snapshot().expect("Failed to snapshot joy2");
    
    assert_eq!(joy_snap1, joy_snap2, "Empty JoySystem snapshots must match");
}
