//! Demo audio configuration.
//!
//! All audio *infrastructure* lives in `anvil_bevy::audio`. This module
//! contains Ashveil-specific configuration only.
//!
//! See `ashveil.rs` for the stem/zone registration, stinger map, and
//! TUNE-marked placeholder values.

pub mod ashveil;

pub use ashveil::AshveilAudioPlugin;
