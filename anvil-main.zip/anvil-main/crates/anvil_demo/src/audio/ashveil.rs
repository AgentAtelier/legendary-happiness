//! Ashveil audio configuration.
//!
//! This file is **data**, not logic. It configures the generic
//! `anvil_bevy::audio` system for the Ashveil demo:
//!
//! - Which stems exist and what their mood curves are.
//! - Where the ambient zones sit in Ashveil's world coordinates.
//! - Which cues map to which stinger assets.
//!
//! Everything that knows about Ashveil specifically lives here. The
//! engine crate (`anvil_bevy`) owns no Ashveil knowledge.
//!
//! ## TUNE markers
//!
//! Volumes, crossfade speeds, and stinger mappings are marked with
//! `TUNE:` comments where artistic judgement is required. These ship
//! with reasonable defaults so the demo is audible from day one, but
//! they should be tuned by ear once real assets land.

use bevy::prelude::*;

use anvil_bevy::audio::{
    AudioDirector, CatastrophePhase, Cue,
    MoodCurve, PlayStinger, Stem, StemRegistry,
    StingerMap, StingerResolver, Zone, ZoneRegistry,
    score::{catastrophe_arc, dawn_dusk_emphasis, weather_threat},
};

/// Plugin for Ashveil-specific audio configuration. Add *after* the
/// `AudioPlugin` from `anvil_bevy` so the registries exist.
pub struct AshveilAudioPlugin;

impl Plugin for AshveilAudioPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, configure_audio.after(register_audio_plugin));
    }
}

/// Marker system for ordering. The real `AudioPlugin` is added in the
/// demo's plugin registration; `configure_audio` runs after that.
fn register_audio_plugin() {}

/// Startup system: register Ashveil's stems and zones, install the
/// stinger map.
fn configure_audio(
    asset_server: Res<AssetServer>,
    mut stems: ResMut<StemRegistry>,
    mut zones: ResMut<ZoneRegistry>,
    mut commands: Commands,
) {
    register_stems(&asset_server, &mut stems);
    register_zones(&asset_server, &mut zones);
    commands.insert_resource(StingerMap::new(AshveilStingerResolver));
}

// ---------- Stems ----------

/// The six score stems for Ashveil. Each is loop-able, mono or stereo,
/// roughly 30 seconds long. See `docs/AUDIO_SHOPPING_LIST.md` for the
/// sourcing brief.
fn register_stems(asset_server: &AssetServer, stems: &mut StemRegistry) {
    register_drone(asset_server, stems);
    register_strings(asset_server, stems);
    register_percussion_and_recovery(asset_server, stems);
}

fn register_drone(asset_server: &AssetServer, stems: &mut StemRegistry) {
    // Sustained drone — always present beneath everything. The morning's
    // texture. TUNE: target volume should sit at ~0.15 when calm.
    stems.register(Stem::new(
        "sustained_drone",
        load_if_present(asset_server, "audio/score/drone.ogg"),
        sustained_drone_curve,
        0.5, // slow crossfade — drones don't snap
        0.20,
    ));
    // Time-marking stem — dawn/dusk emphasis.
    stems.register(Stem::new(
        "time_voice",
        load_if_present(asset_server, "audio/score/time_voice.ogg"),
        dawn_dusk_emphasis as MoodCurve,
        0.6,
        0.3,
    ));
}

fn register_strings(asset_server: &AssetServer, stems: &mut StemRegistry) {
    // Low strings — enters as mood darkens.
    stems.register(Stem::new(
        "low_strings",
        load_if_present(asset_server, "audio/score/low_strings.ogg"),
        low_strings_curve,
        1.0,
        0.5,
    ));
    // High strings — precursor / threat.
    stems.register(Stem::new(
        "high_strings",
        load_if_present(asset_server, "audio/score/high_strings.ogg"),
        high_strings_curve,
        1.5,
        0.45,
    ));
}

fn register_percussion_and_recovery(asset_server: &AssetServer, stems: &mut StemRegistry) {
    // Percussion — catastrophe phase only.
    stems.register(Stem::new(
        "percussion",
        load_if_present(asset_server, "audio/score/percussion.ogg"),
        percussion_curve,
        2.0,
        0.6,
    ));
    // Melodic voice — recovery only.
    stems.register(Stem::new(
        "melodic_voice",
        load_if_present(asset_server, "audio/score/melodic_voice.ogg"),
        melodic_voice_curve,
        0.8,
        0.5,
    ));
}

// Mood curves. Each is a free function (not a closure) so it can be cast
// to `MoodCurve` (a `fn` pointer). The curves are pure; no RNG, no time.
// TUNE: every constant below is provisional.

fn sustained_drone_curve(d: &AudioDirector) -> f32 {
    // Always present, but quieter during full catastrophe (let percussion lead).
    match d.catastrophe_phase {
        CatastrophePhase::Active => 0.5,
        _ => 1.0,
    }
}

fn low_strings_curve(d: &AudioDirector) -> f32 {
    // Rises with weather threat and during catastrophe arc.
    let arc = catastrophe_arc(d);
    let weather = weather_threat(d);
    arc.max(weather)
}

fn high_strings_curve(d: &AudioDirector) -> f32 {
    // Peaks during Precursor and Imminent; recedes during Active (where
    // percussion takes the foreground).
    match d.catastrophe_phase {
        CatastrophePhase::Precursor => 0.6,
        CatastrophePhase::Imminent => 1.0,
        CatastrophePhase::Active => 0.4,
        _ => 0.0,
    }
}

fn percussion_curve(d: &AudioDirector) -> f32 {
    // Active catastrophe only.
    if d.catastrophe_phase == CatastrophePhase::Active {
        1.0
    } else {
        0.0
    }
}

fn melodic_voice_curve(d: &AudioDirector) -> f32 {
    // Aftermath and Suppressing only — the recovery arc's voice.
    match d.catastrophe_phase {
        CatastrophePhase::Suppressing => 0.7,
        CatastrophePhase::Aftermath => 1.0,
        _ => 0.0,
    }
}

// ---------- Zones ----------

/// The four positional ambient zones in Ashveil. Coordinates are in the
/// rendered world (settlement at origin, ground at y≈0), not the
/// narrative coordinates from `DEMO_VISION.md` v1.
///
/// TUNE: positions are placeholders pending the final settlement layout.
fn register_zones(asset_server: &AssetServer, zones: &mut ZoneRegistry) {
    zones.register(Zone::new(
        "watchtower_wind",
        Vec3::new(40.0, 8.0, 0.0),
        60.0,
        load_if_present(asset_server, "audio/ambient/wind_strong.ogg"),
        |d| match d.weather_mood {
            anvil_bevy::audio::WeatherMood::Threatening => 1.0,
            anvil_bevy::audio::WeatherMood::Heavy => 0.7,
            _ => 0.3,
        },
        0.4,
        1.0,
    ));

    zones.register(Zone::new(
        "river",
        Vec3::new(20.0, 0.0, -25.0),
        40.0,
        load_if_present(asset_server, "audio/ambient/river.ogg"),
        |_| 1.0, // river is always running
        0.5,
        1.0,
    ));

    zones.register(Zone::new(
        "eastern_birds",
        Vec3::new(-30.0, 2.0, 20.0),
        50.0,
        load_if_present(asset_server, "audio/ambient/birds_general.ogg"),
        bird_silence_curve,
        0.6,
        1.5,
    ));

    zones.register(Zone::new(
        "village_hum",
        Vec3::new(0.0, 1.0, 0.0),
        30.0,
        load_if_present(asset_server, "audio/ambient/village_hum.ogg"),
        |_| 1.0,
        0.5,
        0.8,
    ));
}

/// Birds silence themselves as the catastrophe approaches.
fn bird_silence_curve(d: &AudioDirector) -> f32 {
    match d.catastrophe_phase {
        CatastrophePhase::None => 1.0,
        CatastrophePhase::Precursor => 0.5,
        CatastrophePhase::Imminent => 0.1,
        _ => 0.0,
    }
}

// ---------- Stinger map ----------

/// Resolver that maps Ashveil's cues to stinger assets.
///
/// TUNE: every entry below is a placeholder. The real mapping is data
/// the project lead authors when stingers are sourced.
struct AshveilStingerResolver;

impl StingerResolver for AshveilStingerResolver {
    fn resolve(&self, _cue: &Cue) -> Option<PlayStinger> {
        // Returning None universally means: no stinger plays for any
        // cue yet. The cue dispatch pipeline still runs (events flow,
        // ducking would activate, etc.), so the moment we add an entry
        // here it works end-to-end. Keeping this stub explicit so the
        // architecture is exercised even before stinger sourcing.
        None
    }
}

// ---------- Helpers ----------

/// Load `path` from `assets/` if the file exists; otherwise return a
/// default (empty) handle. The stem/zone update systems treat handles
/// to missing assets gracefully — Bevy's `bevy_audio` won't panic on
/// an unresolved handle the way it did on a present-but-malformed
/// file, because we never spawn an `AudioPlayer` for a stem whose
/// effective volume is zero, and a missing handle that we *do* try to
/// play would only produce silence in modern bevy_audio.
fn load_if_present(asset_server: &AssetServer, path: &str) -> Handle<bevy::audio::AudioSource> {
    let on_disk = std::path::Path::new("assets").join(path);
    if on_disk.exists() {
        asset_server.load(path.to_owned())
    } else {
        Handle::default()
    }
}

