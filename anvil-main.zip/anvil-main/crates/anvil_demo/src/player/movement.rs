//! First-person movement systems for the Ashveil demo player.
//!
//! This module provides:
//! - WASD keyboard movement with configurable speeds
//! - Sprint with stamina drain
//! - Jump with vertical impulse
//! - Head bob effect (gated by HeadBobSettings)

use bevy::prelude::*;

use super::{HeadBob, HeadBobSettings, IdleState, PlayerBody, PlayerCameraState, PlayerStamina};

/// Walk speed in m/s.
const WALK_SPEED: f32 = 1.4;
/// Sprint speed in m/s.
const SPRINT_SPEED: f32 = 4.5;
/// Stamina drain rate per second while sprinting.
const STAMINA_DRAIN_RATE: f32 = 15.0;
/// Stamina regeneration rate per second.
const STAMINA_REGEN_RATE: f32 = 8.0;
/// Jump impulse strength.
const JUMP_IMPULSE: f32 = 7.0;
/// Gravity for grounded check.
const GRAVITY: f32 = -9.81;
/// Grounded check ray length.
const GROUNDED_RAY_LENGTH: f32 = 0.15;
/// Walk head bob amplitude.
const HEAD_BOB_WALK_AMPLITUDE: f32 = 0.015;
/// Sprint head bob amplitude.
const HEAD_BOB_SPRINT_AMPLITUDE: f32 = 0.025;
/// Head bob frequency multiplier.
const HEAD_BOB_FREQUENCY: f32 = 2.0 * std::f32::consts::PI;

/// Marker component for the ground plane.
#[derive(Component)]
pub struct GroundPlane;

/// Velocity component for the player body.
#[derive(Component, Default)]
pub struct PlayerVelocity {
    pub velocity: Vec3,
}

/// Grounded state for jump checking.
#[derive(Component, Default)]
pub struct Grounded {
    pub is_grounded: bool,
}

/// System that handles keyboard movement input and jump.
/// 
/// This system checks the idle state and skips applying player input
/// when the player is in TakenOver state (NPC control).
pub fn handle_keyboard_movement(
    keyboard: Res<ButtonInput<KeyCode>>,
    camera_state: Res<PlayerCameraState>,
    idle_state: Res<IdleState>,
    mut stamina: ResMut<PlayerStamina>,
    time: Res<Time>,
    mut body_query: Query<(&mut Transform, &mut PlayerVelocity, &Grounded), With<PlayerBody>>,
) {
    if camera_state.body_entity.is_none() {
        return;
    }

    // Skip player input when in TakenOver state
    // NPC system handles movement instead
    if *idle_state == IdleState::TakenOver {
        return;
    }

    let body_entity = camera_state.body_entity.unwrap();
    let Ok((mut body_transform, mut velocity, grounded)) = body_query.get_mut(body_entity) else {
        return;
    };

    // Handle jump
    if keyboard.just_pressed(KeyCode::Space) && grounded.is_grounded {
        velocity.velocity.y = JUMP_IMPULSE;
    }

    // Calculate movement direction relative to body rotation (ignore pitch)
    let mut move_dir = Vec3::ZERO;
    let forward = Vec3::new(body_transform.forward().x, 0.0, body_transform.forward().z).normalize();
    let right = Vec3::new(body_transform.right().x, 0.0, body_transform.right().z).normalize();

    if keyboard.pressed(KeyCode::KeyW) {
        move_dir += forward;
    }
    if keyboard.pressed(KeyCode::KeyS) {
        move_dir -= forward;
    }
    if keyboard.pressed(KeyCode::KeyA) {
        move_dir -= right;
    }
    if keyboard.pressed(KeyCode::KeyD) {
        move_dir += right;
    }

    // Normalize if moving
    let speed = if move_dir != Vec3::ZERO {
        move_dir = move_dir.normalize();
        if keyboard.pressed(KeyCode::ShiftLeft) || keyboard.pressed(KeyCode::ShiftRight) {
            // Check stamina
            if stamina.current > 0.0 {
                stamina.current -= STAMINA_DRAIN_RATE * time.delta_secs() as f32;
                SPRINT_SPEED
            } else {
                WALK_SPEED
            }
        } else {
            WALK_SPEED
        }
    } else {
        0.0
    };

    if speed > 0.0 {
        // Apply movement to horizontal plane only
        velocity.velocity.x = move_dir.x * speed;
        velocity.velocity.z = move_dir.z * speed;
    } else {
        // Apply friction when not moving
        velocity.velocity.x *= 0.8;
        velocity.velocity.z *= 0.8;
    }

    // Apply gravity
    if !grounded.is_grounded {
        velocity.velocity.y += GRAVITY * time.delta_secs() as f32;
    } else if velocity.velocity.y < 0.0 {
        // Stop falling velocity when grounded
        velocity.velocity.y = 0.0;
    }

    // Apply velocity to position
    body_transform.translation += velocity.velocity * time.delta_secs() as f32;
}

/// System that applies head bob effect based on movement.
/// 
/// Head bob is disabled during NPC takeover since the NPC system
/// controls the camera independently.
pub fn apply_head_bob(
    keyboard: Res<ButtonInput<KeyCode>>,
    camera_state: Res<PlayerCameraState>,
    idle_state: Res<IdleState>,
    head_bob_settings: Res<HeadBobSettings>,
    time: Res<Time>,
    mut head_bob: ResMut<HeadBob>,
    mut camera_query: Query<&mut Transform, With<super::PlayerCamera>>,
) {
    // Skip head bob when in TakenOver state
    // NPC system controls camera movement
    if *idle_state == IdleState::TakenOver {
        head_bob.offset = Vec3::ZERO;
        if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
            camera_transform.translation.y = 0.0;
        }
        return;
    }
    if !head_bob_settings.enabled {
        head_bob.offset = Vec3::ZERO;
        if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
            camera_transform.translation.y = 0.0;
        }
        return;
    }

    // Check if player is moving
    let is_moving = keyboard.pressed(KeyCode::KeyW)
        || keyboard.pressed(KeyCode::KeyS)
        || keyboard.pressed(KeyCode::KeyA)
        || keyboard.pressed(KeyCode::KeyD);

    if is_moving {
        // Determine amplitude based on sprint
        let amplitude = if keyboard.pressed(KeyCode::ShiftLeft) 
            || keyboard.pressed(KeyCode::ShiftRight) {
            HEAD_BOB_SPRINT_AMPLITUDE
        } else {
            HEAD_BOB_WALK_AMPLITUDE
        };

        // Update head bob time and calculate offset
        head_bob.time += time.delta_secs() as f32 * HEAD_BOB_FREQUENCY;
        head_bob.offset.y = (head_bob.time.sin() * amplitude) - (head_bob.time.sin() * head_bob.time.sin() * 0.5 * amplitude);
    } else {
        // Dampen head bob when not moving
        head_bob.time = 0.0;
        head_bob.offset = head_bob.offset * 0.9;
    }

    // Apply head bob offset to camera
    if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
        camera_transform.translation = head_bob.offset;
    }
}

/// System that checks if player is grounded using raycast.
/// Uses a simple downward raycast to detect if there's ground below the player.
/// The ground is assumed to be at y=0, and the player body origin is roughly at foot level.
pub fn check_grounded(
    camera_state: Res<PlayerCameraState>,
    mut body_query: Query<(&Transform, &mut Grounded), With<PlayerBody>>,
) {
    if camera_state.body_entity.is_none() {
        return;
    }

    let body_entity = camera_state.body_entity.unwrap();
    let Ok((transform, mut grounded)) = body_query.get_mut(body_entity) else {
        return;
    };

    // Simple raycast downward to check if player is grounded
    // Check if the player is close to the ground plane (y=0)
    // The player body origin is at foot level, so if y is within GROUNDED_RAY_LENGTH,
    // the player is considered grounded
    let distance_to_ground = transform.translation.y;
    grounded.is_grounded = distance_to_ground >= 0.0 && distance_to_ground <= GROUNDED_RAY_LENGTH;
}

/// System that regenerates stamina when not sprinting.
/// 
/// Stamina only regenerates when the player is in control.
/// During NPC takeover, the NPC system manages its own energy state.
pub fn regenerate_stamina(
    keyboard: Res<ButtonInput<KeyCode>>,
    idle_state: Res<IdleState>,
    time: Res<Time>,
    mut stamina: ResMut<PlayerStamina>,
) {
    // Only regenerate when player is in control
    if *idle_state == IdleState::TakenOver {
        return;
    }

    // Only regenerate if not sprinting
    let is_sprinting = keyboard.pressed(KeyCode::ShiftLeft) || keyboard.pressed(KeyCode::ShiftRight);
    
    if !is_sprinting && stamina.current < stamina.max {
        stamina.current = (stamina.current + STAMINA_REGEN_RATE * time.delta_secs() as f32).min(stamina.max);
    }
}
