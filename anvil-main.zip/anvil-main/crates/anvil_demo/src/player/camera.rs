//! First-person camera systems for the Ashveil demo player.
//!
//! This module provides:
//! - Player camera entity spawning with proper hierarchy (body + camera child)
//! - Mouse look with pitch clamping
//! - Cursor capture/release logic

use bevy::prelude::*;

use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::window::{CursorGrabMode, CursorOptions, PrimaryWindow};

use crate::player::movement::{Grounded, PlayerVelocity};

/// Resource for tracking head bob state.
#[derive(Resource, Default)]
pub struct HeadBob {
    /// Current head bob offset.
    pub offset: Vec3,
    /// Accumulated time for head bob oscillation.
    pub time: f32,
}

/// Resource tracking player camera state.
#[derive(Resource, Default)]
pub struct PlayerCameraState {
    /// Current camera yaw (radians).
    pub yaw: f32,
    /// Current camera pitch (radians).
    pub pitch: f32,
    /// Whether the cursor is currently captured.
    pub cursor_captured: bool,
    /// Entity of the camera.
    pub camera_entity: Option<Entity>,
    /// Entity of the player body (parent of camera).
    pub body_entity: Option<Entity>,
}

/// Marker component for the player body entity.
#[derive(Component)]
pub struct PlayerBody;

/// Marker component for the player camera entity.
#[derive(Component)]
pub struct PlayerCamera;

/// System that spawns the player camera and body entity.
pub fn setup_player_camera(mut commands: Commands) {
    use anvil_bevy::markers::CameraFog;
    use bevy::pbr::{DistanceFog, FogFalloff};
    use bevy::color::LinearRgba;

    // Spawn player body at (0, 2, 0) looking east
    let body_entity = commands
        .spawn((
            Transform::from_xyz(0.0, 2.0, 0.0),
            GlobalTransform::default(),
            PlayerBody,
            Name::new("Player Body"),
        ))
        .id();

    // Spawn camera as child of body
    let camera_entity = commands
        .spawn((
            Camera3d::default(),
            Camera {
                order: -1,
                ..default()
            },
            DistanceFog {
                color: Color::LinearRgba(LinearRgba::new(0.50, 0.40, 0.35, 1.0)),
                falloff: FogFalloff::Exponential { density: 0.018 },
                ..default()
            },
            Transform::from_xyz(0.0, 0.0, 0.0),
            GlobalTransform::default(),
            PlayerCamera,
            CameraFog,
            Name::new("Player Camera"),
            // FIX 5: Add SpatialListener for future spatial audio features
            SpatialListener::default(),
        ))
        .id();
    
    // Set parent after both entities exist
    commands.entity(camera_entity).insert(ChildOf(body_entity));

    // Add velocity and grounded components to player body
    commands.entity(body_entity)
        .insert(PlayerVelocity::default())
        .insert(Grounded { is_grounded: true });

    // Update camera state with entity references
    commands.insert_resource(PlayerCameraState {
        yaw: 0.0,
        pitch: 0.0,
        cursor_captured: true,
        camera_entity: Some(camera_entity),
        body_entity: Some(body_entity),
    });
}

/// System that continuously maintains cursor grab state.
/// 
/// On Wayland/Linux, the initial cursor grab at startup can silently fail
/// if the window doesn't have focus yet. This system continuously enforces
/// the grab state every frame, so even if the initial grab fails, it will
/// be re-applied once the window gains focus.
///
/// - Releases grab on Escape
/// - Re-acquires grab on left click
/// - Enforces grab state every frame while captured
pub fn maintain_cursor_grab(
    mut camera_state: ResMut<PlayerCameraState>,
    mut cursor_options: Query<&mut CursorOptions, With<PrimaryWindow>>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
) {
    let Ok(mut opts) = cursor_options.single_mut() else { return };

    // Release on Escape
    if keys.just_pressed(KeyCode::Escape) && camera_state.cursor_captured {
        opts.grab_mode = CursorGrabMode::None;
        opts.visible = true;
        camera_state.cursor_captured = false;
        return;
    }

    // Re-acquire on left click
    if mouse.just_pressed(MouseButton::Left) && !camera_state.cursor_captured {
        camera_state.cursor_captured = true;
    }

    // Enforce grab every frame while captured
    if camera_state.cursor_captured {
        opts.grab_mode = CursorGrabMode::Locked;
        opts.visible = false;
    }
}

/// System that handles mouse movement for camera look.
///
/// Reads the frame's accumulated mouse motion delta (Bevy 0.14+ idiom),
/// updates the cached yaw/pitch in `PlayerCameraState`, and applies them:
/// - yaw to the body transform (so WASD moves relative to look direction),
/// - pitch to the camera transform (so vertical look doesn't tilt the body).
///
/// Pitch is clamped to ±89° (i.e. ±π/2 with a small margin) to prevent
/// the camera from flipping upside down at the zenith / nadir.
pub fn handle_mouse_look(
    mouse_motion: Res<AccumulatedMouseMotion>,
    sensitivity: Res<crate::player::MouseSensitivity>,
    mut camera_state: ResMut<PlayerCameraState>,
    mut body_query: Query<&mut Transform, (With<PlayerBody>, Without<PlayerCamera>)>,
    mut camera_query: Query<&mut Transform, (With<PlayerCamera>, Without<PlayerBody>)>,
) {
    if !camera_state.cursor_captured {
        return;
    }
    let delta = mouse_motion.delta;
    if delta == Vec2::ZERO {
        return;
    }

    // Update cached yaw and pitch.
    camera_state.yaw -= delta.x * sensitivity.0;
    camera_state.pitch -= delta.y * sensitivity.0;
    let pitch_limit = std::f32::consts::FRAC_PI_2 - 0.01;
    camera_state.pitch = camera_state.pitch.clamp(-pitch_limit, pitch_limit);

    // Apply yaw to the body so WASD respects look direction.
    if let Some(body) = camera_state.body_entity {
        if let Ok(mut body_transform) = body_query.get_mut(body) {
            body_transform.rotation = Quat::from_rotation_y(camera_state.yaw);
        }
    }
    // Apply pitch to the camera.
    if let Some(cam) = camera_state.camera_entity {
        if let Ok(mut camera_transform) = camera_query.get_mut(cam) {
            camera_transform.rotation = Quat::from_rotation_x(camera_state.pitch);
        }
    }
}
