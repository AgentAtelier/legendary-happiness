//! First-person player systems for the Ashveil demo.
//!
//! This module owns the player's camera, movement, and idle-takeover
//! behaviour. It replaces the former `bevy_flycam` dependency with a
//! hand-rolled first-person controller integrated with the Rapier3D
//! physics world and the player's NPC entry in the simulation.

mod camera;
mod idle;
mod movement;

use bevy::prelude::*;

pub use camera::{HeadBob, PlayerBody, PlayerCamera, PlayerCameraState};
pub use idle::{IdleState, TimeSinceLastInput, ViewerNpcEntity};
use camera::{setup_player_camera, maintain_cursor_grab, handle_mouse_look};
use idle::{detect_input_and_reset_timer, apply_idle_takeover, handle_idle_return, spawn_idle_vignette, update_vignette, update_cursor_grab};
use movement::{handle_keyboard_movement, apply_head_bob, regenerate_stamina, check_grounded};

/// Mouse sensitivity setting (radians per pixel).
#[derive(Resource)]
pub struct MouseSensitivity(pub f32);

impl Default for MouseSensitivity {
    fn default() -> Self {
        Self(0.003)
    }
}

/// Head bob settings.
#[derive(Resource)]
pub struct HeadBobSettings {
    pub enabled: bool,
}

impl Default for HeadBobSettings {
    fn default() -> Self {
        Self { enabled: true }
    }
}

/// Player stamina for sprinting.
#[derive(Resource)]
pub struct PlayerStamina {
    pub current: f32,
    pub max: f32,
}

impl Default for PlayerStamina {
    fn default() -> Self {
        Self {
            current: 100.0,
            max: 100.0,
        }
    }
}

/// Plugin that installs all player systems.
///
/// Add this to the app during Phase 1 to activate the first-person
/// controller and idle-takeover behaviour.
pub struct PlayerPlugin;

impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        // Insert resources
        app.init_resource::<MouseSensitivity>()
            .init_resource::<HeadBobSettings>()
            .init_resource::<PlayerStamina>()
            .init_resource::<PlayerCameraState>()
            .init_resource::<HeadBob>()
            .init_resource::<TimeSinceLastInput>()
            .init_resource::<IdleState>()
            .init_resource::<ViewerNpcEntity>();

        // Add systems
        app.add_systems(Startup, (
            setup_player_camera,
            spawn_idle_vignette,
            crate::camera::despawn_gltf_cameras,
            crate::camera::set_camera_priorities,
        ).chain())
        .add_systems(PreUpdate, (
            maintain_cursor_grab,
        ))
        .add_systems(Update, (
            // Input detection must run first
            detect_input_and_reset_timer,
            handle_mouse_look,
            // Apply idle takeover after input detection
            apply_idle_takeover,
            // Handle return from takeover
            handle_idle_return,
            // Update cursor grab based on state
            update_cursor_grab,
            // Grounded check must run before movement
            check_grounded.before(handle_keyboard_movement),
            // Player movement - runs after idle detection and grounded check
            handle_keyboard_movement,
            apply_head_bob,
            regenerate_stamina,
            // Update vignette visualization last
            update_vignette,
        ));
    }
}
