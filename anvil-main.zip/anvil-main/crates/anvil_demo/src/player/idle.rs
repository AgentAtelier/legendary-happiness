//! Idle takeover system for the Ashveil demo player.
//!
//! This module implements the "idle takeover" mechanism where the player's
//! body is transferred to NPC control after 60 seconds of inactivity.
//! This expresses Pillar I: "the player is an inhabitant, not a hero."
//!
//! The viewer's body continues living in the simulation even when they
//! are not providing input.

use bevy::prelude::*;

use crate::app::RuntimeResource;
use anvil_sim::settlement::ids::{FamilyId, PersonId};

/// Time threshold (in seconds) before idle takeover activates.
const IDLE_THRESHOLD: f32 = 60.0;
/// Time to fade in the vignette (seconds).
const VIGNETTE_FADE_IN: f32 = 2.0;
/// Time to fade out the vignette (seconds).
const VIGNETTE_FADE_OUT: f32 = 0.5;
/// Maximum vignette opacity.
const VIGNETTE_MAX_OPACITY: f32 = 0.15;
/// Viewer NPC ID - the ninth villager.
const VIEWER_PERSON_ID: u64 = 9;

/// Tracks time since the last player input.
#[derive(Resource)]
pub struct TimeSinceLastInput {
    /// Time in seconds since last input.
    pub seconds: f32,
}

impl Default for TimeSinceLastInput {
    fn default() -> Self {
        Self { seconds: 0.0 }
    }
}

/// Idle state machine for player control.
#[derive(Resource, Default, PartialEq, Eq, Clone, Copy, Debug)]
pub enum IdleState {
    /// Player has active control.
    #[default]
    PlayerControlled,
    /// NPC system has taken over control.
    TakenOver,
}



/// Marker component for the idle vignette UI entity.
#[derive(Component)]
pub struct IdleVignette;

/// Tracks the viewer's NPC entry in the simulation.
/// None means the viewer NPC has not been created yet.
#[derive(Resource)]
pub struct ViewerNpcEntity {
    pub person_id: Option<PersonId>,
}

impl Default for ViewerNpcEntity {
    fn default() -> Self {
        Self { person_id: None }
    }
}

/// System that detects player input and resets the idle timer.
/// 
/// Checks for: WASD, Space, Shift, mouse buttons.
/// Mouse motion detection is deferred pending Bevy 0.18 event system compatibility.
pub fn detect_input_and_reset_timer(
    keyboard: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    time: Res<Time>,
    mut idle_timer: ResMut<TimeSinceLastInput>,
    mut idle_state: ResMut<IdleState>,
) {
    // Check if any relevant input is active
    let has_keyboard_input = keyboard.any_pressed([
        KeyCode::KeyW,
        KeyCode::KeyA,
        KeyCode::KeyS,
        KeyCode::KeyD,
        KeyCode::Space,
        KeyCode::ShiftLeft,
        KeyCode::ShiftRight,
    ]);

    let has_mouse_button_input = mouse_buttons.any_pressed([
        MouseButton::Left,
        MouseButton::Right,
        MouseButton::Middle,
    ]);

    // TODO: Add mouse motion detection when Bevy 0.18 event system is sorted
    // For now, we only check keyboard and mouse buttons
    let has_input = has_keyboard_input || has_mouse_button_input;

    if has_input {
        // Reset timer on any input (unless we're in fade-out mode)
        if idle_timer.seconds >= 0.0 {
            idle_timer.seconds = 0.0;
        }
        
        // If we were taken over, mark that we want to return
        // The actual return happens in handle_idle_return
        if *idle_state == IdleState::TakenOver {
            // Start fade-out by setting timer to negative FADE_OUT value
            // This signals update_vignette to fade out over VIGNETTE_FADE_OUT seconds
            idle_timer.seconds = -VIGNETTE_FADE_OUT;
            *idle_state = IdleState::PlayerControlled;
        }
    } else {
        // Accumulate idle time (including fade-out timer which goes from negative to 0)
        idle_timer.seconds += time.delta_secs() as f32;
    }
}

/// System that applies idle takeover when threshold is exceeded.
pub fn apply_idle_takeover(
    mut commands: Commands,
    idle_timer: Res<TimeSinceLastInput>,
    mut idle_state: ResMut<IdleState>,
    mut viewer_npc: ResMut<ViewerNpcEntity>,
    mut runtime: Option<ResMut<RuntimeResource>>,
) {
    // Only transition if we're currently player-controlled and threshold exceeded
    if *idle_state == IdleState::PlayerControlled && idle_timer.seconds >= IDLE_THRESHOLD {
        *idle_state = IdleState::TakenOver;
        
        // Log the transition
        info!("Idle takeover activated: viewer body transferred to NPC control");
        
        // Ensure viewer NPC exists in the simulation
        ensure_viewer_npc_exists(&mut commands, runtime.as_deref_mut(), &mut viewer_npc);
    }
}

/// Ensures the viewer NPC exists in the NpcSystem.
/// 
/// The viewer is the ninth villager (PersonId::new(9)). If it doesn't exist,
/// we create a minimal NPC entry with neutral substrate.
fn ensure_viewer_npc_exists(
    _commands: &mut Commands,
    runtime: Option<&mut RuntimeResource>,
    viewer_npc: &mut ResMut<ViewerNpcEntity>,
) {
    // Check if viewer NPC already exists
    if viewer_npc.person_id.is_some() {
        return;
    }

    if let Some(runtime) = runtime {
        // Try to find the viewer NPC in existing systems
        let viewer_id = PersonId::new(VIEWER_PERSON_ID);
        
        // Check if viewer already exists in any NpcSystem
        for system in &runtime.runtime.systems {
            if let Some(npc_system) = system.as_any().downcast_ref::<anvil_sim::NpcSystem>() {
                if npc_system.persons.iter().any(|p| p.id.get() == VIEWER_PERSON_ID) {
                    viewer_npc.person_id = Some(viewer_id);
                    return;
                }
            }
        }

        // Viewer NPC doesn't exist - we need to add it
        // For now, we add it to the first NpcSystem we find
        // TODO: This should be done through proper runtime commands
        for system in &mut runtime.runtime.systems {
            if let Some(npc_system) = system.as_any_mut().downcast_mut::<anvil_sim::NpcSystem>() {
                // We need a family for the person
                // Check if there's an existing family or create one
                let family_id = FamilyId::new(9); // Viewer family
                
                // Check if family exists
                let has_family = npc_system.families.iter().any(|f| f.id.get() == 9);
                if !has_family {
                    let family = anvil_sim::settlement::Family::new(
                        family_id,
                        vec![viewer_id],
                    );
                    npc_system.add_family(family);
                }
                
                // Create the viewer person with neutral substrate
                let person = anvil_sim::settlement::Person::new_simple(
                    viewer_id,
                    "Viewer".to_string(),
                    family_id,
                );
                
                npc_system.add_person(person);
                viewer_npc.person_id = Some(viewer_id);
                
                info!("Created viewer NPC with PersonId({})", VIEWER_PERSON_ID);
                return;
            }
        }
        
        // If no NpcSystem found, log a warning
        warn!("No NpcSystem found to add viewer NPC");
    }
}

/// System that handles the return from idle takeover to player control.
/// 
/// This provides a soft return: the vignette fades out over 0.5 seconds
/// and control returns to the player.
pub fn handle_idle_return(
    keyboard: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut idle_state: ResMut<IdleState>,
    mut idle_timer: ResMut<TimeSinceLastInput>,
) {
    // If we're in TakenOver state and any input is detected, return control
    if *idle_state == IdleState::TakenOver {
        let has_keyboard_input = keyboard.any_just_pressed([
            KeyCode::KeyW,
            KeyCode::KeyA,
            KeyCode::KeyS,
            KeyCode::KeyD,
            KeyCode::Space,
            KeyCode::ShiftLeft,
            KeyCode::ShiftRight,
        ]);

        let has_mouse_button_input = mouse_buttons.any_just_pressed([
            MouseButton::Left,
            MouseButton::Right,
            MouseButton::Middle,
        ]);

        // TODO: Add mouse motion detection when Bevy 0.18 event system is sorted
        if has_keyboard_input || has_mouse_button_input {
            *idle_state = IdleState::PlayerControlled;
            // Start fade-out by setting timer to negative FADE_OUT value
            // Don't reset to 0 if already in fade-out mode
            if idle_timer.seconds >= 0.0 {
                idle_timer.seconds = -VIGNETTE_FADE_OUT;
            }
            
            info!("Idle takeover ended: control returned to player");
        }
    }
}

/// System that spawns the idle vignette UI entity.
pub fn spawn_idle_vignette(
    mut commands: Commands,
) {
    // Spawn a full-screen node for the vignette
    // The node is initially hidden and will be shown when takeover activates
    commands.spawn((
        Node {
            position_type: bevy::ui::PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            ..default()
        },
        BackgroundColor::from(Color::srgba(0.0, 0.0, 0.0, 0.0)),
        IdleVignette,
        Name::new("Idle Vignette"),
        Visibility::Hidden,
        ZIndex(1000), // Higher than HUD elements
    ));
}

/// System that updates the vignette visibility and opacity based on idle state.
pub fn update_vignette(
    idle_state: Res<IdleState>,
    idle_timer: Res<TimeSinceLastInput>,
    mut vignette_query: Query<(&mut BackgroundColor, &mut Visibility), With<IdleVignette>>,
) {
    // Get the first vignette entity (there should only be one)
    if let Some((mut bg_color, mut visibility)) = vignette_query.iter_mut().next() {
        match *idle_state {
            IdleState::PlayerControlled => {
                // Handle fade-out when timer is negative (returning from takeover)
                if idle_timer.seconds < 0.0 {
                    // Fading out: timer goes from -VIGNETTE_FADE_OUT to 0
                    let fade_progress = (-idle_timer.seconds) / VIGNETTE_FADE_OUT;
                    let opacity = (1.0 - fade_progress.clamp(0.0, 1.0)) * VIGNETTE_MAX_OPACITY;
                    bg_color.0 = Color::srgba(0.0, 0.0, 0.0, opacity.max(0.0));
                    *visibility = Visibility::Visible;
                    return;
                }
                
                // Normal behavior: fade in when approaching takeover
                if idle_timer.seconds >= IDLE_THRESHOLD - VIGNETTE_FADE_IN {
                    // We're approaching takeover - start fading in
                    let fade_progress = (idle_timer.seconds - (IDLE_THRESHOLD - VIGNETTE_FADE_IN)) 
                        / VIGNETTE_FADE_IN;
                    let opacity = (fade_progress.clamp(0.0, 1.0) * VIGNETTE_MAX_OPACITY).min(VIGNETTE_MAX_OPACITY);
                    bg_color.0 = Color::srgba(0.0, 0.0, 0.0, opacity);
                    *visibility = Visibility::Visible;
                } else {
                    // Fully hidden
                    bg_color.0 = Color::srgba(0.0, 0.0, 0.0, 0.0);
                    *visibility = Visibility::Hidden;
                }
            }
            IdleState::TakenOver => {
                // Fully visible at max opacity
                bg_color.0 = Color::srgba(0.0, 0.0, 0.0, VIGNETTE_MAX_OPACITY);
                *visibility = Visibility::Visible;
            }
        }
    }
}

/// System that locks cursor when player regains control.
/// 
/// TODO: Implement cursor grab when Bevy 0.18 window API is sorted.
/// For now, this is a placeholder - cursor control is deferred.
#[allow(dead_code)]
pub fn update_cursor_grab(
    idle_state: Res<IdleState>,
) {
    // Cursor grab implementation deferred pending Bevy 0.18 API compatibility
    let _ = idle_state;
}

/// System that prevents player movement systems from running during takeover.
/// 
/// This is done by adding/removing a marker component that movement systems
/// can check, or by using system ordering. For now, we use the state directly.
/// 
/// In the movement systems, we should check for IdleState::TakenOver and skip
/// applying player input. The NPC system will handle movement instead.
///
/// The `idle_state` resource is referenced via the system signature so that
/// Bevy schedules this marker system after any other system that mutates
/// `IdleState`; the body of the system is intentionally empty. The leading
/// underscore is the warning-suppressing form for parameters that exist for
/// scheduling effect only.
#[allow(dead_code)]
pub fn block_player_movement_during_takeover(
    _idle_state: Res<IdleState>,
    // This system doesn't need to do anything - movement systems should check the state
) {
    // Marker system for ordering. Movement systems should run after this
    // and check the idle state before applying input.
}
