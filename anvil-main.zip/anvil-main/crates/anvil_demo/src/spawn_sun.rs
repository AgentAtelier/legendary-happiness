//! Sun spawning system for the Ashveil demo.

use bevy::color::LinearRgba;
use bevy::light::{CascadeShadowConfigBuilder, DirectionalLight};
use bevy::prelude::*;
use anvil_bevy::markers::SunLight;

/// Spawn the directional light (sun) with cascade shadow maps.
pub fn spawn_sun(mut commands: Commands) {
    commands.spawn((
        DirectionalLight {
            color: Color::LinearRgba(LinearRgba::new(1.0, 0.72, 0.44, 1.0)),
            illuminance: 5000.0,
            shadows_enabled: true,
            shadow_depth_bias: 0.02,
            shadow_normal_bias: 1.8,
            ..default()
        },
        CascadeShadowConfigBuilder {
            num_cascades: 3,
            minimum_distance: 0.1,
            maximum_distance: 200.0,
            first_cascade_far_bound: 12.0,
            overlap_proportion: 0.15,
        }.build(),
        Transform::default(),
        SunLight,
    ));
}
