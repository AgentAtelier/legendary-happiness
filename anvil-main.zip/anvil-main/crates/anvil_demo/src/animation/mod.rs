//! Animation module for Anvil Demo
//!
//! Contains the animation registry and related systems.

#![allow(unused_imports)]

pub mod registry;

pub use registry::AnimationRegistry;
