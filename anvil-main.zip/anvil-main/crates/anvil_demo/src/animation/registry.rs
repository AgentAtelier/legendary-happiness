use bevy::prelude::*;
use std::collections::HashMap;

/// Resource that stores animation paths for character animations
#[derive(Resource, Debug, Clone)]
pub struct AnimationRegistry {
    /// Map from animation name to asset path
    pub animations: HashMap<String, String>,
}

impl Default for AnimationRegistry {
    fn default() -> Self {
        let mut animations = HashMap::new();

        // Universal Animation Library mappings
        animations.insert("idle".to_string(), "animations/quaternius/library1/Unreal-Godot/UAL1_Standard.glb#Animation0".to_string());
        animations.insert("walk".to_string(), "animations/quaternius/library1/Unreal-Godot/UAL1_Standard.glb#Animation1".to_string());
        animations.insert("run".to_string(), "animations/quaternius/library1/Unreal-Godot/UAL1_Standard.glb#Animation2".to_string());
        animations.insert("jump".to_string(), "animations/quaternius/library1/Unreal-Godot/UAL1_Standard.glb#Animation3".to_string());
        animations.insert("attack".to_string(), "animations/quaternius/library1/Unreal-Godot/UAL1_Standard.glb#Animation4".to_string());

        // Library 2 (additional animations)
        animations.insert("sit".to_string(), "animations/quaternius/library2/Unreal-Godot/UAL2_Standard.glb#Animation0".to_string());
        animations.insert("stand_up".to_string(), "animations/quaternius/library2/Unreal-Godot/UAL2_Standard.glb#Animation1".to_string());
        animations.insert("wave".to_string(), "animations/quaternius/library2/Unreal-Godot/UAL2_Standard.glb#Animation2".to_string());

        Self { animations }
    }
}

impl AnimationRegistry {
    /// Create a new AnimationRegistry with default mappings
    pub fn new() -> Self {
        Self::default()
    }

    /// Get the animation path for a given name
    pub fn get_path(&self, name: &str) -> Option<&String> {
        self.animations.get(name)
    }

    /// Check if an animation exists
    pub fn has_animation(&self, name: &str) -> bool {
        self.animations.contains_key(name)
    }

    /// Get all animation names
    pub fn animation_names(&self) -> Vec<&String> {
        self.animations.keys().collect()
    }

    /// Add a custom animation mapping
    pub fn add_animation(&mut self, name: String, path: String) {
        self.animations.insert(name, path);
    }
}
