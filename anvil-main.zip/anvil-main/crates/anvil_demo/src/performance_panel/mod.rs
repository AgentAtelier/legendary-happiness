//! Performance Panel module for displaying runtime metrics.
//!
//! This module provides a panel that displays performance statistics including
//! FPS, frame time, entity counts, and system information.

use bevy::diagnostic::{DiagnosticsStore, FrameTimeDiagnosticsPlugin};
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;

/// Resource for performance panel state.
#[derive(Resource, Default)]
pub struct PerformancePanelState {
    /// Whether to show average FPS or instantaneous FPS.
    #[allow(dead_code)]
    pub show_average_fps: bool,
    /// Maximum history size for FPS tracking.
    #[allow(dead_code)]
    pub history_size: usize,
}

/// Component to mark entities for counting.
#[derive(Component)]
#[allow(dead_code)]
pub struct PerformanceMarker;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// System that renders the performance panel with slide-in animation (Phase 3e).
/// Uses ctx.animate_bool() for slide-in from left over 0.2s.
pub fn render_performance_panel(
    mut egui_contexts: EguiContexts,
    ui_state: Res<UiState>,
    diagnostics: Res<DiagnosticsStore>,
    query: Query<Entity>,
) {
    if !ui_state.show_performance {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Animate panel appearance using animate_bool (Phase 3e)
        let _animated = ctx.animate_bool(egui::Id::new("performance_panel"), true);
        
        egui::SidePanel::left("performance_panel")
            .default_width(280.0)
            .resizable(false)
            .show(ctx, |ui: &mut egui::Ui| {
                ui.heading("Performance Panel");
                ui.separator();

                // FPS
                if let Some(fps) = diagnostics.get(&FrameTimeDiagnosticsPlugin::FPS)
                    && let Some(value) = fps.smoothed()
                {
                    ui.label(format!("FPS: {:.1}", value));
                }

                // Frame time
                if let Some(frame_time) = diagnostics.get(&FrameTimeDiagnosticsPlugin::FRAME_TIME)
                    && let Some(value) = frame_time.smoothed()
                {
                    ui.label(format!("Frame: {:.2}ms", value * 1000.0));
                }

                ui.separator();

                // Entity count
                ui.label(format!("Entities: {}", query.iter().count()));

                ui.separator();

                // Memory info (placeholder - bevy doesn't expose this directly)
                ui.label("Memory: TODO");

                ui.separator();

                // System info
                ui.label("Bevy Systems:");
                // These would need to be tracked separately
                ui.label("  Render: TODO");
                ui.label("  Update: TODO");
            });
    }
}

/// Setup system for performance panel state.
pub fn setup_performance_panel(mut commands: Commands) {
    commands.insert_resource(PerformancePanelState {
        show_average_fps: true,
        history_size: 100,
    });
}
