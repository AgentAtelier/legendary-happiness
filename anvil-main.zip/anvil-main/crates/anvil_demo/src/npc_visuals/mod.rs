//! NPC Visuals module for rendering NPCs in the demo.
//!
//! This module provides the visual representation of NPCs with:
//! - Procedural humanoid mesh (cylinder body + sphere head)
//! - Mood-to-colour mapping
//! - Clothing variation
//! - Idle breathing animation
//! - Action halos
//! - Action labels
//! - Fluency indicators
//! - Status rings

use anvil_sim::settlement::Person;
use anvil_sim::skill::fluency::FluencyLevel;
use bevy::pbr::StandardMaterial;
use bevy::prelude::*;
use bevy::sprite::Text2d;
use bevy::text::{Font, Justify, TextColor, TextFont, TextLayout};

use crate::ui::inspector_panel::SelectedNpc;
use crate::npc::{npc_body_color, spawn_humanoid_npc, update_npc_breathing, HumanoidVisual, NpcBaseY, BreathingPhase};

/// Type alias for the complex NPC visual query to satisfy clippy::type_complexity
pub type NpcVisualQuery = Or<(With<NpcVisual>, With<HumanoidVisual>, With<ActionHalo>, With<FluencyIndicator>, With<StatusRing>, With<ActionLabel>, With<SelectionRing>)>;

/// Component marking an entity as an NPC visual representation.
#[derive(Component)]
pub struct NpcVisual {
    #[allow(dead_code)]
    pub person_id: u64,
    #[allow(dead_code)]
    pub name: String,
    #[allow(dead_code)]
    pub age_category: String,
    #[allow(dead_code)]
    pub current_action: String,
}

/// Component for selection highlight torus ring.
#[derive(Component)]
pub struct SelectionRing {
    /// Phase offset for pulsing animation.
    pub phase_offset: f32,
}

/// Selection ring color - warm gold (#E5C175).
#[allow(dead_code)]
pub const SELECTION_RING_COLOR: Color = Color::srgb(0.902, 0.7569, 0.4588);

/// Selection ring radius.
#[allow(dead_code)]
pub const SELECTION_RING_RADIUS: f32 = 0.3;

/// Selection ring tube radius.
#[allow(dead_code)]
pub const SELECTION_RING_TUBE: f32 = 0.015;

/// Component for action label text.
#[derive(Component)]
pub struct ActionLabel {
    #[allow(dead_code)]
    pub text: String,
}

/// Component for action halo (pulse effect).
#[derive(Component)]
pub struct ActionHalo {
    pub pulse_timer: f32,
    pub max_scale: f32,
}

/// Component marking a fluency indicator visualization.
#[derive(Component)]
pub struct FluencyIndicator {
    #[allow(dead_code)]
    pub level: FluencyLevel,
    #[allow(dead_code)]
    pub average_maturity: f32,
}

/// Component marking a status ring visualization.
#[derive(Component)]
pub struct StatusRing {
    #[allow(dead_code)]
    pub ring_type: StatusRingType,
    #[allow(dead_code)]
    pub radius: f32,
}

/// Type of status ring.
#[derive(Clone, Copy, PartialEq)]
pub enum StatusRingType {
    Needs,
    Emotion,
    Fluency,
}

/// Resource tracking NPC visual state.
#[derive(Resource, Default)]
pub struct NpcVisualState {
    pub spawned_person_ids: std::collections::HashSet<u64>,
}

/// Scale factor for different age categories.
#[allow(dead_code)]
pub fn age_scale(age_category: &str) -> f32 {
    match age_category.to_lowercase().as_str() {
        "child" => 0.6,
        "elder" => 1.0,
        _ => 1.0,
    }
}

/// Calculates the average maturity and fluency level for a person.
pub fn calculate_fluency(person: &Person) -> (FluencyLevel, f32) {
    let unlocked_count = person.skill_profile.unlocked.len();
    let total_maturity: f32 = person.skill_profile.maturities.values()
        .map(|m| m.maturity)
        .sum();
    let maturity_count = person.skill_profile.maturities.len().max(1);
    let average_maturity = total_maturity / maturity_count as f32;
    let fluency_level = FluencyLevel::from_unlocked_count(unlocked_count);
    (fluency_level, average_maturity)
}

/// Returns the color for a fluency level.
pub fn fluency_color(level: FluencyLevel, _average_maturity: f32) -> Color {
    match level {
        FluencyLevel::Halting => Color::srgb(0.5, 0.0, 0.0),
        FluencyLevel::Awkward => Color::srgb(0.8, 0.4, 0.0),
        FluencyLevel::Competent => Color::srgb(0.8, 0.8, 0.0),
        FluencyLevel::Smooth => Color::srgb(0.4, 0.8, 0.0),
        FluencyLevel::Expert => Color::srgb(0.0, 0.8, 0.8),
    }
}

/// Status ring colors based on type.
pub fn status_ring_color(ring_type: StatusRingType) -> Color {
    match ring_type {
        StatusRingType::Needs => Color::srgb(1.0, 0.3, 0.3),    // Red
        StatusRingType::Emotion => Color::srgb(0.3, 1.0, 0.3),  // Green
        StatusRingType::Fluency => Color::srgb(0.3, 0.3, 1.0),  // Blue
    }
}

/// Spawn a torus ring for status visualization.
pub fn spawn_status_ring(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    position: Vec3,
    ring_type: StatusRingType,
    radius: f32,
) -> Entity {
    let torus = Mesh::from(Torus::new(radius, 0.02));
    let torus_handle = meshes.add(torus);

    let color = status_ring_color(ring_type);
    let material = StandardMaterial {
        base_color: color,
        emissive: color.to_linear(),
        emissive_exposure_weight: 1.5,
        ..default()
    };
    let material_handle = materials.add(material);

    commands.spawn((
        Mesh3d(torus_handle),
        MeshMaterial3d(material_handle),
        Transform::from_translation(position + Vec3::new(0.0, 0.1, 0.0))
            .with_rotation(Quat::from_rotation_x(std::f32::consts::PI / 2.0)),
        StatusRing { ring_type, radius },
    )).id()
}

/// Spawn a selection highlight ring at an NPC's feet.
/// Torus with radius 0.3, tube 0.015, color #E5C175, pulsing ±5%.
pub fn spawn_selection_ring(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    position: Vec3,
    phase_offset: f32,
) -> Entity {
    let torus = Mesh::from(Torus::new(SELECTION_RING_RADIUS, SELECTION_RING_TUBE));
    let torus_handle = meshes.add(torus);

    let ring_material = StandardMaterial {
        base_color: SELECTION_RING_COLOR,
        emissive: SELECTION_RING_COLOR.to_linear(),
        emissive_exposure_weight: 1.5,
        ..default()
    };
    let material_handle = materials.add(ring_material);

    let transform = Transform::from_translation(position + Vec3::new(0.0, 0.01, 0.0))
        .with_rotation(Quat::from_rotation_x(std::f32::consts::PI / 2.0));

    commands.spawn((
        Mesh3d(torus_handle),
        MeshMaterial3d(material_handle),
        transform,
        SelectionRing { phase_offset },
    )).id()
}

/// Spawn an action halo (pulse ring) for an NPC.
pub fn spawn_action_halo(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    position: Vec3,
) -> Entity {
    let torus = Mesh::from(Torus::new(0.7, 0.03));
    let torus_handle = meshes.add(torus);

    let halo_material = StandardMaterial {
        base_color: Color::srgb(0.8, 0.8, 1.0),
        emissive: LinearRgba::new(0.5, 0.5, 1.0, 1.0),
        emissive_exposure_weight: 2.0,
        alpha_mode: AlphaMode::Blend,
        ..default()
    };
    let material_handle = materials.add(halo_material);

    let halo_transform = Transform::from_translation(position + Vec3::new(0.0, 0.5, 0.0))
        .with_rotation(Quat::from_rotation_x(std::f32::consts::PI / 2.0));

    commands.spawn((
        Mesh3d(torus_handle),
        MeshMaterial3d(material_handle),
        halo_transform,
        ActionHalo {
            pulse_timer: 0.0,
            max_scale: 1.2,
        },
    )).id()
}

/// Spawn a fluency indicator bar above an NPC.
pub fn spawn_fluency_indicator(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    fluency_level: FluencyLevel,
    average_maturity: f32,
    position: Vec3,
) -> Entity {
    let bar_length = average_maturity * 1.0;
    let bar_width = 0.1;
    let bar_height = 0.05;

    let cuboid = Mesh::from(Cuboid::new(bar_length, bar_height, bar_width));
    let cuboid_handle = meshes.add(cuboid);

    let color = fluency_color(fluency_level, average_maturity);
    let material = StandardMaterial {
        base_color: color,
        emissive: color.to_linear(),
        emissive_exposure_weight: 1.5,
        ..default()
    };
    let material_handle = materials.add(material);

    let bar_position = position + Vec3::new(0.0, 1.8 + 0.2, 0.0);

    commands.spawn((
        Mesh3d(cuboid_handle),
        MeshMaterial3d(material_handle),
        Transform::from_translation(bar_position),
        FluencyIndicator {
            level: fluency_level,
            average_maturity,
        },
    )).id()
}

/// Spawn a world-space action label for an NPC.
pub fn spawn_action_label(
    commands: &mut Commands,
    action_text: String,
    position: Vec3,
    mood: f32,
) -> Entity {
    let text_color = if mood > 0.0 {
        Color::srgb(0.8, 1.0, 0.8)
    } else {
        Color::srgb(1.0, 0.8, 0.8)
    };

    let font: Handle<Font> = Default::default();
    let text_font = TextFont {
        font,
        font_size: 16.0,
        ..default()
    };

    let text_layout = TextLayout::new_with_justify(Justify::Center);

    commands.spawn((
        Text2d::new(action_text.clone()),
        text_font,
        TextColor(text_color),
        text_layout,
        Transform::from_translation(position + Vec3::new(0.0, 2.0, 0.0)),
        ActionLabel { text: action_text },
    )).id()
}

/// Spawn all visual elements for an NPC.
pub fn spawn_npc_visuals_for_person(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    _asset_server: &Res<AssetServer>,
    person: &Person,
    position: Vec3,
) {
    let person_id = person.id.get();
    let mood = person.emotional_state.mood();
    let (fluency_level, average_maturity) = calculate_fluency(person);

    // Calculate NPC color using mood-to-colour mapping
    let body_color = npc_body_color(person_id, mood);

    // Apply elder tint if elder
    let final_color = if format!("{:?}", person.age_category).to_lowercase() == "elder" {
        // Mix with grey at 50%
        let body_rgba: LinearRgba = body_color.to_linear();
        Color::srgb(
            body_rgba.red * 0.5 + 0.6 * 0.5,
            body_rgba.green * 0.5 + 0.6 * 0.5,
            body_rgba.blue * 0.5 + 0.6 * 0.5,
        )
    } else {
        body_color
    };

    // Spawn humanoid mesh with fluency level for gait speed (Phase 2e)
    spawn_humanoid_npc(commands, meshes, materials, person_id, position, final_color, Some(fluency_level));

    // Spawn action halo
    spawn_action_halo(commands, meshes, materials, position);

    // Spawn fluency indicator
    spawn_fluency_indicator(commands, meshes, materials, fluency_level, average_maturity, position);

    // Spawn status rings
    spawn_status_ring(commands, meshes, materials, position, StatusRingType::Needs, 0.5);
    spawn_status_ring(commands, meshes, materials, position, StatusRingType::Emotion, 0.8);
    spawn_status_ring(commands, meshes, materials, position, StatusRingType::Fluency, 1.1);

    // Spawn action label
    let action_text = person.current_action_id
        .map(|id| format!("Action {}", id))
        .unwrap_or_else(|| "Idle".to_string());
    spawn_action_label(commands, action_text, position, mood);
}

/// System that spawns NPC visuals when enabled.
pub fn spawn_npc_visuals(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    asset_server: Res<AssetServer>,
    runtime: Option<Res<crate::app::RuntimeResource>>,
    ui_state: Res<crate::ui::panel::UiState>,
    mut npc_visual_state: ResMut<NpcVisualState>,
) {
    let Some(runtime) = runtime else { return };
    if !ui_state.show_npc_visuals {
        // Despawn existing NPC visuals
        return;
    }

    // Access the NPC system through the runtime accessor
    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    for person in &npc_system.persons {
        let person_id = person.id.get();
        if npc_visual_state.spawned_person_ids.insert(person_id) {
            // Calculate position in a circle
            let angle = (person.id.get() as f32 * 45.0).to_radians();
            let radius = 3.0 + (person.id.get() % 3) as f32 * 1.5;
            let position = Vec3::new(
                radius * angle.cos(),
                0.0,
                radius * angle.sin(),
            );
            spawn_npc_visuals_for_person(
                &mut commands,
                &mut meshes,
                &mut materials,
                &asset_server,
                person,
                position,
            );
        }
    }
}

/// System that despawns NPC visuals when disabled.
pub fn despawn_npc_visuals(
    mut commands: Commands,
    npc_visuals: Query<Entity, NpcVisualQuery>,
    ui_state: Res<crate::ui::panel::UiState>,
    mut npc_visual_state: ResMut<NpcVisualState>,
) {
    if ui_state.show_npc_visuals {
        return;
    }

    for entity in npc_visuals.iter() {
        commands.entity(entity).despawn();
    }
    npc_visual_state.spawned_person_ids.clear();
}

/// System that animates action halos with a pulsing effect.
pub fn update_action_halos(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &mut ActionHalo)>,
) {
    for (mut transform, mut halo) in query.iter_mut() {
        halo.pulse_timer += time.delta_secs();
        let pulse_speed = 2.0;
        let t = (halo.pulse_timer % pulse_speed) / pulse_speed;
        let scale = 1.0 + (halo.max_scale - 1.0) * (0.5 + 0.5 * (2.0 * std::f32::consts::PI * t).sin());
        transform.scale = Vec3::splat(scale);
    }
}

/// System to update NPC breathing animations.
pub fn update_npc_breathing_system(
    time: Res<Time>,
    query: Query<(&mut Transform, &NpcBaseY, &BreathingPhase)>,
) {
    update_npc_breathing(time, query);
}

/// System to update selection ring animations.
/// Rings pulse ±5% in scale.
pub fn update_selection_rings(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &SelectionRing)>,
) {
    let global_time = time.elapsed_secs();
    let pulse_speed = 3.0; // Full cycle every 2 seconds
    
    for (mut transform, ring) in query.iter_mut() {
        let t = (global_time * pulse_speed + ring.phase_offset).sin();
        // Pulse ±5%: scale from 0.95 to 1.05
        let pulse_scale = 1.0 + t * 0.05;
        transform.scale = Vec3::splat(pulse_scale);
    }
}

/// System to spawn/despawn selection rings based on SelectedNpc component.
/// Simplified approach: spawn a ring for each selected NPC each frame.
/// This is less efficient but simpler to implement.
pub fn update_selection_ring_visibility(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    // Query for NPCs with SelectedNpc component
    selected_npcs: Query<(Entity, &Transform), With<SelectedNpc>>,
    // Query for existing selection rings
    existing_rings: Query<Entity, With<SelectionRing>>,
) {
    // Despawn all existing selection rings
    for entity in existing_rings.iter() {
        commands.entity(entity).despawn();
    }
    
    // Spawn new selection rings for currently selected NPCs
    for (_entity, transform) in selected_npcs.iter() {
        // Use a simple phase offset based on position
        let phase_offset = (transform.translation.x + transform.translation.z) * 10.0;
        spawn_selection_ring(&mut commands, &mut meshes, &mut materials, transform.translation, phase_offset);
    }
}
