//! Demo sequencer system.
//!
//! Manages the high-level phase progression of the demo.

#![allow(dead_code)]

use bevy::prelude::*;
use std::sync::Arc;

use crate::sim::SimTickCounter;

/// High-level phases of the demo from DEMO_VISION.md §3.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DemoPhase {
    /// Dawn - initial state, camera descending to settlement
    Dawn,
    /// Precursor - Senne sees smoke (tick ~600)
    Precursor,
    /// Crisis - fire ignition on ridge (tick ~780)
    Crisis,
    /// Resolution - rain begins (tick ~2100)
    Resolution,
    /// Aftermath - dual-viewport beat (tick ~2700)
    Aftermath,
    /// Complete - logo fade (tick ~3000)
    Complete,
}

impl DemoPhase {
    /// Get the tick at which this phase begins.
    pub fn start_tick(&self) -> u64 {
        match self {
            DemoPhase::Dawn => 0,
            DemoPhase::Precursor => 600,
            DemoPhase::Crisis => 780,
            DemoPhase::Resolution => 2100,
            DemoPhase::Aftermath => 2700,
            DemoPhase::Complete => 3000,
        }
    }
    
    /// Get the next phase.
    pub fn next(&self) -> Option<Self> {
        match self {
            DemoPhase::Dawn => Some(DemoPhase::Precursor),
            DemoPhase::Precursor => Some(DemoPhase::Crisis),
            DemoPhase::Crisis => Some(DemoPhase::Resolution),
            DemoPhase::Resolution => Some(DemoPhase::Aftermath),
            DemoPhase::Aftermath => Some(DemoPhase::Complete),
            DemoPhase::Complete => None,
        }
    }
}

/// Callback type for demo phase transitions.
/// Uses a boxed closure for flexibility.
pub type PhaseCallback = Box<dyn Fn(DemoPhase) + Send + Sync>;

/// Resource managing the demo sequence progression.
#[derive(Resource)]
pub struct DemoSequencer {
    /// Current demo phase.
    pub phase: DemoPhase,
    /// Tick at which the current phase started.
    pub phase_start_tick: u64,
    /// Registered callbacks for phase transitions.
    pub beat_callbacks: Vec<(DemoPhase, Arc<PhaseCallback>)>,
}

impl Default for DemoSequencer {
    fn default() -> Self {
        Self {
            phase: DemoPhase::Dawn,
            phase_start_tick: 0,
            beat_callbacks: Vec::new(),
        }
    }
}

impl DemoSequencer {
    /// Register a callback for a specific phase.
    pub fn register_callback(&mut self, phase: DemoPhase, callback: PhaseCallback) {
        self.beat_callbacks.push((phase, Arc::new(callback)));
    }
}

/// Plugin for the demo sequencer system.
pub struct DemoSequencerPlugin;

impl Plugin for DemoSequencerPlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<DemoSequencer>()
            .add_systems(Update, advance_sequencer);
    }
}

/// Advance the demo sequencer based on simulation ticks.
pub fn advance_sequencer(
    tick_counter: Res<SimTickCounter>,
    mut sequencer: ResMut<DemoSequencer>,
) {
    let current_tick = tick_counter.count;
    
    // Check if we need to transition to a new phase
    if let Some(next) = sequencer.phase.next()
        && current_tick >= next.start_tick()
    {
        // Phase transition
        let old_phase = sequencer.phase;
        sequencer.phase = next;
        sequencer.phase_start_tick = current_tick;
        
        // Log the transition
        tracing::info!(
            "Demo phase transition: {:?} -> {:?} at tick {}",
            old_phase,
            sequencer.phase,
            current_tick
        );
        
        // Call registered callbacks for this phase
        for (callback_phase, callback) in &sequencer.beat_callbacks {
            if *callback_phase == sequencer.phase {
                let cb = callback.clone();
                cb(sequencer.phase);
            }
        }
    }
}
