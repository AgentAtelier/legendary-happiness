//! Demo sequencer systems.
//!
//! This module provides high-level demo sequencing:
//! - Phase progression (Dawn, Precursor, Crisis, Resolution, Aftermath, Complete)
//! - Callback system for phase transitions

pub mod sequencer;

#[allow(unused_imports)]
pub use sequencer::{DemoPhase, DemoSequencer, DemoSequencerPlugin};
