//! Simulation time control systems.
//!
//! This module handles pause/play, speed presets, stepping, and restart functionality.

use bevy::prelude::*;

use crate::app::{RuntimeResource, SimSpeed, WorldResource};
use crate::crash_reporter;
use crate::sim::{SimRng, SimTickCounter};
use crate::ui::panel::SimTime;
use anvil_runtime::Runtime;

/// Resource for checkpoint/snapshot management.
#[derive(Resource, Default)]
pub struct CheckpointState {
    /// The last saved snapshot bytes.
    #[allow(dead_code)]
    pub last_snapshot: Option<Vec<u8>>,
    /// The tick when the last snapshot was taken.
    pub last_snapshot_tick: u64,
}

/// System that handles simulation time control keyboard shortcuts.
pub fn handle_time_controls(
    mut sim_speed: ResMut<SimSpeed>,
    mut sim_time: ResMut<SimTime>,
    mut tick_counter: ResMut<SimTickCounter>,
    mut checkpoint: ResMut<CheckpointState>,
    world: Res<WorldResource>,
    mut runtime: ResMut<RuntimeResource>,
    mut rng: ResMut<SimRng>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Space - Pause/Play
    if keyboard_input.just_pressed(KeyCode::Space) {
        if sim_speed.paused() {
            sim_speed.0 = 1.0;
        } else {
            sim_speed.0 = 0.0;
        }
        println!("Simulation {}", if sim_speed.paused() { "PAUSED" } else { "PLAYING" });
    }

    // Speed presets 1-5
    if keyboard_input.just_pressed(KeyCode::Digit1) {
        sim_speed.0 = 0.5;
    }
    if keyboard_input.just_pressed(KeyCode::Digit2) {
        sim_speed.0 = 1.0;
    }
    if keyboard_input.just_pressed(KeyCode::Digit3) {
        sim_speed.0 = 2.0;
    }
    if keyboard_input.just_pressed(KeyCode::Digit4) {
        sim_speed.0 = 5.0;
    }
    if keyboard_input.just_pressed(KeyCode::Digit5) {
        sim_speed.0 = 10.0;
    }

    // Single step (.) while paused
    if keyboard_input.just_pressed(KeyCode::Period) && sim_time.paused {
        // This will be handled by the tick system checking for single step
        // We just need to signal that a step was requested
    }

    // Restart: R = same seed, Shift+R = new seed
    if keyboard_input.just_pressed(KeyCode::KeyR) {
        let new_seed = if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
            // New random seed
            rng.rng.next_u64()
        } else {
            // Same seed - reset to initial state
            42 // Default seed
        };
        
        // Reinitialize runtime with fresh world
        *runtime = RuntimeResource {
            runtime: Runtime::new(world.world.clone()),
        };
        *rng = SimRng::new(new_seed);
        tick_counter.count = 0;
        sim_time.tick = 0;
        
        println!("Simulation restarted with seed: {}", new_seed);
    }

    // Save snapshot: Ctrl+S
    if keyboard_input.just_pressed(KeyCode::KeyS) && (keyboard_input.pressed(KeyCode::ControlLeft) || keyboard_input.pressed(KeyCode::ControlRight)) {
        // Save current state
        // For now, we just store the tick
        checkpoint.last_snapshot_tick = tick_counter.count;
        println!("Snapshot saved at tick: {}", tick_counter.count);
    }

    // Load snapshot: Ctrl+L
    if keyboard_input.just_pressed(KeyCode::KeyL)
        && (keyboard_input.pressed(KeyCode::ControlLeft) || keyboard_input.pressed(KeyCode::ControlRight))
        && checkpoint.last_snapshot_tick > 0
    {
        // Restore to last snapshot
        tick_counter.count = checkpoint.last_snapshot_tick;
        println!("Snapshot loaded, restored to tick: {}", tick_counter.count);
    }

    // Rollback to last checkpoint: Z
    if keyboard_input.just_pressed(KeyCode::KeyZ) && checkpoint.last_snapshot_tick > 0 {
        tick_counter.count = checkpoint.last_snapshot_tick;
        println!("Rolled back to tick: {}", tick_counter.count);
    }

    // Update SimTime tick from SimTickCounter
    sim_time.tick = tick_counter.count;
}

/// System that updates the SimTime hash from the simulation state.
pub fn update_sim_time_hash(
    mut sim_time: ResMut<SimTime>,
    runtime: Option<Res<RuntimeResource>>,
) {
    let Some(runtime) = runtime else { return };
    // Compute a simple hash from the simulation state
    // For now, use a placeholder - in a full implementation this would
    // hash the entire simulation state
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};

    let mut hasher = DefaultHasher::new();

    // Hash system state using the new accessors
    if let Some(npc_system) = runtime.runtime.npc_system() {
        npc_system.persons.len().hash(&mut hasher);
        npc_system.settlements.len().hash(&mut hasher);
    }
    if let Some(catastrophe_system) = runtime.runtime.catastrophe_system() {
        catastrophe_system.active_events.len().hash(&mut hasher);
    }
    if let Some(joy_system) = runtime.runtime.joy_system() {
        joy_system.persons.len().hash(&mut hasher);
        joy_system.settlements.len().hash(&mut hasher);
    }
    if let Some(physics_system) = runtime.runtime.physics_system() {
        physics_system.rigid_body_set.len().hash(&mut hasher);
    }

    // Also hash runtime state
    runtime.runtime.state_hash().hash(&mut hasher);
    runtime.runtime.time.seconds_since_start.to_bits().hash(&mut hasher);

    let hash_value = hasher.finish();
    sim_time.hash = format!("{:016x}", hash_value);
}

/// System that updates the crash reporter context with current simulation state.
/// This ensures that if a panic occurs, we have the latest tick and state hash.
pub fn update_crash_reporter_context(
    tick_counter: Res<SimTickCounter>,
    sim_time: Res<SimTime>,
) {
    // Parse the hash from hex string to u64
    let state_hash = u64::from_str_radix(sim_time.hash.trim_start_matches("0x"), 16)
        .unwrap_or(0);
    crash_reporter::update_crash_context(tick_counter.count, state_hash);
}

/// System to handle deliberate crash trigger (Ctrl+Shift+K)
pub fn handle_deliberate_crash(
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    if keyboard_input.just_pressed(KeyCode::KeyK)
        && (keyboard_input.pressed(KeyCode::ControlLeft) || keyboard_input.pressed(KeyCode::ControlRight))
        && (keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight))
    {
        crash_reporter::trigger_deliberate_crash();
    }
}
