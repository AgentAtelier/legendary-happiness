// crates/anvil_demo/src/ui/transitions.rs
use bevy::prelude::*;

// ---------------------------------------------------------------------------
// Marker component for the full-screen fade overlay
// ---------------------------------------------------------------------------
#[derive(Component)]
pub struct TransitionOverlay;

// ---------------------------------------------------------------------------
// Resource that drives the fade animation
// ---------------------------------------------------------------------------
#[derive(Resource)]
pub struct FadeState {
    pub alpha:    f32,    // current opacity, 0 = transparent, 1 = black
    pub target:   f32,    // desired opacity
    pub speed:    f32,    // change per second
    pub complete: bool,
}

impl Default for FadeState {
    fn default() -> Self {
        Self {
            alpha:    1.0,   // start fully black
            target:   0.0,   // fade out
            speed:    2.0,   // reach target in ~0.5 s
            complete: false,
        }
    }
}

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------
pub struct TransitionPlugin;

impl Plugin for TransitionPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<FadeState>()
           .init_resource::<TransitionState>()
           .add_systems(Startup, spawn_overlay)
           .add_systems(Update, animate_overlay);
    }
}

// ---------------------------------------------------------------------------
// Spawn a full-screen black rectangle with maximum Z index
// ---------------------------------------------------------------------------
fn spawn_overlay(mut commands: Commands) {
    commands.spawn((
        Node {
            position_type: PositionType::Absolute,
            left:   Val::Px(0.0),
            top:    Val::Px(0.0),
            width:  Val::Percent(100.0),
            height: Val::Percent(100.0),
            ..default()
        },
        BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 1.0)),
        ZIndex(i32::MAX),
        TransitionOverlay,
    ));
}

// ---------------------------------------------------------------------------
// Animate opacity toward the target; hide the entity once transparent
// ---------------------------------------------------------------------------
fn animate_overlay(
    mut fade:    ResMut<FadeState>,
    mut overlay: Query<(Entity, &mut BackgroundColor, &mut Visibility), With<TransitionOverlay>>,
    time:        Res<Time>,
) {
    if fade.complete {
        return;
    }

    let Ok((_entity, mut bg, mut vis)) = overlay.single_mut() else {
        warn_once!("TransitionPlugin: overlay entity not found");
        fade.complete = true;
        return;
    };

    // Move alpha toward target
    let dt = time.delta_secs();
    let sign = (fade.target - fade.alpha).signum();
    fade.alpha = (fade.alpha + sign * fade.speed * dt).clamp(0.0, 1.0);

    bg.0 = Color::srgba(0.0, 0.0, 0.0, fade.alpha);

    // When the fade has reached its target, mark complete and hide
    if (fade.alpha - fade.target).abs() < 0.005 {
        fade.alpha   = fade.target;
        fade.complete = true;
        if fade.target == 0.0 {
            *vis = Visibility::Hidden;
        }
    }
}

// ---------------------------------------------------------------------------
// One-time warning helper
// ---------------------------------------------------------------------------
#[macro_export]
macro_rules! warn_once {
    ($($arg:tt)*) => {{
        static ONCE: std::sync::atomic::AtomicBool =
            std::sync::atomic::AtomicBool::new(false);
        if !ONCE.swap(true, std::sync::atomic::Ordering::Relaxed) {
            tracing::warn!($($arg)*);
        }
    }};
}

// ---------------------------------------------------------------------------
// Legacy types for backwards compatibility with existing code
// ---------------------------------------------------------------------------

/// Resource for menu backdrop state (legacy, kept for compatibility).
#[derive(Resource, Default)]
pub struct MenuBackdrop {
    /// Whether backdrop is visible
    pub visible: bool,
    /// Backdrop opacity (0.0 to 1.0)
    pub opacity: f32,
}

/// Resource to coordinate transitions between states (legacy, kept for compatibility).
#[derive(Resource, Default)]
pub struct TransitionState {
    /// Whether we're in the middle of a transition
    pub in_transition: bool,
    pub from: Option<crate::app::AppState>,
    pub to: Option<crate::app::AppState>,
    pub fade_to_black_complete: bool,
    pub camera_transition_complete: bool,
    pub fade_from_black_complete: bool,
}

impl TransitionState {
    /// Start a transition (legacy method for compatibility).
    pub fn start_transition(&mut self, from: crate::app::AppState, to: crate::app::AppState) {
        self.in_transition = true;
        self.from = Some(from);
        self.to = Some(to);
    }
}

impl FadeState {
    /// Start a fade to black transition (legacy method for compatibility).
    pub fn start_fade_to_black(&mut self) {
        self.alpha = 0.0;
        self.target = 1.0;
        self.complete = false;
    }
}
