use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::app::RuntimeResource;
use crate::ui::panel::UiState;
use crate::ui::resources::{CatastropheWarnings, WeatherTrend};

/// Returns color for temperature value.
pub fn temperature_color(temp: f32) -> egui::Color32 {
    if temp > 30.0 {
        egui::Color32::LIGHT_RED
    } else if temp > 20.0 {
        egui::Color32::LIGHT_YELLOW
    } else if temp > 10.0 {
        egui::Color32::LIGHT_GREEN
    } else {
        egui::Color32::LIGHT_BLUE
    }
}

/// Returns color for humidity value.
pub fn humidity_color(humidity: f32) -> egui::Color32 {
    if humidity > 0.7 {
        egui::Color32::LIGHT_BLUE
    } else if humidity > 0.4 {
        egui::Color32::LIGHT_GREEN
    } else {
        egui::Color32::LIGHT_YELLOW
    }
}

/// Returns trend arrow for temperature.
pub fn temperature_trend_arrow(trend: f32) -> String {
    if trend > 0.1 {
        "\u{2191}".to_string()
    } else if trend < -0.1 {
        "\u{2193}".to_string()
    } else {
        "\u{2192}".to_string()
    }
}

/// Returns trend arrow for humidity.
pub fn humidity_trend_arrow(trend: f32) -> String {
    if trend > 0.01 {
        "\u{2191}".to_string()
    } else if trend < -0.01 {
        "\u{2193}".to_string()
    } else {
        "\u{2192}".to_string()
    }
}

/// Returns trend arrow for wind.
pub fn wind_trend_arrow(trend: f32) -> String {
    if trend > 0.5 {
        "\u{2191}".to_string()
    } else if trend < -0.5 {
        "\u{2193}".to_string()
    } else {
        "\u{2192}".to_string()
    }
}

// ============================================================================
// Panel 5: Weather Panel (Top-right, tabbed with Oracle)
// ============================================================================

/// System that renders the Weather panel.
///
/// Position: Top-right (tabbed with Oracle)
/// Content: Weather state, metrics, warnings
pub fn render_weather_panel(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    trend: Res<WeatherTrend>,
    warnings: Res<CatastropheWarnings>,
    ui_state: Res<UiState>,
) {
    // Only render if Weather panel is enabled
    if !ui_state.show_overlays {
        return;
    }

    let weather = &runtime.runtime.weather;

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        egui::Area::new("weather_panel".into())
            .anchor(egui::Align2::RIGHT_TOP, [-10.0, 100.0])
            .movable(true)
            .default_pos([ctx.content_rect().width() - 350.0, 120.0])
            .show(ctx, |ui| {
                ui.set_min_width(280.0);
                
                // Header
                ui.horizontal(|ui| {
                    ui.heading("\u{1f324} Weather");
                    ui.separator();
                    ui.label(format!("{:?}", weather.current_weather));
                });

                ui.separator();

                // Weather metrics
                ui.group(|ui| {
                    ui.label("Current Conditions:");
                    
                    // Temperature
                    let temp_color = temperature_color(weather.temperature);
                    ui.horizontal(|ui| {
                        ui.colored_label(temp_color, "\u{1f321} Temp: ");
                        ui.label(format!("{:.1}\u{00b0}C", weather.temperature));
                        ui.label(temperature_trend_arrow(trend.temperature_trend));
                    });

                    // Humidity
                    let humidity_color = humidity_color(weather.humidity);
                    ui.horizontal(|ui| {
                        ui.colored_label(humidity_color, "\u{1f4a7} Humidity: ");
                        ui.label(format!("{:.0}%", weather.humidity * 100.0));
                        ui.label(humidity_trend_arrow(trend.humidity_trend));
                    });

                    // Wind
                    ui.horizontal(|ui| {
                        ui.label("\u{1f4a8} Wind: ");
                        ui.label(format!("{:.1} m/s {:.2}rad", weather.wind_speed, weather.wind_direction));
                        ui.label(wind_trend_arrow(trend.wind_speed_trend));
                    });

                    // Pressure
                    ui.horizontal(|ui| {
                        ui.label("\u{1f4ca} Pressure: ");
                        ui.label(format!("{:.1} hPa", weather.pressure));
                    });

                    // Precipitation
                    ui.horizontal(|ui| {
                        ui.label("\u{1f327} Precip: ");
                        ui.label(format!("{:.2} mm", weather.accumulated_precipitation));
                    });
                });

                ui.separator();

                // Weather trend summary
                if trend.is_changing {
                    ui.colored_label(egui::Color32::LIGHT_YELLOW, "\u{1f4c8} Weather is changing");
                } else {
                    ui.label("\u{1f4c9} Weather is stable");
                }

                ui.separator();

                // Catastrophe warnings
                if warnings.has_warnings() {
                    ui.colored_label(egui::Color32::LIGHT_RED, "\u{26a0}\u{fe0f}  Warnings:");
                    
                    for warning in &warnings.active {
                        ui.label(format!("  \u{1f525} {}", warning));
                    }
                    for precursor in &warnings.precursors {
                        ui.label(format!("  \u{1f7e1} {}", precursor));
                    }
                } else {
                    ui.colored_label(egui::Color32::LIGHT_GREEN, "\u{2714} No active warnings");
                }
            });
    }
}
