use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;
use crate::ui::resources::RegionStates;

/// Helper to render a resource bar.
pub fn resource_bar(ui: &mut egui::Ui, label: &str, value: f32, color: egui::Color32) {
    ui.horizontal(|ui| {
        ui.label(format!("{}: ", label));
        ui.add(
            egui::ProgressBar::new(value.clamp(0.0, 1.0))
                .desired_width(100.0)
                .fill(color),
        );
        ui.label(format!("{:.0}%", value * 100.0));
    });
}

// ============================================================================
// Panel 2: Settlement Panel (Bottom-left)
// ============================================================================

/// System that renders the Settlement panel.
///
/// Position: Bottom-left
/// Content: Region list, status, population, resources
pub fn render_settlement_panel(
    mut egui_contexts: EguiContexts,
    regions: Res<RegionStates>,
    ui_state: Res<UiState>,
) {
    // Only render if Settlement panel is enabled
    if !ui_state.show_catastrophe_panel {
        return;
    }

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        egui::Area::new("settlement_panel".into())
            .anchor(egui::Align2::LEFT_BOTTOM, [10.0, -10.0])
            .movable(true)
            .default_pos([20.0, ctx.content_rect().height() - 400.0])
            .show(ctx, |ui| {
                ui.set_min_width(250.0);
                
                // Header
                ui.horizontal(|ui| {
                    ui.heading("\u{1f3d8} Settlement");
                    ui.label(format!("Total: {} people", regions.total_population));
                });

                ui.separator();

                // Region list
                for region in &regions.regions {
                    // Determine status color
                    let status_color = if region.is_loaded {
                        egui::Color32::LIGHT_GREEN
                    } else {
                        egui::Color32::LIGHT_RED
                    };
                    
                    let status_text = if region.is_loaded {
                        "Loaded"
                    } else {
                        "Not Loaded"
                    };

                    // Region card
                    ui.group(|ui| {
                        ui.horizontal(|ui| {
                            ui.colored_label(status_color, status_text);
                            ui.label(&region.name);
                            ui.label(format!("({})", region.population));
                        });

                        // Resource bars
                        resource_bar(ui, "Food", region.food, egui::Color32::LIGHT_GREEN);
                        resource_bar(ui, "Water", region.water, egui::Color32::LIGHT_BLUE);
                        resource_bar(ui, "Materials", region.materials, egui::Color32::from_rgb(245, 245, 220));
                        resource_bar(ui, "Integrity", region.structural_integrity, egui::Color32::LIGHT_GRAY);
                    });

                    ui.separator();
                }

                // Total resources across settlement
                if let Some(settlement) = regions.settlement() {
                    ui.collapsing("\u{1f4c8} Settlement Resources", |ui| {
                        resource_bar(ui, "Food", settlement.food, egui::Color32::LIGHT_GREEN);
                        resource_bar(ui, "Water", settlement.water, egui::Color32::LIGHT_BLUE);
                        resource_bar(ui, "Materials", settlement.materials, egui::Color32::from_rgb(245, 245, 220));
                        resource_bar(ui, "Integrity", settlement.structural_integrity, egui::Color32::LIGHT_GRAY);
                    });
                }
            });
    }
}
