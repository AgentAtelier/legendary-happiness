use bevy::prelude::*;
use bevy_egui::EguiPrimaryContextPass;

use crate::plugins::SimBridgeSet;
use super::{render_inspector_panel, render_oracle_panel, render_settlement_panel, render_sim_status_panel, render_weather_panel};

// ============================================================================
// Panel Plugin
// ============================================================================

/// Plugin for all 5 UI panels.
///
/// This plugin registers all panel rendering systems.
pub struct PanelsPlugin;

impl Plugin for PanelsPlugin {
    fn build(&self, app: &mut App) {
        app
            .add_systems(
                EguiPrimaryContextPass,
                (
                    render_sim_status_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_settlement_panel,
                    render_inspector_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_oracle_panel,
                    render_weather_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                ).after(SimBridgeSet),
            );
    }
}

#[cfg(test)]
mod tests {
    use crate::ui::resources::DemoCompletion;
    use crate::app::SimSpeed;

    /// Test demo completion percentage formatting.
    #[test]
    fn test_demo_completion_display() {
        let completion = DemoCompletion(0.5);
        assert_eq!(completion.as_percent(), "50.0%");
        
        let completion = DemoCompletion(0.25);
        assert_eq!(completion.as_percent(), "25.0%");
    }

    /// Test SimSpeed display.
    #[test]
    fn test_sim_speed_display() {
        let speed = SimSpeed(1.0);
        assert_eq!(speed.display(), "1x");
        
        let speed = SimSpeed(10.0);
        assert_eq!(speed.display(), "10x");
        
        let speed = SimSpeed(0.0);
        assert_eq!(speed.display(), "PAUSED");
    }
}
