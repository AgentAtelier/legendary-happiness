use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::app::SimSpeed;
use crate::ui::resources::{CurrentDemoPhase, CurrentTick, DemoCompletion};
use crate::ui::panel::UiState;



// ============================================================================
// Panel 1: SimStatus Panel (Top-left)
// ============================================================================

/// System that renders the SimStatus panel.
///
/// Position: Top-left
/// Content: Phase name, tick count, progress bar, speed controls
pub fn render_sim_status_panel(
    mut egui_contexts: EguiContexts,
    phase: Res<CurrentDemoPhase>,
    tick: Res<CurrentTick>,
    completion: Res<DemoCompletion>,
    speed: Res<SimSpeed>,
    ui_state: Res<UiState>,
    mut commands: Commands,
) {
    // Only render if the toggle bar is visible
    if !ui_state.show_toggle_bar {
        return;
    }

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        egui::TopBottomPanel::top("sim_status_panel")
            .default_height(80.0)
            .show(ctx, |ui| {
                // Title bar
                ui.horizontal(|ui| {
                    ui.label("\u{1f4ca} Sim Status");
                    ui.separator();
                });

                // Phase and tick
                ui.horizontal(|ui| {
                    ui.label(format!("Phase: {}", phase.description()));
                    ui.separator();
                    ui.label(format!("Tick: {}", tick.0));
                    ui.separator();
                    ui.label(format!("Completion: {}", completion.as_percent()));
                });

                // Progress bar
                ui.add(
                    egui::ProgressBar::new(completion.0)
                        .desired_width(f32::INFINITY)
                        .text(format!("{}", completion.as_percent())),
                );

                // Speed controls
                ui.horizontal(|ui| {
                    ui.label("Speed:");
                    
                    // Speed buttons - write to SimSpeed
                    let speed_options = [0.1, 0.5, 1.0, 2.0, 5.0, 10.0];
                    for &opt in &speed_options {
                        let is_active = (speed.0 - opt).abs() < f32::EPSILON;
                        let color = if is_active {
                            egui::Color32::LIGHT_GREEN
                        } else {
                            egui::Color32::WHITE
                        };
                        
                        if ui
                            .button(egui::RichText::new(format!("{}x", opt)).color(color))
                            .clicked()
                        {
                            commands.insert_resource(SimSpeed(opt));
                        }
                    }
                    
                    ui.separator();
                    
                    // Pause/Play toggle
                    let pause_text = if speed.paused() { "\u{25b6} Play" } else { "\u{23f8} Pause" };
                    let pause_color = if speed.paused() {
                        egui::Color32::GREEN
                    } else {
                        egui::Color32::ORANGE
                    };
                    
                    if ui
                        .button(egui::RichText::new(pause_text).color(pause_color))
                        .clicked()
                    {
                        if speed.paused() {
                            commands.insert_resource(SimSpeed(1.0));
                        } else {
                            commands.insert_resource(SimSpeed(0.0));
                        }
                    }
                    
                    // Current speed display
                    ui.colored_label(speed.color(), speed.display());
                });
            });
    }
}
