//! UI Panels for Ashveil Demo
//!
//! Implements the 5 egui panels that read from Bevy resources synced via SimBridgePlugin.
//! These panels display simulation state but do NOT mutate it.
//!
//! Architecture:
//!   anvil_demo_core (SequencerState, etc.)
//!       \u{2193} sync via SimBridgePlugin
//!   Bevy Resources (CurrentDemoPhase, RegionStates, etc.)
//!       \u{2193} read by
//!   UI Systems (in this module)
//!
//! Panels:
//! 1. SimStatus - Top-left: Phase, tick, progress, speed controls
//! 2. Settlement - Bottom-left: Regions, population, resources
//! 3. Inspector - Bottom-left (tabbed): NPC stats, needs, emotions, skills
//! 4. Oracle - Top-right: Next 3 actions, utility scores, explanations
//! 5. Weather - Top-right (tabbed): Weather state, metrics, warnings

pub mod inspector;
pub mod oracle;
pub mod settlement;
pub mod sim_status;
pub mod weather;

pub use inspector::render_inspector_panel;
pub use oracle::render_oracle_panel;
pub use settlement::render_settlement_panel;
pub use sim_status::render_sim_status_panel;
pub use weather::render_weather_panel;
pub use plugin::PanelsPlugin;

mod plugin;
