use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;
use crate::ui::resources::{NpcPredictions, SelectedNpc};

// ============================================================================
// Panel 4: Oracle Panel (Top-right)
// ============================================================================

/// System that renders the Oracle panel.
///
/// Position: Top-right
/// Content: Next 3 actions, utility scores, explanations
pub fn render_oracle_panel(
    mut egui_contexts: EguiContexts,
    predictions: Res<NpcPredictions>,
    _selected_npc: Res<SelectedNpc>,
    ui_state: Res<UiState>,
) {
    // Only render if Oracle overlay is enabled
    if !ui_state.show_oracle_overlay {
        return;
    }

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        egui::Area::new("oracle_panel".into())
            .anchor(egui::Align2::RIGHT_TOP, [-10.0, 10.0])
            .movable(true)
            .default_pos([ctx.content_rect().width() - 350.0, 10.0])
            .show(ctx, |ui| {
                ui.set_min_width(300.0);
                
                // Header
                ui.horizontal(|ui| {
                    ui.heading("\u{1f52e} Oracle");
                    ui.separator();
                    
                    if predictions.npc_id.is_some() {
                        ui.label(&predictions.npc_name);
                    } else {
                        ui.label("No NPC selected");
                    }
                });

                ui.separator();

                if predictions.predictions.is_empty() {
                    ui.label("Select an NPC to see predictions");
                } else {
                    ui.label("Top 3 Predicted Actions:");
                    ui.separator();

                    // Sort predictions by score (descending)
                    let mut sorted = predictions.predictions.clone();
                    sorted.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));

                    for (i, pred) in sorted.iter().enumerate() {
                        let color = if pred.is_best {
                            egui::Color32::GOLD
                        } else {
                            egui::Color32::WHITE
                        };

                        ui.group(|ui| {
                            ui.horizontal(|ui| {
                                if pred.is_best {
                                    ui.label("\u{2b50} ");
                                }
                                ui.colored_label(color, format!("{}. {}", i + 1, pred.action));
                            });
                            
                            ui.horizontal(|ui| {
                                ui.label(format!("Score: {:.2}", pred.score));
                                ui.label(format!("| Factor: {:.0}%", pred.score * 100.0));
                            });
                            
                            ui.label(pred.explanation.clone());
                        });

                        ui.separator();
                    }

                    // Summary
                    ui.label("The Oracle predicts actions based on:");
                    ui.label("  \u{2022} 7-factor utility scoring");
                    ui.label("  \u{2022} NPC substrate (personality)");
                    ui.label("  \u{2022} Current needs and emotions");
                    ui.label("  \u{2022} Available skill affordances");
                }
            });
    }
}
