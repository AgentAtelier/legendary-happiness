use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;
use crate::ui::resources::{NpcDetails, SelectedNpc};

/// Returns color for need satisfaction level.
pub fn need_color(value: f32) -> egui::Color32 {
    if value >= 0.7 {
        egui::Color32::LIGHT_GREEN
    } else if value >= 0.4 {
        egui::Color32::LIGHT_YELLOW
    } else {
        egui::Color32::LIGHT_RED
    }
}

/// Returns color for emotion value.
pub fn emotion_color(value: f32) -> egui::Color32 {
    if value > 0.0 {
        egui::Color32::LIGHT_GREEN
    } else if value < 0.0 {
        egui::Color32::LIGHT_RED
    } else {
        egui::Color32::WHITE
    }
}

/// Returns color for skill fluency level.
pub fn skill_color(fluency: &str) -> egui::Color32 {
    match fluency {
        "Expert" => egui::Color32::GOLD,
        "Smooth" => egui::Color32::LIGHT_YELLOW,
        "Competent" => egui::Color32::LIGHT_BLUE,
        "Awkward" => egui::Color32::LIGHT_RED,
        "Halting" => egui::Color32::RED,
        _ => egui::Color32::WHITE,
    }
}

// ============================================================================
// Panel 3: Inspector Panel (Bottom-left, tabbed)
// ============================================================================

/// System that renders the Inspector panel.
///
/// Position: Bottom-left (tabbed)
/// Content: NPC stats, needs, emotions, skills
/// Selection: Dropdown for now (click-to-select later)
pub fn render_inspector_panel(
    mut egui_contexts: EguiContexts,
    selected_npc: Res<SelectedNpc>,
    npc_details: Res<NpcDetails>,
    ui_state: Res<UiState>,
) {
    // Only render if Inspector panel is enabled
    if !ui_state.show_inspector {
        return;
    }

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        egui::Area::new("inspector_panel".into())
            .anchor(egui::Align2::LEFT_BOTTOM, [10.0, -10.0])
            .movable(true)
            .default_pos([300.0, ctx.content_rect().height() - 500.0])
            .show(ctx, |ui| {
                ui.set_min_width(300.0);
                
                // Header
                ui.horizontal(|ui| {
                    ui.heading("\u{1f464} Inspector");
                    ui.separator();
                    
                    // NPC selection dropdown
                    let npc_names = vec![
                        "None",
                        "Elder Maren Ironbark",
                        "Dak Voss",
                        "Senne Ironbark",
                        "Tibor Ironbark",
                        "Lora Vance",
                        "Cael Ironbark",
                        "Yarra Keld",
                        "Pell Vance",
                    ];
                    
                    let mut selected_index = if selected_npc.has_selection() {
                        // Map NPC ID to index (1-8 -> 1-8 in list)
                        let id = selected_npc.get() as usize;
                        if id >= 1 && id <= 8 {
                            id
                        } else {
                            0
                        }
                    } else {
                        0
                    };
                    
                    egui::ComboBox::from_id_salt("npc_selector")
                        .width(200.0)
                        .selected_text(format!("{}", npc_names[selected_index]))
                        .show_ui(ui, |ui| {
                            for (i, name) in npc_names.iter().enumerate() {
                                if ui.selectable_value(&mut selected_index, i, format!("{}", name)).clicked() {
                                    // Selection would be updated by a separate system
                                }
                            }
                        });
                });

                ui.separator();

                if selected_npc.has_selection() && npc_details.id > 0 {
                    // NPC Profile
                    ui.collapsing("\u{1f4cb} Profile", |ui| {
                        ui.label(format!("Name: {}", npc_details.name));
                        ui.label(format!("Family: {}", npc_details.family));
                        ui.label(format!("Age: {}", npc_details.age));
                        ui.label(format!("Position: ({:.1}, {:.1}, {:.1})", 
                            npc_details.position.0, 
                            npc_details.position.1, 
                            npc_details.position.2));
                        ui.label(format!("Belonging: {:.2}", npc_details.belonging));
                    });

                    ui.separator();

                    // Needs
                    ui.collapsing("\u{1f496} Needs", |ui| {
                        for (need_name, value) in &npc_details.needs {
                            let color = need_color(*value);
                            ui.horizontal(|ui| {
                                ui.colored_label(color, format!("{}: ", need_name));
                                ui.add(egui::ProgressBar::new(value.clamp(0.0, 1.0)).desired_width(100.0).fill(egui::Color32::LIGHT_BLUE));
                                ui.label(format!("{:.0}%", value * 100.0));
                            });
                        }
                    });

                    ui.separator();

                    // Emotions (Substrate)
                    ui.collapsing("\u{1f9e0} Emotional Substrate", |ui| {
                        for (emotion, value) in &npc_details.emotions {
                            let color = emotion_color(*value);
                            ui.horizontal(|ui| {
                                ui.colored_label(color, format!("{}: ", emotion));
                                ui.label(format!("{:+.2}", value));
                            });
                        }
                    });

                    ui.separator();

                    // Skills
                    ui.collapsing("\u{1f3af} Skills", |ui| {
                        for (skill, fluency) in &npc_details.skills {
                            let color = skill_color(fluency);
                            ui.horizontal(|ui| {
                                ui.colored_label(color, format!("{}: ", skill));
                                ui.label(fluency);
                            });
                        }
                    });

                    ui.separator();

                    // Current Action
                    ui.collapsing("\u{26a1} Current Action", |ui| {
                        ui.label(format!("Action: {}", npc_details.current_action));
                        ui.label("Dominant Need:");
                        ui.colored_label(
                            need_color(npc_details.needs.get(&npc_details.dominant_need).copied().unwrap_or(0.0)),
                            &npc_details.dominant_need,
                        );
                        
                        ui.separator();
                        ui.label("Action Score Breakdown:");
                        for (factor, score) in &npc_details.action_scores {
                            ui.horizontal(|ui| {
                                ui.label(format!("  {}: ", factor));
                                ui.label(format!("{:.2}", score));
                            });
                        }
                    });
                } else {
                    ui.label("Select an NPC to inspect");
                    ui.label("Press 'I' to toggle this panel");
                }
            });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Test need color function.
    #[test]
    fn test_need_color() {
        assert_eq!(need_color(0.8), egui::Color32::LIGHT_GREEN);
        assert_eq!(need_color(0.5), egui::Color32::LIGHT_YELLOW);
        assert_eq!(need_color(0.2), egui::Color32::LIGHT_RED);
    }

    /// Test emotion color function.
    #[test]
    fn test_emotion_color() {
        assert_eq!(emotion_color(0.5), egui::Color32::LIGHT_GREEN);
        assert_eq!(emotion_color(-0.5), egui::Color32::LIGHT_RED);
        assert_eq!(emotion_color(0.0), egui::Color32::WHITE);
    }

    /// Test skill color function.
    #[test]
    fn test_skill_color() {
        assert_eq!(skill_color("Expert"), egui::Color32::GOLD);
        assert_eq!(skill_color("Smooth"), egui::Color32::LIGHT_YELLOW);
        assert_eq!(skill_color("Competent"), egui::Color32::LIGHT_BLUE);
        assert_eq!(skill_color("Awkward"), egui::Color32::LIGHT_RED);
        assert_eq!(skill_color("Halting"), egui::Color32::RED);
    }
}
