//! Window title management for the Application Shell Sprint.
//!
//! This module provides a system to update the window title dynamically
//! with the application name and active scenario: "Forgeborn — Greyridge"
//! or "Forgeborn — {scenario_name}".

use bevy::prelude::*;
use bevy::window::PrimaryWindow;

use crate::app::ScenarioSelection;
use crate::ui::panel::SimTime;

/// Base window title prefix.
const BASE_TITLE: &str = "Forgeborn — ";

/// System to update the primary window title with application name and scenario.
/// Format: "Forgeborn — Greyridge" or "Forgeborn — {scenario_name}"
/// When in debug/Backtick mode, appends sim info.
pub fn update_window_title(
    mut primary_window: Query<&mut Window, With<PrimaryWindow>>,
    scenario: Res<ScenarioSelection>,
    sim_time: Res<SimTime>,
    ui_state: Res<crate::ui::panel::UiState>,
) {
    if let Ok(mut window) = primary_window.single_mut() {
        // Base title with scenario name
        let scenario_name = &scenario.display_name;
        let mut title = format!("{}\\n{}", BASE_TITLE, scenario_name);
        
        // Append debug info when toggle bar is visible (Backtick mode)
        if ui_state.show_toggle_bar {
            let hash8 = truncate_hash(&sim_time.hash, 8);
            let speed_str = format_speed(sim_time.speed);
            title = format!("{}| tick: {} | hash: {} | {}x", title, sim_time.tick, hash8, speed_str);
        }
        
        window.title = title;
    }
}

/// Truncates a hash string to the specified length.
fn truncate_hash(hash: &str, max_len: usize) -> String {
    if hash.len() <= max_len {
        hash.to_string()
    } else {
        format!("{}..", &hash[..max_len.saturating_sub(2)])
    }
}

/// Formats the speed as a clean string.
fn format_speed(speed: f32) -> String {
    match speed {
        0.5 => "0.5".to_string(),
        1.0 => "1".to_string(),
        2.0 => "2".to_string(),
        5.0 => "5".to_string(),
        10.0 => "10".to_string(),
        _ => format!("{:.1}", speed),
    }
}
