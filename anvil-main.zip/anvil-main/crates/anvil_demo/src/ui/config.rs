//! Config persistence module for the Visual Uplift Sprint.
//!
//! Serializes panel states, camera position, and sim speed to `dev_config.json`.
//! Reloads on startup.

use bevy::camera::Camera3d;
use bevy::prelude::*;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

use crate::states::options::{AudioOptions, DisplayOptions};

/// Returns the path to the config file in the user's config directory.
fn config_path() -> Option<PathBuf> {
    dirs::config_dir().map(|d| d.join("anvil").join("dev_config.json"))
}

/// Configuration data to persist to dev_config.json.
#[derive(Serialize, Deserialize, Debug, Clone, Default)]
pub struct DevConfig {
    /// Whether NPC Visuals panel is enabled.
    pub show_npc_visuals: bool,
    /// Whether Overlays panel is enabled.
    pub show_overlays: bool,
    /// Whether Inspector panel is enabled.
    pub show_inspector: bool,
    /// Whether Event Log panel is enabled.
    pub show_event_log: bool,
    /// Whether Performance panel is enabled.
    pub show_performance: bool,
    /// Whether Catastrophe Panel is enabled.
    pub show_catastrophe_panel: bool,
    /// Whether Time Travel panel is enabled.
    pub show_time_travel: bool,
    /// Whether Oracle Overlay is enabled.
    pub show_oracle_overlay: bool,
    /// Whether the toggle bar is visible.
    pub show_toggle_bar: bool,
    /// Camera position.
    pub camera_position: [f32; 3],
    /// Camera rotation.
    pub camera_rotation: [f32; 4],
    /// Simulation speed multiplier.
    pub sim_speed: f32,
    /// Whether simulation is paused.
    pub sim_paused: bool,
    /// Display options (UI scale).
    pub display_options: DisplayOptions,
    /// Audio options (volume, mute).
    pub audio_options: AudioOptions,
}

impl DevConfig {
    /// Load config from dev_config.json file in the user's config directory.
    pub fn load() -> Self {
        if let Some(path) = config_path() && let Ok(contents) = std::fs::read_to_string(&path) {
            return serde_json::from_str(&contents).unwrap_or_default();
        }
        DevConfig::default()
    }

    /// Save config to dev_config.json file in the user's config directory.
    pub fn save(&self) {
        if let Ok(json) = serde_json::to_string_pretty(self) && let Some(path) = config_path() {
            // Create parent directories if they don't exist
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            let _ = std::fs::write(&path, json);
        }
    }
}

/// Resource for managing config state.
#[derive(Resource, Default)]
pub struct ConfigState {
    /// The current configuration.
    pub config: DevConfig,
    /// Whether config has been modified since last save.
    #[allow(dead_code)]
    pub dirty: bool,
}

/// System to load config on startup.
pub fn load_config(mut commands: Commands) {
    let config = DevConfig::load();
    commands.insert_resource(ConfigState {
        config,
        dirty: false,
    });
}

/// System to save config on exit.
/// Note: This needs to be run in the Last schedule to ensure all state is saved.
pub fn save_config_on_exit(
    config_state: Res<ConfigState>,
    ui_state: Res<crate::ui::panel::UiState>,
    sim_time: Res<crate::ui::panel::SimTime>,
    display_options: Res<DisplayOptions>,
    audio_options: Res<AudioOptions>,
    camera_query: Query<&Transform, (With<Camera3d>, Without<crate::npc_visuals::NpcVisual>)>,
) {
    let mut config = config_state.config.clone();

    // Update panel states
    config.show_npc_visuals = ui_state.show_npc_visuals;
    config.show_overlays = ui_state.show_overlays;
    config.show_inspector = ui_state.show_inspector;
    config.show_event_log = ui_state.show_event_log;
    config.show_performance = ui_state.show_performance;
    config.show_catastrophe_panel = ui_state.show_catastrophe_panel;
    config.show_time_travel = ui_state.show_time_travel;
    config.show_oracle_overlay = ui_state.show_oracle_overlay;
    config.show_toggle_bar = ui_state.show_toggle_bar;

    // Update sim state
    config.sim_speed = sim_time.speed;
    config.sim_paused = sim_time.paused;

    // Update display options
    config.display_options = display_options.clone();

    // Update audio options
    config.audio_options = audio_options.clone();

    // Update camera state
    if let Ok(camera_transform) = camera_query.single() {
        config.camera_position = [
            camera_transform.translation.x,
            camera_transform.translation.y,
            camera_transform.translation.z,
        ];
        config.camera_rotation = [
            camera_transform.rotation.x,
            camera_transform.rotation.y,
            camera_transform.rotation.z,
            camera_transform.rotation.w,
        ];
    }

    config.save();
}

/// System to apply loaded config to UI state.
pub fn apply_loaded_config(
    mut ui_state: ResMut<crate::ui::panel::UiState>,
    mut sim_time: ResMut<crate::ui::panel::SimTime>,
    mut camera_query: Query<&mut Transform, (With<Camera3d>, Without<crate::npc_visuals::NpcVisual>)>,
    mut display_options: ResMut<DisplayOptions>,
    mut audio_options: ResMut<AudioOptions>,
    config_state: Res<ConfigState>,
) {
    let config = &config_state.config;

    // Apply panel states
    ui_state.show_npc_visuals = config.show_npc_visuals;
    ui_state.show_overlays = config.show_overlays;
    ui_state.show_inspector = config.show_inspector;
    ui_state.show_event_log = config.show_event_log;
    ui_state.show_performance = config.show_performance;
    ui_state.show_catastrophe_panel = config.show_catastrophe_panel;
    ui_state.show_time_travel = config.show_time_travel;
    ui_state.show_oracle_overlay = config.show_oracle_overlay;
    ui_state.show_toggle_bar = config.show_toggle_bar;

    // Apply sim state
    sim_time.speed = config.sim_speed;
    sim_time.paused = config.sim_paused;

    // Apply display options
    *display_options = config.display_options.clone();

    // Apply audio options
    *audio_options = config.audio_options.clone();

    // Apply camera state
    if let Ok(mut camera_transform) = camera_query.single_mut() {
        camera_transform.translation = Vec3::new(
            config.camera_position[0],
            config.camera_position[1],
            config.camera_position[2],
        );
        camera_transform.rotation = Quat::from_xyzw(
            config.camera_rotation[0],
            config.camera_rotation[1],
            config.camera_rotation[2],
            config.camera_rotation[3],
        );
    }
}
