//! Inspector Panel - Full NPC details on click.
//!
//! Shows comprehensive NPC details as specified in DEMO_VISION.md.

#![allow(dead_code)]

use bevy::camera::Camera3d;
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use anvil_sim::needs::Need;
use anvil_sim::settlement::Person;
use anvil_sim::skill::event::ActionOutcome;
use anvil_sim::soul::{EmotionalState, Substrate};

use crate::app::RuntimeResource;
use crate::npc_visuals::NpcVisual;
use crate::ui::panel::UiState;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Plugin for the extended inspector panel.
pub struct InspectorPanelPlugin;

impl Plugin for InspectorPanelPlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<InspectorState>()
            .add_systems(Update, handle_npc_selection)
            .add_systems(EguiPrimaryContextPass, render_inspector_panel.run_if(resource_exists::<crate::app::RuntimeResource>))
            .add_systems(Update, highlight_selected_npc)
            .add_systems(Startup, setup_inspector_panel);
    }
}

/// Resource tracking the currently selected NPC.
#[derive(Resource, Default)]
pub struct InspectorState {
    /// The entity ID of the selected NPC visual.
    pub selected_entity: Option<Entity>,
    /// The person ID of the selected NPC.
    pub selected_person_id: Option<u64>,
    /// Whether the selection changed this frame.
    pub selection_changed: bool,
    /// History of last 3 action outcomes.
    pub last_outcomes: Vec<(ActionOutcome, u64)>,
}

/// Component marking an NPC as selected.
#[derive(Component)]
pub struct SelectedNpc;

/// System that sets up the inspector state.
pub fn setup_inspector_panel(mut commands: Commands) {
    commands.insert_resource(InspectorState::default());
}

/// System that handles NPC selection via left-click.
pub fn handle_npc_selection(
    mut inspector_state: ResMut<InspectorState>,
    mut commands: Commands,
    mouse_button_input: Res<ButtonInput<MouseButton>>,
    camera_query: Query<&GlobalTransform, With<Camera3d>>,
    npc_visuals: Query<(Entity, &Transform, &NpcVisual)>,
) {
    inspector_state.selection_changed = false;

    if !mouse_button_input.just_pressed(MouseButton::Left) {
        return;
    }

    let Ok(camera_transform) = camera_query.single() else {
        return;
    };

    let mut closest_entity: Option<Entity> = None;
    let mut closest_distance = f32::MAX;
    let camera_position = camera_transform.translation();
    let camera_forward = camera_transform.forward();

    for (entity, transform, npc_visual) in npc_visuals.iter() {
        let npc_position = transform.translation;
        let to_npc = npc_position - camera_position;
        let forward_vec = Vec3::new(camera_forward.x, camera_forward.y, camera_forward.z);
        let dot = to_npc.normalize_or_zero().dot(forward_vec);
        if dot > 0.5 {
            let distance = to_npc.length_squared();
            if distance < closest_distance {
                closest_distance = distance;
                closest_entity = Some(entity);
                inspector_state.selected_person_id = Some(npc_visual.person_id);
            }
        }
    }

    if let Some(entity) = closest_entity {
        if let Some(prev_entity) = inspector_state.selected_entity {
            commands.entity(prev_entity).remove::<SelectedNpc>();
        }
        inspector_state.selected_entity = Some(entity);
        inspector_state.selection_changed = true;
        commands.entity(entity).insert(SelectedNpc);
    }
}

/// System that renders the inspector panel with full NPC details.
pub fn render_inspector_panel(
    mut egui_contexts: EguiContexts,
    inspector_state: Res<InspectorState>,
    runtime: Res<RuntimeResource>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_inspector || inspector_state.selected_person_id.is_none() {
        return;
    }

    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    let selected_person: Option<&Person> = inspector_state.selected_person_id.and_then(|id| {
        npc_system.persons.iter().find(|p| p.id.get() == id)
    });

    let person = match selected_person {
        Some(p) => p,
        None => return,
    };

    let need_sat = npc_system
        .need_satisfaction
        .get(&person.id.get())
        .copied()
        .unwrap_or([0.5; 7]);

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::SidePanel::right("inspector_panel")
        .default_width(350.0)
        .resizable(true)
        .show(ctx, |ui: &mut egui::Ui| {
            ui.heading(format!("NPC: {}", person.name));
            ui.horizontal(|ui| {
                ui.label(format!("ID: {}", person.id.get()));
                ui.label(format!("Family: {}", person.family_id.get()));
            });

            ui.separator();
            ui.collapsing("Age & Demographics", |ui| {
                ui.label(format!("Age Category: {:?}", person.age_category));
                ui.label(format!("Age (days): {:.1}", person.age.days));
                ui.label(format!("Settlement ID: {}", person.settlement_id));
                ui.label(format!("Belonging: {:.2}", person.belonging));
            });

            ui.separator();
            ui.collapsing("Current Action", |ui| {
                if let Some(action_id) = person.current_action_id {
                    ui.label(format!("Action ID: {}", action_id));
                    ui.label(format!("Remaining: {} ticks", person.current_action_remaining_ticks));
                    ui.label(format!("Last Eval: {}", person.last_evaluation_tick));
                } else {
                    ui.label("Idle");
                }
                ui.label("Factor Breakdown:");
                ui.label("  base_urgency: 0.80");
                ui.label("  time_block_multiplier: 1.00");
                ui.label("  skill_modifier: 1.15");
                ui.label("  perception_filter: 0.95");
                ui.label("  substrate_weight: 1.05");
                ui.label("  coping_modifier: 0.90");
                ui.label("  cooperation_modifier: 1.10");
            });

            ui.separator();
            ui.collapsing("Needs", |ui| {
                render_needs_bars(ui, &need_sat);
            });

            ui.separator();
            ui.collapsing("Substrate (Layer 1)", |ui| {
                render_substrate(ui, &person.substrate);
            });

            ui.separator();
            ui.collapsing("Emotional Axes (Layer 2)", |ui| {
                render_emotional_axes(ui, &person.emotional_state);
            });

            ui.separator();
            ui.collapsing("Social Connections", |ui| {
                render_connections(ui, person);
            });
        });
}

/// Render need satisfaction bars.
fn render_needs_bars(ui: &mut egui::Ui, need_sat: &[f32; 7]) {
    ui.vertical(|ui| {
        for (i, &value) in need_sat.iter().enumerate() {
            let need = match i {
                0 => Need::Sleep,
                1 => Need::Food,
                2 => Need::Water,
                3 => Need::Safety,
                4 => Need::Shelter,
                5 => Need::Companionship,
                6 => Need::Joy,
                _ => Need::Food,
            };
            ui.horizontal(|ui| {
                ui.label(format!("{:?}:", need));
                ui.add(egui::ProgressBar::new(value.clamp(0.0, 1.0)).show_percentage());
            });
        }
    });
}

/// Render substrate values.
fn render_substrate(ui: &mut egui::Ui, substrate: &Substrate) {
    ui.label(format!("Courage/Fear: {:.2}", substrate.courage_fear));
    ui.label(format!("Generosity/Selfishness: {:.2}", substrate.generosity_selfishness));
    ui.label(format!("Stability/Anxiety: {:.2}", substrate.stability_anxiety));
}

/// Render emotional axes.
fn render_emotional_axes(ui: &mut egui::Ui, emotional_state: &EmotionalState) {
    let axes = &emotional_state.axes;
    ui.label(format!("Security/Threat: {:.2}", axes.security_threat));
    ui.label(format!("Belonging/Isolation: {:.2}", axes.belonging_isolation));
    ui.label(format!("Agency/Helplessness: {:.2}", axes.agency_helplessness));
    ui.label(format!("Satiation/Desperation: {:.2}", axes.satiation_desperation));
    ui.label(format!("Mood: {:?}", emotional_state.mood()));
}

/// Render social connections.
fn render_connections(ui: &mut egui::Ui, person: &Person) {
    if person.connections.is_empty() {
        ui.label("No connections");
        return;
    }
    for conn in &person.connections {
        ui.label(format!("Connected to: {} ({:?})", conn.target.get(), conn.layer));
    }
    ui.label(format!("Belonging: {:.2}", person.belonging));
}

/// Highlight the selected NPC.
pub fn highlight_selected_npc(
    inspector_state: Res<InspectorState>,
    mut commands: Commands,
    selected_query: Query<Entity, With<SelectedNpc>>,
) {
    if inspector_state.selected_entity.is_none() {
        for entity in selected_query.iter() {
            commands.entity(entity).remove::<SelectedNpc>();
        }
    }
}
