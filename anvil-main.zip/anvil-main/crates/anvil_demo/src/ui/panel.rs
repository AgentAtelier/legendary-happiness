//! Toggle panel and UI panel management.
//!
//! This module provides the persistent toggle bar and panel management system.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

/// Resource containing the UI state for all panels.
#[derive(Resource)]
pub struct UiState {
    /// Whether the toggle bar is visible.
    pub show_toggle_bar: bool,
    /// Whether NPC Visuals panel is enabled.
    pub show_npc_visuals: bool,
    /// Whether Overlays panel is enabled.
    pub show_overlays: bool,
    /// Whether Inspector panel is enabled.
    pub show_inspector: bool,
    /// Whether Event Log panel is enabled.
    pub show_event_log: bool,
    /// Whether Performance panel is enabled.
    pub show_performance: bool,
    /// Whether Catastrophe Panel is enabled.
    pub show_catastrophe_panel: bool,
    /// Whether Time Travel panel is enabled.
    pub show_time_travel: bool,
    /// Whether Oracle Overlay is enabled.
    pub show_oracle_overlay: bool,
    /// Whether the plain-language view is enabled in the inspector (Task 5).
    #[allow(dead_code)]
    pub inspector_plain_language: bool,
    /// Whether the World Integrity panel is enabled.
    pub show_integrity_panel: bool,
}

impl Default for UiState {
    fn default() -> Self {
        Self {
            show_toggle_bar: true,
            show_npc_visuals: false,  // Task 4: start closed
            show_overlays: false,
            show_inspector: false,
            show_event_log: false,
            show_performance: false,
            show_catastrophe_panel: false,
            show_time_travel: false,
            show_oracle_overlay: false,
            inspector_plain_language: true,  // Task 5: plain-language is default
            show_integrity_panel: false,
        }
    }
}

/// Resource for simulation time control.
#[derive(Resource, Default)]
pub struct SimTime {
    /// Whether the simulation is paused.
    pub paused: bool,
    /// Current speed multiplier (0.5, 1.0, 2.0, 5.0, 10.0).
    pub speed: f32,
    /// Current simulation tick.
    pub tick: u64,
    /// Current state hash.
    pub hash: String,
}

/// Extension trait to provide try_ctx_mut for compatibility
trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// System that renders the toggle panel with slide-in animation (Phase 3e).
/// Uses ctx.animate_bool() for fade-in over 0.2s.
pub fn render_toggle_panel(
    mut egui_contexts: EguiContexts,
    mut ui_state: ResMut<UiState>,
    sim_time: Res<SimTime>,
) {
    if !ui_state.show_toggle_bar {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Animate panel appearance using animate_bool (Phase 3e)
        let _alpha = ctx.animate_bool(egui::Id::new("toggle_bar"), true);
        
        // Top bar
        egui::TopBottomPanel::top("toggle_bar")
            .default_height(32.0)
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    // Title bar with sim info
                    ui.label("anvil_demo");
                    ui.separator();
                    ui.label(format!("Tick: {}", sim_time.tick));
                    ui.separator();
                    ui.label(format!("Hash: {}", truncate_hash(&sim_time.hash)));
                    ui.separator();
                    
                    // Speed indicator with color
                    let speed_color = match sim_time.speed {
                        0.5 => egui::Color32::LIGHT_BLUE,
                        1.0 => egui::Color32::WHITE,
                        2.0 => egui::Color32::LIGHT_GREEN,
                        5.0 => egui::Color32::LIGHT_YELLOW,
                        10.0 => egui::Color32::ORANGE,
                        _ => egui::Color32::WHITE,
                    };
                    ui.colored_label(speed_color, format!("{}x", sim_time.speed));
                    
                    // Pause/Play indicator
                    ui.separator();
                    let pause_label = if sim_time.paused { 
                        "PAUSED"
                    } else { 
                        "PLAYING"
                    };
                    let pause_color = if sim_time.paused {
                        egui::Color32::RED
                    } else {
                        egui::Color32::GREEN
                    };
                    ui.colored_label(pause_color, pause_label);
                });

                ui.separator();

                // Toggle checkboxes for panels
                ui.horizontal(|ui| {
                    ui.checkbox(&mut ui_state.show_npc_visuals, "NPC Visuals (V)");
                    ui.checkbox(&mut ui_state.show_overlays, "Overlays (Shift+V)");
                    ui.checkbox(&mut ui_state.show_inspector, "Inspector (I)");
                    ui.checkbox(&mut ui_state.show_event_log, "Event Log (L)");
                    ui.checkbox(&mut ui_state.show_performance, "Performance (P)");
                    ui.checkbox(&mut ui_state.show_catastrophe_panel, "Catastrophe (C)");
                    ui.checkbox(&mut ui_state.show_time_travel, "Time Travel (T)");
                    ui.checkbox(&mut ui_state.show_oracle_overlay, "Oracle (O)");
                });
            });
    }
}

/// System that handles keyboard shortcuts for toggling panels.
pub fn handle_toggle_shortcuts(
    mut ui_state: ResMut<UiState>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Backtick toggles the toggle bar itself
    if keyboard_input.just_pressed(KeyCode::Backquote) {
        ui_state.show_toggle_bar = !ui_state.show_toggle_bar;
    }

    // Panel toggles
    // Check Shift+V first (before plain V) to handle the combination correctly
    if keyboard_input.just_pressed(KeyCode::KeyV) {
        if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
            ui_state.show_overlays = !ui_state.show_overlays;
        } else {
            ui_state.show_npc_visuals = !ui_state.show_npc_visuals;
        }
    }
    if keyboard_input.just_pressed(KeyCode::KeyI) {
        ui_state.show_inspector = !ui_state.show_inspector;
    }
    if keyboard_input.just_pressed(KeyCode::KeyL) {
        ui_state.show_event_log = !ui_state.show_event_log;
    }
    if keyboard_input.just_pressed(KeyCode::KeyP) {
        ui_state.show_performance = !ui_state.show_performance;
    }
    if keyboard_input.just_pressed(KeyCode::KeyC) {
        ui_state.show_catastrophe_panel = !ui_state.show_catastrophe_panel;
    }
    if keyboard_input.just_pressed(KeyCode::KeyT) {
        ui_state.show_time_travel = !ui_state.show_time_travel;
    }
    if keyboard_input.just_pressed(KeyCode::KeyO) {
        ui_state.show_oracle_overlay = !ui_state.show_oracle_overlay;
    }
}

/// Truncates a hash string to a display-friendly length.
fn truncate_hash(hash: &str) -> String {
    if hash.len() <= 6 {
        hash.to_string()
    } else {
        format!("{}…", &hash[..6])
    }
}

/// Setup system for UI state.
pub fn setup_ui_state(mut commands: Commands) {
    commands.insert_resource(UiState {
        show_toggle_bar: true,
        show_npc_visuals: false,  // Task 4: start closed by default
        show_overlays: false,
        show_inspector: false,
        show_event_log: false,
        show_performance: false,
        show_catastrophe_panel: false,
        show_time_travel: false,
        show_oracle_overlay: false,
        inspector_plain_language: true,
        show_integrity_panel: false,
    });

    commands.insert_resource(SimTime {
        paused: false,
        speed: 1.0,
        tick: 0,
        hash: "000000".to_string(),
    });
}
