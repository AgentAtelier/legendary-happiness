use bevy_egui::egui;

use crate::ui::resources::WorldIntegrity;

pub fn render_asset_section(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    ui.label(format!("Total Archetypes: {}", integrity.total_archetypes));
    ui.separator();

    // Validation summary
    let all_have_mappings = integrity.assets.iter().all(|a| a.has_glb_mapping);
    let all_exist = integrity
        .assets
        .iter()
        .filter_map(|a| a.glb_exists)
        .all(|e| e);

    ui.horizontal(|ui| {
        if all_have_mappings {
            ui.colored_label(egui::Color32::GREEN, "✅ All archetypes have GLB mappings");
        } else {
            ui.colored_label(
                egui::Color32::YELLOW,
                "⚠️  Some archetypes have no GLB mappings",
            );
        }
    });

    ui.horizontal(|ui| {
        if all_exist {
            ui.colored_label(egui::Color32::GREEN, "✅ All GLB files exist");
        } else {
            ui.colored_label(
                egui::Color32::RED,
                "❌ Some GLB files are missing",
            );
        }
    });

    ui.separator();

    // Scrollable asset list
    egui::ScrollArea::vertical().show(ui, |ui| {
        ui.label("Archetype List:");
        
        for asset in &integrity.assets {
            ui.horizontal(|ui| {
                // Status icon
                let status_icon = if asset.has_glb_mapping && asset.glb_exists == Some(true) {
                    "🟢 Mapped"
                } else if asset.has_glb_mapping {
                    "🟡 Missing"
                } else {
                    "🔴 No Mapping"
                };
                ui.label(status_icon);
                
                // Asset info
                ui.label(&asset.archetype);
            });
            
            // Show asset-specific details
            if let Some(ref path) = asset.glb_path {
                ui.label(format!("  Path: {}", path));
            }
            
            if let Some(exists) = asset.glb_exists {
                ui.label(format!("  Exists: {}", if exists { "✅" } else { "❌" }));
            }
            
            // Show asset-specific errors
            if !asset.errors.is_empty() {
                for error in &asset.errors {
                    ui.colored_label(egui::Color32::RED, format!("  ❌ {}", error));
                }
            }
            
            ui.separator();
        }
    });
}

// ============================================================================
// 5. Errors & Warnings Section
// ============================================================================

/// Render the Errors & Warnings section.
