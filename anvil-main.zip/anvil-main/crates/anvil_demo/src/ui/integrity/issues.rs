use bevy_egui::egui;

use crate::ui::resources::{Severity, ValidationError, ValidationWarning, WorldIntegrity};

pub fn render_issues_section(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    // Error counts by severity
    ui.horizontal(|ui| {
        ui.label(format!("🔴 Critical: {}", integrity.critical_error_count()));
        ui.label(format!("🟠 High: {}", integrity.high_error_count()));
        ui.label(format!("🟡 Medium: {}", integrity.medium_error_count()));
        ui.label(format!("🔵 Low: {}", integrity.low_error_count()));
    });
    
    ui.label(format!("⚠️  Warnings: {}", integrity.warnings.len()));
    ui.separator();

    // Clear button
    if ui.button("Clear All Issues").clicked() {
        // Note: Clearing is handled by the system that rebuilds integrity each frame
        // This button is here for UI consistency but the actual clear happens in sync
    }
    
    ui.separator();

    // Errors list
    if !integrity.errors.is_empty() {
        ui.label("Errors:");
        egui::ScrollArea::vertical().show(ui, |ui| {
            for error in &integrity.errors {
                ui.colored_label(error.severity.color(), format!("[{}] {}", error.severity.name(), error.message));
            }
        });
        ui.separator();
    }

    // Warnings list
    if !integrity.warnings.is_empty() {
        ui.label("Warnings:");
        egui::ScrollArea::vertical().show(ui, |ui| {
            for warning in &integrity.warnings {
                ui.colored_label(egui::Color32::YELLOW, format!("⚠️  {}", warning.message));
            }
        });
    }
}
