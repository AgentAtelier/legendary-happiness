use bevy_egui::egui;

use crate::ui::resources::{NpcIntegrity, Severity, WorldIntegrity};

pub fn render_npc_section(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    ui.label(format!("Total NPCs: {}", integrity.total_npcs));
    ui.label(format!("Active NPCs: {}", integrity.active_npcs));
    ui.separator();

    // Validation summary
    let all_valid_ids = integrity.npcs.iter().all(|n| n.has_valid_id);
    let all_valid_substrates = integrity.npcs.iter().all(|n| n.has_valid_substrate);
    let all_valid_actions = integrity.npcs.iter().all(|n| n.has_valid_actions);
    let all_valid_states = integrity.npcs.iter().all(|n| n.is_valid_state);

    // Check for duplicate NPC IDs
    let mut seen_ids = std::collections::HashSet::new();
    let has_duplicates = integrity.npcs.iter().any(|n| !seen_ids.insert(n.id));

    ui.horizontal(|ui| {
        if all_valid_ids {
            ui.colored_label(egui::Color32::GREEN, "✅ All NPCs have valid IDs");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Some NPCs have invalid IDs");
        }
    });

    ui.horizontal(|ui| {
        if !has_duplicates {
            ui.colored_label(egui::Color32::GREEN, "✅ No duplicate NPC IDs");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Duplicate NPC IDs detected");
        }
    });

    ui.horizontal(|ui| {
        if all_valid_substrates {
            ui.colored_label(egui::Color32::GREEN, "✅ All NPCs have valid substrates");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Some NPCs have invalid substrates");
        }
    });

    ui.horizontal(|ui| {
        if all_valid_actions {
            ui.colored_label(egui::Color32::GREEN, "✅ All NPCs have valid actions");
        } else {
            ui.colored_label(egui::Color32::YELLOW, "⚠️  Some NPCs have invalid actions");
        }
    });

    ui.horizontal(|ui| {
        if all_valid_states {
            ui.colored_label(egui::Color32::GREEN, "✅ All NPCs in valid states");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Some NPCs in invalid states");
        }
    });

    ui.separator();

    // Scrollable NPC list
    egui::ScrollArea::vertical().show(ui, |ui| {
        ui.label("NPC List:");
        
        for npc in &integrity.npcs {
            ui.horizontal(|ui| {
                // Status icon
                let status_icon = if npc.has_valid_id && npc.has_valid_substrate && npc.has_valid_actions {
                    "🟢 Valid"
                } else {
                    "🔴 Invalid"
                };
                ui.label(status_icon);
                
                // NPC info
                ui.label(format!("{} (ID: {})", npc.name, npc.id));
            });
            
            // Show NPC-specific details
            ui.horizontal(|ui| {
                ui.label(format!("  Valid ID: {}", if npc.has_valid_id { "✅" } else { "❌" }));
                ui.label(format!("  Valid Substrate: {}", if npc.has_valid_substrate { "✅" } else { "❌" }));
                ui.label(format!("  Valid Actions: {}", if npc.has_valid_actions { "✅" } else { "❌" }));
            });
            
            // Show NPC-specific errors
            if !npc.errors.is_empty() {
                for error in &npc.errors {
                    ui.colored_label(egui::Color32::RED, format!("  ❌ {}", error));
                }
            }
            
            ui.separator();
        }
    });
}

// ============================================================================
// 3. Connection Graph Section
// ============================================================================

/// Render the Connection Graph section.
