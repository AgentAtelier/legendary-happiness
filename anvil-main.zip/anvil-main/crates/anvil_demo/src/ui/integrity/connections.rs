use bevy_egui::egui;

use crate::ui::resources::{ConnectionIntegrity, Severity, WorldIntegrity};

pub fn render_connection_section(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    ui.label(format!("Total Connections: {}", integrity.total_connections));
    ui.separator();

    // Validation summary
    let all_bidirectional = integrity.connections.iter().all(|c| c.is_bidirectional);
    let all_regions_exist = integrity.connections.iter().all(|c| c.regions_exist);

    // Check for orphaned regions
    let orphaned_count = integrity
        .regions
        .iter()
        .filter(|r| r.connection_count == 0)
        .count();

    ui.horizontal(|ui| {
        if all_bidirectional {
            ui.colored_label(egui::Color32::GREEN, "✅ All connections are bidirectional");
        } else {
            ui.colored_label(
                egui::Color32::YELLOW,
                "⚠️  Some connections are not bidirectional",
            );
        }
    });

    ui.horizontal(|ui| {
        if all_regions_exist {
            ui.colored_label(egui::Color32::GREEN, "✅ All connections reference valid regions");
        } else {
            ui.colored_label(
                egui::Color32::RED,
                "❌ Some connections reference invalid regions",
            );
        }
    });

    ui.horizontal(|ui| {
        if orphaned_count == 0 {
            ui.colored_label(egui::Color32::GREEN, "✅ No orphaned regions");
        } else {
            ui.colored_label(
                egui::Color32::YELLOW,
                format!("⚠️  {} orphaned regions", orphaned_count),
            );
        }
    });

    ui.separator();

    // Scrollable connection list
    egui::ScrollArea::vertical().show(ui, |ui| {
        ui.label("Connection List:");
        
        for conn in &integrity.connections {
            ui.horizontal(|ui| {
                // Status icon
                let status_icon = if conn.is_bidirectional && conn.regions_exist {
                    "🟢 Valid"
                } else if conn.regions_exist {
                    "🟡 Partial"
                } else {
                    "🔴 Invalid"
                };
                ui.label(status_icon);
                
                // Connection info
                ui.label(format!("{} -> {}", conn.from_region, conn.to_region));
            });
            
            // Show connection-specific details
            ui.horizontal(|ui| {
                ui.label(format!("  Bidirectional: {}", if conn.is_bidirectional { "✅" } else { "❌" }));
                ui.label(format!("  Regions Exist: {}", if conn.regions_exist { "✅" } else { "❌" }));
            });
            
            // Show connection-specific errors
            if !conn.errors.is_empty() {
                for error in &conn.errors {
                    ui.colored_label(egui::Color32::RED, format!("  ❌ {}", error));
                }
            }
            
            ui.separator();
        }
    });
}

// ============================================================================
// 4. Asset Catalogue Section
// ============================================================================

/// Render the Asset Catalogue section.
