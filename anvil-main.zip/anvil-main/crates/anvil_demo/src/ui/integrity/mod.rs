//! World Integrity Debug Panel
//!
//! This module provides a debug panel that displays world state validation
//! and integrity checks. The panel reads from Bevy resources synced via
//! SimBridgePlugin and helps identify issues during development.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::{
    panel::UiState,
    resources::{
        ConnectionIntegrity, NpcIntegrity, RegionIntegrity, Severity, ValidationError,
        ValidationWarning, WorldIntegrity,
    },
};

mod assets;
mod connections;
mod content;
mod issues;
mod npcs;
mod regions;

pub use assets::render_asset_section;
pub use connections::render_connection_section;
pub use content::render_integrity_content;
pub use issues::render_issues_section;
pub use npcs::render_npc_section;
pub use regions::render_region_section;

/// Plugin for the World Integrity debug panel.
pub struct IntegrityPlugin;

impl Plugin for IntegrityPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<WorldIntegrity>()
            .add_systems(Update, render_integrity_panel);
    }
}

/// System that renders the World Integrity panel.
///
/// Position: Bottom-right
/// Size: 300x400 pixels (adjustable)
/// Visibility: Toggle with key W
pub fn render_integrity_panel(
    mut egui_contexts: EguiContexts,
    ui_state: Res<UiState>,
    integrity: Res<WorldIntegrity>,
) {
    // Only render if the integrity panel is enabled
    if !ui_state.show_integrity_panel {
        return;
    }

    if let Some(ctx) = egui_contexts.ctx_mut() {
        egui::Window::new("World Integrity")
            .default_pos(egui::Pos2::new(1024.0 - 320.0, 768.0 - 420.0))
            .default_size(egui::Vec2::new(300.0, 400.0))
            .resizable(true)
            .show(ctx, |ui| {
                render_integrity_content(ui, &integrity);
            });
    }
}
