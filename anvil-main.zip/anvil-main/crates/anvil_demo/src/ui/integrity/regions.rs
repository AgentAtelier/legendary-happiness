use bevy_egui::egui;

use crate::ui::resources::{RegionIntegrity, Severity, WorldIntegrity};

pub fn render_region_section(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    ui.label(format!("Total Regions: {}", integrity.total_regions));
    ui.label(format!("Loaded Regions: {}", integrity.loaded_regions));
    ui.separator();

    // Validation summary
    let all_valid_ids = integrity.regions.iter().all(|r| r.has_valid_id);
    let any_duplicates = integrity.regions.len() != integrity.total_regions;

    ui.horizontal(|ui| {
        if all_valid_ids {
            ui.colored_label(egui::Color32::GREEN, "✅ All regions have valid IDs");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Some regions have invalid IDs");
        }
    });

    ui.horizontal(|ui| {
        if !any_duplicates {
            ui.colored_label(egui::Color32::GREEN, "✅ No duplicate region IDs");
        } else {
            ui.colored_label(egui::Color32::RED, "❌ Duplicate region IDs detected");
        }
    });

    let all_valid_connections = integrity
        .regions
        .iter()
        .all(|r| r.connection_count > 0 || integrity.total_regions <= 1);

    ui.horizontal(|ui| {
        if all_valid_connections {
            ui.colored_label(egui::Color32::GREEN, "✅ All regions have valid connections");
        } else {
            ui.colored_label(
                egui::Color32::YELLOW,
                "⚠️  Some regions have no connections",
            );
        }
    });

    ui.separator();

    // Scrollable region list
    egui::ScrollArea::vertical().show(ui, |ui| {
        ui.label("Region List:");
        
        for region in &integrity.regions {
            ui.horizontal(|ui| {
                // Status icon
                let status_icon = if region.is_loaded {
                    "🟢 Loaded"
                } else {
                    "🔴 Unloaded"
                };
                ui.label(status_icon);
                
                // Region info
                ui.label(format!("{} ({})", region.name, region.id));
            });
            
            ui.horizontal(|ui| {
                ui.label(format!("  Population: {}", region.population));
                ui.label(format!("  Connections: {}", region.connection_count));
            });
            
            // Show region-specific errors
            if !region.errors.is_empty() {
                for error in &region.errors {
                    ui.colored_label(egui::Color32::RED, format!("  ❌ {}", error));
                }
            }
            
            ui.separator();
        }
    });
}

// ============================================================================
// 2. NPC Validation Section
// ============================================================================

/// Render the NPC Validation section.
