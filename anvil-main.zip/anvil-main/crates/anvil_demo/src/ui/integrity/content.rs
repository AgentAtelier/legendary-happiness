use bevy_egui::egui;

use super::regions::render_region_section;
use super::npcs::render_npc_section;
use super::connections::render_connection_section;
use super::assets::render_asset_section;
use super::issues::render_issues_section;

use crate::ui::resources::WorldIntegrity;

pub fn render_integrity_content(ui: &mut egui::Ui, integrity: &WorldIntegrity) {
    // Summary header with counts
    ui.horizontal(|ui| {
        ui.label("🌍 World Integrity");
        ui.separator();
        
        // Error/warning indicator
        if integrity.has_errors() {
            ui.colored_label(
                egui::Color32::RED,
                format!("❌ {} errors", integrity.errors.len()),
            );
        } else if integrity.has_warnings() {
            ui.colored_label(
                egui::Color32::YELLOW,
                format!("⚠️  {} warnings", integrity.warnings.len()),
            );
        } else {
            ui.colored_label(
                egui::Color32::GREEN,
                "✅ All checks passed",
            );
        }
    });

    ui.separator();

    // Tabs for different sections
    egui::TabBar::new("integrity_tabs").show(ui, |ui| {
        // Region Integrity Tab
        ui.tab("🗺️  Regions", |ui| {
            render_region_section(ui, integrity);
        });

        // NPC Validation Tab
        ui.tab("👥 NPCs", |ui| {
            render_npc_section(ui, integrity);
        });

        // Connection Graph Tab
        ui.tab("🔗 Connections", |ui| {
            render_connection_section(ui, integrity);
        });

        // Asset Catalogue Tab
        ui.tab("📦 Assets", |ui| {
            render_asset_section(ui, integrity);
        });

        // Errors & Warnings Tab
        ui.tab("⚠️  Issues", |ui| {
            render_issues_section(ui, integrity);
        });
    });
}

// ============================================================================
// 1. Region Integrity Section
// ============================================================================

/// Render the Region Integrity section.
