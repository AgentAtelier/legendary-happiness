use bevy::prelude::*;
use bevy_egui::egui;

// ============================================================================
// World Integrity Panel Resources
// ============================================================================

/// Severity level for validation errors.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Severity {
    /// Critical errors that must be fixed.
    Critical,
    /// High-severity issues that should be addressed.
    High,
    /// Medium-severity issues that are nice to fix.
    Medium,
    /// Low-severity warnings.
    Low,
}

impl Severity {
    /// Returns the display name for this severity.
    pub fn name(&self) -> &'static str {
        match self {
            Severity::Critical => "Critical",
            Severity::High => "High",
            Severity::Medium => "Medium",
            Severity::Low => "Low",
        }
    }

    /// Returns the color for this severity.
    pub fn color(&self) -> egui::Color32 {
        match self {
            Severity::Critical => egui::Color32::RED,
            Severity::High => egui::Color32::ORANGE,
            Severity::Medium => egui::Color32::YELLOW,
            Severity::Low => egui::Color32::LIGHT_BLUE,
        }
    }
}

impl Default for Severity {
    fn default() -> Self {
        Self::Medium
    }
}

/// Information about a single region's integrity.
#[derive(Debug, Clone)]
pub struct RegionIntegrity {
    /// Region identifier.
    pub id: String,
    /// Region display name.
    pub name: String,
    /// Whether the region is loaded.
    pub is_loaded: bool,
    /// Whether the region has valid ID.
    pub has_valid_id: bool,
    /// Number of connections from/to this region.
    pub connection_count: usize,
    /// Population count.
    pub population: usize,
    /// Validation errors for this region.
    pub errors: Vec<String>,
}

/// Information about a single NPC's integrity.
#[derive(Debug, Clone)]
pub struct NpcIntegrity {
    /// NPC identifier.
    pub id: u64,
    /// NPC display name.
    pub name: String,
    /// Whether the NPC has valid ID (1-8 for Ashveil).
    pub has_valid_id: bool,
    /// Whether the NPC has valid substrate values.
    pub has_valid_substrate: bool,
    /// Whether the NPC has valid actions.
    pub has_valid_actions: bool,
    /// Whether the NPC is in a valid state.
    pub is_valid_state: bool,
    /// Validation errors for this NPC.
    pub errors: Vec<String>,
}

/// Information about a single connection's integrity.
#[derive(Debug, Clone)]
pub struct ConnectionIntegrity {
    /// Connection identifier.
    pub id: String,
    /// Source region.
    pub from_region: String,
    /// Destination region.
    pub to_region: String,
    /// Whether the connection is bidirectional.
    pub is_bidirectional: bool,
    /// Whether both regions exist.
    pub regions_exist: bool,
    /// Validation errors for this connection.
    pub errors: Vec<String>,
}

/// Information about an asset catalogue entry.
#[derive(Debug, Clone)]
pub struct AssetIntegrity {
    /// Archetype tag.
    pub archetype: String,
    /// Whether the archetype has a GLB mapping.
    pub has_glb_mapping: bool,
    /// GLB path if mapped.
    pub glb_path: Option<String>,
    /// Whether the GLB file exists (if checked).
    pub glb_exists: Option<bool>,
    /// Validation errors for this asset.
    pub errors: Vec<String>,
}

/// A validation error with severity.
#[derive(Debug, Clone)]
pub struct ValidationError {
    /// Error message.
    pub message: String,
    /// Severity level.
    pub severity: Severity,
}

/// A validation warning.
#[derive(Debug, Clone)]
pub struct ValidationWarning {
    /// Warning message.
    pub message: String,
}

/// Resource containing all world integrity information.
/// This is synced from the runtime and used by the integrity panel.
#[derive(Resource, Debug, Default, Clone)]
pub struct WorldIntegrity {
    /// All regions with their integrity status.
    pub regions: Vec<RegionIntegrity>,
    /// All NPCs with their integrity status.
    pub npcs: Vec<NpcIntegrity>,
    /// All connections with their integrity status.
    pub connections: Vec<ConnectionIntegrity>,
    /// All assets with their integrity status.
    pub assets: Vec<AssetIntegrity>,
    /// All validation errors.
    pub errors: Vec<ValidationError>,
    /// All validation warnings.
    pub warnings: Vec<ValidationWarning>,
    /// Total count of regions.
    pub total_regions: usize,
    /// Total count of loaded regions.
    pub loaded_regions: usize,
    /// Total count of NPCs.
    pub total_npcs: usize,
    /// Total count of active NPCs (in loaded regions).
    pub active_npcs: usize,
    /// Total count of connections.
    pub total_connections: usize,
    /// Total count of archetypes.
    pub total_archetypes: usize,
}

impl WorldIntegrity {
    /// Creates a new empty WorldIntegrity resource.
    pub fn new() -> Self {
        Self::default()
    }

    /// Clears all data.
    pub fn clear(&mut self) {
        self.regions.clear();
        self.npcs.clear();
        self.connections.clear();
        self.assets.clear();
        self.errors.clear();
        self.warnings.clear();
        self.total_regions = 0;
        self.loaded_regions = 0;
        self.total_npcs = 0;
        self.active_npcs = 0;
        self.total_connections = 0;
        self.total_archetypes = 0;
    }

    /// Adds a validation error.
    pub fn add_error(&mut self, message: String, severity: Severity) {
        self.errors.push(ValidationError { message, severity });
    }

    /// Adds a validation warning.
    pub fn add_warning(&mut self, message: String) {
        self.warnings.push(ValidationWarning { message });
    }

    /// Returns true if there are any errors.
    pub fn has_errors(&self) -> bool {
        !self.errors.is_empty()
    }

    /// Returns true if there are any warnings.
    pub fn has_warnings(&self) -> bool {
        !self.warnings.is_empty()
    }

    /// Returns true if there are any issues (errors or warnings).
    pub fn has_issues(&self) -> bool {
        self.has_errors() || self.has_warnings()
    }

    /// Returns the count of critical errors.
    pub fn critical_error_count(&self) -> usize {
        self.errors.iter().filter(|e| e.severity == Severity::Critical).count()
    }

    /// Returns the count of high-severity errors.
    pub fn high_error_count(&self) -> usize {
        self.errors.iter().filter(|e| e.severity == Severity::High).count()
    }

    /// Returns the count of medium-severity errors.
    pub fn medium_error_count(&self) -> usize {
        self.errors.iter().filter(|e| e.severity == Severity::Medium).count()
    }

    /// Returns the count of low-severity errors.
    pub fn low_error_count(&self) -> usize {
        self.errors.iter().filter(|e| e.severity == Severity::Low).count()
    }
}
