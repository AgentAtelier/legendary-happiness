// ============================================================================
// Oracle Panel Resources
// ============================================================================

use bevy::prelude::Resource;

/// A single action prediction with score and explanation.
#[derive(Debug, Clone)]
pub struct ActionPrediction {
    /// Action identifier/name.
    pub action: String,
    /// Utility score for this action.
    pub score: f32,
    /// Whether this is the best action.
    pub is_best: bool,
    /// Explanation of why this action scores this way.
    pub explanation: String,
}

/// Predictions for an NPC's next actions.
#[derive(Resource, Debug, Clone, Default)]
pub struct NpcPredictions {
    /// NPC ID these predictions are for.
    pub npc_id: Option<u64>,
    /// The NPC's name.
    pub npc_name: String,
    /// Top 3 predicted actions.
    pub predictions: Vec<ActionPrediction>,
}

impl NpcPredictions {
    /// Creates a new empty predictions set.
    pub fn new() -> Self {
        Self {
            npc_id: None,
            npc_name: "None".to_string(),
            predictions: Vec::with_capacity(3),
        }
    }
    
    /// Updates predictions for a specific NPC.
    pub fn set(&mut self, npc_id: u64, npc_name: String, predictions: Vec<ActionPrediction>) {
        self.npc_id = Some(npc_id);
        self.npc_name = npc_name;
        self.predictions = predictions;
    }
    
    /// Clears predictions.
    pub fn clear(&mut self) {
        self.npc_id = None;
        self.npc_name.clear();
        self.predictions.clear();
    }
}
