use bevy::prelude::*;
use anvil_demo_core::beat::DemoPhase;

// ============================================================================
// SimStatus Panel Resources
// ============================================================================

/// Current demo phase (Dawn, RidgeStreamIn, SenneSeesFire, etc.)
#[derive(Resource, Debug, Clone, Copy, PartialEq, Eq)]
pub struct CurrentDemoPhase(pub DemoPhase);

impl Default for CurrentDemoPhase {
    fn default() -> Self {
        Self(DemoPhase::Dawn)
    }
}

impl CurrentDemoPhase {
    /// Returns the phase description.
    pub fn description(&self) -> &'static str {
        self.0.description()
    }
    
    /// Returns the phase name.
    pub fn name(&self) -> &'static str {
        match self.0 {
            DemoPhase::Dawn => "Dawn",
            DemoPhase::RidgeStreamIn => "RidgeStreamIn",
            DemoPhase::SenneSeesFire => "SenneSeesFire",
            DemoPhase::FireArrives => "FireArrives",
            DemoPhase::SettlementResponse => "SettlementResponse",
            DemoPhase::DaksFear => "DaksFear",
            DemoPhase::Rain => "Rain",
            DemoPhase::Determinism => "Determinism",
            DemoPhase::AshveilStands => "AshveilStands",
            _ => "Unknown",
        }
    }
}

/// Current simulation tick count.
#[derive(Resource, Debug, Clone, Copy, PartialEq, Eq)]
pub struct CurrentTick(pub u64);

impl Default for CurrentTick {
    fn default() -> Self {
        Self(0)
    }
}

/// Demo completion percentage (0.0 to 1.0).
#[derive(Resource, Debug, Clone, Copy)]
pub struct DemoCompletion(pub f32);

impl Default for DemoCompletion {
    fn default() -> Self {
        Self(0.0)
    }
}

impl DemoCompletion {
    /// Returns completion as a percentage string.
    pub fn as_percent(&self) -> String {
        format!("{:.1}%", self.0 * 100.0)
    }
}
