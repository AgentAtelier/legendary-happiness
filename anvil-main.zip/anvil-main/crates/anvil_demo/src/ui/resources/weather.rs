// ============================================================================
// Weather Panel Resources
// ============================================================================

use bevy::prelude::*;

/// Weather trend information.
#[derive(Resource, Debug, Clone)]
pub struct WeatherTrend {
    /// Temperature trend (+ for increasing, - for decreasing).
    pub temperature_trend: f32,
    /// Humidity trend.
    pub humidity_trend: f32,
    /// Wind speed trend.
    pub wind_speed_trend: f32,
    /// Whether weather is changing significantly.
    pub is_changing: bool,
}

impl Default for WeatherTrend {
    fn default() -> Self {
        Self {
            temperature_trend: 0.0,
            humidity_trend: 0.0,
            wind_speed_trend: 0.0,
            is_changing: false,
        }
    }
}

/// Active catastrophe warnings.
#[derive(Resource, Debug, Clone, Default)]
pub struct CatastropheWarnings {
    /// List of active catastrophe names.
    pub active: Vec<String>,
    /// List of pending precursor signals.
    pub precursors: Vec<String>,
    /// Severity of the most severe active catastrophe (0.0 to 1.0).
    pub max_severity: f32,
}

impl CatastropheWarnings {
    /// Creates a new empty warnings set.
    pub fn new() -> Self {
        Self {
            active: Vec::new(),
            precursors: Vec::new(),
            max_severity: 0.0,
        }
    }
    
    /// Adds an active catastrophe.
    pub fn add_active(&mut self, name: String, severity: f32) {
        self.active.push(name);
        self.max_severity = self.max_severity.max(severity);
    }
    
    /// Adds a precursor signal.
    pub fn add_precursor(&mut self, signal: String) {
        self.precursors.push(signal);
    }
    
    /// Clears all warnings.
    pub fn clear(&mut self) {
        self.active.clear();
        self.precursors.clear();
        self.max_severity = 0.0;
    }
    
    /// Returns true if there are any warnings.
    pub fn has_warnings(&self) -> bool {
        !self.active.is_empty() || !self.precursors.is_empty()
    }
}
