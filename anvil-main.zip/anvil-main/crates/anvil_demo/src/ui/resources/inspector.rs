// ============================================================================
// Inspector Panel Resources
// ============================================================================

use bevy::prelude::*;

/// ID of the currently selected NPC for inspection.
#[derive(Resource, Debug, Clone, Copy, PartialEq, Eq)]
pub struct SelectedNpc(pub Option<u64>);

impl Default for SelectedNpc {
    fn default() -> Self {
        Self(None)
    }
}

impl SelectedNpc {
    /// Returns true if an NPC is selected.
    pub fn has_selection(&self) -> bool {
        self.0.is_some()
    }
    
    /// Returns the selected NPC ID or 0.
    pub fn get(&self) -> u64 {
        self.0.unwrap_or(0)
    }
}

/// Detailed information about an NPC.
#[derive(Resource, Debug, Clone)]
pub struct NpcDetails {
    /// NPC unique identifier.
    pub id: u64,
    /// NPC display name.
    pub name: String,
    /// NPC family/group identifier.
    pub family: String,
    /// NPC age in years.
    pub age: u32,
    /// Current dominant need.
    pub dominant_need: String,
    /// Need satisfaction levels (name -> value).
    pub needs: std::collections::HashMap<String, f32>,
    /// Emotional state values.
    pub emotions: std::collections::HashMap<String, f32>,
    /// Skill domain -> fluency level.
    pub skills: std::collections::HashMap<String, String>,
    /// Current action being performed.
    pub current_action: String,
    /// Action score breakdown (factor -> value).
    pub action_scores: std::collections::HashMap<String, f32>,
    /// Belonging value (0.0 to 1.0).
    pub belonging: f32,
    /// Position in world.
    pub position: (f32, f32, f32),
}

impl Default for NpcDetails {
    fn default() -> Self {
        Self {
            id: 0,
            name: "Unknown".to_string(),
            family: "None".to_string(),
            age: 0,
            dominant_need: "None".to_string(),
            needs: std::collections::HashMap::new(),
            emotions: std::collections::HashMap::new(),
            skills: std::collections::HashMap::new(),
            current_action: "Idle".to_string(),
            action_scores: std::collections::HashMap::new(),
            belonging: 0.0,
            position: (0.0, 0.0, 0.0),
        }
    }
}
