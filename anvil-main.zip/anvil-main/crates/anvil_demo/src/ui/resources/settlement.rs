// ============================================================================
// Settlement Panel Resources
// ============================================================================

use bevy::prelude::Resource;

/// Information about a single region.
#[derive(Debug, Clone)]
pub struct RegionInfo {
    /// Region identifier.
    pub id: String,
    /// Region display name.
    pub name: String,
    /// Whether the region is currently loaded.
    pub is_loaded: bool,
    /// Number of persons in the region.
    pub population: usize,
    /// Food resource level (0.0 to 1.0).
    pub food: f32,
    /// Water resource level (0.0 to 1.0).
    pub water: f32,
    /// Materials resource level (0.0 to 1.0).
    pub materials: f32,
    /// Structural integrity (0.0 to 1.0).
    pub structural_integrity: f32,
}

/// Collection of all region states.
#[derive(Resource, Debug, Clone, Default)]
pub struct RegionStates {
    /// All regions in the world.
    pub regions: Vec<RegionInfo>,
    /// Total population across all regions.
    pub total_population: usize,
}

impl RegionStates {
    /// Creates a new empty RegionStates.
    pub fn new() -> Self {
        Self {
            regions: Vec::new(),
            total_population: 0,
        }
    }
    
    /// Gets a region by ID.
    pub fn get(&self, id: &str) -> Option<&RegionInfo> {
        self.regions.iter().find(|r| r.id == id)
    }
    
    /// Gets the settlement region (ashveil_valley).
    pub fn settlement(&self) -> Option<&RegionInfo> {
        self.regions.iter().find(|r| r.id == "ashveil_valley")
    }
}
