//! UI Resources for Ashveil Demo Panels
//!
//! This module contains all Bevy resources that mirror anvil_demo_core state
//! for use by egui panels. These resources are synced from core via SimBridgePlugin.
//!
//! Architecture:
//!   anvil_demo_core (SequencerState, WorldAuthored, etc.)
//!       \u{2193} sync via SimBridgePlugin
//!   Bevy Resources (in this module)
//!       \u{2193} read by
//!   UI Systems (in ui/ panels)
//!
//! This maintains the firewall: UI never imports anvil_demo_core types directly.

pub mod integrity;
pub mod inspector;
pub mod oracle;
pub mod settlement;
pub mod sim_status;
pub mod ui_panel;
pub mod weather;

pub use integrity::{
    AssetIntegrity, ConnectionIntegrity, NpcIntegrity, RegionIntegrity, Severity,
    WorldIntegrity,
};
pub use inspector::{NpcDetails, SelectedNpc};
pub use oracle::NpcPredictions;
pub use settlement::{RegionInfo, RegionStates};
pub use sim_status::{CurrentDemoPhase, CurrentTick, DemoCompletion};
pub use weather::{CatastropheWarnings, WeatherTrend};
