// ============================================================================
// Combined Resources for Convenience
// ============================================================================

use bevy::prelude::*;
use super::{
    CatastropheWarnings, CurrentDemoPhase, CurrentTick, DemoCompletion,
    NpcDetails, NpcPredictions, RegionStates, SelectedNpc, WeatherTrend, WorldIntegrity,
};

/// All resources needed for UI panels, bundled for convenience.
/// This can be used to pass all UI state at once.
#[derive(Resource, Debug, Clone)]
pub struct UiPanelResources {
    pub phase: CurrentDemoPhase,
    pub tick: CurrentTick,
    pub completion: DemoCompletion,
    pub speed: crate::app::SimSpeed,
    pub regions: RegionStates,
    pub selected_npc: SelectedNpc,
    pub npc_details: NpcDetails,
    pub predictions: NpcPredictions,
    pub weather_trend: WeatherTrend,
    pub warnings: CatastropheWarnings,
    pub integrity: WorldIntegrity,
}

impl Default for UiPanelResources {
    fn default() -> Self {
        Self {
            phase: CurrentDemoPhase::default(),
            tick: CurrentTick::default(),
            completion: DemoCompletion::default(),
            speed: crate::app::SimSpeed::default(),
            regions: RegionStates::default(),
            selected_npc: SelectedNpc::default(),
            npc_details: NpcDetails::default(),
            predictions: NpcPredictions::default(),
            weather_trend: WeatherTrend::default(),
            warnings: CatastropheWarnings::default(),
            integrity: WorldIntegrity::default(),
        }
    }
}

// ============================================================================
// Helper Types
// ============================================================================

/// Position in 3D space for UI display.
#[derive(Debug, Clone, Copy)]
pub struct UiPosition {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl From<(f32, f32, f32)> for UiPosition {
    fn from(pos: (f32, f32, f32)) -> Self {
        Self {
            x: pos.0,
            y: pos.1,
            z: pos.2,
        }
    }
}

impl UiPosition {
    pub fn as_tuple(&self) -> (f32, f32, f32) {
        (self.x, self.y, self.z)
    }
    
    pub fn display(&self) -> String {
        format!("({:.1}, {:.1}, {:.1})", self.x, self.y, self.z)
    }
}
