//! UI Theme system for the Visual Uplift Sprint.
//!
//! Defines a consistent color palette, spacing, and styling for all panels.

use bevy::prelude::*;
use bevy_egui::{EguiContexts, egui};

use crate::states::options::{AccessibilityOptions, DisplayOptions};

/// UI Theme with color palette, spacing, and font settings.
#[derive(Resource, Clone, Debug)]
#[allow(dead_code)]
pub struct UiTheme {
    /// Background color for panels - dark grey (#1F2124).
    pub background: egui::Color32,
    /// Surface color for widgets - slightly lighter (#2A2D31).
    pub surface: egui::Color32,
    /// Border color - subtle separation (#3A3D42).
    pub border: egui::Color32,
    /// Primary text color - warm light (#E4D4B9).
    pub text_primary: egui::Color32,
    /// Secondary text color - muted (#8C8375).
    pub text_secondary: egui::Color32,
    /// Accent color - amber/gold (#B89B72).
    pub accent: egui::Color32,
    /// Success color - green (#4B9B6B).
    pub success: egui::Color32,
    /// Warning color - orange (#C78D4B).
    pub warning: egui::Color32,
    /// Danger color - red (#C2422E).
    pub danger: egui::Color32,
    /// Joy accent color - warm gold (#E5C175).
    pub joy: egui::Color32,
}

impl Default for UiTheme {
    fn default() -> Self {
        Self {
            background: egui::Color32::from_rgb(0x1F, 0x21, 0x24), // #1F2124
            surface: egui::Color32::from_rgb(0x2A, 0x2D, 0x31),   // #2A2D31
            border: egui::Color32::from_rgb(0x3A, 0x3D, 0x42),     // #3A3D42
            text_primary: egui::Color32::from_rgb(0xE4, 0xD4, 0xB9), // #E4D4B9
            text_secondary: egui::Color32::from_rgb(0x8C, 0x83, 0x75), // #8C8375
            accent: egui::Color32::from_rgb(0xB8, 0x9B, 0x72),    // #B89B72
            success: egui::Color32::from_rgb(0x4B, 0x9B, 0x6B),    // #4B9B6B
            warning: egui::Color32::from_rgb(0xC7, 0x8D, 0x4B),    // #C78D4B
            danger: egui::Color32::from_rgb(0xC2, 0x42, 0x2E),     // #C2422E
            joy: egui::Color32::from_rgb(0xE5, 0xC1, 0x75),       // #E5C175
        }
    }
}

impl UiTheme {
    /// Apply this theme to an egui context.
    pub fn apply(&self, ctx: &mut egui::Context) {
        let mut style = (*ctx.style()).clone();

        // Window styling
        style.visuals.widgets.noninteractive.bg_fill = self.surface;
        style.visuals.widgets.noninteractive.bg_stroke = egui::Stroke::new(1.0, self.border);
        
        // Window background
        style.visuals.window_fill = self.background;
        
        // Button styling
        style.visuals.widgets.active.bg_fill = self.accent;
        style.visuals.widgets.hovered.bg_fill = self.accent;
        
        // Rounded windows (4px corner radius)
        style.visuals.window_corner_radius = egui::CornerRadius::same(4);
        
        // Spacing
        style.spacing.item_spacing = egui::Vec2::new(8.0, 4.0);
        style.spacing.window_margin = egui::Margin::same(12);

        ctx.set_style(style);
    }
}

/// System to apply the UI theme to the egui context.
pub fn apply_ui_theme(
    mut egui_contexts: EguiContexts,
    theme: Res<UiTheme>,
) {
    if let Ok(ctx) = egui_contexts.ctx_mut() {
        theme.apply(ctx);
    }
}

/// System to apply the UI scale from DisplayOptions to the egui context.
/// UI scale ranges from 80% (0.8) to 140% (1.4).
pub fn apply_ui_scale(
    mut egui_contexts: EguiContexts,
    display_options: Res<DisplayOptions>,
) {
    if let Ok(ctx) = egui_contexts.ctx_mut() {
        // egui uses pixels_per_point for scaling
        // Default is 1.0, higher values make everything larger
        let scale = display_options.ui_scale;
        ctx.set_pixels_per_point(scale);
    }
}

/// Apply color-blind mode transformation to a color.
/// Currently implements deuteranopia (red-green) simulation.
#[allow(dead_code)]
fn apply_color_blind(color: egui::Color32, enabled: bool) -> egui::Color32 {
    if !enabled {
        return color;
    }

    // Deuteranopia (red-green) transformation matrix
    // This approximates what people with deuteranopia see
    // Matrix from: https://www.inf.ufrgs.br/~oliveira/pubs_files/CVD_Simulation/CVD_Simulation.html
    let r = color.r() as f32 / 255.0;
    let g = color.g() as f32 / 255.0;
    let b = color.b() as f32 / 255.0;

    // Deuteranopia simulation
    let new_r = 0.625 * r + 0.375 * g + 0.0 * b;
    let new_g = 0.7 * r + 0.3 * g + 0.0 * b;
    let new_b = 0.0 * r + 0.3 * g + 0.7 * b;

    egui::Color32::from_rgb(
        (new_r * 255.0).min(255.0) as u8,
        (new_g * 255.0).min(255.0) as u8,
        (new_b * 255.0).min(255.0) as u8,
    )
}

/// System to apply color-blind mode to the egui visuals.
/// Currently a placeholder - in a full implementation, this would:
/// 1. Apply color transformation matrix to all UI colors
/// 2. Or use a post-processing shader for the entire screen
/// 3. Support different types of color blindness (deuteranopia, protanopia, tritanopia)
pub fn apply_color_blind_mode(
    mut egui_contexts: EguiContexts,
    accessibility_options: Res<AccessibilityOptions>,
) {
    if !accessibility_options.color_blind_mode {
        return;
    }

    if let Ok(_ctx) = egui_contexts.ctx_mut() {
        // For now, we just mark that color-blind mode is active
        // A proper implementation would apply color transformations
        // either to the style or via a custom painter
    }
}

/// System to setup the default UI theme resource.
pub fn setup_ui_theme(mut commands: Commands) {
    commands.insert_resource(UiTheme::default());
}
