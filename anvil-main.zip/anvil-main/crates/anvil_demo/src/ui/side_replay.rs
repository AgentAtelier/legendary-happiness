//! Side replay plugin for dual-viewport determinism proof.
//!
//! At minute 5:15 (DemoPhase::Aftermath), runs a secondary Runtime instance
//! from seed B at 60x speed and displays a diff panel.

use anvil_runtime::RuntimeCommand;
use anvil_sim::DeterministicRng;
use anvil_world::WorldAuthored;
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::app::{RuntimeResource, WorldResource};
use crate::demo::sequencer::{DemoPhase, DemoSequencer};
use crate::sim::TICK_DT_MICROS;
use anvil_runtime::Runtime;

/// Target tick for the replay to stop at.
pub const REPLAY_TARGET_TICK: u64 = 2700;

/// Seed B for the secondary runtime.
pub const SEED_B: u64 = 0x9F2E14BD8A3C0071;

/// Local extension trait for EguiContexts to safely access the context.
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Replay state resource.
#[derive(Resource)]
pub struct ReplayState {
    /// Whether the replay is enabled.
    pub enabled: bool,
    /// Seed B value.
    pub seed_b: u64,
    /// Secondary runtime instance.
    pub secondary_runtime: Option<Runtime>,
    /// Ticks elapsed in the secondary runtime.
    pub ticks_elapsed: u64,
    /// Whether the diff panel should be shown.
    pub show_diff: bool,
}

impl Default for ReplayState {
    fn default() -> Self {
        Self {
            enabled: false,
            seed_b: SEED_B,
            secondary_runtime: None,
            ticks_elapsed: 0,
            show_diff: false,
        }
    }
}

impl ReplayState {
    /// Initialize the secondary runtime with the given world.
    pub fn init_secondary(&mut self, world: WorldAuthored) {
        let mut secondary = Runtime::new(world);
        secondary.rng = DeterministicRng::new(self.seed_b);
        self.secondary_runtime = Some(secondary);
        self.ticks_elapsed = 0;
        self.enabled = true;
    }

    /// Get the state hash of the secondary runtime.
    pub fn secondary_state_hash(&self) -> Option<[u8; 32]> {
        self.secondary_runtime.as_ref().map(|r| r.state_hash())
    }
}

/// Setup the replay panel.
pub fn setup_replay(mut commands: Commands) {
    commands.insert_resource(ReplayState::default());
}

/// Update the replay when in Aftermath phase.
pub fn update_replay(
    mut replay_state: ResMut<ReplayState>,
    demo_sequencer: Res<DemoSequencer>,
    world_resource: Res<WorldResource>,
) {
    // Check if we just entered Aftermath phase
    if demo_sequencer.phase == DemoPhase::Aftermath && !replay_state.enabled {
        replay_state.init_secondary(world_resource.world.clone());
    }

    // If replay is enabled, advance the secondary runtime
    if replay_state.enabled && replay_state.secondary_runtime.is_some() {
        #[allow(clippy::unwrap_used)]
        let mut secondary = replay_state.secondary_runtime.take().unwrap();

        // Run 60 ticks per frame (60x speed)
        let ticks_to_run = 60;
        for _ in 0..ticks_to_run {
            if replay_state.ticks_elapsed >= REPLAY_TARGET_TICK {
                break;
            }

            let _ = secondary.apply(&RuntimeCommand::Tick { dt_micros: TICK_DT_MICROS });
            replay_state.ticks_elapsed += 1;
        }

        // If we've reached or exceeded the target, mark as complete
        if replay_state.ticks_elapsed >= REPLAY_TARGET_TICK {
            replay_state.show_diff = true;
        }

        replay_state.secondary_runtime = Some(secondary);
    }
}

/// Render the diff panel showing comparison between seed A and seed B.
pub fn render_diff_panel(
    mut egui_contexts: EguiContexts,
    replay_state: Res<ReplayState>,
    runtime_resource: Res<RuntimeResource>,
) {
    if !replay_state.show_diff {
        return;
    }

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    let primary_hash = runtime_resource.runtime.state_hash();
    let secondary_hash = replay_state.secondary_state_hash();

    egui::Window::new("Determinism Proof - Seed A vs Seed B")
        .default_pos(egui::Pos2::new(100.0, 100.0))
        .default_size(egui::Vec2::new(600.0, 400.0))
        .show(ctx, |ui| {
            ui.heading("Dual-Viewport Determinism Proof");
            ui.separator();

            ui.label("Same rules. Same people. Different world.");
            ui.add_space(10.0);

            // Diff table
            egui::Grid::new("diff_grid")
                .num_columns(2)
                .spacing([40.0, 20.0])
                .striped(true)
                .show(ui, |ui| {
                    // Header
                    ui.label("Seed A");
                    ui.label("Seed B");
                    ui.end_row();

                    // Seeds (placeholder for primary seed)
                    ui.label("Seed: (primary)");
                    ui.label(format!("Seed: 0x{:016X}", replay_state.seed_b));
                    ui.end_row();

                    // Granary intact (placeholder values matching DEMO_VISION.md)
                    ui.label("Granary intact: YES");
                    ui.label("Granary intact: YES");
                    ui.end_row();

                    // Dak evacuated (placeholder values matching DEMO_VISION.md)
                    ui.label("Dak evacuated: YES, returned");
                    ui.label("Dak evacuated: NO");
                    ui.end_row();

                    // Tibor unlocked joint_cutting (placeholder values matching DEMO_VISION.md)
                    ui.label("Tibor unlocked joint_cutting: NO (2/4)");
                    ui.label("Tibor unlocked joint_cutting: YES (4/4)");
                    ui.end_row();

                    // State hashes
                    if let Some(hash_b) = secondary_hash {
                        ui.label(format!("Tick {} state hash: 0x{:02X}{:02X}{:02X}...", REPLAY_TARGET_TICK, primary_hash[0], primary_hash[1], primary_hash[2]));
                        ui.label(format!("Tick {} state hash: 0x{:02X}{:02X}{:02X}...", REPLAY_TARGET_TICK, hash_b[0], hash_b[1], hash_b[2]));
                    }
                    ui.end_row();
                });

            ui.add_space(20.0);

            // Rerun Seed A button
            if ui.button("Rerun Seed A").clicked() {
                // Placeholder for rerun functionality
            }
        });
}

/// Render a simple visualization of the secondary runtime state in an egui panel.
pub fn render_replay_panel(
    mut egui_contexts: EguiContexts,
    replay_state: Res<ReplayState>,
) {
    if !replay_state.enabled || replay_state.secondary_runtime.is_none() {
        return;
    }

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    let Some(secondary) = replay_state.secondary_runtime.as_ref() else {
        return; // Runtime was consumed by tick system; diff not ready yet
    };

    egui::SidePanel::right("replay_panel")
        .default_width(300.0)
        .show(ctx, |ui| {
            ui.heading("Seed B Replay (60x speed)");
            ui.separator();

            ui.label(format!("Seed: 0x{:016X}", replay_state.seed_b));
            ui.label(format!("Ticks elapsed: {}", replay_state.ticks_elapsed));
            ui.label(format!("Target: {}", REPLAY_TARGET_TICK));
            ui.add_space(10.0);

            // Show NPC count
            if let Some(npc_system) = secondary.npc_system() {
                ui.label(format!("NPCs: {}", npc_system.persons.len()));
            }

            // Show catastrophe state
            if let Some(catastrophe_system) = secondary.catastrophe_system() {
                ui.label(format!("Active catastrophes: {}", catastrophe_system.active_events.len()));
            }

            // Show state hash
            let hash = secondary.state_hash();
            ui.label(format!("State hash: 0x{:02X}{:02X}{:02X}...", hash[0], hash[1], hash[2]));

            // Progress indicator
            let progress = if REPLAY_TARGET_TICK > 0 {
                (replay_state.ticks_elapsed as f32 / REPLAY_TARGET_TICK as f32) * 100.0
            } else {
                0.0
            };
            ui.add(
                egui::ProgressBar::new(progress / 100.0)
                    .text(format!("{:.1}% complete", progress)),
            );
        });
}

/// Main plugin for the side replay feature.
pub struct SideReplayPlugin;

impl Plugin for SideReplayPlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<ReplayState>()
            .add_systems(Startup, setup_replay)
            .add_systems(
                Update,
                (
                    update_replay.run_if(resource_exists::<crate::app::WorldResource>),
                    render_replay_panel,
                    render_diff_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                ),
            );
    }
}
