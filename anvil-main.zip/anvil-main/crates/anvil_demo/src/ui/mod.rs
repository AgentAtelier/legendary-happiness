//! UI systems for anvil_demo.
//!
//! This module contains all UI-related systems and resources for the demo,
//! including the toggle panel, inspector, event log, and other diagnostic panels.

pub mod config;
pub mod controls;
pub mod demo_hud;
pub mod inspector_panel;
pub mod oracle;
pub mod panel;
pub mod panels;
pub mod resources;
pub mod side_replay;
pub mod theme;
pub mod transitions;
pub mod window_title;

pub use demo_hud::{DemoHudPlugin};
pub use inspector_panel::{InspectorPanelPlugin};
pub use oracle::{OraclePlugin, setup_oracle};
pub use panels::PanelsPlugin;
pub use side_replay::SideReplayPlugin;
pub use theme::{apply_color_blind_mode, apply_ui_scale, apply_ui_theme, setup_ui_theme, UiTheme};
pub use window_title::update_window_title;
