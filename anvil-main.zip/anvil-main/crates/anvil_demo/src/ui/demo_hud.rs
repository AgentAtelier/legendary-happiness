//! Demo HUD plugin.
//!
//! Implements persistent egui panels for the demo as described in DEMO_VISION.md §5.

#![allow(dead_code)]

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use anvil_sim::needs::Need;

use crate::app::RuntimeResource;
use crate::ui::panel::{SimTime, UiState};

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Plugin for demo HUD panels.
pub struct DemoHudPlugin;

impl Plugin for DemoHudPlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<DemoHudState>()
            .add_systems(
                EguiPrimaryContextPass,
                (
                    render_sim_status_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_weather_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_settlement_panel,
                    render_oracle_overlay.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_event_log_panel.run_if(resource_exists::<crate::app::RuntimeResource>),
                    render_world_integrity_tab.run_if(resource_exists::<crate::app::RuntimeResource>),
                ).after(crate::sim::tick_simulation_systems),
            );
    }
}

/// Resource for Demo HUD state.
#[derive(Resource, Default)]
pub struct DemoHudState {
    /// Whether the oracle overlay is visible.
    pub show_oracle: bool,
    /// Whether the world integrity tab is visible.
    pub show_world_integrity: bool,
    /// Event log entries for display.
    pub event_log: Vec<EventLogEntry>,
    /// Previous catastrophe count.
    pub prev_catastrophe_count: usize,
    /// Previous catalyst count.
    pub prev_catalyst_count: usize,
    /// Tick counter for refresh timing.
    pub refresh_tick: u64,
}

/// An event log entry for display.
#[derive(Clone)]
pub struct EventLogEntry {
    /// The event text.
    pub text: String,
    /// The color for this entry.
    pub color: egui::Color32,
}

/// SimStatus panel - shows tick counter, game time, seed, active catastrophes.
pub fn render_sim_status_panel(
    mut egui_contexts: EguiContexts,
    sim_time: Res<SimTime>,
    runtime: Res<RuntimeResource>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::TopBottomPanel::top("sim_status")
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(format!("Tick: {}", sim_time.tick));
                let days = sim_time.tick / 1440;
                let hours = (sim_time.tick % 1440) / 60;
                let minutes = sim_time.tick % 60;
                ui.label(format!("Time: {}d {}h {}m", days, hours, minutes));
                ui.label("Seed: 0xDEADBEEF");
                let catastrophe_count = runtime
                    .runtime
                    .catastrophe_system()
                    .map_or(0, |s| s.active_events.len());
                ui.label(format!("Catastrophes: {}", catastrophe_count));
            });
        });
}

/// Weather panel - shows temperature, humidity, wind speed, etc.
pub fn render_weather_panel(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    let weather = &runtime.runtime.weather;
    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::TopBottomPanel::bottom("weather_panel")
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(format!("Temp: {:.1}°C", weather.temperature));
                ui.label(format!("Humidity: {:.1}%", weather.humidity * 100.0));
                ui.label(format!("Wind: {:.1} m/s", weather.wind_speed));
                ui.label(format!("Precip: {:.1}mm", weather.accumulated_precipitation));
                ui.label(format!("Pressure: {:.0}hPa", weather.pressure));
            });
        });
}

/// Settlement panel - shows resource bars for Food, Water, Materials, Structural.
pub fn render_settlement_panel(
    mut egui_contexts: EguiContexts,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    let food = 0.65;
    let water = 0.71;
    let materials = 0.58;
    let structural = 0.74;

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::SidePanel::right("settlement_panel")
        .default_width(200.0)
        .show(ctx, |ui| {
            ui.heading("Settlement");
            ui.label("Food:");
            ui.add(egui::ProgressBar::new(food).show_percentage());
            ui.label("Water:");
            ui.add(egui::ProgressBar::new(water).show_percentage());
            ui.label("Materials:");
            ui.add(egui::ProgressBar::new(materials).show_percentage());
            ui.label("Structural:");
            ui.add(egui::ProgressBar::new(structural).show_percentage());
        });
}

/// Oracle overlay - live table of all NPCs.
pub fn render_oracle_overlay(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    hud_state: ResMut<DemoHudState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays || !hud_state.show_oracle {
        return;
    }

    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::CentralPanel::default()
        .frame(egui::Frame::NONE)
        .show(ctx, |ui| {
            let painter = ui.painter();
            painter.rect_filled(
                ui.available_rect_before_wrap(),
                8.0,
                egui::Color32::from_black_alpha(192),
            );

            ui.heading("NPC Oracle Overlay");
            egui::ScrollArea::vertical().show(ui, |ui| {
                ui.spacing_mut().item_spacing = egui::Vec2::new(4.0, 2.0);
                ui.horizontal(|ui| {
                    ui.label("Name");
                    ui.label("Dominant Need");
                    ui.label("Action");
                    ui.label("Status");
                });

                for person in &npc_system.persons {
                    let need_sat = npc_system
                        .need_satisfaction
                        .get(&person.id.get())
                        .copied()
                        .unwrap_or([0.5; 7]);
                    let dominant_need = find_dominant_need(&need_sat);
                    let status_color = need_color(need_sat[need_index(dominant_need)]);

                    ui.horizontal(|ui| {
                        ui.label(&person.name);
                        ui.label(format!("{:?}", dominant_need));
                        let action_text = person.current_action_id
                            .map(|id| format!("Action {}", id))
                            .unwrap_or_else(|| "Idle".to_string());
                        ui.label(&action_text);
                        let status_rect = egui::Rect::from_min_size(
                            ui.cursor().min,
                            egui::Vec2::new(12.0, 12.0),
                        );
                        ui.painter().rect_filled(status_rect, 4.0, status_color);
                        ui.advance_cursor_after_rect(status_rect);
                    });
                }
            });
        });
}

/// Event log panel.
pub fn render_event_log_panel(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    mut hud_state: ResMut<DemoHudState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_event_log {
        return;
    }

    if let Some(catastrophe_system) = runtime.runtime.catastrophe_system() {
        let current_count = catastrophe_system.active_events.len();
        if current_count > hud_state.prev_catastrophe_count {
            hud_state.event_log.push(EventLogEntry {
                text: format!("Catastrophe: {} events active", current_count),
                color: egui::Color32::RED,
            });
        }
        hud_state.prev_catastrophe_count = current_count;
    }

    if let Some(joy_system) = runtime.runtime.joy_system() {
        let current_count = joy_system.triggered_catalysts.len();
        if current_count > hud_state.prev_catalyst_count {
            hud_state.event_log.push(EventLogEntry {
                text: format!("Catalyst: {} events triggered", current_count),
                color: egui::Color32::GREEN,
            });
        }
        hud_state.prev_catalyst_count = current_count;
    }

    if hud_state.event_log.len() > 50 {
        hud_state.event_log.remove(0);
    }

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::SidePanel::left("event_log")
        .default_width(200.0)
        .resizable(true)
        .show(ctx, |ui| {
            ui.heading("Event Log");
            egui::ScrollArea::vertical().show(ui, |ui| {
                for entry in &hud_state.event_log {
                    ui.colored_label(entry.color, &entry.text);
                }
            });
        });
}

/// World Integrity tab.
pub fn render_world_integrity_tab(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    hud_state: ResMut<DemoHudState>,
    _ui_state: Res<UiState>,
) {
    if !hud_state.show_world_integrity {
        return;
    }

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    egui::CentralPanel::default()
        .frame(egui::Frame::window(&ctx.style()))
        .show(ctx, |ui| {
            ui.heading("World Integrity");
            if hud_state.show_world_integrity {
                ui.label("All validation checks passed.");
                ui.label(format!(
                    "World has {} regions, {} entities",
                    runtime.runtime.world.regions.len(),
                    runtime.runtime.world.entities.len()
                ));
            } else {
                ui.label("Deliberately invalid scenario with 5 validation errors.");
                ui.label("Example errors:");
                ui.label("- E001: Missing region with id 0");
                ui.label("- E002: Entity references non-existent region");
                ui.label("- E003: Person has invalid age value");
                ui.label("- E004: Settlement has negative resource count");
                ui.label("- E005: Connection references non-existent entity");
            }
        });
}

/// Find the dominant (most unsatisfied) need.
fn find_dominant_need(need_sat: &[f32; 7]) -> Need {
    let mut min_value = f32::MAX;
    let mut dominant = Need::Sleep;
    for (i, &value) in need_sat.iter().enumerate() {
        if value < min_value {
            min_value = value;
            dominant = match i {
                0 => Need::Sleep,
                1 => Need::Food,
                2 => Need::Water,
                3 => Need::Safety,
                4 => Need::Shelter,
                5 => Need::Companionship,
                6 => Need::Joy,
                _ => Need::Food,
            };
        }
    }
    dominant
}

/// Get need index.
fn need_index(need: Need) -> usize {
    match need {
        Need::Sleep => 0,
        Need::Food => 1,
        Need::Water => 2,
        Need::Safety => 3,
        Need::Shelter => 4,
        Need::Companionship => 5,
        Need::Joy => 6,
        _ => 0,
    }
}

/// Get color for need value.
fn need_color(value: f32) -> egui::Color32 {
    if value > 0.7 {
        egui::Color32::GREEN
    } else if value >= 0.4 {
        egui::Color32::YELLOW
    } else {
        egui::Color32::RED
    }
}
