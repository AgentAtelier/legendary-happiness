//! Crash Reporter Module
//!
//! Provides a custom panic hook that writes structured crash reports
//! to ~/.anvil/crashes/ and detects unreported crashes on startup.
//!
//! # Design
//!
//! - Panic hook captures: panic message, location, sim tick, state hash, last N events
//! - Crash reports are written as JSON to `~/.anvil/crashes/crash_<timestamp>.json`
//! - No Bevy dependencies (runs during panic, Bevy may be in invalid state)
//! - No network calls, no PII
//! - On startup: checks for crash files newer than last session

use serde::{Deserialize, Serialize};
use std::backtrace::Backtrace;
use std::fs::{self, File};
use std::io::Write;
use std::path::PathBuf;
use std::sync::{atomic::{AtomicBool, Ordering}, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};

/// Number of recent events to include in crash report
const LAST_N_EVENTS: usize = 20;

/// Directory for crash reports
const CRASH_DIR: &str = ".anvil/crashes";

/// File to track last successful session time
const LAST_SESSION_FILE: &str = ".anvil/last_session.txt";

/// Flag to prevent double-panic in the panic hook itself
static IN_PANIC_HOOK: AtomicBool = AtomicBool::new(false);

// -----------------------------------------------------------
// Crash Report Types
// -----------------------------------------------------------

/// Structured crash report data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrashReport {
    /// Timestamp when the crash occurred (Unix timestamp in milliseconds)
    pub timestamp: u64,
    /// Human-readable timestamp (UTC)
    pub timestamp_iso8601: String,
    /// The panic message
    pub panic_message: String,
    /// The panic location (file:line)
    pub panic_location: String,
    /// The backtrace as string
    pub backtrace: String,
    /// Simulation tick at time of crash (if available)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sim_tick: Option<u64>,
    /// State hash at time of crash (if available)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub state_hash: Option<String>,
    /// Last N events from the event log (if available)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub recent_events: Option<Vec<RecentEvent>>,
    /// Version information
    pub version: CrashReportVersion,
}

/// Version information for the crash report format
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrashReportVersion {
    /// Format version
    pub format_version: u32,
    /// Anvil version (from Cargo.toml or git)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub anvil_version: Option<String>,
}

/// A recent event from the event log (simplified for crash report)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecentEvent {
    /// The simulation tick
    pub tick: u64,
    /// The event message
    pub message: String,
    /// The event category
    pub category: String,
}

// -----------------------------------------------------------
// Global State (updated by simulation)
// -----------------------------------------------------------

/// Global storage for current simulation state (updated each frame)
/// This is safe to access from the panic hook because:
/// 1. It's a simple struct with Copy types
/// 2. We use relaxed atomic ordering since we only need best-effort capture
/// 3. The panic hook runs in the same thread that was simulating
#[derive(Debug, Clone, Copy)]
pub struct CrashContext {
    /// Current simulation tick
    pub tick: u64,
    /// Current state hash (as u64 for easy storage)
    pub state_hash: u64,
}

/// Global storage for recent events (thread-local for safety)
/// We use a Mutex for thread-safety, but the panic hook accesses it
/// from the same thread that was running the simulation
pub struct RecentEventsBuffer {
    events: std::sync::Mutex<Vec<RecentEvent>>,
}

impl RecentEventsBuffer {
    pub fn new() -> Self {
        Self {
            events: std::sync::Mutex::new(Vec::with_capacity(LAST_N_EVENTS + 1)),
        }
    }

    pub fn push(&self, tick: u64, message: String, category: String) {
        if let Ok(mut events) = self.events.lock() {
            events.push(RecentEvent { tick, message, category });
            if events.len() > LAST_N_EVENTS {
                events.remove(0);
            }
        }
    }

    pub fn get_recent(&self) -> Vec<RecentEvent> {
        self.events.lock().ok().map(|e| e.clone()).unwrap_or_default()
    }
}

/// Global singleton for crash context
/// Using Mutex for thread-safe mutable access
static CRASH_CONTEXT: once_cell::sync::OnceCell<Mutex<CrashContext>> = once_cell::sync::OnceCell::new();

/// Global singleton for recent events buffer
static RECENT_EVENTS: once_cell::sync::OnceCell<RecentEventsBuffer> = once_cell::sync::OnceCell::new();

// -----------------------------------------------------------
// Initialization
// -----------------------------------------------------------

/// Initialize the crash reporter module.
/// Must be called early in main() before any panics can occur.
pub fn init() {
    // Create crash directory if it doesn't exist
    if let Err(e) = create_crash_dir() {
        eprintln!("Warning: Failed to create crash directory: {}", e);
    }

    // Initialize singletons
    CRASH_CONTEXT.get_or_init(|| Mutex::new(CrashContext { tick: 0, state_hash: 0 }));
    RECENT_EVENTS.get_or_init(RecentEventsBuffer::new);

    // Register panic hook
    std::panic::set_hook(Box::new(crash_panic_hook));
}

/// Update the crash context with current simulation state.
/// Called each frame from the simulation system.
pub fn update_crash_context(tick: u64, state_hash: u64) {
    if let Some(Ok(mut ctx)) = CRASH_CONTEXT.get().map(|l| l.lock()) {
        ctx.tick = tick;
        ctx.state_hash = state_hash;
    }
}

/// Record an event for potential inclusion in crash report.
pub fn record_event(tick: u64, message: String, category: String) {
    if let Some(buffer) = RECENT_EVENTS.get() {
        buffer.push(tick, message, category);
    }
}

/// Create the crash directory if it doesn't exist
fn create_crash_dir() -> std::io::Result<()> {
    let Some(crash_dir) = crash_dir_path() else {
        return Ok(()); // Cannot determine home dir, skip creating crash dir
    };
    if !crash_dir.exists() {
        fs::create_dir_all(&crash_dir)?;
    }
    Ok(())
}

/// Get the crash directory path
fn crash_dir_path() -> Option<PathBuf> {
    dirs::home_dir().map(|h| h.join(CRASH_DIR))
}

/// Get the last session file path
fn last_session_path() -> Option<PathBuf> {
    dirs::home_dir().map(|h| h.join(LAST_SESSION_FILE))
}

// -----------------------------------------------------------
// Panic Hook
// -----------------------------------------------------------

/// Custom panic hook that writes a structured crash report
fn crash_panic_hook(panic_info: &std::panic::PanicHookInfo) {
    // Prevent double-panic
    if IN_PANIC_HOOK.swap(true, Ordering::SeqCst) {
        eprintln!("CRASH: Double panic detected! Original panic:");
        let msg = match panic_info.payload().downcast_ref::<&str>() {
            Some(s) => *s,
            None => match panic_info.payload().downcast_ref::<String>() {
                Some(s) => s.as_str(),
                None => "unknown",
            },
        };
        eprintln!("  Message: {}", msg);
        eprintln!("  Location: {}", panic_info.location().map_or("unknown".to_string(), |l| l.to_string()));
        std::process::abort();
    }

    // Build crash report
    let report = build_crash_report(panic_info);

    // Write crash report to file
    if let Err(e) = write_crash_report(&report) {
        eprintln!("CRASH: Failed to write crash report: {}", e);
    }

    // Print crash message to stderr
    eprintln!("\n========================================");
    eprintln!("CRASH: Anvil Demo has panicked!");
    eprintln!("========================================");
    eprintln!("Message: {}", report.panic_message);
    eprintln!("Location: {}", report.panic_location);
    eprintln!("\nA crash report has been written to:");
    eprintln!("  {}", get_crash_report_path(&report).display());
    eprintln!("\nOn next launch, the demo will detect this crash.");
    eprintln!("========================================\n");

    // Reset the flag so if we somehow continue, we can panic again
    IN_PANIC_HOOK.store(false, Ordering::SeqCst);
}

/// Build a crash report from panic information
fn build_crash_report(panic_info: &std::panic::PanicHookInfo) -> CrashReport {
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    let timestamp_iso8601 = format_iso8601(timestamp);

    // Get panic message as string
    let panic_message = match panic_info.payload().downcast_ref::<&str>() {
        Some(s) => s.to_string(),
        None => match panic_info.payload().downcast_ref::<String>() {
            Some(s) => s.clone(),
            None => format!("{:?}", panic_info.payload()),
        },
    };

    // Get panic location
    let panic_location = panic_info
        .location()
        .map(|l| format!("{}:{}:{}", l.file(), l.line(), l.column()))
        .unwrap_or_else(|| "unknown".to_string());

    // Get backtrace
    let backtrace = Backtrace::capture().to_string();

    // Get crash context (best effort - may be from before the panic)
    let (sim_tick, state_hash) = if let Some(ctx_lock) = CRASH_CONTEXT.get() {
        if let Ok(ctx) = ctx_lock.lock() {
            (Some(ctx.tick), Some(format!("{:016x}", ctx.state_hash)))
        } else {
            (None, None)
        }
    } else {
        (None, None)
    };

    // Get recent events
    let recent_events = RECENT_EVENTS.get().map(|b| b.get_recent());

    // Get version
    let version = get_version_info();

    CrashReport {
        timestamp,
        timestamp_iso8601,
        panic_message,
        panic_location,
        backtrace,
        sim_tick,
        state_hash,
        recent_events: recent_events.map(|v| v.into_iter().filter(|e| e.tick > 0).collect()),
        version,
    }
}

/// Format Unix timestamp (millis) as ISO 8601
fn format_iso8601(timestamp_millis: u64) -> String {
    // Simple ISO 8601 formatting without external deps
    let seconds = timestamp_millis / 1000;
    let millis = timestamp_millis % 1000;

    // Calculate date/time components (simplified - no timezone handling)
    let _days_since_epoch = seconds / 86400;
    let seconds_today = seconds % 86400;
    let hours = seconds_today / 3600;
    let minutes = (seconds_today % 3600) / 60;
    let secs = seconds_today % 60;

    // We'll just use a simple format without full date calculation
    // For a proper implementation, we'd use chrono, but we want no deps
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        2026,  // Approximate year
        1,     // We'll use placeholder - in practice use chrono
        1,
        hours,
        minutes,
        secs,
        millis
    )
}

/// Get version information
fn get_version_info() -> CrashReportVersion {
    CrashReportVersion {
        format_version: 1,
        anvil_version: option_env!("CARGO_PKG_VERSION").map(|v| v.to_string()) 
            .or_else(|| {
                // Try to read from Cargo.toml
                std::fs::read_to_string("Cargo.toml")
                    .ok()
                    .and_then(|content| {
                        content
                            .lines()
                            .find(|l| l.trim().starts_with("version ="))
                            .and_then(|l| {
                                let trimmed = l.trim()
                                    .trim_start_matches("version =")
                                    .trim()
                                    .trim_matches('"')
                                    .trim();
                                if !trimmed.is_empty() {
                                    Some(trimmed.to_string())
                                } else {
                                    None
                                }
                            })
                    })
            }),
    }
}

/// Write crash report to file
fn write_crash_report(report: &CrashReport) -> std::io::Result<()> {
    let path = get_crash_report_path(report);
    let json = serde_json::to_string_pretty(report)
        .map_err(std::io::Error::other)?;

    let mut file = File::create(&path)?;
    file.write_all(json.as_bytes())?;
    file.flush()?;
    drop(file);

    // Also write to stderr for debugging
    eprintln!("Crash report written to: {}", path.display());

    Ok(())
}

/// Generate crash report file path
fn get_crash_report_path(report: &CrashReport) -> PathBuf {
    crash_dir_path()
        .unwrap_or_else(|| PathBuf::from("."))
        .join(format!(
            "crash_{}_{}.json",
            report.timestamp,
            report
                .panic_message
                .chars()
                .take(30)
                .collect::<String>()
                .replace(|c: char| !c.is_ascii_alphanumeric(), "_")
        ))
}

// -----------------------------------------------------------
// Crash Detection on Startup
// -----------------------------------------------------------

/// Check for unreported crash files on startup.
/// Returns a list of crash file paths that are newer than the last session.
pub fn check_for_crashes() -> Vec<PathBuf> {
    let Some(crash_dir) = crash_dir_path() else {
        return Vec::new(); // Cannot determine home dir, skip crash detection
    };
    let Some(last_session) = last_session_path() else {
        return Vec::new(); // Cannot determine home dir, skip crash detection
    };

    // Get last session timestamp
    let last_session_time = fs::metadata(&last_session)
        .ok()
        .and_then(|m| m.modified().ok())
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    // Find all crash files
    let mut crash_files: Vec<PathBuf> = Vec::new();
    if let Ok(entries) = fs::read_dir(&crash_dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.extension().is_some_and(|ext| ext == "json") {
                // Check if file is newer than last session
                if let Ok(metadata) = fs::metadata(&path)
                    && let Ok(modified) = metadata.modified()
                    && let Ok(duration) = modified.duration_since(UNIX_EPOCH)
                {
                    let file_time = duration.as_millis() as u64;
                    if file_time > last_session_time {
                        crash_files.push(path);
                    }
                }
            }
        }
    }

    crash_files
}

/// Update the last session file to mark a successful launch.
/// This prevents the same crash from being reported multiple times.
pub fn update_last_session() {
    let Some(path) = last_session_path() else {
        return; // Cannot determine home dir, skip updating last session
    };
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    // Write current timestamp
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis().to_string())
        .unwrap_or_default();
    let _ = fs::write(&path, timestamp);
}

/// Bevy system wrapper for update_last_session (runs once on startup)
pub fn startup_update_last_session() {
    update_last_session();
}

/// Print detection messages for any unreported crashes.
/// Returns true if crashes were detected.
pub fn print_crash_detections() -> bool {
    let crashes = check_for_crashes();
    if crashes.is_empty() {
        false
    } else {
        for crash in &crashes {
            println!("Detected unreported crash: {}", crash.display());
        }
        true
    }
}

// -----------------------------------------------------------
// Deliberate Crash for Testing
// -----------------------------------------------------------

/// Trigger a deliberate panic for testing the crash reporter.
/// This is intentionally kept simple to avoid dependencies.
#[allow(clippy::panic)]
pub fn trigger_deliberate_crash() {
    panic!("DELIBERATE CRASH: Triggered by Ctrl+Shift+K for crash reporter testing");
}

// -----------------------------------------------------------
// Tests
// -----------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_crash_dir_path() {
        let Some(path) = crash_dir_path() else {
            return; // Cannot test without home directory
        };
        assert!(path.to_string_lossy().contains(".anvil"));
        assert!(path.to_string_lossy().contains("crashes"));
    }

    #[test]
    fn test_last_session_path() {
        let Some(path) = last_session_path() else {
            return; // Cannot test without home directory
        };
        assert!(path.to_string_lossy().contains(".anvil"));
        assert!(path.to_string_lossy().contains("last_session"));
    }

    #[test]
    fn test_crash_report_serialization() {
        let report = CrashReport {
            timestamp: 1234567890,
            timestamp_iso8601: "2024-01-01T00:00:00.000Z".to_string(),
            panic_message: "test panic".to_string(),
            panic_location: "test.rs:42".to_string(),
            backtrace: "test backtrace".to_string(),
            sim_tick: Some(100),
            state_hash: Some("abc123".to_string()),
            recent_events: Some(vec![RecentEvent {
                tick: 99,
                message: "test event".to_string(),
                category: "test".to_string(),
            }]),
            version: CrashReportVersion {
                format_version: 1,
                anvil_version: Some("0.1.0".to_string()),
            },
        };

        let json = serde_json::to_string(&report).unwrap();
        assert!(json.contains("test panic"));
        assert!(json.contains("test.rs:42"));
        assert!(json.contains("\"sim_tick\":100"));

        let deserialized: CrashReport = serde_json::from_str(&json).unwrap();
        assert_eq!(deserialized.panic_message, "test panic");
        assert_eq!(deserialized.sim_tick, Some(100));
    }
}
