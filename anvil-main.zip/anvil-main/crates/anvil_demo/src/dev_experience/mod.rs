//! Dev Experience module for developer tools.
//!
//! Provides config persistence, seed display, and graceful crash handling.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;

/// Resource for dev experience state.
#[derive(Resource, Default)]
pub struct DevExperienceState {
    /// Current seed value.
    pub seed: u64,
}

/// System that renders the dev experience panel.
pub fn render_dev_panel(
    mut egui_contexts: EguiContexts,
    dev_state: Res<DevExperienceState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_toggle_bar {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::Window::new("Dev Tools")
            .default_pos(egui::Pos2::new(500.0, 100.0))
            .show(ctx, |ui| {
                ui.heading("Dev Experience");
                ui.separator();
                ui.label(format!("Seed: {}", dev_state.seed));
                ui.label("RNG state: TODO");
                ui.separator();
                ui.label("Config: TODO - persistence not yet implemented");
            });
    }
}

pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

pub fn setup_dev_experience(mut commands: Commands) {
    commands.insert_resource(DevExperienceState { seed: 42 });
}
