//! Debris VFX system.
//!
//! Spawns rigid body debris when fire reaches the settlement.

#![allow(dead_code)]

use bevy::prelude::*;

use anvil_sim::catastrophe::event::CatastropheType;

use crate::app::RuntimeResource;

/// Marker component for debris particles.
#[derive(Component)]
pub struct DebrisParticle;

/// Component for debris lifetime tracking.
#[derive(Component)]
pub struct DebrisTimer {
    /// Time remaining before despawn (in seconds).
    pub remaining: f32,
}

/// Plugin for debris visual effects.
pub struct DebrisPlugin;

impl Plugin for DebrisPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, (
            spawn_debris.run_if(resource_exists::<crate::app::RuntimeResource>),
            update_debris_timers,
        ));
    }
}

/// Check if a position is within the ashveil_valley bounds.
/// For simplicity, we use a rough bounding box.
fn is_within_ashveil_valley(position: &::glam::Vec3) -> bool {
    // Ashveil valley is roughly centered at origin with some extent
    // These bounds are approximate based on the scenario
    position.x >= -150.0 && position.x <= 150.0
        && position.z >= -150.0 && position.z <= 150.0
        && position.y >= 0.0 && position.y <= 100.0
}

/// Spawn debris when fire reaches the settlement boundary.
pub fn spawn_debris(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    runtime: Res<RuntimeResource>,
) {
    let Some(catastrophe_system) = runtime.runtime.catastrophe_system() else {
        return;
    };

    // Check for wildfire events
    for event in &catastrophe_system.active_events {
        if event.catastrophe_type != CatastropheType::Wildfire {
            continue;
        }

        // Check each affected area
        for area in &event.affected_areas {
            // Check if this area is within the ashveil_valley bounds
            if is_within_ashveil_valley(&area.position) && area.intensity > 0.5 {
                // Spawn 3-5 debris pieces
                let debris_count = 3 + (area.intensity * 2.0) as i32;
                // Easterly wind direction
                let wind_direction = ::glam::Vec3::new(1.0, 0.0, 0.0);
                let wind_speed = 4.2; // From DEMO_VISION.md §3

                for i in 0..debris_count {
                    // Calculate spawn position near the boundary
                    let offset = ::glam::Vec3::new(
                        (i as f32 - debris_count as f32 / 2.0) * 2.0,
                        5.0 + (i as f32 * 0.5),
                        (i as f32 - debris_count as f32 / 2.0) * 1.5,
                    );
                    let spawn_pos = ::glam::Vec3::new(
                        area.position.x + offset.x,
                        area.position.y + offset.y,
                        area.position.z + offset.z,
                    );

                    // Calculate initial velocity based on wind
                    let velocity_scale = 1.0 + (i as f32 * 0.2);
                    let debris_velocity = wind_direction * wind_speed * velocity_scale
                        + ::glam::Vec3::new(0.0, 2.0, 0.0); // Some upward motion

                    // Spawn debris sphere
                    let radius = 0.15 + (i as f32 * 0.05);
                    let sphere = Mesh::from(Sphere::new(radius));
                    let mesh_handle = meshes.add(sphere);

                    let material = StandardMaterial {
                        base_color: Color::srgb(0.3, 0.15, 0.05),
                        emissive: LinearRgba::new(0.5, 0.25, 0.1, 1.0),
                        emissive_exposure_weight: 1.5,
                        ..default()
                    };
                    let material_handle = materials.add(material);

                    // Convert glam::Vec3 to bevy::prelude::Vec3 for transform
                    let bevy_pos = Vec3::new(spawn_pos.x, spawn_pos.y, spawn_pos.z);

                    commands.spawn((
                        Mesh3d(mesh_handle),
                        MeshMaterial3d(material_handle),
                        Transform::from_translation(bevy_pos),
                        DebrisParticle,
                        DebrisTimer { remaining: 8.0 },
                        // Store velocity in glam::Vec3 for internal use
                        DebrisVelocity { velocity: debris_velocity },
                    ));
                }
            }
        }
    }
}

/// Component for debris velocity (simplified physics).
#[derive(Component)]
pub struct DebrisVelocity {
    /// Current velocity vector (in glam::Vec3 for compatibility).
    pub velocity: ::glam::Vec3,
}

/// Update debris positions and timers.
/// Applies simple gravity and velocity simulation.
pub fn update_debris_timers(
    time: Res<Time>,
    mut commands: Commands,
    mut query: Query<(Entity, &mut Transform, &mut DebrisTimer, &DebrisVelocity)>,
) {
    let delta = time.delta_secs();
    let gravity = ::glam::Vec3::new(0.0, -9.8, 0.0);

    for (entity, mut transform, mut timer, velocity) in query.iter_mut() {
        timer.remaining -= delta;

        if timer.remaining <= 0.0 {
            commands.entity(entity).despawn();
            continue;
        }

        // Apply velocity and gravity using glam::Vec3
        let mut new_velocity = velocity.velocity + gravity * delta * 0.5;

        // Convert to bevy::prelude::Vec3 for transform
        let bevy_velocity = Vec3::new(new_velocity.x, new_velocity.y, new_velocity.z);
        transform.translation += bevy_velocity * delta;

        // Add some drag
        new_velocity *= 0.98;

        // Bounce off ground (y=0)
        if transform.translation.y < 0.0 {
            transform.translation.y = 0.0;
            new_velocity.y = -new_velocity.y * 0.5; // Bounce with energy loss
        }

        // Log collision as placeholder for audio
        if transform.translation.y < 0.1 && new_velocity.y < -0.1 {
            tracing::info!("Debris collision at {:?}", transform.translation);
        }
    }
}
