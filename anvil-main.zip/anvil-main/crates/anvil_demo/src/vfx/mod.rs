//! Visual feedback and effects module for the Visual Uplift Sprint.
//!
//! This module contains systems for visual feedback:
//! - Attention pulse: expanding torus ring every 4s on NPC with highest emotional axis sum
//! - CPU particle systems: spawned on CatastropheEvent/CatalystEvent
//! - Screen-edge indicators: project off-screen events to viewport edges

use bevy::pbr::StandardMaterial;
use bevy::prelude::*;
use std::collections::HashMap;
use std::hash::Hash;

use crate::npc::HumanoidVisual;

/// Component for attention pulse effect on NPCs.
/// Expands from radius 0.5 to 2.0 over 1.5s, alpha fades from 0.6 to 0.0.
#[derive(Component)]
pub struct AttentionPulse {
    /// Timer for pulse animation (0.0 to 1.5).
    pub timer: f32,
    /// Dominant emotional axis for color determination.
    #[allow(dead_code)]
    pub dominant_axis: EmotionalAxis,
}

/// Emotional axes for color mapping.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Hash)]
pub enum EmotionalAxis {
    /// Security/Threat axis.
    SecurityThreat,
    /// Belonging/Isolation axis.
    BelongingIsolation,
    /// Agency/Helplessness axis.
    AgencyHelplessness,
    /// Satiation/Desperation axis.
    SatiationDesperation,
}

impl EmotionalAxis {
    /// Get the color for this axis.
    pub fn color(&self) -> Color {
        match self {
            EmotionalAxis::SecurityThreat => Color::srgb(0.8, 0.2, 0.2),   // Red
            EmotionalAxis::BelongingIsolation => Color::srgb(0.2, 0.8, 0.2), // Green
            EmotionalAxis::AgencyHelplessness => Color::srgb(0.2, 0.2, 0.8), // Blue
            EmotionalAxis::SatiationDesperation => Color::srgb(0.8, 0.8, 0.2), // Yellow
        }
    }
}

/// Component for CPU particle systems.
#[derive(Component)]
#[allow(dead_code)]
pub struct CpuParticle {
    /// Particle velocity.
    pub velocity: Vec3,
    /// Particle lifetime.
    pub lifetime: f32,
    /// Particle max lifetime.
    pub max_lifetime: f32,
}

/// Component for screen-edge indicators.
#[derive(Component)]
#[allow(dead_code)]
pub struct ScreenEdgeIndicator {
    /// Distance label text.
    #[allow(dead_code)]
    pub label: String,
    /// Edge type (for color determination).
    #[allow(dead_code)]
    pub edge_type: String,
}

/// Resource for VFX state.
#[derive(Resource)]
pub struct VfxState {
    /// Whether attention pulses are enabled.
    pub show_attention_pulses: bool,
    /// Whether CPU particles are enabled.
    pub show_cpu_particles: bool,
    /// Whether screen edge indicators are enabled.
    #[allow(dead_code)]
    pub show_screen_edge_indicators: bool,
    /// Current simulation load level (0.0 to 1.0).
    pub simulation_load: f32,
    /// Timer for attention pulse spawning (counts up to 4.0).
    pub attention_pulse_timer: f32,
    /// Entity of the current attention pulse (only one at a time).
    pub current_attention_pulse: Option<Entity>,
    /// Pre-allocated torus mesh handle for attention pulses.
    pub attention_pulse_mesh: Option<Handle<Mesh>>,
    /// Pre-allocated material handles for each emotional axis.
    pub axis_materials: std::collections::HashMap<EmotionalAxis, Handle<StandardMaterial>>,
    /// Previous catastrophe event count for detecting new events.
    pub prev_catastrophe_count: usize,
    /// Previous catalyst event count for detecting new events.
    pub prev_catalyst_count: usize,
}

impl Default for VfxState {
    fn default() -> Self {
        Self {
            show_attention_pulses: true,
            show_cpu_particles: true,
            show_screen_edge_indicators: false,
            simulation_load: 0.0,
            attention_pulse_timer: 0.0,
            current_attention_pulse: None,
            attention_pulse_mesh: None,
            axis_materials: HashMap::new(),
            prev_catastrophe_count: 0,
            prev_catalyst_count: 0,
        }
    }
}

/// System to find the NPC with the highest absolute emotional axis sum
/// and spawn an attention pulse on them every 4 seconds.
/// 
/// Spec: Every 4s, find NPC with highest absolute emotional axis sum.
/// Spawn expanding torus ring (0.5 to 2.0 over 1.5s, alpha 0.6 to 0.0).
/// Colour by dominant axis. One at a time.
#[allow(clippy::collapsible_if)]
pub fn update_attention_pulses(
    time: Res<Time>,
    mut commands: Commands,
    mut vfx_state: ResMut<VfxState>,
    runtime: Res<crate::app::RuntimeResource>,
    npc_visuals: Query<(Entity, &Transform, &HumanoidVisual)>,
    existing_pulses: Query<Entity, With<AttentionPulse>>,
) {
    if !vfx_state.show_attention_pulses {
        return;
    }

    // Update timer
    vfx_state.attention_pulse_timer += time.delta_secs();

    // Despawn existing pulses
    for entity in existing_pulses.iter() {
        commands.entity(entity).despawn();
    }
    vfx_state.current_attention_pulse = None;

    // Access the NPC system through the runtime accessor
    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    // Spawn new pulse every 4 seconds
    if vfx_state.attention_pulse_timer >= 4.0 {
        vfx_state.attention_pulse_timer = 0.0;

        // Find NPC with highest absolute emotional axis sum
        let mut max_sum = 0.0;
        let mut best_person_id: Option<u64> = None;
        let mut best_entity: Option<Entity> = None;
        let mut best_dominant_axis = EmotionalAxis::SecurityThreat;

        for person in &npc_system.persons {
            let axes = &person.emotional_state.axes;
            let sum = axes.security_threat.abs()
                + axes.belonging_isolation.abs()
                + axes.agency_helplessness.abs()
                + axes.satiation_desperation.abs();

            if sum > max_sum {
                max_sum = sum;
                best_person_id = Some(person.id.get());
                // Determine dominant axis
                let mut dominant = EmotionalAxis::SecurityThreat;
                let mut max_abs = axes.security_threat.abs();

                if axes.belonging_isolation.abs() > max_abs {
                    max_abs = axes.belonging_isolation.abs();
                    dominant = EmotionalAxis::BelongingIsolation;
                }
                if axes.agency_helplessness.abs() > max_abs {
                    max_abs = axes.agency_helplessness.abs();
                    dominant = EmotionalAxis::AgencyHelplessness;
                }
                if axes.satiation_desperation.abs() > max_abs {
                    dominant = EmotionalAxis::SatiationDesperation;
                }
                best_dominant_axis = dominant;
            }
        }

        // Find the entity for this person
        if let Some(person_id) = best_person_id {
            for (entity, _, visual) in npc_visuals.iter() {
                if visual.person_id == person_id {
                    best_entity = Some(entity);
                    break;
                }
            }
        }

        // Spawn attention pulse on the best NPC
        if let Some(entity) = best_entity {
            if let Ok((_, npc_transform, _)) = npc_visuals.get(entity) {
                // Use pre-allocated mesh and material
                let Some(torus_handle) = vfx_state.attention_pulse_mesh.clone() else {
                    return;
                };
                let Some(material_handle) = vfx_state.axis_materials.get(&best_dominant_axis).cloned()
                else {
                    return;
                };

                let pulse_entity = commands
                    .spawn((
                        Mesh3d(torus_handle),
                        MeshMaterial3d(material_handle),
                        Transform::from_translation(npc_transform.translation + Vec3::new(0.0, 0.5, 0.0))
                            .with_rotation(Quat::from_rotation_x(std::f32::consts::PI / 2.0)),
                        AttentionPulse {
                            timer: 0.0,
                            dominant_axis: best_dominant_axis,
                        },
                    ))
                    .id();

                vfx_state.current_attention_pulse = Some(pulse_entity);
            }
        }
    }
}

/// System to update attention pulse animations.
/// Expands from radius 0.5 to 2.0 over 1.5s, alpha fades from 0.6 to 0.0.
pub fn update_attention_pulse_animations(
    time: Res<Time>,
    mut commands: Commands,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut query: Query<(Entity, &mut Transform, &MeshMaterial3d<StandardMaterial>, &AttentionPulse)>,
) {
    let delta = time.delta_secs();

    for (entity, mut transform, mesh_material, pulse) in query.iter_mut() {
        let mut pulse_timer = pulse.timer;
        pulse_timer += delta;

        // Animate for 1.5 seconds
        if pulse_timer >= 1.5 {
            commands.entity(entity).despawn();
            continue;
        }

        // Calculate progress (0.0 to 1.0)
        let t = pulse_timer / 1.5;

        // Scale from 0.5 to 2.0
        let scale = 0.5 + (2.0 - 0.5) * t;
        transform.scale = Vec3::splat(scale);

        // Alpha from 0.6 to 0.0
        let alpha = 0.6 * (1.0 - t);
        // Update material alpha - need to clone and modify
        if let Some(mat) = materials.get_mut(&mesh_material.0) {
            let srgba = mat.base_color.to_srgba();
            mat.base_color = Color::srgba(srgba.red, srgba.green, srgba.blue, alpha);
        }
    }
}

/// System to spawn CPU particles based on simulation events.
/// Red/orange for catastrophes, gold/white for catalysts.
#[allow(dead_code)]
pub fn spawn_cpu_particles(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    vfx_state: &Res<VfxState>,
    spawn_position: Vec3,
    is_catastrophe: bool,
) {
    if !vfx_state.show_cpu_particles {
        return;
    }

    let particle_count = 15 + (vfx_state.simulation_load * 5.0) as i32;
    let (color_base, emissive_base) = if is_catastrophe {
        (Color::srgb(0.8, 0.3, 0.1), LinearRgba::new(0.8, 0.3, 0.1, 1.0))
    } else {
        (Color::srgb(0.9, 0.8, 0.3), LinearRgba::new(0.9, 0.8, 0.3, 1.0))
    };

    for i in 0..particle_count {
        // Random direction
        let angle = i as f32 * std::f32::consts::TAU / particle_count as f32
            + vfx_state.simulation_load * 100.0 * i as f32;
        let direction = Vec3::new(angle.cos(), 0.0, angle.sin());
        let velocity = direction * (0.5 + vfx_state.simulation_load * 0.5);

        // Create a small sphere for the particle
        let sphere = Mesh::from(Sphere::new(0.05));
        let sphere_handle = meshes.add(sphere);

        let particle_material = StandardMaterial {
            base_color: color_base,
            emissive: emissive_base,
            emissive_exposure_weight: 1.5,
            ..default()
        };
        let material_handle = materials.add(particle_material);

        commands.spawn((
            Mesh3d(sphere_handle),
            MeshMaterial3d(material_handle),
            Transform::from_translation(spawn_position),
            CpuParticle {
                velocity,
                lifetime: 0.0,
                max_lifetime: 1.0 + vfx_state.simulation_load * 2.0,
            },
        ));
    }
}

/// System to update CPU particle positions and lifetimes.
pub fn update_cpu_particles(
    time: Res<Time>,
    mut commands: Commands,
    mut query: Query<(Entity, &mut Transform, &mut CpuParticle)>,
) {
    let delta = time.delta_secs();

    for (entity, mut transform, mut particle) in query.iter_mut() {
        particle.lifetime += delta;

        if particle.lifetime >= particle.max_lifetime {
            commands.entity(entity).despawn();
            continue;
        }

        // Move particle
        transform.translation += particle.velocity * delta;

        // Add gravity effect
        transform.translation.y -= 9.8 * delta * 0.1;
    }
}

/// System to spawn particles for new catastrophe and catalyst events (Phase 3b).
/// Spawns 15-20 small cubes at epicentre with random velocity + fake gravity.
/// Red/orange for catastrophes, gold/white for catalysts.
pub fn spawn_event_particles(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut vfx_state: ResMut<VfxState>,
    runtime: Res<crate::app::RuntimeResource>,
) {
    if !vfx_state.show_cpu_particles {
        return;
    }

    // Access the catastrophe and joy systems through the runtime accessors
    let catastrophe_system = runtime.runtime.catastrophe_system();
    let joy_system = runtime.runtime.joy_system();

    // Check for new catastrophe events
    let current_catastrophe_count = catastrophe_system.map_or(0, |s| s.active_events.len());
    if current_catastrophe_count > vfx_state.prev_catastrophe_count {
        // New catastrophe event(s) detected - spawn particles for the newest one
        if let Some(newest_event) = catastrophe_system.and_then(|s| s.active_events.last()) {
            let epicentre = newest_event.epicentre.position;
            spawn_cpu_particles_helper(
                &mut commands,
                &mut meshes,
                &mut materials,
                &vfx_state,
                epicentre,
                true,
            );
        }
        vfx_state.prev_catastrophe_count = current_catastrophe_count;
    }

    // Check for new catalyst events
    let current_catalyst_count = joy_system.map_or(0, |s| s.triggered_catalysts.len());
    if current_catalyst_count > vfx_state.prev_catalyst_count {
        // New catalyst event(s) detected - spawn particles for the newest one
        // Use a position slightly offset from origin for catalyst events
        let epicentre = ::glam::Vec3::new(0.0, 1.0, 0.0);
        spawn_cpu_particles_helper(
            &mut commands,
            &mut meshes,
            &mut materials,
            &vfx_state,
            epicentre,
            false,
        );
        vfx_state.prev_catalyst_count = current_catalyst_count;
    }
}

/// Helper function to spawn CPU particles at a position.
fn spawn_cpu_particles_helper(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    vfx_state: &VfxState,
    spawn_position: ::glam::Vec3,
    is_catastrophe: bool,
) {
    // Convert glam::Vec3 to bevy::prelude::Vec3
    let spawn_position_bevy = Vec3::new(spawn_position.x, spawn_position.y, spawn_position.z);
    let particle_count = 15 + (vfx_state.simulation_load * 5.0) as i32;
    let (color_base, emissive_base) = if is_catastrophe {
        (Color::srgb(0.8, 0.3, 0.1), LinearRgba::new(0.8, 0.3, 0.1, 1.0))
    } else {
        (Color::srgb(0.9, 0.8, 0.3), LinearRgba::new(0.9, 0.8, 0.3, 1.0))
    };

    for i in 0..particle_count {
        // Random direction using deterministic hash based on seed
        let seed = i as u64 * 997 + spawn_position_bevy.x as u64 * 10007 + spawn_position_bevy.z as u64 * 10009;
        let hash = ((seed.wrapping_mul(6364136223846793005).wrapping_add(1)) ^ seed) as f32 / u64::MAX as f32;
        
        let angle = hash * std::f32::consts::TAU;
        let direction = Vec3::new(angle.cos(), 0.0, angle.sin());
        let velocity = direction * (0.5 + vfx_state.simulation_load * 0.5);

        // Create a small cube for the particle
        let cube = Mesh::from(Cuboid::new(0.03, 0.03, 0.03));
        let cube_handle = meshes.add(cube);

        let particle_material = StandardMaterial {
            base_color: color_base,
            emissive: emissive_base,
            emissive_exposure_weight: 1.5,
            ..default()
        };
        let material_handle = materials.add(particle_material);

        commands.spawn((
            Mesh3d(cube_handle),
            MeshMaterial3d(material_handle),
            Transform::from_translation(spawn_position_bevy),
            CpuParticle {
                velocity,
                lifetime: 0.0,
                max_lifetime: 1.5 + vfx_state.simulation_load * 0.5,
            },
        ));
    }
}

/// Setup system for VFX state.
pub fn setup_vfx(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let torus_mesh = meshes.add(Mesh::from(Torus::new(0.5, 0.03)));

    let mut axis_materials = HashMap::new();
    for axis in [
        EmotionalAxis::SecurityThreat,
        EmotionalAxis::BelongingIsolation,
        EmotionalAxis::AgencyHelplessness,
        EmotionalAxis::SatiationDesperation,
    ] {
        let color = axis.color();
        let material = materials.add(StandardMaterial {
            base_color: color,
            emissive: color.to_linear(),
            emissive_exposure_weight: 1.5,
            alpha_mode: AlphaMode::Blend,
            ..default()
        });
        axis_materials.insert(axis, material);
    }

    commands.insert_resource(VfxState {
        attention_pulse_mesh: Some(torus_mesh),
        axis_materials,
        ..default()
    });
}

mod debris;
mod fire_spread;
mod smoke;
mod screen_edge;

pub use debris::DebrisPlugin;
pub use fire_spread::FireSpreadPlugin;
pub use smoke::SmokePlugin;
pub use screen_edge::render_screen_edge_indicators;
