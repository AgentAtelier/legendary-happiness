//! Screen-edge indicators module for Phase 3c.
//!
//! Projects off-screen event positions to viewport edges.
//! Clamps to 20px inset. Draws small coloured triangle pointing inward.
//! Distance label (e.g., "Flood 140m"). Pulse opacity by severity.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use anvil_sim::catastrophe::CatastropheType as CT;
use crate::app::RuntimeResource;

/// System to render screen-edge indicators (Phase 3c).
pub fn render_screen_edge_indicators(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
) {
    // Access the catastrophe system through the runtime accessor
    let Some(catastrophe_system) = runtime.runtime.catastrophe_system() else {
        return;
    };

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        let content_rect = ctx.content_rect();
        let inset = 20.0;

        // Check for active catastrophe events
        for event in &catastrophe_system.active_events {
            let epicentre = event.epicentre.position;

            // For now, just place at bottom-right as a demo
            // In a full implementation, we'd project 3D positions to 2D screen space
            // and determine the appropriate edge based on direction
            let distance = epicentre.length();
            if distance > 50.0 {
                let pos = egui::Pos2::new(content_rect.right() - inset, content_rect.bottom() - inset);

                // Create a small area for the indicator
                let indicator_size = egui::vec2(30.0, 30.0);

                egui::Area::new(egui::Id::new(format!("edge_indicator_{}", event.id)))
                    .fixed_pos(pos)
                    .default_size(indicator_size)
                    .show(ctx, |ui: &mut egui::Ui| {
                        // Draw a triangle pointing inward
                        let painter = ui.painter();
                        let rect = ui.available_rect_before_wrap();

                        // Triangle points (pointing left for right edge)
                        let points = vec![
                            rect.left_top(),
                            rect.right_top(),
                            rect.center_bottom(),
                        ];

                        // Color based on catastrophe type
                        let color = match event.catastrophe_type {
                            CT::Flood => egui::Color32::BLUE,
                            CT::Drought => egui::Color32::from_rgb(139, 69, 19),
                            CT::Earthquake => egui::Color32::from_rgb(139, 69, 19),
                            CT::Wildfire => egui::Color32::from_rgb(255, 69, 0),
                            CT::Blizzard => egui::Color32::from_rgb(240, 248, 255),
                            CT::Landslide => egui::Color32::from_rgb(139, 69, 19),
                            CT::Blight => egui::Color32::from_rgb(139, 0, 139),
                            _ => egui::Color32::RED,
                        };

                        // Draw filled triangle using Path shape
                        let triangle_shape = egui::epaint::PathShape::convex_polygon(
                            points.clone(),
                            color,
                            egui::epaint::Stroke::new(0.0, color),
                        );
                        painter.add(triangle_shape);
                    });
            }
        }
    }
}
