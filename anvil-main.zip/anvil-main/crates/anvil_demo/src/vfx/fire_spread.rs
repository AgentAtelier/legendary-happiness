//! Fire spread VFX system.
//!
//! Renders the Wildfire catastrophe as visible flame clusters.

#![allow(dead_code)]

use bevy::prelude::*;

use anvil_sim::catastrophe::event::CatastropheType;

use crate::app::RuntimeResource;

/// Marker component for fire particle entities.
#[derive(Component)]
pub struct FireParticle;

/// Component storing flame intensity for color calculation.
#[derive(Component)]
pub struct FlameIntensity {
    /// Current intensity (0.0 to 1.0+).
    pub intensity: f32,
}

/// Plugin for fire spread visual effects.
pub struct FireSpreadPlugin;

impl Plugin for FireSpreadPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, update_fire_spread.run_if(resource_exists::<crate::app::RuntimeResource>));
    }
}

/// Color based on flame intensity.
/// Orange at high intensity, red at low, fading to smoke grey below 0.3.
fn flame_color(intensity: f32) -> Color {
    if intensity < 0.05 {
        // Despawn threshold - return transparent
        Color::srgba(0.3, 0.3, 0.3, 0.0)
    } else if intensity < 0.3 {
        // Smoke grey
        let alpha = (intensity - 0.05) / (0.3 - 0.05);
        Color::srgba(0.3, 0.3, 0.3, 0.5 * alpha)
    } else if intensity < 0.6 {
        // Red to orange transition
        let t = (intensity - 0.3) / 0.3;
        Color::srgb(1.0, 0.3 + 0.7 * t, 0.1)
    } else {
        // Bright orange
        Color::srgb(1.0, 0.6, 0.1)
    }
}

/// Spawn a flame entity at the given position with the given intensity.
fn spawn_flame(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    position: Vec3,
    intensity: f32,
) {
    let cube = Mesh::from(Cuboid::new(0.2, 0.4, 0.2));
    let cube_handle = meshes.add(cube);

    let color = flame_color(intensity);
    // Convert Color to LinearRgba for emissive
    let srgba = color.to_srgba();
    let material = StandardMaterial {
        base_color: color,
        emissive: LinearRgba::new(srgba.red, srgba.green, srgba.blue, 1.0),
        emissive_exposure_weight: 2.0,
        ..default()
    };
    let material_handle = materials.add(material);

    commands.spawn((
        Mesh3d(cube_handle),
        MeshMaterial3d(material_handle),
        Transform::from_translation(position),
        FireParticle,
        FlameIntensity { intensity },
    ));
}

/// Update fire spread visual effects.
/// Reads the CatastropheSystem from RuntimeResource and spawns flame
/// proxies for each affected area of Wildfire events.
pub fn update_fire_spread(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    runtime: Res<RuntimeResource>,
    flame_query: Query<(Entity, &FlameIntensity)>,
) {
    // Access catastrophe system through runtime
    let Some(catastrophe_system) = runtime.runtime.catastrophe_system() else {
        return;
    };

    // Despawn old flame entities with intensity below threshold
    for (entity, intensity) in flame_query.iter() {
        if intensity.intensity < 0.05 {
            commands.entity(entity).despawn();
        }
    }

    // Process each active catastrophe event
    for event in &catastrophe_system.active_events {
        if event.catastrophe_type == CatastropheType::Wildfire && event.magnitude > 0.0 {
            for area in &event.affected_areas {
                if area.intensity > 0.05 {
                    // Convert glam::Vec3 to bevy::prelude::Vec3
                    let world_pos = Vec3::new(
                        area.position.x,
                        area.position.y,
                        area.position.z,
                    );
                    spawn_flame(&mut commands, &mut meshes, &mut materials, world_pos, area.intensity);
                }
            }
        }
    }
}
