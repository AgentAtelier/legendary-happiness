//! Smoke signal VFX system.
//!
//! Renders the Wildfire precursor smoke signal before the fire becomes visible.

#![allow(dead_code)]

use bevy::prelude::*;

use anvil_sim::catastrophe::event::CatastropheType;

use crate::app::RuntimeResource;

/// Marker component for smoke signal entities.
#[derive(Component)]
pub struct SmokeSignal;

/// Component storing smoke signal intensity for alpha scaling.
#[derive(Component)]
pub struct SmokeIntensity {
    /// Current intensity (0.0 to 1.0).
    pub intensity: f32,
}

/// Plugin for smoke signal visual effects.
pub struct SmokePlugin;

impl Plugin for SmokePlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, update_smoke_signal);
    }
}

/// Create a translucent grey billboard quad mesh.
fn create_billboard_quad() -> Mesh {
    // Simple quad mesh (Rectangle is the type for quad in Bevy)
    Mesh::from(Rectangle::new(5.0, 5.0))
}

/// Spawn a smoke signal billboard at the given position.
fn spawn_smoke_signal(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    position: Vec3,
    intensity: f32,
) {
    let quad = create_billboard_quad();
    let mesh_handle = meshes.add(quad);

    // Translucent grey material with alpha based on intensity
    let alpha = intensity.clamp(0.0, 1.0);
    let material = StandardMaterial {
        base_color: Color::srgba(0.4, 0.4, 0.4, 0.3 * alpha),
        alpha_mode: AlphaMode::Blend,
        ..default()
    };
    let material_handle = materials.add(material);

    commands.spawn((
        Mesh3d(mesh_handle),
        MeshMaterial3d(material_handle),
        Transform::from_translation(position),
        SmokeSignal,
        SmokeIntensity { intensity },
    ));
}

/// Update smoke signal visual effects.
/// Checks for Wildfire PrecursorSignal events and spawns translucent
/// grey billboard quads at the epicentre region's edge.
pub fn update_smoke_signal(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    runtime: Option<Res<RuntimeResource>>,
    smoke_query: Query<(Entity, &SmokeIntensity)>,
) {
    let Some(runtime) = runtime else { return };
    // Access catastrophe system through runtime
    let Some(catastrophe_system) = runtime.runtime.catastrophe_system() else {
        return;
    };

    // Despawn old smoke entities
    for (entity, intensity) in smoke_query.iter() {
        if intensity.intensity <= 0.0 {
            commands.entity(entity).despawn();
        }
    }

    // Process precursor signals
    for signal in &catastrophe_system.pending_signals {
        if signal.catastrophe_type == CatastropheType::Wildfire && signal.intensity > 0.0 {
            // Spawn smoke at a fixed position for the demo
            // In a real implementation, this would be at the signal epicentre
            let smoke_pos = Vec3::new(0.0, 50.0, -200.0);
            spawn_smoke_signal(&mut commands, &mut meshes, &mut materials, smoke_pos, signal.intensity);
        }
    }
}
