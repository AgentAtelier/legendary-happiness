// anvil_demo/src/sim_bridge.rs
use bevy::prelude::*;
use anvil_bevy::sim_bridge::{SimSnapshot, TimeSnapshot, WeatherSnapshot, CatastropheSnapshot, CatastropheKind};

use crate::app::RuntimeResource;

/// Reads the deterministic runtime and populates the presentation-side snapshot.
/// Runs in PreUpdate, before interpolation and apply.
pub fn sim_bridge_system(
    runtime: Res<RuntimeResource>,
    mut snapshot: ResMut<SimSnapshot>,
) {
    // Access the runtime's public API.
    let sim = &runtime.runtime;

    // Time
    snapshot.time = TimeSnapshot {
        time_of_day: sim.time.day_phase(),
        day: (sim.time.seconds_since_start / 86400.0) as u32,
    };
    snapshot.tick = 0; // Will be set by simulation tick counter

    // Weather
    let w = &sim.weather;
    snapshot.weather = WeatherSnapshot {
        temperature_c: w.temperature,
        humidity: w.humidity,
        wind_speed_ms: w.wind_speed,
        wind_direction: w.wind_direction,
        precipitation: match w.current_weather {
            anvil_runtime::weather::WeatherPhase::Rain => 0.8,
            anvil_runtime::weather::WeatherPhase::Storm => 1.0,
            _ => 0.0,
        },
        cloud_cover: match w.current_weather {
            anvil_runtime::weather::WeatherPhase::Clear => 0.0,
            anvil_runtime::weather::WeatherPhase::Overcast => 0.75,
            anvil_runtime::weather::WeatherPhase::Rain => 0.88,
            anvil_runtime::weather::WeatherPhase::Fog => 0.60,
            anvil_runtime::weather::WeatherPhase::Storm => 1.0,
        },
        pressure_hpa: w.pressure,
    };

    // Catastrophes (active events with stable VFX seed)
    if let Some(cat_system) = sim.catastrophe_system() {
        snapshot.catastrophes = cat_system.active_events
            .iter()
            .filter_map(|c| {
                let kind = match c.catastrophe_type {
                    anvil_sim::catastrophe::CatastropheType::Wildfire => CatastropheKind::Wildfire,
                    anvil_sim::catastrophe::CatastropheType::Flood => CatastropheKind::Flood,
                    anvil_sim::catastrophe::CatastropheType::Earthquake => CatastropheKind::Earthquake,
                    _ => return None,
                };
                Some(CatastropheSnapshot {
                    id: c.id,
                    kind,
                    origin: Vec3::new(c.epicentre.position.x, c.epicentre.position.y, c.epicentre.position.z),
                    intensity: c.magnitude,
                    vfx_seed: stable_seed_from_id(c.id, c.trigger_tick),
                })
            })
            .collect();
    }
}

// Deterministic seed helper
fn stable_seed_from_id(id: u64, onset_tick: u64) -> u64 {
    let mut h = id ^ (onset_tick.wrapping_shl(32) | onset_tick.wrapping_shr(32));
    h ^= h >> 30;
    h = h.wrapping_mul(0xBF58476D1CE4E5B9);
    h ^= h >> 27;
    h = h.wrapping_mul(0x94D049BB133111EB);
    h ^= h >> 31;
    h
}
