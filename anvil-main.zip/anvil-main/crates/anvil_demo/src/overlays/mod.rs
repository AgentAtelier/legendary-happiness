//! Overlays module for NPC visualization overlays.
//!
//! This module provides visual overlays including:
//! - Emotion lines: connections between NPCs based on emotional state
//! - Rings: concentric rings showing NPC stats
//! - Needs bars: 7-segment needs display above NPC heads
//! - Skill flashes: expanding rings on observation credit gain
//!
//! Note: Trails are deferred due to complexity. Using mesh-based rendering
//! to avoid bevy_gizmos version conflicts.

use bevy::pbr::StandardMaterial;
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};
use std::collections::HashSet;

use crate::npc_visuals::NpcVisual;
use crate::ui::panel::UiState;

pub mod needs_bar;
pub mod skill_flash;

pub use needs_bar::NeedsBarPlugin;
pub use skill_flash::SkillFlashPlugin;

/// Resource for overlay state.
#[derive(Resource, Default)]
pub struct OverlayState {
    /// Whether emotion lines are enabled.
    pub show_emotion_lines: bool,
    /// Whether rings are enabled.
    pub show_rings: bool,
}

/// Component marking an emotion line entity.
#[derive(Component)]
#[allow(dead_code)]
pub struct EmotionLine {
    /// The two NPC entities this line connects.
    pub npc_entities: (Entity, Entity),
}

/// Component marking a ring entity.
#[derive(Component)]
#[allow(dead_code)]
pub struct OverlayStatusRing {
    /// Ring radius.
    pub radius: f32,
    /// Ring color.
    pub color: Color,
    /// The NPC entity this ring belongs to.
    pub npc_entity: Entity,
}

/// Resource tracking emotion line entities by NPC entity pairs.
#[derive(Resource, Default)]
pub struct EmotionLineEntities {
    /// Map from (min_entity, max_entity) to emotion line entity.
    pub entities: std::collections::HashMap<(Entity, Entity), Entity>,
}

/// Ring configuration for status rings.
pub const RING_CONFIGS: [(f32, Color); 3] = [
    (0.5, Color::srgba(1.0, 0.3, 0.3, 0.3)),  // Red for needs
    (0.8, Color::srgba(0.3, 1.0, 0.3, 0.3)),  // Green for emotion
    (1.1, Color::srgba(0.3, 0.3, 1.0, 0.3)),  // Blue for fluency
];

/// Component to track status ring entities for an NPC.
#[derive(Component, Default)]
pub struct NpcStatusRings {
    /// Entity handles for the three status rings (needs, emotion, fluency).
    pub ring_entities: [Option<Entity>; 3],
}

/// System that spawns/despawns emotion lines based on NPC proximity.
/// Uses a reuse pattern: spawn entities once and update Transform/Visibility
/// instead of despawn+respawn every frame.
#[allow(clippy::too_many_arguments)]
pub fn update_emotion_lines(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    npc_visuals: Query<(Entity, &Transform, &NpcVisual)>,
    emotion_lines: Query<(Entity, &EmotionLine)>,
    mut line_entities: ResMut<EmotionLineEntities>,
    ui_state: Res<UiState>,
    overlay_state: Res<OverlayState>,
) {
    if !ui_state.show_overlays || !overlay_state.show_emotion_lines {
        // Hide all emotion lines instead of despawning
        for (entity, _) in emotion_lines.iter() {
            commands.entity(entity).insert(Visibility::Hidden);
        }
        return;
    }

    // Collect all NPC entities and positions
    let npc_data: Vec<(Entity, Vec3)> = npc_visuals.iter()
        .map(|(entity, transform, _)| (entity, transform.translation))
        .collect();
    
    let npc_count = npc_data.len();
    
    // Track which pairs currently need lines
    let mut needed_pairs: HashSet<(Entity, Entity)> = HashSet::new();
    
    // Find all pairs within distance
    for i in 0..npc_count {
        for j in (i + 1)..npc_count {
            let (e1, p1) = &npc_data[i];
            let (e2, p2) = &npc_data[j];
            
            let distance = p1.distance(*p2);
            if distance < 5.0 {
                // Order entities consistently for the hash map key
                let (min_e, max_e) = if e1.index() < e2.index() { (*e1, *e2) } else { (*e2, *e1) };
                needed_pairs.insert((min_e, max_e));
            }
        }
    }
    
    // Update existing lines: show and update Transform for needed pairs
    // Despawn lines for pairs no longer needed
    let mut entities_to_remove: Vec<Entity> = Vec::new();
    
    for ((e1, e2), &line_entity) in &line_entities.entities {
        if needed_pairs.contains(&(*e1, *e2)) {
            // This pair still needs a line - update its transform
            if let (Some(p1), Some(p2)) = (npc_data.iter().find(|(e, _)| *e == *e1).map(|(_, p)| *p),
                                         npc_data.iter().find(|(e, _)| *e == *e2).map(|(_, p)| *p)) {
                let mid_point = (p1 + p2) / 2.0;
                let direction = (p2 - p1).normalize_or_zero();
                let line_length = p1.distance(p2);
                let rotation = Quat::from_rotation_arc(Vec3::X, direction);
                
                commands.entity(line_entity).insert((
                    Transform {
                        translation: mid_point,
                        rotation,
                        scale: Vec3::new(line_length, 0.02, 0.02),
                    },
                    Visibility::Visible,
                ));
            }
        } else {
            // This pair no longer needs a line - despawn it
            commands.entity(line_entity).despawn();
            entities_to_remove.push(line_entity);
        }
    }
    
    // Remove despawned entities from tracking
    for &entity in &entities_to_remove {
        // Find and remove from the map
        line_entities.entities.retain(|_, &mut v| v != entity);
    }
    
    // Spawn new lines for pairs that need them but don't have them yet
    for &(e1, e2) in &needed_pairs {
        // Use entry API to avoid contains_key + insert pattern
        line_entities.entities.entry((e1, e2)).or_insert_with(|| {
            // Spawn a new line entity
            let line_color = Color::srgba(0.5, 0.5, 1.0, 0.3);
            
            let material = StandardMaterial {
                base_color: line_color,
                alpha_mode: AlphaMode::Blend,
                ..default()
            };
            let material_handle = materials.add(material);
            
            // Create a thin cuboid mesh for the line
            let cuboid = Mesh::from(Cuboid::new(1.0, 0.02, 0.02));
            let cuboid_handle = meshes.add(cuboid);
            
            commands.spawn((
                Mesh3d(cuboid_handle),
                MeshMaterial3d(material_handle),
                Transform::default(),
                Visibility::Hidden,
                EmotionLine {
                    npc_entities: (e1, e2),
                },
            )).id()
        });
    }
}

/// System that spawns/despawns status rings around NPCs.
/// Uses a reuse pattern: spawn entities once and update Transform/Visibility
/// instead of despawn+respawn every frame.
pub fn update_status_rings(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    npc_visuals: Query<(Entity, &Transform, &NpcVisual, Option<&NpcStatusRings>)>,
    ui_state: Res<UiState>,
    overlay_state: Res<OverlayState>,
) {
    if !ui_state.show_overlays || !overlay_state.show_rings {
        // Hide all rings
        for (_, _, _, rings) in npc_visuals.iter() {
            if let Some(rings) = rings {
                for ring_entity in rings.ring_entities.iter().flatten() {
                    commands.entity(*ring_entity).insert(Visibility::Hidden);
                }
            }
        }
        return;
    }

    // Spawn rings for NPCs that don't have them yet
    for (npc_entity, transform, _npc_visual, rings) in npc_visuals.iter() {
        if let Some(rings) = rings {
            // Update existing rings: set position and make visible
            let position = transform.translation + Vec3::new(0.0, 0.1, 0.0);
            for (idx, (_radius, _color)) in RING_CONFIGS.iter().enumerate() {
                if let Some(ring_entity) = rings.ring_entities[idx] {
                    commands.entity(ring_entity).insert((
                        Transform {
                            translation: position,
                            rotation: Quat::from_rotation_x(std::f32::consts::PI / 2.0),
                            scale: Vec3::ONE,
                        },
                        Visibility::Visible,
                    ));
                }
            }
        } else {
            // Spawn the three status rings for this NPC
            let mut ring_entities = [None, None, None];
            let position = transform.translation + Vec3::new(0.0, 0.1, 0.0);
            
            for (idx, (radius, color)) in RING_CONFIGS.iter().enumerate() {
                // Create a torus for the ring
                let torus = Mesh::from(Torus::new(*radius - 0.02, *radius));
                let torus_handle = meshes.add(torus);
                
                let material = StandardMaterial {
                    base_color: *color,
                    alpha_mode: AlphaMode::Blend,
                    ..default()
                };
                let material_handle = materials.add(material);
                
                let ring_entity = commands.spawn((
                    Mesh3d(torus_handle),
                    MeshMaterial3d(material_handle),
                    Transform {
                        translation: position,
                        rotation: Quat::from_rotation_x(std::f32::consts::PI / 2.0),
                        scale: Vec3::ONE,
                    },
                    Visibility::Hidden,
                    OverlayStatusRing {
                        radius: *radius,
                        color: *color,
                        npc_entity,
                    },
                )).id();
                
                ring_entities[idx] = Some(ring_entity);
            }
            
            // Add the component to the NPC entity
            commands.entity(npc_entity).insert(NpcStatusRings {
                ring_entities,
            });
        }
    }
}

/// Setup system for overlay state.
pub fn setup_overlays(mut commands: Commands) {
    commands.insert_resource(OverlayState {
        show_emotion_lines: true,
        show_rings: true,
    });
    commands.init_resource::<EmotionLineEntities>();
}

/// System to render network line legend panel (Phase 5b).
/// Small fixed panel bottom-right when Overlays ON:
/// Family (thick red), Proximity (dashed blue), Village (thin dotted grey).
pub fn render_network_line_legend(
    mut egui_contexts: EguiContexts,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    if let Ok(ctx) = egui_contexts.ctx_mut() {
        // Create a small window at bottom-right
        egui::Window::new("Network Legend")
            .id(egui::Id::new("network_legend"))
            .anchor(egui::Align2::RIGHT_BOTTOM, egui::vec2(-10.0, -10.0))
            .fixed_size(egui::vec2(200.0, 100.0))
            .resizable(false)
            .title_bar(false)
            .show(ctx, |ui: &mut egui::Ui| {
                // Background with rounded corners
                egui::Frame::NONE
                    .fill(egui::Color32::from_rgba_unmultiplied(40, 40, 40, 200))
                    .corner_radius(egui::CornerRadius::same(4))
                    .stroke(egui::Stroke::new(1.0, egui::Color32::from_rgb(80, 80, 80)))
                    .show(ui, |ui: &mut egui::Ui| {
                        ui.label("Network Lines:");
                        ui.separator();
                        
                        // Family: thick red
                        ui.horizontal(|ui| {
                            // Color swatch
                            let response = ui.allocate_response(egui::vec2(20.0, 12.0), egui::Sense::hover());
                            ui.painter().rect_filled(
                                response.rect,
                                egui::CornerRadius::ZERO,
                                egui::Color32::from_rgb(200, 50, 50),
                            );
                            ui.label("Family");
                        });
                        
                        // Proximity: dashed blue
                        ui.horizontal(|ui| {
                            let response = ui.allocate_response(egui::vec2(20.0, 12.0), egui::Sense::hover());
                            ui.painter().rect_filled(
                                response.rect,
                                egui::CornerRadius::ZERO,
                                egui::Color32::from_rgb(50, 100, 200),
                            );
                            ui.label("Proximity");
                        });
                        
                        // Village: thin dotted grey
                        ui.horizontal(|ui| {
                            let response = ui.allocate_response(egui::vec2(20.0, 12.0), egui::Sense::hover());
                            ui.painter().rect_filled(
                                response.rect,
                                egui::CornerRadius::ZERO,
                                egui::Color32::from_rgb(150, 150, 150),
                            );
                            ui.label("Village");
                        });
                    });
            });
    }
}
