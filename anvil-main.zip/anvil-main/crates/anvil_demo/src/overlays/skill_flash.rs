//! Skill flash overlay system.
//!
//! Shows a brief expanding ring when an NPC gains an observation credit.

#![allow(dead_code)]

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::RuntimeResource;
use crate::npc_visuals::NpcVisual;
use crate::ui::panel::UiState;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Plugin for skill flash overlay.
pub struct SkillFlashPlugin;

impl Plugin for SkillFlashPlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<SkillFlashState>()
            .add_systems(
                Update,
                (
                    check_observation_credits.run_if(resource_exists::<crate::app::RuntimeResource>),
                    update_skill_flash_timers,
                ),
            )
            .add_systems(EguiPrimaryContextPass, render_skill_flashes);
    }
}

/// Resource tracking active skill flashes.
#[derive(Resource, Default)]
pub struct SkillFlashState {
    /// Active flashes: (npc_person_id, start_time_s, duration_s)
    pub flashes: Vec<(u64, f32, f32)>,
    /// Previous observation credit count for each person
    pub prev_credits: std::collections::HashMap<u64, u32>,
}

/// Component marking a skill flash entity.
#[derive(Component)]
pub struct SkillFlash;

/// Check for new observation credits and spawn flashes.
pub fn check_observation_credits(
    time: Res<Time>,
    runtime: Res<RuntimeResource>,
    mut flash_state: ResMut<SkillFlashState>,
    npc_visuals: Query<(Entity, &NpcVisual)>,
) {
    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    let current_time = time.elapsed_secs();

    // Check each person for new observation gains
    for person in &npc_system.persons {
        let person_id = person.id.get();

        let current_gains = npc_system
            .observation_gains_today
            .iter()
            .filter(|((pid, _), _)| *pid == person_id)
            .map(|(_, &count)| count)
            .sum::<u32>();

        let prev_gains = flash_state.prev_credits.get(&person_id).copied().unwrap_or(0);

        if current_gains > prev_gains {
            // New observation credits gained!
            for (_entity, npc_visual) in npc_visuals.iter() {
                if npc_visual.person_id == person_id {
                    flash_state.flashes.push((
                        person_id,
                        current_time,
                        1.0,
                    ));
                    break;
                }
            }
        }

        flash_state.prev_credits.insert(person_id, current_gains);
    }
}

/// Render skill flashes as expanding rings using egui.
pub fn render_skill_flashes(
    time: Res<Time>,
    mut egui_contexts: EguiContexts,
    flash_state: ResMut<SkillFlashState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    let current_time = time.elapsed_secs();
    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    for (person_id, start_time, duration) in &flash_state.flashes {
        let elapsed = current_time - start_time;
        let progress = (elapsed / duration).min(1.0);

        // Calculate position based on person_id
        let x = 100.0 + ((*person_id as f32 % 10.0) * 20.0);
        let y = 50.0 + ((*person_id as f32 / 10.0) * 30.0);
        let center = egui::Pos2::new(x, y);

        draw_skill_ring(ctx, center, progress);
    }
}

/// Draw the skill flash ring using egui.
fn draw_skill_ring(ctx: &mut egui::Context, center: egui::Pos2, progress: f32) {
    let min_radius = 5.0;
    let max_radius = 25.0;
    let radius = min_radius + (max_radius - min_radius) * progress;
    let alpha = (1.0 - progress).clamp(0.0, 1.0);

    let painter = ctx.layer_painter(egui::LayerId::new(
        egui::Order::Foreground,
        egui::Id::new("skill_flash"),
    ));

    let color = egui::Color32::from_rgba_premultiplied(
        100,
        200,
        255,
        (180.0 * alpha) as u8,
    );

    painter.circle_stroke(center, radius, egui::Stroke::new(2.0, color));
}

/// Update flash timers and despawn completed flashes.
pub fn update_skill_flash_timers(
    time: Res<Time>,
    mut flash_state: ResMut<SkillFlashState>,
) {
    let current_time = time.elapsed_secs();
    flash_state
        .flashes
        .retain(|(_, start_time, duration)| current_time - start_time < *duration);
}
