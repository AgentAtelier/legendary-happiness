//! Needs bar overlay system.
//!
//! Renders a 7-segment needs bar above each NPC's head.

#![allow(dead_code)]

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use anvil_sim::needs::Need;

use crate::app::RuntimeResource;
use crate::npc_visuals::NpcVisual;
use crate::ui::panel::UiState;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Plugin for needs bar overlay.
pub struct NeedsBarPlugin;

impl Plugin for NeedsBarPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(
            EguiPrimaryContextPass,
            render_needs_bars.after(crate::sim::tick_simulation_systems).run_if(resource_exists::<crate::app::RuntimeResource>),
        );
    }
}

/// Color for a need value.
fn need_color(value: f32) -> egui::Color32 {
    if value > 0.7 {
        egui::Color32::GREEN
    } else if value >= 0.4 {
        egui::Color32::YELLOW
    } else {
        egui::Color32::RED
    }
}

/// Render needs bars for all NPCs.
pub fn render_needs_bars(
    mut egui_contexts: EguiContexts,
    runtime: Res<RuntimeResource>,
    npc_visuals: Query<(Entity, &NpcVisual)>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_overlays {
        return;
    }

    let Some(npc_system) = runtime.runtime.npc_system() else {
        return;
    };

    let Some(ctx) = egui_contexts.try_ctx_mut() else {
        return;
    };

    // For each NPC, render a needs bar at a fixed offset
    let mut y_offset = 20.0;

    for (entity, npc_visual) in npc_visuals.iter() {
        let need_sat = npc_system
            .need_satisfaction
            .get(&npc_visual.person_id)
            .copied()
            .unwrap_or([0.5; 7]);

        render_needs_bar_for_npc(ctx, entity, &need_sat, y_offset);
        y_offset += 25.0;
    }
}

/// Render needs bar for a single NPC.
fn render_needs_bar_for_npc(
    ctx: &mut egui::Context,
    entity: Entity,
    need_sat: &[f32; 7],
    y_offset: f32,
) {
    let window_id = egui::Id::new("needs_bar").with(entity.index());

    egui::Window::new("")
        .id(window_id)
        .title_bar(false)
        .resizable(false)
        .collapsible(false)
        .fixed_pos(egui::Pos2::new(10.0, y_offset))
        .fixed_size(egui::Vec2::new(200.0, 14.0))
        .show(ctx, |ui| {
            ui.horizontal(|ui| {
                // Render 7 segments
                for (i, &value) in need_sat.iter().enumerate() {
                    let need = match i {
                        0 => Need::Sleep,
                        1 => Need::Food,
                        2 => Need::Water,
                        3 => Need::Safety,
                        4 => Need::Shelter,
                        5 => Need::Companionship,
                        6 => Need::Joy,
                        _ => Need::Food,
                    };

                    let color = if matches!(need, Need::Joy) {
                        egui::Color32::GRAY
                    } else {
                        need_color(value)
                    };

                    let width = 25.0;
                    let height = 12.0;
                    let fill_height = value.clamp(0.0, 1.0) * height;

                    // Draw segment
                    let fill_rect = egui::Rect::from_min_size(
                        ui.cursor().min,
                        egui::Vec2::new(width - 1.0, fill_height),
                    );
                    ui.painter().rect_filled(fill_rect, 0.0, color);

                    ui.advance_cursor_after_rect(egui::Rect::from_min_size(
                        ui.cursor().min,
                        egui::Vec2::new(width, height),
                    ));
                }
            });
        });
}
