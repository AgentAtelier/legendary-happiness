//! Procedural humanoid mesh for NPCs.
//!
//! Creates a simple humanoid proxy mesh consisting of a capsule body
//! and a sphere head.

use anvil_sim::skill::fluency::FluencyLevel;
use bevy::prelude::*;

/// Body dimensions for the humanoid mesh.
const BODY_RADIUS: f32 = 0.12;
const BODY_HEIGHT: f32 = 0.8; // Half-length * 2

/// Head dimensions for the humanoid mesh.
const HEAD_RADIUS: f32 = 0.1;
const HEAD_Y_OFFSET: f32 = 0.55; // Position head above body center

/// Marker component for NPC humanoid visual.
#[derive(Component)]
pub struct HumanoidVisual {
    #[allow(dead_code)]
    pub person_id: u64,
}

/// Component for tracking base Y position for breathing animation.
#[derive(Component)]
pub struct NpcBaseY {
    pub base_y: f32,
}

/// Component for tracking the phase offset for breathing animation.
#[derive(Component)]
pub struct BreathingPhase {
    pub phase_offset: f32,
}

/// Fluency level speed multipliers for diegetic skill expression (Phase 2e).
const FLUENCY_SPEED_MULTIPLIERS: [f32; 5] = [
    0.5,   // Halting
    0.75,  // Awkward
    1.0,   // Competent
    1.15,  // Smooth
    1.3,   // Expert
];

/// System to spawn a humanoid NPC mesh.
pub fn spawn_humanoid_npc(
    commands: &mut Commands,
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
    person_id: u64,
    position: Vec3,
    color: Color,
    fluency_level: Option<FluencyLevel>,
) -> Entity {
    // Create body capsule (using cylinder as placeholder for capsule)
    let body_mesh = Mesh::from(Cylinder::new(BODY_HEIGHT, BODY_RADIUS));
    let body_mesh_handle = meshes.add(body_mesh);

    // Create body material with emotion color
    let body_material = StandardMaterial {
        base_color: color,
        perceptual_roughness: 0.5,
        metallic: 0.1,
        ..default()
    };
    let body_material_handle = materials.add(body_material);

    // Create head sphere
    let head_mesh = Mesh::from(Sphere::new(HEAD_RADIUS));
    let head_mesh_handle = meshes.add(head_mesh);

    // Head is slightly lighter than body
    // Mix: body_color * 0.7 + head_tint * 0.3
    let head_tint_r = 0.9;
    let head_tint_g = 0.85;
    let head_tint_b = 0.8;
    // Convert color to LinearRgba to access components
    let color_rgba: LinearRgba = color.to_linear();
    let head_color = Color::srgb(
        color_rgba.red * 0.7 + head_tint_r * 0.3,
        color_rgba.green * 0.7 + head_tint_g * 0.3,
        color_rgba.blue * 0.7 + head_tint_b * 0.3,
    );
    let head_material = StandardMaterial {
        base_color: head_color,
        perceptual_roughness: 0.5,
        metallic: 0.1,
        ..default()
    };
    let head_material_handle = materials.add(head_material);

    // Calculate speed multiplier from fluency level (Phase 2e)
    let speed_multiplier = fluency_level
        .map(|level| FLUENCY_SPEED_MULTIPLIERS[level as usize])
        .unwrap_or(1.0);
    
    // Generate a random but deterministic movement direction based on person_id
    let angle = (person_id as f32 * 137.0).to_radians();
    let velocity = Vec3::new(angle.cos(), 0.0, angle.sin()) * 0.5 * speed_multiplier;

    // Spawn the body entity
    let entity = commands.spawn((
        Mesh3d(body_mesh_handle),
        MeshMaterial3d(body_material_handle),
        Transform::from_translation(position),
        HumanoidVisual { person_id },
        NpcBaseY { base_y: position.y },
        BreathingPhase {
            phase_offset: (person_id as f32 * 1.7).fract() * 2.0 * std::f32::consts::PI,
        },
        NpcVelocity {
            velocity,
            speed_multiplier,
        },
    )).id();

    // Add head as child
    commands.entity(entity).with_children(|parent| {
        parent.spawn((
            Mesh3d(head_mesh_handle),
            MeshMaterial3d(head_material_handle),
            Transform::from_xyz(0.0, HEAD_Y_OFFSET, 0.0),
        ));
    });

    entity
}

/// Mood-to-colour mapping as specified in the sprint.
/// 
/// Maps mood value from -1.0 (despair) to +1.0 (euphoria) to a color gradient.
pub fn mood_to_color(mood: f32) -> Color {
    let t = (mood + 1.0) * 0.5; // map -1..1 to 0..1
    // Linear interpolation between despair (#5B6B7A) and euphoria (#E8D5B5)
    let r = 0.35 + (0.91 - 0.35) * t;
    let g = 0.42 + (0.84 - 0.42) * t;
    let b = 0.48 + (0.71 - 0.48) * t;
    Color::srgb(r, g, b)
}

/// Clothing variation colors - 6 earthy tones.
const CLOTHING_COLORS: [Color; 6] = [
    Color::srgb(0.29, 0.23, 0.17),  // #4B3B2B - dark brown
    Color::srgb(0.36, 0.25, 0.20),  // #5C4033 - medium brown
    Color::srgb(0.23, 0.30, 0.18),  // #3B4D2E - dark green
    Color::srgb(0.18, 0.29, 0.38),  // #2E4A62 - dark blue
    Color::srgb(0.42, 0.30, 0.23),  // #6A4D3B - warm brown
    Color::srgb(0.27, 0.25, 0.20),  // #454133 - dark grey
];

/// Get clothing color based on person ID (deterministic).
pub fn clothing_color(person_id: u64) -> Color {
    let idx = (person_id as usize) % CLOTHING_COLORS.len();
    CLOTHING_COLORS[idx]
}

/// Combined mood and clothing color.
/// Body uses clothing color tinted by mood.
pub fn npc_body_color(person_id: u64, mood: f32) -> Color {
    let clothing = clothing_color(person_id);
    let mood_color = mood_to_color(mood);
    // Mix clothing with mood color (mood has more weight)
    clothing.mix(&mood_color, 0.7)
}

/// Component for NPC target direction (where the NPC should face).
/// Used for smooth rotation toward targets (Phase 2d).
#[derive(Component)]
pub struct NpcTargetDirection {
    /// Target direction as a normalized vector.
    pub direction: Vec3,
}

/// Component for NPC velocity (movement direction and speed).
/// Used for diegetic skill expression (Phase 2e).
#[derive(Component)]
pub struct NpcVelocity {
    /// Current velocity vector.
    pub velocity: Vec3,
    /// Base speed multiplier from FluencyLevel.
    pub speed_multiplier: f32,
}

/// System to animate NPC breathing.
pub fn update_npc_breathing(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &NpcBaseY, &BreathingPhase)>,
) {
    let global_time = time.elapsed_secs();

    for (mut transform, base_y, phase) in query.iter_mut() {
        // Vertical bob: sin(time * 2.5 + phase) * 0.015
        let bob = (global_time * 2.5 + phase.phase_offset).sin() * 0.015;

        // Body squash/stretch: scale.y = 1.0 + sin(time * 3.0 + phase) * 0.005
        let squash = (global_time * 3.0 + phase.phase_offset).sin() * 0.005;

        // Sway: slight rotation around Z: sin(time * 1.2 + phase) * 0.015 radians
        let sway = (global_time * 1.2 + phase.phase_offset).sin() * 0.015;

        // Apply transformations
        // NOTE: We store base_y separately to prevent drift
        // The breathing is applied relative to base_y each frame
        transform.translation.y = base_y.base_y + bob;
        transform.scale.y = 1.0 + squash;
        transform.rotation = Quat::from_rotation_z(sway);
    }
}

/// System for smooth NPC rotation toward targets (Phase 2d).
/// Uses slerp at 8.0x delta, snaps instantly if dot < 0.0.
/// NPCs face toward settlement center (0,0,0) by default.
pub fn update_npc_rotation_toward_targets(
    time: Res<Time>,
    mut query: Query<(&mut Transform, Option<&NpcTargetDirection>), With<HumanoidVisual>>,
) {
    let delta = time.delta_secs();
    let smoothing_factor = 8.0 * delta;

    for (mut transform, target_dir) in query.iter_mut() {
        // Default target: settlement center (0,0,0)
        let target_direction = target_dir
            .map(|t| t.direction)
            .unwrap_or(Vec3::NEG_Z);
        
        // Normalize the target direction
        let target_dir_normalized = target_direction.normalize_or_zero();
        
        // Calculate target rotation (facing along the direction vector)
        let target_rotation = Quat::from_rotation_arc(Vec3::Z, target_dir_normalized);
        
        // Snap if dot < 0.0 to prevent 180° spin
        let dot = transform.rotation.dot(target_rotation);
        if dot < 0.0 {
            transform.rotation = target_rotation;
        } else {
            // Smooth slerp
            transform.rotation = transform.rotation.slerp(target_rotation, smoothing_factor);
        }
    }
}

/// System for NPC movement with diegetic skill expression (Phase 2e).
/// Movement speed is scaled by FluencyLevel: Halting 0.5x, Awkward 0.75x,
/// Competent 1.0x, Smooth 1.15x, Expert 1.3x.
pub fn update_npc_movement(
    time: Res<Time>,
    mut query: Query<(&mut Transform, &NpcVelocity), With<HumanoidVisual>>,
) {
    let delta = time.delta_secs();

    for (mut transform, velocity) in query.iter_mut() {
        // Apply velocity with speed multiplier
        transform.translation += velocity.velocity * delta * velocity.speed_multiplier;

        // Bounce at world boundaries (simple containment)
        // World bounds: -100 to 100 in X and Z
        let bounds = 100.0;
        if transform.translation.x.abs() > bounds {
            transform.translation.x = transform.translation.x.signum() * bounds;
            // Reverse X velocity on bounce
            // We can't mutate velocity here directly, but for simplicity we'll just clamp
        }
        if transform.translation.z.abs() > bounds {
            transform.translation.z = transform.translation.z.signum() * bounds;
        }
    }
}
