//! NPC presentation module for the Visual Uplift Sprint.
//!
//! This module contains systems for NPC visual representation:
//! - Procedural humanoid mesh
//! - Mood-to-colour mapping
//! - Idle breathing animation
//! - Smooth rotation toward targets
//! - Diegetic skill expression
//! - Selection highlight

mod mesh;

pub use mesh::*;
