//! Plugins for anvil_demo
//!
//! This module contains all the Bevy plugins for the demo application.

pub mod registration;
pub mod sim_bridge;

pub use sim_bridge::{SimBridgePlugin, SimBridgeSet};
