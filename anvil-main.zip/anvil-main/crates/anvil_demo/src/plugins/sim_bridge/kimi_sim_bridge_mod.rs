//! SimBridge Plugin
//!
//! Provides the synchronization layer between anvil_demo_core (pure simulation)
//! and anvil_demo (Bevy app). This plugin:
//! 1. Initializes the SequencerState with beats from the scenario
//! 2. Advances the SequencerState based on simulation ticks
//! 3. Drains PendingBeat from the sequencer and converts them to Bevy events
//! 4. Syncs core simulation state to Bevy UI resources

use bevy::ecs::schedule::IntoScheduleConfigs;
use bevy::prelude::*;

use crate::sim::tick_simulation_systems;

mod sync;
mod world_integrity;

// Re-export for parent module
pub use sync::SimBridgeSet;

// Make sync functions available to this module
use sync::*;

/// Bevy event emitted when a beat fires.
///
/// This event is emitted by the SimBridgePlugin when it drains pending beats
/// from the SequencerState. Other systems can listen for these events to
/// trigger camera changes, UI updates, music transitions, etc.
#[derive(Event, Debug, Clone)]
pub struct BeatEvent {
    /// The beat that fired.
    pub beat: anvil_demo_core::beat::Beat,
    /// The tick at which this beat was queued.
    pub queued_tick: u64,
    /// The data payload associated with this beat.
    pub data: anvil_demo_core::beat::BeatData,
}

/// Marker component to indicate the SequencerState has been initialized.
/// This prevents re-initialization if the system runs multiple times.
#[derive(Resource, Default)]
pub struct SequencerInitialized;

/// Plugin that bridges the core simulation sequencer with Bevy's event system.
///
/// This plugin:
/// 1. Registers BeatEvent as a Bevy event
/// 2. Initializes SequencerState with beats from the Ashveil scenario
/// 3. Advances the SequencerState based on simulation ticks
/// 4. Drains PendingBeat from the sequencer and converts them to Bevy events
/// 5. Syncs core state to UI Bevy resources for panel display
pub struct SimBridgePlugin;

impl Plugin for SimBridgePlugin {
    fn build(&self, app: &mut App) {
        // Register BeatEvent as a Bevy event
        app
            // Initialize SequencerState marker
            .init_resource::<SequencerInitialized>()
            .init_resource::<crate::ui::resources::WorldIntegrity>()
            // Add the system set
            .configure_sets(Update, SimBridgeSet.after(tick_simulation_systems))
            // Add systems to the set
            .add_systems(
                Startup,
                (
                    init_sequencer_state,
                    init_ui_resources,
                ),
            )
            .add_systems(
                Update,
                (
                    advance_sequencer.in_set(SimBridgeSet),
                    drain_pending_beats.in_set(SimBridgeSet),
                    sync_demo_phase.in_set(SimBridgeSet),
                    sync_tick_counter.in_set(SimBridgeSet),
                    sync_completion.in_set(SimBridgeSet),
                    sync_regions.in_set(SimBridgeSet),
                    sync_catastrophes.in_set(SimBridgeSet),
                    sync_npc_details.in_set(SimBridgeSet),
                    sync_npc_predictions.in_set(SimBridgeSet),
                    sync_world_integrity.in_set(SimBridgeSet),
                ),
            );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_demo_core::beat::{Beat, BeatId, DemoPhase};

    /// Test that BeatEvent can be created and has the expected fields.
    #[test]
    fn test_beat_event_creation() {
        let beat = Beat::new(
            BeatId::new(1),
            "Test Beat",
            100,
            Some("Test description"),
            true,
            anvil_demo_core::beat::BeatData::Empty,
        );

        let event = BeatEvent {
            beat: beat.clone(),
            queued_tick: 100,
            data: anvil_demo_core::beat::BeatData::Empty,
        };

        assert_eq!(event.beat.id.get(), 1);
        assert_eq!(event.queued_tick, 100);
        assert!(matches!(event.data, anvil_demo_core::beat::BeatData::Empty));
    }

    /// Test that DemoPhase conversions work.
    #[test]
    fn test_demo_phase_conversions() {
        assert_eq!(DemoPhase::from_tick(0), DemoPhase::Dawn);
        assert_eq!(DemoPhase::from_tick(100), DemoPhase::Dawn);
        assert_eq!(DemoPhase::from_tick(270), DemoPhase::RidgeStreamIn);
        assert_eq!(DemoPhase::from_tick(600), DemoPhase::SenneSeesFire);
        assert_eq!(DemoPhase::from_tick(780), DemoPhase::FireArrives);
        assert_eq!(DemoPhase::from_tick(1800), DemoPhase::SettlementResponse);
        assert_eq!(DemoPhase::from_tick(2400), DemoPhase::DaksFear);
        assert_eq!(DemoPhase::from_tick(2700), DemoPhase::Rain);
        assert_eq!(DemoPhase::from_tick(3000), DemoPhase::Determinism);
        assert_eq!(DemoPhase::from_tick(3300), DemoPhase::AshveilStands);
        assert_eq!(DemoPhase::from_tick(3600), DemoPhase::AshveilStands);
    }
}
