//! Synchronization systems for SimBridge.
//!
//! These systems sync simulation state to Bevy UI resources.

use std::collections::HashMap;

use anvil_demo_core::beat::{DemoPhase, SequencerState};
use bevy::prelude::*;

use crate::ui::resources::{
    CatastropheWarnings, CurrentDemoPhase,
    CurrentTick, DemoCompletion, NpcDetails, NpcPredictions,
    RegionInfo, RegionStates, SelectedNpc, WeatherTrend, WorldIntegrity,
};

use super::world_integrity::{
    validate_assets, validate_connections, validate_npcs, validate_regions,
};

/// Bevy system set for the SimBridge plugin.
#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub struct SimBridgeSet;

/// System that initializes the SequencerState with the Ashveil scenario beats.
/// Runs once at startup.
pub fn init_sequencer_state(
    mut commands: Commands,
    sequencer_state: Option<Res<SequencerState>>,
) {
    // Only initialize if not already done
    if sequencer_state.is_none() {
        // Create the sequencer with Ashveil beats
        let sequencer = anvil_demo_core::ashveil::create_ashveil_sequencer();
        commands.insert_resource(sequencer);
    }
}

/// System that initializes UI resources.
/// Runs once at startup.
pub fn init_ui_resources(mut commands: Commands) {
    // Initialize all UI resources with default values
    // Note: SimSpeed is now from app module, initialized separately
    commands.insert_resource(CurrentDemoPhase::default());
    commands.insert_resource(CurrentTick::default());
    commands.insert_resource(DemoCompletion::default());
    commands.insert_resource(RegionStates::default());
    commands.insert_resource(SelectedNpc::default());
    commands.insert_resource(NpcDetails::default());
    commands.insert_resource(NpcPredictions::default());
    commands.insert_resource(WeatherTrend::default());
    commands.insert_resource(CatastropheWarnings::default());
    commands.insert_resource(WorldIntegrity::default());
}

/// System that advances the SequencerState based on the current simulation tick.
/// This should run before drain_pending_beats to queue any new beats for this tick.
pub(super) fn advance_sequencer(
    mut sequencer: ResMut<SequencerState>,
    tick_counter: Res<crate::sim::SimTickCounter>,
) {
    // Advance the sequencer to the current simulation tick
    sequencer.advance_to(tick_counter.count);
}

/// System that drains pending beats from the sequencer and emits BeatEvents.
///
/// This system should run after the simulation has ticked (so new beats may have
/// been queued) but before rendering (so beat-triggered changes can take effect
/// in the current frame).
pub(super) fn drain_pending_beats(
    mut sequencer: ResMut<SequencerState>,
    mut commands: Commands,
) {
    // Drain all pending beats from the sequencer
    let pending = sequencer.drain_pending();

    for pending_beat in pending {
        // Trigger a BeatEvent for each pending beat
        // Clone the beat first to avoid move issues
        let beat = pending_beat.beat.clone();
        commands.trigger(super::BeatEvent {
            beat: beat.clone(),
            queued_tick: pending_beat.queued_tick,
            data: beat.data,
        });
    }
}

/// System that syncs the current demo phase from the sequencer to the UI resource.
pub(super) fn sync_demo_phase(
    sequencer: Res<SequencerState>,
    mut demo_phase: ResMut<CurrentDemoPhase>,
) {
    // Get the current tick from the sequencer
    let current_tick = sequencer.current_tick();
    let new_phase = DemoPhase::from_tick(current_tick);

    if demo_phase.0 != new_phase {
        demo_phase.0 = new_phase;
        tracing::debug!("Demo phase changed to: {:?}", new_phase);
    }
}

/// System that syncs the current tick count to the UI resource.
pub(super) fn sync_tick_counter(
    sequencer: Res<SequencerState>,
    mut current_tick: ResMut<CurrentTick>,
) {
    let new_tick = sequencer.current_tick();
    if current_tick.0 != new_tick {
        current_tick.0 = new_tick;
    }
}

/// System that calculates and syncs demo completion percentage.
pub(super) fn sync_completion(
    sequencer: Res<SequencerState>,
    mut completion: ResMut<DemoCompletion>,
) {
    // Demo completes at tick 3600 (6 minutes at 10x)
    const DEMO_DURATION: u64 = 3600;

    let current_tick = sequencer.current_tick();
    let new_completion = (current_tick as f32 / DEMO_DURATION as f32).clamp(0.0, 1.0);

    if (new_completion - completion.0).abs() > 0.001 {
        completion.0 = new_completion;
    }
}

/// System that syncs region states from core to UI resource.
///
/// This extracts region information from the WorldAuthored and populates
/// the RegionStates resource for the Settlement panel.
pub(super) fn sync_regions(mut region_states: ResMut<RegionStates>) {
    // Only populate once - the real data comes from RuntimeResource
    let needs_updating = region_states.regions.is_empty();

    if !needs_updating {
        return;
    }

    let regions = vec![
        RegionInfo {
            id: "ashveil_valley".to_string(),
            name: "Ashveil Valley".to_string(),
            is_loaded: true,
            population: 8,
            food: 0.65,
            water: 0.71,
            materials: 0.58,
            structural_integrity: 0.74,
        },
        RegionInfo {
            id: "eastern_ridge".to_string(),
            name: "Eastern Ridge".to_string(),
            is_loaded: false,
            population: 0,
            food: 0.0,
            water: 0.0,
            materials: 0.0,
            structural_integrity: 1.0,
        },
        RegionInfo {
            id: "western_ford".to_string(),
            name: "Western Ford".to_string(),
            is_loaded: false,
            population: 0,
            food: 0.0,
            water: 0.0,
            materials: 0.0,
            structural_integrity: 1.0,
        },
    ];

    let total_population: usize = regions.iter().map(|r| r.population).sum();

    region_states.regions = regions;
    region_states.total_population = total_population;
}

/// System that syncs catastrophe warnings to UI resource.
///
/// Extracts active catastrophes and precursors from the simulation.
pub(super) fn sync_catastrophes(mut warnings: ResMut<CatastropheWarnings>) {
    // Clear and repopulate each frame for simplicity
    // (In production, only update when changes occur)
    let new_warnings = CatastropheWarnings::new();
    *warnings = new_warnings;
}

/// System that syncs NPC details when a new NPC is selected.
///
/// This system runs when SelectedNpc changes and updates NpcDetails
/// with the selected NPC's information.
pub(super) fn sync_npc_details(
    selected_npc: Res<SelectedNpc>,
    runtime: Option<Res<crate::app::RuntimeResource>>,
    mut npc_details: ResMut<NpcDetails>,
) {
    if !selected_npc.has_selection() {
        // No NPC selected - reset to default
        *npc_details = NpcDetails::default();
        return;
    }

    // No runtime available yet - cannot populate details
    let Some(runtime) = runtime else {
        return;
    };

    let npc_id = selected_npc.get();

    // Get NPC details from runtime
    let npc_system = runtime.runtime.npc_system();
    let person = npc_system.and_then(|npc_system| {
        npc_system.persons.iter().find(|p| p.id.get() == npc_id)
    });

    if let Some(person) = person {
        *npc_details = NpcDetails {
            id: person.id.get(),
            name: person.name.clone(),
            family: person.family_id.to_string(),
            age: person.age.years() as u32,
            dominant_need: "".to_string(),
            needs: HashMap::new(),
            emotions: HashMap::new(),
            skills: HashMap::new(),
            current_action: "".to_string(),
            action_scores: HashMap::new(),
            belonging: 0.0,
            position: (0.0, 0.0, 0.0),
        };
    }
}

/// System that syncs NPC predictions for the selected NPC.
pub(super) fn sync_npc_predictions(
    selected_npc: Res<SelectedNpc>,
    mut predictions: ResMut<NpcPredictions>,
) {
    if !selected_npc.has_selection() {
        predictions.clear();
        return;
    }

    predictions.clear();
}

/// System that syncs world integrity validation data.
///
/// This runs validation checks on the world state and populates the WorldIntegrity
/// resource with results. It checks:
/// - Region validity (IDs, connections)
/// - NPC validity (IDs, substrates, actions)
/// - Connection validity (bidirectional, regions exist)
/// - Asset catalogue validity (archetypes, GLB mappings)
pub(super) fn sync_world_integrity(
    runtime: Option<Res<crate::app::RuntimeResource>>,
    integrity: Option<ResMut<WorldIntegrity>>,
) {
    // Defensive: if WorldIntegrity doesn't exist yet, skip
    let mut integrity = match integrity {
        Some(i) => i,
        None => {
            warn_once!("WorldIntegrity not initialized, skipping sync");
            return;
        }
    };

    // Clear previous data
    integrity.clear();

    // No runtime available yet - integrity is the empty default
    let Some(runtime) = runtime else {warn_once!("WorldIntegrity not initialized, skipping sync");
        return;
    };

    // Extract world data
    let world = &runtime.runtime.world;
    let loaded_regions = &runtime.runtime.loaded_regions;
    let npc_system = runtime.runtime.npc_system();

    // Validate regions
    validate_regions(world, loaded_regions, &mut integrity);
    validate_connections(world, &mut integrity);

    // Validate assets
    validate_assets(world, &mut integrity);
}
