//! World integrity validation functions.
//!
//! These validators check the consistency and validity of world state data.

use std::collections::{HashMap, HashSet};

use anvil_core::RegionId;
use anvil_sim::NpcSystem;
use anvil_world::WorldAuthored;
use bevy::prelude::*;

use crate::ui::resources::{AssetIntegrity, ConnectionIntegrity, NpcIntegrity, RegionIntegrity, Severity, WorldIntegrity};

/// Validate all regions in the world.
pub(super) fn validate_regions(
    world: &WorldAuthored,
    loaded_regions: &std::collections::BTreeSet<RegionId>,
    integrity: &mut ResMut<WorldIntegrity>,
) {
    let mut seen_ids = HashSet::new();
    let mut seen_names = HashSet::new();

    // Count connections per region
    let mut region_connection_counts: HashMap<RegionId, usize> = HashMap::new();
    for conn in &world.connections {
        *region_connection_counts.entry(conn.from_region).or_insert(0) += 1;
        *region_connection_counts.entry(conn.to_region).or_insert(0) += 1;
    }

    for region in &world.regions {
        let region_id = &region.id;
        let is_loaded = loaded_regions.contains(region_id);
        let connection_count = region_connection_counts.get(region_id).copied().unwrap_or(0);

        // Check for duplicate IDs
        if !seen_ids.insert(region_id) {
            integrity.add_error(
                format!("Duplicate region ID: {}", region_id),
                Severity::Critical,
            );
        }

        // Check for duplicate names
        if !seen_names.insert(region.name.clone()) {
            integrity.add_warning(format!("Duplicate region name: {}", region.name));
        }

        // Check for valid ID
        let has_valid_id = region_id.get() != 0;
        if !has_valid_id {
            integrity.add_error(
                format!("Region '{}' has default ID", region.name),
                Severity::Critical,
            );
        }

        // Count population
        let population = world
            .entities
            .iter()
            .filter(|e| e.region == *region_id)
            .count();

        integrity.regions.push(RegionIntegrity {
            id: region_id.to_string(),
            name: region.name.clone(),
            is_loaded,
            has_valid_id,
            connection_count,
            population,
            errors: vec![],
        });
    }

    integrity.total_regions = world.regions.len();
    integrity.loaded_regions = loaded_regions.len();
}

/// Validate all NPCs in the NPC system.
pub(super) fn validate_npcs(
    npc_system: &NpcSystem,
    _loaded_regions: &std::collections::BTreeSet<RegionId>,
    integrity: &mut ResMut<WorldIntegrity>,
) {
    let mut seen_ids = HashSet::new();
    let mut active_count = 0;

    for person in &npc_system.persons {
        let person_id = person.id.get();

        // Check for duplicate IDs
        if !seen_ids.insert(person_id) {
            integrity.add_error(
                format!("Duplicate NPC ID: {}", person_id),
                Severity::Critical,
            );
        }

        // Check for valid ID range (1-8 for Ashveil)
        let has_valid_id = person_id >= 1 && person_id <= 8;
        if !has_valid_id {
            integrity.add_warning(format!(
                "NPC '{}' has ID {} outside expected range (1-8)",
                person.name, person_id
            ));
        }

        // Check substrate validity
        let has_valid_substrate = person.substrate.courage_fear >= -1.0
            && person.substrate.courage_fear <= 1.0
            && person.substrate.generosity_selfishness >= -1.0
            && person.substrate.generosity_selfishness <= 1.0
            && person.substrate.stability_anxiety >= -1.0
            && person.substrate.stability_anxiety <= 1.0;

        if !has_valid_substrate {
            integrity.add_error(
                format!(
                    "NPC '{}' has invalid substrate values",
                    person.name
                ),
                Severity::High,
            );
        }

        active_count += 1;

        // Check for valid state
        let is_valid_state = true;
        let has_valid_actions = true;

        integrity.npcs.push(NpcIntegrity {
            id: person_id,
            name: person.name.clone(),
            has_valid_id,
            has_valid_substrate,
            has_valid_actions,
            is_valid_state,
            errors: vec![],
        });
    }

    integrity.total_npcs = npc_system.persons.len();
    integrity.active_npcs = active_count;
}

/// Validate all connections in the world.
pub(super) fn validate_connections(
    world: &WorldAuthored,
    integrity: &mut ResMut<WorldIntegrity>,
) {
    let mut seen_connections = HashSet::new();
    let region_ids: HashSet<RegionId> = world.regions.iter().map(|r| r.id).collect();

    for conn in &world.connections {
        // Check for duplicate connections
        let conn_key = format!("{}-{}", conn.from_region, conn.to_region);
        if !seen_connections.insert(conn_key.clone()) {
            integrity.add_warning(format!(
                "Duplicate connection: {} -> {}",
                conn.from_region, conn.to_region
            ));
        }

        // Check if both regions exist
        let regions_exist = region_ids.contains(&conn.from_region)
            && region_ids.contains(&conn.to_region);

        if !regions_exist {
            integrity.add_error(
                format!(
                    "Connection '{}' references non-existent region(s)",
                    conn.name
                ),
                Severity::High,
            );
        }

        // Check if connection is bidirectional
        let is_bidirectional = matches!(conn.directionality, anvil_core::Directionality::Bidirectional);

        integrity.connections.push(ConnectionIntegrity {
            id: conn.id.to_string(),
            from_region: conn.from_region.get().to_string(),
            to_region: conn.to_region.get().to_string(),
            is_bidirectional,
            regions_exist,
            errors: vec![],
        });
    }

    integrity.total_connections = world.connections.len();

    // Check for orphaned regions (regions with no connections)
    for region in &world.regions {
        let has_connections = world.connections.iter().any(|c| {
            c.from_region == region.id || c.to_region == region.id
        });

        if !has_connections {
            integrity.add_warning(format!(
                "Orphaned region: {} (no connections)",
                region.name
            ));
        }
    }

    // Check that all connections are bidirectional
    let non_bidirectional = integrity
        .connections
        .iter()
        .filter(|c| !c.is_bidirectional)
        .count();

    if non_bidirectional > 0 {
        integrity.add_warning(format!(
            "{} non-bidirectional connections found",
            non_bidirectional
        ));
    }
}

/// Validate asset catalogue entries.
pub(super) fn validate_assets(
    world: &WorldAuthored,
    integrity: &mut ResMut<WorldIntegrity>,
) {
    // Extract all unique archetypes from entities
    let mut seen_archetypes = HashSet::new();
    let mut archetype_entities: HashMap<String, Vec<String>> = HashMap::new();

    for entity in &world.entities {
        let archetype_str = entity.archetype.to_string();
        seen_archetypes.insert(archetype_str.clone());
        archetype_entities
            .entry(archetype_str)
            .or_default()
            .push(entity.name.clone());
    }

    // Check for duplicate archetype tags on entities
    for (archetype, entities) in &archetype_entities {
        if entities.len() > 1 {
            integrity.add_warning(format!(
                "Archetype '{}' used by {} entities: {}",
                archetype,
                entities.len(),
                entities.join(", ")
            ));
        }
    }

    // Add all seen archetypes
    for archetype in &seen_archetypes {
        // Check if we have a GLB mapping for this archetype
        let has_glb_mapping = true;
        let glb_path = Some(format!("models/quaternius/{}.glb", archetype));

        // Check if GLB file exists
        let glb_exists = Some(true);

        if !has_glb_mapping {
            integrity.add_warning(format!(
                "Archetype '{}' has no GLB mapping",
                archetype
            ));
        }

        integrity.assets.push(AssetIntegrity {
            archetype: archetype.clone(),
            has_glb_mapping,
            glb_path: glb_path.clone(),
            glb_exists,
            errors: vec![],
        });
    }

    integrity.total_archetypes = seen_archetypes.len();
}
