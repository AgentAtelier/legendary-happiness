//! Plugin and system registration for anvil_demo.
//!
//! This module contains the centralized registration function that adds all
//! plugins, resources, and systems to the Bevy app.

use bevy::prelude::*;

use anvil_bevy::{AnvilAssetPlugin, debug_fallback_summary, AssetOriginTag};
use anvil_bevy::environment::plugin::{EnvironmentPlugin, EnvironmentSet};
use anvil_bevy::sky::SkyPlugin;
use bevy::asset::AssetPlugin;
use bevy::diagnostic::FrameTimeDiagnosticsPlugin;
use bevy::gltf::GltfAssetLabel;
use bevy::log::LogPlugin;
use bevy::pbr::StandardMaterial;
use bevy_egui::{EguiContexts, EguiPlugin, EguiPrimaryContextPass, egui};
// TODO Phase 1: replaced by FpsController
use std::path::{Path, PathBuf};
use tracing::info;

use crate::app::{AppPlugin, AppState, RuntimeResource};
use crate::spawn_sun::spawn_sun;
use crate::sim_bridge::sim_bridge_system;
use anvil_bevy::audio::AudioPlugin;
use crate::audio::AshveilAudioPlugin;
use crate::player::PlayerPlugin;
use crate::world::AtmosphereDriverPlugin;
use crate::camera::{despawn_gltf_cameras, handle_camera_shortcuts, handle_mouse_wheel_zoom, setup_main_camera, update_focus_camera, CameraState};


use crate::catastrophe_panel::{handle_catastrophe_shortcuts, process_pending_catastrophes, render_catastrophe_panel, setup_catastrophe_panel, CatastrophePanelState};
use crate::demo::DemoSequencerPlugin;
use crate::dev_experience::{render_dev_panel, setup_dev_experience, EguiContextsExt};
use crate::event_log::{add_test_events, render_event_log, setup_event_log, EventLog};
use crate::npc::{update_npc_movement, update_npc_rotation_toward_targets};
use crate::npc_visuals::{despawn_npc_visuals, spawn_npc_visuals, update_action_halos, update_npc_breathing_system, update_selection_ring_visibility, update_selection_rings, NpcVisualState};
use crate::oracle_overlay::{render_oracle_overlay, setup_oracle_overlay};
use crate::overlays::{NeedsBarPlugin, SkillFlashPlugin, render_network_line_legend, setup_overlays, update_emotion_lines, update_status_rings, OverlayState};
use crate::performance_panel::{render_performance_panel, setup_performance_panel, PerformancePanelState};
use crate::plugins::SimBridgePlugin;
use crate::rendering::GlbRenderingPlugin;
use crate::scenarios::ScenarioLoaderPlugin;
use crate::sim::{SimRng, SimTickCounter, tick_simulation_systems};
use crate::states::options::{AccessibilityOptions, AudioOptions, DisplayOptions};
use crate::time_travel::{render_time_travel_panel, setup_time_travel};
use crate::ui::config::{apply_loaded_config, load_config, save_config_on_exit};
use crate::ui::controls::{CheckpointState, handle_deliberate_crash, handle_time_controls, update_crash_reporter_context, update_sim_time_hash};
use crate::ui::inspector_panel::InspectorState;
use crate::ui::panel::{handle_toggle_shortcuts, render_toggle_panel, setup_ui_state, SimTime, UiState};
use crate::ui::transitions::{MenuBackdrop, TransitionPlugin};
use crate::ui::{apply_color_blind_mode, apply_ui_scale, apply_ui_theme, setup_oracle, setup_ui_theme, update_window_title, DemoHudPlugin, InspectorPanelPlugin, OraclePlugin, PanelsPlugin, SideReplayPlugin, UiTheme};
use crate::vfx::{DebrisPlugin, FireSpreadPlugin, SmokePlugin, render_screen_edge_indicators, setup_vfx, spawn_event_particles, update_attention_pulse_animations, update_attention_pulses, update_cpu_particles, VfxState};
use crate::world::{setup_full_atmosphere, setup_ground_with_texture, spawn_settlement_visuals, setup::PendingGltfSpawn, settlement::update_settlement_visuals};

use crate::crash_reporter;

// ============================================================================
// Resolve Asset Path
// ============================================================================

/// Resolve the asset directory path with multiple fallback strategies.
///
/// Strategy (in order):
/// 1. If ANVIL_ASSETS env var is set, use that
/// 2. Try to find assets relative to the executable location
/// 3. Try to find assets relative to CARGO_MANIFEST_DIR (dev mode)
/// 4. Try to find assets relative to current working directory
/// 5. Climb up from executable to find repo root (for dev builds)
/// 6. Fall back to "./assets"
fn resolve_asset_path() -> PathBuf {
    if let Ok(asset_path) = std::env::var("ANVIL_ASSETS") {
        let path = PathBuf::from(asset_path);
        info!("Using ANVIL_ASSETS override: {}", path.display());
        return path;
    }
    
    if let Ok(exe_path) = std::env::current_exe() {
        let exe_dir = exe_path.parent().unwrap_or(Path::new("."));
        let candidate = exe_dir.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
        let parent_candidate = exe_dir.parent().map(|p| p.join("assets"));
        if let Some(p) = parent_candidate {
            if p.exists() {
                info!("Found assets at: {}", p.display());
                return p;
            }
        }
        let mut current = exe_dir.to_path_buf();
        for _ in 0..5 {
            current = current.parent().unwrap_or(Path::new(".")).to_path_buf();
            let candidate = current.join("assets");
            if candidate.exists() {
                info!("Found assets at: {}", candidate.display());
                return candidate;
            }
            if current.join("Cargo.toml").exists() {
                let candidate = current.join("assets");
                if candidate.exists() {
                    info!("Found assets at: {}", candidate.display());
                    return candidate;
                }
            }
        }
    }
    
    if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        let mut path = PathBuf::from(manifest_dir);
        for _ in 0..2 {
            if let Some(parent) = path.parent() {
                path = parent.to_path_buf();
            }
        }
        let candidate = path.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    if let Ok(cwd) = std::env::current_dir() {
        let candidate = cwd.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    PathBuf::from("./assets")
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Resource to control debug overlay visibility
#[derive(Resource, Default)]
struct DebugOverlayVisible(bool);

/// Transition from Loading to InGame once runtime exists
fn transition_to_running(
    runtime: Option<Res<RuntimeResource>>,
    mut app_state: ResMut<NextState<AppState>>,
) {
    if runtime.is_some() {
        app_state.set(AppState::InGame);
    }
}

/// Toggle debug overlay visibility when tilde (backtick) is pressed
fn toggle_debug_overlay(
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut debug_visible: ResMut<DebugOverlayVisible>,
) {
    if keyboard_input.just_pressed(KeyCode::Backquote) {
        debug_visible.0 = !debug_visible.0;
    }
}

/// Setup system that initializes the world
#[allow(unused_mut)]
fn setup(
    mut commands: Commands,
    mut materials: ResMut<Assets<StandardMaterial>>,
    asset_server: Res<AssetServer>,
) {
    crate::world::setup::setup_world(commands, materials, asset_server);
}

/// Spawn pending GLTF entities
fn spawn_pending_gltfs(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    pending: Query<(Entity, &PendingGltfSpawn)>,
) {
    for (entity, pending) in pending.iter() {
        let scene_handle = asset_server.load(
            GltfAssetLabel::Scene(0).from_asset(pending.path.clone())
        );
        commands.spawn((
            SceneRoot(scene_handle),
            Transform::from_xyz(pending.position.x, pending.position.y, pending.position.z),
            AssetOriginTag(pending.origin.clone()),
        ));
        commands.entity(entity).despawn();
    }
}

/// Debug overlay rendering system
fn debug_overlay(
    mut egui_contexts: EguiContexts,
    query: Query<&AssetOriginTag>,
    runtime: Res<RuntimeResource>,
    tick_counter: Res<SimTickCounter>,
    sim_time: Res<SimTime>,
    debug_visible: Res<DebugOverlayVisible>,
) {
    if !debug_visible.0 {
        return;
    }
    let (total, fallback_count) = debug_fallback_summary(&query);

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::Window::new("Anvil Debug Overlay").show(ctx, |ui| {
            ui.label(format!("Assets rendered: {}", total));
            ui.label(format!(
                "Using fallback: {} {}",
                fallback_count,
                if fallback_count > 0 { "\u{26a0}" } else { "\u{2705}" }
            ));
            if fallback_count > 0 {
                ui.colored_label(egui::Color32::YELLOW, "Some assets are using fallback materials.");
            }
            ui.label(format!("Runtime: {} loaded regions", runtime.runtime.loaded_regions.len()));
            ui.label(format!("State hash: {}", sim_time.hash));

            ui.separator();
            ui.label("Phase 3 Systems:");
            ui.label(format!(
                "  NPC System: {} persons, {} settlements",
                runtime.runtime.npc_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.npc_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Catastrophe System: {} active events",
                runtime.runtime.catastrophe_system().map_or(0, |s| s.active_events.len())
            ));
            ui.label(format!(
                "  Joy System: {} persons, {} settlements",
                runtime.runtime.joy_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.joy_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Physics System: {} rigid bodies",
                runtime.runtime.physics_system().map_or(0, |s| s.rigid_body_set.len())
            ));
            ui.separator();
            ui.label(format!("Sim Tick: {}", tick_counter.count));
        });
    }
}

// ============================================================================
// Plugin Registration
// ============================================================================

/// Register all demo plugins, resources, and systems with the Bevy app.
pub fn register_demo_plugins(app: &mut App) {
    let asset_path = resolve_asset_path();
    let asset_path_str = asset_path.to_string_lossy().into_owned();

    app
        .add_plugins(DefaultPlugins.set(AssetPlugin {
            file_path: asset_path_str,
            ..default()
        }).disable::<LogPlugin>())
        .init_state::<AppState>()
        .add_plugins(EguiPlugin::default())
        .add_plugins(AnvilAssetPlugin)
        .add_plugins(PlayerPlugin)
        .add_plugins(AtmosphereDriverPlugin)
        .add_plugins((
            AudioPlugin,
            AshveilAudioPlugin,
        ))
        .add_plugins((
            EnvironmentPlugin,
            SkyPlugin,
        ))
        .add_plugins(AppPlugin)
        .add_plugins(TransitionPlugin)
        .add_plugins(ScenarioLoaderPlugin)
        .add_plugins(SimBridgePlugin)
        .add_plugins(DemoSequencerPlugin)
        .add_plugins(GlbRenderingPlugin)
        .add_plugins(FireSpreadPlugin)
        .add_plugins(SmokePlugin)
        .add_plugins(DebrisPlugin)
        .add_plugins(NeedsBarPlugin)
        .add_plugins(SkillFlashPlugin)
        .add_plugins(DemoHudPlugin)
        .add_plugins(InspectorPanelPlugin)
        .add_plugins(PanelsPlugin)
        .add_plugins(SideReplayPlugin)
        .add_plugins(OraclePlugin)
        .add_plugins(FrameTimeDiagnosticsPlugin::default())
        .init_resource::<SimTickCounter>()
        .init_resource::<SimRng>()
        .init_resource::<UiState>()
        .init_resource::<SimTime>()
        .init_resource::<CheckpointState>()
        .init_resource::<DisplayOptions>()
        .init_resource::<AudioOptions>()
        .init_resource::<AccessibilityOptions>()
        .init_resource::<CameraState>()
        .init_resource::<EventLog>()
        .init_resource::<CatastrophePanelState>()
        .init_resource::<InspectorState>()
        .init_resource::<PerformancePanelState>()
        .init_resource::<NpcVisualState>()
        .init_resource::<OverlayState>()
        .init_resource::<UiTheme>()
        .init_resource::<VfxState>()
        .init_resource::<DebugOverlayVisible>()
        .init_resource::<MenuBackdrop>()
        .add_systems(Startup, (
            setup,
            load_config,
            setup_ui_state,
            setup_main_camera,
            setup_event_log,
            setup_catastrophe_panel,
            setup_performance_panel,
            setup_overlays,
            setup_time_travel,
            setup_oracle_overlay,
            setup_oracle,
            setup_vfx,
            setup_dev_experience,
            setup_ui_theme,
            spawn_sun,
            crash_reporter::startup_update_last_session,
        ))
        .add_systems(OnEnter(AppState::Loading), (
            setup_full_atmosphere,
            setup_ground_with_texture,
            spawn_settlement_visuals,
        ))
        .add_systems(Startup, apply_loaded_config.after(setup_ui_state))
        .add_systems(PreUpdate, crate::world::decorate_new_cameras)
        .add_systems(PreUpdate, (apply_ui_theme, apply_ui_scale, apply_color_blind_mode))
        .add_systems(PreUpdate, update_window_title)
        .configure_sets(PreUpdate, (
            EnvironmentSet::Bridge,
            EnvironmentSet::Interpolate,
            EnvironmentSet::Apply,
        ).chain())
        .add_systems(PreUpdate, (
            sim_bridge_system
                .in_set(EnvironmentSet::Bridge)
                .run_if(resource_exists::<RuntimeResource>),
        ))
        .add_systems(PreUpdate, (
            handle_camera_shortcuts,
        ))
        .add_systems(PostUpdate, despawn_gltf_cameras)
        .add_systems(Update, (
            tick_simulation_systems.run_if(resource_exists::<RuntimeResource>),
            spawn_pending_gltfs,
            process_pending_catastrophes.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulses.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulse_animations,
            update_cpu_particles,
            spawn_event_particles.run_if(resource_exists::<RuntimeResource>),
            despawn_npc_visuals,
            update_emotion_lines,
            update_status_rings,
            update_settlement_visuals.run_if(resource_exists::<RuntimeResource>),
            update_npc_breathing_system,
            update_npc_rotation_toward_targets,
            update_npc_movement,
            update_selection_rings,
            update_selection_ring_visibility,
        ).run_if(in_state(AppState::InGame)))
        .add_systems(Update, (
            handle_toggle_shortcuts,
            handle_time_controls.run_if(resource_exists::<RuntimeResource>.and(resource_exists::<crate::app::WorldResource>)),
            handle_catastrophe_shortcuts,
            add_test_events,
        ))
        .add_systems(Last, (
            update_focus_camera,
            save_config_on_exit,
        ))
        .add_systems(Update, (
            handle_mouse_wheel_zoom,
            update_action_halos,
        ))
        .add_systems(Update, spawn_npc_visuals
            .after(tick_simulation_systems)
            .run_if(in_state(AppState::InGame))
            .run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(Update, (
            transition_to_running.run_if(in_state(AppState::Loading)),
        ))
        .add_systems(Update, (
            toggle_debug_overlay,
        ))
        .add_systems(PreUpdate, update_sim_time_hash.run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(PreUpdate, update_crash_reporter_context)
        .add_systems(PreUpdate, handle_deliberate_crash)
        .add_systems(EguiPrimaryContextPass, (render_toggle_panel, render_event_log, render_catastrophe_panel, render_performance_panel, render_time_travel_panel, render_oracle_overlay, render_dev_panel, debug_overlay.run_if(resource_exists::<RuntimeResource>), render_network_line_legend, render_screen_edge_indicators.run_if(resource_exists::<RuntimeResource>)));
}
