//! Event Log module for displaying simulation events.
//!
//! This module provides a bottom-left scrolling panel that displays
//! timestamped simulation events with color-coding and filter toggles.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};
use serde::{Deserialize, Serialize};

use crate::crash_reporter;
use crate::sim::SimTickCounter;
use crate::ui::panel::UiState;

/// Resource containing the event log entries.
#[derive(Resource, Default)]
pub struct EventLog {
    /// List of all events in chronological order.
    pub entries: Vec<EventEntry>,
    /// Maximum number of entries to keep.
    pub max_entries: usize,
    /// Filter flags for each event category.
    pub filters: EventFilters,
}

/// A single event log entry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventEntry {
    /// The simulation tick when this event occurred.
    pub tick: u64,
    /// The event message.
    pub message: String,
    /// The event category for color-coding.
    pub category: EventCategory,
}

/// Event categories for color-coding.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum EventCategory {
    /// Environment events (flood detected, weather changes).
    Environment,
    /// NPC action events (action switched, action completed).
    NpcAction,
    /// Skill events (affordance unlocked, practice).
    Skill,
    /// Social events (connection formed, teaching).
    Social,
    /// Catastrophe events (flood, fire, earthquake).
    Catastrophe,
    /// Joy events (catalyst events, celebrations).
    Joy,
    /// Death events.
    Death,
}

impl EventCategory {
    /// Returns the display name for this category.
    pub fn name(&self) -> &'static str {
        match self {
            EventCategory::Environment => "Env",
            EventCategory::NpcAction => "NPC",
            EventCategory::Skill => "Skill",
            EventCategory::Social => "Social",
            EventCategory::Catastrophe => "Cat",
            EventCategory::Joy => "Joy",
            EventCategory::Death => "Death",
        }
    }

    /// Returns the color for this category.
    pub fn color(&self) -> egui::Color32 {
        match self {
            EventCategory::Environment => egui::Color32::BLUE,
            EventCategory::NpcAction => egui::Color32::WHITE,
            EventCategory::Skill => egui::Color32::GREEN,
            EventCategory::Social => egui::Color32::GOLD,
            EventCategory::Catastrophe => egui::Color32::RED,
            EventCategory::Joy => egui::Color32::YELLOW,
            EventCategory::Death => egui::Color32::DARK_RED,
        }
    }
}

/// Filter state for event categories.
#[derive(Default)]
pub struct EventFilters {
    pub environment: bool,
    pub npc_action: bool,
    pub skill: bool,
    pub social: bool,
    pub catastrophe: bool,
    pub joy: bool,
    pub death: bool,
}

impl EventFilters {
    /// Creates a new EventFilters with all categories enabled.
    pub fn all_enabled() -> Self {
        Self {
            environment: true,
            npc_action: true,
            skill: true,
            social: true,
            catastrophe: true,
            joy: true,
            death: true,
        }
    }

    /// Returns whether an event category is enabled.
    pub fn is_enabled(&self, category: EventCategory) -> bool {
        match category {
            EventCategory::Environment => self.environment,
            EventCategory::NpcAction => self.npc_action,
            EventCategory::Skill => self.skill,
            EventCategory::Social => self.social,
            EventCategory::Catastrophe => self.catastrophe,
            EventCategory::Joy => self.joy,
            EventCategory::Death => self.death,
        }
    }


}

impl EventLog {
    /// Creates a new EventLog with default settings.
    pub fn new(max_entries: usize) -> Self {
        Self {
            entries: Vec::new(),
            max_entries,
            filters: EventFilters::all_enabled(),
        }
    }

    /// Adds a new event to the log.
    pub fn add_event(&mut self, tick: u64, message: String, category: EventCategory) {
        self.entries.push(EventEntry {
            tick,
            message: message.clone(),
            category,
        });

        // Trim to max entries
        if self.entries.len() > self.max_entries {
            self.entries.remove(0);
        }

        // Record event for crash reporter
        crash_reporter::record_event(
            tick,
            message,
            format!("{:?}", category),
        );
    }

    /// Returns filtered events based on current filter settings.
    pub fn filtered_entries(&self) -> Vec<&EventEntry> {
        self.entries
            .iter()
            .filter(|e| self.filters.is_enabled(e.category))
            .collect()
    }
}

/// System that sets up the event log.
pub fn setup_event_log(mut commands: Commands) {
    commands.insert_resource(EventLog::new(1000));
}

/// Extension trait to provide try_ctx_mut for compatibility
trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// System that renders the event log panel.
pub fn render_event_log(
    mut egui_contexts: EguiContexts,
    mut event_log: ResMut<EventLog>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_event_log {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Animate panel appearance using animate_bool (Phase 3e)
        let _animated = ctx.animate_bool(egui::Id::new("event_log_panel"), true);
        
        // Left panel (combined with performance in the layout spec)
        // For now, render as a left side panel
        egui::SidePanel::left("event_log_panel")
            .default_width(280.0)
            .resizable(false)
            .show(ctx, |ui: &mut egui::Ui| {
                // Panel title and filter toggles
                ui.heading("Event Log");
                ui.separator();
                
                // Filter toggle buttons
                ui.horizontal(|ui| {
                    // Create mutable array of filter references
                    let filters = &mut event_log.filters;
                    let mut categories = [
                        (EventCategory::Environment, &mut filters.environment),
                        (EventCategory::NpcAction, &mut filters.npc_action),
                        (EventCategory::Skill, &mut filters.skill),
                        (EventCategory::Social, &mut filters.social),
                        (EventCategory::Catastrophe, &mut filters.catastrophe),
                        (EventCategory::Joy, &mut filters.joy),
                        (EventCategory::Death, &mut filters.death),
                    ];

                    for (category, filter) in categories.iter_mut() {
                        let _color = if **filter {
                            category.color()
                        } else {
                            egui::Color32::DARK_GRAY
                        };
                        if ui.button(category.name()).clicked() {
                            **filter = !**filter;
                        }
                    }
                });

                ui.separator();

                // Scrolling event list
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .max_height(200.0)
                    .show(ui, |ui| {
                        let filtered = event_log.filtered_entries();
                        for entry in filtered {
                            let color = if event_log.filters.is_enabled(entry.category) {
                                entry.category.color()
                            } else {
                                egui::Color32::DARK_GRAY
                            };
                            
                            ui.colored_label(color, format!("[tick {}] {}", entry.tick, entry.message));
                        }
                    });
            });
    }
}

/// System that adds a test event for demonstration.
/// 
/// In a full implementation, this would be replaced by actual event
/// emission from the simulation systems.
pub fn add_test_events(
    mut event_log: ResMut<EventLog>,
    tick_counter: Res<SimTickCounter>,
) {
    // Add a test event every 100 ticks for demonstration
    if tick_counter.count.is_multiple_of(100) && tick_counter.count > 0 {
        let messages: Vec<(&str, EventCategory)> = vec![
            ("Flood precursor detected (region 2)", EventCategory::Environment),
            ("NPC Maren switched action: Farm -> Repair", EventCategory::NpcAction),
            ("Affordance unlocked: NPC Brynn — soil_moisture_reading", EventCategory::Skill),
            ("NPC Aldric formed connection with NPC Brynn", EventCategory::Social),
            ("Flood catastrophe triggered in region 2", EventCategory::Catastrophe),
            ("CatalystEvent: Harvest Feast — settlement 1", EventCategory::Joy),
            ("NPC Old Tom died of starvation", EventCategory::Death),
        ];

        let idx = ((tick_counter.count / 100) % messages.len() as u64) as usize;
        let (message, category) = messages[idx];
        event_log.add_event(tick_counter.count, message.to_string(), category);
    }
}
