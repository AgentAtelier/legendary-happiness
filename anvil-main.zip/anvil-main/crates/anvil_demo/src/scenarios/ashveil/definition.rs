//! Ashveil scenario definition.

use super::super::{CatastropheType, ScenarioDefinition};

/// Returns the Ashveil scenario definition.
pub fn scenario() -> ScenarioDefinition {
    ScenarioDefinition {
        id: "ashveil".to_string(),
        name: "Ashveil at Dawn".to_string(),
        description: "A wildfire crests the eastern ridge at dawn.".to_string(),
        seed: 0x4D3219AFDEADBEEF,
        catastrophe: CatastropheType::Wildfire,
        npc_count: 8,
        initial_food: 0.65,
        initial_water: 0.71,
        initial_materials: 0.58,
        initial_structural_integrity: 0.74,
    }
}
