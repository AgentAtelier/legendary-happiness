//! Ashveil scenario metadata for the loader UI.
//!
//! The actual world, NPCs, and sequencer live in `anvil_demo_core::ashveil`.
//! This module only carries the `ScenarioDefinition` for the loader screen.

pub use definition::scenario;

mod definition;
