//! Random Seed scenario - A fresh, unpredictable world.

use super::{CatastropheType, ScenarioDefinition};
use std::time::{SystemTime, UNIX_EPOCH};

/// Generate a random seed from system entropy.
pub fn random_seed() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
        .wrapping_mul(123456789)
        .wrapping_add(987654321)
}

pub fn scenario() -> ScenarioDefinition {
    let seed = random_seed();
    ScenarioDefinition {
        id: "random".to_string(),
        name: "Random Seed".to_string(),
        description: "A fresh, unpredictable world".to_string(),
        seed,
        catastrophe: CatastropheType::Random,
        npc_count: 15,
        initial_food: 0.7,
        initial_water: 0.7,
        initial_materials: 0.7,
        initial_structural_integrity: 0.8,
    }
}
