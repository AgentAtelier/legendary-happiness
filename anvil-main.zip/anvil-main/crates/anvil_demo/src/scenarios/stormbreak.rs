//! Stormbreak scenario - A coastal village threatened by rising waters.

use super::{CatastropheType, ScenarioDefinition};

pub fn scenario() -> ScenarioDefinition {
    ScenarioDefinition {
        id: "stormbreak".to_string(),
        name: "Stormbreak".to_string(),
        description: "A coastal village threatened by rising waters".to_string(),
        seed: 12345,
        catastrophe: CatastropheType::Flood,
        npc_count: 14,
        initial_food: 0.8,
        initial_water: 0.7,
        initial_materials: 0.7,
        initial_structural_integrity: 0.7,
    }
}
