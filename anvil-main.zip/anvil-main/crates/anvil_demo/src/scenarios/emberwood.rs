//! Emberwood scenario - A forest community on the brink of disaster.

use super::{CatastropheType, ScenarioDefinition};

pub fn scenario() -> ScenarioDefinition {
    ScenarioDefinition {
        id: "emberwood".to_string(),
        name: "Emberwood".to_string(),
        description: "A forest community on the brink of wildfire".to_string(),
        seed: 67890,
        catastrophe: CatastropheType::Wildfire,
        npc_count: 13,
        initial_food: 0.6,
        initial_water: 0.8,
        initial_materials: 0.8,
        initial_structural_integrity: 0.7,
    }
}
