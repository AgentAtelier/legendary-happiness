//! Greyridge scenario - A highland settlement faces water scarcity.

use super::{CatastropheType, ScenarioDefinition};

pub fn scenario() -> ScenarioDefinition {
    ScenarioDefinition {
        id: "greyridge".to_string(),
        name: "Greyridge".to_string(),
        description: "A highland settlement faces water scarcity".to_string(),
        seed: 42,
        catastrophe: CatastropheType::Drought,
        npc_count: 15,
        initial_food: 0.7,
        initial_water: 0.8,
        initial_materials: 0.6,
        initial_structural_integrity: 0.8,
    }
}
