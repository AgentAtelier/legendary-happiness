//! Frostpeak scenario - A mountain settlement braces for extreme cold.

use super::{CatastropheType, ScenarioDefinition};

pub fn scenario() -> ScenarioDefinition {
    ScenarioDefinition {
        id: "frostpeak".to_string(),
        name: "Frostpeak".to_string(),
        description: "A mountain settlement braces for extreme cold".to_string(),
        seed: 98765,
        catastrophe: CatastropheType::Blizzard,
        npc_count: 12,
        initial_food: 0.8,
        initial_water: 0.6,
        initial_materials: 0.7,
        initial_structural_integrity: 0.8,
    }
}
