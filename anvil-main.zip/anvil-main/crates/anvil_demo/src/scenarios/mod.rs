//! Scenario definitions for the Application Shell Sprint.
//!
//! Each scenario defines:
//! - name
//! - description
//! - seed
//! - catastrophe type
//! - NPC count
//! - initial resource levels

use bevy::prelude::*;
use serde::{Deserialize, Serialize};

pub mod ashveil;
pub mod emberwood;
pub mod frostpeak;
pub mod greyridge;
pub mod loader;
pub mod random;
pub mod stormbreak;

pub use loader::ScenarioLoaderPlugin;

/// Scenario configuration
#[derive(Resource, Clone, Debug)]
pub struct ScenarioConfig {
    /// All available scenarios
    pub scenarios: Vec<ScenarioDefinition>,
}

/// A single scenario definition
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ScenarioDefinition {
    /// Unique identifier
    pub id: String,
    /// Display name
    pub name: String,
    /// Description
    pub description: String,
    /// Seed for deterministic generation
    pub seed: u64,
    /// Catastrophe type for auto-demo
    pub catastrophe: CatastropheType,
    /// Number of NPCs
    pub npc_count: usize,
    /// Initial resource levels (0.0 to 1.0)
    pub initial_food: f32,
    pub initial_water: f32,
    pub initial_materials: f32,
    pub initial_structural_integrity: f32,
}

/// Type of catastrophe for the scenario
#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum CatastropheType {
    /// No catastrophe (random after 30 seconds)
    Random,
    /// Drought
    Drought,
    /// Flood
    Flood,
    /// Wildfire
    Wildfire,
    /// Blizzard
    Blizzard,
}

impl Default for ScenarioConfig {
    fn default() -> Self {
        Self {
            scenarios: vec![
                ashveil::scenario(),
                greyridge::scenario(),
                stormbreak::scenario(),
                emberwood::scenario(),
                frostpeak::scenario(),
                random::scenario(),
            ],
        }
    }
}

impl ScenarioConfig {
    /// Get a scenario by ID
    #[allow(dead_code)]
    pub fn get(&self, id: &str) -> Option<&ScenarioDefinition> {
        self.scenarios.iter().find(|s| s.id == id)
    }
}
