//! Scenario loading system for the Application Shell Sprint.
//!
//! This module provides systems to load scenarios asynchronously or step-by-step,
//! with progress reporting for the loading screen.

use bevy::prelude::*;
use anvil_assets::prelude::*;
use anvil_assembly::compile_plan;
use anvil_core::repo_path;
use anvil_runtime::{Runtime, RuntimeCommand};
use anvil_world::compile_world;

use crate::scenarios::{ScenarioConfig, ScenarioDefinition, CatastropheType};
use crate::app::{AppState, ScenarioSelection};
use crate::states::options::AssetOptions;

/// Resource to track scenario loading progress.
#[derive(Resource, Default)]
pub struct ScenarioLoader {
    /// Current loading stage (0-3 for 4 stages)
    pub current_stage: usize,
    /// Total stages
    pub total_stages: usize,
    /// Current stage progress (0.0 to 1.0)
    pub stage_progress: f32,
    /// Current status message
    pub status: String,
    /// Whether loading is complete
    pub is_complete: bool,
    /// The loaded world runtime (if loading is complete)
    pub runtime: Option<Runtime>,
    /// The compiled world
    pub world: Option<anvil_world::WorldAuthored>,
    /// The assembly plan
    pub plan: Option<anvil_assembly::AssemblyPlan>,
    /// The scenario definition being loaded
    pub scenario: Option<ScenarioDefinition>,
    /// Timer for stage transitions
    pub stage_timer: Timer,
}

/// Loading stages with their names.
const LOADING_STAGES: &[&str] = &[
    "Generating terrain...",
    "Spawning NPCs...",
    "Building connections...",
    "Stabilising simulation...",
];

impl ScenarioLoader {
    /// Start loading a scenario.
    pub fn start_loading(&mut self, scenario: ScenarioDefinition) {
        self.current_stage = 0;
        self.total_stages = LOADING_STAGES.len();
        self.stage_progress = 0.0;
        self.status = LOADING_STAGES[0].to_string();
        self.is_complete = false;
        self.runtime = None;
        self.world = None;
        self.plan = None;
        self.scenario = Some(scenario);
        self.stage_timer = Timer::from_seconds(0.5, TimerMode::Once);
    }

    /// Get overall progress (0.0 to 1.0).
    pub fn progress(&self) -> f32 {
        if self.is_complete {
            return 1.0;
        }
        let stage_fraction = self.current_stage as f32 / self.total_stages as f32;
        let stage_contribution = self.stage_progress / self.total_stages as f32;
        stage_fraction + stage_contribution
    }

    /// Advance to the next stage.
    pub fn advance_stage(&mut self) {
        self.current_stage += 1;
        if self.current_stage >= self.total_stages {
            self.current_stage = self.total_stages - 1;
            self.stage_progress = 1.0;
            self.status = "Complete!".to_string();
            self.is_complete = true;
        } else {
            self.stage_progress = 0.0;
            self.status = LOADING_STAGES[self.current_stage].to_string();
            self.stage_timer.reset();
        }
    }
}

/// System to initiate scenario loading when entering Loading state.
pub fn start_scenario_loading(
    mut loader: ResMut<ScenarioLoader>,
    scenario_selection: Res<ScenarioSelection>,
    scenario_config: Res<ScenarioConfig>,
) {
    // Find the selected scenario
    if let Some(scenario_def) = scenario_config.scenarios.iter()
        .find(|s| s.id == scenario_selection.scenario_id) {
        loader.start_loading(scenario_def.clone());
    } else {
        // Fallback to default scenario
        loader.start_loading(scenario_config.scenarios[0].clone());
    }
}

/// System to update scenario loading progress.
/// This simulates the loading process with discrete stages.
/// In a full implementation, this would actually load the world asynchronously.
pub fn update_scenario_loading(
    time: Res<Time>,
    mut loader: ResMut<ScenarioLoader>,
    mut app_state: ResMut<NextState<AppState>>,
) {
    if loader.is_complete {
        return;
    }

    // Tick the stage timer
    loader.stage_timer.tick(time.delta());
    
    // Update stage progress based on timer
    if loader.stage_timer.is_finished() {
        loader.advance_stage();
    } else {
        loader.stage_progress = loader.stage_timer.fraction();
    }

    // When loading is complete, transition to InGame
    if loader.is_complete {
        app_state.set(AppState::InGame);
    }
}

/// System to perform actual world loading for the current scenario.
/// This runs alongside the progress simulation and actually loads the world.
/// For now, it loads a default world based on the scenario seed.
pub fn load_scenario_world(
    mut loader: ResMut<ScenarioLoader>,
    asset_options: Res<AssetOptions>,
) {
    // Only load if we have a scenario and haven't loaded yet
    let Some(scenario) = loader.scenario.as_ref() else {
        return;
    };

    // Only load once per scenario
    if loader.world.is_some() {
        return;
    }

    // Load catalogue - use CC0 catalogue if enabled
    let catalogue_path = if asset_options.use_cc0_assets {
        repo_path!("assets/catalogue_cc0.json")
    } else {
        repo_path!("assets/catalogue.json")
    };
    
    let catalogue = match AssetCatalogue::load(&catalogue_path, None) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("Failed to load catalogue from {}: {}", catalogue_path.display(), e);
            // Fall back to default catalogue
            let fallback_path = repo_path!("assets/catalogue.json");
            match AssetCatalogue::load(&fallback_path, None) {
                Ok(c) => c,
                Err(e2) => {
                    eprintln!("Failed to load fallback catalogue: {}", e2);
                    return;
                }
            }
        }
    };

    // Create world specs based on scenario
    let specs = scenario_specs(scenario);
    let connections = vec![]; // No connections for now

    // Compile world
    match compile_world(&specs, &connections, &catalogue) {
        Ok(world) => {
            loader.world = Some(world.clone());
            
            // Create runtime
            let mut runtime = Runtime::new(world.clone());
            
            // Load the first region
            if !world.regions.is_empty() {
                let region_id = world.regions[0].id;
                if let Err(e) = runtime.apply(&RuntimeCommand::LoadRegion { id: region_id }) {
                    eprintln!("Failed to load region: {}", e);
                }
            }
            
            loader.runtime = Some(runtime);
            
            // Compile assembly plan
            if let Ok(plan) = compile_plan(&world) {
                loader.plan = Some(plan);
            }
        }
        Err(e) => {
            eprintln!("Failed to compile world: {:?}", e);
        }
    }
}

/// Generate world specs based on scenario definition.
fn scenario_specs(scenario: &ScenarioDefinition) -> Vec<anvil_core::RegionSpec> {
    use anvil_core::{RegionSpec, TerrainType, StyleHints, LandmarkSpec, LandmarkKind};

    let terrain_type = match scenario.catastrophe {
        CatastropheType::Drought => TerrainType::Highlands,
        CatastropheType::Flood => TerrainType::Coast,
        CatastropheType::Wildfire => TerrainType::Forest,
        CatastropheType::Blizzard => TerrainType::Highlands, // Use Highlands for blizzard
        CatastropheType::Random => TerrainType::Highlands,
    };

    let mood = match scenario.catastrophe {
        CatastropheType::Drought => "dry",
        CatastropheType::Flood => "damp",
        CatastropheType::Wildfire => "hot",
        CatastropheType::Blizzard => "cold",
        CatastropheType::Random => "neutral",
    };

    // Region semantic validation (anvil_core::semantic E006) requires 3–5
    // landmarks per region, each with a unique archetype tag. Below we always
    // ship a Settlement plus two natural/sentinel landmarks; the natural
    // landmarks are correlated to the scenario's catastrophe to keep the
    // scene legible (e.g. a Cave makes sense in a drought; a Shrine in a
    // wildfire region; a Bridge in a flood; a StandingStone in a blizzard).
    let (secondary_kind, secondary_name, secondary_description): (LandmarkKind, &str, String) =
        match scenario.catastrophe {
            CatastropheType::Drought => (
                LandmarkKind::Cave,
                "Dry Wellspring",
                "A cave that once held a spring — now silent.".to_string(),
            ),
            CatastropheType::Flood => (
                LandmarkKind::Bridge,
                "River Crossing",
                "A timber bridge bearing the weight of every spring flood.".to_string(),
            ),
            CatastropheType::Wildfire => (
                LandmarkKind::Shrine,
                "Forest Shrine",
                "A small stone shrine deep among the trees.".to_string(),
            ),
            CatastropheType::Blizzard => (
                LandmarkKind::StandingStone,
                "Watcher Stone",
                "An ancient marker that endures every winter.".to_string(),
            ),
            CatastropheType::Random => (
                LandmarkKind::Ruin,
                "Old Foundations",
                "The remains of an older settlement.".to_string(),
            ),
        };

    // Greyridge requires a marker landmark (StandingStone, Monument, or Shrine)
    // to pass semantic validation. Add a Shrine specifically for Greyridge.
    let needs_marker = scenario.name == "Greyridge";
    
    let mut landmarks = vec![
        LandmarkSpec {
            name: "Settlement".to_string(),
            kind: LandmarkKind::Settlement,
            description: format!("A settlement facing {}", scenario.description),
        },
        LandmarkSpec {
            name: "Watchtower".to_string(),
            kind: LandmarkKind::Tower,
            description: "A wooden watchtower overlooking the approach.".to_string(),
        },
        LandmarkSpec {
            name: secondary_name.to_string(),
            kind: secondary_kind,
            description: secondary_description,
        },
    ];
    
    // Add Greymarker Shrine for Greyridge region
    if needs_marker {
        landmarks.push(LandmarkSpec {
            name: "Greymarker Shrine".to_string(),
            kind: LandmarkKind::Shrine,
            description: "An ancient wayside shrine marking the boundary of Greyridge.".to_string(),
        });
    }

    vec![RegionSpec {
        name: scenario.name.clone(),
        terrain_type,
        mood: mood.to_string(),
        landmarks,
        style_hints: StyleHints {
            palette: vec!["stone".to_string(), "wood".to_string()],
            density: "medium".to_string(),
            atmosphere: "clear".to_string(),
        },
    }]
}

/// System to clean up the scenario loader after transition to InGame.
/// This frees the memory held by the loaded world, runtime, and plan.
pub fn cleanup_scenario_loader(
    mut loader: ResMut<ScenarioLoader>,
) {
    // Reset the loader to free memory after data has been transferred to resources
    loader.runtime = None;
    loader.world = None;
    loader.plan = None;
}

/// Plugin for scenario loading.
pub struct ScenarioLoaderPlugin;

impl Plugin for ScenarioLoaderPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<ScenarioLoader>()
            .add_systems(OnEnter(AppState::Loading), start_scenario_loading)
            .add_systems(
                Update,
                (update_scenario_loading, load_scenario_world)
                    .run_if(in_state(AppState::Loading)),
            )
            .add_systems(OnExit(AppState::Loading), cleanup_scenario_loader);
    }
}
