//! Time Travel module for simulation state navigation.
//!
//! Provides timeline scrubbing, bookmarks, and snapshot management.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Resource for time travel state.
#[derive(Resource, Default)]
pub struct TimeTravelState {
    /// Current timeline position (tick).
    pub current_tick: u64,
    /// Bookmarked ticks.
    pub bookmarks: Vec<u64>,
    /// Selected bookmark index.
    #[allow(dead_code)]
    pub selected_bookmark: Option<usize>,
}

/// System that renders the time travel panel.
pub fn render_time_travel_panel(
    mut egui_contexts: EguiContexts,
    time_travel: Res<TimeTravelState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_time_travel {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Animate panel appearance using animate_bool (Phase 3e)
        let _animated = ctx.animate_bool(egui::Id::new("time_travel_panel"), true);
        
        egui::SidePanel::left("time_travel_panel")
            .default_width(280.0)
            .resizable(false)
            .show(ctx, |ui: &mut egui::Ui| {
                ui.heading("Time Travel");
                ui.separator();
                ui.label(format!("Current Tick: {}", time_travel.current_tick));
                ui.separator();
                ui.label("Bookmarks:");
                for (i, &tick) in time_travel.bookmarks.iter().enumerate() {
                    let _ = ui.button(format!("Bookmark {}: {}", i + 1, tick));
                }
                ui.separator();
                ui.label("Note: Time travel requires simulation integration");
            });
    }
}

/// Setup system for time travel state.
pub fn setup_time_travel(mut commands: Commands) {
    commands.insert_resource(TimeTravelState::default());
}
