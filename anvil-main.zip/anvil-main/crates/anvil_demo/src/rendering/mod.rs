//! GLB Rendering System for Quaternius models
//!
//! This module provides:
//! - Archetype-to-GLB path mapping
//! - GLB asset loading via Bevy's AssetServer
//! - Entity spawning with loaded GLB models
//! - Integration with SimBridgePlugin for entity positions

pub mod glb_assets;
pub mod glb_rendering;

#[allow(unused_imports)]
pub use glb_assets::{ArchetypeGlbMap, GlbAssets, GlbSpawnedEntities};
pub use glb_rendering::GlbRenderingPlugin;
