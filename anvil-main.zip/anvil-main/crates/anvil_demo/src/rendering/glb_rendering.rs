//! GLB Rendering Plugin
//!
//! Provides the main plugin for loading and rendering GLB models from Quaternius.com.
//! This plugin:
//! - Pre-loads all GLB files at startup
//! - Spawns entities with loaded GLB models
//! - Handles missing GLB files gracefully (warning + skip)
//! - Integrates with SimBridgePlugin to get entity positions

use bevy::animation::*;
use bevy::gltf::Gltf;
use bevy::prelude::*;
use bevy::scene::SceneRoot;
use once_cell::sync::Lazy;
use tracing::{debug, info, warn};

use super::glb_assets::{ArchetypeGlbMap, GlbAssets, GlbSpawnedEntities};
use crate::app::RuntimeResource;
use crate::sim::SimTickCounter;

// NPC-specific scale and rotation adjustments
// All models need 180° Y-rotation (Blender -Z → Bevy +Z)
// Use Lazy to avoid const fn issues with Quat::from_rotation_y
static NPC_TRANSFORMS: Lazy<Vec<(&'static str, Vec3, Quat)>> = Lazy::new(|| {
    vec![
        // Female base (1.775m tall)
        ("maren", Vec3::new(1.0, 0.93, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),      // 1.775 * 0.93 ≈ 1.65m
        ("senne", Vec3::new(1.0, 0.93, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),
        ("yarra", Vec3::new(1.0, 0.93, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),
        ("elder_maren", Vec3::new(1.0, 0.87, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),    // 1.775 * 0.87 ≈ 1.54m
        ("ironbark_mother", Vec3::new(1.0, 0.96, 1.0), Quat::from_rotation_y(std::f32::consts::PI)), // 1.775 * 0.96 ≈ 1.70m

        // Male base (1.82m tall)
        ("dak_voss", Vec3::new(1.0, 1.0, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),       // 1.82m ≈ 1.9m target
        ("ironbark_father", Vec3::new(1.0, 0.99, 1.0), Quat::from_rotation_y(std::f32::consts::PI)), // 1.82 * 0.99 ≈ 1.80m

        // Child (Female base scaled down)
        ("ironbark_child", Vec3::new(1.0, 0.68, 1.0), Quat::from_rotation_y(std::f32::consts::PI)),  // 1.775 * 0.68 ≈ 1.20m
    ]
});

/// Plugin for GLB rendering system
pub struct GlbRenderingPlugin;

impl Plugin for GlbRenderingPlugin {
    fn build(&self, app: &mut App) {
        app
            // Initialize resources
            .init_resource::<ArchetypeGlbMap>()
            .init_resource::<GlbAssets>()
            .init_resource::<GlbSpawnedEntities>()
            // Add systems
            .add_systems(Startup, load_glb_assets)
            .add_systems(Update, spawn_glb_entities);
    }
}

/// Component to mark entities that should have a GLB model spawned
#[derive(Component)]
pub struct GlbEntity {
    /// The archetype of this entity
    pub archetype: String,
    /// The position where the GLB should be spawned
    pub position: Vec3,
    /// Optional rotation
    pub rotation: Option<Quat>,
    /// Optional scale
    pub scale: Option<Vec3>,
}

/// Component to track which GLB scene is loaded on an entity
#[derive(Component)]
pub struct GlbScene {
    /// The archetype of the loaded GLB
    pub archetype: String,
    /// The scene handle
    pub handle: Handle<Scene>,
}

/// Component to mark an entity as a spawned GLB model
#[derive(Component)]
pub struct GlbModel {
    /// The archetype of this model
    pub archetype: String,
}

/// Marker component for entities that have been spawned from runtime
#[derive(Component)]
pub struct SpawnedFromRuntime {
    /// The entity ID from the runtime
    pub entity_id: u64,
}

/// System to pre-load all GLB files at startup
pub fn load_glb_assets(
    asset_server: Res<AssetServer>,
    archetype_map: Res<ArchetypeGlbMap>,
    mut glb_assets: ResMut<GlbAssets>,
) {
    info!("Starting GLB asset pre-loading...");

    let mappings = &archetype_map.mappings;

    for (archetype, path) in mappings {
        // Try to load the scene
        if let Some(scene_handle) = try_load_scene(&asset_server, path) {
            glb_assets.handles.insert(archetype.clone(), scene_handle);
            info!(
                "Loaded GLB scene for archetype '{}' from '{}'",
                archetype, path
            );
        } else {
            // Try to load as GLTF directly
            if let Some(gltf_handle) = try_load_gltf(&asset_server, path) {
                glb_assets
                    .gltf_handles
                    .insert(archetype.clone(), gltf_handle);
                info!("Loaded GLTF for archetype '{}' from '{}'", archetype, path);
            } else {
                // File doesn't exist or failed to load
                let error_msg = format!("GLB file not found or failed to load: {}", path);
                warn!("{}", error_msg);
                glb_assets.mark_failed(archetype.clone(), error_msg);
            }
        }
    }

    info!(
        "GLB asset pre-loading complete: {} scenes, {} gltfs, {} failed",
        glb_assets.handles.len(),
        glb_assets.gltf_handles.len(),
        glb_assets.failed_loads.len()
    );
}

/// Try to load a scene from a GLB path
fn try_load_scene(asset_server: &AssetServer, path: &str) -> Option<Handle<Scene>> {
    // Use Bevy's typed label API — never embed #Scene0 in strings
    let scene_path = bevy::gltf::GltfAssetLabel::Scene(0).from_asset(path.to_string());
    Some(asset_server.load(scene_path))
}

/// Try to load a GLTF from a path
fn try_load_gltf(asset_server: &AssetServer, path: &str) -> Option<Handle<Gltf>> {
    if path.contains('#') {
        // Strip the #Scene0 suffix for GLTF loading
        let gltf_path: String = path.split('#').next().unwrap_or(path).to_string();
        return Some(asset_server.load(gltf_path));
    }
    // AssetServer resolves paths relative to the configured asset root.
    // No filesystem pre-check needed - Bevy handles path resolution.
    Some(asset_server.load(path.to_string()))
}



/// System to spawn GLB entities based on runtime state
///
/// This listens for entity spawn events or polls the world state
/// and spawns GLB models at the correct positions.
pub fn spawn_glb_entities(
    mut commands: Commands,
    _asset_server: Res<AssetServer>,
    scenes: Res<Assets<Scene>>,
    glb_assets: Res<GlbAssets>,
    archetype_map: Res<ArchetypeGlbMap>,
    mut spawned_entities: ResMut<GlbSpawnedEntities>,
    runtime: Option<Res<RuntimeResource>>,
    _tick_counter: Res<SimTickCounter>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    // Only run if we have a runtime
    let Some(runtime) = runtime else {
        return;
    };

    // Get the loaded regions from the runtime
    let loaded_regions = &runtime.runtime.loaded_regions;

    // Get the world entities
    let world_entities = &runtime.runtime.world.entities;

    // For each loaded region, spawn entities that have GLB mappings
    for entity in world_entities {
        // Skip entities not in loaded regions
        if !loaded_regions.contains(&entity.region) {
            continue;
        }

        let archetype_str = entity.archetype.to_string();

        // Check if this archetype has a GLB mapping
        if !archetype_map.has_mapping(&archetype_str) {
            debug!(
                "Skipping entity with archetype '{}' - no GLB mapping found",
                archetype_str
            );
            continue;
        }

        // Check if the GLB failed to load
        if glb_assets.did_fail(&archetype_str) {
            warn!(
                "Skipping entity with archetype '{}' - GLB failed to load: {}",
                archetype_str,
                glb_assets
                    .get_error(&archetype_str)
                    .unwrap_or(&"Unknown error".to_string())
            );
            continue;
        }

        // Get the GLB scene handle
        let scene_handle = match glb_assets.get_scene(&archetype_str) {
            Some(handle) => handle,
            None => {
                // GLB might still be loading, skip for now
                debug!(
                    "Skipping entity with archetype '{}' - GLB not yet loaded",
                    archetype_str
                );
                continue;
            }
        };

        // Check if the scene is actually loaded
        if !scenes.contains(scene_handle) {
            debug!(
                "Skipping entity with archetype '{}' - Scene not ready yet",
                archetype_str
            );
            continue;
        }

        // Create a unique entity ID for tracking
        let entity_id = entity.id.get();

        // Compute position based on entity index (similar to setup_world)
        // AuthoredEntity doesn't have a position field, so we compute it
        let spacing = 4.0;
        let entity_idx = world_entities
            .iter()
            .position(|e| e.id == entity.id)
            .unwrap_or(0);
        let x = (entity_idx as f32 % 10.0) * spacing - 20.0;
        let z = (entity_idx as f32 / 10.0) * spacing;
        let position = [x, 0.0, z];

        // Check if this entity has already been spawned
        if spawned_entities.is_spawned(entity_id) {
            debug!(
                "Skipping already spawned entity {} with archetype '{}'",
                entity_id, archetype_str
            );
            continue;
        }

        // Mark as spawned
        spawned_entities.mark_spawned(entity_id);

        // Spawn the GLB scene at the computed position
        spawn_glb_scene(
            &mut commands,
            scene_handle.clone(),
            &archetype_str,
            entity_id,
            position,
            &mut meshes,
            &mut materials,
        );
    }
}

/// Helper function to spawn a GLB scene at a position with appropriate transforms
fn spawn_glb_scene(
    commands: &mut Commands,
    scene_handle: Handle<Scene>,
    archetype: &str,
    entity_id: u64,
    position: [f32; 3],
    meshes: &mut ResMut<Assets<Mesh>>,
    materials: &mut ResMut<Assets<StandardMaterial>>,
) {
    // Convert position array to Vec3
    let pos = Vec3::new(position[0], position[1], position[2]);

    // Get NPC-specific transform if available
    let (scale, rotation) = NPC_TRANSFORMS
        .iter()
        .find(|(name, _, _)| *name == archetype)
        .map(|(_, s, r)| (*s, *r))
        .unwrap_or((Vec3::ONE, Quat::IDENTITY)); // Default: no scale, no rotation

    let transform = Transform::from_translation(pos)
        .with_scale(scale)
        .with_rotation(rotation);

    // Check if this is a placeholder archetype
    // All character, vegetation, structure, and building archetypes now have real models
    // Only truly unmapped archetypes should use placeholders
    let is_placeholder = archetype == "placeholder";

    if is_placeholder {
        // Spawn a colored cube as placeholder
        let color = Color::srgb(0.8, 0.2, 0.2);
        
        commands.spawn((
            Mesh3d(meshes.add(Cuboid::new(1.0, 1.0, 1.0))),
            MeshMaterial3d(materials.add(color)),
            transform,
            GlbModel {
                archetype: archetype.to_string(),
            },
            SpawnedFromRuntime { entity_id },
            Name::new(format!("Placeholder_{}_{}", archetype, entity_id)),
        ));
    } else {
        // Spawn the actual GLB scene with animation player
        // Check if this is a character that should have animations
        let is_npc = NPC_TRANSFORMS.iter().any(|(name, _, _)| *name == archetype);
        
        if is_npc {
            commands.spawn((
                SceneRoot(scene_handle),
                transform,
                GlbModel {
                    archetype: archetype.to_string(),
                },
                SpawnedFromRuntime { entity_id },
                AnimationPlayer::default(),
                Name::new(format!("GLB_{}_{}", archetype, entity_id)),
            ));
        } else {
            commands.spawn((
                SceneRoot(scene_handle),
                transform,
                GlbModel {
                    archetype: archetype.to_string(),
                },
                SpawnedFromRuntime { entity_id },
                Name::new(format!("GLB_{}_{}", archetype, entity_id)),
            ));
        }
    }

    debug!(
        "Spawned {} for archetype '{}' at position {:?} with scale {:?} rotation {:?}",
        if is_placeholder { "placeholder cube" } else { "GLB model" },
        archetype, pos, scale, rotation
    );
}





#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_glb_entity_component() {
        let entity = GlbEntity {
            archetype: "humanoid".to_string(),
            position: Vec3::new(1.0, 2.0, 3.0),
            rotation: None,
            scale: None,
        };

        assert_eq!(entity.archetype, "humanoid");
        assert_eq!(entity.position, Vec3::new(1.0, 2.0, 3.0));
        let _ = (&entity.rotation, &entity.scale); // Use variables to avoid warnings
    }

    #[test]
    fn test_glb_model_component() {
        let model = GlbModel {
            archetype: "house".to_string(),
        };

        assert_eq!(model.archetype, "house");
    }

    #[test]
    fn test_spawned_from_runtime_component() {
        let spawned = SpawnedFromRuntime { entity_id: 42 };

        assert_eq!(spawned.entity_id, 42);
    }
}
