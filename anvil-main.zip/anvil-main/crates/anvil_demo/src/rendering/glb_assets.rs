//! GLB Asset Definitions
//!
//! Contains the archetype-to-GLB mapping and asset handle storage.

use bevy::gltf::Gltf;
use bevy::prelude::*;
use std::collections::HashMap;

/// Resource that maps archetype names to GLB file paths.
///
/// This contains all the mappings for Quaternius.com models as specified
/// in DEMO_VISION.md and the asset directory structure.
/// 
/// All paths are relative to the asset root and use hardcoded values
/// to avoid filesystem access at initialization time.
#[derive(Resource, Debug, Clone)]
pub struct ArchetypeGlbMap {
    /// Map from archetype tag string to GLB file path
    pub mappings: HashMap<String, String>,
}

impl Default for ArchetypeGlbMap {
    fn default() -> Self {
        let mut mappings = HashMap::new();

        // === Universal Base Characters (Quaternius) ===
        // NPCs: Use Female for Maren, Senne, Yarra, Elder Maren, Ironbark mother/child
        mappings.insert("maren".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("senne".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("yarra".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("elder_maren".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("ironbark_mother".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("ironbark_child".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());

        // NPCs: Use Male for Dak, Ironbark father
        mappings.insert("dak_voss".to_string(), "models/quaternius/Superhero_Male_FullBody.gltf#Scene0".to_string());
        mappings.insert("ironbark_father".to_string(), "models/quaternius/Superhero_Male_FullBody.gltf#Scene0".to_string());

        // Generic archetypes (fallback to Female)
        mappings.insert("humanoid".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("person".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());
        mappings.insert("npc".to_string(), "models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string());

        // === Stylized Nature Mega Kit ===
        // Vegetation
        mappings.insert("vegetation_pine_cluster".to_string(), "models/quaternius/nature/glTF/Pine_1.gltf".to_string());
        mappings.insert("vegetation_scrub_dry".to_string(), "models/quaternius/nature/glTF/Bush_Common.gltf".to_string());
        mappings.insert("vegetation_tree".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());
        mappings.insert("vegetation".to_string(), "models/quaternius/nature/glTF/Grass_Common_Short.gltf".to_string());

        // === Fantasy Props Mega Kit ===
        // Structures - mapped to nature meshes (original props/Structures paths don't exist)
        mappings.insert("structure_watchtower_stone".to_string(), "models/quaternius/nature/glTF/Pine_1.gltf".to_string());
        mappings.insert("structure_watchtower".to_string(), "models/quaternius/nature/glTF/Pine_1.gltf".to_string());
        mappings.insert("structure_well".to_string(), "models/quaternius/nature/glTF/Bush_Common.gltf".to_string());
        mappings.insert("structure_bridge".to_string(), "models/quaternius/nature/glTF/DeadTree_1.gltf".to_string());
        mappings.insert("structure_wall".to_string(), "models/quaternius/nature/glTF/Rock_Medium_1.gltf".to_string());
        mappings.insert("structure".to_string(), "models/quaternius/nature/glTF/Mushroom_Common.gltf".to_string());
        mappings.insert("settlement".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());

        // Buildings - mapped to nature meshes (original props/Structures paths don't exist)
        mappings.insert("building".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());
        mappings.insert("building_timber_longhouse".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());
        mappings.insert("building_granary_stone".to_string(), "models/quaternius/nature/glTF/Pine_1.gltf".to_string());
        mappings.insert("building_longhouse".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());
        mappings.insert("building_house".to_string(), "models/quaternius/nature/glTF/CommonTree_1.gltf".to_string());

        // === Placeholder ===
        // Fallback for any unmapped archetypes
        mappings.insert("placeholder".to_string(), "models/quaternius/nature/glTF/Bush_Common.gltf".to_string());

        Self { mappings }
    }
}

impl ArchetypeGlbMap {
    /// Create a new ArchetypeGlbMap with default mappings
    pub fn new() -> Self {
        Self::default()
    }

    /// Get the GLB path for a given archetype, if it exists
    pub fn get_path(&self, archetype: &str) -> Option<&String> {
        // Direct match first
        if let Some(p) = self.mappings.get(archetype) {
            return Some(p);
        }

        // Longest prefix match (deterministic)
        let lower = archetype.to_lowercase();
        let mut best: Option<(&str, &String)> = None;
        for (key, path) in &self.mappings {
            if lower.starts_with(key.as_str()) {
                match best {
                    None => best = Some((key, path)),
                    Some((prev_key, _)) if key.len() > prev_key.len() => {
                        best = Some((key, path));
                    }
                    _ => {}
                }
            }
        }
        best.map(|(_, p)| p)
    }

    /// Check if an archetype has a GLB mapping
    pub fn has_mapping(&self, archetype: &str) -> bool {
        self.get_path(archetype).is_some()
    }

    /// Get all archetype names that have mappings
    pub fn archetypes(&self) -> Vec<&String> {
        self.mappings.keys().collect()
    }

    /// Add a custom mapping (for testing or runtime overrides)
    pub fn add_mapping(&mut self, archetype: String, path: String) {
        self.mappings.insert(archetype, path);
    }
}

/// Resource that stores loaded GLB asset handles.
///
/// Maps archetype names to their loaded Scene handles from Bevy's AssetServer.
#[derive(Resource, Debug, Default)]
pub struct GlbAssets {
    /// Map from archetype tag string to Scene handle
    pub handles: HashMap<String, Handle<Scene>>,
    /// Map from archetype tag string to GLTF asset handle (for direct mesh access)
    pub gltf_handles: HashMap<String, Handle<Gltf>>,
    /// Track which archetypes failed to load
    pub failed_loads: HashMap<String, String>,
}

/// Resource to track which entities have been spawned as GLB models.
/// This prevents duplicate spawning.
#[derive(Resource, Debug, Default)]
pub struct GlbSpawnedEntities {
    /// Set of entity IDs that have been spawned
    pub spawned_ids: std::collections::HashSet<u64>,
}

impl GlbSpawnedEntities {
    /// Create a new empty tracking resource
    pub fn new() -> Self {
        Self::default()
    }

    /// Check if an entity has been spawned
    pub fn is_spawned(&self, entity_id: u64) -> bool {
        self.spawned_ids.contains(&entity_id)
    }

    /// Mark an entity as spawned
    pub fn mark_spawned(&mut self, entity_id: u64) -> bool {
        self.spawned_ids.insert(entity_id)
    }

    /// Clear all spawned entities
    pub fn clear(&mut self) {
        self.spawned_ids.clear();
    }
}

impl GlbAssets {
    /// Create a new empty GlbAssets resource
    pub fn new() -> Self {
        Self::default()
    }

    /// Check if an archetype's GLB is loaded
    pub fn is_loaded(&self, archetype: &str) -> bool {
        self.handles.contains_key(archetype)
    }

    /// Get the Scene handle for an archetype, if loaded
    pub fn get_scene(&self, archetype: &str) -> Option<&Handle<Scene>> {
        self.handles.get(archetype)
    }

    /// Get the GLTF handle for an archetype, if loaded
    pub fn get_gltf(&self, archetype: &str) -> Option<&Handle<Gltf>> {
        self.gltf_handles.get(archetype)
    }

    /// Mark an archetype as failed to load with an error message
    pub fn mark_failed(&mut self, archetype: String, error: String) {
        self.failed_loads.insert(archetype, error);
    }

    /// Check if an archetype failed to load
    pub fn did_fail(&self, archetype: &str) -> bool {
        self.failed_loads.contains_key(archetype)
    }

    /// Get the error message for a failed load
    pub fn get_error(&self, archetype: &str) -> Option<&String> {
        self.failed_loads.get(archetype)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_archetype_glb_map_default_mappings() {
        let map = ArchetypeGlbMap::default();

        // Test NPC mappings (Universal Base Characters)
        assert_eq!(
            map.get_path("maren"),
            Some(&"models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string())
        );
        assert_eq!(
            map.get_path("dak_voss"),
            Some(&"models/quaternius/Superhero_Male_FullBody.gltf#Scene0".to_string())
        );
        assert_eq!(
            map.get_path("humanoid"),
            Some(&"models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string())
        );
        assert_eq!(
            map.get_path("person"),
            Some(&"models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string())
        );
        assert_eq!(
            map.get_path("npc"),
            Some(&"models/quaternius/Superhero_Female_FullBody.gltf#Scene0".to_string())
        );

        // Test Stylized Nature Mega Kit vegetation mappings
        assert_eq!(
            map.get_path("vegetation_pine_cluster"),
            Some(&"models/quaternius/nature/glTF/Pine_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("vegetation_scrub_dry"),
            Some(&"models/quaternius/nature/glTF/Bush_Common.gltf".to_string())
        );
        assert_eq!(
            map.get_path("vegetation_tree"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("vegetation"),
            Some(&"models/quaternius/nature/glTF/Grass_Common_Short.gltf".to_string())
        );

        // Test Fantasy Props Mega Kit structure mappings (mapped to nature meshes)
        assert_eq!(
            map.get_path("structure_watchtower_stone"),
            Some(&"models/quaternius/nature/glTF/Pine_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("structure_watchtower"),
            Some(&"models/quaternius/nature/glTF/Pine_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("structure_well"),
            Some(&"models/quaternius/nature/glTF/Bush_Common.gltf".to_string())
        );
        assert_eq!(
            map.get_path("structure_bridge"),
            Some(&"models/quaternius/nature/glTF/DeadTree_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("structure_wall"),
            Some(&"models/quaternius/nature/glTF/Rock_Medium_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("structure"),
            Some(&"models/quaternius/nature/glTF/Mushroom_Common.gltf".to_string())
        );
        assert_eq!(
            map.get_path("settlement"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );

        // Test Fantasy Props Mega Kit building mappings (mapped to nature meshes)
        assert_eq!(
            map.get_path("building"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("building_timber_longhouse"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("building_granary_stone"),
            Some(&"models/quaternius/nature/glTF/Pine_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("building_longhouse"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );
        assert_eq!(
            map.get_path("building_house"),
            Some(&"models/quaternius/nature/glTF/CommonTree_1.gltf".to_string())
        );
        // Test placeholder mapping (mapped to nature mesh)
        assert_eq!(
            map.get_path("placeholder"),
            Some(&"models/quaternius/nature/glTF/Bush_Common.gltf".to_string())
        );
    }

    #[test]
    fn test_archetype_glb_map_has_mapping() {
        let map = ArchetypeGlbMap::default();

        assert!(map.has_mapping("maren"));
        assert!(map.has_mapping("dak_voss"));
        assert!(map.has_mapping("humanoid"));
        assert!(map.has_mapping("vegetation_pine_cluster"));
        assert!(map.has_mapping("vegetation_scrub_dry"));
        assert!(map.has_mapping("structure_watchtower_stone"));
        assert!(map.has_mapping("structure_well"));
        assert!(map.has_mapping("building_timber_longhouse"));
        assert!(map.has_mapping("building_house"));
        assert!(!map.has_mapping("nonexistent_archetype"));
    }

    #[test]
    fn test_archetype_glb_map_archetypes() {
        let map = ArchetypeGlbMap::default();
        let archetypes = map.archetypes();

        assert!(archetypes.len() > 0);
        assert!(archetypes.contains(&&"maren".to_string()));
        assert!(archetypes.contains(&&"dak_voss".to_string()));
        assert!(archetypes.contains(&&"humanoid".to_string()));
        assert!(archetypes.contains(&&"vegetation_pine_cluster".to_string()));
        assert!(archetypes.contains(&&"structure_watchtower_stone".to_string()));
        assert!(archetypes.contains(&&"building_timber_longhouse".to_string()));
    }

    #[test]
    fn test_glb_assets_new() {
        let assets = GlbAssets::new();

        assert!(assets.handles.is_empty());
        assert!(assets.gltf_handles.is_empty());
        assert!(assets.failed_loads.is_empty());
    }

    #[test]
    fn test_glb_assets_mark_failed() {
        let mut assets = GlbAssets::new();

        assets.mark_failed("test_archetype".to_string(), "File not found".to_string());

        assert!(assets.did_fail("test_archetype"));
        assert_eq!(
            assets.get_error("test_archetype"),
            Some(&"File not found".to_string())
        );
        assert!(!assets.did_fail("other_archetype"));
    }

    #[test]
    fn test_glb_spawned_entities_new() {
        let spawned = GlbSpawnedEntities::new();

        assert!(spawned.spawned_ids.is_empty());
    }

    #[test]
    fn test_glb_spawned_entities_mark_and_check() {
        let mut spawned = GlbSpawnedEntities::new();

        assert!(!spawned.is_spawned(42));

        spawned.mark_spawned(42);
        assert!(spawned.is_spawned(42));
        assert!(!spawned.is_spawned(43));
    }

    #[test]
    fn test_glb_spawned_entities_clear() {
        let mut spawned = GlbSpawnedEntities::new();

        spawned.mark_spawned(42);
        spawned.mark_spawned(43);
        assert!(spawned.is_spawned(42));
        assert!(spawned.is_spawned(43));

        spawned.clear();
        assert!(!spawned.is_spawned(42));
        assert!(!spawned.is_spawned(43));
    }
}
