//! Catastrophe Panel module for spawning and controlling catastrophes.
//!
//! This module provides a panel for triggering and configuring catastrophes
//! in the simulation.

use anvil_sim::catastrophe::CatastropheType;
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// A pending catastrophe trigger to be processed during simulation tick.
#[derive(Debug, Clone)]
pub struct PendingCatastrophe {
    pub catastrophe_type: CatastropheType,
    pub epicentre: bevy::prelude::Vec3,
    pub magnitude: f32,
    pub radius: f32,
}

/// Resource for catastrophe panel state.
#[derive(Resource)]
pub struct CatastrophePanelState {
    /// Selected catastrophe type.
    pub selected_type: CatastropheType,
    /// Intensity slider value (0.1 - 1.0).
    pub intensity: f32,
    /// Whether the panel border should flash red.
    pub flash_red: bool,
    /// Flash timer.
    pub flash_timer: f32,
    /// Last triggered catastrophe type for logging.
    pub last_triggered: Option<CatastropheType>,
    /// Queue of pending catastrophe triggers.
    pub pending_triggers: Vec<PendingCatastrophe>,
}

impl Default for CatastrophePanelState {
    fn default() -> Self {
        Self {
            selected_type: CatastropheType::Flood,
            intensity: 0.5,
            flash_red: false,
            flash_timer: 0.0,
            last_triggered: None,
            pending_triggers: Vec::new(),
        }
    }
}

/// System that renders the catastrophe panel.
pub fn render_catastrophe_panel(
    mut egui_contexts: EguiContexts,
    mut panel_state: ResMut<CatastrophePanelState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_catastrophe_panel {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Animate panel appearance using animate_bool (Phase 3e)
        let _animated = ctx.animate_bool(egui::Id::new("catastrophe_panel"), true);
        
        egui::SidePanel::right("catastrophe_panel")
            .default_width(300.0)
            .resizable(false)
            .show(ctx, |ui: &mut egui::Ui| {
                // Update flash timer
                if panel_state.flash_red {
                    panel_state.flash_timer -= ui.input(|i| i.unstable_dt);
                    if panel_state.flash_timer <= 0.0 {
                        panel_state.flash_red = false;
                    }
                }

                ui.heading("Catastrophe Panel");
                ui.separator();

                // Catastrophe type dropdown
                ui.label("Type:");
                
                // Array of catastrophe types with their display names
                let types = [
                    (CatastropheType::Flood, "Flood"),
                    (CatastropheType::Earthquake, "Earthquake"),
                    (CatastropheType::Wildfire, "Wildfire"),
                    (CatastropheType::Blizzard, "Blizzard"),
                    (CatastropheType::Drought, "Drought"),
                    (CatastropheType::Landslide, "Landslide"),
                    (CatastropheType::Blight, "Blight"),
                ];

                // Find current selection index
                let current_name = types.iter()
                    .find(|(t, _)| *t == panel_state.selected_type)
                    .map(|(_, name)| *name)
                    .unwrap_or("Flood");

                // Dropdown selector
                egui::ComboBox::from_label("Select catastrophe type")
                    .selected_text(current_name)
                    .show_ui(ui, |ui| {
                        for (cat_type, name) in types.iter() {
                            if ui.selectable_value(
                                &mut panel_state.selected_type,
                                *cat_type,
                                *name,
                            ).clicked() {
                                // Selection changed
                            }
                        }
                    });

                ui.separator();

                // Intensity slider
                ui.label("Intensity:");
                ui.add(
                    egui::Slider::new(&mut panel_state.intensity, 0.1..=1.0)
                        .text("Intensity")
                        .show_value(true),
                );

                ui.separator();

                // Spawn buttons for F1-F7
                ui.label("Quick Select:");
                ui.horizontal(|ui| {
                    if ui.button("F1: Flood").clicked() {
                        panel_state.selected_type = CatastropheType::Flood;
                    }
                    if ui.button("F2: Earthquake").clicked() {
                        panel_state.selected_type = CatastropheType::Earthquake;
                    }
                    if ui.button("F3: Wildfire").clicked() {
                        panel_state.selected_type = CatastropheType::Wildfire;
                    }
                });
                ui.horizontal(|ui| {
                    if ui.button("F4: Blizzard").clicked() {
                        panel_state.selected_type = CatastropheType::Blizzard;
                    }
                    if ui.button("F5: Drought").clicked() {
                        panel_state.selected_type = CatastropheType::Drought;
                    }
                    if ui.button("F6: Landslide").clicked() {
                        panel_state.selected_type = CatastropheType::Landslide;
                    }
                });
                ui.horizontal(|ui| {
                    if ui.button("F7: Blight").clicked() {
                        panel_state.selected_type = CatastropheType::Blight;
                    }
                });

                ui.separator();

                // Trigger button
                if ui.button("Trigger Catastrophe").clicked() {
                    // Queue a pending catastrophe trigger
                    let pending = PendingCatastrophe {
                        catastrophe_type: panel_state.selected_type,
                        epicentre: Vec3::new(0.0, 0.0, 0.0), // Center at origin for now
                        magnitude: panel_state.intensity * 10.0, // Scale intensity to magnitude
                        radius: panel_state.intensity * 50.0, // Scale intensity to radius
                    };
                    panel_state.pending_triggers.push(pending);
                    panel_state.last_triggered = Some(panel_state.selected_type);
                    panel_state.flash_red = true;
                    panel_state.flash_timer = 0.5;
                    println!("Triggered catastrophe: {:?} with intensity {}", panel_state.selected_type, panel_state.intensity);
                }
            });
    }
}

/// System that handles catastrophe spawning keyboard shortcuts.
pub fn handle_catastrophe_shortcuts(
    mut panel_state: ResMut<CatastrophePanelState>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // F1-F7 keys for each catastrophe type
    if keyboard_input.just_pressed(KeyCode::F1) {
        panel_state.selected_type = CatastropheType::Flood;
    }
    if keyboard_input.just_pressed(KeyCode::F2) {
        panel_state.selected_type = CatastropheType::Earthquake;
    }
    if keyboard_input.just_pressed(KeyCode::F3) {
        panel_state.selected_type = CatastropheType::Wildfire;
    }
    if keyboard_input.just_pressed(KeyCode::F4) {
        panel_state.selected_type = CatastropheType::Blizzard;
    }
    if keyboard_input.just_pressed(KeyCode::F5) {
        panel_state.selected_type = CatastropheType::Drought;
    }
    if keyboard_input.just_pressed(KeyCode::F6) {
        panel_state.selected_type = CatastropheType::Landslide;
    }
    if keyboard_input.just_pressed(KeyCode::F7) {
        panel_state.selected_type = CatastropheType::Blight;
    }
}

/// System that processes pending catastrophe triggers and adds them to the simulation.
pub fn process_pending_catastrophes(
    mut panel_state: ResMut<CatastrophePanelState>,
    mut runtime: ResMut<crate::app::RuntimeResource>,
    tick_counter: Res<crate::sim::SimTickCounter>,
) {
    // Process all pending triggers
    for pending in panel_state.pending_triggers.drain(..) {
        // Convert bevy Vec3 to glam Vec3
        let glam_epicentre = glam::Vec3::new(
            pending.epicentre.x,
            pending.epicentre.y,
            pending.epicentre.z,
        );
        
        // Get mutable catastrophe system
        let Some(catastrophe_system) = runtime.runtime.catastrophe_system_mut() else {
            continue;
        };
        
        let _event = catastrophe_system.trigger_catastrophe(
            pending.catastrophe_type,
            glam_epicentre,
            pending.magnitude,
            pending.radius,
            tick_counter.count,
        );
        println!("Processed catastrophe trigger: {:?}", pending.catastrophe_type);
    }
}

/// Setup system for catastrophe panel state.
pub fn setup_catastrophe_panel(mut commands: Commands) {
    commands.insert_resource(CatastrophePanelState::default());
}
