//! Character module for Anvil Demo
//!
//! Contains outfit systems and character-related resources.

#![allow(unused_imports)]

pub mod outfits;

pub use outfits::{OutfitDefinition, OutfitRegistry};
