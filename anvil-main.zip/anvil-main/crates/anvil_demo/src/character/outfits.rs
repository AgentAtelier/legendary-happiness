use bevy::prelude::*;
use std::collections::HashMap;

/// Resource that stores outfit definitions for NPCs
#[derive(Resource, Debug, Clone)]
pub struct OutfitRegistry {
    /// Map from NPC name to outfit definition
    pub outfits: HashMap<String, OutfitDefinition>,
}

/// Definition of a character outfit (modular parts)
#[derive(Debug, Clone)]
pub struct OutfitDefinition {
    /// Head/face model path
    pub head: String,
    /// Torso/upper body model path
    pub torso: String,
    /// Legs model path
    pub legs: String,
    /// Feet model path
    pub feet: String,
    /// Hands model path
    pub hands: String,
}

impl Default for OutfitRegistry {
    fn default() -> Self {
        let mut outfits = HashMap::new();

        // Map outfits to NPCs using Modular Character Outfits Fantasy
        outfits.insert("maren".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Arms.gltf".to_string(),
        });

        outfits.insert("dak_voss".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Arms.gltf".to_string(),
        });

        outfits.insert("senne".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Head_Hood.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Arms.gltf".to_string(),
        });

        outfits.insert("yarra".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Arms.gltf".to_string(),
        });

        outfits.insert("elder_maren".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Peasant_Arms.gltf".to_string(),
        });

        outfits.insert("ironbark_father".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Ranger_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Ranger_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Ranger_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Ranger_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Ranger_Arms.gltf".to_string(),
        });

        outfits.insert("ironbark_mother".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Female_Ranger_Arms.gltf".to_string(),
        });

        outfits.insert("ironbark_child".to_string(), OutfitDefinition {
            head: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Head.gltf".to_string(),
            torso: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Body.gltf".to_string(),
            legs: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Legs.gltf".to_string(),
            feet: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Feet.gltf".to_string(),
            hands: "models/quaternius/outfits/Exports/glTF (Godot-Unreal)/Modular Parts/Male_Peasant_Arms.gltf".to_string(),
        });

        Self { outfits }
    }
}

impl OutfitRegistry {
    /// Create a new OutfitRegistry with default mappings
    pub fn new() -> Self {
        Self::default()
    }

    /// Get the outfit for a given NPC
    pub fn get_outfit(&self, npc_name: &str) -> Option<&OutfitDefinition> {
        self.outfits.get(npc_name)
    }

    /// Check if an outfit exists for an NPC
    pub fn has_outfit(&self, npc_name: &str) -> bool {
        self.outfits.contains_key(npc_name)
    }

    /// Get all NPC names with outfits
    pub fn npc_names(&self) -> Vec<&String> {
        self.outfits.keys().collect()
    }

    /// Add a custom outfit
    pub fn add_outfit(&mut self, npc_name: String, outfit: OutfitDefinition) {
        self.outfits.insert(npc_name, outfit);
    }
}
