//! InGame state.
//!
//! The main gameplay state. Handles:
//! - Simulation ticking
//! - Camera controls
//! - Escape toggles to Paused
//! - World rendering
//! - Diagnostic panel toggle with Backtick
//! - Camera fly-in transition from menu
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;

use crate::app::AppState;
use crate::ui::transitions::{FadeState, MenuBackdrop, TransitionState};

/// Plugin for the in-game state
pub struct InGamePlugin;

impl Plugin for InGamePlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::InGame), setup_in_game)
            .add_systems(
                Update,
                (
                    handle_in_game_input,
                    start_fly_in_transition,
                )
                    .run_if(in_state(AppState::InGame)),
            )
            .add_systems(OnExit(AppState::InGame), cleanup_in_game);
    }
}

fn setup_in_game() {
    // The world is already set up in Startup systems
    // This is just a marker that we've entered InGame state
}

/// System to start the camera fly-in transition when entering InGame from Loading.
/// This runs once on the first frame of InGame state.
fn start_fly_in_transition(
    mut transition_state: ResMut<TransitionState>,
    mut fade_state: ResMut<FadeState>,
    mut backdrop: ResMut<MenuBackdrop>,
) {
    // Only trigger if not already in a transition
    if transition_state.in_transition {
        return;
    }

    // Start the transition
    transition_state.start_transition(AppState::Loading, AppState::InGame);
    
    // Start fade to black
    fade_state.start_fade_to_black();

    // Disable menu backdrop during transition
    backdrop.visible = false;
}

fn handle_in_game_input(
    mut app_state: ResMut<NextState<AppState>>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Escape toggles pause
    if keyboard_input.just_pressed(KeyCode::Escape) {
        app_state.set(AppState::Paused);
    }
}

fn cleanup_in_game() {
    // Nothing to clean up
}
