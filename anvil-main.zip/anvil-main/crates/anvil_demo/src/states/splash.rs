//! Splash screen state.
//!
//! A full-screen splash with the title "FORGEBORN" in large warm gold text,
//! subtitle "A Deterministic World of Emergent Stories", and a subtle procedural
//! background gradient. Fade in over 0.5s, hold for 2s, fade out over 0.5s,
//! auto-advance to `MainMenu`. Any key press skips.
//!
//! Note: Using bevy_egui for immediate mode UI since bevy_ui Bundle types
//! are not available in Bevy 0.18.1.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::{AppState, ScenarioSelection, SimSpeed};

/// Timer for splash screen phases
#[derive(Resource)]
struct SplashTimer {
    /// Current phase of the splash screen
    phase: SplashPhase,
    /// Timer for the current phase
    timer: Timer,
    /// Current alpha for fade in/out
    alpha: f32,
}

/// Phases of the splash screen animation
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SplashPhase {
    /// Fade in (0.5s)
    FadeIn,
    /// Hold (2s)
    Hold,
    /// Fade out (0.5s)
    FadeOut,
    /// Skip to main menu
    Skip,
}

/// Plugin for the splash screen state
pub struct SplashPlugin;

impl Plugin for SplashPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Splash), setup_splash_screen)
            .add_systems(
                EguiPrimaryContextPass,
                render_splash_screen.run_if(in_state(AppState::Splash)),
            )
            .add_systems(Update, (
                update_splash_timer,
                handle_splash_skip,
            ).run_if(in_state(AppState::Splash)))
            .add_systems(OnExit(AppState::Splash), cleanup_splash_screen);
    }
}

/// Color constants for the splash screen (matching existing palette)
fn title_color() -> egui::Color32 {
    egui::Color32::from_rgb(200, 140, 75) // #C78D4B warm gold
}

fn subtitle_color() -> egui::Color32 {
    egui::Color32::from_rgb(228, 212, 185) // #E4D4B9 light
}

fn background_color() -> egui::Color32 {
    egui::Color32::from_rgb(42, 47, 54) // #2A2F36 dark
}

fn setup_splash_screen(mut commands: Commands) {
    // Initialize timer
    commands.insert_resource(SplashTimer {
        phase: SplashPhase::FadeIn,
        timer: Timer::from_seconds(0.5, TimerMode::Once),
        alpha: 0.0,
    });
}

fn update_splash_timer(
    time: Res<Time>,
    mut splash_timer: ResMut<SplashTimer>,
    mut app_state: ResMut<NextState<AppState>>,
    mut commands: Commands,
) {
    splash_timer.timer.tick(time.delta());

    match splash_timer.phase {
        SplashPhase::FadeIn => {
            if splash_timer.timer.is_finished() {
                splash_timer.phase = SplashPhase::Hold;
                splash_timer.timer = Timer::from_seconds(2.0, TimerMode::Once);
                splash_timer.alpha = 1.0;
            } else {
                splash_timer.alpha = splash_timer.timer.fraction();
            }
        }
        SplashPhase::Hold => {
            if splash_timer.timer.is_finished() {
                splash_timer.phase = SplashPhase::FadeOut;
                splash_timer.timer = Timer::from_seconds(0.5, TimerMode::Once);
            }
        }
        SplashPhase::FadeOut => {
            if splash_timer.timer.is_finished() {
                // Auto-start the demo
                commands.insert_resource(ScenarioSelection::default());
                commands.insert_resource(SimSpeed(1.0));
                app_state.set(AppState::Loading);
            } else {
                splash_timer.alpha = 1.0 - splash_timer.timer.fraction();
            }
        }
        SplashPhase::Skip => {
            // Same auto-start when skipping
            commands.insert_resource(ScenarioSelection::default());
            commands.insert_resource(SimSpeed(1.0));
            app_state.set(AppState::Loading);
        }
    }
}

fn handle_splash_skip(
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut splash_timer: ResMut<SplashTimer>,
) {
    // Check common keys that might be pressed to skip
    let keys = [
        KeyCode::Space,
        KeyCode::Enter,
        KeyCode::Escape,
        KeyCode::KeyW,
        KeyCode::KeyA,
        KeyCode::KeyS,
        KeyCode::KeyD,
    ];
    for key in keys {
        if keyboard_input.just_pressed(key) {
            splash_timer.phase = SplashPhase::Skip;
            break;
        }
    }
}

fn render_splash_screen(
    mut egui_contexts: EguiContexts,
    splash_timer: Res<SplashTimer>,
) {
    if let Ok(ctx) = egui_contexts.ctx_mut() {
        // Full-screen central panel
        egui::CentralPanel::default()
            .frame(egui::Frame::NONE)
            .show(ctx, |ui| {
                // Set background
                let painter = ui.painter();
                let rect = ui.available_rect_before_wrap();
                painter.rect_filled(
                    rect,
                    0.0,
                    background_color(),
                );

                // Center content
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 20.0);
                    
                    // Apply alpha to text
                    let alpha = splash_timer.alpha;
                    let title_color = title_color().gamma_multiply(alpha);
                    let subtitle_color = subtitle_color().gamma_multiply(alpha);

                    // Title
                    ui.heading(egui::RichText::new("FORGEBORN")
                        .color(title_color)
                        .size(96.0));

                    // Subtitle
                    ui.label(egui::RichText::new("A Deterministic World of Emergent Stories")
                        .color(subtitle_color)
                        .size(24.0));
                });
            });
    }
}

fn cleanup_splash_screen() {
    // Nothing to clean up for egui-based UI
}
