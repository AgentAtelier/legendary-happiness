//! Main menu state.
//!
//! A bevy_egui panel with:
//! - Title "FORGEBORN" (large, warm gold)
//! - Buttons: "Start Default", "Scenarios", "Options", "Credits", "Quit"
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::{AppState, ScenarioSelection, SimSpeed};
use crate::scenarios::ScenarioConfig;
use crate::ui::transitions::MenuBackdrop;

/// Plugin for the main menu state
pub struct MainMenuPlugin;

impl Plugin for MainMenuPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::MainMenu), setup_main_menu)
            .add_systems(
                Update,
                handle_main_menu_input.run_if(in_state(AppState::MainMenu)),
            )
            .add_systems(
                EguiPrimaryContextPass,
                render_main_menu.run_if(in_state(AppState::MainMenu)),
            )
            .add_systems(OnExit(AppState::MainMenu), cleanup_main_menu)
            .init_resource::<ScenarioConfig>()
            .init_resource::<ScenarioPickerState>();
    }
}

/// Resource to track the scenario picker state
#[derive(Resource, Default)]
pub struct ScenarioPickerState {
    /// Whether the scenario picker is currently open
    pub is_open: bool,
    /// Selected scenario index (None means no selection)
    pub selected_index: Option<usize>,
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

fn setup_main_menu(
    mut backdrop: ResMut<MenuBackdrop>,
) {
    // Enable the dark backdrop for the menu
    backdrop.visible = true;
    backdrop.opacity = 0.6; // 60% opacity
}

fn handle_main_menu_input(
    _commands: Commands,
    _app_state: ResMut<NextState<AppState>>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Escape goes back (though there's nowhere to go from main menu)
    if keyboard_input.just_pressed(KeyCode::Escape) {
        // Could go to a previous state, but for now just stay
    }
}

fn render_main_menu(
    mut egui_contexts: EguiContexts,
    mut commands: Commands,
    mut app_state: ResMut<NextState<AppState>>,
    scenario_config: Res<ScenarioConfig>,
    mut scenario_picker: ResMut<ScenarioPickerState>,
) {
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Main menu panel - transparent to show 3D world behind
        egui::CentralPanel::default()
            .frame(egui::Frame::NONE)
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 40.0);
                    
                    // Title
                    ui.heading(egui::RichText::new("FORGEBORN")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                        .size(72.0));

                    // Buttons
                    if ui.button(egui::RichText::new("Start Default").size(24.0)).clicked() {
                        commands.insert_resource(ScenarioSelection::default());
                        commands.insert_resource(SimSpeed(0.1));
                        app_state.set(AppState::Loading);
                    }

                    if ui.button(egui::RichText::new("Scenarios").size(24.0)).clicked() {
                        scenario_picker.is_open = true;
                        scenario_picker.selected_index = None;
                    }

                    if ui.button(egui::RichText::new("Options").size(24.0)).clicked() {
                        app_state.set(AppState::Options);
                    }

                    if ui.button(egui::RichText::new("Credits").size(24.0)).clicked() {
                        app_state.set(AppState::Credits);
                    }

                    if ui.button(egui::RichText::new("Quit").size(24.0)).clicked() {
                        std::process::exit(0);
                    }
                });
            });

        // Scenario picker modal
        if scenario_picker.is_open {
            render_scenario_picker(ctx, &scenario_config, &mut scenario_picker, &mut commands, &mut app_state);
        }
    }
}

/// Render the scenario picker modal
fn render_scenario_picker(
    ctx: &mut egui::Context,
    scenario_config: &Res<ScenarioConfig>,
    scenario_picker: &mut ResMut<ScenarioPickerState>,
    commands: &mut Commands,
    app_state: &mut ResMut<NextState<AppState>>,
) {
    // Semi-transparent overlay
    let screen_rect = ctx.input(|i| i.viewport_rect());
    let painters = ctx.layer_painter(egui::LayerId::background());
    painters.rect_filled(
        screen_rect,
        0.0,
        egui::Color32::from_black_alpha(180),
    );

    // Modal window
    egui::Area::new(egui::Id::new("scenario_picker"))
        .anchor(egui::Align2::CENTER_CENTER, egui::Vec2::ZERO)
        .show(ctx, |ui| {
            egui::Frame::NONE
                .fill(egui::Color32::from_rgba_unmultiplied(42, 47, 54, 240))
                .stroke(egui::Stroke::new(2.0, egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255)))
                .corner_radius(10.0)
                .inner_margin(20.0)
                .outer_margin(egui::Margin::same(40))
                .show(ui, |ui| {
                    ui.set_min_width(600.0);
                    
                    // Title
                    ui.centered_and_justified(|ui| {
                        ui.heading(egui::RichText::new("Select a Scenario")
                            .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255)));
                    });
                    
                    ui.separator();
                    ui.add_space(10.0);

                    // Scenario list
                    egui::ScrollArea::vertical().show(ui, |ui| {
                        let scenarios = &scenario_config.scenarios;
                        
                        for (index, scenario) in scenarios.iter().enumerate() {
                            let is_selected = scenario_picker.selected_index == Some(index);
                            
                            // Create a selectable row
                            let response = ui.selectable_value(
                                &mut scenario_picker.selected_index,
                                Some(index),
                                format!("{}\n{}\nCatastrophe: {:?} | NPCs: {}",
                                    scenario.name,
                                    scenario.description,
                                    scenario.catastrophe,
                                    scenario.npc_count)
                            );
                            
                            // Style the selectable
                            if is_selected {
                                response.highlight();
                            }
                        }
                    });

                    ui.separator();
                    ui.add_space(10.0);

                    // Buttons
                    ui.horizontal(|ui| {
                        if ui.button(egui::RichText::new("Cancel").size(18.0)).clicked() {
                            scenario_picker.is_open = false;
                        }
                        
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui.button(egui::RichText::new("Start").size(18.0)).clicked()
                                && let Some(index) = scenario_picker.selected_index
                            {
                                let scenario = &scenario_config.scenarios[index];
                                commands.insert_resource(ScenarioSelection {
                                    scenario_id: scenario.id.clone(),
                                    display_name: scenario.name.clone(),
                                    description: scenario.description.clone(),
                                });
                                commands.insert_resource(SimSpeed(0.1));
                                scenario_picker.is_open = false;
                                app_state.set(AppState::Loading);
                            }
                        });
                    });
                });
        });
}

fn cleanup_main_menu(
    mut backdrop: ResMut<MenuBackdrop>,
) {
    // Disable the backdrop when leaving the menu
    backdrop.visible = false;
}
