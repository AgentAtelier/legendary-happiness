//! Credits screen state.
//!
//! Shows:
//! - "Engine: Anvil"
//! - "Design: Forgeborn"
//! - "Built with: Bevy, Rapier, egui, Kira"
//! - "Inspired by: Dwarf Fortress, The Sims, Kenshi"
//! - A thank-you to the open-source community
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::AppState;

/// Plugin for the credits state
pub struct CreditsPlugin;

impl Plugin for CreditsPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Credits), setup_credits)
            .add_systems(
                EguiPrimaryContextPass,
                render_credits.run_if(in_state(AppState::Credits)),
            )
            .add_systems(OnExit(AppState::Credits), cleanup_credits);
    }
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

fn setup_credits() {
    // Nothing to setup for egui-based UI
}

fn render_credits(
    mut egui_contexts: EguiContexts,
    mut app_state: ResMut<NextState<AppState>>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Check for any key press to go back
    if keyboard_input.get_just_pressed().next().is_some() || keyboard_input.just_pressed(KeyCode::Escape) {
        app_state.set(AppState::MainMenu);
        return;
    }
    
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::CentralPanel::default()
            .frame(egui::Frame {
                fill: egui::Color32::from_rgba_unmultiplied(26, 30, 33, 255),
                ..default()
            })
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 20.0);
                    
                    // Title
                    ui.heading(egui::RichText::new("FORGEBORN")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                        .size(64.0));

                    ui.separator();
                    ui.add_space(30.0);

                    // Credits content
                    ui.centered_and_justified(|ui| {
                        ui.vertical_centered(|ui| {
                            ui.label(egui::RichText::new("Engine: Anvil")
                                .color(egui::Color32::WHITE)
                                .size(24.0));
                            
                            ui.label(egui::RichText::new("Design: Forgeborn")
                                .color(egui::Color32::WHITE)
                                .size(24.0));
                            
                            ui.add_space(20.0);

                            ui.label(egui::RichText::new("Built with: Bevy, Rapier, egui, Kira Audio")
                                .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255))
                                .size(18.0));
                            
                            ui.add_space(20.0);

                            ui.label(egui::RichText::new("Inspired by: Dwarf Fortress, The Sims, Kenshi")
                                .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255))
                                .size(18.0));
                            
                            ui.add_space(30.0);
                            ui.separator();
                            ui.add_space(20.0);

                            ui.label(egui::RichText::new("Thank you to the open-source community")
                                .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                                .size(20.0));

                            ui.add_space(40.0);

                            ui.label(egui::RichText::new("Press any key to return")
                                .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255))
                                .size(14.0));
                        });
                    });
                });
            });
    }
}

fn cleanup_credits() {
    // Nothing to clean up for egui-based UI
}
