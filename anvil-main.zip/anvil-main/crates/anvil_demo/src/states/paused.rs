//! Pause overlay state.
//!
//! Full-screen semi-transparent black overlay (70% opacity).
//! Centred panel: "PAUSED", buttons for Resume, Restart Scenario, Options, Quit to Menu.
//! Escape in Paused returns to InGame.
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::{AppState, ScenarioSelection};

/// Plugin for the paused state
pub struct PausedPlugin;

impl Plugin for PausedPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Paused), setup_pause_overlay)
            .add_systems(
                Update,
                handle_pause_input.run_if(in_state(AppState::Paused)),
            )
            .add_systems(
                EguiPrimaryContextPass,
                render_pause_overlay.run_if(in_state(AppState::Paused)),
            )
            .add_systems(OnExit(AppState::Paused), cleanup_pause_overlay);
    }
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

fn setup_pause_overlay() {
    // Nothing to setup for egui-based UI
}

fn handle_pause_input(
    mut app_state: ResMut<NextState<AppState>>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    // Escape unpauses
    if keyboard_input.just_pressed(KeyCode::Escape) {
        app_state.set(AppState::InGame);
    }
}

fn render_pause_overlay(
    mut egui_contexts: EguiContexts,
    mut app_state: ResMut<NextState<AppState>>,
    mut commands: Commands,
    scenario_selection: Res<ScenarioSelection>,
) {
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        // Semi-transparent overlay
        egui::CentralPanel::default()
            .frame(egui::Frame {
                fill: egui::Color32::from_rgba_unmultiplied(0, 0, 0, 180), // 70% opacity
                ..default()
            })
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 20.0);

                    // Title
                    ui.heading(egui::RichText::new("PAUSED")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                        .size(48.0));

                    // Subtitle with current scenario
                    ui.label(egui::RichText::new(format!("Scenario: {}", scenario_selection.display_name))
                        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255))
                        .size(18.0));

                    ui.separator();

                    // Buttons
                    if ui.button(egui::RichText::new("Resume").size(20.0)).clicked() {
                        app_state.set(AppState::InGame);
                    }

                    if ui.button(egui::RichText::new("Restart Scenario").size(20.0)).clicked() {
                        // Re-insert the current scenario selection to ensure it's used
                        commands.insert_resource(scenario_selection.clone());
                        app_state.set(AppState::Loading);
                    }

                    if ui.button(egui::RichText::new("Options").size(20.0)).clicked() {
                        app_state.set(AppState::Options);
                    }

                    if ui.button(egui::RichText::new("Quit to Menu").size(20.0)).clicked() {
                        app_state.set(AppState::MainMenu);
                    }
                });
            });
    }
}

fn cleanup_pause_overlay() {
    // Nothing to clean up for egui-based UI
}
