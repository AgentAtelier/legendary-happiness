//! Error screen state.
//!
//! Shows:
//! - Title: "Something Went Wrong"
//! - Plain-language message (never a Rust stack trace)
//! - Buttons: Retry, Start Default, Quit
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::AppState;

/// Resource containing the error message to display
#[derive(Resource, Default)]
pub struct AppError {
    /// Plain-language error message
    pub message: String,
    /// Optional technical details (not shown to user)
    #[allow(dead_code)]
    pub details: Option<String>,
}

/// Plugin for the error state
pub struct ErrorPlugin;

impl Plugin for ErrorPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Error), setup_error_screen)
            .add_systems(
                EguiPrimaryContextPass,
                render_error_screen.run_if(in_state(AppState::Error)),
            )
            .add_systems(OnExit(AppState::Error), cleanup_error_screen)
            .init_resource::<AppError>();
    }
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

fn setup_error_screen(mut commands: Commands, error: Option<Res<AppError>>) {
    // Set a default error message if none is set
    if error.is_none() || error.as_ref().is_none_or(|e| e.message.is_empty()) {
        commands.insert_resource(AppError {
            message: "An unknown error occurred".to_string(),
            details: None,
        });
    }
}

fn render_error_screen(
    mut egui_contexts: EguiContexts,
    mut app_state: ResMut<NextState<AppState>>,
    error: Res<AppError>,
) {
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::CentralPanel::default()
            .frame(egui::Frame {
                fill: egui::Color32::from_rgba_unmultiplied(26, 30, 33, 255),
                ..default()
            })
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 20.0);

                    // Title (reddish)
                    ui.heading(egui::RichText::new("Something Went Wrong")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 50, 50, 255))
                        .size(36.0));

                    ui.separator();

                    // Error message
                    ui.label(egui::RichText::new(&error.message)
                        .color(egui::Color32::from_rgba_unmultiplied(228, 212, 185, 255))
                        .size(20.0));

                    ui.separator();

                    // Buttons
                    if ui.button(egui::RichText::new("Retry").size(18.0)).clicked() {
                        // Retry loading the current scenario
                        app_state.set(AppState::Loading);
                    }

                    if ui.button(egui::RichText::new("Start Default").size(18.0)).clicked() {
                        // Start with default scenario
                        app_state.set(AppState::MainMenu);
                    }

                    if ui.button(egui::RichText::new("Quit").size(18.0)).clicked() {
                        std::process::exit(1);
                    }
                });
            });
    }
}

fn cleanup_error_screen() {
    // Nothing to clean up for egui-based UI
}
