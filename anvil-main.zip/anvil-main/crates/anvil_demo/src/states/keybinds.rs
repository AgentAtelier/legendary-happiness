//! Keybinding reference data for the options menu.
//!
//! Contains all keybindings organized by category for display in the Controls tab.

use anvil_core::repo_path;
use serde::{Deserialize, Serialize};
use std::sync::OnceLock;
use thiserror::Error;

/// A category of keybindings.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct KeybindCategory {
    /// Category name
    pub name: String,
    /// List of keybindings in this category
    pub bindings: Vec<KeybindEntry>,
}

/// A single keybinding entry.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct KeybindEntry {
    /// Action name
    pub action: String,
    /// Primary key
    pub key: String,
    /// Optional modifier
    pub modifier: Option<String>,
    /// Description
    pub description: String,
}

/// Error type for keybind reference operations.
#[derive(Debug, Error)]
#[non_exhaustive]
pub enum KeybindReferenceError {
    /// Failed to read the keybind reference file.
    #[error("failed to read keybind reference file: {0}")]
    IoError(#[from] std::io::Error),
    /// Failed to parse the keybind reference JSON.
    #[error("failed to parse keybind reference JSON: {0}")]
    ParseError(#[from] serde_json::Error),
}

/// Loads the keybind reference from a JSON file.
pub fn load_keybind_reference() -> Result<Vec<KeybindCategory>, KeybindReferenceError> {
    let path = repo_path!("assets/ui/keybinds.json");
    let bytes = std::fs::read(&path)?;
    let categories: Vec<KeybindCategory> = serde_json::from_slice(&bytes)?;
    Ok(categories)
}

/// Cached keybind reference (lazy initialization).
static KEYBIND_REFERENCE: OnceLock<Vec<KeybindCategory>> = OnceLock::new();

/// Returns the keybind reference, loading from JSON on first use.
pub fn keybind_reference() -> &'static Vec<KeybindCategory> {
    KEYBIND_REFERENCE.get_or_init(|| {
        load_keybind_reference()
            .expect("Keybind reference must load")
    })
}

/// Create the keybind reference with all bindings.
#[deprecated(note = "Use `keybind_reference()` instead. This function will be removed once all call sites are migrated.")]
pub fn create_keybind_reference() -> Vec<KeybindCategory> {
    keybind_reference().clone()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn keybinds_json_loads() {
        let categories = load_keybind_reference()
            .expect("keybinds.json must be loadable");
        assert!(!categories.is_empty(), "Keybind reference should have categories");
        
        // Verify some expected categories exist
        let category_names: Vec<&str> = categories.iter()
            .map(|c| c.name.as_str())
            .collect();
        
        assert!(category_names.contains(&"General"));
        assert!(category_names.contains(&"Camera"));
        assert!(category_names.contains(&"Simulation"));
        assert!(category_names.contains(&"Panels"));
        assert!(category_names.contains(&"Catastrophes"));
        
        // Verify General category has expected bindings
        let general = categories.iter().find(|c| c.name == "General").unwrap();
        let binding_actions: Vec<&str> = general.bindings.iter()
            .map(|b| b.action.as_str())
            .collect();
        
        assert!(binding_actions.contains(&"Toggle Pause"));
        assert!(binding_actions.contains(&"Toggle Debug Panel"));
        assert!(binding_actions.contains(&"Quit/Back"));
    }
}
