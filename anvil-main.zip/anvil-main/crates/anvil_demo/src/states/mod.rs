//! Application states module.
//!
//! Each state owns its UI, input, and transitions. Simulation runs during
//! Loading and InGame. Simulation time pauses in Paused. All other states
//! stop the sim clock.

pub mod credits;
pub mod error;
pub mod ingame;
pub mod keybinds;
pub mod loading;
pub mod menu;
pub mod options;
pub mod paused;
pub mod splash;
