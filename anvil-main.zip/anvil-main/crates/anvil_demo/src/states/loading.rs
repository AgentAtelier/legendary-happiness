//! Loading screen state.
//!
//! A `Loading` state with:
//! - "LOADING..." title
//! - A progress bar (horizontal rectangle that fills from 0 to 100%)
//! - A status text: "Generating terrain...", "Spawning NPCs...",
//!   "Building connections...", "Stabilising simulation..."
//! - A rotating lore tip
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};

use crate::app::AppState;
use crate::scenarios::loader::ScenarioLoader;

/// Loading progress resource
#[derive(Resource, Default)]
pub struct LoadingProgress {
    /// Current progress (0.0 to 1.0)
    pub value: f32,
    /// Current status message
    pub status: String,
    /// Current lore tip index
    pub tip_index: usize,
    /// Timer for tip rotation
    pub tip_timer: Timer,
}

/// Loading tips
const LOADING_TIPS: &[&str] = &[
    "The world does not care. People do.",
    "Every villager has a unique personality shaped by their past.",
    "Trigger catastrophes with F1-F7 to test the settlement.",
    "Click on NPCs to see what they're doing and why.",
    "The sky remembers the village's mood.",
    "Joy emerges from survival, not from scripting.",
    "Time is a resource. Use it wisely.",
];

/// Loading phases
const LOADING_PHASES: &[&str] = &[
    "Generating terrain...",
    "Spawning NPCs...",
    "Building connections...",
    "Stabilising simulation...",
];

/// Plugin for the loading screen state
pub struct LoadingPlugin;

impl Plugin for LoadingPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Loading), setup_loading_screen)
            .add_systems(
                Update,
                (
                    update_loading_progress,
                    update_loading_tips,
                )
                    .run_if(in_state(AppState::Loading)),
            )
            .add_systems(
                EguiPrimaryContextPass,
                render_loading_screen.run_if(in_state(AppState::Loading)),
            )
            .add_systems(OnExit(AppState::Loading), cleanup_loading_screen)
            .init_resource::<LoadingProgress>();
    }
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

fn setup_loading_screen(mut commands: Commands) {
    commands.insert_resource(LoadingProgress {
        value: 0.0,
        status: "Initializing...".to_string(),
        tip_index: 0,
        tip_timer: Timer::from_seconds(3.0, TimerMode::Repeating),
    });
}

fn update_loading_progress(
    time: Res<Time>,
    mut loading_progress: ResMut<LoadingProgress>,
    mut app_state: ResMut<NextState<AppState>>,
) {
    // Tick the timer
    loading_progress.tip_timer.tick(time.delta());

    // Simulate loading progress through phases
    let phase_duration = 0.8;
    let elapsed = loading_progress.tip_timer.elapsed_secs();
    let phase = (elapsed / phase_duration).floor() as usize;

    if phase < LOADING_PHASES.len() {
        loading_progress.status = LOADING_PHASES[phase].to_string();
        loading_progress.value = (phase as f32 + (elapsed % phase_duration) / phase_duration)
            / LOADING_PHASES.len() as f32;
    } else {
        loading_progress.value = 1.0;
        loading_progress.status = "Complete!".to_string();
    }

    // Transition to InGame when complete
    if loading_progress.value >= 1.0 {
        app_state.set(AppState::InGame);
    }
}

fn update_loading_tips(
    time: Res<Time>,
    mut loading_progress: ResMut<LoadingProgress>,
) {
    loading_progress.tip_timer.tick(time.delta());

    if loading_progress.tip_timer.just_finished() {
        loading_progress.tip_index =
            (loading_progress.tip_index + 1) % LOADING_TIPS.len();
    }
}

fn render_loading_screen(
    mut egui_contexts: EguiContexts,
    loading_progress: Res<LoadingProgress>,
    scenario_loader: Option<Res<ScenarioLoader>>,
) {
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::CentralPanel::default()
            .frame(egui::Frame {
                fill: egui::Color32::from_rgba_unmultiplied(26, 30, 33, 255),
                ..default()
            })
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 30.0);

                    // Title
                    ui.heading(egui::RichText::new("LOADING...")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                        .size(48.0));

                    // Progress bar - use either the old progress or the new loader
                    let (progress, use_new_loader) = if let Some(ref loader) = scenario_loader {
                        (loader.progress(), true)
                    } else {
                        (loading_progress.value.clamp(0.0, 1.0), false)
                    };
                    
                    let progress_bar = egui::ProgressBar::new(progress)
                        .desired_width(500.0);
                    
                    // Show percentage if using the new loader
                    if use_new_loader {
                        ui.add(progress_bar.show_percentage());
                    } else {
                        ui.add(progress_bar);
                    }

                    // Status text
                    let status = if let Some(ref loader) = scenario_loader {
                        loader.status.clone()
                    } else {
                        loading_progress.status.clone()
                    };
                    ui.label(&status);

                    // Tip text
                    let tip_index = if let Some(ref loader) = scenario_loader {
                        // Use scenario name as tip for now
                        loader.scenario.as_ref().map_or(0, |s| {
                            // Hash the scenario name to get a tip index
                            s.name.len() % LOADING_TIPS.len()
                        })
                    } else {
                        loading_progress.tip_index
                    };
                    let current_tip = LOADING_TIPS[tip_index % LOADING_TIPS.len()];
                    ui.label(egui::RichText::new(current_tip)
                        .color(egui::Color32::from_rgba_unmultiplied(150, 150, 150, 255))
                        .size(16.0));
                });
            });
    }
}

fn cleanup_loading_screen() {
    // Nothing to clean up for egui-based UI
}
