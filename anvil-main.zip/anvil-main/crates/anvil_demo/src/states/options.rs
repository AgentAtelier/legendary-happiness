//! Options menu state.
//!
//! Tabs or sections for:
//! - Display (UI scale slider)
//! - Audio (master volume slider, mute toggle)
//! - Accessibility (subtitle toggle, colour-blind mode toggle)
//! - Controls (keybind reference)
//!
//! Note: Using bevy_egui for immediate mode UI.

use bevy::ecs::system::SystemParam;
use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts, EguiPrimaryContextPass};
use serde::{Deserialize, Serialize};

use crate::app::AppState;
use crate::states::keybinds::{keybind_reference, KeybindCategory};

// System parameter to bundle all option resources
#[derive(SystemParam)]
struct OptionsParams<'w> {
    display: ResMut<'w, DisplayOptions>,
    audio: ResMut<'w, AudioOptions>,
    accessibility: ResMut<'w, AccessibilityOptions>,
    asset: ResMut<'w, AssetOptions>,
}

// -----------------------------------------------------------
// Options State Resources
// -----------------------------------------------------------

/// Resource for display options.
#[derive(Resource, Clone, Debug, Serialize, Deserialize)]
pub struct DisplayOptions {
    /// UI scale (80-140%)
    pub ui_scale: f32,
}

impl Default for DisplayOptions {
    fn default() -> Self {
        Self { ui_scale: 1.0 }
    }
}

/// Resource for audio options.
#[derive(Resource, Clone, Debug, Serialize, Deserialize)]
pub struct AudioOptions {
    /// Master volume (0.0 to 1.0)
    pub master_volume: f32,
    /// Whether audio is muted
    pub muted: bool,
    /// Ambient volume (0.0 to 1.0)
    pub ambient_volume: f32,
    /// UI sound effects volume (0.0 to 1.0)
    pub ui_volume: f32,
}

impl Default for AudioOptions {
    fn default() -> Self {
        Self {
            master_volume: 0.7,
            muted: false,
            ambient_volume: 0.5,
            ui_volume: 0.8,
        }
    }
}

/// Resource for accessibility options.
#[derive(Resource, Clone, Debug, Serialize, Deserialize)]
pub struct AccessibilityOptions {
    /// Whether subtitles are enabled
    pub subtitles_enabled: bool,
    /// Whether color-blind mode is enabled
    pub color_blind_mode: bool,
    /// Text size multiplier for subtitles
    pub subtitle_size: f32,
}

impl Default for AccessibilityOptions {
    fn default() -> Self {
        Self {
            subtitles_enabled: true,
            color_blind_mode: false,
            subtitle_size: 1.0,
        }
    }
}

/// Resource for asset options.
#[derive(Resource, Clone, Debug, Serialize, Deserialize, Default)]
pub struct AssetOptions {
    /// Whether to use CC0 assets instead of NM-derived assets
    pub use_cc0_assets: bool,
    /// Whether to use CC0 NPC model (if available)
    pub use_cc0_npc_model: bool,
}

/// Which options tab is currently selected.
#[derive(Resource, Default, Clone, Copy, PartialEq, Eq)]
pub enum OptionsTab {
    #[default]
    Display,
    Audio,
    Accessibility,
    Controls,
    Assets,
}

/// Resource containing all keybindings for reference.
#[derive(Resource, Clone)]
pub struct KeybindReference {
    /// List of keybind categories and their bindings.
    pub categories: Vec<KeybindCategory>,
}

impl Default for KeybindReference {
    fn default() -> Self {
        Self {
            categories: keybind_reference().clone(),
        }
    }
}

/// Plugin for the options menu state
pub struct OptionsPlugin;

impl Plugin for OptionsPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(OnEnter(AppState::Options), setup_options_menu)
            .add_systems(
                Update,
                handle_options_input.run_if(in_state(AppState::Options)),
            )
            .add_systems(
                EguiPrimaryContextPass,
                render_options_menu.run_if(in_state(AppState::Options)),
            )
            .add_systems(OnExit(AppState::Options), cleanup_options_menu)
            .init_resource::<DisplayOptions>()
            .init_resource::<AudioOptions>()
            .init_resource::<AccessibilityOptions>()
            .init_resource::<AssetOptions>()
            .init_resource::<OptionsTab>()
            .init_resource::<KeybindReference>();
    }
}

// -----------------------------------------------------------
// Extension trait for egui contexts
// -----------------------------------------------------------

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

// -----------------------------------------------------------
// Setup and Cleanup
// -----------------------------------------------------------

fn setup_options_menu() {
    // Nothing to setup for egui-based UI
}

fn handle_options_input(
    mut app_state: ResMut<NextState<AppState>>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
) {
    if keyboard_input.just_pressed(KeyCode::Escape) {
        app_state.set(AppState::MainMenu);
    }
}

fn cleanup_options_menu() {
    // Nothing to clean up for egui-based UI
}

// -----------------------------------------------------------
// Render Options Menu
// -----------------------------------------------------------

fn render_options_menu(
    mut egui_contexts: EguiContexts,
    mut app_state: ResMut<NextState<AppState>>,
    mut options: OptionsParams,
    mut current_tab: ResMut<OptionsTab>,
    keybinds: Res<KeybindReference>,
) {
    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::CentralPanel::default()
            .frame(egui::Frame {
                fill: egui::Color32::from_rgba_unmultiplied(42, 47, 54, 255),
                ..default()
            })
            .show(ctx, |ui| {
                ui.centered_and_justified(|ui| {
                    ui.spacing_mut().item_spacing = egui::Vec2::new(0.0, 20.0);
                    
                    // Title
                    ui.heading(egui::RichText::new("Options")
                        .color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255))
                        .size(48.0));
                    
                    ui.separator();

                    // Tab selection
                    ui.horizontal(|ui| {
                        ui.selectable_value(&mut *current_tab, OptionsTab::Display, "Display");
                        ui.selectable_value(&mut *current_tab, OptionsTab::Audio, "Audio");
                        ui.selectable_value(&mut *current_tab, OptionsTab::Accessibility, "Accessibility");
                        ui.selectable_value(&mut *current_tab, OptionsTab::Controls, "Controls");
                        ui.selectable_value(&mut *current_tab, OptionsTab::Assets, "Assets");
                    });
                    
                    ui.separator();

                    // Render the selected tab
                    match *current_tab {
                        OptionsTab::Display => render_display_tab(ui, &mut options.display),
                        OptionsTab::Audio => render_audio_tab(ui, &mut options.audio),
                        OptionsTab::Accessibility => render_accessibility_tab(ui, &mut options.accessibility),
                        OptionsTab::Controls => render_controls_tab(ui, &keybinds),
                        OptionsTab::Assets => render_assets_tab(ui, &mut options.asset),
                    }

                    ui.separator();
                    ui.add_space(10.0);

                    // Back button
                    if ui.button(egui::RichText::new("Back").size(20.0)).clicked() {
                        app_state.set(AppState::MainMenu);
                    }
                });
            });
    }
}

fn render_display_tab(ui: &mut egui::Ui, display_options: &mut DisplayOptions) {
    ui.heading("Display Settings");
    ui.add_space(10.0);

    // UI Scale slider
    ui.label("UI Scale");
    let mut scale_percent = display_options.ui_scale * 100.0;
    if ui.add(egui::Slider::new(&mut scale_percent, 80.0..=140.0).text("%%")).changed() {
        display_options.ui_scale = scale_percent / 100.0;
    }
    ui.label(egui::RichText::new(format!("Current: {:.0}%", scale_percent))
        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255)));

    ui.add_space(20.0);
    ui.label(egui::RichText::new("Adjust the size of all UI elements.")
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255))
        .size(14.0));
}

fn render_audio_tab(ui: &mut egui::Ui, audio_options: &mut AudioOptions) {
    ui.heading("Audio Settings");
    ui.add_space(10.0);

    // Master volume
    ui.label("Master Volume");
    if ui.add(egui::Slider::new(&mut audio_options.master_volume, 0.0..=1.0)).changed() {
        // Clamp to valid range
        audio_options.master_volume = audio_options.master_volume.clamp(0.0, 1.0);
    }
    ui.label(egui::RichText::new(format!("Volume: {:.0}%", audio_options.master_volume * 100.0))
        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255)));

    ui.add_space(10.0);

    // Mute toggle
    ui.checkbox(&mut audio_options.muted, "Mute All Audio");

    ui.add_space(20.0);

    // Ambient volume
    ui.label("Ambient Volume");
    if ui.add(egui::Slider::new(&mut audio_options.ambient_volume, 0.0..=1.0)).changed() {
        audio_options.ambient_volume = audio_options.ambient_volume.clamp(0.0, 1.0);
    }
    ui.label(egui::RichText::new(format!("Volume: {:.0}%", audio_options.ambient_volume * 100.0))
        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255)));

    ui.add_space(20.0);

    // UI volume
    ui.label("UI Sound Effects");
    if ui.add(egui::Slider::new(&mut audio_options.ui_volume, 0.0..=1.0)).changed() {
        audio_options.ui_volume = audio_options.ui_volume.clamp(0.0, 1.0);
    }
    ui.label(egui::RichText::new(format!("Volume: {:.0}%", audio_options.ui_volume * 100.0))
        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255)));
}

fn render_accessibility_tab(ui: &mut egui::Ui, accessibility_options: &mut AccessibilityOptions) {
    ui.heading("Accessibility Settings");
    ui.add_space(10.0);

    // Subtitles toggle
    ui.checkbox(&mut accessibility_options.subtitles_enabled, "Subtitles");
    ui.label(egui::RichText::new("Display narration text as captions at the bottom of the screen.")
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255))
        .size(14.0));

    ui.add_space(15.0);

    // Subtitle size
    ui.label("Subtitle Size");
    let mut subtitle_percent = accessibility_options.subtitle_size * 100.0;
    if ui.add(egui::Slider::new(&mut subtitle_percent, 50.0..=200.0).text("%%")).changed() {
        accessibility_options.subtitle_size = subtitle_percent / 100.0;
    }
    ui.label(egui::RichText::new(format!("Size: {:.0}%", subtitle_percent))
        .color(egui::Color32::from_rgba_unmultiplied(180, 180, 180, 255)));

    ui.add_space(20.0);

    // Color-blind mode toggle
    ui.checkbox(&mut accessibility_options.color_blind_mode, "Colour-Friendly Mode");
    ui.label(egui::RichText::new("Replace red-green aura palette with blue-orange for better visibility.")
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255))
        .size(14.0));
    
    ui.add_space(10.0);
    
    // Color-blind legend
    if accessibility_options.color_blind_mode {
        ui.label("Active: Threat→Orange, Belonging→Blue, Agency→Yellow, Desperation→Pink");
    }
}

fn render_controls_tab(ui: &mut egui::Ui, keybinds: &KeybindReference) {
    ui.heading("Controls Reference");
    ui.add_space(10.0);
    ui.label(egui::RichText::new("All keyboard shortcuts available in the game.")
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255))
        .size(14.0));
    
    ui.add_space(10.0);

    // Render each category in a collapsible section
    for category in &keybinds.categories {
        ui.collapsing(&category.name, |ui| {
            // Create a grid for the bindings
            egui::Grid::new(category.name.to_string())
                .num_columns(3)
                .striped(true)
                .show(ui, |ui| {
                    // Header row
                    ui.label(egui::RichText::new("Action").strong());
                    ui.label(egui::RichText::new("Key").strong());
                    ui.label(egui::RichText::new("Description").strong());
                    ui.end_row();

                    // Binding rows
                    for binding in &category.bindings {
                        let key_text = match &binding.modifier {
                            Some(modif) => format!("{}+{}", modif, binding.key),
                            None => binding.key.clone(),
                        };

                        ui.label(&binding.action);
                        ui.label(egui::RichText::new(&key_text).color(egui::Color32::from_rgba_unmultiplied(200, 140, 75, 255)));
                        ui.label(&binding.description);
                        ui.end_row();
                    }
                });
        });
        ui.add_space(8.0);
    }
}

fn render_assets_tab(ui: &mut egui::Ui, asset_options: &mut AssetOptions) {
    ui.heading("Asset Settings");
    ui.add_space(10.0);

    ui.label("Configure CC0 asset usage. These are legally redistributable alternatives to NM-derived assets.");

    ui.add_space(15.0);

    // CC0 Assets toggle
    ui.checkbox(
        &mut asset_options.use_cc0_assets,
        egui::RichText::new("Use CC0 Assets").size(18.0),
    );
    ui.label(
        egui::RichText::new(
            "Replace all NatureManufacture assets with CC0 alternatives from Kenney.nl, Freesound, and AmbientCG.",
        )
        .size(14.0)
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255)),
    );

    ui.add_space(10.0);

    // CC0 NPC Model toggle
    ui.checkbox(
        &mut asset_options.use_cc0_npc_model,
        egui::RichText::new("Use CC0 NPC Model").size(18.0),
    );
    ui.label(
        egui::RichText::new(
            "Use the CC0 humanoid model instead of procedural capsule placeholders.",
        )
        .size(14.0)
        .color(egui::Color32::from_rgba_unmultiplied(120, 120, 120, 255)),
    );

    ui.add_space(20.0);

    // Info about CC0 sources
    ui.label(egui::RichText::new("CC0 Asset Sources:").strong());
    ui.label(egui::RichText::new("• Audio: Freesound.org (InspectorJ, acclivity)").size(14.0));
    ui.label(egui::RichText::new("• Models: Kenney.nl").size(14.0));
    ui.label(egui::RichText::new("• Textures: AmbientCG.com").size(14.0));
    ui.add_space(5.0);
    ui.label(
        egui::RichText::new("See ASSET_REGISTRY.md and CREDITS.txt for full attribution.")
            .size(12.0)
            .color(egui::Color32::from_rgba_unmultiplied(100, 100, 100, 255)),
    );
}
