//! Simulation integration for anvil_demo.
//!
//! This module provides the simulation systems integration for the demo,
//! including resource definitions and ticking logic.

use anvil_runtime::{RuntimeCommand, RuntimeEvent};
use anvil_sim::DeterministicRng;
use bevy::prelude::{Res, ResMut, Resource};
use tracing::error;

use crate::app::{RuntimeResource, SimSpeed};
use crate::event_log::EventLog;

// -----------------------------------------------------------
// Simulation Constants
// -----------------------------------------------------------

/// Number of simulation ticks to run per rendered frame.
pub const TICKS_PER_FRAME: u64 = 60;

/// Fixed delta time per tick in microseconds (1/60 second = ~16667 microseconds).
pub const TICK_DT_MICROS: u64 = 16_667;

/// Interval in ticks for printing simulation status to console.
pub const SIM_STATUS_PRINT_INTERVAL: u64 = 600;

// -----------------------------------------------------------
// Simulation Resources
// -----------------------------------------------------------

/// Bevy resource tracking the simulation tick counter.
#[derive(Resource, Default)]
pub struct SimTickCounter {
    /// Current simulation tick number.
    pub count: u64,
    /// Accumulator for fractional tick scaling.
    /// Prevents drift when sim_speed is not an integer.
    pub tick_accumulator: f32,
}

/// Bevy resource wrapping the deterministic RNG.
///
/// Note: This is a simple wrapper that owns the RNG. Since Bevy's Update
/// schedule runs on a single thread, we don't need interior mutability here.
#[derive(Resource)]
pub struct SimRng {
    /// The deterministic RNG state.
    pub rng: DeterministicRng,
}

impl SimRng {
    /// Creates a new wrapped RNG with the given seed.
    pub fn new(seed: u64) -> Self {
        Self {
            rng: DeterministicRng::new(seed),
        }
    }
}

impl Default for SimRng {
    fn default() -> Self {
        Self::new(42)
    }
}

/// System that ticks all simulation systems each frame.
/// The number of ticks is controlled by SimSpeed:
/// - 0.0 = no ticks (paused)
/// - 0.1 = 1 tick per 10 frames (slow)
/// - 1.0 = TICKS_PER_FRAME ticks (normal)
pub fn tick_simulation_systems(
    mut runtime: ResMut<RuntimeResource>,
    mut tick_counter: ResMut<SimTickCounter>,
    sim_speed: Res<SimSpeed>,
    mut event_log: ResMut<EventLog>,
) {
    // If sim speed is 0, don't tick at all (paused)
    if sim_speed.0 <= 0.0 {
        return;
    }

    // Use accumulator for fractional tick scaling to prevent drift
    tick_counter.tick_accumulator += TICKS_PER_FRAME as f32 * sim_speed.0;
    let ticks_to_run = tick_counter.tick_accumulator.trunc() as u64;
    tick_counter.tick_accumulator = tick_counter.tick_accumulator.fract();

    // Tick the runtime for each simulation step
    for _ in 0..ticks_to_run {
        match runtime.runtime.apply(&RuntimeCommand::Tick { dt_micros: TICK_DT_MICROS }) {
            Ok(events) => {
                for event in &events {
                    if let RuntimeEvent::SystemError { system_name, error } = event {
                        error!(
                            system = system_name,
                            tick = tick_counter.count,
                            "{}",
                            error,
                        );
                        event_log.add_event(
                            tick_counter.count,
                            format!("{}: {}", system_name, error),
                            crate::event_log::EventCategory::Catastrophe,
                        );
                    }
                }
            }
            Err(e) => {
                error!(tick = tick_counter.count, "runtime apply failed: {}", e);
                event_log.add_event(
                    tick_counter.count,
                    format!("Runtime: {}", e),
                    crate::event_log::EventCategory::Catastrophe,
                );
            }
        }
        tick_counter.count += 1;
    }

    // Log status at startup and every SIM_STATUS_PRINT_INTERVAL ticks
    if tick_counter.count == 0 || tick_counter.count.is_multiple_of(SIM_STATUS_PRINT_INTERVAL) {
        tracing::debug!(tick = tick_counter.count, speed = sim_speed.0, "sim tick status");
    }
}
