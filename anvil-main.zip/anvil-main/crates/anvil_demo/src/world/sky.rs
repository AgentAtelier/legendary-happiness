//! Procedural sky gradient rendering.
//!
//! Creates a large inverted sphere (radius ~150) representing the sky.
//! Uses horizon color (#2E3E55) for now - proper gradient requires custom shader.
//! Sun disk glow (#F59E0B) at 45° elevation is configured in atmosphere.rs.

use bevy::prelude::*;

/// Radius of the sky sphere.
pub const SKY_RADIUS: f32 = 150.0;

/// Top color of the sky gradient - deep blue (#1B2433).
#[allow(dead_code)]
pub const SKY_TOP_COLOR: Color = Color::srgb(0.1059, 0.1451, 0.20);

/// Horizon color of the sky gradient - lighter blue-grey (#2E3E55).
#[allow(dead_code)]
pub const SKY_HORIZON_COLOR: Color = Color::srgb(0.1804, 0.2431, 0.3333);

/// Sun color - warm orange (#F59E0B).
#[allow(dead_code)]
pub const SUN_COLOR: Color = Color::srgb(0.9608, 0.6196, 0.0431);

/// Sun direction (normalized vector pointing toward the sun).
/// At 45 degree elevation in the XZ plane.
/// Uses FRAC_1_SQRT_2 which is approximately 0.7071 (1/sqrt(2)).
#[allow(dead_code)]
pub const SUN_DIRECTION: Vec3 = Vec3::new(
    std::f32::consts::FRAC_1_SQRT_2,
    std::f32::consts::FRAC_1_SQRT_2,
    0.0,
);

/// Marker component for the sky entity.
#[derive(Component)]
pub struct SkyMarker;

/// System to setup the sky dome.
/// Creates a large inverted sphere with horizon color.
/// 
/// Note: Proper gradient from top (#1B2433) to horizon (#2E3E55) requires a custom
/// WGSL shader or fullscreen quad. This is the fallback using StandardMaterial
/// with horizon color. The camera clear color is set to top color in atmosphere.rs.
pub fn setup_sky(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    // Create a sphere mesh for the sky
    let sphere = Mesh::from(Sphere::new(SKY_RADIUS));
    let mesh_handle = meshes.add(sphere);

    // Use horizon color for the sky sphere
    // For a proper gradient, we'd need a custom shader that interpolates
    // between SKY_TOP_COLOR and SKY_HORIZON_COLOR based on vertex position.
    let sky_material = StandardMaterial {
        base_color: SKY_HORIZON_COLOR,
        perceptual_roughness: 1.0,
        metallic: 0.0,
        reflectance: 0.0,
        ..default()
    };
    let material_handle = materials.add(sky_material);

    // Spawn the sky entity - it will surround the camera
    commands.spawn((
        Mesh3d(mesh_handle),
        MeshMaterial3d(material_handle),
        SkyMarker,
        Transform::default(),
    ));
}
