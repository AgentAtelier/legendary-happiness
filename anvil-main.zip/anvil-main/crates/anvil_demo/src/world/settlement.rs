//! Settlement visuals module for Phase 5c.
//!
//! Visual representation of settlement state:
//! - Arch structure with opacity + tint based on structural_integrity
//! - Food dots with color based on food_store level

use bevy::pbr::StandardMaterial;
use bevy::prelude::*;

/// Component marking an entity as a settlement arch.
#[derive(Component)]
pub struct SettlementArch {
    /// Reference to settlement ID.
    #[allow(dead_code)]
    pub settlement_id: u64,
}

/// Component marking an entity as a food indicator dot.
#[derive(Component)]
pub struct FoodDot {
    /// Reference to settlement ID.
    #[allow(dead_code)]
    pub settlement_id: u64,
}

/// System to spawn settlement visuals.
pub fn spawn_settlement_visuals(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    existing_arches: Query<Entity, With<SettlementArch>>,
) {
    // Only spawn once - check if any settlement arch already exists
    if existing_arches.iter().next().is_some() {
        return;
    }

    // Position settlement visuals at a fixed location
    let settlement_position = Vec3::new(0.0, 0.0, 0.0);

    // Create the arch structure (semi-circular arch using torus segments)
    // For simplicity, use a torus as the arch
    let arch_mesh = Mesh::from(Torus::new(5.0, 0.2));
    let arch_mesh_handle = meshes.add(arch_mesh);

    // Initial arch material - will be updated based on structural_integrity
    let arch_material = StandardMaterial {
        base_color: Color::srgb(0.5, 0.5, 0.5), // Neutral grey
        ..default()
    };
    let arch_material_handle = materials.add(arch_material);

    // Spawn the arch entity
    commands.spawn((
        Mesh3d(arch_mesh_handle),
        MeshMaterial3d(arch_material_handle),
        Transform::from_translation(settlement_position + Vec3::new(0.0, 0.2, 0.0))
            .with_rotation(Quat::from_rotation_x(std::f32::consts::PI / 2.0)),
        SettlementArch {
            settlement_id: 1, // Hardcoded for now - the demo has one settlement
        },
    ));

    // Create food dot indicator
    let dot_mesh = Mesh::from(Sphere::new(0.15));
    let dot_mesh_handle = meshes.add(dot_mesh);

    let dot_material = StandardMaterial {
        base_color: Color::srgb(0.5, 0.8, 0.5), // Green by default
        ..default()
    };
    let dot_material_handle = materials.add(dot_material);

    commands.spawn((
        Mesh3d(dot_mesh_handle),
        MeshMaterial3d(dot_material_handle),
        Transform::from_translation(settlement_position + Vec3::new(0.0, 1.5, 0.0)),
        FoodDot { settlement_id: 1 },
    ));
}

/// System to update settlement visuals based on settlement state (Phase 5c).
/// Maps structural_integrity to arch opacity + tint (red->neutral grey).
/// Food dot: green >0.5, yellow >0.2, red <0.2.
#[allow(dead_code)]
pub fn update_settlement_visuals(
    mut materials: ResMut<Assets<StandardMaterial>>,
    runtime: Res<crate::app::RuntimeResource>,
    arch_query: Query<(Entity, &MeshMaterial3d<StandardMaterial>, &SettlementArch)>,
    dot_query: Query<(Entity, &MeshMaterial3d<StandardMaterial>, &FoodDot)>,
) {
    // Access the joy system through the runtime accessor
    let Some(joy_system) = runtime.runtime.joy_system() else {
        return;
    };

    // Get the first settlement
    let Some(settlement) = joy_system.settlements.first() else {
        return;
    };

    let structural_integrity = settlement.structural_integrity;
    let food_store = settlement.food_store;

    // Update arch: map structural_integrity to opacity + tint
    // Integrity 0.0 -> red, 1.0 -> neutral grey
    // Opacity scales with integrity
    for (_entity, mesh_material, _arch) in arch_query.iter() {
        if let Some(mat) = materials.get_mut(&mesh_material.0) {
            // Map integrity to red-grey gradient
            let t = structural_integrity.clamp(0.0, 1.0);
            let r = 0.5 + (0.5 - t * 0.5); // Red component: 1.0 at t=0, 0.5 at t=1
            let g = 0.5 + (t * 0.3); // Green: 0.5 at t=0, 0.8 at t=1
            let b = 0.5 + (t * 0.3); // Blue: 0.5 at t=0, 0.8 at t=1
            let alpha = 0.5 + t * 0.5; // Opacity: 0.5 at t=0, 1.0 at t=1

            mat.base_color = Color::srgba(r, g, b, alpha);
        }
    }

    // Update food dot: green >0.5, yellow >0.2, red <0.2
    for (_entity, mesh_material, _dot) in dot_query.iter() {
        if let Some(mat) = materials.get_mut(&mesh_material.0) {
            let color = if food_store > 0.5 {
                Color::srgb(0.3, 0.9, 0.3) // Green
            } else if food_store > 0.2 {
                Color::srgb(0.9, 0.9, 0.3) // Yellow
            } else {
                Color::srgb(0.9, 0.3, 0.3) // Red
            };
            mat.base_color = color;
        }
    }
}
