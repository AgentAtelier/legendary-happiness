//! Procedural ground plane with noise texture.
//!
//! Creates a large textured plane with procedural noise for terrain variation.

use bevy::prelude::*;
use bevy::render::render_resource::{Extent3d, TextureDimension, TextureFormat};
use bevy::asset::RenderAssetUsages;

/// Size of the ground plane in world units.
pub const GROUND_SIZE: f32 = 200.0;

/// Base ground color - dark earth (#2A2F36).
pub const GROUND_BASE_COLOR: Color = Color::srgb(0.1647, 0.1843, 0.2118);

/// Noise variation percentage.
pub const GROUND_NOISE_VARIATION: f32 = 0.05;

/// Noise scale for UV mapping.
pub const GROUND_NOISE_SCALE: f32 = 10.0;

/// Texture resolution for the noise map.
pub const NOISE_TEXTURE_SIZE: usize = 256;

/// Marker component for the ground entity.
#[derive(Component)]
pub struct GroundMarker;

/// Simple 2D value noise function.
/// Uses a basic hash-based approach for deterministic noise.
fn value_noise_2d(x: f32, y: f32, seed: u32) -> f32 {
    // Simple hash function
    let mut hash = seed.wrapping_mul(1664525).wrapping_add(1013904223);
    
    // Convert floats to integers
    let ix = (x * 1000.0) as i32;
    let iy = (y * 1000.0) as i32;
    
    // Hash the coordinates
    hash = hash.wrapping_mul(1664525).wrapping_add(ix as u32);
    hash = hash.wrapping_mul(1664525).wrapping_add(iy as u32);
    
    // Convert hash to float in [0, 1]
    (hash as f32) / (u32::MAX as f32)
}

/// Generate a procedural noise texture.
fn generate_noise_texture(size: usize, scale: f32, seed: u32) -> Image {
    let mut image_data = vec![0u8; size * size * 4]; // RGBA
    
    for y in 0..size {
        for x in 0..size {
            let nx = (x as f32 / size as f32 - 0.5) * 2.0 * scale;
            let ny = (y as f32 / size as f32 - 0.5) * 2.0 * scale;
            
            let noise = value_noise_2d(nx, ny, seed);
            
            // Map noise to [0.95, 1.05] variation around base
            let variation = (noise - 0.5) * 2.0 * GROUND_NOISE_VARIATION;
            let intensity = 0.95 + variation;
            
            // Convert to RGB (grayscale)
            let rgb = (intensity * 255.0).clamp(0.0, 255.0) as u8;
            
            let idx = (y * size + x) * 4;
            image_data[idx] = rgb;      // R
            image_data[idx + 1] = rgb;  // G  
            image_data[idx + 2] = rgb;  // B
            image_data[idx + 3] = 255;  // A
        }
    }
    
    Image::new(
        Extent3d {
            width: size as u32,
            height: size as u32,
            ..default()
        },
        TextureDimension::D2,
        image_data,
        TextureFormat::Rgba8UnormSrgb,
        RenderAssetUsages::RENDER_WORLD,
    )
}

/// Combined system for ground setup.
pub fn setup_ground_with_texture(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
    mut images: ResMut<Assets<Image>>,
) {
    // Generate noise texture
    let noise_texture = generate_noise_texture(
        NOISE_TEXTURE_SIZE,
        GROUND_NOISE_SCALE,
        42,
    );
    let texture_handle = images.add(noise_texture);

    // Create plane mesh
    let plane = Mesh::from(Plane3d::default().mesh().size(GROUND_SIZE, GROUND_SIZE));
    let mesh_handle = meshes.add(plane);

    // Create material with noise texture
    let ground_material = StandardMaterial {
        base_color: GROUND_BASE_COLOR,
        base_color_texture: Some(texture_handle.clone()),
        perceptual_roughness: 0.85,
        metallic: 0.0,
        ..default()
    };
    
    let material_handle = materials.add(ground_material);

    // Spawn ground
    commands.spawn((
        Mesh3d(mesh_handle),
        MeshMaterial3d(material_handle),
        GroundMarker,
        Transform::from_rotation(Quat::from_rotation_x(-std::f32::consts::PI / 2.0)),
    ));
}
