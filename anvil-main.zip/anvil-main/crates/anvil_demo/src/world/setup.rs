//! World setup module for anvil_demo.
//!
//! Contains the world initialization logic extracted from main.rs to keep file sizes under limits.

use bevy::prelude::*;
use anvil_assets::prelude::{AssetCatalogue, CatalogueQuery, MaterialOrigin, MaterialOverride, VegetationState};
use anvil_assembly::compile_plan;
use anvil_bevy::to_standard_material;
use anvil_core::RegionId;
use anvil_runtime::{Runtime, RuntimeCommand};
use anvil_sim::{
    CatastropheSystem, JoySystem, NpcSystem, PhysicsSystem, SimSystem,
    settlement::{Settlement, Person, Family},
    settlement::ids::{FamilyId, PersonId, SettlementId},
};
use anvil_world::compile_world;
use std::path::{Path, PathBuf};
use tracing::{error, warn, info};

use crate::app::{RuntimeResource, WorldResource};
use crate::world::specs::demo_specs;

/// Attempt to resolve a path relative to the repository root.
/// Returns None if the repository root cannot be determined or the path doesn't exist.
fn try_repo_path(segments: &[&str]) -> Option<PathBuf> {
    // Try to get the repository root by climbing up from CARGO_MANIFEST_DIR
    let manifest_dir = std::env::var("CARGO_MANIFEST_DIR").ok()?;
    let mut path = Path::new(&manifest_dir);
    // Climb up 2 levels: crates/<name>/ -> crates/ -> repo root
    for _ in 0..2 {
        path = path.parent()?;
    }
    Some(path.join(segments.join("/")))
}

/// Attempt to resolve an asset path with multiple fallback strategies.
/// 1. Try repo-relative path (crates/anvil_demo/../../assets/...)
/// 2. Try relative to current working directory (./assets/...)
/// 3. Try just the filename
fn resolve_asset_path(filename: &str) -> Vec<PathBuf> {
    let mut candidates = Vec::new();
    
    // Try repo-relative path
    if let Some(repo_path) = try_repo_path(&["assets", filename]) {
        candidates.push(repo_path);
    }
    
    // Try relative to current directory
    candidates.push(PathBuf::from(".").join("assets").join(filename));
    
    // Try just the filename (for when assets are bundled next to the binary)
    candidates.push(PathBuf::from(filename));
    
    candidates
}

/// Component to store pending GLB scene spawns with material override
#[derive(Component)]
pub struct PendingGltfSpawn {
    pub path: String,
    pub material: Handle<StandardMaterial>,
    pub position: Vec3,
    pub origin: MaterialOrigin,
}

/// Load the catalogue, preferring CC0 assets if requested via environment variable.
/// 
/// Uses graceful fallbacks:
/// 1. Try CC0 catalogue if ANVIL_USE_CC0_ASSETS is set
/// 2. Try regular catalogue
/// 3. Try all path resolution strategies for each
/// 4. Return empty catalogue if all fail (never panics)
pub fn load_catalogue() -> AssetCatalogue {
    let use_cc0 = std::env::var("ANVIL_USE_CC0_ASSETS")
        .map(|v| v == "1" || v.to_lowercase() == "true")
        .unwrap_or(false);
    
    let catalogue_filenames = if use_cc0 {
        ["catalogue_cc0.json", "catalogue.json"]
    } else {
        ["catalogue.json", "catalogue_cc0.json"]
    };
    
    // Try each catalogue filename with all resolution strategies
    for filename in catalogue_filenames {
        let candidates = resolve_asset_path(filename);
        
        for candidate in &candidates {
            if candidate.exists() {
                match AssetCatalogue::load(candidate, None) {
                    Ok(catalogue) => {
                        info!("Loaded catalogue from: {}", candidate.display());
                        if use_cc0 {
                            info!("Using CC0 assets mode");
                        }
                        return catalogue;
                    }
                    Err(e) => {
                        warn!("Failed to parse catalogue at {}: {}", candidate.display(), e);
                        // Continue to next candidate
                    }
                }
            }
        }
    }
    
    // If no catalogue was found, log warnings and return empty catalogue
    let tried: Vec<&str> = catalogue_filenames.iter().copied().collect();
    warn!(
        "No catalogue file found. Tried (in order): {}",
        tried.join(", ")
    );
    warn!("Using empty catalogue as fallback. Assets will use defaults.");
    
    AssetCatalogue::default()
}

/// Set up the demo world with catalogue-based asset resolution.
pub fn setup_world(
    mut commands: Commands,
    mut materials: ResMut<Assets<StandardMaterial>>,
    asset_server: Res<AssetServer>,
) {
    let catalogue = load_catalogue();
    
    let (specs, connections) = demo_specs();
    let world = match compile_world(&specs, &connections, &catalogue) {
        Ok(w) => w,
        Err(e) => {
            error!(
                "Failed to compile demo world — check that catalogue.json \
                 contains all required archetype tags.\n\nErrors:\n{:#?}",
                e
            );
            // Insert empty resources so downstream systems don't panic
            commands.insert_resource(RuntimeResource::default());
            commands.insert_resource(WorldResource::default());
            return;
        }
    };

    println!("Compiled world: {} regions, {} entities, {} connections",
        world.regions.len(), world.entities.len(), world.connections.len());

    let mut runtime = Runtime::new(world.clone());
    
    // Register simulation systems with the runtime
    // Create test settlement, families, and persons for the demo
    let settlement = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Demo Settlement".to_string(),
        RegionId::new(0),
        10,
    );

    let family1 = Family::new(
        FamilyId::new(1),
        vec![
            PersonId::new(1),
            PersonId::new(2),
        ],
    );

    let person1 = Person::new_simple(
        PersonId::new(1),
        "Aldric".to_string(),
        FamilyId::new(1),
    );
    let person2 = Person::new_simple(
        PersonId::new(2),
        "Brynn".to_string(),
        FamilyId::new(1),
    );

    // Create systems with test data
    let mut npc_system = NpcSystem::new();
    npc_system.add_settlement(settlement.clone());
    npc_system.add_family(family1);
    npc_system.add_person(person1.clone());
    npc_system.add_person(person2.clone());

    let catastrophe_system = CatastropheSystem::new();

    let mut joy_system = JoySystem::new();
    joy_system.add_settlement(settlement);
    joy_system.add_person(person1);
    joy_system.add_person(person2);

    let physics_system = PhysicsSystem::new();

    // Register systems with runtime (they will be sorted by priority)
    runtime.register_system(Box::new(npc_system) as Box<dyn SimSystem>);
    runtime.register_system(Box::new(catastrophe_system) as Box<dyn SimSystem>);
    runtime.register_system(Box::new(joy_system) as Box<dyn SimSystem>);
    runtime.register_system(Box::new(physics_system) as Box<dyn SimSystem>);

    let h0 = runtime.state_hash();
    println!("Runtime initialised. State hash: {}", hex::encode(h0));

    let highlands_id = runtime.world.regions[0].id;
    if let Err(e) = runtime.apply(&RuntimeCommand::LoadRegion { id: highlands_id }) {
        error!("Failed to apply LoadRegion: {:#?}", e);
        return;
    }
    let h1 = runtime.state_hash();
    println!("After loading Highlands. State hash: {}", hex::encode(h1));
    if h0 == h1 {
        error!("State hash did not change after LoadRegion — runtime may be broken");
        return;
    }

    let plan = match compile_plan(&world) {
        Ok(p) => p,
        Err(e) => {
            error!("Failed to compile assembly plan: {:#?}", e);
            return;
        }
    };
    println!("Assembly plan: {} entities, {} regions", plan.entities.len(), plan.regions.len());

    let snapshot_bytes = match runtime.snapshot() {
        Ok(b) => b,
        Err(e) => {
            error!("Failed to snapshot runtime: {:#?}", e);
            return;
        }
    };
    let restored_runtime = match Runtime::restore_with_world(&snapshot_bytes, runtime.world.clone()) {
        Ok(r) => r,
        Err(e) => {
            error!("Failed to restore snapshot: {:#?}", e);
            return;
        }
    };
    if runtime.state_hash() != restored_runtime.state_hash() {
        error!("Snapshot/restore changed state hash — determinism is broken");
        return;
    }
    println!("Snapshot/restore round-trip: state hash matches.");

    let loaded_regions = runtime.loaded_regions.clone();
    commands.insert_resource(RuntimeResource { runtime });
    commands.insert_resource(WorldResource { world: world.clone() });

    let mut total_spawned = 0u32;
    let spacing = 4.0;

    for (entity_idx, entity) in world.entities.iter().enumerate() {
        if !loaded_regions.contains(&entity.region) {
            continue;
        }

        if let Some(resolved) = catalogue.resolve_query(
            &CatalogueQuery::new(entity.archetype.clone()).with_vegetation(VegetationState::Mature)
        ) {
            let mesh_path = resolved.mesh_path.to_string_lossy().to_string();
            if mesh_path.ends_with(".glb") || mesh_path.ends_with(".gltf") {
                let mat = if let Some(ref material_override) = resolved.material {
                    to_standard_material(material_override, &asset_server)
                } else {
                    to_standard_material(&MaterialOverride::default(), &asset_server)
                };
                let material_handle = materials.add(mat);

                let x = (entity_idx as f32 % 10.0) * spacing - 20.0;
                let z = (entity_idx as f32 / 10.0) * spacing;

                commands.spawn((PendingGltfSpawn {
                    path: mesh_path.clone(),
                    material: material_handle,
                    position: Vec3::new(x, 0.0, z),
                    origin: resolved.material_origin,
                },));
                total_spawned += 1;
            }
        }
    }

    println!("Spawned {} world entities with resolved assets", total_spawned);
    println!("Sim running. Tick: 0");
}
