//! Demo world specifications.
//!
//! Contains the region and connection specifications for the demo world.

use anvil_core::{ConnectionKind, ConnectionSpec, Directionality, LandmarkKind, LandmarkSpec, RegionSpec, StyleHints, TerrainType};

/// Returns the demo world specifications: regions and connections.
pub fn demo_specs() -> (Vec<RegionSpec>, Vec<ConnectionSpec>) {
    let highlands = RegionSpec {
        name: "Highland Ridge".to_string(),
        terrain_type: TerrainType::Highlands,
        mood: "brooding".to_string(),
        landmarks: vec![
            LandmarkSpec {
                name: "Watchtower".to_string(),
                kind: LandmarkKind::Tower,
                description: "A ruined watchtower on the ridge".to_string(),
            },
            LandmarkSpec {
                name: "Standing Stone".to_string(),
                kind: LandmarkKind::StandingStone,
                description: "An ancient standing stone".to_string(),
            },
            LandmarkSpec {
                name: "Shrine".to_string(),
                kind: LandmarkKind::Shrine,
                description: "A weathered shrine".to_string(),
            },
        ],
        style_hints: StyleHints {
            palette: vec!["stone".to_string(), "grey".to_string()],
            density: "sparse".to_string(),
            atmosphere: "clear".to_string(),
        },
    };

    let forest = RegionSpec {
        name: "Dark Forest".to_string(),
        terrain_type: TerrainType::Forest,
        mood: "ominous".to_string(),
        landmarks: vec![
            LandmarkSpec {
                name: "Settlement".to_string(),
                kind: LandmarkKind::Settlement,
                description: "A small woodland settlement".to_string(),
            },
            LandmarkSpec {
                name: "Cave".to_string(),
                kind: LandmarkKind::Cave,
                description: "A dark cave entrance".to_string(),
            },
            LandmarkSpec {
                name: "Monument".to_string(),
                kind: LandmarkKind::Monument,
                description: "A forgotten monument".to_string(),
            },
        ],
        style_hints: StyleHints {
            palette: vec!["green".to_string(), "brown".to_string()],
            density: "dense".to_string(),
            atmosphere: "foggy".to_string(),
        },
    };

    let regions = vec![highlands, forest];

    let connections = vec![
        ConnectionSpec {
            name: "Ridge Path".to_string(),
            from_region: "Highland Ridge".to_string(),
            to_region: "Dark Forest".to_string(),
            kind: ConnectionKind::Path,
            directionality: Directionality::Bidirectional,
        },
    ];

    (regions, connections)
}
