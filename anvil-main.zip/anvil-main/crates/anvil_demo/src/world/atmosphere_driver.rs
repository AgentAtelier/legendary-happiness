//! Atmosphere driver system for the Ashveil demo.
//!
//! This module implements the `AtmosphereDriver` system that reads live weather
//! and game time from the simulation and writes to the renderer every frame
//! so the world visibly reacts.

use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

use crate::app::RuntimeResource;
use anvil_sim::catastrophe::CatastropheType;

/// Colour temperature lookup table entries.
/// Maps day phase [0, 1] to RGB colour.
const COLOUR_TEMPERATURE_TABLE: [(f32, Color); 6] = [
    // Dawn (0.20): warm amber
    (0.20, Color::srgb(1.0, 0.6, 0.2)),
    // Mid-morning (0.35): soft white
    (0.35, Color::srgb(0.95, 0.85, 0.7)),
    // Noon (0.50): cool white
    (0.50, Color::srgb(0.95, 0.95, 1.0)),
    // Mid-afternoon (0.65): soft white
    (0.65, Color::srgb(0.95, 0.85, 0.7)),
    // Dusk (0.80): warm amber
    (0.80, Color::srgb(1.0, 0.6, 0.2)),
    // Night (1.0): deep blue
    (1.0, Color::srgb(0.2, 0.2, 0.4)),
];

/// Base fog colour (#121416).
const BASE_FOG_COLOR: Color = Color::srgb(0.0706, 0.0784, 0.0863);
/// Fire bias colour - warm orange.
const FIRE_BIAS_COLOR: Color = Color::srgb(1.0, 0.4, 0.1);
/// Cool blue bias for dusk.
const DUSK_BIAS_COLOR: Color = Color::srgb(0.3, 0.4, 0.6);
/// Neutral grey bias for rain.
const RAIN_BIAS_COLOR: Color = Color::srgb(0.4, 0.4, 0.4);

/// Interpolates colour from the temperature lookup table based on day phase.
/// The table is ordered by phase ascending. For phases in the night range
/// (between the last entry at 1.0 and first entry at 0.20), we interpolate between
/// the last entry (night at 1.0) and the first entry (dawn at 0.20).
fn interpolate_colour_temperature(day_phase: f32) -> Color {
    // Normalize day_phase to [0, 1]
    let phase = day_phase.fract();

    // Find the bracket: the largest table_phase <= phase
    let mut prev_idx = 0usize;
    let mut prev_phase = COLOUR_TEMPERATURE_TABLE[0].0;
    let mut prev_color = COLOUR_TEMPERATURE_TABLE[0].1;

    for (i, &(table_phase, table_color)) in COLOUR_TEMPERATURE_TABLE.iter().enumerate() {
        if table_phase <= phase {
            prev_idx = i;
            prev_phase = table_phase;
            prev_color = table_color;
        } else {
            // Found the first entry > phase, so previous is the bracket
            break;
        }
    }

    // Determine next entry for interpolation
    let next_idx = if prev_idx + 1 < COLOUR_TEMPERATURE_TABLE.len() {
        prev_idx + 1
    } else {
        // Wrap around: for phases > last entry (1.0), use first entry (0.20)
        // This handles night -> dawn transition (phase near 0 is treated as near 1.0)
        0
    };

    let next_phase = COLOUR_TEMPERATURE_TABLE[next_idx].0;
    let next_color = COLOUR_TEMPERATURE_TABLE[next_idx].1;

    // Calculate interpolation factor
    let range = next_phase - prev_phase;
    if range <= 0.0 {
        // Handle negative range from wrap-around (night at 1.0 to dawn at 0.20)
        // Adjust phase to be in the [prev_phase, next_phase + 1.0] range
        // For example: prev=1.0, next=0.20, phase=0.05 -> adjusted_phase=1.05
        let adjusted_phase = if phase < prev_phase { phase + 1.0 } else { phase };
        let adjusted_range = (next_phase + 1.0) - prev_phase;
        if adjusted_range <= 0.0 {
            return prev_color;
        }
        let t = (adjusted_phase - prev_phase) / adjusted_range;
        return prev_color.mix(&next_color, t.clamp(0.0, 1.0));
    }
    let t = (phase - prev_phase) / range;

    prev_color.mix(&next_color, t.clamp(0.0, 1.0))
}

/// Checks if a wildfire is currently active in the catastrophe system.
fn is_fire_active(runtime: &RuntimeResource) -> bool {
    for system in &runtime.runtime.systems {
        if let Some(catastrophe_system) = system.as_any().downcast_ref::<anvil_sim::CatastropheSystem>() {
            for event in &catastrophe_system.active_events {
                if event.catastrophe_type == CatastropheType::Wildfire {
                    return true;
                }
            }
        }
    }
    false
}

/// Checks if it's currently raining based on weather phase.
fn is_raining(weather: &anvil_runtime::weather::WeatherSimulation) -> bool {
    use anvil_runtime::weather::WeatherPhase;
    matches!(
        weather.current_weather,
        WeatherPhase::Rain | WeatherPhase::Storm
    )
}

/// System that updates atmosphere settings based on simulation state.
pub fn update_atmosphere(
    runtime: Option<Res<RuntimeResource>>,
    mut directional_lights: Query<(&mut DirectionalLight, &mut Transform)>,
    mut fog_query: Query<&mut DistanceFog, With<Camera3d>>,
    mut ambient_lights: Query<&mut AmbientLight>,
) {
    let Some(runtime) = runtime else {
        return;
    };

    let game_time = &runtime.runtime.time;
    let weather = &runtime.runtime.weather;

    // ========================================================================
    // Sun direction
    // ========================================================================
    // day_phase is [0, 1] where 0 = start of day, 1 = end of day
    // Map to elevation: dawn(0.25)=0°, noon(0.5)=90°, dusk(0.75)=0°, night(0.0/1.0)=-90°
    // Formula: sin((phase - 0.25) * 2π) * 90°
    // - phase 0.0: sin(-π/2) * 90 = -90° (night)
    // - phase 0.25: sin(0) * 90 = 0° (dawn)
    // - phase 0.5: sin(π/2) * 90 = 90° (noon)
    // - phase 0.75: sin(π) * 90 = 0° (dusk)
    // - phase 1.0: sin(3π/2) * 90 = -90° (night)
    let day_phase = game_time.day_phase();
    let sun_pitch_rad = (day_phase - 0.25) * 2.0 * std::f32::consts::PI;
    let sun_pitch_deg = sun_pitch_rad.sin() * 90.0;
    let sun_pitch = sun_pitch_deg * std::f32::consts::PI / 180.0;

    // Apply rotation to directional lights (sun points along -Z by default)
    for (mut light, mut transform) in directional_lights.iter_mut() {
        transform.rotation = Quat::from_rotation_x(-sun_pitch);

        // ====================================================================
        // Sun colour
        // ====================================================================
        let sun_color = interpolate_colour_temperature(day_phase);

        // Apply humidity bias (grey out when humidity > 0.5)
        let mut final_color = sun_color;
        if weather.humidity > 0.5 {
            let grey_factor = (weather.humidity - 0.5) / 0.5; // [0, 1] for humidity [0.5, 1.0]
            let grey = Color::srgb(0.5, 0.5, 0.5);
            final_color = final_color.mix(&grey, grey_factor);
        }

        // Apply fire bias when wildfire is active
        if is_fire_active(&runtime) {
            final_color = final_color.mix(&FIRE_BIAS_COLOR, 0.3);
        }

        light.color = final_color;
    }

    // ========================================================================
    // Fog
    // ========================================================================
    // Base density: 0.0008 * (1.0 + humidity * 2.0) + 0.0004 * precipitation
    let base_density = 0.0008 * (1.0 + weather.humidity * 2.0) + 0.0004 * weather.accumulated_precipitation;

    // Fog colour: base #121416
    let mut fog_color = BASE_FOG_COLOR;

    // Lerp warm orange when fire active
    if is_fire_active(&runtime) {
        fog_color = fog_color.mix(&FIRE_BIAS_COLOR, 0.4);
    }

    // Cool blue at dusk (day phase ~0.75-0.85)
    if day_phase >= 0.70 && day_phase <= 0.85 || day_phase <= 0.05 {
        fog_color = fog_color.mix(&DUSK_BIAS_COLOR, 0.5);
    }

    // Neutral grey during rain
    if is_raining(weather) {
        fog_color = fog_color.mix(&RAIN_BIAS_COLOR, 0.6);
    }

    // Update fog on all 3D cameras
    for mut fog in fog_query.iter_mut() {
        fog.color = fog_color;
        // Use ExponentialSquared falloff
        if let FogFalloff::ExponentialSquared { density } = &mut fog.falloff {
            *density = base_density;
        } else {
            fog.falloff = FogFalloff::ExponentialSquared {
                density: base_density,
            };
        }
    }

    // ========================================================================
    // Ambient light
    // ========================================================================
    // Base intensity 0.15
    // Drop 30% when humidity > 0.7
    // Boost 15% at midday (day phase ~0.5)
    let mut ambient_brightness = 0.15;

    if weather.humidity > 0.7 {
        ambient_brightness *= 0.7; // Drop 30%
    }

    // Boost at midday (around phase 0.5, +/- 0.1)
    if day_phase >= 0.4 && day_phase <= 0.6 {
        // Linear boost: max 15% at exact midday
        let midday_dist = (day_phase - 0.5).abs();
        let boost_factor = 1.0 - (midday_dist / 0.1).min(1.0);
        ambient_brightness *= 1.0 + 0.15 * boost_factor;
    }

    // Update all ambient lights
    for mut ambient in ambient_lights.iter_mut() {
        ambient.brightness = ambient_brightness.clamp(0.0, 2.0);
    }
}

/// Plugin that registers the atmosphere driver systems.
pub struct AtmosphereDriverPlugin;

impl Plugin for AtmosphereDriverPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, update_atmosphere);
    }
}
