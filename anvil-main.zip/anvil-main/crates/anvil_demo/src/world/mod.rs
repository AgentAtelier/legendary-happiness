//! World rendering module for the Visual Uplift Sprint.
//!
//! This module contains systems for rendering the world environment:
//! - Procedural sky gradient (inverted sphere radius ~150)
//! - Fog (ExponentialSquared, density 0.0008, color #121416)
//! - Lighting (DirectionalLight at 45°, #FFF4E5, 120000; AmbientLight #CBD5E1 at 0.15)
//! - Tonemapping (TonyMcMapface + DebandDither)
//! - Ground plane (200x200 with 256x256 noise texture, base #2A2F36)
//! - Settlement state visuals (arch + food dot)

mod atmosphere;
mod atmosphere_driver;
mod ground;
pub mod setup;
pub mod specs;
pub mod settlement;
mod sky;

pub use atmosphere::*;
pub use atmosphere_driver::AtmosphereDriverPlugin;
pub use ground::*;
pub use settlement::*;
// `sky` module is retained for future per-vertex sky shader work (Phase 6
// polish) but its public symbols are not currently consumed elsewhere; the
// `pub use sky::*` re-export is intentionally omitted to keep the crate
// boundary honest.
