//! Atmosphere rendering systems.
//!
//! This module handles fog, lighting, and tonemapping for the scene.
//! All values match the Visual Uplift Sprint Phase 1 specifications.

use bevy::core_pipeline::tonemapping::{DebandDither, Tonemapping};
use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

/// Sky top color - deep blue (#1B2433).
#[allow(dead_code)]
pub const SKY_TOP_COLOR: Color = Color::srgb(0.1059, 0.1451, 0.20);

/// Sky horizon color - blue-grey (#2E3E55).
#[allow(dead_code)]
pub const SKY_HORIZON_COLOR: Color = Color::srgb(0.1804, 0.2431, 0.3333);

/// Sun color - warm orange (#F59E0B).
#[allow(dead_code)]
pub const SUN_COLOR: Color = Color::srgb(0.9608, 0.6196, 0.0431);

/// Fog color - dark near-black (#121416).
pub const FOG_COLOR: Color = Color::srgb(0.0706, 0.0784, 0.0863);

/// Fog density for exponential squared falloff.
pub const FOG_DENSITY: f32 = 0.0008;

/// Sun light color - slightly warm white (#FFF4E5).
pub const SUN_LIGHT_COLOR: Color = Color::srgb(1.0, 0.9569, 0.898);

/// Sun light intensity.
pub const SUN_LIGHT_INTENSITY: f32 = 120000.0;

/// Ambient light color - cool blue-grey (#CBD5E1).
pub const AMBIENT_LIGHT_COLOR: Color = Color::srgb(0.7961, 0.8353, 0.8824);

/// Ambient light intensity.
pub const AMBIENT_LIGHT_INTENSITY: f32 = 0.15;

/// Marker component for the sun directional light.
#[derive(Component)]
pub struct SunLight;

/// Combined setup for all atmosphere elements:
/// - Camera clear color (sky top color #1B2433)
/// - Directional light (sun) at 45 degree elevation with color #FFF4E5, intensity 120000
/// - Ambient light with color #CBD5E1 at intensity 0.15
/// - Tonemapping: TonyMcMapface with DebandDither enabled
/// - Fog: ExponentialSquared with density 0.0008 and color #121416
pub fn setup_full_atmosphere(
    mut commands: Commands,
    mut cameras: Query<(Entity, &mut Camera)>,
) {
    for (entity, mut camera) in cameras.iter_mut() {
        // Camera clear color: sky top color #1B2433
        camera.clear_color = ClearColorConfig::Custom(SKY_TOP_COLOR);
        
        // Add Tonemapping component to the camera entity
        commands.entity(entity).insert(Tonemapping::TonyMcMapface);
        
        // Add DebandDither component to the camera entity
        commands.entity(entity).insert(DebandDither::Enabled);
        
        // Add DistanceFog component to the camera entity
        commands.entity(entity).insert(DistanceFog {
            color: FOG_COLOR,
            directional_light_color: SUN_COLOR,
            directional_light_exponent: 1.0,
            falloff: FogFalloff::ExponentialSquared {
                density: FOG_DENSITY,
            },
        });
    }
    
    // Spawn directional light (sun) at 45 degree elevation
    // In Bevy, light points along -Z by default. To get 45° elevation,
    // we rotate around X by -45° (pi/4 radians) so it points down and forward.
    commands.spawn((
        DirectionalLight {
            illuminance: SUN_LIGHT_INTENSITY,
            color: SUN_LIGHT_COLOR,
            shadows_enabled: true,
            ..default()
        },
        SunLight,
        Transform::from_rotation(Quat::from_euler(
            EulerRot::ZYX,
            0.0,
            0.0,
            -std::f32::consts::FRAC_PI_4, // -45 degrees pitch
        )),
    ));

    // Setup ambient light on all cameras
    // In Bevy 0.18, AmbientLight is a Component that must be on an entity with Camera
    for (entity, _) in cameras.iter_mut() {
        commands.entity(entity).insert(AmbientLight {
            color: AMBIENT_LIGHT_COLOR,
            brightness: AMBIENT_LIGHT_INTENSITY,
            ..default()
        });
    }
}

/// Legacy system for fog setup - now handled in setup_full_atmosphere.
#[allow(dead_code)]
pub fn setup_fog() {}

/// System that decorates newly-added cameras with the atmospheric
/// configuration (clear colour, tonemapping, fog) that `setup_full_atmosphere`
/// applies to the cameras present at startup.
///
/// Gated by `Added<Camera3d>` so it does no work on the steady state.
pub fn decorate_new_cameras(
    mut commands: Commands,
    new_cameras: Query<Entity, Added<Camera3d>>,
) {
    for entity in new_cameras.iter() {
        commands.entity(entity).insert((
            Camera {
                clear_color: ClearColorConfig::Custom(SKY_TOP_COLOR),
                ..default()
            },
            Tonemapping::TonyMcMapface,
            DebandDither::Enabled,
            DistanceFog {
                color: FOG_COLOR,
                directional_light_color: SUN_COLOR,
                directional_light_exponent: 1.0,
                falloff: FogFalloff::ExponentialSquared { density: FOG_DENSITY },
            },
        ));
    }
}
