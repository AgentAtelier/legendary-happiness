#![allow(dead_code)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]
//!
//! anvil_demo — a live viewport into the Anvil simulation.
//!
//! Cap list (v2 - Demo Integration Sprint Phase 2):
//! 1. Tick the simulation in the demo loop
//! 2. Toggle panel with simulation controls
//! 3. Show Phase 3 systems in the debug overlay
//! 4. Load a real catalogue
//! 5. Spawn entities for every family + biome combination
//! 6. Apply material overrides per entity
//! 7. Debug overlay: highlight fallback assets
//! 8. Fly camera and basic lighting

mod animation;
mod app;
mod audio;
mod camera;
mod catastrophe_panel;
mod character;
mod crash_reporter;
mod demo;
mod dev_experience;
mod event_log;
mod npc;
mod oracle_overlay;
mod overlays;
mod performance_panel;
mod player;
mod plugins;
mod rendering;
mod scenarios;
mod sim;
mod sim_bridge;
mod spawn_sun;
mod states;
mod time_travel;
mod ui;
mod vfx;
mod world;
mod npc_visuals;

use bevy::prelude::*;
use std::path::{Path, PathBuf};
use tracing::info;

use tracing_appender::rolling::{RollingFileAppender, Rotation};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter, Layer};

// Re-export from plugins for main
use plugins::registration::register_demo_plugins;

// ============================================================================
// Logging and Tracing
// ============================================================================

/// Parse --log-level CLI argument
/// Returns the log level filter string, or default
fn get_log_level_filter() -> String {
    let args: Vec<String> = std::env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--log-level" && i + 1 < args.len() {
            return args[i + 1].clone();
        }
    }
    // Default: warn level globally, info for anvil_sim
    "warn,anvil_sim=info".to_string()
}

/// Set up tracing with console and file layers.
/// Console: human-readable, compact format, filtered by RUST_LOG or --log-level
/// File: JSON format, rolling file with daily rotation, max 7 files
fn setup_tracing() -> tracing_appender::non_blocking::WorkerGuard {
    // Create logs directory if it doesn't exist
    let logs_dir = Path::new("logs");
    std::fs::create_dir_all(logs_dir).ok();

    // Get log level from CLI or default
    let log_filter = get_log_level_filter();

    // File appender with rolling: daily rotation, max 7 files
    #[allow(clippy::expect_used)]
    let file_appender = RollingFileAppender::builder()
        .rotation(Rotation::DAILY)
        .filename_prefix("anvil_sim")
        .filename_suffix("json")
        .max_log_files(7)
        .build(logs_dir)
        .expect("Failed to create rolling file appender");

    // Non-blocking writer for the file layer
    let (non_blocking_file, _guard) = tracing_appender::non_blocking(file_appender);

    // Console layer: compact format
    let console_layer = tracing_subscriber::fmt::layer()
        .compact()
        .with_filter(EnvFilter::new(&log_filter));

    // File layer: JSON format (always writes warn+ and anvil_sim=info)
    let file_filter = EnvFilter::new("warn,anvil_sim=info");
    let file_layer = tracing_subscriber::fmt::layer()
        .json()
        .with_writer(non_blocking_file)
        .with_filter(file_filter);

    // Combine layers and initialize
    tracing_subscriber::registry()
        .with(console_layer)
        .with(file_layer)
        .init();

    _guard
}

/// Resolve the asset directory path with multiple fallback strategies.
///
/// Strategy (in order):
/// 1. If ANVIL_ASSETS env var is set, use that
/// 2. Try to find assets relative to the executable location
/// 3. Try to find assets relative to CARGO_MANIFEST_DIR (dev mode)
/// 4. Try to find assets relative to current working directory
/// 5. Climb up from executable to find repo root (for dev builds)
/// 6. Fall back to "./assets"
fn resolve_asset_path() -> PathBuf {
    // Check for explicit environment variable override
    if let Ok(asset_path) = std::env::var("ANVIL_ASSETS") {
        let path = PathBuf::from(asset_path);
        info!("Using ANVIL_ASSETS override: {}", path.display());
        return path;
    }
    
    // Try to find assets relative to the executable location (standalone builds)
    if let Ok(exe_path) = std::env::current_exe() {
        let exe_dir = exe_path.parent().unwrap_or(Path::new("."));
        let candidate = exe_dir.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
        // Also check parent directory (common for bundled apps)
        let parent_candidate = exe_dir.parent().map(|p| p.join("assets"));
        if let Some(p) = parent_candidate {
            if p.exists() {
                info!("Found assets at: {}", p.display());
                return p;
            }
        }
        // Climb up to find repo root from executable location
        let mut current = exe_dir.to_path_buf();
        for _ in 0..5 {
            current = current.parent().unwrap_or(Path::new(".")).to_path_buf();
            let candidate = current.join("assets");
            if candidate.exists() {
                info!("Found assets at: {}", candidate.display());
                return candidate;
            }
            if current.join("Cargo.toml").exists() {
                let candidate = current.join("assets");
                if candidate.exists() {
                    info!("Found assets at: {}", candidate.display());
                    return candidate;
                }
            }
        }
    }
    
    // Try CARGO_MANIFEST_DIR
    if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        let mut path = PathBuf::from(manifest_dir);
        for _ in 0..2 {
            if let Some(parent) = path.parent() {
                path = parent.to_path_buf();
            }
        }
        let candidate = path.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    // Try current working directory
    if let Ok(cwd) = std::env::current_dir() {
        let candidate = cwd.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    PathBuf::from("./assets")
}

// ============================================================================
// Main
// ============================================================================

fn main() {
    // Initialize tracing with console and file layers
    let _tracing_guard = setup_tracing();

    // Initialize crash reporter (must be first to catch any panics)
    crash_reporter::init();

    // Check for unreported crashes from previous session
    crash_reporter::print_crash_detections();

    let mut app = App::new();
    register_demo_plugins(&mut app);
    app.run();
}
