//! Camera and navigation systems for anvil_demo.
//!
//! This module provides enhanced camera controls including:
//! - Flycam with inertia/smoothing
//! - Zoom with mouse wheel
//! - Focus mode (lock to selected NPC)
//! - NPC cycling
//! - Reset view
//! - Turbo mode

use bevy::camera::{Camera, Camera3d};
use bevy::prelude::*;

use crate::npc_visuals::NpcVisual;
use crate::player::PlayerCamera;

/// Resource tracking camera state.
#[derive(Resource, Default)]
pub struct CameraState {
    /// Whether focus mode is active.
    pub focus_mode: bool,
    /// The entity being focused on (if any).
    pub focused_entity: Option<Entity>,
    /// Camera speed multiplier (turbo mode).
    pub speed_multiplier: f32,
    /// Default camera transform for reset.
    pub default_transform: Transform,
}

/// System that sets up the main camera.
pub fn setup_main_camera(mut commands: Commands) {
    // The flycam plugin already spawns a camera, so we just need to tag it
    // and set up the default transform
    commands.insert_resource(CameraState {
        focus_mode: false,
        focused_entity: None,
        speed_multiplier: 1.0,
        default_transform: Transform::from_xyz(0.0, 5.0, 10.0).looking_at(Vec3::ZERO, Vec3::Y),
    });
}

/// Sets explicit camera priorities to avoid ambiguity warnings.
/// UI camera (Camera2d) gets order=1, scene camera (Camera3d) gets order=0.
///
/// **Note.** Mutates the *existing* `Camera` component in place rather than
/// re-inserting one. Re-inserting `Camera { order, ..default() }` replaces
/// the whole component, which clears the render-graph configuration that
/// Bevy attaches to a camera based on its companion marker (`Camera2d` /
/// `Camera3d`). After such a replacement Bevy logs:
///
/// > Entity NNNvK has a `Camera` component, but it doesn't have a render
/// > graph configured.
///
/// Mutating only the `order` field keeps the render graph intact.
pub fn set_camera_priorities(
    mut ui_cameras: Query<&mut Camera, (With<bevy::camera::Camera2d>, Without<bevy::camera::Camera3d>)>,
    mut player_cameras: Query<&mut Camera, (With<PlayerCamera>, With<bevy::camera::Camera3d>)>,
    mut scene_cameras: Query<&mut Camera, (With<bevy::camera::Camera3d>, Without<bevy::camera::Camera2d>, Without<PlayerCamera>)>,
) {
    // UI camera: order = 1 (renders on top)
    for mut camera in &mut ui_cameras {
        camera.order = 1;
    }

    // Player camera: order = -1 (renders first, before other scene cameras)
    for mut camera in &mut player_cameras {
        camera.order = -1;
    }

    // Other scene cameras: order = 0 (renders after player camera)
    for mut camera in &mut scene_cameras {
        camera.order = 0;
    }
}

/// Despawns camera entities imported from GLTF files.
/// Despawns camera entities imported from GLTF files.
/// Must run in PostUpdate after scene spawning but before visibility checks.
/// Despawns camera entities imported from GLTF files.
/// Must run in PostUpdate after scene spawning but before visibility checks.
pub fn despawn_gltf_cameras(
    mut commands: Commands,
    gltf_cameras: Query<Entity, (With<Camera>, Without<crate::player::PlayerCamera>)>,
) {
    for entity in &gltf_cameras {
        commands.entity(entity)
            .remove::<Camera>()
            .remove::<Camera3d>()
            .remove::<Camera2d>();
    }
}

/// System that handles camera keyboard shortcuts.
pub fn handle_camera_shortcuts(
    mut camera_state: ResMut<CameraState>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut camera_query: Query<
        &mut Transform,
        (With<Camera3d>, Without<NpcVisual>, Without<PlayerCamera>),
    >,
    npc_visuals: Query<Entity, With<NpcVisual>>,
) {
    // Turbo: Shift increases camera speed
    if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
        camera_state.speed_multiplier = 2.0;
    } else {
        camera_state.speed_multiplier = 1.0;
    }

    // Focus mode: F locks camera to selected NPC
    if keyboard_input.just_pressed(KeyCode::KeyF) {
        camera_state.focus_mode = !camera_state.focus_mode;
        
        if camera_state.focus_mode && camera_state.focused_entity.is_none() {
            // Focus on first NPC if none selected
            if let Some(first_npc) = npc_visuals.iter().next() {
                camera_state.focused_entity = Some(first_npc);
            }
        }
        
        println!("Focus mode: {}", if camera_state.focus_mode { "ON" } else { "OFF" });
    }

    // Cycle NPCs: Tab / Shift+Tab
    if keyboard_input.just_pressed(KeyCode::Tab) {
        let npcs: Vec<Entity> = npc_visuals.iter().collect();
        if !npcs.is_empty() {
            let current_idx = camera_state.focused_entity
                .and_then(|e| npcs.iter().position(|&x| x == e));
            
            let next_idx = if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
                // Shift+Tab: previous
                current_idx.map(|i| (i + npcs.len() - 1) % npcs.len()).unwrap_or(0)
            } else {
                // Tab: next
                current_idx.map(|i| (i + 1) % npcs.len()).unwrap_or(0)
            };
            
            camera_state.focused_entity = Some(npcs[next_idx]);
            camera_state.focus_mode = true;
            println!("Focused on NPC: {:?}", camera_state.focused_entity);
        }
    }

    // Reset view: Home
    if keyboard_input.just_pressed(KeyCode::Home) {
        camera_state.focus_mode = false;
        camera_state.focused_entity = None;
        
        for mut transform in camera_query.iter_mut() {
            *transform = camera_state.default_transform;
        }
        
        println!("Camera reset to default view");
    }

}

/// System that implements focus mode camera tracking.
/// Uses exponential smoothing: pos += (target - pos) * (1.0 - exp(-10.0 * delta))
/// Settles in ~0.4s as specified in Visual Uplift Sprint.
pub fn update_focus_camera(
    time: Res<Time>,
    camera_state: Res<CameraState>,
    mut camera_query: Query<
        &mut Transform,
        (With<Camera3d>, Without<NpcVisual>, Without<PlayerCamera>),
    >,
    npc_transforms: Query<&Transform, (With<NpcVisual>, Without<Camera3d>)>,
) {
    if !camera_state.focus_mode || camera_state.focused_entity.is_none() {
        return;
    }

    let delta = time.delta_secs();

    if let Some(focused) = camera_state.focused_entity
        && let Ok(npc_transform) = npc_transforms.get(focused)
    {
        for mut camera_transform in camera_query.iter_mut() {
            // Calculate target position: slightly offset from NPC
            let target_position = npc_transform.translation + Vec3::new(0.0, 2.0, 5.0);
            let target_rotation = Transform::from_translation(target_position)
                .looking_at(npc_transform.translation, Vec3::Y)
                .rotation;

            // Exponential smoothing for position
            // pos += (target - pos) * (1.0 - exp(-10.0 * delta))
            let smoothing_factor = 1.0 - (-10.0 * delta).exp();
            let current_pos = camera_transform.translation;
            camera_transform.translation = current_pos + (target_position - current_pos) * smoothing_factor;

            // Exponential smoothing for rotation (slerp)
            // Snap if dot < 0.0 to prevent 180° spin
            let dot = camera_transform.rotation.dot(target_rotation);
            if dot < 0.0 {
                // Snap instantly
                camera_transform.rotation = target_rotation;
            } else {
                // Slerp with same smoothing factor
                camera_transform.rotation = camera_transform.rotation.slerp(target_rotation, smoothing_factor * 8.0);
            }
        }
    }
}

/// System that handles mouse wheel zoom.
/// 
/// Note: This is a placeholder. For proper event handling, we'd need EventReader,
/// but that requires bevy::ecs::event which has version compatibility issues
/// with the workspace glam version. Zoom functionality is deferred to a
/// future iteration when the dependency conflict is resolved.
pub fn handle_mouse_wheel_zoom() {
    // Placeholder for mouse wheel zoom functionality.
    // Requires EventReader<MouseWheel> which has version compatibility issues.
}


