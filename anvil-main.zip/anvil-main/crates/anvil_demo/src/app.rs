//! Application state machine and plugin setup for the Application Shell Sprint.
//!
//! This module defines the `AppState` enum that drives the application flow and
//! the `AppPlugin` that sets up all the state-related systems.

use bevy::prelude::*;
use anvil_runtime::Runtime;
use anvil_world::WorldAuthored;

use crate::states::credits::CreditsPlugin;
use crate::states::error::ErrorPlugin;
use crate::states::ingame::InGamePlugin;
use crate::states::loading::LoadingPlugin;
use crate::states::menu::MainMenuPlugin;
use crate::states::options::OptionsPlugin;
use crate::states::paused::PausedPlugin;
use crate::states::splash::SplashPlugin;

/// The application state machine.
///
/// State transitions:
/// ```text
/// Boot → Splash → MainMenu ↔ Options
///                    ↓
///                 Loading
///                    ↓
///                 InGame ↔ Paused ↔ Options
///                              ↓
///                          MainMenu
///                    ↓
///                  Error
/// ```
#[derive(States, Default, Clone, Eq, PartialEq, Debug, Hash)]
pub enum AppState {
    /// Initial state - splash screen
    #[default]
    Splash,
    /// Main menu screen
    MainMenu,
    /// Options menu
    Options,
    /// Credits screen
    Credits,
    /// Loading screen
    Loading,
    /// In-game state
    InGame,
    /// Paused state
    Paused,
    /// Error state
    Error,
}

/// Resource to track the selected scenario.
#[derive(Resource, Clone, Debug)]
#[allow(dead_code)]
pub struct ScenarioSelection {
    /// The identifier of the selected scenario
    pub scenario_id: String,
    /// The display name of the scenario
    pub display_name: String,
    /// The description of the scenario
    pub description: String,
}

impl Default for ScenarioSelection {
    fn default() -> Self {
        Self {
            scenario_id: "greyridge".to_string(),
            display_name: "Greyridge".to_string(),
            description: "A highland settlement faces water scarcity".to_string(),
        }
    }
}

/// Resource to track the current sim speed multiplier for the menu background.
/// - 0.0 = paused (no ticks)
/// - 0.1 = slow (1 tick per 10 frames)
/// - 1.0 = normal (default ticks per frame)
#[derive(Resource, Debug, Clone, Copy)]
pub struct SimSpeed(pub f32);

impl Default for SimSpeed {
    fn default() -> Self {
        Self(0.1) // Menu runs at 0.1x speed
    }
}

impl SimSpeed {
    /// Returns true if simulation is paused (multiplier is 0.0).
    pub fn paused(&self) -> bool {
        self.0 <= 0.0
    }

    /// Returns the display string for the speed.
    pub fn display(&self) -> String {
        if self.paused() {
            "PAUSED".to_string()
        } else {
            match self.0 {
                0.1 => "0.1x".to_string(),
                0.5 => "0.5x".to_string(),
                1.0 => "1x".to_string(),
                2.0 => "2x".to_string(),
                5.0 => "5x".to_string(),
                10.0 => "10x".to_string(),
                _ => format!("{}x", self.0),
            }
        }
    }

    /// Returns the color for the speed display.
    pub fn color(&self) -> egui::Color32 {
        if self.paused() {
            egui::Color32::RED
        } else {
            match self.0 {
                0.1 | 0.5 => egui::Color32::LIGHT_BLUE,
                1.0 => egui::Color32::WHITE,
                2.0 => egui::Color32::LIGHT_GREEN,
                5.0 => egui::Color32::LIGHT_YELLOW,
                10.0 => egui::Color32::ORANGE,
                _ => egui::Color32::WHITE,
            }
        }
    }
}

/// Runtime resource wrapper for Bevy.
#[derive(Resource)]
pub struct RuntimeResource {
    pub runtime: Runtime,
}

impl Default for RuntimeResource {
    fn default() -> Self {
        Self { runtime: Runtime::new(WorldAuthored::default()) }
    }
}

/// World resource wrapper for Bevy.
#[derive(Resource, Clone, Default)]
pub struct WorldResource {
    pub world: WorldAuthored,
}

/// Plugin that sets up the application state machine and all state-related systems.
pub struct AppPlugin;

impl Plugin for AppPlugin {
    fn build(&self, app: &mut App) {
        // Add all state plugins
        app.add_plugins((
            SplashPlugin,
            MainMenuPlugin,
            OptionsPlugin,
            CreditsPlugin,
            LoadingPlugin,
            InGamePlugin,
            PausedPlugin,
            ErrorPlugin,
        ));

        // Initialize resources
        app.init_resource::<ScenarioSelection>()
            .init_resource::<SimSpeed>()
            .init_resource::<RuntimeResource>();
    }
}
