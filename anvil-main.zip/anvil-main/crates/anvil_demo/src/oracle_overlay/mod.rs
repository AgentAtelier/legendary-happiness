//! Oracle Overlay module for displaying ghost propagation zones.

use bevy::prelude::*;
use bevy_egui::{egui, EguiContexts};

use crate::ui::panel::UiState;

/// Resource for oracle overlay state.
#[derive(Resource, Default)]
pub struct OracleOverlayState {
    /// Whether to show propagation zones.
    #[allow(dead_code)]
    pub show_propagation_zones: bool,
}

/// System that renders the oracle overlay panel.
pub fn render_oracle_overlay(
    mut egui_contexts: EguiContexts,
    _oracle_state: Res<OracleOverlayState>,
    ui_state: Res<UiState>,
) {
    if !ui_state.show_oracle_overlay {
        return;
    }

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::Window::new("Oracle Overlay")
            .default_pos(egui::Pos2::new(100.0, 100.0))
            .show(ctx, |ui| {
                ui.heading("Oracle Overlay");
                ui.separator();
                ui.label("Ghost Propagation Zones");
                ui.label("Visualization: TODO - requires oracle system integration");
            });
    }
}

/// Extension trait to provide try_ctx_mut for compatibility
pub trait EguiContextsExt {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context>;
}

impl EguiContextsExt for EguiContexts<'_, '_> {
    fn try_ctx_mut(&mut self) -> Option<&mut egui::Context> {
        self.ctx_mut().ok()
    }
}

/// Setup system for oracle overlay state.
pub fn setup_oracle_overlay(mut commands: Commands) {
    commands.insert_resource(OracleOverlayState::default());
}
