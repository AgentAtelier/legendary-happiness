#![deny(warnings)]
#![deny(missing_docs)]
#![cfg_attr(
    not(test),
    deny(
        clippy::unwrap_used,
        clippy::expect_used,
        clippy::panic,
        clippy::unreachable,
        clippy::todo,
    )
)]

//! Anvil Assembly: Deterministic world plan compilation and materialization.
//!
//! This crate bridges `anvil_world` (authoring) and `anvil_runtime` (execution).
//! It provides:
//! - `AssemblyPlan`: The compiled world layout (regions, entities, connections)
//! - `compile_plan`: Turns a `WorldAuthored` into an `AssemblyPlan`
//! - `compute_plan_hash`: Deterministic hash of a plan
//! - Authority reports for plan validation

/// Authority reporting for world plans.
pub mod authority;

/// Plan compilation from authored world data.
pub mod compile;

/// Materialization of compiled plans into runtime data.
pub mod materialize;

/// Assembly plan types and layout.
pub mod plan;

/// Resource management for assembly.
pub mod resources;

pub use authority::{report_world_plan_authority, validate_authority_report, WorldPlanAuthorityReport};
pub use compile::{compile_plan, compute_plan_hash, CompileError};
pub use materialize::{
    compute_materialized_hash, materialize, MaterializeError, MaterializedAuthorityReport,
    report_materialized_authority,
};
pub use materialize::types::{
    DecorationProfile, MaterializeMetadata, MaterializedConnection, MaterializedRegion,
    MaterializedWorld, PlacedEntity, TerrainData, WorldBounds,
};
pub use plan::{AssemblyPlan, ConnectionPlan, EntityPlan, RegionPlan};
pub use resources::{
    GameRulesResource, LightingResource, LocalEffectEmitter, LocalEffectEmittersResource,
    PlayerStartResource, ResourceDecl, ResourceKind, ResourcePayload, TerrainResource,
};
