// Source: forge_assembly/src/lib.rs as of the Forge snapshot.
// Resource declarations for the assembly plan.

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};

/// The kind of resource a declaration represents.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResourceKind {
    /// Game rules configuration (e.g., time of day cycle, difficulty).
    GameRules,
    /// Terrain generation parameters.
    Terrain,
    /// Lighting configuration.
    Lighting,
    /// Player start position(s).
    PlayerStart,
    /// Local effect emitters (particles, sounds, etc.).
    LocalEffectEmitters,
}

/// A typed payload for resource declarations.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResourcePayload {
    /// Game rules configuration (e.g., time of day cycle, difficulty).
    GameRules(GameRulesResource),
    /// Terrain generation parameters.
    Terrain(TerrainResource),
    /// Lighting configuration.
    Lighting(LightingResource),
    /// Player start position(s).
    PlayerStart(PlayerStartResource),
    /// Local effect emitters (particles, sounds, etc.).
    LocalEffectEmitters(LocalEffectEmittersResource),
}

/// A single resource declaration attached to the assembly plan.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ResourceDecl {
    /// Unique identifier for this resource.
    pub resource_id: String,
    /// The kind of resource.
    pub kind: ResourceKind,
    /// The archetype tag for categorization.
    pub archetype_tag: Option<ArchetypeTag>,
    /// The typed payload — the concrete resource data.
    pub payload: ResourcePayload,
}

/// Game rules resource: time cycle, difficulty scaling, etc.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct GameRulesResource {
    /// Base time scale for the world.
    pub time_scale: f32,
    /// Whether time passes in real-time or scaled.
    pub realtime: bool,
    /// Difficulty multiplier (1.0 = normal).
    pub difficulty: f32,
}

/// Terrain resource: heightmap and material layer definitions.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TerrainResource {
    /// Base height of the terrain.
    pub base_height: f32,
    /// Maximum height variation.
    pub max_height: f32,
    /// Frequency of height variation (higher = more detail).
    pub frequency: f32,
    /// Persistence for fractal noise.
    pub persistence: f32,
    /// Lacunarity for fractal noise.
    pub lacunarity: f32,
    /// Octaves for fractal noise.
    pub octaves: usize,
    /// Seed for noise generation.
    pub seed: u64,
}

/// Lighting resource: ambient and directional light configuration.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LightingResource {
    /// Ambient light color as RGB.
    pub ambient_color: [f32; 3],
    /// Ambient light intensity.
    pub ambient_intensity: f32,
    /// Directional light direction (normalized).
    pub sun_direction: [f32; 3],
    /// Directional light color as RGB.
    pub sun_color: [f32; 3],
    /// Directional light intensity.
    pub sun_intensity: f32,
}

/// Player start resource: where the player begins.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PlayerStartResource {
    /// World position for the player start.
    pub position: [f32; 3],
    /// Rotation as Euler angles in degrees.
    pub rotation: [f32; 3],
    /// Region ID where the player starts.
    pub region_id: String,
}

/// A local effect emitter (particles, sound, etc.).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LocalEffectEmitter {
    /// The emitter's identifier.
    pub emitter_id: String,
    /// Archetype tag for the effect type.
    pub archetype_tag: ArchetypeTag,
    /// World position.
    pub position: [f32; 3],
    /// Radius of effect.
    pub radius: f32,
    /// Intensity multiplier.
    pub intensity: f32,
}

/// Collection of local effect emitters.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LocalEffectEmittersResource {
    /// List of effect emitters.
    pub emitters: Vec<LocalEffectEmitter>,
}
