// Source: forge_assembly/src/lib.rs as of the Forge snapshot.
// Foundation port — AssemblyPlan, EntityPlan, RegionPlan, ConnectionPlan.

use anvil_core::{ArchetypeTag, AuthoredEntityId, ConnectionId, RegionId};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// A connection between two regions in the assembly plan.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConnectionPlan {
    /// The connection's identifier.
    pub connection_id: ConnectionId,
    /// The archetype tag for this connection type.
    pub archetype_tag: ArchetypeTag,
    /// The two regions this connection joins.
    pub region_a: RegionId,
    /// The second region in the connection.
    pub region_b: RegionId,
    /// Whether this is a one-way connection (A -> B only).
    pub one_way: bool,
    /// Display name for tooling.
    pub display_name: String,
}

/// An entity in the assembly plan.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EntityPlan {
    /// The entity's identifier.
    pub entity_id: AuthoredEntityId,
    /// The archetype tag for this entity type.
    pub archetype_tag: ArchetypeTag,
    /// The region this entity belongs to.
    pub region_id: RegionId,
    /// Local position within the region (0-1 range).
    pub local_position: [f32; 3],
    /// Rotation as Euler angles in degrees.
    pub rotation_degrees: [f32; 3],
    /// Uniform scale factor.
    pub scale: f32,
    /// Display name for tooling.
    pub display_name: String,
}

/// A region in the assembly plan.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RegionPlan {
    /// The region's identifier.
    pub region_id: RegionId,
    /// The archetype tag for this region type.
    pub archetype_tag: ArchetypeTag,
    /// World-space center position.
    pub center: [f32; 3],
    /// Extents in X, Y, Z.
    pub extents: [f32; 3],
    /// Display name for tooling.
    pub display_name: String,
}

/// The top-level assembly plan: a deterministic world layout description.
/// This is the bridge between authoring (anvil_world) and runtime (anvil_runtime).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AssemblyPlan {
    /// Unique identifier for this plan version.
    pub plan_id: String,
    /// Human-readable name.
    pub display_name: String,
    /// All regions in this plan.
    pub regions: Vec<RegionPlan>,
    /// All entities in this plan.
    pub entities: Vec<EntityPlan>,
    /// All connections between regions.
    pub connections: Vec<ConnectionPlan>,
    /// Resource declarations attached to this plan.
    pub resources: Vec<super::resources::ResourceDecl>,
    /// Plan-level metadata.
    pub metadata: HashMap<String, String>,
}

impl AssemblyPlan {
    /// Creates a new empty AssemblyPlan.
    pub fn new(plan_id: String, display_name: String) -> Self {
        Self {
            plan_id,
            display_name,
            regions: Vec::new(),
            entities: Vec::new(),
            connections: Vec::new(),
            resources: Vec::new(),
            metadata: HashMap::new(),
        }
    }

    /// Adds a region to the plan.
    pub fn with_region(mut self, region: RegionPlan) -> Self {
        self.regions.push(region);
        self
    }

    /// Adds an entity to the plan.
    pub fn with_entity(mut self, entity: EntityPlan) -> Self {
        self.entities.push(entity);
        self
    }

    /// Adds a connection to the plan.
    pub fn with_connection(mut self, connection: ConnectionPlan) -> Self {
        self.connections.push(connection);
        self
    }
}
