// Source: forge_assembly/src/lib.rs as of the Forge snapshot.
// Authority reporting for assembly plans.

use crate::plan::AssemblyPlan;
use anvil_core::{AnvilCoreError, ArchetypeTag, ErrorCode, FailureClass, ValidationErrors};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// A report on the authority/ownership of entities and regions in a plan.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorldPlanAuthorityReport {
    /// Total number of regions in the plan.
    pub region_count: usize,
    /// Total number of entities in the plan.
    pub entity_count: usize,
    /// Total number of connections in the plan.
    pub connection_count: usize,
    /// Map of archetype tag to count of regions with that tag.
    pub regions_by_archetype: HashMap<ArchetypeTag, usize>,
    /// Map of archetype tag to count of entities with that tag.
    pub entities_by_archetype: HashMap<ArchetypeTag, usize>,
    /// Map of archetype tag to count of connections with that tag.
    pub connections_by_archetype: HashMap<ArchetypeTag, usize>,
    /// List of archetype tags that have no instances in the plan.
    pub unused_archetypes: Vec<ArchetypeTag>,
}

/// Generate an authority report for a world plan.
pub fn report_world_plan_authority(plan: &AssemblyPlan) -> WorldPlanAuthorityReport {
    let mut regions_by_archetype = HashMap::new();
    let mut entities_by_archetype = HashMap::new();
    let mut connections_by_archetype = HashMap::new();

    for region in &plan.regions {
        *regions_by_archetype.entry(region.archetype_tag.clone()).or_insert(0) += 1;
    }

    for entity in &plan.entities {
        *entities_by_archetype.entry(entity.archetype_tag.clone()).or_insert(0) += 1;
    }

    for connection in &plan.connections {
        *connections_by_archetype
            .entry(connection.archetype_tag.clone())
            .or_insert(0) += 1;
    }

    // Collect all archetypes that appear in the catalogue but not in the plan
    // For now, this is empty as we don't have access to the catalogue here
    let unused_archetypes = Vec::new();

    WorldPlanAuthorityReport {
        region_count: plan.regions.len(),
        entity_count: plan.entities.len(),
        connection_count: plan.connections.len(),
        regions_by_archetype,
        entities_by_archetype,
        connections_by_archetype,
        unused_archetypes,
    }
}

/// Validation result for a world plan authority report.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum AuthorityValidationStatus {
    /// All archetypes are used at least once.
    Complete,
    /// Some archetypes are unused.
    HasUnusedArchetypes,
    /// Multiple regions/entities with the same archetype (might be intentional).
    HasDuplicates,
}

/// Validate the authority report and return any issues.
pub fn validate_authority_report(
    report: &WorldPlanAuthorityReport,
) -> ValidationErrors {
    let mut errors = Vec::new();

    if !report.unused_archetypes.is_empty() {
        for archetype in &report.unused_archetypes {
            errors.push(AnvilCoreError::validation(
                FailureClass::Structural,
                ErrorCode::new("A001"),
                "WorldPlanAuthorityReport",
                "unused_archetypes",
                archetype.as_str(),
                format!("Archetype {} is declared but has no instances", archetype),
            ));
        }
    }

    // Check for potential duplicate archetypes in the counts
    for (archetype, &count) in &report.regions_by_archetype {
        if count == 0 {
            errors.push(AnvilCoreError::validation(
                FailureClass::Structural,
                ErrorCode::new("A002"),
                "WorldPlanAuthorityReport",
                "regions_by_archetype",
                archetype.as_str(),
                format!("Region archetype {} has zero count", archetype),
            ));
        }
    }

    for (archetype, &count) in &report.entities_by_archetype {
        if count == 0 {
            errors.push(AnvilCoreError::validation(
                FailureClass::Structural,
                ErrorCode::new("A003"),
                "WorldPlanAuthorityReport",
                "entities_by_archetype",
                archetype.as_str(),
                format!("Entity archetype {} has zero count", archetype),
            ));
        }
    }

    errors
}
