// Source: forge_assembly/src/lib.rs as of the Forge snapshot.
// Plan compilation and hashing.

use crate::plan::{AssemblyPlan, ConnectionPlan, EntityPlan, RegionPlan};
use anvil_core::{AnvilCoreError, ArchetypeTag, ConnectionKind, Directionality, ErrorCode, FailureClass, TerrainType, ValidationErrors};
use blake3::{Hash, Hasher};

/// Compile an assembly plan from a world authored specification.
/// This is the minimum viable pipeline implementation for Wave 4:
///
/// - Creates RegionPlan for each region in the world
/// - Creates EntityPlan for each entity in the world
/// - Creates ConnectionPlan for each connection in the world
///
/// Full procedural layout is deferred to a later sprint.
pub fn compile_plan(world: &anvil_world::WorldAuthored) -> Result<AssemblyPlan, CompileError> {

    // Generate a deterministic plan ID from the world's region count
    let mut hasher = Hasher::new();
    hasher.update(&world.regions.len().to_le_bytes());
    hasher.update(&world.entities.len().to_le_bytes());
    hasher.update(&world.connections.len().to_le_bytes());
    let hash_hex = hasher.finalize().to_hex();
    let plan_id = format!("plan_{}", &hash_hex[..8]);

    let mut plan = AssemblyPlan::new(plan_id, "Assembly Plan".to_string());

    // Create RegionPlan for each region
    for region in &world.regions {
        // Map terrain_type to a basic archetype tag
        let archetype_tag = terrain_type_to_archetype(region.terrain_type);

        let region_plan = RegionPlan {
            region_id: region.id,
            archetype_tag,
            center: [0.0, 0.0, 0.0], // Center will be computed during materialization
            extents: [100.0, 100.0, 100.0], // Default extents
            display_name: region.name.clone(),
        };
        plan.regions.push(region_plan);
    }

    // Create EntityPlan for each entity
    for entity in &world.entities {
        let entity_plan = EntityPlan {
            entity_id: entity.id,
            archetype_tag: entity.archetype.clone(),
            region_id: entity.region,
            local_position: [0.5, 0.0, 0.5], // Center of region by default
            rotation_degrees: [0.0, 0.0, 0.0], // Default rotation
            scale: 1.0, // Default scale
            display_name: entity.name.clone(),
        };
        plan.entities.push(entity_plan);
    }

    // Create ConnectionPlan for each connection
    for connection in &world.connections {
        let one_way = match connection.directionality {
            Directionality::OneWay => true,
            Directionality::Bidirectional => false,
            _ => false, // Default to bidirectional for any future variants
        };

        let archetype_tag = connection_kind_to_archetype(connection.kind);

        let connection_plan = ConnectionPlan {
            connection_id: connection.id,
            archetype_tag,
            region_a: connection.from_region,
            region_b: connection.to_region,
            one_way,
            display_name: connection.name.clone(),
        };
        plan.connections.push(connection_plan);
    }

    Ok(plan)
}

/// Map a TerrainType to an ArchetypeTag for region plans.
/// All returned tags are valid archetype tag formats (lowercase letters and underscores only).
#[allow(clippy::expect_used)]
fn terrain_type_to_archetype(terrain: TerrainType) -> ArchetypeTag {
    // SAFETY: All tag strings below are valid archetype tag formats
    // (lowercase letters, digits, and underscores only, starting with a letter)
    match terrain {
        TerrainType::Highlands => ArchetypeTag::new("terrain_highlands"),
        TerrainType::Forest => ArchetypeTag::new("terrain_forest"),
        TerrainType::Desert => ArchetypeTag::new("terrain_desert"),
        TerrainType::Marsh => ArchetypeTag::new("terrain_marsh"),
        TerrainType::Coast => ArchetypeTag::new("terrain_coast"),
        _ => ArchetypeTag::new("terrain_default"),
    }
    // SAFETY: All new() calls above use valid tag strings that cannot fail
    .expect("All terrain type archetype tags are statically valid")
}

/// Map a ConnectionKind to an ArchetypeTag for connection plans.
/// All returned tags are valid archetype tag formats (lowercase letters and underscores only).
#[allow(clippy::expect_used)]
fn connection_kind_to_archetype(kind: ConnectionKind) -> ArchetypeTag {
    // SAFETY: All tag strings below are valid archetype tag formats
    // (lowercase letters, digits, and underscores only, starting with a letter)
    match kind {
        ConnectionKind::Road => ArchetypeTag::new("connection_road"),
        ConnectionKind::Path => ArchetypeTag::new("connection_path"),
        ConnectionKind::Portal => ArchetypeTag::new("connection_portal"),
        ConnectionKind::Gate => ArchetypeTag::new("connection_gate"),
        ConnectionKind::River => ArchetypeTag::new("connection_river"),
        _ => ArchetypeTag::new("connection_default"),
    }
    // SAFETY: All new() calls above use valid tag strings that cannot fail
    .expect("All connection kind archetype tags are statically valid")
}

/// Compute a deterministic hash of the assembly plan.
/// Uses BLAKE3 for fast, deterministic hashing of the serialized plan.
#[allow(clippy::expect_used)]
pub fn compute_plan_hash(plan: &AssemblyPlan) -> Hash {
    // SAFETY: AssemblyPlan implements Serialize and contains only serializable types.
    // serde_json::to_vec cannot fail for types that implement Serialize correctly.
    let serialized = serde_json::to_vec(plan).expect("AssemblyPlan must be serializable");
    blake3::hash(&serialized)
}

/// Error type for plan compilation failures.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CompileError {
    /// A region in the world has no valid archetype tag.
    InvalidRegionArchetype(ArchetypeTag),
    /// An entity in the world has no valid archetype tag.
    InvalidEntityArchetype(ArchetypeTag),
    /// A connection in the world has no valid archetype tag.
    InvalidConnectionArchetype(ArchetypeTag),
    /// Multiple regions with the same ID.
    DuplicateRegionId(String),
    /// Multiple entities with the same ID.
    DuplicateEntityId(String),
}

impl std::fmt::Display for CompileError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidRegionArchetype(tag) => {
                write!(f, "Invalid region archetype: {}", tag)
            }
            Self::InvalidEntityArchetype(tag) => {
                write!(f, "Invalid entity archetype: {}", tag)
            }
            Self::InvalidConnectionArchetype(tag) => {
                write!(f, "Invalid connection archetype: {}", tag)
            }
            Self::DuplicateRegionId(id) => {
                write!(f, "Duplicate region ID: {}", id)
            }
            Self::DuplicateEntityId(id) => {
                write!(f, "Duplicate entity ID: {}", id)
            }
        }
    }
}

impl std::error::Error for CompileError {}

impl From<CompileError> for ValidationErrors {
    fn from(error: CompileError) -> Self {
        vec![AnvilCoreError::validation(
            FailureClass::Structural,
            ErrorCode::new("A010"),
            "AssemblyCompile",
            "error",
            error.to_string(),
            error.to_string(),
        )]
    }
}
