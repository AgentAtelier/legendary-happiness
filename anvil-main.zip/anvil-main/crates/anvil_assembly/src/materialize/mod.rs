// Source: forge_materialize/src/lib.rs as of the Forge snapshot.
// Materialization: the step between plan and runtime.

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};
use thiserror::Error;

/// Materialization type definitions.
pub mod types;

/// Terrain generation for materialization.
pub mod terrain;

/// Layout computation for world regions.
pub mod layout;

pub use types::{
    DecorationProfile, MaterializeMetadata, MaterializedConnection, MaterializedRegion,
    MaterializedWorld, PlacedEntity, TerrainData, WorldBounds,
};

/// Error type for materialization failures.
#[derive(Debug, Error)]
pub enum MaterializeError {
    /// Failed to generate terrain for a region.
    #[error("Failed to generate terrain for region {0}")]
    TerrainGenerationFailed(String),
    /// Failed to place an entity with a specific reason.
    #[error("Failed to place entity {0}: {1}")]
    EntityPlacementFailed(String, String),
    /// No valid position could be found for an entity.
    #[error("No valid position found for entity {0}")]
    NoValidPosition(String),
    /// A referenced region was not found in the plan.
    #[error("Region {0} not found in plan")]
    RegionNotFound(String),
    /// A referenced archetype was not found in the catalogue.
    #[error("Archetype {0} not found in catalogue")]
    ArchetypeNotFound(ArchetypeTag),
    /// Materialization produced a hash that doesn't match the expected value.
    #[error("Materialization hash mismatch: expected {0}, got {1}")]
    HashMismatch(String, String),
}

/// Materialize an assembly plan into a MaterializedWorld.
pub fn materialize(
    _plan: &crate::AssemblyPlan,
) -> Result<MaterializedWorld, MaterializeError> {
    // TODO: Full implementation will:
    // 1. Create MaterializedRegion for each RegionPlan
    // 2. Generate terrain for each region
    // 3. Place entities using layout algorithms
    // 4. Create connections between regions
    // 5. Compute materialized hash
    Ok(MaterializedWorld::default())
}

/// Compute a deterministic hash of the materialized world.
#[allow(clippy::expect_used)]
pub fn compute_materialized_hash(world: &MaterializedWorld) -> String {
    // SAFETY: MaterializedWorld implements Serialize and contains only serializable types
    let serialized = serde_json::to_vec(world).expect("MaterializedWorld must be serializable");
    let hash = blake3::hash(&serialized);
    hash.to_hex().to_string()
}

/// Generate an authority report for the materialized world.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MaterializedAuthorityReport {
    /// Number of regions in the materialized world.
    pub region_count: usize,
    /// Number of entities in the materialized world.
    pub entity_count: usize,
    /// Number of connections in the materialized world.
    pub connection_count: usize,
    /// Total number of terrain vertices across all regions.
    pub terrain_vertices: usize,
    /// Number of entities that were successfully placed.
    pub placed_entity_count: usize,
}

/// Generate materialized authority report.
pub fn report_materialized_authority(world: &MaterializedWorld) -> MaterializedAuthorityReport {
    MaterializedAuthorityReport {
        region_count: world.regions.len(),
        entity_count: world.entities.len(),
        connection_count: world.connections.len(),
        terrain_vertices: world
            .regions
            .iter()
            .map(|r| r.terrain.vertices.len())
            .sum(),
        placed_entity_count: world
            .regions
            .iter()
            .map(|r| r.placed_entities.len())
            .sum(),
    }
}
