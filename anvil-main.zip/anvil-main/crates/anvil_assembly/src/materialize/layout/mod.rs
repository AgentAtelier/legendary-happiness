// Source: forge_materialize/src/layout.rs as of the Forge snapshot.
// 4-way split of the layout module.

/// Entity footprint computation for placement.
pub mod footprint;

/// History-based layout constraints.
pub mod history;

/// Placement logic for entities.
pub mod place;

/// Storytelling-driven layout.
pub mod storytelling;

pub use footprint::*;
pub use history::*;
pub use place::*;
pub use storytelling::*;
