// Source: forge_materialize/src/layout.rs as of the Forge snapshot.
// Collision avoidance and density rules for entity footprints.

/// Footprint of an entity on the terrain.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct EntityFootprint {
    /// Radius of the entity's base.
    pub radius: f32,
    /// Height of the entity.
    pub height: f32,
    /// Whether the entity blocks placement of other entities.
    pub blocks_placement: bool,
    /// Maximum slope (in radians) that this entity can be placed on.
    pub max_slope: f32,
}

/// Density rules for entity placement within a region.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DensityRules {
    /// Maximum number of entities per square meter.
    pub max_density: f32,
    /// Minimum distance between entities of the same type.
    pub min_same_type_distance: f32,
    /// Minimum distance between any entities.
    pub min_any_distance: f32,
    /// Clustering factor (0 = uniform, 1 = fully clustered).
    pub clustering: f32,
}

impl Default for DensityRules {
    fn default() -> Self {
        Self {
            max_density: 0.1,
            min_same_type_distance: 10.0,
            min_any_distance: 5.0,
            clustering: 0.5,
        }
    }
}

/// Check if a position is valid for placement given existing footprints.
pub fn is_position_valid(
    position: [f32; 3],
    footprint: &EntityFootprint,
    existing: &[PlacedFootprint],
) -> bool {
    for placed in existing {
        let dx = position[0] - placed.position[0];
        let dy = position[1] - placed.position[1];
        let dz = position[2] - placed.position[2];
        let distance_sq = dx * dx + dy * dy + dz * dz;

        let min_distance = if footprint.blocks_placement && placed.footprint.blocks_placement {
            (footprint.radius + placed.footprint.radius).powi(2)
        } else {
            0.0
        };

        if distance_sq < min_distance {
            return false;
        }
    }
    true
}

/// A placed footprint in the world.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PlacedFootprint {
    /// World-space position of the footprint.
    pub position: [f32; 3],
    /// The entity footprint definition.
    pub footprint: EntityFootprint,
}

/// Density map for a region, used to guide placement.
#[derive(Debug, Clone, PartialEq)]
pub struct DensityMap {
    /// Grid of density values (0-1).
    pub grid: Vec<f32>,
    /// Width of the grid.
    pub width: usize,
    /// Depth of the grid.
    pub depth: usize,
    /// Cell size in world units.
    pub cell_size: f32,
}

impl DensityMap {
    /// Creates a new DensityMap with the given dimensions and cell size.
    pub fn new(width: usize, depth: usize, cell_size: f32) -> Self {
        assert!(width > 0, "DensityMap width must be greater than 0");
        assert!(depth > 0, "DensityMap depth must be greater than 0");
        assert!(cell_size > 0.0, "DensityMap cell_size must be greater than 0");
        Self {
            grid: vec![1.0; width * depth],
            width,
            depth,
            cell_size,
        }
    }

    /// Get density at a world position.
    pub fn density_at(&self, position: [f32; 3]) -> f32 {
        // Clamp negative positions to 0 before division and cast
        let gx = ((position[0] / self.cell_size).max(0.0) as usize).min(self.width.saturating_sub(1));
        let gz = ((position[2] / self.cell_size).max(0.0) as usize).min(self.depth.saturating_sub(1));
        self.grid[gz * self.width + gx]
    }

    /// Set density at grid coordinates.
    pub fn set(&mut self, gx: usize, gz: usize, value: f32) {
        if gx < self.width && gz < self.depth {
            self.grid[gz * self.width + gx] = value.clamp(0.0, 1.0);
        }
    }
}
