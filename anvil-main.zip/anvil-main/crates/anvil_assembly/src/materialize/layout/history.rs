// Source: forge_materialize/src/layout.rs as of the Forge snapshot.
// Post-placement history mutation.

use anvil_core::ArchetypeTag;

/// A mutation to apply to the placement history.
#[derive(Debug, Clone, PartialEq)]
pub enum PlacementMutation {
    /// Add an entity at a specific position.
    AddEntity {
        /// The archetype tag of the entity to add.
        archetype_tag: ArchetypeTag,
        /// World-space position.
        position: [f32; 3],
        /// Rotation as Euler angles.
        rotation: [f32; 3],
        /// Uniform scale factor.
        scale: f32,
    },
    /// Remove an entity by index.
    RemoveEntity {
        /// Index of the entity to remove.
        index: usize
    },
    /// Move an entity to a new position.
    MoveEntity {
        /// Index of the entity to move.
        index: usize,
        /// Original position.
        from_position: [f32; 3],
        /// New position.
        to_position: [f32; 3]
    },
    /// Update entity rotation.
    RotateEntity {
        /// Index of the entity to rotate.
        index: usize,
        /// Original rotation.
        from_rotation: [f32; 3],
        /// New rotation.
        to_rotation: [f32; 3]
    },
    /// Update entity scale.
    ScaleEntity {
        /// Index of the entity to scale.
        index: usize,
        /// Original scale.
        from_scale: f32,
        /// New scale.
        to_scale: f32
    },
}

impl PlacementMutation {
    /// Returns the inverse of this mutation for undo operations.
    pub fn inverse(&self) -> PlacementMutation {
        match self {
            PlacementMutation::AddEntity { archetype_tag: _, position: _, rotation: _, scale: _ } => {
                // Inverse of Add is Remove - but we need the index
                // Since we don't have the index, we can't create a proper inverse
                // This is a limitation that will be addressed when full undo is implemented
                PlacementMutation::RemoveEntity { index: 0 }
            }
            PlacementMutation::RemoveEntity { index: _ } => {
                // Inverse of Remove is Add - but we need the entity data
                // This is a limitation that will be addressed when full undo is implemented
                PlacementMutation::AddEntity {
                    archetype_tag: ArchetypeTag::missing(),
                    position: [0.0, 0.0, 0.0],
                    rotation: [0.0, 0.0, 0.0],
                    scale: 1.0,
                }
            }
            PlacementMutation::MoveEntity { index, from_position, to_position } => {
                // Inverse: move back from to_position to from_position
                PlacementMutation::MoveEntity {
                    index: *index,
                    from_position: *to_position,
                    to_position: *from_position,
                }
            }
            PlacementMutation::RotateEntity { index, from_rotation, to_rotation } => {
                // Inverse: rotate back from to_rotation to from_rotation
                PlacementMutation::RotateEntity {
                    index: *index,
                    from_rotation: *to_rotation,
                    to_rotation: *from_rotation,
                }
            }
            PlacementMutation::ScaleEntity { index, from_scale, to_scale } => {
                // Inverse: scale back from to_scale to from_scale
                PlacementMutation::ScaleEntity {
                    index: *index,
                    from_scale: *to_scale,
                    to_scale: *from_scale,
                }
            }
        }
    }
}

/// History of placement operations for undo/redo.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlacementHistory {
    /// Stack of mutations that can be undone.
    undo_stack: Vec<PlacementMutation>,
    /// Stack of mutations that can be redone.
    redo_stack: Vec<PlacementMutation>,
    /// Maximum history size.
    max_size: usize,
}

impl PlacementHistory {
    /// Creates a new PlacementHistory with the given maximum size.
    pub fn new(max_size: usize) -> Self {
        Self {
            undo_stack: Vec::new(),
            redo_stack: Vec::new(),
            max_size,
        }
    }

    /// Push a mutation onto the history.
    pub fn push(&mut self, mutation: PlacementMutation) {
        self.undo_stack.push(mutation);
        self.redo_stack.clear();

        // Trim if over max size
        if self.undo_stack.len() > self.max_size {
            self.undo_stack.remove(0);
        }
    }

    /// Undo the last mutation, returns the inverse mutation to apply.
    pub fn undo(&mut self) -> Option<PlacementMutation> {
        self.undo_stack.pop().inspect(|forward| {
            // Store the forward mutation for redo
            self.redo_stack.push(forward.clone());
        }).map(|forward| forward.inverse())
    }

    /// Redo the last undone mutation, returns the forward mutation to apply.
    pub fn redo(&mut self) -> Option<PlacementMutation> {
        self.redo_stack.pop().inspect(|forward| {
            self.undo_stack.push(forward.clone());
        })
    }

    /// Clear all history.
    pub fn clear(&mut self) {
        self.undo_stack.clear();
        self.redo_stack.clear();
    }

    /// Get current history depth.
    pub fn depth(&self) -> usize {
        self.undo_stack.len()
    }
}

/// Track placement statistics for a region.
#[derive(Debug, Clone, PartialEq, Default)]
pub struct PlacementStats {
    /// Number of entities placed.
    pub placed_count: usize,
    /// Number of placement failures.
    pub failure_count: usize,
    /// Time spent on placement (in seconds).
    pub time_spent: f64,
    /// Average placement attempts per entity.
    pub avg_attempts: f32,
    /// Placement density (entities per square meter).
    pub density: f32,
}

/// Apply a set of mutations to placement stats.
pub fn apply_mutations_to_stats(
    stats: &mut PlacementStats,
    mutations: &[PlacementMutation],
) {
    for mutation in mutations {
        match mutation {
            PlacementMutation::AddEntity { .. } => {
                stats.placed_count += 1;
            }
            PlacementMutation::RemoveEntity { .. } => {
                stats.placed_count = stats.placed_count.saturating_sub(1);
            }
            _ => {}
        }
    }
}
