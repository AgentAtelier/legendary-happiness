// Source: forge_materialize/src/layout.rs as of the Forge snapshot.
// Entity placement core.

use anvil_core::ArchetypeTag;
use noise::{NoiseFn, Perlin};

/// Parameters for entity placement.
#[derive(Debug, Clone, Copy)]
pub struct PlacementParams {
    /// Minimum distance between placed entities.
    pub min_distance: f32,
    /// Maximum attempts to find a valid position.
    pub max_attempts: usize,
    /// Whether to use jitter (random offset) for placement.
    pub use_jitter: bool,
    /// Jitter radius as a fraction of the region size.
    pub jitter_radius: f32,
}

impl Default for PlacementParams {
    fn default() -> Self {
        Self {
            min_distance: 5.0,
            max_attempts: 100,
            use_jitter: true,
            jitter_radius: 0.1,
        }
    }
}

/// A valid position for entity placement.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PlacementPosition {
    /// X coordinate.
    pub x: f32,
    /// Y coordinate.
    pub y: f32,
    /// Z coordinate.
    pub z: f32,
}

/// Attempt to find a valid position for an entity within a region.
pub fn find_placement_position(
    region_center: [f32; 3],
    region_extents: [f32; 3],
    _archetype: &ArchetypeTag,
    params: &PlacementParams,
    seed: u32,
) -> Option<PlacementPosition> {
    let perlin = Perlin::new(seed);
    let mut last_position: Option<PlacementPosition> = None;

    for attempt in 0..params.max_attempts {
        let t = attempt as f64 / params.max_attempts as f64;

        // Generate a position within the region
        let mut px = perlin.get([t * 100.0, 0.0]) as f32;
        let mut pz = perlin.get([0.0, t * 100.0]) as f32;

        // Map from -1..1 to 0..1
        px = (px + 1.0) / 2.0;
        pz = (pz + 1.0) / 2.0;

        // Apply jitter if enabled
        if params.use_jitter {
            let jx = perlin.get([t * 200.0, 100.0]) as f32 * params.jitter_radius;
            let jz = perlin.get([100.0, t * 200.0]) as f32 * params.jitter_radius;
            px = (px + jx + 1.0) / 2.0;
            pz = (pz + jz + 1.0) / 2.0;
        }

        // Convert to world coordinates
        let wx = region_center[0] + (px - 0.5) * region_extents[0] * 2.0;
        let wy = region_center[1];
        let wz = region_center[2] + (pz - 0.5) * region_extents[2] * 2.0;

        // For now, store the position (always valid in this stub)
        // In the full implementation, we'd check against existing placements
        // and terrain slope and only store valid positions.
        last_position = Some(PlacementPosition { x: wx, y: wy, z: wz });
    }

    last_position
}

/// Place entities in a region according to a density map.
pub fn place_entities_in_region(
    _region_id: &str,
    region_center: [f32; 3],
    region_extents: [f32; 3],
    _archetype: &ArchetypeTag,
    count: usize,
    params: &PlacementParams,
    seed: u32,
) -> Vec<PlacementPosition> {
    let mut positions = Vec::with_capacity(count);

    for i in 0..count {
        let entity_seed = seed.wrapping_add(i as u32);
        if let Some(pos) = find_placement_position(region_center, region_extents, _archetype, params, entity_seed) {
            positions.push(pos);
        }
    }

    positions
}
