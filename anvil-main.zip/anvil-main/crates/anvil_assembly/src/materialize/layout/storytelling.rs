// Source: forge_materialize/src/layout.rs as of the Forge snapshot.
// Narrative-driven surface patches.

use anvil_core::ArchetypeTag;
use noise::{NoiseFn, Perlin};

/// Default archetype tag for surface paths.
/// Valid format: starts with lowercase letter, contains only lowercase letters, digits, underscores.
const SURFACE_PATH_DIRT_TAG: &str = "surface_path_dirt";

/// A narrative-driven surface patch for storytelling purposes.
#[derive(Debug, Clone, PartialEq)]
pub struct SurfacePatch {
    /// Identifier for this patch.
    pub patch_id: String,
    /// Archetype tag for the surface type.
    pub surface_archetype: ArchetypeTag,
    /// World-space bounds of the patch.
    pub bounds: [[f32; 3]; 2], // min, max
    /// Narrative significance level (0-1).
    pub significance: f32,
    /// Whether this patch is a player path.
    pub is_path: bool,
    /// Connected patches.
    pub connected_to: Vec<String>,
}

/// Parameters for generating narrative surface patches.
#[derive(Debug, Clone, Copy)]
pub struct StorytellingParams {
    /// Number of main paths to generate.
    pub num_main_paths: usize,
    /// Number of side paths per main path.
    pub num_side_paths: usize,
    /// Width of paths.
    pub path_width: f32,
    /// Curvature factor for paths (higher = more winding).
    pub curvature: f32,
    /// Seed for procedural generation.
    pub seed: u32,
}

impl Default for StorytellingParams {
    fn default() -> Self {
        Self {
            num_main_paths: 3,
            num_side_paths: 2,
            path_width: 5.0,
            curvature: 0.5,
            seed: 0,
        }
    }
}

/// Generate a set of narrative surface patches.
pub fn generate_surface_patches(
    _region_center: [f32; 3],
    _region_extents: [f32; 3],
    params: &StorytellingParams,
) -> Vec<SurfacePatch> {
    let mut patches = Vec::new();

    // Generate main paths
    for i in 0..params.num_main_paths {
        let path_seed = params.seed.wrapping_add(i as u32);
        let path = generate_path(
            _region_center,
            _region_extents,
            params.path_width,
            params.curvature,
            path_seed,
        );
        patches.push(path);
    }

    // Generate side paths
    for i in 0..params.num_main_paths * params.num_side_paths {
        let side_seed = params.seed.wrapping_add(1000).wrapping_add(i as u32);
        let side_path = generate_path(
            _region_center,
            _region_extents,
            params.path_width * 0.7,
            params.curvature * 1.5,
            side_seed,
        );
        patches.push(side_path);
    }

    patches
}

/// Generate a single path as a surface patch.
fn generate_path(
    region_center: [f32; 3],
    region_extents: [f32; 3],
    width: f32,
    curvature: f32,
    seed: u32,
) -> SurfacePatch {
    let perlin = Perlin::new(seed);

    // Generate control points for the path
    let num_segments = 5;
    let mut control_points = Vec::with_capacity(num_segments);

    for i in 0..num_segments {
        let t = i as f64 / (num_segments - 1) as f64;
        let px = perlin.get([t * 100.0, seed as f64]) as f32 * curvature;
        let pz = perlin.get([seed as f64, t * 100.0]) as f32 * curvature;

        let wx = region_center[0] + (px) * region_extents[0];
        let wz = region_center[2] + (pz) * region_extents[2];

        control_points.push([wx, region_center[1], wz]);
    }

    // Compute bounds from control points
    let mut min = [f32::INFINITY, f32::INFINITY, f32::INFINITY];
    let mut max = [f32::NEG_INFINITY, f32::NEG_INFINITY, f32::NEG_INFINITY];

    for &cp in &control_points {
        min[0] = min[0].min(cp[0]);
        min[1] = min[1].min(cp[1]);
        min[2] = min[2].min(cp[2]);
        max[0] = max[0].max(cp[0]);
        max[1] = max[1].max(cp[1]);
        max[2] = max[2].max(cp[2]);
    }

    // Expand bounds by half width
    let half_width = width / 2.0;
    min[0] -= half_width;
    max[0] += half_width;
    min[2] -= half_width;
    max[2] += half_width;

    // SAFETY: SURFACE_PATH_DIRT_TAG is a valid archetype tag format
    // (starts with lowercase letter, contains only lowercase letters and underscores)
    #[allow(clippy::expect_used)]
    let surface_archetype = ArchetypeTag::new(SURFACE_PATH_DIRT_TAG)
        .expect("surface_path_dirt is a statically valid archetype tag");
    SurfacePatch {
        patch_id: format!("path_{}", seed),
        surface_archetype,
        bounds: [min, max],
        significance: 0.8,
        is_path: true,
        connected_to: Vec::new(),
    }
}

/// Compute narrative density at a position.
pub fn narrative_density_at(
    position: [f32; 3],
    patches: &[SurfacePatch],
) -> f32 {
    patches
        .iter()
        .map(|patch| {
            // Check if position is within patch bounds
            if position[0] >= patch.bounds[0][0]
                && position[0] <= patch.bounds[1][0]
                && position[2] >= patch.bounds[0][2]
                && position[2] <= patch.bounds[1][2]
            {
                patch.significance
            } else {
                0.0
            }
        })
        .sum()
}
