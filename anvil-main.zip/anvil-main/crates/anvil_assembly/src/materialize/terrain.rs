// Source: forge_materialize/src/terrain.rs as of the Forge snapshot.
// Terrain generation using Perlin noise.

use noise::{NoiseFn, Perlin};

/// Mesh data tuple: vertices, normals, UVs, indices.
pub type TerrainMeshData = (Vec<[f32; 3]>, Vec<[f32; 3]>, Vec<[f32; 2]>, Vec<u32>);

/// Parameters for Perlin noise-based terrain generation.
#[derive(Debug, Clone, Copy)]
pub struct TerrainNoiseParams {
    /// Frequency of the noise (higher = more detail).
    pub frequency: f64,
    /// Persistence for fractal noise (how quickly amplitudes decrease).
    pub persistence: f64,
    /// Lacunarity for fractal noise (how quickly frequencies increase).
    pub lacunarity: f64,
    /// Number of octaves for fractal noise.
    pub octaves: usize,
    /// Seed for the noise generator.
    pub seed: u32,
}

impl Default for TerrainNoiseParams {
    fn default() -> Self {
        Self {
            frequency: 0.05,
            persistence: 0.5,
            lacunarity: 2.0,
            octaves: 4,
            seed: 0,
        }
    }
}

/// Generate terrain heightmap for a region.
pub fn generate_terrain(
    width: usize,
    depth: usize,
    params: &TerrainNoiseParams,
) -> Vec<f32> {
    let perlin = Perlin::new(params.seed);
    let mut heightmap = Vec::with_capacity(width * depth);

    for z in 0..depth {
        for x in 0..width {
            let mut xf = x as f64 * params.frequency;
            let mut zf = z as f64 * params.frequency;

            // Fractal noise (fBm)
            let mut amplitude = 1.0;
            let mut max_value = 0.0;
            let mut value = 0.0;

            for _ in 0..params.octaves {
                value += perlin.get([xf, zf]) * amplitude;
                max_value += amplitude;
                xf *= params.lacunarity;
                zf *= params.lacunarity;
                amplitude *= params.persistence;
            }

            // Normalize to 0-1 range
            let normalized = ((value / max_value) + 1.0) / 2.0;
            heightmap.push(normalized as f32);
        }
    }

    heightmap
}

/// Calculate slope at a given point in the heightmap.
/// Returns the slope in radians.
pub fn calculate_slope_at(
    heightmap: &[f32],
    width: usize,
    x: usize,
    z: usize,
) -> f32 {
    if x == 0 || x >= width - 1 || z == 0 || z >= (heightmap.len() / width) - 1 {
        return 0.0;
    }

    let idx = z * width + x;
    let left = heightmap[idx - 1];
    let right = heightmap[idx + 1];
    let up = heightmap[idx - width];
    let down = heightmap[idx + width];

    let dx = (right - left) * 0.5;
    let dz = (down - up) * 0.5;

    dx.hypot(dz).atan()
}

/// Generate a terrain mesh from a heightmap.
pub fn generate_terrain_mesh(
    heightmap: &[f32],
    width: usize,
    height_scale: f32,
) -> TerrainMeshData {
    let depth = heightmap.len() / width;
    let mut vertices = Vec::new();
    let mut normals = Vec::new();
    let mut uvs = Vec::new();
    let mut indices = Vec::new();

    // Pass 1: Generate all vertices and UVs
    for z in 0..depth {
        for x in 0..width {
            let idx = z * width + x;
            let height = heightmap[idx] * height_scale;
            vertices.push([x as f32, height, z as f32]);
            uvs.push([x as f32 / (width - 1) as f32, z as f32 / (depth - 1) as f32]);
        }
    }

    // Pass 2: Compute normals from the complete vertex array
    for z in 0..depth {
        for x in 0..width {
            let idx = z * width + x;
            let normal = if x < width - 1 && z < depth - 1 {
                let p0 = vertices[idx];
                let p1 = vertices[idx + 1];
                let p2 = vertices[idx + width];

                let edge1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
                let edge2 = [p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]];

                // Cross product
                let nx = edge1[1] * edge2[2] - edge1[2] * edge2[1];
                let ny = edge1[2] * edge2[0] - edge1[0] * edge2[2];
                let nz = edge1[0] * edge2[1] - edge1[1] * edge2[0];

                // Normalize
                let len = (nx * nx + ny * ny + nz * nz).sqrt();
                if len > 0.0 {
                    [nx / len, ny / len, nz / len]
                } else {
                    [0.0, 1.0, 0.0]
                }
            } else {
                [0.0, 1.0, 0.0]
            };
            normals.push(normal);
        }
    }

    // Generate indices (two triangles per quad)
    for z in 0..depth - 1 {
        for x in 0..width - 1 {
            let idx = z * width + x;
            indices.push(idx as u32);
            indices.push((idx + 1) as u32);
            indices.push((idx + width) as u32);

            indices.push(idx as u32);
            indices.push((idx + width) as u32);
            indices.push((idx + width + 1) as u32);
        }
    }

    (vertices, normals, uvs, indices)
}
