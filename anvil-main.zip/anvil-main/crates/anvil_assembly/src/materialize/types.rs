// Source: forge_materialize/src/types.rs as of the Forge snapshot.
// Materialized world types.

use anvil_core::ArchetypeTag;
use serde::{Deserialize, Serialize};

/// Bounding box in world space.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorldBounds {
    /// Minimum corner of the bounding box.
    pub min: [f32; 3],
    /// Maximum corner of the bounding box.
    pub max: [f32; 3],
}

/// Terrain data for a single region.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TerrainData {
    /// Vertices of the terrain mesh.
    pub vertices: Vec<[f32; 3]>,
    /// Normals for each vertex.
    pub normals: Vec<[f32; 3]>,
    /// UV coordinates for each vertex.
    pub uvs: Vec<[f32; 2]>,
    /// Indices for the mesh (triangles).
    pub indices: Vec<u32>,
    /// Heightmap values (normalized 0-1).
    pub heightmap: Vec<f32>,
    /// Slope values at each point (radians).
    pub slopes: Vec<f32>,
}

/// A placed entity in the materialized world.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PlacedEntity {
    /// The archetype tag of the entity.
    pub archetype_tag: ArchetypeTag,
    /// World-space position.
    pub position: [f32; 3],
    /// Rotation as Euler angles in degrees.
    pub rotation: [f32; 3],
    /// Uniform scale factor.
    pub scale: f32,
    /// Instance identifier within the region.
    pub instance_id: u64,
}

/// Decoration profile for entity placement.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DecorationProfile {
    /// Minimum scale for decorated entities.
    pub min_scale: f32,
    /// Maximum scale for decorated entities.
    pub max_scale: f32,
    /// Minimum rotation offset in degrees.
    pub min_rotation: f32,
    /// Maximum rotation offset in degrees.
    pub max_rotation: f32,
    /// Density of decoration (entities per square meter).
    pub density: f32,
    /// Radius around parent entity to place decorations.
    pub radius: f32,
}

/// Metadata for the materialization process.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
pub struct MaterializeMetadata {
    /// The plan ID this was materialized from.
    pub plan_id: String,
    /// Timestamp of materialization.
    pub timestamp: String,
    /// Version of the materialization algorithm.
    pub version: String,
    /// Random seed used for procedural placement.
    pub seed: u64,
}

/// A materialized region.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MaterializedRegion {
    /// Region identifier.
    pub region_id: String,
    /// Archetype tag.
    pub archetype_tag: ArchetypeTag,
    /// World-space bounds.
    pub bounds: WorldBounds,
    /// Terrain data for this region.
    pub terrain: TerrainData,
    /// Entities placed in this region.
    pub placed_entities: Vec<PlacedEntity>,
}

/// A materialized connection between regions.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MaterializedConnection {
    /// Connection identifier.
    pub connection_id: String,
    /// Archetype tag.
    pub archetype_tag: ArchetypeTag,
    /// The two regions connected.
    pub region_a: String,
    /// The second region in the connection.
    pub region_b: String,
    /// Whether this is one-way.
    pub one_way: bool,
}

/// The fully materialized world ready for runtime.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
pub struct MaterializedWorld {
    /// All materialized regions.
    pub regions: Vec<MaterializedRegion>,
    /// All materialized entities (global list).
    pub entities: Vec<PlacedEntity>,
    /// All materialized connections.
    pub connections: Vec<MaterializedConnection>,
    /// Metadata about the materialization.
    pub metadata: MaterializeMetadata,
}

impl MaterializedWorld {
    /// Creates a new empty MaterializedWorld with the given plan ID.
    pub fn new(plan_id: String) -> Self {
        Self {
            regions: Vec::new(),
            entities: Vec::new(),
            connections: Vec::new(),
            metadata: MaterializeMetadata {
                plan_id,
                version: "1.0.0".to_string(),
                seed: 42, // Default seed
                ..Default::default()
            },
        }
    }

    /// Sets the random seed for materialization.
    pub fn with_seed(mut self, seed: u64) -> Self {
        self.metadata.seed = seed;
        self
    }
}
