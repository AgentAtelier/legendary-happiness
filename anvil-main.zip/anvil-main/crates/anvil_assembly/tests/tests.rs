//! Test suite for anvil_assembly crate.
//!
//! Wave 4: Tests + Correctness

use anvil_assembly::authority::{validate_authority_report, WorldPlanAuthorityReport};
use anvil_assembly::compile::compute_plan_hash;
use anvil_assembly::materialize::layout::place::{find_placement_position, PlacementParams};
use anvil_assembly::materialize::terrain::{generate_terrain, generate_terrain_mesh, TerrainNoiseParams};
use anvil_assembly::materialize::{compute_materialized_hash, MaterializedWorld};
use anvil_assembly::plan::AssemblyPlan;
use anvil_core::ArchetypeTag;

const SURFACE_PATH_DIRT_TAG: &str = "surface_path_dirt";

/// Test that generate_terrain produces width × depth values in [0.0, 1.0]
#[test]
fn test_generate_terrain_produces_correct_dimensions_and_range() {
    let width = 100;
    let depth = 50;
    let params = TerrainNoiseParams::default();
    
    let heightmap = generate_terrain(width, depth, &params);
    
    // Check dimensions
    assert_eq!(heightmap.len(), width * depth, 
        "Heightmap should have width × depth values");
    
    // Check all values are in [0.0, 1.0]
    for &height in &heightmap {
        assert!((0.0..=1.0).contains(&height), 
            "Height value {} is out of range [0.0, 1.0]", height);
    }
}

/// Test that generate_terrain_mesh does not panic and produces correct vertex count
#[test]
fn test_generate_terrain_mesh_no_panic_correct_vertices() {
    let width = 4;
    let depth = 4;
    let params = TerrainNoiseParams::default();
    
    // Generate heightmap
    let heightmap = generate_terrain(width, depth, &params);
    
    // Generate mesh - should not panic
    let mesh_data = generate_terrain_mesh(&heightmap, width, 1.0);
    
    let (vertices, normals, uvs, _indices) = mesh_data;
    
    // Check vertex count matches width × depth
    assert_eq!(vertices.len(), width * depth, 
        "Should have width × depth vertices");
    assert_eq!(normals.len(), width * depth, 
        "Should have width × depth normals");
    assert_eq!(uvs.len(), width * depth, 
        "Should have width × depth UVs");
}

/// Test that find_placement_position returns a position within region bounds
#[test]
fn test_find_placement_position_returns_valid_position() {
    let region_center = [0.0, 0.0, 0.0];
    let region_extents = [100.0, 50.0, 100.0]; // half-extents
    let archetype = ArchetypeTag::new(SURFACE_PATH_DIRT_TAG).expect("Valid tag");
    let params = PlacementParams::default();
    let seed = 42;
    
    let position = find_placement_position(region_center, region_extents, &archetype, &params, seed);
    
    assert!(position.is_some(), "Should find a placement position");
    
    let pos = position.unwrap();
    // Position should be within bounds: center ± extents
    assert!(pos.x >= -region_extents[0] && pos.x <= region_extents[0], 
        "X position {} out of bounds [{}, {}]", pos.x, -region_extents[0], region_extents[0]);
    assert!(pos.z >= -region_extents[2] && pos.z <= region_extents[2], 
        "Z position {} out of bounds [{}, {}]", pos.z, -region_extents[2], region_extents[2]);
}

/// Test that validate_authority_report on an empty plan returns no errors
#[test]
fn test_validate_authority_report_empty_plan_no_errors() {
    use std::collections::HashMap;
    let report = WorldPlanAuthorityReport {
        region_count: 0,
        entity_count: 0,
        connection_count: 0,
        regions_by_archetype: HashMap::new(),
        entities_by_archetype: HashMap::new(),
        connections_by_archetype: HashMap::new(),
        unused_archetypes: Vec::new(),
    };
    
    let errors = validate_authority_report(&report);
    assert!(errors.is_empty(), "Empty report should have no errors, got: {:?}", errors);
}

/// Test that compute_plan_hash on identical inputs returns identical strings
#[test]
fn test_compute_plan_hash_identical_inputs() {
    let plan1 = AssemblyPlan::new("test_plan".to_string(), "Test Plan".to_string());
    let plan2 = AssemblyPlan::new("test_plan".to_string(), "Test Plan".to_string());
    
    let hash1 = compute_plan_hash(&plan1);
    let hash2 = compute_plan_hash(&plan2);
    
    assert_eq!(hash1, hash2, "Identical plans should produce identical hashes");
}

/// Test that compute_materialized_hash on identical inputs returns identical strings
#[test]
fn test_compute_materialized_hash_identical_inputs() {
    let world1 = MaterializedWorld::default();
    let world2 = MaterializedWorld::default();
    
    let hash1 = compute_materialized_hash(&world1);
    let hash2 = compute_materialized_hash(&world2);
    
    assert_eq!(hash1, hash2, "Identical worlds should produce identical hashes");
}
