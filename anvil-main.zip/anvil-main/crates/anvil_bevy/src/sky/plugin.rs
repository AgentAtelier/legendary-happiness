//! Sky sphere rendering plugin.
//!
//! This module provides the SkyPlugin which spawns and updates the sky sphere
//! entity with the procedural sky material.

use bevy::light::{NotShadowCaster, NotShadowReceiver};
use bevy::prelude::*;

use super::material::SkyMaterial;
use crate::environment::config::EnvironmentConfig;
use crate::environment::state::EnvironmentState;
use crate::markers::SkySphere;

/// Plugin that manages the sky sphere rendering.
///
/// Spawns a large inverted sphere with a custom material that renders
/// a procedural sky gradient with sun disc and corona.
pub struct SkyPlugin;

impl Plugin for SkyPlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins(MaterialPlugin::<SkyMaterial>::default())
           .add_systems(Startup, spawn_sky_sphere)
           .add_systems(PostUpdate, update_sky_uniforms);
    }
}

/// Spawns the sky sphere entity with the procedural sky material.
fn spawn_sky_sphere(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut sky_mats: ResMut<Assets<SkyMaterial>>,
    config: Res<EnvironmentConfig>,
) {
    let radius = config.sky.sphere_radius;
    let mesh = meshes.add(Sphere::new(radius).mesh().ico(6).unwrap());

    let mat = sky_mats.add(SkyMaterial {
        sun_disc_size: config.sky.sun_disc_size,
        sun_disc_intensity: config.sky.sun_disc_intensity,
        fog_blend_start: 0.12,
        ..default()
    });

    commands.spawn((
        Mesh3d(mesh),
        MeshMaterial3d(mat),
        // Flip normals so the inside faces the camera
        Transform::from_scale(Vec3::splat(-1.0)),
        NotShadowCaster,
        NotShadowReceiver,
        SkySphere,
    ));
}

/// Updates the sky material uniforms from the environment state.
fn update_sky_uniforms(
    env: Res<EnvironmentState>,
    mut sky_mats: ResMut<Assets<SkyMaterial>>,
    sky_query: Query<&MeshMaterial3d<SkyMaterial>, With<SkySphere>>,
) {
    let Ok(handle) = sky_query.single() else {
        warn_once!("SkyPlugin: no SkySphere entity found");
        return;
    };
    let Some(mat) = sky_mats.get_mut(&handle.0) else { return };

    let sun_dir = env.sun_dir_vec();
    mat.zenith_color = env.sky_zenith_color.current;
    mat.horizon_color = env.fog_color.current;
    mat.fog_color = env.fog_color.current;
    mat.sun_direction = Vec4::new(sun_dir.x, sun_dir.y, sun_dir.z, 0.0);
    mat.sun_color = env.sun_color.current;
    mat.sun_disc_intensity = env.sun_disc_base_intensity;
}
