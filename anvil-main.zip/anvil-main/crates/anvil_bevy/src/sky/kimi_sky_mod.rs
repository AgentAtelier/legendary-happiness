//! Sky sphere rendering module.
//!
//! This module provides the sky sphere material and plugin for rendering
//! a procedural sky with gradient and sun disc.

pub mod material;
pub mod plugin;

pub use material::*;
pub use plugin::*;
