//! Sky sphere material.
//!
//! Provides a custom Bevy material for rendering the procedural sky sphere
//! with gradient colors and sun disc.

use bevy::prelude::*;
use bevy::render::render_resource::AsBindGroup;
use bevy::shader::ShaderRef;

/// Custom material for the sky sphere.
///
/// This material renders a gradient sky with configurable zenith/horizon colors,
/// fog blending, and a sun disc with corona effect.
#[derive(Asset, AsBindGroup, TypePath, Clone, Default)]
pub struct SkyMaterial {
    /// Color at the zenith (top of sky).
    #[uniform(0)]
    pub zenith_color: LinearRgba,
    /// Color at the horizon.
    #[uniform(0)]
    pub horizon_color: LinearRgba,
    /// Color of the fog at the horizon.
    #[uniform(0)]
    pub fog_color: LinearRgba,
    /// Direction to the sun in world space (normalized vec4).
    #[uniform(0)]
    pub sun_direction: Vec4,
    /// Color of the sun disc.
    #[uniform(0)]
    pub sun_color: LinearRgba,
    /// Angular radius of the sun disc in the shader (0-1).
    #[uniform(0)]
    pub sun_disc_size: f32,
    /// Bloom intensity multiplier for the sun disc.
    #[uniform(0)]
    pub sun_disc_intensity: f32,
    /// Elevation angle where fog blending starts.
    #[uniform(0)]
    pub fog_blend_start: f32,
    /// Padding to align uniform buffer.
    #[uniform(0)]
    pub _pad: f32,
}

impl Material for SkyMaterial {
    fn fragment_shader() -> ShaderRef {
        "shaders/sky.wgsl".into()
    }

    fn alpha_mode(&self) -> AlphaMode {
        AlphaMode::Opaque
    }

    fn depth_bias(&self) -> f32 {
        f32::MIN // never write depth, always behind everything
    }

    fn prepass_fragment_shader() -> ShaderRef {
        ShaderRef::Default
    }
}
