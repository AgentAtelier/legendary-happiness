//! Solar math and environment target derivation.
//!
//! This module provides pure math functions to derive visual targets from
//! simulation state. No Bevy queries are used here.

use std::f32::consts::TAU;
use bevy::color::LinearRgba;

use crate::sim_bridge::SimSnapshot;
use crate::environment::{config::EnvironmentConfig, state::EnvironmentState};

/// Derives all visual targets from the current snapshot and config.
/// No smoothing applied here — call `env_state.tick(dt)` afterwards.
/// This function is pure: it only reads arguments and sets targets.
pub fn resolve_targets(
    snapshot: &SimSnapshot,
    config: &EnvironmentConfig,
    env: &mut EnvironmentState,
) {
    let tod = snapshot.time.time_of_day;
    let w = &snapshot.weather;
    let lat = config.location.latitude_deg.to_radians();
    let dec = config.location.declination_deg.to_radians();

    // ── Solar geometry ──────────────────────────────────────────────────
    let hour_angle = (tod - 0.5) * TAU;

    let sin_elev = lat.sin() * dec.sin()
                 + lat.cos() * dec.cos() * hour_angle.cos();
    let elevation = sin_elev.asin();

    let cos_elev_safe = elevation.cos().max(0.0001);
    let cos_azim = (dec.sin() - lat.sin() * sin_elev)
                 / (lat.cos() * cos_elev_safe);
    let raw_azim = cos_azim.clamp(-1.0, 1.0).acos();
    let azimuth = if hour_angle > 0.0 { TAU - raw_azim } else { raw_azim }
                  - std::f32::consts::FRAC_PI_2;

    env.sun_elevation.set_target(elevation);
    env.sun_azimuth.set_target(azimuth);

    // ── Illuminance ──────────────────────────────────────────────────────
    let il = &config.illuminance;
    // How far above the horizon (0 = on horizon, 1 = at peak elevation for latitude)
    let sun_above = (elevation / 0.06).clamp(0.0, 1.0);
    let cloud_factor = 1.0 - w.cloud_cover * (1.0 - il.overcast_factor);
    let base_lux = il.noon_clear_lux * sun_above * cloud_factor;
    env.sun_illuminance.set_target(base_lux.max(il.night_min_lux));

    // ── Sun colour ────────────────────────────────────────────────────────
    // Near horizon: warm orange. At zenith: neutral white. Overcast: cooler.
    let horizon_blend = 1.0 - (elevation / (std::f32::consts::FRAC_PI_4)).clamp(0.0, 1.0);
    let overcast_cool = w.cloud_cover * 0.15;
    env.sun_color.set_target(LinearRgba::new(
        1.0,
        (0.70 + 0.30 * (1.0 - horizon_blend) - overcast_cool).clamp(0.0, 1.0),
        (0.40 + 0.60 * (1.0 - horizon_blend) - overcast_cool * 0.5).clamp(0.0, 1.0),
        1.0,
    ));

    // ── Ambient ───────────────────────────────────────────────────────────
    let ambient_strength = il.ambient_night
        + (il.ambient_noon - il.ambient_night) * sun_above * cloud_factor;
    // Overcast shifts ambient toward flat grey-blue; clear sky keeps warmer cast.
    let warm = 1.0 - w.cloud_cover * 0.5;
    env.ambient_color.set_target(LinearRgba::new(
        0.50 + 0.20 * sun_above * warm,
        0.50 + 0.18 * sun_above,
        0.55 + 0.25 * sun_above * (1.0 - warm * 0.3),
        1.0,
    ));
    env.ambient_brightness.set_target(ambient_strength);

    // ── Fog ───────────────────────────────────────────────────────────────
    let fc = &config.fog;
    let cold_contribution = if w.temperature_c < fc.cold_fog_threshold_c {
        (fc.cold_fog_threshold_c - w.temperature_c) * fc.cold_fog_scale
    } else {
        0.0
    };
    let density = (fc.base_density
        + w.humidity * fc.humidity_density_scale
        + w.precipitation * fc.precip_density_scale
        + cold_contribution)
        .clamp(0.0, fc.max_density);
    env.fog_density.set_target(density);

    // Fog colour tracks sky horizon, shifts grey with humidity, brown with precipitation.
    let fog_r = 0.55 + horizon_blend * 0.25 - w.humidity * 0.08 + w.precipitation * 0.04;
    let fog_g = 0.45 + horizon_blend * 0.10 - w.humidity * 0.05;
    let fog_b = 0.40 + sun_above * 0.15 + w.cloud_cover * 0.10 - w.precipitation * 0.04;
    env.fog_color.set_target(LinearRgba::new(fog_r, fog_g, fog_b, 1.0));

    // ── Sky zenith ────────────────────────────────────────────────────────
    // Deep twilight purple -> grey-blue overcast -> dawn orange-pink
    let night_zenith = LinearRgba::new(0.04, 0.04, 0.12, 1.0);
    let day_clear = LinearRgba::new(0.20, 0.25, 0.50, 1.0);
    let day_overcast = LinearRgba::new(0.50, 0.50, 0.55, 1.0);
    let blend_day = sun_above;
    let blend_overcast = w.cloud_cover;
    let clear_zenith = LinearRgba::new(
        night_zenith.red + (day_clear.red - night_zenith.red) * blend_day,
        night_zenith.green + (day_clear.green - night_zenith.green) * blend_day,
        night_zenith.blue + (day_clear.blue - night_zenith.blue) * blend_day,
        1.0,
    );
    env.sky_zenith_color.set_target(LinearRgba::new(
        clear_zenith.red + (day_overcast.red - clear_zenith.red) * blend_overcast,
        clear_zenith.green + (day_overcast.green - clear_zenith.green) * blend_overcast,
        clear_zenith.blue + (day_overcast.blue - clear_zenith.blue) * blend_overcast,
        1.0,
    ));

    // ── Wetness ───────────────────────────────────────────────────────────
    // Wetness builds with precipitation, drains slowly with low humidity.
    // Freezing temperatures suppress liquid wetness (snow, not wet).
    let liquid_factor = (w.temperature_c / 2.0).clamp(0.0, 1.0);
    let wet_target = (w.precipitation * 0.85 + w.humidity * 0.15) * liquid_factor;
    env.wetness.set_target(wet_target.clamp(0.0, 1.0));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sun_rises_in_east_at_dawn() {
        let config = EnvironmentConfig::default();
        let mut env = EnvironmentState::new(&config);
        let mut snap = SimSnapshot::default();
        snap.time.time_of_day = 0.25; // 6am
        resolve_targets(&snap, &config, &mut env);
        // At 6am in the northern hemisphere, sun is near east (negative azimuth or near PI/2)
        // Elevation should be near 0 (just rising)
        assert!(
            env.sun_elevation.target.abs() < 0.3,
            "Sun should be near horizon at dawn, got {}rad",
            env.sun_elevation.target
        );
    }

    #[test]
    fn fog_increases_with_precipitation() {
        let config = EnvironmentConfig::default();
        let mut env = EnvironmentState::new(&config);
        let mut snap = SimSnapshot::default();

        snap.weather.precipitation = 0.0;
        resolve_targets(&snap, &config, &mut env);
        let dry_density = env.fog_density.target;

        snap.weather.precipitation = 1.0;
        resolve_targets(&snap, &config, &mut env);
        let wet_density = env.fog_density.target;

        assert!(
            wet_density > dry_density,
            "Fog density should increase with precipitation: {} vs {}",
            wet_density,
            dry_density
        );
    }
}
