// crates/anvil_bevy/src/environment/plugin.rs
use bevy::light::GlobalAmbientLight;
use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

use super::config::EnvironmentConfig;
use super::state::EnvironmentState;
use super::solar::resolve_targets;
use crate::sim_bridge::SimSnapshot;
use crate::markers::{SunLight, CameraFog};

// ---------------------------------------------------------------------------
// SystemSet – guarantees Bridge → Interpolate → Apply ordering
// ---------------------------------------------------------------------------
/// Environment system ordering sets.
#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub enum EnvironmentSet {
    /// Bridge set where sim_bridge_system writes SimSnapshot (registered in anvil_demo).
    Bridge,
    /// Interpolate set where resolve_targets + state.tick() runs.
    Interpolate,
    /// Apply set where smoothed state is written to Bevy components (sun, fog, ambient).
    Apply,
}

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------
/// Plugin that manages environment interpolation and application.
///
/// This plugin:
/// - Inserts default EnvironmentConfig, EnvironmentState, and SimSnapshot resources
/// - Configures system ordering: Bridge → Interpolate → Apply
/// - Runs interpolation system (resolve_targets + tick)
/// - Runs apply system (writes to sun, fog, ambient)
pub struct EnvironmentPlugin;

impl Plugin for EnvironmentPlugin {
    fn build(&self, app: &mut App) {
        let config = EnvironmentConfig::default();
        app.insert_resource(EnvironmentState::new(&config))
           .insert_resource(config)
           .insert_resource(SimSnapshot::default())
           .configure_sets(
               PreUpdate,
               (
                   EnvironmentSet::Bridge,
                   EnvironmentSet::Interpolate,
                   EnvironmentSet::Apply,
               ).chain(),
           )
           .add_systems(
               PreUpdate,
               (
                   environment_interpolate_system.in_set(EnvironmentSet::Interpolate),
                   environment_apply_system.in_set(EnvironmentSet::Apply),
               ),
           );
    }
}

// ---------------------------------------------------------------------------
// System 1 — derive targets → tick smoothing
// ---------------------------------------------------------------------------
fn environment_interpolate_system(
    snapshot: Res<SimSnapshot>,
    config:   Res<EnvironmentConfig>,
    mut env:  ResMut<EnvironmentState>,
    time:     Res<Time>,
) {
    resolve_targets(&snapshot, &config, &mut env);
    env.tick(time.delta_secs());
}

// ---------------------------------------------------------------------------
// System 2 — push smoothed state into Bevy's lights and fog
// ---------------------------------------------------------------------------
fn environment_apply_system(
    env:          Res<EnvironmentState>,
    mut sun_q:    Query<(&mut DirectionalLight, &mut Transform), With<SunLight>>,
    mut fog_q:    Query<&mut DistanceFog, With<CameraFog>>,
    mut ambient:  ResMut<GlobalAmbientLight>,
) {
    // ── Sun ──────────────────────────────────────────────────────────
    match sun_q.single_mut() {
        Ok((mut light, mut transform)) => {
            light.color = Color::LinearRgba(env.sun_color.current);
            light.illuminance = env.sun_illuminance.current;
            let dir = env.sun_dir_vec();
            if dir.length_squared() > 0.001 {
                let up = if dir.y.abs() > 0.98 { Vec3::X } else { Vec3::Y };
                transform.look_to(dir, up);
            }
        }
        Err(_) => {
            warn_once!("EnvironmentPlugin: no SunLight entity found");
        }
    }

    // ── Fog ──────────────────────────────────────────────────────────
    match fog_q.single_mut() {
        Ok(mut fog) => {
            fog.color = Color::LinearRgba(env.fog_color.current);
            fog.falloff = FogFalloff::Exponential { density: env.fog_density.current };
        }
        Err(_) => {
            warn_once!("EnvironmentPlugin: no CameraFog entity found");
        }
    }

    // ── Ambient ──────────────────────────────────────────────────────
    ambient.color = Color::LinearRgba(env.ambient_color.current);
    ambient.brightness = env.ambient_brightness.current;
}


