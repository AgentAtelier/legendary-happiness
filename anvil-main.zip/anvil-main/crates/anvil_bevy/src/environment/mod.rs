//! Environment systems and configuration.
//!
//! This module provides environment-related types and systems for
//! atmosphere, weather, and lighting configuration.

/// Environment configuration types.
pub mod config;

/// Environment plugin and system sets.
pub mod plugin;

/// Solar math and target derivation.
pub mod solar;

/// Environment state types with smoothed interpolation.
pub mod state;

pub use config::*;
pub use plugin::*;
pub use solar::*;
pub use state::*;
