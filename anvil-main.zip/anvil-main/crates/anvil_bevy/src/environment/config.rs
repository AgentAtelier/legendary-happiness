//! Environment configuration types.
//!
//! This module provides configuration structs for the environment/atmosphere
//! systems, loaded from TOML configuration files.

use bevy::prelude::*;
use serde::{Deserialize, Serialize};

/// All tunable parameters for the environment system.
/// Loaded from assets/config/environment.toml at startup.
/// Re-loaded on hot-reload in dev builds.
#[derive(Resource, Clone, Debug, Deserialize, Serialize)]
pub struct EnvironmentConfig {
    /// Geographic location parameters.
    pub location: LocationConfig,
    /// Smoothing time constants for interpolated values.
    pub smoothing: SmoothingConfig,
    /// Illuminance and ambient lighting parameters.
    pub illuminance: IlluminanceConfig,
    /// Fog density and color parameters.
    pub fog: FogConfig,
    /// Sky sphere rendering parameters.
    pub sky: SkyConfig,
}

/// Geographic location configuration.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct LocationConfig {
    /// Geographic latitude of Ashveil valley in degrees.
    pub latitude_deg: f32,
    /// Axial tilt contribution (seasonal declination), degrees. 0 = equinox.
    pub declination_deg: f32,
}

/// Smoothing time constants for interpolated values.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SmoothingConfig {
    /// Smoothing time constant for sun position in seconds.
    pub sun_position_tau: f32,
    /// Smoothing time constant for sun colour in seconds.
    pub sun_colour_tau: f32,
    /// Smoothing time constant for fog density in seconds.
    pub fog_density_tau: f32,
    /// Smoothing time constant for fog colour in seconds.
    pub fog_colour_tau: f32,
    /// Smoothing time constant for ambient lighting in seconds.
    pub ambient_tau: f32,
    /// Smoothing time constant for wetness in seconds.
    pub wetness_tau: f32,
}

/// Illuminance and ambient lighting configuration.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct IlluminanceConfig {
    /// Peak clear-sky noon illuminance in lux.
    pub noon_clear_lux: f32,
    /// Illuminance at full cloud cover (relative to clear noon).
    pub overcast_factor: f32,
    /// Minimum night illuminance (moonlight).
    pub night_min_lux: f32,
    /// Ambient strength at solar noon, clear sky.
    pub ambient_noon: f32,
    /// Ambient strength at night.
    pub ambient_night: f32,
}

/// Fog density and color configuration.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct FogConfig {
    /// Base density at zero humidity, zero precipitation.
    pub base_density: f32,
    /// Additional density per unit of humidity (0-1).
    pub humidity_density_scale: f32,
    /// Additional density per unit of precipitation (0-1).
    pub precip_density_scale: f32,
    /// Additional density per degree below this temperature (cold ground fog).
    pub cold_fog_threshold_c: f32,
    /// Scale factor for cold fog contribution.
    pub cold_fog_scale: f32,
    /// Maximum fog density before the scene is unplayable.
    pub max_density: f32,
}

/// Sky sphere rendering configuration.
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SkyConfig {
    /// Radius of the sky sphere in world units.
    pub sphere_radius: f32,
    /// Angular radius of the sun disc in the sky shader, 0-1.
    pub sun_disc_size: f32,
    /// Bloom multiplier applied to the sun disc colour.
    pub sun_disc_intensity: f32,
}

impl Default for EnvironmentConfig {
    fn default() -> Self {
        Self {
            location: LocationConfig {
                latitude_deg: 55.0,
                declination_deg: 0.0,
            },
            smoothing: SmoothingConfig {
                sun_position_tau: 300.0,
                sun_colour_tau: 60.0,
                fog_density_tau: 30.0,
                fog_colour_tau: 60.0,
                ambient_tau: 30.0,
                wetness_tau: 45.0,
            },
            illuminance: IlluminanceConfig {
                noon_clear_lux: 80_000.0,
                overcast_factor: 0.10,
                night_min_lux: 0.1,
                ambient_noon: 0.20,
                ambient_night: 0.04,
            },
            fog: FogConfig {
                base_density: 0.003,
                humidity_density_scale: 0.025,
                precip_density_scale: 0.018,
                cold_fog_threshold_c: 5.0,
                cold_fog_scale: 0.003,
                max_density: 0.08,
            },
            sky: SkyConfig {
                sphere_radius: 4500.0,
                sun_disc_size: 0.003,
                sun_disc_intensity: 3.0,
            },
        }
    }
}
