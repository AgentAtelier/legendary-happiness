//! Environment state types with smoothed interpolation.

use bevy::color::LinearRgba;
use bevy::prelude::*;

use crate::environment::config::EnvironmentConfig;

/// A float value that smoothly interpolates toward a target using exponential smoothing.
#[derive(Clone, Debug)]
pub struct SmoothedFloat {
    /// The current interpolated value.
    pub current: f32,
    /// The target value being interpolated toward.
    pub target: f32,
    /// Time constant in seconds. Higher = slower response.
    pub tau: f32,
}

impl SmoothedFloat {
    /// Creates a new smoothed float with the given initial value and time constant.
    pub fn new(value: f32, tau: f32) -> Self {
        Self {
            current: value,
            target: value,
            tau,
        }
    }

    /// Sets the target value for interpolation.
    pub fn set_target(&mut self, value: f32) {
        self.target = value;
    }

    /// Advances the interpolation by delta seconds.
    pub fn tick(&mut self, delta: f32) {
        if self.tau <= 0.0 {
            self.current = self.target;
            return;
        }
        // Exponential smoothing: current = current + (target - current) * (1 - exp(-delta / tau))
        let alpha = 1.0 - (-delta / self.tau).exp();
        self.current = self.current + (self.target - self.current) * alpha;
    }
}

/// A colour value that smoothly interpolates toward a target using exponential smoothing.
#[derive(Clone, Debug)]
pub struct SmoothedColor {
    /// The current interpolated color.
    pub current: LinearRgba,
    /// The target color being interpolated toward.
    pub target: LinearRgba,
    /// Time constant in seconds. Higher = slower response.
    pub tau: f32,
}

impl SmoothedColor {
    /// Creates a new smoothed color with the given initial value and time constant.
    pub fn new(value: LinearRgba, tau: f32) -> Self {
        Self {
            current: value,
            target: value,
            tau,
        }
    }

    /// Sets the target color for interpolation.
    pub fn set_target(&mut self, value: LinearRgba) {
        self.target = value;
    }

    /// Advances the interpolation by delta seconds.
    pub fn tick(&mut self, delta: f32) {
        if self.tau <= 0.0 {
            self.current = self.target;
            return;
        }
        let alpha = 1.0 - (-delta / self.tau).exp();
        self.current = LinearRgba {
            red: self.current.red + (self.target.red - self.current.red) * alpha,
            green: self.current.green + (self.target.green - self.current.green) * alpha,
            blue: self.current.blue + (self.target.blue - self.current.blue) * alpha,
            alpha: self.current.alpha + (self.target.alpha - self.current.alpha) * alpha,
        };
    }
}

/// Environment state that drives all visual targets.
///
/// This struct holds all the interpolated values that control the visual appearance
/// of the environment (sun position, fog, lighting, etc.).
#[derive(Clone, Debug)]
pub struct EnvironmentState {
    /// Sun elevation angle above the horizon in radians.
    pub sun_elevation: SmoothedFloat,
    /// Sun azimuth angle (0 = east, increasing counterclockwise).
    pub sun_azimuth: SmoothedFloat,
    /// Sun color in linear RGB.
    pub sun_color: SmoothedColor,
    /// Sun illuminance in lux.
    pub sun_illuminance: SmoothedFloat,
    /// Ambient light color in linear RGB.
    pub ambient_color: SmoothedColor,
    /// Ambient light brightness multiplier.
    pub ambient_brightness: SmoothedFloat,
    /// Fog color in linear RGB.
    pub fog_color: SmoothedColor,
    /// Fog density.
    pub fog_density: SmoothedFloat,
    /// Sky zenith color in linear RGB.
    pub sky_zenith_color: SmoothedColor,
    /// Surface wetness factor (0.0 = dry, 1.0 = saturated).
    pub wetness: SmoothedFloat,
    /// Cached from config so update_sky_uniforms can read it.
    pub sun_disc_base_intensity: f32,
}

impl EnvironmentState {
    /// Creates a new environment state initialized with Ashveil dawn values.
    pub fn new(config: &EnvironmentConfig) -> Self {
        let s = &config.smoothing;
        // Ashveil dawn starting values.
        let dawn_fog = LinearRgba::new(0.50, 0.40, 0.35, 1.0);
        let dawn_sky = LinearRgba::new(0.18, 0.15, 0.28, 1.0);
        let dawn_sun = LinearRgba::new(1.0, 0.70, 0.40, 1.0);
        let dawn_ambient = LinearRgba::new(0.30, 0.28, 0.40, 1.0);

        Self {
            sun_elevation: SmoothedFloat::new(0.08, s.sun_position_tau),
            sun_azimuth: SmoothedFloat::new(-1.57, s.sun_position_tau),
            sun_color: SmoothedColor::new(dawn_sun, s.sun_colour_tau),
            sun_illuminance: SmoothedFloat::new(4000.0, 30.0),
            ambient_color: SmoothedColor::new(dawn_ambient, s.ambient_tau),
            ambient_brightness: SmoothedFloat::new(0.12, s.ambient_tau),
            fog_color: SmoothedColor::new(dawn_fog, s.fog_colour_tau),
            fog_density: SmoothedFloat::new(0.018, s.fog_density_tau),
            sky_zenith_color: SmoothedColor::new(dawn_sky, s.sun_colour_tau),
            wetness: SmoothedFloat::new(0.0, s.wetness_tau),
            sun_disc_base_intensity: config.sky.sun_disc_intensity,
        }
    }

    /// Advances all smoothed values by delta seconds.
    pub fn tick(&mut self, delta: f32) {
        self.sun_elevation.tick(delta);
        self.sun_azimuth.tick(delta);
        self.sun_color.tick(delta);
        self.sun_illuminance.tick(delta);
        self.ambient_color.tick(delta);
        self.ambient_brightness.tick(delta);
        self.fog_color.tick(delta);
        self.fog_density.tick(delta);
        self.sky_zenith_color.tick(delta);
        self.wetness.tick(delta);
    }

    /// Returns the sun direction as a normalized world-space vector.
    ///
    /// Elevation is the angle above the horizon, azimuth is the rotation around the vertical axis.
    /// Uses a right-handed coordinate system with Y up, X east, and Z north.
    pub fn sun_dir_vec(&self) -> Vec3 {
        let elevation = self.sun_elevation.current;
        let azimuth = self.sun_azimuth.current;
        // Convert spherical to cartesian:
        // x = cos(elevation) * cos(azimuth)
        // y = sin(elevation)
        // z = cos(elevation) * sin(azimuth)
        let cos_elev = elevation.cos();
        Vec3::new(
            cos_elev * azimuth.cos(),
            elevation.sin(),
            cos_elev * azimuth.sin(),
        ).normalize()
    }
}

impl Resource for EnvironmentState {}
