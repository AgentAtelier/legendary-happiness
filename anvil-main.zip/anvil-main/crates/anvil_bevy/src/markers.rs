//! Marker components for entity identification.
//!
//! This module provides marker components used to identify specific entity types
//! in the scene for targeted system queries.

use bevy::prelude::*;

/// Marker component for the main directional light (sun).
#[derive(Component)]
pub struct SunLight;

/// Marker component for the main camera that receives fog.
#[derive(Component)]
pub struct CameraFog;

/// Marker component for terrain chunk entities.
#[derive(Component)]
pub struct TerrainChunk;

/// Marker component for the sky sphere entity.
#[derive(Component)]
pub struct SkySphere;
