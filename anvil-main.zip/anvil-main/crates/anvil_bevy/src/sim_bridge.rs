//! Simulation bridge types for presentation layer.
//!
//! This module provides snapshot types that carry simulation state from the
//! deterministic sim crates to the Bevy presentation layer.

use bevy::prelude::*;

/// Presentation-side view of simulation state. Populated once per frame
/// by the bridge system in anvil_demo. Never written to by visual systems.
#[derive(Resource, Clone, Debug, Default)]
pub struct SimSnapshot {
    /// The simulation tick number.
    pub tick: u64,
    /// Time-related state.
    pub time: TimeSnapshot,
    /// Weather state.
    pub weather: WeatherSnapshot,
    /// Per-catastrophe visual descriptors. Empty when no catastrophe is active.
    pub catastrophes: Vec<CatastropheSnapshot>,
}

/// Time-related simulation state.
#[derive(Clone, Debug, Default)]
pub struct TimeSnapshot {
    /// 0.0 = midnight, 0.25 ≈ 6am, 0.5 = noon, 0.75 ≈ 6pm
    pub time_of_day: f32,
    /// The current day number.
    pub day: u32,
}

/// Weather state snapshot.
#[derive(Clone, Debug)]
pub struct WeatherSnapshot {
    /// Temperature in degrees Celsius.
    pub temperature_c: f32,
    /// Relative humidity (0.0-1.0).
    pub humidity: f32,
    /// Wind speed in meters per second.
    pub wind_speed_ms: f32,
    /// Wind direction in radians (0 = east).
    pub wind_direction: f32,
    /// Precipitation intensity (0.0-1.0).
    pub precipitation: f32,
    /// Cloud cover fraction (0.0-1.0).
    pub cloud_cover: f32,
    /// Atmospheric pressure in hectopascals.
    pub pressure_hpa: f32,
}

impl Default for WeatherSnapshot {
    fn default() -> Self {
        // Ashveil dawn defaults: cold, low humidity, no precipitation
        Self {
            temperature_c: 6.4,
            humidity: 0.31,
            wind_speed_ms: 4.2,
            wind_direction: 0.0,
            precipitation: 0.0,
            cloud_cover: 0.25,
            pressure_hpa: 1008.0,
        }
    }
}

/// A snapshot of an active catastrophe.
#[derive(Clone, Debug)]
pub struct CatastropheSnapshot {
    /// Unique identifier for this catastrophe instance.
    pub id: u64,
    /// The type of catastrophe.
    pub kind: CatastropheKind,
    /// The origin position of the catastrophe in world space.
    pub origin: Vec3,
    /// The intensity of the catastrophe (0.0-1.0).
    pub intensity: f32,
    /// Stable seed: derived at catastrophe onset, unchanged for its lifetime.
    /// Used to seed bevy_hanabi emitters and stochastic audio selection.
    pub vfx_seed: u64,
}

/// The kind of catastrophe.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CatastropheKind {
    /// Fire spreading through flammable terrain.
    Wildfire,
    /// Water-based damage affecting low-lying areas.
    Flood,
    /// Ground shaking affecting structures.
    Earthquake,
}
