//! Output stage — stinger playback, master volume application.
//!
//! This module is the bottom of the audio pipeline. By the time a sound
//! reaches here, the mood reader has decided what the mix should be, the
//! stems have crossfaded, the zones have positioned, the cues have
//! resolved into stinger plays, and the ducking system has applied its
//! multiplier. The output stage's job is to actually produce the
//! `AudioPlayer` entities for stingers and to make sure nothing leaves
//! the audio system clipped or DC-biased.
//!
//! **Sample-rate request.** Bevy 0.18's `bevy_audio` defers sample-rate
//! decisions to the OS audio backend, which in PipeWire/ALSA terms
//! usually means whatever the system's default is. We do not currently
//! attempt to force a specific rate at the device level — that would
//! require touching `cpal` directly, which is out of scope. Instead,
//! the deterministic-mix promise is: the mix decisions (which stems at
//! what volume, when stingers fire) are bit-deterministic. The speaker
//! output may drift by up to one buffer period (~10 ms) because of OS
//! buffer sizing. See `ANVIL_AUDIO.md` §determinism for the full
//! contract.

use bevy::audio::{AudioPlayer, PlaybackSettings, Volume};
use bevy::prelude::*;
use super::cue_queue::StingerQueue;
use super::director::AudioDirector;

/// System: receive `PlayStinger` events, spawn one-shot `AudioPlayer`
/// entities for each, with master volume applied.
///
/// Stingers despawn themselves via `PlaybackSettings::DESPAWN` once their
/// audio finishes playing. They are *not* tracked in any registry; they
/// are intentionally fire-and-forget. The same handle can be triggered
/// rapidly without entity-leak risk because each play gets its own
/// entity with its own auto-despawn.
pub fn play_stingers(
    mut commands: Commands,
    mut stinger_queue: ResMut<StingerQueue>,
    director: Res<AudioDirector>,
) {
    let master = director.master_volume;
    if master <= 0.0 || director.muted {
        // Drain the stingers even when muted so they don't pile up if the
        // player unmutes later. Stingers are temporal — replaying a
        // 30-second backlog of stingers after unmute would be terrible.
        stinger_queue.drain().for_each(|_| {});
        return;
    }
    for stinger in stinger_queue.drain() {
        let final_volume = (stinger.volume * master).clamp(0.0, 1.0);
        if final_volume <= 0.0 {
            continue;
        }
        commands.spawn((
            AudioPlayer::new(stinger.handle.clone()),
            PlaybackSettings::DESPAWN.with_volume(Volume::Linear(final_volume)),
        ));
    }
}

#[cfg(test)]
mod tests {
    #[allow(unused_imports)]
    use super::*;

    #[test]
    fn module_compiles() {
        // Smoke test — the systems above need a Bevy `App` to exercise
        // properly; the cue_dispatch and determinism integration tests
        // do that work. Here we just confirm the module is wired.
    }
}
