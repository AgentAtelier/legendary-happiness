//! Ducking — temporarily lower stems when a stinger fires.
//!
//! When a [`PlayStinger`] event arrives with `duck_stems = true`, the
//! ducking system reduces every stem's effective volume by a fixed dB
//! amount (~6 dB) and lets it recover over a short window (~500 ms). This
//! makes one-shot events cut through the mix without raising the master
//! gain.
//!
//! Implementation note: ducking applies *after* the per-stem mood curve
//! but *before* the master volume. It writes a multiplier to a small
//! shared resource that `update_stems`'s output stage multiplies into the
//! final value. Keeping it stateful (decay-over-time) on its own
//! resource means ducking is observable and testable in isolation.

use bevy::prelude::*;
use super::cue_queue::StingerQueue;

/// Per-frame ducking multiplier applied to all stems.
///
/// Range: `[0.0, 1.0]`. At rest it's `1.0` (no ducking). When a stinger
/// fires with `duck_stems = true`, this snaps down to [`DUCK_DEPTH`] and
/// recovers linearly toward `1.0` over [`DUCK_RECOVERY_SECS`].
#[derive(Resource, Debug, Clone, Copy)]
pub struct DuckingState {
    multiplier: f32,
}

impl DuckingState {
    pub fn multiplier(&self) -> f32 {
        self.multiplier
    }
}

impl Default for DuckingState {
    fn default() -> Self {
        Self { multiplier: 1.0 }
    }
}

/// How deep the duck goes. `0.5` ≈ -6 dB. Hard-coded constant; if you want
/// per-stinger ducking depth, extend `PlayStinger` with a `duck_depth`
/// field and read it here.
const DUCK_DEPTH: f32 = 0.5;

/// How long ducking takes to recover, in seconds.
const DUCK_RECOVERY_SECS: f32 = 0.5;

/// System: react to `PlayStinger` events and decay the duck multiplier.
///
/// Runs every frame regardless of whether stingers fired, so the decay
/// is smooth even on frames with no events. Listens to events, not state,
/// so stinger sources don't need to know ducking exists.
pub fn update_ducking(
    mut ducking: ResMut<DuckingState>,
    stinger_queue: Res<StingerQueue>,
    time: Res<Time>,
) {
    // Process incoming stingers. If any duck-flagged stinger fires this
    // frame, snap the multiplier down.
    for stinger in stinger_queue.events.iter() {
        if stinger.duck_stems {
            ducking.multiplier = ducking.multiplier.min(DUCK_DEPTH);
        }
    }

    // Linear recovery toward 1.0.
    if ducking.multiplier < 1.0 {
        let recovery_rate = (1.0 - DUCK_DEPTH) / DUCK_RECOVERY_SECS;
        ducking.multiplier = (ducking.multiplier + recovery_rate * time.delta_secs()).min(1.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_is_unducked() {
        let d = DuckingState::default();
        assert_eq!(d.multiplier(), 1.0);
    }

    #[test]
    fn duck_constant_is_in_range() {
        assert!((0.0..1.0).contains(&DUCK_DEPTH));
        assert!(DUCK_RECOVERY_SECS > 0.0);
    }
}
