//! `AudioDirector` — the central state resource for the audio system.
//!
//! Every audio subsystem reads from `AudioDirector`. The `MoodReader` system
//! writes to it once per frame, deriving mood from simulation state. This is
//! the **only** path by which simulation state reaches audio: subsystems
//! that need weather, time, or mood data go through the director, never
//! through the simulation directly.
//!
//! The boundary matters. Audio subsystems must be readable in isolation;
//! they cannot drift across game versions because the simulation evolves
//! while the audio's contract with the director stays stable. The director
//! is the audio system's API to the simulation, not the simulation's API
//! to audio.

use bevy::prelude::*;

/// Central audio state. Read by every subsystem; written by [`MoodReader`].
///
/// One source of truth for "what is happening, audibly, right now."
#[derive(Resource, Debug, Clone, Default)]
pub struct AudioDirector {
    /// Aggregate village mood, weighted by social-graph centrality.
    /// Range: `[-1.0, 1.0]`. Negative is fear/grief; positive is calm/joy.
    pub village_mood: f32,

    /// Catastrophe state machine. Derived from `CatastropheSystem::active_events`
    /// and recent precursor activity.
    pub catastrophe_phase: CatastrophePhase,

    /// Time-of-day phase. Derived from `GameTime::hour_of_day()`.
    pub time_phase: TimePhase,

    /// Weather mood. A compressed summary of humidity, temperature, and
    /// precipitation.
    pub weather_mood: WeatherMood,

    /// Player's somatic state. Drives heartbeat, breath, vignette audio.
    /// `None` if the player NPC hasn't been resolved yet (early startup).
    pub body_state: Option<BodyState>,

    /// Effective master volume, after honouring `AudioOptions::muted`.
    /// Multiplied into every per-stem volume by the output stage.
    pub master_volume: f32,

    /// Convenience: are we audibly muted (master_volume == 0.0 or muted set)?
    pub muted: bool,
}

/// Catastrophe state machine, derived from sim state by `MoodReader`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum CatastrophePhase {
    /// No active threat. Default state.
    #[default]
    None,
    /// Precursor signals are firing; no event has triggered yet.
    Precursor,
    /// Trigger predicate is about to fire. Brief; <30 seconds of game time.
    Imminent,
    /// A catastrophe is in progress. Magnitude is non-zero and rising.
    Active,
    /// Magnitude is decaying. Rain has begun, or fire is suppressing.
    Suppressing,
    /// Catastrophe resolved; village in recovery.
    Aftermath,
}

/// Time-of-day phase. Six bands derived from `GameTime::hour_of_day()`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum TimePhase {
    /// 05:00–07:00. Cold, blue, sparse.
    #[default]
    Dawn,
    /// 07:00–11:00. Warming, active.
    Morning,
    /// 11:00–14:00. Peak activity.
    Midday,
    /// 14:00–18:00. Light slowing.
    Afternoon,
    /// 18:00–21:00. Cooling, settling.
    Dusk,
    /// 21:00–05:00. Quiet, sparse.
    Night,
}

/// Weather mood — a compressed summary of the live weather state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum WeatherMood {
    /// Low humidity, low wind, no precipitation.
    #[default]
    Clear,
    /// High humidity, gusty wind. No rain yet but the air is heavy.
    Heavy,
    /// Active precipitation.
    Wet,
    /// Pre-catastrophe conditions: humidity dropping, wind rising,
    /// temperature climbing into fire territory.
    Threatening,
}

/// Player's somatic body state. Drives heartbeat, breath, vignette audio.
/// Updated by Phase 3's `BodyState` aggregator — for now the audio system
/// only needs the threat axis and sprint state.
#[derive(Debug, Clone, Copy)]
pub struct BodyState {
    /// `security_threat` axis: -1.0 (safe) to +1.0 (terrified).
    pub security_threat: f32,
    /// `agency_helplessness` axis: -1.0 (in control) to +1.0 (frozen).
    pub agency_helplessness: f32,
    /// True if the player has sprinted within the last ~5 seconds.
    pub recently_sprinted: bool,
    /// Ambient temperature in °C, for breath visibility/audibility.
    pub temperature_c: f32,
}

/// System: derive `AudioDirector` state from the simulation each frame.
///
/// **Read-only on simulation crates.** This system is the audio module's
/// only window into the simulation; no other audio system reads
/// `RuntimeResource` directly. If you find yourself reaching for the
/// runtime in another audio file, it belongs here.
///
/// Performance: O(NPC count) for mood aggregation; called once per frame.
/// Cost is dominated by NPC iteration, which is bounded by the village
/// size. For Ashveil (8 NPCs) this is trivial.
pub fn update_director(
    // The runtime resource lives in `anvil_demo`; we receive its data
    // through an adapter trait so this crate doesn't depend on the demo.
    // For now, this system is stub-able: tests can write `AudioDirector`
    // directly. Real wiring happens in the demo's `ashveil.rs` shim.
    mut director: ResMut<AudioDirector>,
    audio_options: Option<Res<AudioOptionsRead>>,
) {
    // Master volume is the only piece of state every director.update needs
    // to refresh, regardless of source. Sim-driven fields are written by
    // the demo-side bridge system (see `anvil_demo::audio::ashveil`).
    if let Some(opts) = audio_options {
        director.muted = opts.muted;
        director.master_volume = if opts.muted { 0.0 } else { opts.master_volume };
    } else {
        // No options resource — fall back to audible default.
        director.muted = false;
        director.master_volume = 1.0;
    }
}

/// Read-only view of the demo's `AudioOptions`. The demo inserts this as a
/// resource each frame; the audio system reads it. We don't depend on
/// `anvil_demo`'s `AudioOptions` type directly because that would invert
/// the crate dependency.
#[derive(Resource, Debug, Clone, Copy)]
pub struct AudioOptionsRead {
    pub muted: bool,
    pub master_volume: f32,
}

impl Default for AudioOptionsRead {
    fn default() -> Self {
        Self { muted: false, master_volume: 1.0 }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn director_defaults_are_safe() {
        let d = AudioDirector::default();
        assert_eq!(d.village_mood, 0.0);
        assert_eq!(d.catastrophe_phase, CatastrophePhase::None);
        assert_eq!(d.time_phase, TimePhase::Dawn);
        assert_eq!(d.weather_mood, WeatherMood::Clear);
        assert!(d.body_state.is_none());
        assert!(!d.muted);
    }

    #[test]
    fn muted_options_zero_volume() {
        let mut director = AudioDirector::default();
        director.master_volume = 1.0;
        let opts = AudioOptionsRead { muted: true, master_volume: 0.8 };
        // Simulate update_director's logic
        director.muted = opts.muted;
        director.master_volume = if opts.muted { 0.0 } else { opts.master_volume };
        assert_eq!(director.master_volume, 0.0);
        assert!(director.muted);
    }
}
