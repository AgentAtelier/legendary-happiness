#![allow(missing_docs)]

use bevy::prelude::*;
use super::cues::{Cue, PlayStinger};

/// Queue of cues emitted by the simulation this frame.
#[derive(Resource, Default)]
pub struct CueQueue {
    /// The queued cue events.
    pub events: Vec<Cue>,
}

impl CueQueue {
    /// Push a cue into the queue.
    pub fn send(&mut self, cue: Cue) {
        self.events.push(cue);
    }

    /// Drain all queued cues and return an iterator.
    pub fn drain(&mut self) -> impl Iterator<Item = Cue> + '_ {
        self.events.drain(..)
    }
}

/// Queue of stinger play requests produced by cue dispatch.
#[derive(Resource, Default)]
pub struct StingerQueue {
    /// The queued stinger play requests.
    pub events: Vec<PlayStinger>,
}

impl StingerQueue {
    /// Push a stinger into the queue.
    pub fn send(&mut self, stinger: PlayStinger) {
        self.events.push(stinger);
    }

    /// Drain all queued stingers and return an iterator.
    pub fn drain(&mut self) -> impl Iterator<Item = PlayStinger> + '_ {
        self.events.drain(..)
    }
}
