//! Cues — the audio system's communication channel.
//!
//! A [`Cue`] is a discrete event the simulation announces to the audio
//! system. Cues are consumed via Bevy's `EventReader`, never polled;
//! emitters fire them from the simulation side; subscribers in this crate
//! map them to stinger playback, ducking pulses, and other one-shot
//! responses.
//!
//! This is the load-bearing piece of Q4c (diegetic-leaning, sound as HUD
//! substitute). When the simulation needs to tell the player something —
//! a precursor signal, a threat shift, a community resilience moment — it
//! emits a cue. The player learns to read the audio responses to cues the
//! way they would read a HUD.
//!
//! **No polling.** Reviewers: do not introduce per-frame inspection of
//! simulation state to derive stinger triggers. Cue → stinger goes through
//! events; if the simulation can't yet emit a particular cue, fix the sim
//! side, don't poll for the condition here.

use bevy::prelude::*;
use super::cue_queue::{CueQueue, StingerQueue};

/// Top-level audio cue enum. Wraps the three categories of discrete
/// communication the simulation can issue.
#[derive(Event, Debug, Clone)]
pub enum Cue {
    Emotional(EmotionalCue),
    Environmental(EnvironmentalCue),
    Narrative(NarrativeCue),
}

/// Emotional state shifts in the player or a focal NPC.
///
/// Phase 3's somatic body system will subscribe to these to drive
/// heartbeat, breath cadence, peripheral vignette. For now they are
/// declared but largely unconsumed; the contract is in place.
#[derive(Debug, Clone)]
pub enum EmotionalCue {
    /// Player's `security_threat` axis crossed a threshold upward.
    ThreatRising { magnitude: f32 },
    /// Player's `security_threat` axis returned to baseline.
    ThreatResolving,
    /// Strong positive affect: joy catalyst, community moment.
    JoyPulse { intensity: f32 },
    /// Strong negative affect: grief, loss, isolation.
    GriefPulse { intensity: f32 },
}

/// World-level environmental changes.
#[derive(Debug, Clone)]
pub enum EnvironmentalCue {
    /// A precursor signal has reached perceptible intensity for a nearby NPC
    /// (or the player NPC). `kind` identifies the catastrophe class; the
    /// audio responds with an appropriate low-amplitude bed shift.
    PrecursorSignal {
        kind: PrecursorKind,
        intensity: f32,
        position: Vec3,
    },
    /// A catastrophe has ignited. This is the loud event: the audio
    /// system should respond with its biggest authored stinger.
    CatastropheIgnition {
        kind: CatastropheKind,
        epicentre: Vec3,
    },
    /// Weather phase transitioned. Drives rain-start sound, wind ramp.
    WeatherTransition {
        from: WeatherPhaseLabel,
        to: WeatherPhaseLabel,
    },
    /// A nearby physical impact (debris falling, building collapse).
    DebrisImpact { position: Vec3, magnitude: f32 },
}

/// Narrative-arc events from the demo sequencer or main game.
#[derive(Debug, Clone)]
pub enum NarrativeCue {
    /// A scripted beat has triggered. The `tag` is opaque to the audio
    /// system; the demo's stinger map decides which sample to play.
    Beat { tag: &'static str },
    /// `JoySystem::CatalystEvent::CommunityResilience` or equivalent.
    CommunityResilience,
}

/// Catastrophe sub-types. Mirrors the sim's enum but kept independent so
/// the audio system doesn't depend on sim types. Update this enum when
/// new catastrophe kinds land; the demo's cue→stinger table will catch
/// missing arms via exhaustive matching.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CatastropheKind {
    Wildfire,
    Flood,
    Blizzard,
    Drought,
    Earthquake,
}

/// Precursor sub-types. Same independence rationale.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PrecursorKind {
    SmokeOnHorizon,
    FallingPressure,
    RisingWind,
    SilencingBirds,
    DryLightning,
}

/// Weather phase label.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WeatherPhaseLabel {
    Clear,
    Clouding,
    Raining,
    Clearing,
}

/// System that consumes `Cue` events and produces stinger play requests.
///
/// Stinger mapping is a *data* concern, owned by the demo's `ashveil.rs`
/// configuration (or the main game's equivalent). This system reads the
/// [`StingerMap`] resource, looks up the matched cue, and emits a
/// `PlayStinger` event for the output stage to handle.
///
/// Cues that have no entry in the stinger map are silently ignored — that
/// is the correct behaviour, not an error. Many cues will only ever drive
/// vignette/heartbeat/breath via Phase 3 somatic subscribers, never a
/// stinger.
pub fn dispatch_cues(
    mut cue_queue: ResMut<CueQueue>,
    stinger_map: Option<Res<StingerMap>>,
    mut stinger_queue: ResMut<StingerQueue>,
) {
    let Some(map) = stinger_map else {
        // No stinger map registered yet. Drain the cues so we don't
        // accumulate stale events.
        cue_queue.drain().for_each(|_| {});
        return;
    };
    for cue in cue_queue.drain() {
        if let Some(stinger) = map.resolve(&cue) {
            stinger_queue.send(stinger);
        }
    }
}

/// Stinger-map adapter trait. The demo's `ashveil.rs` (or the main game)
/// inserts a concrete implementation as a `Res<StingerMap>`. This crate
/// owns no policy about which sample plays for which cue.
#[derive(Resource)]
pub struct StingerMap {
    /// The resolver function. Stored as a trait object so each project
    /// can supply its own mapping without touching this crate.
    pub resolver: Box<dyn StingerResolver + Send + Sync>,
}

impl StingerMap {
    pub fn new<R: StingerResolver + Send + Sync + 'static>(resolver: R) -> Self {
        Self { resolver: Box::new(resolver) }
    }
    pub fn resolve(&self, cue: &Cue) -> Option<PlayStinger> {
        self.resolver.resolve(cue)
    }
}

/// Trait the demo (or main game) implements to map cues to stinger plays.
pub trait StingerResolver {
    fn resolve(&self, cue: &Cue) -> Option<PlayStinger>;
}

/// Event emitted by `dispatch_cues` and consumed by the output stage.
/// Carries the audio handle and a target volume.
#[derive(Event, Debug, Clone)]
pub struct PlayStinger {
    pub handle: Handle<bevy::audio::AudioSource>,
    pub volume: f32,
    /// Causes the ducking system to dip the stems briefly. Set to `false`
    /// for incidental stingers that should sit *under* the music.
    pub duck_stems: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    struct NoopResolver;
    impl StingerResolver for NoopResolver {
        fn resolve(&self, _cue: &Cue) -> Option<PlayStinger> {
            None
        }
    }

    #[test]
    fn stinger_map_constructs() {
        let map = StingerMap::new(NoopResolver);
        let cue = Cue::Environmental(EnvironmentalCue::DebrisImpact {
            position: Vec3::ZERO,
            magnitude: 1.0,
        });
        assert!(map.resolve(&cue).is_none());
    }
}
