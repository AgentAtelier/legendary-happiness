//! Score — the reactive composition layer.
//!
//! Stems are the *units* of composition; the score is the *policy*. This
//! module reads the [`AudioDirector`] state and constructs the per-stem
//! target volumes that the [`StemRegistry`]'s `update_stems` system
//! consumes via each stem's `MoodCurve`.
//!
//! In the current architecture, the `MoodCurve` *is* the policy: each
//! stem owns a function from director state to target volume. This
//! module's role is to provide reusable helpers for writing those
//! functions, and to host the deferred work — the actual artistic curves
//! must be tuned with the audio playing, not designed in the abstract,
//! so the placeholders below are intentionally simple and marked as
//! [`TUNE`].
//!
//! [`TUNE`]: # tuning-the-score

use super::director::{AudioDirector, CatastrophePhase, TimePhase, WeatherMood};

/// Curve helper: linear ramp on village mood. Returns the mood mapped
/// from `[-1, 1]` to `[0, 1]`, clipped.
pub fn ramp_on_village_mood(director: &AudioDirector) -> f32 {
    ((director.village_mood + 1.0) * 0.5).clamp(0.0, 1.0)
}

/// Curve helper: stem is fully audible during a specific catastrophe
/// phase, silent otherwise. Useful for stems that mark one phase.
pub fn during_phase(phase: CatastrophePhase) -> impl Fn(&AudioDirector) -> f32 {
    move |d| if d.catastrophe_phase == phase { 1.0 } else { 0.0 }
}

/// Curve helper: stem ramps up during precursor, peaks during active,
/// fades during aftermath. The canonical "catastrophe score" shape.
pub fn catastrophe_arc(director: &AudioDirector) -> f32 {
    match director.catastrophe_phase {
        CatastrophePhase::None => 0.0,
        CatastrophePhase::Precursor => 0.15,
        CatastrophePhase::Imminent => 0.45,
        CatastrophePhase::Active => 1.0,
        CatastrophePhase::Suppressing => 0.6,
        CatastrophePhase::Aftermath => 0.25,
    }
}

/// Curve helper: stem is louder at dawn and dusk, quieter midday/night.
/// Useful for "transition" stems that mark passage of time.
pub fn dawn_dusk_emphasis(director: &AudioDirector) -> f32 {
    match director.time_phase {
        TimePhase::Dawn | TimePhase::Dusk => 1.0,
        TimePhase::Morning | TimePhase::Afternoon => 0.5,
        TimePhase::Midday | TimePhase::Night => 0.2,
    }
}

/// Curve helper: stem rises with weather threat.
pub fn weather_threat(director: &AudioDirector) -> f32 {
    match director.weather_mood {
        WeatherMood::Clear => 0.0,
        WeatherMood::Heavy => 0.5,
        WeatherMood::Threatening => 0.85,
        WeatherMood::Wet => 0.3,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::audio::director::AudioDirector;

    #[test]
    fn ramp_zero_at_min_mood() {
        let mut d = AudioDirector::default();
        d.village_mood = -1.0;
        assert!((ramp_on_village_mood(&d) - 0.0).abs() < 1e-6);
    }

    #[test]
    fn ramp_one_at_max_mood() {
        let mut d = AudioDirector::default();
        d.village_mood = 1.0;
        assert!((ramp_on_village_mood(&d) - 1.0).abs() < 1e-6);
    }

    #[test]
    fn catastrophe_arc_is_monotone_through_phases() {
        // The arc should peak at Active and decline; not strictly
        // monotone, but a meaningful shape.
        let mut d = AudioDirector::default();
        d.catastrophe_phase = CatastrophePhase::None;
        let none = catastrophe_arc(&d);
        d.catastrophe_phase = CatastrophePhase::Active;
        let active = catastrophe_arc(&d);
        d.catastrophe_phase = CatastrophePhase::Aftermath;
        let aftermath = catastrophe_arc(&d);
        assert!(active > none);
        assert!(active > aftermath);
    }

    #[test]
    fn during_phase_factory_works() {
        let curve = during_phase(CatastrophePhase::Active);
        let mut d = AudioDirector::default();
        d.catastrophe_phase = CatastrophePhase::Active;
        assert!((curve(&d) - 1.0).abs() < 1e-6);
        d.catastrophe_phase = CatastrophePhase::None;
        assert!((curve(&d) - 0.0).abs() < 1e-6);
    }
}
