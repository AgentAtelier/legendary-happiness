#![allow(missing_docs)]

//! Asset-driven reactive audio for the Anvil engine.
//!
//! Add [`AudioPlugin`] once to a Bevy `App`. The plugin registers:
//!
//! - [`AudioSeed`] — deterministic master seed (insert before plugin if you
//!   want non-default seeding from the world seed).
//! - [`AudioDirector`] — the central state aggregator.
//! - [`StemRegistry`] — global score stems with mood-driven volumes.
//! - [`ZoneRegistry`] — positional ambient zones with proximity falloff.
//! - [`DuckingState`] — ducks the stems briefly when stingers fire.
//! - [`Cue`] and [`PlayStinger`] events — the communication channel.
//!
//! Game code (the demo crate, the main game) configures the registries
//! and inserts a [`StingerMap`] to translate cues into stinger plays.
//! This crate owns *no policy* about which sounds play when — only the
//! mechanism. See `crates/anvil_demo/src/audio/ashveil.rs` for the
//! reference policy implementation.
//!
//! # Determinism
//!
//! The mix is **bit-deterministic** given identical inputs and seed:
//! the same stems play at the same volumes at the same simulation tick.
//! Speaker output may drift by up to one audio buffer period (~10 ms)
//! because OS-level audio buffer sizes are not under our control. See
//! `ANVIL_AUDIO.md` for the full contract.

/// Resource-backed event queues for cue and stinger transport.
pub mod cue_queue;
pub mod cues;
pub mod director;
pub mod ducking;
pub mod output;
pub mod score;
pub mod seed;
pub mod stems;
pub mod zones;

#[cfg(test)]
mod tests;

use bevy::prelude::*;

pub use cue_queue::{CueQueue, StingerQueue};
pub use cues::{
    Cue, EmotionalCue, EnvironmentalCue, NarrativeCue, PlayStinger, StingerMap,
    StingerResolver, CatastropheKind, PrecursorKind, WeatherPhaseLabel,
};
pub use director::{
    AudioDirector, AudioOptionsRead, BodyState, CatastrophePhase, TimePhase, WeatherMood,
};
pub use ducking::DuckingState;
pub use seed::{AudioSeed, Xorshift64};
pub use stems::{MoodCurve, Stem, StemId, StemRegistry};
pub use zones::{AudioListener, Zone, ZoneCurve, ZoneId, ZoneRegistry};

/// The single audio plugin. Add once.
pub struct AudioPlugin;

impl Plugin for AudioPlugin {
    fn build(&self, app: &mut App) {
        app
            // Resources: insert defaults if absent. Callers can pre-insert
            // a seeded `AudioSeed` (or a populated `StingerMap`) before
            // adding the plugin and we'll respect their choice.
            .init_resource::<AudioSeed>()
            .init_resource::<AudioDirector>()
            .init_resource::<StemRegistry>()
            .init_resource::<ZoneRegistry>()
            .init_resource::<DuckingState>()
            // Event queues
            .init_resource::<CueQueue>()
            .init_resource::<StingerQueue>()
            // Systems: ordered to make the data flow explicit.
            // 1. Director state refresh (sim → audio).
            // 2. Cue dispatch (cue → PlayStinger event).
            // 3. Ducking update (PlayStinger → multiplier).
            // 4. Stems + zones (director + ducking → audio entities).
            // 5. Stinger playback (PlayStinger → spawned entities).
            .add_systems(
                Update,
                (
                    director::update_director,
                    cues::dispatch_cues,
                    ducking::update_ducking,
                    stems::update_stems,
                    zones::update_zones,
                    output::play_stingers,
                )
                    .chain(),
            );
    }
}
