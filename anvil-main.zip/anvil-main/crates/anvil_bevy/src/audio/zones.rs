//! Positional ambient audio zones.
//!
//! A [`Zone`] is an audio source anchored at a world position, with a
//! falloff radius and a target volume modulated by both proximity to the
//! player and [`AudioDirector`] state (wind speed, weather, time of day).
//!
//! Zones are conceptually distinct from stems: stems are the *score*, mixed
//! globally; zones are the *world*, mixed positionally. Both use the same
//! spawn-and-track-entity discipline that prevents the screech bug.
//!
//! Zone positions are passed in by the demo's configuration (`ashveil.rs`).
//! This module knows nothing about Ashveil's coordinate system — it just
//! receives `Vec3` positions and computes distance.

use bevy::audio::{AudioPlayer, AudioSink, AudioSource, PlaybackSettings, Volume};
use bevy::prelude::*;
use std::collections::HashMap;

use super::director::AudioDirector;

/// Stable, type-safe zone identifier.
pub type ZoneId = &'static str;

/// Function mapping director state to a *contextual* volume multiplier in
/// `[0.0, 1.0]`. Multiplied against the distance-derived gain to produce
/// the final target volume. Pure: no RNG, no time.
pub type ZoneCurve = fn(&AudioDirector) -> f32;

/// One ambient zone in the world.
///
/// `entity` is the spawn bookkeeping; same discipline as `Stem`. The
/// spawn-and-write happens in one function in this file; no other system
/// mutates this field.
pub struct Zone {
    pub id: ZoneId,
    pub position: Vec3,
    pub radius: f32,
    pub handle: Handle<AudioSource>,
    pub curve: ZoneCurve,
    pub max_volume: f32,
    pub crossfade_speed: f32,
    pub(crate) entity: Option<Entity>,
    pub(crate) current_volume: f32,
}

impl Zone {
    pub fn new(
        id: ZoneId,
        position: Vec3,
        radius: f32,
        handle: Handle<AudioSource>,
        curve: ZoneCurve,
        max_volume: f32,
        crossfade_speed: f32,
    ) -> Self {
        Self {
            id,
            position,
            radius,
            handle,
            curve,
            max_volume,
            crossfade_speed,
            entity: None,
            current_volume: 0.0,
        }
    }
}

/// Owns all zones. Drives target volumes, crossfade, spawn, despawn.
#[derive(Resource, Default)]
pub struct ZoneRegistry {
    zones: HashMap<ZoneId, Zone>,
}

impl ZoneRegistry {
    pub fn register(&mut self, zone: Zone) {
        self.zones.insert(zone.id, zone);
    }

    pub fn iter(&self) -> impl Iterator<Item = &Zone> {
        self.zones.values()
    }
}

/// Marker for the listener entity. The demo's player camera should be
/// tagged with this once it spawns; the zone system queries for it.
#[derive(Component)]
pub struct AudioListener;

/// Per-frame system. Reads listener position, recomputes proximity gain,
/// applies the zone's mood curve, lerps toward target, spawns/despawns.
///
/// Identical bookkeeping discipline to `update_stems` — kept separate
/// because stems mix globally and zones mix positionally, and conflating
/// the two would force every zone to carry a no-op position.
pub fn update_zones(
    mut commands: Commands,
    mut registry: ResMut<ZoneRegistry>,
    director: Res<AudioDirector>,
    time: Res<Time>,
    mut sinks: Query<&mut AudioSink>,
    listener: Query<&GlobalTransform, With<AudioListener>>,
) {
    let dt = time.delta_secs();
    let master = director.master_volume;
    let listener_pos = listener.iter().next().map(|t| t.translation());
    for zone in registry.zones.values_mut() {
        tick_one_zone(zone, &director, listener_pos, dt, master, &mut commands, &mut sinks);
    }
}

/// Compute proximity gain (smooth-stepped linear falloff) for a zone given
/// the listener's current position. Returns 0.0 if the listener is absent.
fn proximity_gain(zone_pos: Vec3, zone_radius: f32, listener_pos: Option<Vec3>) -> f32 {
    let Some(pos) = listener_pos else { return 0.0 };
    let distance = pos.distance(zone_pos);
    if distance >= zone_radius {
        return 0.0;
    }
    let t = 1.0 - distance / zone_radius;
    t * t * (3.0 - 2.0 * t)
}

/// Per-zone tick. Extracted so `update_zones` stays under the 50-line
/// function budget.
fn tick_one_zone(
    zone: &mut Zone,
    director: &AudioDirector,
    listener_pos: Option<Vec3>,
    dt: f32,
    master: f32,
    commands: &mut Commands,
    sinks: &mut Query<&mut AudioSink>,
) {
    let prox = proximity_gain(zone.position, zone.radius, listener_pos);
    let curve_mul = (zone.curve)(director).clamp(0.0, 1.0);
    let target = prox * curve_mul * zone.max_volume;

    let alpha = 1.0 - (-zone.crossfade_speed * dt).exp();
    zone.current_volume += (target - zone.current_volume) * alpha;

    let effective = zone.current_volume * master;
    match zone.entity {
        None if effective > AUDIBILITY_THRESHOLD => {
            let id = commands
                .spawn((
                    AudioPlayer::new(zone.handle.clone()),
                    PlaybackSettings::LOOP.with_volume(Volume::Linear(effective)),
                ))
                .id();
            zone.entity = Some(id);
        }
        Some(entity) if effective <= AUDIBILITY_THRESHOLD => {
            commands.entity(entity).despawn();
            zone.entity = None;
        }
        Some(entity) => {
            if let Ok(mut sink) = sinks.get_mut(entity) {
                sink.set_volume(Volume::Linear(effective));
            }
        }
        None => {}
    }
}

const AUDIBILITY_THRESHOLD: f32 = 0.001;

#[cfg(test)]
mod tests {
    use super::*;

    fn always_one(_: &AudioDirector) -> f32 {
        1.0
    }

    #[test]
    fn zone_registers() {
        let mut registry = ZoneRegistry::default();
        registry.register(Zone::new(
            "wind",
            Vec3::ZERO,
            50.0,
            Handle::default(),
            always_one,
            1.0,
            1.0,
        ));
        assert_eq!(registry.zones.len(), 1);
    }
}
