//! Deterministic seeding for the audio system.
//!
//! Every audio subsystem that uses randomness derives its RNG from a single
//! [`AudioSeed`] resource. The master seed is derived from the world seed at
//! startup; named subsystems pull stable sub-RNGs from it via hash. Two runs
//! of the same world seed produce identical RNG streams across every audio
//! subsystem — see `tests/determinism.rs` for the proof.
//!
//! This module is the determinism anchor for the whole audio system. No
//! audio code should call `rand::thread_rng()`, `std::time::Instant::now()`,
//! or any non-seeded source of entropy. The compiler can't catch this, so
//! it's the reviewer's job; the test suite catches drift by comparing
//! sample-accurate output across runs.

use bevy::prelude::*;
use std::hash::{Hash, Hasher};

/// The master audio seed. Derived from the world seed at startup.
///
/// Insert this resource before [`AudioPlugin`] is added; the plugin will
/// fall back to a fixed seed if absent (useful for unit tests but never for
/// production paths).
#[derive(Resource, Debug, Clone, Copy)]
pub struct AudioSeed {
    master: u64,
}

impl AudioSeed {
    /// Construct from a world seed. The returned [`AudioSeed`] hashes the
    /// world seed with a constant tag so audio RNG streams do not collide
    /// with simulation RNG streams that share the same world seed.
    pub fn from_world_seed(world_seed: u64) -> Self {
        Self {
            master: hash_with_tag(world_seed, b"anvil-audio-v1"),
        }
    }

    /// Construct directly from a master seed. Use only in tests.
    #[cfg(any(test, debug_assertions))]
    pub fn from_master(master: u64) -> Self {
        Self { master }
    }

    /// Derive a deterministic sub-RNG for a named subsystem.
    ///
    /// The label must be a `'static str` so the call site is auditable: every
    /// audio subsystem's RNG label is visible in source. The same label and
    /// the same master seed always produce the same RNG state.
    pub fn rng_for(&self, label: &'static str) -> Xorshift64 {
        Xorshift64::seeded(hash_with_tag(self.master, label.as_bytes()))
    }
}

impl Default for AudioSeed {
    /// Fallback seed for development paths that haven't wired up a world
    /// seed yet. Not for production — replays will not match.
    fn default() -> Self {
        Self::from_world_seed(0x0123_4567_89AB_CDEF)
    }
}

/// Xorshift64 PRNG. Matches the implementation used in `anvil_sim`'s
/// `DeterministicRng`. Deterministic, fast, fixed period.
#[derive(Debug, Clone)]
pub struct Xorshift64 {
    state: u64,
}

impl Xorshift64 {
    fn seeded(seed: u64) -> Self {
        // Xorshift64 must not start at zero. Hash collisions with zero are
        // vanishingly rare but we guard anyway.
        let state = if seed == 0 { 0xDEAD_BEEF_CAFE_BABE } else { seed };
        Self { state }
    }

    /// Advance and return a `u64`.
    pub fn next_u64(&mut self) -> u64 {
        let mut x = self.state;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.state = x;
        x
    }

    /// Return a value in `[0.0, 1.0)`. Useful for jitter and volume randomisation.
    pub fn next_f32(&mut self) -> f32 {
        (self.next_u64() >> 40) as f32 / (1u64 << 24) as f32
    }

    /// Return a value in `[-1.0, 1.0)`. Useful for signed perturbations.
    pub fn next_signed_f32(&mut self) -> f32 {
        self.next_f32() * 2.0 - 1.0
    }

    /// Choose an index in `[0, n)`. Panics on `n == 0` in debug; returns 0 in release.
    pub fn pick_index(&mut self, n: usize) -> usize {
        debug_assert!(n > 0, "Xorshift64::pick_index called with n=0");
        if n == 0 {
            return 0;
        }
        (self.next_u64() as usize) % n
    }
}

/// Hash a seed with a tag using the standard library's default hasher.
/// Stable across `std` versions per the standard library's stability promise
/// for `DefaultHasher` outputs *within a single Rust release*. For
/// cross-version determinism we'd need a custom hash; that's out of scope —
/// see `ANVIL_AUDIO.md` §determinism.
fn hash_with_tag(seed: u64, tag: &[u8]) -> u64 {
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    seed.hash(&mut hasher);
    tag.hash(&mut hasher);
    hasher.finish()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn same_world_seed_same_rng_stream() {
        let a = AudioSeed::from_world_seed(42);
        let b = AudioSeed::from_world_seed(42);
        let mut rng_a = a.rng_for("zone_jitter");
        let mut rng_b = b.rng_for("zone_jitter");
        for _ in 0..1000 {
            assert_eq!(rng_a.next_u64(), rng_b.next_u64());
        }
    }

    #[test]
    fn different_labels_diverge() {
        let seed = AudioSeed::from_world_seed(42);
        let mut a = seed.rng_for("zone_jitter");
        let mut b = seed.rng_for("stinger_selection");
        // Probabilistic but with 10000 samples the chance of identical streams
        // from different labels is effectively zero.
        let mut diverged = false;
        for _ in 0..10000 {
            if a.next_u64() != b.next_u64() {
                diverged = true;
                break;
            }
        }
        assert!(diverged, "different labels produced identical RNG streams");
    }

    #[test]
    fn signed_f32_in_range() {
        let mut rng = Xorshift64::seeded(12345);
        for _ in 0..10000 {
            let v = rng.next_signed_f32();
            assert!((-1.0..1.0).contains(&v), "out of range: {}", v);
        }
    }
}
