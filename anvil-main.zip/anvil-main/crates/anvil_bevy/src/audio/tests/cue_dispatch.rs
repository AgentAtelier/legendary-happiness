//! Cue dispatch integration test.
//!
//! Asserts that a `Cue` emitted via `CueQueue` reaches the
//! `dispatch_cues` system, that the `StingerMap` resolves it (when an
//! entry exists), and that a `PlayStinger` is produced in the `StingerQueue`.
//!
//! This test exercises the queue-driven path the architecture commits
//! to. If polling sneaks back in, the test still passes because it only
//! verifies the queue side; but the architecture's no-polling discipline
//! lives in code review, not here.

use bevy::prelude::*;

use crate::audio::{
    AudioPlugin, Cue, CueQueue, EnvironmentalCue, PlayStinger, StingerMap,
    StingerResolver,
};

/// Resolver that produces a stinger for any `DebrisImpact` cue and
/// nothing else. Used to assert that dispatch correctly routes cues.
struct DebrisOnlyResolver;
impl StingerResolver for DebrisOnlyResolver {
    fn resolve(&self, cue: &Cue) -> Option<PlayStinger> {
        match cue {
            Cue::Environmental(EnvironmentalCue::DebrisImpact { .. }) => Some(PlayStinger {
                handle: Handle::default(),
                volume: 0.7,
                duck_stems: true,
            }),
            _ => None,
        }
    }
}

fn build_app() -> App {
    let mut app = App::new();
    app.add_plugins((
        MinimalPlugins,
        bevy::asset::AssetPlugin::default(),
        AudioPlugin,
    ));
    app.insert_resource(StingerMap::new(DebrisOnlyResolver));
    app
}

/// Helper: count spawned AudioPlayer entities.
fn audio_player_count(app: &mut App) -> usize {
    app.world_mut().query::<&bevy::audio::AudioPlayer>().iter(app.world_mut()).count()
}

#[test]
fn matching_cue_produces_play_stinger() {
    let mut app = build_app();
    app.update(); // settle

    app.world_mut()
        .resource_mut::<CueQueue>()
        .send(Cue::Environmental(EnvironmentalCue::DebrisImpact {
            position: Vec3::ZERO,
            magnitude: 1.0,
        }));
    app.update();

    // The cue should have been dispatched to a PlayStinger, which should have
    // spawned an AudioPlayer entity.
    assert_eq!(audio_player_count(&mut app), 1);
}

#[test]
fn unmatched_cue_produces_nothing() {
    let mut app = build_app();
    app.update();

    app.world_mut()
        .resource_mut::<CueQueue>()
        .send(Cue::Environmental(EnvironmentalCue::PrecursorSignal {
            kind: crate::audio::PrecursorKind::SmokeOnHorizon,
            intensity: 0.5,
            position: Vec3::ZERO,
        }));
    app.update();

    // No AudioPlayer should be spawned for unmatched cues.
    assert_eq!(audio_player_count(&mut app), 0);
}

#[test]
fn cues_without_stinger_map_are_drained_not_accumulated() {
    let mut app = App::new();
    app.add_plugins((MinimalPlugins, bevy::asset::AssetPlugin::default(), AudioPlugin));
    // Note: no StingerMap inserted.
    app.update();

    for _ in 0..10 {
        app.world_mut()
            .resource_mut::<CueQueue>()
            .send(Cue::Environmental(EnvironmentalCue::DebrisImpact {
                position: Vec3::ZERO,
                magnitude: 1.0,
            }));
    }
    app.update();
    // No stinger plays because there's no map, so no AudioPlayer entities.
    assert_eq!(audio_player_count(&mut app), 0);
    // And the cue queue should be empty after dispatch drains it.
    let queue = app.world().resource::<CueQueue>();
    assert_eq!(queue.events.len(), 0);
}
