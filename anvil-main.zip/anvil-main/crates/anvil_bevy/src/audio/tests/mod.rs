//! Integration tests for the audio system.
//!
//! Unit tests live in each module's `#[cfg(test)] mod tests` block. This
//! directory holds tests that exercise multiple modules together —
//! determinism across the full pipeline, cue dispatch through the event
//! system, etc.

mod cue_dispatch;
mod determinism;
