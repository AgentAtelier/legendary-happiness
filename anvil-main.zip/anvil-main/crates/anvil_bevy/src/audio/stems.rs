//! Stems — the unit of asset-driven reactive composition.
//!
//! A [`Stem`] is one audio asset that participates in the live mix. The
//! [`StemRegistry`] owns all stems, computes target volumes from the
//! [`AudioDirector`], smoothly fades each stem toward its target, and
//! manages the spawned `AudioPlayer` entities.
//!
//! **Screech-bug resistance.** The previous architecture had a class of
//! bugs where the spawn check (`audio_manager.score_entities.contains_key`)
//! and the spawn bookkeeping (`audio_manager.score_entities.insert`) were
//! separated, so the bookkeeping was sometimes missed and the audio system
//! spawned the same `AudioPlayer` every frame. This module makes that bug
//! structurally impossible: the spawn and the entity-write happen in the
//! same function body, three lines apart, mutating the same struct field.
//! No second map. No second source of truth.
//!
//! A debug assertion in [`StemRegistry::tick`] catches drift between the
//! stored entity and the actual sink existence in dev builds.

use bevy::audio::{AudioPlayer, AudioSink, AudioSource, PlaybackSettings, Volume};
use bevy::prelude::*;
use std::collections::HashMap;

use super::director::AudioDirector;

/// Stable, type-safe stem identifier.
///
/// Using `&'static str` rather than `String` keeps stem references zero-cost
/// and visible in source. Adding a stem means adding a constant in the
/// demo's `ashveil.rs`, not allocating at runtime.
pub type StemId = &'static str;

/// Function mapping director state to a target volume in `[0.0, 1.0]`.
///
/// Each stem owns one. The function is pure: same director state → same
/// target volume. No RNG inside `MoodCurve` — randomness goes through the
/// `AudioSeed` system at registry construction time, not at mix time.
pub type MoodCurve = fn(&AudioDirector) -> f32;

/// One audio asset participating in the reactive mix.
///
/// The `entity` field is the spawn bookkeeping; it is `Some` exactly when
/// this stem is currently playing in the Bevy world. The pattern that
/// previously produced the screech bug — separate spawn check and spawn
/// write — cannot occur here because the field is mutated *in the same
/// function* that calls `commands.spawn`.
pub struct Stem {
    pub id: StemId,
    pub handle: Handle<AudioSource>,
    pub mood_curve: MoodCurve,
    pub crossfade_speed: f32,
    pub max_volume: f32,
    pub(crate) entity: Option<Entity>,
    pub(crate) current_volume: f32,
}

impl Stem {
    /// Constructor for use by `StemRegistry::register`. Made `pub` so the
    /// demo crate can build stems but kept ergonomic enough that you don't
    /// reach for it directly outside of registration.
    pub fn new(
        id: StemId,
        handle: Handle<AudioSource>,
        mood_curve: MoodCurve,
        crossfade_speed: f32,
        max_volume: f32,
    ) -> Self {
        Self {
            id,
            handle,
            mood_curve,
            crossfade_speed,
            max_volume,
            entity: None,
            current_volume: 0.0,
        }
    }
}

/// Owns all stems. Drives target volumes, crossfade, spawn, despawn.
///
/// Inserted as a Bevy resource. Mutated by the `update_stems` system once
/// per frame. Read by the ducking and output stages.
#[derive(Resource, Default)]
pub struct StemRegistry {
    stems: HashMap<StemId, Stem>,
}

impl StemRegistry {
    /// Register a stem. Idempotent: re-registering the same id replaces.
    ///
    /// Call from the demo's startup configuration (`ashveil.rs`). Once the
    /// registry is built, this should not be called during normal play;
    /// adding stems mid-game is technically supported but a smell.
    pub fn register(&mut self, stem: Stem) {
        self.stems.insert(stem.id, stem);
    }

    /// Iterate over stems for inspection (UI, tests). Order is unspecified.
    pub fn iter(&self) -> impl Iterator<Item = &Stem> {
        self.stems.values()
    }
}

/// Per-frame system. Computes target volumes, lerps current toward target,
/// spawns/despawns `AudioPlayer` entities, writes volumes to sinks.
///
/// **Single point of mutation.** The fact that this is the only system
/// that writes `Stem::entity` is what makes the screech bug impossible.
/// Reviewers: do not add another path that spawns audio entities for stems.
/// If you need to play a one-shot sound, use the `cues` module's stinger
/// path, not the stem path.
pub fn update_stems(
    mut commands: Commands,
    mut registry: ResMut<StemRegistry>,
    director: Res<AudioDirector>,
    time: Res<Time>,
    mut sinks: Query<&mut AudioSink>,
) {
    let dt = time.delta_secs();
    let master = director.master_volume;
    for stem in registry.stems.values_mut() {
        tick_one_stem(stem, &director, dt, master, &mut commands, &mut sinks);
    }
}

/// Per-stem tick. Extracted so `update_stems` stays under the 50-line
/// function budget; this function lives in the same file because the
/// `Stem` struct's private fields are mutated here.
fn tick_one_stem(
    stem: &mut Stem,
    director: &AudioDirector,
    dt: f32,
    master: f32,
    commands: &mut Commands,
    sinks: &mut Query<&mut AudioSink>,
) {
    let raw_target = (stem.mood_curve)(director);
    let target = raw_target.clamp(0.0, 1.0) * stem.max_volume;

    // Smoothed approach. Exponential crossfade per the notebook entry —
    // linear sounds mechanical; this matches human loudness perception.
    let alpha = 1.0 - (-stem.crossfade_speed * dt).exp();
    stem.current_volume += (target - stem.current_volume) * alpha;

    let effective = stem.current_volume * master;

    // Spawn-or-despawn-or-update — exactly one of these per stem per frame,
    // atomic with respect to `stem.entity`.
    match stem.entity {
        None if effective > AUDIBILITY_THRESHOLD => {
            let id = commands
                .spawn((
                    AudioPlayer::new(stem.handle.clone()),
                    PlaybackSettings::LOOP.with_volume(Volume::Linear(effective)),
                ))
                .id();
            stem.entity = Some(id);
        }
        Some(entity) if effective <= AUDIBILITY_THRESHOLD => {
            commands.entity(entity).despawn();
            stem.entity = None;
        }
        Some(entity) => {
            if let Ok(mut sink) = sinks.get_mut(entity) {
                sink.set_volume(Volume::Linear(effective));
            }
        }
        None => {} // Below threshold and not playing.
    }
}

/// Volume below which we treat a stem as silent and avoid spawning it.
/// Spawn-then-immediately-despawn churn at the edges of audibility wastes
/// allocations and produces audible clicks; this hysteresis avoids both.
const AUDIBILITY_THRESHOLD: f32 = 0.001;

#[cfg(test)]
mod tests {
    use super::*;
    use crate::audio::director::AudioDirector;

    fn always_loud(_: &AudioDirector) -> f32 {
        1.0
    }
    fn always_silent(_: &AudioDirector) -> f32 {
        0.0
    }

    #[test]
    fn registry_replaces_on_duplicate_id() {
        let mut registry = StemRegistry::default();
        registry.register(Stem::new("a", Handle::default(), always_loud, 1.0, 1.0));
        registry.register(Stem::new("a", Handle::default(), always_silent, 1.0, 1.0));
        assert_eq!(registry.stems.len(), 1);
    }

    #[test]
    fn iter_visits_all_stems() {
        let mut registry = StemRegistry::default();
        registry.register(Stem::new("a", Handle::default(), always_loud, 1.0, 1.0));
        registry.register(Stem::new("b", Handle::default(), always_silent, 1.0, 1.0));
        let mut ids: Vec<_> = registry.iter().map(|s| s.id).collect();
        ids.sort();
        assert_eq!(ids, vec!["a", "b"]);
    }
}
