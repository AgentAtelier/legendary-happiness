//! # anvil_bevy
//!
//! **Layer:** PRESENTATION
//!
//! **Purpose:** Converts `anvil_assets` types into Bevy components and materials,
//! enabling the Anvil pipeline to render in a Bevy application.
//!
//! **Main Entry Points:**
//! - [`AnvilAssetPlugin`] — Bevy plugin that registers Anvil asset types and components
//! - [`to_standard_material()`] — converts `MaterialOverride` to Bevy `StandardMaterial`
//! - [`load_mesh()`] — loads mesh assets from resolved asset paths
//! - [`AssetOriginTag`] — component tracking material origin (authored vs fallback)
//! - [`debug_fallback_summary()`] — debug utility for counting fallback assets

#![deny(missing_docs)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use anvil_assets::prelude::*;
use bevy::asset::AssetServer;
use bevy::mesh::Mesh;
use bevy::prelude::*;
use std::path::PathBuf;
use std::sync::Arc;

/// Convert a `MaterialOverride` into a Bevy `StandardMaterial`.
///
/// This function maps Anvil's material properties to Bevy's standard material:
/// - `albedo_texture` → `base_color_texture`
/// - `normal_texture` → `normal_map_texture`
/// - `roughness_metallic_texture` → `metallic_roughness_texture`
/// - `base_color_tint` → `base_color` (with warm clay fallback if missing)
/// - `perceptual_roughness` → `perceptual_roughness`
/// - `metallic` → `metallic`
/// - `emissive` → `emissive`
///
/// Textures are loaded via the `AssetServer` and return handles.
pub fn to_standard_material(
    overrides: &MaterialOverride,
    asset_server: &AssetServer,
) -> StandardMaterial {
    let mut mat = StandardMaterial::default();

    if let Some(ref albedo_tex) = overrides.albedo_texture {
        let path = albedo_tex.to_string_lossy().to_string();
        mat.base_color_texture = Some(asset_server.load(path));
    }
    if let Some(ref normal_tex) = overrides.normal_texture {
        let path = normal_tex.to_string_lossy().to_string();
        mat.normal_map_texture = Some(asset_server.load(path));
    }
    if let Some(ref orm_tex) = overrides.roughness_metallic_texture {
        let path = orm_tex.to_string_lossy().to_string();
        mat.metallic_roughness_texture = Some(asset_server.load(path));
    }
    if let Some(tint) = overrides.base_color_tint {
        mat.base_color = Color::srgba(tint[0], tint[1], tint[2], tint[3]);
    } else {
        mat.base_color = Color::srgb(0.8, 0.5, 0.3); // warm clay fallback
    }
    if let Some(roughness) = overrides.perceptual_roughness {
        mat.perceptual_roughness = roughness;
    }
    if let Some(metallic) = overrides.metallic {
        mat.metallic = metallic;
    }
    if let Some(emissive) = overrides.emissive {
        mat.emissive = Color::srgb(emissive[0], emissive[1], emissive[2]).into();
    }
    mat
}

/// Load a mesh from an `Arc<PathBuf>` (as stored in `ResolvedAsset`).
///
/// This is a synchronous operation that returns a `Handle<Mesh>`. The mesh data
/// is loaded asynchronously by Bevy's asset server.
///
/// # Errors
/// This function does not return errors directly; invalid paths will result
/// in failed asset loads that can be detected through Bevy's asset events.
pub fn load_mesh(path: &Arc<PathBuf>, asset_server: &AssetServer) -> Handle<Mesh> {
    asset_server.load(path.to_string_lossy().to_string())
}

/// Tag component marking whether an entity uses explicit or fallback material.
///
/// This component is attached to Bevy entities that were spawned from Anvil assets.
/// It carries a [`MaterialOrigin`] value indicating whether the entity's material
/// came from an authored asset (`MaterialOrigin::Authored`) or was generated
/// as a fallback (`MaterialOrigin::Fallback`).
///
/// Use this for debugging and runtime inspection of asset loading.
#[derive(Component)]
pub struct AssetOriginTag(pub MaterialOrigin);

/// Count fallback assets and return a summary tuple.
///
/// This debug utility function iterates over a query of [`AssetOriginTag`] components
/// and returns a tuple of `(total_entities, fallback_count)`. It is primarily used
/// in debug builds to monitor asset loading and identify entities that failed
/// to load their authored materials.
///
/// # Usage
/// ```ignore
/// let (total, fallbacks) = debug_fallback_summary(&query);
/// println!("Loaded {} entities, {} using fallback materials", total, fallbacks);
/// ```
pub fn debug_fallback_summary(query: &Query<&AssetOriginTag>) -> (usize, usize) {
    let fallback = query.iter().filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
    let total = query.iter().count();
    (total, fallback)
}

/// Bevy plugin that registers Anvil asset types and components.
///
/// This plugin is a placeholder for future Anvil-specific asset loaders.
/// Currently it serves as the central registration point for Anvil asset integration.
#[derive(Default)]
pub struct AnvilAssetPlugin;

impl Plugin for AnvilAssetPlugin {
    fn build(&self, _app: &mut App) {
        // Future: register custom asset loaders here
        // e.g., app.init_asset_loader::<AnvilAssetLoader>()
    }
}

// ---------------------------------------------------------------------------

pub mod audio;

/// Simulation bridge types for presentation layer.
pub mod sim_bridge;

/// Environment systems and configuration.
pub mod environment;

/// Sky sphere rendering.
pub mod sky;

/// Marker components for entity identification.
pub mod markers;

/// Terrain material extension for batch rendering.
pub mod terrain;

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use bevy::asset::AssetPlugin;
    use bevy::prelude::{App, Color, Image, MinimalPlugins, World};
    use std::sync::Arc;

    #[test]
    fn test_to_standard_material_albedo_propagation() {
        // Create a mock asset server for testing
        // We can't fully test asset loading without initializing all Bevy asset types,
        // but we can verify the color fallback behavior
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, AssetPlugin::default()));
        
        // Initialize the Image asset type to avoid panics
        app.init_asset::<Image>();
        
        let asset_server = app.world().get_resource::<AssetServer>().unwrap();

        let overrides = MaterialOverride {
            albedo_texture: Some(Arc::new(PathBuf::from("test_albedo.png"))),
            normal_texture: None,
            roughness_metallic_texture: None,
            base_color_tint: None,
            perceptual_roughness: None,
            metallic: None,
            emissive: None,
        };

        let material = to_standard_material(&overrides, asset_server);

        // Should have the albedo texture loaded
        assert!(material.base_color_texture.is_some());
        // Should use warm clay fallback for base_color since no tint provided
        assert_eq!(material.base_color, Color::srgb(0.8, 0.5, 0.3));
    }

    #[test]
    fn test_to_standard_material_fallback_colour() {
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, AssetPlugin::default()));
        app.init_asset::<Image>();
        
        let asset_server = app.world().get_resource::<AssetServer>().unwrap();

        let overrides = MaterialOverride {
            albedo_texture: None,
            normal_texture: None,
            roughness_metallic_texture: None,
            base_color_tint: None,
            perceptual_roughness: None,
            metallic: None,
            emissive: None,
        };

        let material = to_standard_material(&overrides, asset_server);

        // Should use warm clay fallback when no albedo or tint
        assert_eq!(material.base_color, Color::srgb(0.8, 0.5, 0.3));
        assert!(material.base_color_texture.is_none());
    }

    #[test]
    fn test_debug_fallback_summary_empty() {
        // Test with an empty world - no entities with AssetOriginTag
        // Create a world and verify there are no AssetOriginTag components
        let mut world = World::new();
        let entity_count = world.query::<&AssetOriginTag>().iter(&world).count();
        let fallback_count = world.query::<&AssetOriginTag>().iter(&world)
            .filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
        
        assert_eq!(entity_count, 0);
        assert_eq!(fallback_count, 0);
    }

    #[test]
    fn test_debug_fallback_summary_non_empty() {
        // Test with a world that has AssetOriginTag entities
        let mut world = World::new();
        
        // Spawn entities directly without using Commands
        // MaterialOrigin has Explicit and Fallback variants
        world.spawn((AssetOriginTag(MaterialOrigin::Explicit),));
        world.spawn((AssetOriginTag(MaterialOrigin::Explicit),));
        world.spawn((AssetOriginTag(MaterialOrigin::Fallback),));
        
        let entity_count = world.query::<&AssetOriginTag>().iter(&world).count();
        let fallback_count = world.query::<&AssetOriginTag>().iter(&world)
            .filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
        
        assert_eq!(entity_count, 3);
        assert_eq!(fallback_count, 1);
    }
    
    #[allow(dead_code)]
    fn _unused_check() {
        // Used to prevent unused import warnings in test module
    }
}
