//! Terrain rendering module.
//!
//! This module provides the terrain material extension system for batch rendering
//! terrain chunks with shared material parameters.

/// Material types for terrain rendering.
pub mod material;

/// Plugin for terrain material system.
pub mod plugin;
