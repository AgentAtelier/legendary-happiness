use bevy::prelude::*;
use crate::terrain::material::TerrainMaterial;
use crate::environment::state::EnvironmentState;
use crate::sim_bridge::{SimSnapshot, CatastropheKind};
use crate::markers::TerrainChunk;

/// Bevy plugin for terrain material rendering.
///
/// This plugin registers the terrain material type and adds systems to drive
/// terrain material parameters based on environment and simulation state.
pub struct TerrainPlugin;

impl Plugin for TerrainPlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins(MaterialPlugin::<TerrainMaterial>::default())
           .add_systems(PostUpdate, drive_terrain_material_params);
    }
}

/// Updates a SINGLE material asset handle. All terrain chunks that share
/// this handle are updated together. O(1), not O(chunk_count).
fn drive_terrain_material_params(
    env: Res<EnvironmentState>,
    snapshot: Res<SimSnapshot>,
    mut mats: ResMut<Assets<TerrainMaterial>>,
    terrain_q: Query<&MeshMaterial3d<TerrainMaterial>, With<TerrainChunk>>,
) {
    let Ok(handle) = terrain_q.single() else { return };
    let Some(mat) = mats.get_mut(&handle.0) else { return };

    // Burn factor: maximum intensity across all active wildfires.
    let burn = snapshot.catastrophes.iter()
        .filter(|c| c.kind == CatastropheKind::Wildfire)
        .map(|c| c.intensity)
        .fold(0.0f32, f32::max);

    // Snow: when temperature is below -1°C and precipitation is falling.
    let snow = if snapshot.weather.temperature_c < -1.0 {
        (snapshot.weather.precipitation * 0.9).clamp(0.0, 1.0)
    } else {
        0.0
    };

    mat.extension.params.wetness = env.wetness.current;
    mat.extension.params.snow_cover = snow;
    mat.extension.params.burn_factor = burn;
}
