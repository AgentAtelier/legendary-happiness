use bevy::prelude::*;
use bevy::pbr::{ExtendedMaterial, MaterialExtension};
use bevy::render::render_resource::{AsBindGroup, ShaderType};
use bevy::shader::ShaderRef;

/// Material extension for terrain that adds wetness, snow, and burn effects.
///
/// This extension modulates the base PBR inputs before the standard lighting
/// calculation runs, allowing all terrain chunks to share a single material handle.
#[derive(Asset, AsBindGroup, TypePath, Clone, Default)]
pub struct TerrainExtension {
    /// Uniform parameters passed to the terrain shader.
    #[uniform(100)]
    pub params: TerrainMaterialParams,
}

/// Uniform parameters for terrain material shader.
#[derive(ShaderType, Clone, Copy, Default)]
pub struct TerrainMaterialParams {
    /// Wetness factor: 0.0 = dry, 1.0 = saturated.
    pub wetness: f32,
    /// Snow cover factor: 0.0 = bare, 1.0 = snow-covered.
    pub snow_cover: f32,
    /// Burn factor: 0.0 = pristine, 1.0 = charred.
    pub burn_factor: f32,
    /// Padding to align to 16 bytes.
    pub _pad: f32,
}

impl MaterialExtension for TerrainExtension {
    fn fragment_shader() -> ShaderRef {
        "shaders/terrain_extension.wgsl".into()
    }
}

/// All terrain chunks use this one material type.
///
/// One handle -> one draw call batch -> O(1) uniform update.
pub type TerrainMaterial = ExtendedMaterial<StandardMaterial, TerrainExtension>;
