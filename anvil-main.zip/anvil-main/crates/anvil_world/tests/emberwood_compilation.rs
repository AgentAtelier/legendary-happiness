use anvil_assets::AssetCatalogue;
use anvil_core::{LandmarkKind, LandmarkSpec, RegionSpec, StyleHints, TerrainType, repo_path};
use anvil_world::compile_region;

#[test]
fn emberwood_catalogue_compiles_simple_region() {
    // Load the minimal assets/catalogue.json
    let catalogue_path = repo_path!("assets/catalogue.json");
    let catalogue = AssetCatalogue::load(&catalogue_path, None).expect("Failed to load catalogue");

    // Create a simple RegionSpec with three landmarks that match catalogue entries
    // The catalogue has entries like: forest_stone_ruin_medium, standing_stone, tower_ruined
    let spec = RegionSpec {
        name: "Emberwood Test".to_string(),
        terrain_type: TerrainType::Highlands,  // Use Highlands to match catalogue biome tags
        mood: "mysterious".to_string(),
        landmarks: vec![
            LandmarkSpec {
                name: "standing_stone".to_string(),
                kind: LandmarkKind::StandingStone,
                description: "A towering standing stone".to_string(),
            },
            LandmarkSpec {
                name: "highlands_tower_ruined".to_string(),
                kind: LandmarkKind::Tower,
                description: "A ruined tower".to_string(),
            },
            LandmarkSpec {
                name: "highlands_shrine_weathered".to_string(),
                kind: LandmarkKind::Shrine,
                description: "A weathered shrine".to_string(),
            },
        ],
        style_hints: StyleHints {
            palette: vec!["green".to_string(), "brown".to_string()],
            density: "medium".to_string(),
            atmosphere: "misty".to_string(),
        },
    };

    // Compile the region
    let result = compile_region(&spec, &catalogue);
    if let Err(errors) = &result {
        for e in errors {
            eprintln!("Compile error: {}", e);
        }
    }
    assert!(result.is_ok(), "Compilation should succeed");

    let world = result.expect("Expected successful compilation");

    // Check that the compiled world has at least one entity
    assert!(
        !world.entities.is_empty(),
        "World should have at least one entity"
    );
}
