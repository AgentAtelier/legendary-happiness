use crate::history_report::HistoryDigestReport;
use anvil_core::HistoryEvent;

/// Build a compact history-digest report from the four authority checkpoints.
/// This is the single reusable helper used by CLI audits and tooling front doors.
pub fn report_history_digest(
    authored_digest: &str,
    plan_digest: &str,
    loaded_events: &[HistoryEvent],
    plan_events: &[HistoryEvent],
) -> HistoryDigestReport {
    let loaded_digest = crate::hashing::history_events_digest(loaded_events);
    let aligned = authored_digest == plan_digest && loaded_digest == plan_digest;
    let events_match = loaded_events == plan_events;
    HistoryDigestReport {
        authored: authored_digest.to_string(),
        plan: plan_digest.to_string(),
        saved: String::new(),
        loaded: loaded_digest,
        aligned,
        events_match,
    }
}

/// Build a history-digest report that includes the save file's own stored digest.
/// Use this for CLI audits that perform full save/load roundtrips.
pub fn report_history_digest_with_save(
    authored_digest: &str,
    plan_digest: &str,
    saved_digest: &str,
    loaded_events: &[HistoryEvent],
    plan_events: &[HistoryEvent],
) -> HistoryDigestReport {
    let loaded_digest = crate::hashing::history_events_digest(loaded_events);
    let aligned = authored_digest == plan_digest
        && loaded_digest == plan_digest
        && (saved_digest.is_empty() || saved_digest == loaded_digest);
    let events_match = loaded_events == plan_events;
    HistoryDigestReport {
        authored: authored_digest.to_string(),
        plan: plan_digest.to_string(),
        saved: saved_digest.to_string(),
        loaded: loaded_digest,
        aligned,
        events_match,
    }
}
