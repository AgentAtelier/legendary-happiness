use anvil_core::{
    ArchetypeTag, AssetPath, AuthoredEntityId, ConnectionId, ConnectionKind,
    Directionality, EntityKind, HistoryEvent, RegionId, StyleHints, TerrainType,
};
use serde::{Deserialize, Serialize};
use std::fmt;
use std::sync::Arc;

// Import from our own modules
use crate::compile_error::CompileError;

// Import anvil_assets for ValidatedCatalogue
use anvil_assets::AssetCatalogue;

/// A catalogue that has passed validation and can be safely used by the compiler.
pub struct ValidatedCatalogue {
    inner: Arc<AssetCatalogue>,
}

impl ValidatedCatalogue {
    /// Create a new ValidatedCatalogue from an AssetCatalogue.
    /// Returns Err if the catalogue fails validation.
    pub fn new(catalogue: AssetCatalogue) -> Result<Self, Vec<CompileError>> {
        // Validate the catalogue paths
        if let Err(e) = catalogue.validate_paths() {
            return Err(vec![CompileError::InvalidSpec(format!(
                "Catalogue validation failed: {}",
                e
            ))]);
        }
        // Note: Additional validation could be added here
        Ok(Self {
            inner: Arc::new(catalogue),
        })
    }

    /// Get a reference to the inner catalogue.
    pub fn inner(&self) -> &AssetCatalogue {
        &self.inner
    }
}

/// The fully compiled and validated world state.
/// This is the output of the world compiler and the input to the runtime.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorldAuthored {
    /// All regions in the world. Indexed by `RegionId::get()` for O(1) lookup.
    pub regions: Vec<Region>,
    /// All authored entities in the world.
    pub entities: Vec<AuthoredEntity>,
    /// All connections between regions in the world.
    pub connections: Vec<AuthoredConnection>,
    /// History events that have occurred in the world, shared via Arc for cheap cloning.
    #[serde(
        default,
        serialize_with = "serialize_history_events",
        deserialize_with = "deserialize_history_events"
    )]
    pub history_events: Arc<Vec<HistoryEvent>>,
    /// Asset reference table mapping entities to their asset entries.
    pub asset_refs: AssetReferenceTable,
    /// Metadata about the compiled world.
    pub metadata: WorldMetadata,
    /// Index from entity ID to position in the `entities` Vec. Enables O(1) entity lookup.
    #[serde(skip)]
    pub entity_index: std::collections::HashMap<AuthoredEntityId, usize>,
    /// Index from connection ID to position in the `connections` Vec. Enables O(1) connection lookup.
    #[serde(skip)]
    pub connection_index: std::collections::HashMap<ConnectionId, usize>,
    /// Index from entity ID to position in the asset_refs entries. Enables O(1) asset lookup.
    #[serde(skip)]
    pub asset_ref_index: std::collections::HashMap<AuthoredEntityId, usize>,
}

// Custom serialization for Arc<Vec<HistoryEvent>>
fn serialize_history_events<S>(events: &Arc<Vec<HistoryEvent>>, serializer: S) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    use serde::Serialize;
    events.serialize(serializer)
}

// Custom deserialization for Arc<Vec<HistoryEvent>>
fn deserialize_history_events<'de, D>(deserializer: D) -> Result<Arc<Vec<HistoryEvent>>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    use serde::Deserialize;
    let events: Vec<HistoryEvent> = Vec::deserialize(deserializer)?;
    Ok(Arc::new(events))
}

/// A region in the world.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Region {
    /// Unique identifier for this region.
    pub id: RegionId,
    /// Human-readable name of the region.
    pub name: String,
    /// The terrain type of the region.
    pub terrain_type: TerrainType,
    /// The mood/atmosphere of the region.
    pub mood: String,
    /// Style hints for asset selection in this region.
    pub style: StyleHints,
}

/// An entity as authored in the world specification.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuthoredEntity {
    /// Unique identifier for this entity.
    pub id: AuthoredEntityId,
    /// Human-readable name of the entity.
    pub name: String,
    /// The kind of entity (landmark, settlement, connection, etc.).
    pub kind: EntityKind,
    /// The region this entity belongs to.
    pub region: RegionId,
    /// The archetype tag for this entity.
    pub archetype: ArchetypeTag,
    /// Description of the entity.
    pub description: String,
}

/// A connection between two regions as authored in the world specification.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuthoredConnection {
    /// Unique identifier for this connection.
    pub id: ConnectionId,
    /// Human-readable name of the connection.
    pub name: String,
    /// The source region.
    pub from_region: RegionId,
    /// The destination region.
    pub to_region: RegionId,
    /// The kind of connection (path, road, bridge, etc.).
    pub kind: ConnectionKind,
    /// The directionality of the connection.
    pub directionality: Directionality,
    /// The entity ID that represents this connection.
    pub entity_id: AuthoredEntityId,
}

/// Table of asset references for entities in the world.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct AssetReferenceTable {
    /// All asset references in the table.
    pub entries: Vec<AssetReference>,
}

impl AssetReferenceTable {
    /// Find an asset reference by entity ID.
    pub fn get(&self, entity_id: AuthoredEntityId) -> Option<&AssetReference> {
        self.entries.iter().find(|a| a.entity_id == entity_id)
    }
    /// Returns the number of entries in the table.
    pub fn len(&self) -> usize {
        self.entries.len()
    }
    /// Returns true if the table has no entries.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

/// A reference to an asset for a specific entity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AssetReference {
    /// The entity this asset reference is for.
    pub entity_id: AuthoredEntityId,
    /// The archetype tag of the asset.
    pub archetype: ArchetypeTag,
    /// The resolved filesystem path to the asset.
    pub resolved_path: AssetPath,
}

/// Metadata about the compiled world.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WorldMetadata {
    /// Hash of the source specification that produced this world.
    pub source_hash: String,
    /// Version of the compiler that produced this world.
    pub compiler_version: String,
    /// Digest of the history events in this world.
    #[serde(default)]
    pub history_events_digest: String,
}

impl fmt::Display for WorldAuthored {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "World(regions={}, entities={}, connections={}, history={})",
            self.regions.len(),
            self.entities.len(),
            self.connections.len(),
            self.history_events.len()
        )
    }
}

impl Default for WorldAuthored {
    fn default() -> Self {
        Self {
            regions: vec![],
            entities: vec![],
            connections: vec![],
            history_events: Arc::new(vec![]),
            asset_refs: AssetReferenceTable::default(),
            metadata: WorldMetadata {
                source_hash: String::new(),
                compiler_version: env!("CARGO_PKG_VERSION").to_string(),
                history_events_digest: String::new(),
            },
            entity_index: std::collections::HashMap::new(),
            connection_index: std::collections::HashMap::new(),
            asset_ref_index: std::collections::HashMap::new(),
        }
    }
}

impl WorldAuthored {
    /// Build lookup indexes for entities, connections, and asset refs.
    /// Call this after constructing a WorldAuthored to enable O(1) lookups.
    pub fn build_indexes(&mut self) {
        self.entity_index = self
            .entities
            .iter()
            .enumerate()
            .map(|(idx, entity)| (entity.id, idx))
            .collect();
        self.connection_index = self
            .connections
            .iter()
            .enumerate()
            .map(|(idx, connection)| (connection.id, idx))
            .collect();
        self.asset_ref_index = self
            .asset_refs
            .entries
            .iter()
            .enumerate()
            .map(|(idx, asset_ref)| (asset_ref.entity_id, idx))
            .collect();
    }

    /// Get a region by its ID.
    pub fn region(&self, id: RegionId) -> Option<&Region> {
        self.regions.get(id.get())
    }

    /// Return an iterator over all entities within a given region.
    pub fn entities_in_region(&self, id: RegionId) -> impl Iterator<Item = &AuthoredEntity> {
        self.entities
            .iter()
            .filter(move |entity| entity.region == id)
    }

    /// Get an entity by its ID using the pre-built index for O(1) lookup.
    pub fn entity(&self, id: AuthoredEntityId) -> Option<&AuthoredEntity> {
        self.entity_index.get(&id).map(|&idx| &self.entities[idx])
    }

    /// Get the asset reference for a given entity using the pre-built index for O(1) lookup.
    pub fn asset_for_entity(&self, id: AuthoredEntityId) -> Option<&AssetReference> {
        self.asset_ref_index.get(&id).map(|&idx| &self.asset_refs.entries[idx])
    }

    /// Get a connection by its ID using the pre-built index for O(1) lookup.
    pub fn connection(&self, id: ConnectionId) -> Option<&AuthoredConnection> {
        self.connection_index.get(&id).map(|&idx| &self.connections[idx])
    }

    /// Returns the total number of entities in the world.
    pub fn entity_count(&self) -> usize {
        self.entities.len()
    }

    /// Replace this world's history events with the provided set (builder pattern).
    ///
    /// Prefer `compile_world_with_history()` when constructing a world from scratch —
    /// it accepts authored events at compile time as a first-class input.
    ///
    /// Use this method only when you need to override an already-compiled world's
    /// history (e.g., in tests or when loading from an external scenario file that
    /// was not available at compile time).  Callers are responsible for calling
    /// `validate()` afterwards.
    pub fn with_history_events(mut self, events: Vec<HistoryEvent>) -> Self {
        self.metadata.history_events_digest = crate::hashing::history_events_digest(&events);
        self.history_events = Arc::new(events);
        self
    }
}
