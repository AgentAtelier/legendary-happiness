//! Cached tag resolver that eliminates per-landmark string allocations.

use anvil_core::ArchetypeTag;
use std::collections::HashMap;

/// Cached tag resolver that eliminates per-landmark string allocations.
///
/// Maintains a reusable `String` buffer and a `HashMap` cache so that
/// valid `(prefix, base)` combinations are constructed and validated
/// only once per compilation. Invalid combinations are also cached (negative caching)
/// to avoid retrying validation for known-bad inputs.
pub struct TagResolver {
    buffer: String,
    cache: HashMap<String, Option<ArchetypeTag>>,
}

impl TagResolver {
    /// Creates a new TagResolver with empty buffer and cache.
    pub fn new() -> Self {
        Self {
            buffer: String::with_capacity(64),
            cache: HashMap::new(),
        }
    }

    /// Private helper: look up the current buffer in the cache, or validate and cache it.
    /// Uses negative caching to remember invalid tag strings and avoid re-validation.
    fn resolve_from_buffer(&mut self) -> Option<ArchetypeTag> {
        if let Some(cached) = self.cache.get(&self.buffer) {
            return cached.clone();
        }
        match ArchetypeTag::new(&self.buffer) {
            Ok(tag) => {
                self.cache.insert(self.buffer.clone(), Some(tag.clone()));
                Some(tag)
            }
            Err(_) => {
                self.cache.insert(self.buffer.clone(), None);
                None
            }
        }
    }

    /// Try to build a valid `ArchetypeTag` from a prefix and a base tag.
    ///
    /// On cache hit, returns the cached tag with zero allocations.
    /// On cache miss, builds the string once, validates it, and caches it.
    pub fn resolve(&mut self, prefix: &str, base: &str) -> Option<ArchetypeTag> {
        self.buffer.clear();
        self.buffer.push_str(prefix);
        self.buffer.push('_');
        self.buffer.push_str(base);

        self.resolve_from_buffer()
    }

    /// Resolve a base tag without a prefix (no leading underscore).
    pub fn resolve_base(&mut self, base: &str) -> Option<ArchetypeTag> {
        self.buffer.clear();
        self.buffer.push_str(base);

        self.resolve_from_buffer()
    }
}

impl Default for TagResolver {
    fn default() -> Self {
        Self::new()
    }
}
