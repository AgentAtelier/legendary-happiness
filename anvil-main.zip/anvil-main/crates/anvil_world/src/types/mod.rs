//! World domain types: regions, entities, settlements, vegetation,
//! damage, and history.

mod error_collector;
mod main;
mod tag_resolver;

pub use error_collector::ErrorCollector;
pub use main::*;
pub use tag_resolver::TagResolver;
