//! Accumulates compilation errors without short-circuiting.

use anvil_core::AnvilCoreError;
use crate::compile_error::CompileError;

/// Accumulates compilation errors without short-circuiting.
///
/// Follows the Anvil multi-error pattern: `validate()` methods push
/// errors into the collector, and the caller decides when to fail.
pub struct ErrorCollector {
    /// The collected compilation errors.
    pub errors: Vec<CompileError>,
}

impl ErrorCollector {
    /// Creates a new, empty ErrorCollector.
    pub fn new() -> Self {
        Self { errors: Vec::new() }
    }

    /// Add a single compilation error to the collector.
    pub fn push(&mut self, error: CompileError) {
        self.errors.push(error);
    }

    /// Add multiple compilation errors from a Vec.
    pub fn extend(&mut self, more_errors: Vec<CompileError>) {
        self.errors.extend(more_errors);
    }

    /// Push all errors from a `Vec<AnvilCoreError>` as `InvalidSpec` errors.
    pub fn extend_core(&mut self, core_errors: Vec<AnvilCoreError>, context: &str) {
        for e in core_errors {
            self.push(CompileError::from_core_error(e, context));
        }
    }

    /// Returns true if any errors have been collected.
    pub fn has_errors(&self) -> bool {
        !self.errors.is_empty()
    }

    /// Convert the collector into a Result: Ok(()) if empty, Err(errors) otherwise.
    pub fn into_result(self) -> Result<(), Vec<CompileError>> {
        if self.errors.is_empty() {
            Ok(())
        } else {
            Err(self.errors)
        }
    }
}

impl Default for ErrorCollector {
    fn default() -> Self {
        Self::new()
    }
}

impl std::iter::Extend<CompileError> for ErrorCollector {
    fn extend<T: IntoIterator<Item = CompileError>>(&mut self, iter: T) {
        self.errors.extend(iter);
    }
}
