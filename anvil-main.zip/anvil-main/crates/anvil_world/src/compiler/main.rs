use crate::compiler::validation::validate_region_landmark_distribution;
use crate::compile_error::CompileError;
use crate::hashing::{StableHash, history_events_digest};
use crate::types::{
    AssetReference, AssetReferenceTable, AuthoredConnection, AuthoredEntity,
    ErrorCollector, Region, TagResolver, WorldAuthored, WorldMetadata,
};
use anvil_assets::AssetCatalogue;
use anvil_core::{
    ArchetypeTag, AssetPath, AuthoredEntityId, ConnectionId, ConnectionSpec, DamageType,
    EntityKind, HistoryEvent, LandmarkKind, RegionId, RegionSpec, SemanticArtifact, TerrainType,
};
use hex;
use std::collections::HashMap;
use std::sync::Arc;

/// Compiles a single region specification into a WorldAuthored.
pub fn compile_region(
    spec: &RegionSpec,
    catalogue: &AssetCatalogue,
) -> Result<WorldAuthored, Vec<CompileError>> {
    compile_world(std::slice::from_ref(spec), &[], catalogue)
}

/// Compiles region and connection specifications into a WorldAuthored.
pub fn compile_world(
    specs: &[RegionSpec],
    connections: &[ConnectionSpec],
    catalogue: &AssetCatalogue,
) -> Result<WorldAuthored, Vec<CompileError>> {
    let mut errors = ErrorCollector::new();
    let mut resolver = TagResolver::new();

    if specs.is_empty() {
        errors.push(CompileError::EmptyWorld);
    }

    let mut regions = Vec::with_capacity(specs.len());
    let mut entities = Vec::new();
    let mut authored_connections = Vec::with_capacity(connections.len());
    let mut asset_refs = Vec::new();
    let mut entity_id_counter = 0_u64;
    let mut name_to_id = HashMap::new();

    // Validate all specs first
    for spec in specs {
        errors.extend_core(spec.validate(), &format!("region '{}' ", spec.name));
    }
    for conn in connections {
        errors.extend_core(conn.validate(), &format!("connection '{}' ", conn.name));
    }
    if errors.has_errors() {
        return Err(errors.errors);
    }

    for (i, spec) in specs.iter().enumerate() {
        let landmark_errors = validate_region_landmark_distribution(spec);
        if !landmark_errors.is_empty() {
            errors.extend(landmark_errors);
            continue;
        }

        if name_to_id.contains_key(&spec.name) {
            errors.push(CompileError::DuplicateRegionName(spec.name.clone()));
            continue;
        }

        let region_id = RegionId::new(i);
        name_to_id.insert(spec.name.clone(), region_id);

        regions.push(Region {
            id: region_id,
            name: spec.name.clone(),
            terrain_type: spec.terrain_type,
            mood: spec.mood.clone(),
            style: spec.style_hints.clone(),
        });

        for landmark in &spec.landmarks {
            let entity_id = AuthoredEntityId::new(entity_id_counter);
            entity_id_counter += 1;

            let candidates = preferred_archetypes(spec.terrain_type, landmark.kind, &mut resolver);
            let Some(asset_entry) =
                resolve_landmark_asset_entry(catalogue, spec.terrain_type, landmark.kind)
            else {
                errors.push(CompileError::UnresolvedArchetypeFamily {
                    landmark: landmark.name.clone(),
                    terrain: spec.terrain_type,
                    candidates: candidates
                        .iter()
                        .map(|tag| tag.as_str().to_string())
                        .collect(),
                });
                continue;
            };

            let archetype = asset_entry.tag.clone();

            entities.push(AuthoredEntity {
                id: entity_id,
                name: landmark.name.clone(),
                kind: EntityKind::Landmark,
                region: region_id,
                archetype: archetype.clone(),
                description: landmark.description.clone(),
            });

            asset_refs.push(AssetReference {
                entity_id,
                archetype,
                // SAFETY: asset_entry.path comes from a validated catalogue.
                // Catalogue paths are validated before use, so AssetPath::new should succeed.
                #[allow(clippy::expect_used)]
                resolved_path: AssetPath::new(&*asset_entry.path)
                    .expect("asset path from catalogue must be valid"),
            });
        }

        let spawn_id = AuthoredEntityId::new(entity_id_counter);
        entity_id_counter += 1;

        entities.push(AuthoredEntity {
            id: spawn_id,
            name: format!("Player Spawn ({})", spec.name),
            kind: EntityKind::SpawnPoint,
            region: region_id,
            // SAFETY: "spawn_point" is a valid archetype tag string (lowercase with underscores).
            #[allow(clippy::expect_used)]
            archetype: ArchetypeTag::new("spawn_point").expect("spawn_point tag should be valid"),
            description: "Default player spawn location".to_string(),
        });
    }

    for (i, connection) in connections.iter().enumerate() {
        let Some(from_region) = name_to_id.get(&connection.from_region).copied() else {
            errors.push(CompileError::UnknownRegionInConnection {
                connection: connection.name.clone(),
                region_name: connection.from_region.clone(),
            });
            continue;
        };

        let Some(to_region) = name_to_id.get(&connection.to_region).copied() else {
            errors.push(CompileError::UnknownRegionInConnection {
                connection: connection.name.clone(),
                region_name: connection.to_region.clone(),
            });
            continue;
        };

        let entity_id = AuthoredEntityId::new(entity_id_counter);
        entity_id_counter += 1;

        entities.push(AuthoredEntity {
            id: entity_id,
            name: connection.name.clone(),
            kind: EntityKind::Connection,
            region: from_region,
            // SAFETY: "connection_marker" is a valid archetype tag string (lowercase with underscores).
            #[allow(clippy::expect_used)]
            archetype: ArchetypeTag::new("connection_marker")
                .expect("connection_marker tag should be valid"),
            description: format!("Connection to {}", connection.to_region),
        });

        authored_connections.push(AuthoredConnection {
            id: ConnectionId::new(i),
            name: connection.name.clone(),
            from_region,
            to_region,
            kind: connection.kind,
            directionality: connection.directionality,
            entity_id,
        });
    }

    let history = generate_history_events(specs, connections);
    let history_digest = history_events_digest(&history);
    let mut world = WorldAuthored {
        regions,
        entities,
        connections: authored_connections,
        history_events: Arc::new(history),
        asset_refs: AssetReferenceTable {
            entries: asset_refs,
        },
        metadata: WorldMetadata {
            source_hash: compute_specs_hash(specs, connections),
            compiler_version: env!("CARGO_PKG_VERSION").to_string(),
            history_events_digest: history_digest,
        },
        entity_index: std::collections::HashMap::new(),
        connection_index: std::collections::HashMap::new(),
        asset_ref_index: std::collections::HashMap::new(),
    };

    // Build indexes for O(1) entity/connection lookup
    world.build_indexes();

    errors.extend(world.validate());
    if errors.has_errors() {
        return Err(errors.errors);
    }
    Ok(world)
}

/// Compile a world from region specs and connections, using the provided authored history
/// events instead of the deterministic synthetic fallback.
///
/// Use this when the authoring layer owns the history (e.g. a scenario with a
/// `history_events.json` file).  The provided events are validated and their digest is
/// stored in `WorldMetadata`.
///
/// If `history_events` is empty, the compiled world will carry no history — unlike
/// `compile_world()`, which always generates synthetic events.  Pass the output of
/// `generate_history_events_for(specs, connections)` explicitly if you want the synthetic
/// fallback with a named call.
pub fn compile_world_with_history(
    specs: &[RegionSpec],
    connections: &[ConnectionSpec],
    catalogue: &AssetCatalogue,
    history_events: Vec<HistoryEvent>,
) -> Result<WorldAuthored, Vec<CompileError>> {
    // Validate all events before proceeding.
    let mut errors = ErrorCollector::new();
    for (i, event) in history_events.iter().enumerate() {
        let history_errors = event.validate();
        if !history_errors.is_empty() {
            errors.push(CompileError::InvalidHistoryEvent {
                index: i,
                message: history_errors
                    .iter()
                    .map(|e| e.to_string())
                    .collect::<Vec<_>>()
                    .join("; "),
            });
        }
    }
    if errors.has_errors() {
        return Err(errors.errors);
    }
    let mut world = compile_world(specs, connections, catalogue)?;
    // Replace the synthetic history with the authored history.
    world.history_events = Arc::new(history_events);
    world.metadata.history_events_digest = history_events_digest(&world.history_events);
    Ok(world)
}

/// Returns the base archetype tags for a given landmark kind.
pub fn base_archetype_tags(kind: LandmarkKind) -> &'static [&'static str] {
    match kind {
        LandmarkKind::Ruin => &["stone_ruin_medium"],
        LandmarkKind::Monument | LandmarkKind::StandingStone => &["standing_stone"],
        LandmarkKind::Settlement => &["settlement_small"],
        LandmarkKind::Tower => &["tower_ruined"],
        LandmarkKind::Shrine => &["shrine_weathered"],
        LandmarkKind::Cave => &["cave_entrance"],
        LandmarkKind::Bridge => &["stone_bridge"],
        _ => &[],
    }
}

/// Returns the asset category for a given landmark kind.
pub fn landmark_asset_category(kind: LandmarkKind) -> anvil_assets::AssetCategory {
    match kind {
        LandmarkKind::Bridge => anvil_assets::AssetCategory::ArchitectureKit,
        _ => anvil_assets::AssetCategory::Landmark,
    }
}

/// Resolves a landmark asset entry from the catalogue based on terrain and kind.
pub fn resolve_landmark_asset_entry(
    catalogue: &AssetCatalogue,
    terrain: TerrainType,
    kind: LandmarkKind,
) -> Option<&anvil_assets::AssetEntry> {
    catalogue
        .find_family_variant(
            landmark_asset_category(kind),
            AssetCatalogue::biome_aliases_for(terrain),
            base_archetype_tags(kind),
        )
        .or_else(|| {
            let base_candidates = base_archetype_tags(kind)
                .iter()
                .map(|tag| {
                    // SAFETY: base_archetype_tags returns valid tag strings from the codebase.
                    #[allow(clippy::expect_used)]
                    ArchetypeTag::new(*tag).expect("base archetype tag should be valid")
                })
                .collect::<Vec<_>>();
            catalogue.resolve_first(&base_candidates)
        })
}

/// Returns the preferred archetype tags for a given terrain type and landmark kind.
pub fn preferred_archetypes(
    terrain: TerrainType,
    kind: LandmarkKind,
    resolver: &mut TagResolver,
) -> Vec<ArchetypeTag> {
    let mut candidates = Vec::new();

    let terrain_prefixes: &[&str] = match terrain {
        TerrainType::Highlands => &["highlands", "mountain"],
        TerrainType::Forest => &["forest", "woodland"],
        TerrainType::Desert => &["desert", "arid"],
        TerrainType::Marsh => &["marsh", "fen"],
        TerrainType::Coast => &["coast", "coastal"],
        _ => &[],
    };

    let bases = base_archetype_tags(kind);

    for prefix in terrain_prefixes {
        for base in bases {
            if let Some(tag) = resolver.resolve(prefix, base) {
                candidates.push(tag);
            }
        }
    }

    for base in bases {
        if let Some(tag) = resolver.resolve_base(base) {
            candidates.push(tag);
        }
    }

    candidates
}

/// Computes a Blake3 hash of the region and connection specifications.
pub fn compute_specs_hash(specs: &[RegionSpec], connections: &[ConnectionSpec]) -> String {
    let mut hasher = blake3::Hasher::new();
    specs.write_stable(&mut hasher);
    connections.write_stable(&mut hasher);
    // Return hex string for backward compatibility with existing metadata format.
    hex::encode(hasher.finalize().as_bytes())
}

/// Converts a hash string to a deterministic seed value.
pub fn hash_to_seed(hash: &str) -> u64 {
    let hex_prefix = if hash.len() >= 16 { &hash[..16] } else { hash };
    u64::from_str_radix(hex_prefix, 16).unwrap_or_else(|e| {
        eprintln!("hash_to_seed: failed to parse '{}': {}", hex_prefix, e);
        0 // deterministic fallback, never a magic constant
    })
}

/// Generate deterministic history events for a world spec set.
///
/// This is the synthetic fallback used by `compile_world()`.  Callers that want
/// to use the synthetic events explicitly (rather than relying on the `compile_world`
/// default) can call this directly and pass the result to `compile_world_with_history()`.
pub fn generate_history_events_for(
    specs: &[RegionSpec],
    connections: &[ConnectionSpec],
) -> Vec<HistoryEvent> {
    generate_history_events(specs, connections)
}

/// Generate deterministic history events for a newly compiled world.
pub fn generate_history_events(
    specs: &[RegionSpec],
    connections: &[ConnectionSpec],
) -> Vec<HistoryEvent> {
    let hash = compute_specs_hash(specs, connections);
    let seed = hash_to_seed(&hash);

    // Simple deterministic RNG using hashing
    let mut next_rand = seed;

    let mut rand_f32 = || {
        // SplitMix64-like deterministic rand
        next_rand = next_rand.wrapping_mul(0x9e3779b97f4a7c15).wrapping_add(1);
        let x = next_rand;
        (x >> 32) as f32 / (u32::MAX as f32)
    };

    let mut events = Vec::new();

    // Track used damage types per region index
    let mut used_damage_per_region: HashMap<usize, Vec<DamageType>> = HashMap::new();

    // Iterate through regions and generate events
    for (region_idx, spec) in specs.iter().enumerate() {
        if spec.landmarks.is_empty() {
            continue; // Skip regions without landmarks
        }

        // Determine number of events for this region (1-3)
        let event_count = 1 + (rand_f32() * 2.0) as usize;

        for i in 0..event_count {
            // Determine damage type based on terrain
            let damage_type = match spec.terrain_type {
                TerrainType::Highlands => {
                    let variants = [
                        DamageType::Earthquake,
                        DamageType::Fire,
                        DamageType::Drought,
                    ];
                    variants[(rand_f32() * 3.0) as usize % 3]
                }
                TerrainType::Forest => {
                    let variants = [DamageType::Fire, DamageType::Flood, DamageType::Drought];
                    variants[(rand_f32() * 3.0) as usize % 3]
                }
                TerrainType::Desert => {
                    let variants = [DamageType::Drought, DamageType::Fire, DamageType::Volcanic];
                    variants[(rand_f32() * 3.0) as usize % 3]
                }
                TerrainType::Marsh => {
                    let variants = [DamageType::Flood, DamageType::Erosion, DamageType::Drought];
                    variants[(rand_f32() * 3.0) as usize % 3]
                }
                TerrainType::Coast => {
                    let variants = [DamageType::Flood, DamageType::Erosion, DamageType::Volcanic];
                    variants[(rand_f32() * 3.0) as usize % 3]
                }
                _ => {
                    // Default damage type for unknown terrain
                    DamageType::Fire
                }
            };

            // Avoid duplicate damage types for same region
            let region_damages = used_damage_per_region
                .entry(region_idx)
                .or_default();
            if region_damages.contains(&damage_type) {
                continue;
            }
            region_damages.push(damage_type);

            // Generate magnitude (0.5 - 0.95)
            let magnitude = 0.5 + rand_f32() * 0.45;

            // Generate radius (60 - 180)
            let radius = 60.0 + rand_f32() * 120.0;

            // Generate epicenter from region index (deterministic fallback)
            let idx = region_idx as f32;
            let epicenter = [idx * 100.0, 0.0, idx * 80.0];

            // Generate tick (deterministic spacing)
            let base_tick = region_idx as u64 * 100;
            let tick_offset = (i as u64 * 40) + (rand_f32() * 20.0) as u64;
            let tick = base_tick + tick_offset;

            events.push(HistoryEvent {
                damage_type,
                magnitude,
                epicenter,
                radius,
                tick,
            });
        }
    }

    // Sort by tick for deterministic ordering
    events.sort_by_key(|e| e.tick);
    events
}
