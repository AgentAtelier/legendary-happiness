//! World compilation module.
//! 
//! Provides the main world compiler and validation utilities.

/// Main world compilation logic.
pub mod main;

/// Region landmark distribution validation.
pub mod validation;

pub use main::*;
pub use validation::validate_region_landmark_distribution;
