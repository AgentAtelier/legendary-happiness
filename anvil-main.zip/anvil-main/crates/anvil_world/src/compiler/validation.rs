//! Region landmark distribution validation.

use anvil_core::{LandmarkKind, RegionSpec, TerrainType};
use crate::compile_error::CompileError;

/// Validate that a region spec has the required landmark distribution.
/// Returns a list of compilation errors if the distribution is invalid.
pub fn validate_region_landmark_distribution(spec: &RegionSpec) -> Vec<CompileError> {
    let mut errors = Vec::new();
    let mut marker = 0usize;
    let mut major = 0usize;
    let mut terrain_affine = 0usize;

    for landmark in &spec.landmarks {
        match landmark.kind {
            LandmarkKind::StandingStone | LandmarkKind::Monument | LandmarkKind::Shrine => {
                marker += 1;
            }
            _ => {}
        }

        match landmark.kind {
            LandmarkKind::Tower
            | LandmarkKind::Settlement
            | LandmarkKind::Ruin
            | LandmarkKind::Cave
            | LandmarkKind::Bridge => {
                major += 1;
            }
            _ => {}
        }

        let matches_terrain = match spec.terrain_type {
            TerrainType::Highlands => matches!(
                landmark.kind,
                LandmarkKind::Tower
                    | LandmarkKind::Monument
                    | LandmarkKind::Shrine
                    | LandmarkKind::Cave
            ),
            TerrainType::Forest => matches!(
                landmark.kind,
                LandmarkKind::Settlement
                    | LandmarkKind::Tower
                    | LandmarkKind::Shrine
                    | LandmarkKind::Cave
            ),
            TerrainType::Desert => matches!(
                landmark.kind,
                LandmarkKind::Monument
                    | LandmarkKind::Shrine
                    | LandmarkKind::Bridge
                    | LandmarkKind::Ruin
            ),
            TerrainType::Marsh => matches!(
                landmark.kind,
                LandmarkKind::StandingStone
                    | LandmarkKind::Shrine
                    | LandmarkKind::Bridge
                    | LandmarkKind::Cave
            ),
            TerrainType::Coast => matches!(
                landmark.kind,
                LandmarkKind::Bridge
                    | LandmarkKind::Cave
                    | LandmarkKind::Shrine
                    | LandmarkKind::Tower
            ),
            _ => false,
        };

        if matches_terrain {
            terrain_affine += 1;
        }
    }

    if marker == 0 {
        errors.push(CompileError::InvalidLandmarkDistribution {
            region: spec.name.clone(),
            reason: "needs at least one marker landmark (standing_stone, monument, or shrine)"
                .to_string(),
        });
    }

    if major == 0 {
        errors.push(CompileError::InvalidLandmarkDistribution {
            region: spec.name.clone(),
            reason: "needs at least one major landmark (tower, settlement, ruin, cave, or bridge)"
                .to_string(),
        });
    }

    if terrain_affine == 0 {
        errors.push(CompileError::InvalidLandmarkDistribution {
            region: spec.name.clone(),
            reason: format!(
                "needs at least one terrain-affine landmark for {:?}",
                spec.terrain_type
            ),
        });
    }

    errors
}
