//! Deterministic, allocation‑free hashing for world specs and history events.
//!
//! The `StableHash` trait replaces `serde_json::to_string` for hashing,
//! eliminating temporary `String` allocations while preserving byte‑identical
//! output across runs.

use anvil_core::{ConnectionSpec, DamageType, HistoryEvent, RegionSpec, TerrainType};
use blake3::Hasher;

/// A type that can be hashed deterministically for compilation fingerprints.
pub trait StableHash {
    /// Write a stable hash representation to the hasher.
    fn write_stable(&self, hasher: &mut Hasher);
}

impl StableHash for str {
    fn write_stable(&self, hasher: &mut Hasher) {
        hasher.update(self.as_bytes());
        hasher.update(&[0xFF]); // delimiter prevents collisions: "ab"+"c" != "a"+"bc"
    }
}

impl StableHash for String {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.as_str().write_stable(hasher);
    }
}

impl StableHash for u64 {
    fn write_stable(&self, hasher: &mut Hasher) {
        hasher.update(&self.to_le_bytes());
    }
}

impl StableHash for u32 {
    fn write_stable(&self, hasher: &mut Hasher) {
        hasher.update(&self.to_le_bytes());
    }
}

impl StableHash for f32 {
    fn write_stable(&self, hasher: &mut Hasher) {
        hasher.update(&self.to_le_bytes());
    }
}

impl<T: StableHash, const N: usize> StableHash for [T; N] {
    fn write_stable(&self, hasher: &mut Hasher) {
        for item in self {
            item.write_stable(hasher);
        }
    }
}

impl<T: StableHash> StableHash for [T] {
    fn write_stable(&self, hasher: &mut Hasher) {
        for item in self {
            item.write_stable(hasher);
        }
    }
}

impl<T: StableHash> StableHash for Vec<T> {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.as_slice().write_stable(hasher);
    }
}

impl<T: StableHash> StableHash for Option<T> {
    fn write_stable(&self, hasher: &mut Hasher) {
        match self {
            Some(v) => {
                hasher.update(&[1]);
                v.write_stable(hasher);
            }
            None => {
                hasher.update(&[0]);
            }
        }
    }
}

impl StableHash for TerrainType {
    fn write_stable(&self, hasher: &mut Hasher) {
        // Use the Display representation which is deterministic and stable.
        self.to_string().write_stable(hasher);
    }
}

impl StableHash for DamageType {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.to_string().write_stable(hasher);
    }
}

impl StableHash for HistoryEvent {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.damage_type.write_stable(hasher);
        self.magnitude.write_stable(hasher);
        self.epicenter.write_stable(hasher);
        self.radius.write_stable(hasher);
        self.tick.write_stable(hasher);
    }
}

impl StableHash for RegionSpec {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.name.write_stable(hasher);
        self.terrain_type.write_stable(hasher);
        self.mood.write_stable(hasher);
        self.landmarks.write_stable(hasher);
        // style_hints are not hashed — they are presentation hints, not
        // structural content. If future audits require them, add them here.
    }
}

impl StableHash for ConnectionSpec {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.name.write_stable(hasher);
        self.from_region.write_stable(hasher);
        self.to_region.write_stable(hasher);
        self.kind.write_stable(hasher);
        self.directionality.write_stable(hasher);
    }
}

impl StableHash for anvil_core::LandmarkSpec {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.name.write_stable(hasher);
        self.kind.write_stable(hasher);
        self.description.write_stable(hasher);
    }
}

impl StableHash for anvil_core::LandmarkKind {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.to_string().write_stable(hasher);
    }
}

impl StableHash for anvil_core::ConnectionKind {
    fn write_stable(&self, hasher: &mut Hasher) {
        self.to_string().write_stable(hasher);
    }
}

impl StableHash for anvil_core::Directionality {
    fn write_stable(&self, hasher: &mut Hasher) {
        match self {
            anvil_core::Directionality::Bidirectional => "bidirectional".write_stable(hasher),
            anvil_core::Directionality::OneWay => "one_way".write_stable(hasher),
            _ => "unknown".write_stable(hasher),
        }
    }
}

/// Compute a 32‑byte blake3 hash of anything implementing `StableHash`.
pub fn stable_hash(value: &(impl StableHash + ?Sized)) -> [u8; 32] {
    let mut hasher = Hasher::new();
    value.write_stable(&mut hasher);
    *hasher.finalize().as_bytes()
}

/// Compute a hex‑encoded stable hash string (for use in metadata fields).
pub fn stable_hash_hex(value: &(impl StableHash + ?Sized)) -> String {
    hex::encode(stable_hash(value))
}

/// Compute a digest string for a slice of history events.
pub fn history_events_digest(events: &[HistoryEvent]) -> String {
    stable_hash_hex(events)
}
