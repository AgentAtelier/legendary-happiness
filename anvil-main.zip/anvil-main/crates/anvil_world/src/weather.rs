//! Weather state for simulation contexts.

use serde::{Deserialize, Serialize};

/// Weather state that can be passed to simulation systems.
/// This is a plain data struct with no behavior, suitable for
/// being stored in WorldRuntime and accessed by systems.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WeatherState {
    /// Temperature in °C
    pub temperature: f32,
    /// Humidity in [0.0, 1.0]
    pub humidity: f32,
    /// Pressure in hPa-like units
    pub pressure: f32,
    /// Wind speed in m/s
    pub wind_speed: f32,
    /// Accumulated precipitation in mm
    pub accumulated_precipitation: f32,
}

impl Default for WeatherState {
    fn default() -> Self {
        Self {
            temperature: 14.0,
            humidity: 0.45,
            pressure: 1013.0,
            wind_speed: 2.5,
            accumulated_precipitation: 0.0,
        }
    }
}
