// PLACEHOLDER FROM forge_world/src/lib.rs (DemoVistaLayout subsystem) as of Forge snapshot.
//
// Review: PD-001 in PLACEHOLDER_DEBT.md. Trigger: Forgeborn GDD "First-hour player experience" drafted.

use anvil_core::{ArchetypeTag, ConnectionId, RegionId};
use serde::{Deserialize, Serialize};

/// The DemoVista layout configuration.
/// This is a placeholder port from the Forge codebase that will be fully
/// integrated once the Forgeborn GDD's "First-hour player experience" is drafted.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DemoVistaLayout {
    /// The central hub region where the player starts.
    pub hub_region: RegionId,
    /// Spoke regions radiating from the hub.
    pub spoke_regions: Vec<RegionId>,
    /// Connections between hub and spokes.
    pub hub_connections: Vec<ConnectionId>,
    /// Decoration profiles for each region type.
    pub decoration_profiles: Vec<DemoVistaDecorationProfile>,
    /// Lighting configuration.
    pub lighting: DemoVistaLighting,
}

/// Decoration profile for a DemoVista region.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DemoVistaDecorationProfile {
    /// The archetype tag for the region this profile applies to.
    pub region_archetype: ArchetypeTag,
    /// The density of decorations in this region.
    pub density: f32,
    /// The archetype tags for decorations to spawn.
    pub archetypes: Vec<ArchetypeTag>,
    /// Minimum scale factor for spawned decorations.
    pub min_scale: f32,
    /// Maximum scale factor for spawned decorations.
    pub max_scale: f32,
}

/// Lighting configuration for DemoVista.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DemoVistaLighting {
    /// RGB ambient light color.
    pub ambient_color: [f32; 3],
    /// Ambient light intensity multiplier.
    pub ambient_intensity: f32,
    /// Normalized direction vector for the sun.
    pub sun_direction: [f32; 3],
    /// RGB sun light color.
    pub sun_color: [f32; 3],
    /// Sun light intensity multiplier.
    pub sun_intensity: f32,
}

impl Default for DemoVistaLayout {
    fn default() -> Self {
        Self {
            hub_region: RegionId::new(0),
            spoke_regions: vec![
                RegionId::new(1),
                RegionId::new(2),
                RegionId::new(3),
                RegionId::new(4),
            ],
            hub_connections: vec![
                ConnectionId::new(0),
                ConnectionId::new(1),
                ConnectionId::new(2),
                ConnectionId::new(3),
            ],
            decoration_profiles: Vec::new(),
            lighting: DemoVistaLighting {
                ambient_color: [0.5, 0.6, 0.7],
                ambient_intensity: 0.3,
                sun_direction: [0.5, -0.7, 0.5],
                sun_color: [1.0, 0.9, 0.8],
                sun_intensity: 1.5,
            },
        }
    }
}

/// Create a basic DemoVista layout.
pub fn create_demo_vista_layout() -> DemoVistaLayout {
    DemoVistaLayout::default()
}
