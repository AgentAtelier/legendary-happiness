//! Compilation error types for world compilation.

use anvil_core::{AnvilCoreError, AuthoredEntityId, ConnectionId, RegionId, TerrainType};
use serde::{Deserialize, Serialize};
use std::fmt;

/// Errors that can occur during world compilation.
#[non_exhaustive]
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CompileError {
    /// A region specification failed validation.
    InvalidSpec(String),

    /// A region has an invalid landmark distribution (e.g., missing required landmark roles).
    InvalidLandmarkDistribution {
        /// The name of the region with invalid distribution.
        region: String,
        /// The reason for the invalid distribution.
        reason: String,
    },

    /// No catalogue archetype could be resolved for a landmark in a specific terrain.
    UnresolvedArchetypeFamily {
        /// The name of the landmark.
        landmark: String,
        /// The terrain type where the landmark is located.
        terrain: TerrainType,
        /// The candidate archetype tags that were tried.
        candidates: Vec<String>,
    },

    /// An entity ID was used more than once.
    DuplicateEntityId(AuthoredEntityId),

    /// The computed history events digest does not match the stored metadata.
    HistoryEventsDigestMismatch {
        /// The metadata's stored digest.
        metadata: String,
        /// The actual computed digest.
        actual: String,
    },

    /// A region name was used more than once.
    DuplicateRegionName(String),

    /// An entity references a region that does not exist.
    DanglingRegionRef {
        /// The entity that has the dangling reference.
        entity_id: AuthoredEntityId,
        /// The non-existent region being referenced.
        region_id: RegionId,
    },

    /// An entity has an asset reference but no corresponding asset exists.
    DanglingAssetRef {
        /// The entity with the dangling asset reference.
        entity_id: AuthoredEntityId,
    },

    /// A connection references a region that does not exist.
    UnknownRegionInConnection {
        /// The name of the connection.
        connection: String,
        /// The name of the unknown region.
        region_name: String,
    },

    /// A connection references a region that does not exist in the compiled world.
    DanglingConnectionRegion {
        /// The connection ID.
        connection_id: ConnectionId,
        /// The non-existent region being referenced.
        region_id: RegionId,
    },

    /// A connection references an entity that does not exist.
    DanglingConnectionEntity {
        /// The connection ID.
        connection_id: ConnectionId,
        /// The non-existent entity being referenced.
        entity_id: AuthoredEntityId,
    },

    /// A connection ID was used more than once.
    DuplicateConnectionId(ConnectionId),

    /// An entity is missing a required asset reference.
    MissingAssetRef {
        /// The entity missing the asset reference.
        entity_id: AuthoredEntityId,
    },

    /// A history event at a specific index is invalid.
    InvalidHistoryEvent {
        /// The index of the invalid event.
        index: usize,
        /// The validation error message.
        message: String,
    },

    /// The compiled world has no regions.
    EmptyWorld,

    /// A region in the compiled world is not reachable from the starting region.
    UnreachableRegion(String),
}

impl CompileError {
    /// Returns the error code for this compilation error.
    pub fn error_code(&self) -> &'static str {
        match self {
            CompileError::EmptyWorld => "E100",
            CompileError::DuplicateEntityId(_) => "E101",
            CompileError::DuplicateRegionName(_) => "E102",
            CompileError::DanglingRegionRef { .. } => "E103",
            CompileError::UnknownRegionInConnection { .. } => "E103",
            CompileError::DanglingConnectionRegion { .. } => "E103",
            CompileError::DanglingAssetRef { .. } => "E104",
            CompileError::DanglingConnectionEntity { .. } => "E104",
            CompileError::MissingAssetRef { .. } => "E111",
            CompileError::UnreachableRegion(_) => "E107",
            CompileError::InvalidSpec(_) => "E100",
            CompileError::InvalidLandmarkDistribution { .. } => "E106",
            CompileError::UnresolvedArchetypeFamily { .. } => "E105",
            CompileError::HistoryEventsDigestMismatch { .. } => "E108",
            CompileError::InvalidHistoryEvent { .. } => "E112",
            CompileError::DuplicateConnectionId(_) => "E110",
        }
    }

    /// Joins multiple errors into a single message.
    /// Note: ErrorCollector::extend_core is preferred for multi-error scenarios
    /// as it preserves individual error context.
    pub fn from_errors(errors: Vec<AnvilCoreError>) -> Self {
        let messages: Vec<_> = errors.iter().map(|e| e.to_string()).collect();
        CompileError::InvalidSpec(messages.join("; "))
    }

    /// Wrap a core error with context and convert to a CompileError.
    pub fn from_core_error(error: AnvilCoreError, context: &str) -> Self {
        CompileError::InvalidSpec(format!("[{}] {}", context, error))
    }
}

impl fmt::Display for CompileError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let code = self.error_code();
        match self {
            CompileError::InvalidSpec(msg) => {
                write!(f, "[{}] region spec validation failed: {}", code, msg)
            }
            CompileError::InvalidLandmarkDistribution { region, reason } => {
                write!(
                    f,
                    "[{}] region '{}' has invalid landmark distribution: {}",
                    code, region, reason
                )
            }
            CompileError::UnresolvedArchetypeFamily {
                landmark,
                terrain,
                candidates,
            } => write!(
                f,
                "[{}] no catalogue archetype resolved for landmark '{}' in terrain '{:?}'; candidates={:?}",
                code, landmark, terrain, candidates
            ),
            CompileError::DuplicateEntityId(id) => {
                write!(f, "[{}] duplicate entity ID: {:?}", code, id)
            }
            CompileError::HistoryEventsDigestMismatch { metadata, actual } => write!(
                f,
                "[{}] history events digest mismatch: metadata={}, actual={}",
                code, metadata, actual
            ),
            CompileError::DuplicateRegionName(name) => {
                write!(f, "[{}] duplicate region name: {}", code, name)
            }
            CompileError::DanglingRegionRef {
                entity_id,
                region_id,
            } => write!(
                f,
                "[{}] entity {:?} references non-existent region {:?}",
                code, entity_id, region_id
            ),
            CompileError::DanglingAssetRef { entity_id } => write!(
                f,
                "[{}] asset reference points to non-existent entity {:?}",
                code, entity_id
            ),
            CompileError::UnknownRegionInConnection {
                connection,
                region_name,
            } => write!(
                f,
                "[{}] connection '{}' references unknown region '{}'",
                code, connection, region_name
            ),
            CompileError::DanglingConnectionRegion {
                connection_id,
                region_id,
            } => write!(
                f,
                "[{}] connection {:?} references non-existent region {:?}",
                code, connection_id, region_id
            ),
            CompileError::DanglingConnectionEntity {
                connection_id,
                entity_id,
            } => write!(
                f,
                "[{}] connection {:?} references non-existent entity {:?}",
                code, connection_id, entity_id
            ),
            CompileError::DuplicateConnectionId(id) => {
                write!(f, "[{}] duplicate connection ID: {:?}", code, id)
            }
            CompileError::MissingAssetRef { entity_id } => write!(
                f,
                "[{}] missing asset reference for entity {:?}",
                code, entity_id
            ),
            CompileError::InvalidHistoryEvent { index, message } => write!(
                f,
                "[{}] history event at index {} is invalid: {}",
                code, index, message
            ),
            CompileError::EmptyWorld => write!(f, "[{}] compiled world has no regions", code),
            CompileError::UnreachableRegion(name) => write!(
                f,
                "[{}] region '{}' is unreachable from the starting region",
                code, name
            ),
        }
    }
}

impl std::error::Error for CompileError {}

/// Validation errors for world compilation.
/// TODO: migrate to anvil_core::ValidationErrors (Sprint 5)
pub type ValidationErrors = Vec<CompileError>;
