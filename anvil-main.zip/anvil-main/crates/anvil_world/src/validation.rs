use crate::compile_error::{CompileError, ValidationErrors};
use crate::types::{ErrorCollector, WorldAuthored};
use anvil_core::{Directionality, EntityKind, RegionId};
use std::collections::{HashMap, HashSet, VecDeque};

impl WorldAuthored {
    /// Validates the compiled world, checking for structural errors and inconsistencies.
    /// Returns a Vec of all encountered CompileErrors.
    pub fn validate(&self) -> ValidationErrors {
        let mut errors = ErrorCollector::new();

        if self.regions.is_empty() {
            errors.push(CompileError::EmptyWorld);
        }

        // Build sets once for efficient lookups
        let region_ids: HashSet<RegionId> = self.regions.iter().map(|r| r.id).collect();
        let entity_ids: HashSet<_> = self.entities.iter().map(|e| e.id).collect();
        let asset_ref_entity_ids: HashSet<_> = self
            .asset_refs
            .entries
            .iter()
            .map(|ar| ar.entity_id)
            .collect();

        // Check for duplicate region names
        let mut seen_region_names = HashSet::new();
        for region in &self.regions {
            if !seen_region_names.insert(&region.name) {
                errors.push(CompileError::DuplicateRegionName(region.name.clone()));
            }
        }

        // Check for duplicate connection IDs
        let mut seen_connection_ids = HashSet::new();
        for connection in &self.connections {
            if !seen_connection_ids.insert(connection.id) {
                errors.push(CompileError::DuplicateConnectionId(connection.id));
            }
        }

        // Check for duplicate entity IDs and other entity-related issues
        let mut seen_entity_ids = HashSet::new();
        for entity in &self.entities {
            // Check duplicate entity IDs
            if !seen_entity_ids.insert(entity.id) {
                errors.push(CompileError::DuplicateEntityId(entity.id));
            }

            // Check region reference is valid
            if !region_ids.contains(&entity.region) {
                errors.push(CompileError::DanglingRegionRef {
                    entity_id: entity.id,
                    region_id: entity.region,
                });
            }

            // Check landmark entities have asset references
            if matches!(entity.kind, EntityKind::Landmark)
                && !asset_ref_entity_ids.contains(&entity.id)
            {
                errors.push(CompileError::MissingAssetRef {
                    entity_id: entity.id,
                });
            }
        }

        // Check asset refs point to valid entities
        for asset_ref in &self.asset_refs.entries {
            if !entity_ids.contains(&asset_ref.entity_id) {
                errors.push(CompileError::DanglingAssetRef {
                    entity_id: asset_ref.entity_id,
                });
            }
        }

        // Check connections
        for connection in &self.connections {
            // Check region references are valid
            if !region_ids.contains(&connection.from_region) {
                errors.push(CompileError::DanglingConnectionRegion {
                    connection_id: connection.id,
                    region_id: connection.from_region,
                });
            }

            if !region_ids.contains(&connection.to_region) {
                errors.push(CompileError::DanglingConnectionRegion {
                    connection_id: connection.id,
                    region_id: connection.to_region,
                });
            }

            // Check entity reference is valid
            if !entity_ids.contains(&connection.entity_id) {
                errors.push(CompileError::DanglingConnectionEntity {
                    connection_id: connection.id,
                    entity_id: connection.entity_id,
                });
            }
        }

        // Check history events
        for (index, event) in self.history_events.iter().enumerate() {
            let history_errors: Vec<anvil_core::AnvilCoreError> = event.validate();
            if !history_errors.is_empty() {
                errors.push(CompileError::InvalidHistoryEvent {
                    index,
                    message: history_errors
                        .iter()
                        .map(|e: &anvil_core::AnvilCoreError| e.to_string())
                        .collect::<Vec<_>>()
                        .join("; "),
                });
            }
        }

        let actual_digest = crate::hashing::history_events_digest(&self.history_events);
        if self.metadata.history_events_digest != actual_digest {
            errors.push(CompileError::HistoryEventsDigestMismatch {
                metadata: self.metadata.history_events_digest.clone(),
                actual: actual_digest,
            });
        }

        if let Err(e) = self.check_reachability() {
            errors.push(e);
        }

        errors.errors
    }

    /// Checks that all regions in the world are reachable from the first region via connections.
    /// Uses BFS traversal starting from region 0.
    fn check_reachability(&self) -> Result<(), CompileError> {
        if self.regions.len() <= 1 {
            return Ok(());
        }

        // Build a mapping from RegionId to its index in the regions vector.
        let id_to_idx: HashMap<RegionId, usize> = self
            .regions
            .iter()
            .enumerate()
            .map(|(i, r)| (r.id, i))
            .collect();

        let mut visited = vec![false; self.regions.len()];
        let mut queue = VecDeque::new();

        // Start BFS from the first region (index 0).
        visited[0] = true;
        queue.push_back(0usize);

        while let Some(current_idx) = queue.pop_front() {
            let current_id = self.regions[current_idx].id;

            for connection in &self.connections {
                // Determine the neighbour region ID.
                let neighbour_id = if connection.from_region == current_id {
                    Some(connection.to_region)
                } else if connection.to_region == current_id
                    && connection.directionality == Directionality::Bidirectional
                {
                    Some(connection.from_region)
                } else {
                    None
                };

                // Look up the neighbour's index and enqueue if unvisited.
                if let Some(n_id) = neighbour_id
                    && let Some(&n_idx) = id_to_idx.get(&n_id)
                    && !visited[n_idx]
                {
                    visited[n_idx] = true;
                    queue.push_back(n_idx);
                }
            }
        }

        // Report any region that was never visited.
        for (index, reached) in visited.iter().enumerate() {
            if !reached {
                return Err(CompileError::UnreachableRegion(
                    self.regions[index].name.clone(),
                ));
            }
        }

        Ok(())
    }
}
