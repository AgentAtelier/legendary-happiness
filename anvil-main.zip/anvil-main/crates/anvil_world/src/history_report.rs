//! History digest report for world compilation.

use serde::{Deserialize, Serialize};
use std::fmt;

/// Compact report of history-events digest alignment across the authority chain.
/// Produced by `report_history_digest` and consumed by CLI audits.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HistoryDigestReport {
    /// Digest stored in WorldAuthored metadata.
    pub authored: String,
    /// Digest stored in AssemblyPlan metadata.
    pub plan: String,
    /// Digest stored in the save file itself. Empty for legacy saves.
    pub saved: String,
    /// Digest recomputed from loaded/persisted history events.
    pub loaded: String,
    /// True when authored, plan, saved, and loaded all agree.
    pub aligned: bool,
    /// True when the loaded events vector exactly matches the plan events.
    pub events_match: bool,
}

impl HistoryDigestReport {
    /// Returns formatted lines suitable for CLI audit output.
    pub fn audit_lines(&self) -> Vec<String> {
        let mut lines = vec![
            format!("  authored_history_events_digest: {}", self.authored),
            format!("  plan_history_events_digest: {}", self.plan),
        ];
        if !self.saved.is_empty() {
            lines.push(format!("  saved_history_events_digest: {}", self.saved));
        }
        lines.extend([
            format!("  loaded_history_events_digest: {}", self.loaded),
            format!(
                "  history_digest_alignment: {}",
                if self.aligned { "ok" } else { "FAIL" }
            ),
            format!("  history_events_persisted: {}", self.events_match),
        ]);
        lines
    }
}

impl fmt::Display for HistoryDigestReport {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(f, "authored_history_events_digest: {}", self.authored)?;
        writeln!(f, "plan_history_events_digest: {}", self.plan)?;
        if !self.saved.is_empty() {
            writeln!(f, "saved_history_events_digest: {}", self.saved)?;
        }
        writeln!(f, "loaded_history_events_digest: {}", self.loaded)?;
        write!(
            f,
            "history_digest_alignment: {}",
            if self.aligned { "ok" } else { "FAIL" }
        )?;
        if !self.events_match {
            write!(f, " (events_changed)")?;
        }
        Ok(())
    }
}
