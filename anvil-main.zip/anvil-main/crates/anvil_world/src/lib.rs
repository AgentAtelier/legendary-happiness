#![deny(warnings)]
#![deny(missing_docs)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

//! # anvil_world
//!
//! Deterministic world compiler for the Anvil pipeline.
//!
//! Takes authored `RegionSpec`s, `ConnectionSpec`s, and an
//! `AssetCatalogue`, and produces a fully compiled, validated
//! `WorldAuthored` structure.
//!
//! Same inputs → byte‑identical outputs.  All validation errors
//! are collected before failing (multi‑error pattern).

pub mod types;
pub use types::{
    AssetReference, AssetReferenceTable, AuthoredConnection, AuthoredEntity,
    ErrorCollector, Region, TagResolver, ValidatedCatalogue, WorldAuthored,
    WorldMetadata,
};

pub mod compile_error;
pub use compile_error::{CompileError, ValidationErrors};

pub mod history_report;
pub use history_report::HistoryDigestReport;

pub mod compiler;
pub use compiler::{
    base_archetype_tags, compile_region, compile_world, compile_world_with_history,
    generate_history_events, preferred_archetypes, resolve_landmark_asset_entry,
};

/// Vista generation for demo purposes.
pub mod vista;
pub use vista::{create_demo_vista_layout, DemoVistaDecorationProfile, DemoVistaLayout, DemoVistaLighting};

/// Hashing utilities for world data.
pub mod hashing;
pub use hashing::{StableHash, history_events_digest};

/// History reporting utilities.
pub mod history;
pub use history::{report_history_digest, report_history_digest_with_save};

/// World validation utilities.
pub mod validation;

#[cfg(test)]
mod tests {
    use super::*;
    use anvil_assets::{AssetCatalogue, AssetEntry, AssetKind};
    use anvil_core::{
        ArchetypeTag, ConnectionKind, ConnectionSpec, Directionality, EntityKind, HistoryEvent,
        LandmarkKind, LandmarkSpec, RegionSpec, StyleHints, TerrainType,
    };
    use std::collections::HashSet;
    use std::path::PathBuf;
    use std::sync::Arc;

    fn make_test_spec(name: &str, mood: &str, kind: LandmarkKind) -> RegionSpec {
        RegionSpec {
            name: name.to_string(),
            terrain_type: TerrainType::Highlands,
            mood: mood.to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: format!("{name} Primary"),
                    kind,
                    description: "Primary landmark".to_string(),
                },
                LandmarkSpec {
                    name: format!("{name} Tower"),
                    kind: LandmarkKind::Tower,
                    description: "Secondary landmark".to_string(),
                },
                LandmarkSpec {
                    name: format!("{name} Marker"),
                    kind: LandmarkKind::StandingStone,
                    description: "Marker landmark".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["grey-green".to_string()],
                density: "sparse".to_string(),
                atmosphere: "misty".to_string(),
            },
        }
    }

    fn make_test_catalogue() -> AssetCatalogue {
        AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("standing_stone"),
                path: Arc::new(PathBuf::from("meshes/stone.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 3.0,
            },
            AssetEntry {
                tag: tag("tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
            AssetEntry {
                tag: tag("stone_ruin_medium"),
                path: Arc::new(PathBuf::from("meshes/ruin.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 5.0,
            },
            AssetEntry {
                tag: tag("settlement_small"),
                path: Arc::new(PathBuf::from("meshes/settlement.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 7.0,
            },
        ])
    }

    fn tag(s: &str) -> ArchetypeTag {
        ArchetypeTag::new(s).unwrap_or_else(|e| panic!("invalid test tag '{s}': {e}"))
    }

    #[test]
    fn resolve_landmark_asset_entry_prefers_catalogue_family_variant() {
        use anvil_assets::AssetCatalogue;
        let catalogue = AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("forest_tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/forest_tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
            AssetEntry {
                tag: tag("tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
        ]);

        let entry =
            resolve_landmark_asset_entry(&catalogue, TerrainType::Forest, LandmarkKind::Tower)
                .expect("tower should resolve");

        assert_eq!(entry.tag.as_str(), "forest_tower_ruined");
    }

    #[test]
    fn preferred_archetypes_fall_back_to_base_tags() {
        let mut resolver = TagResolver::new();
        let candidates =
            preferred_archetypes(TerrainType::Forest, LandmarkKind::Tower, &mut resolver);
        let values: Vec<_> = candidates.iter().map(|tag| tag.as_str()).collect();

        assert!(values.contains(&"forest_tower_ruined"));
        assert!(values.contains(&"woodland_tower_ruined"));
        assert!(values.contains(&"tower_ruined"));
    }

    #[test]
    fn preferred_archetypes_cover_new_schema_kinds() {
        let mut resolver = TagResolver::new();
        let shrine =
            preferred_archetypes(TerrainType::Highlands, LandmarkKind::Shrine, &mut resolver);
        let cave = preferred_archetypes(TerrainType::Forest, LandmarkKind::Cave, &mut resolver);
        let bridge = preferred_archetypes(TerrainType::Coast, LandmarkKind::Bridge, &mut resolver);

        let shrine_values: Vec<_> = shrine.iter().map(|tag| tag.as_str()).collect();
        let cave_values: Vec<_> = cave.iter().map(|tag| tag.as_str()).collect();
        let bridge_values: Vec<_> = bridge.iter().map(|tag| tag.as_str()).collect();

        assert!(shrine_values.contains(&"highlands_shrine_weathered"));
        assert!(shrine_values.contains(&"shrine_weathered"));
        assert!(cave_values.contains(&"forest_cave_entrance"));
        assert!(cave_values.contains(&"cave_entrance"));
        assert!(bridge_values.contains(&"coast_stone_bridge"));
        assert!(bridge_values.contains(&"stone_bridge"));
    }

    #[test]
    fn compiles_valid_spec() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        assert_eq!(world.regions.len(), 1);
        assert_eq!(world.regions[0].name, "Test Highlands");
        assert_eq!(world.entities.len(), 4);
        assert_eq!(world.connections.len(), 0);
        assert_eq!(world.asset_refs.entries.len(), 3);
    }

    #[test]
    fn compiles_multi_region_world() {
        let specs = vec![
            make_test_spec("Misty Highlands", "brooding", LandmarkKind::Monument),
            make_test_spec("Dark Forest", "ominous", LandmarkKind::Settlement),
        ];
        let connections = vec![ConnectionSpec {
            name: "Highland Path".to_string(),
            from_region: "Misty Highlands".to_string(),
            to_region: "Dark Forest".to_string(),
            kind: ConnectionKind::Path,
            directionality: Directionality::Bidirectional,
        }];

        let world = compile_world(&specs, &connections, &make_test_catalogue())
            .expect("multi-region world should compile");

        assert_eq!(world.regions.len(), 2);
        assert_eq!(world.connections.len(), 1);
        assert!(
            world
                .entities
                .iter()
                .any(|entity| entity.kind == EntityKind::Connection),
            "expected a connection entity"
        );
    }

    #[test]
    fn entity_ids_are_unique() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        let mut ids: Vec<_> = world.entities.iter().map(|entity| entity.id).collect();
        ids.sort_by_key(|id| id.get());
        ids.dedup();

        assert_eq!(ids.len(), world.entities.len());
    }

    #[test]
    fn all_entities_reference_existing_region() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        for entity in &world.entities {
            assert!(
                world.region(entity.region).is_some(),
                "entity {:?} references non-existent region {:?}",
                entity.id,
                entity.region,
            );
        }
    }

    #[test]
    fn rejects_region_with_no_marker_role() {
        let spec = RegionSpec {
            name: "No Marker".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "brooding".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Settlement".to_string(),
                    kind: LandmarkKind::Settlement,
                    description: "settlement".to_string(),
                },
                LandmarkSpec {
                    name: "Tower".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "tower".to_string(),
                },
                LandmarkSpec {
                    name: "Ruin".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "ruin".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["grey".to_string()],
                density: "sparse".to_string(),
                atmosphere: "misty".to_string(),
            },
        };

        let errors = compile_region(&spec, &make_test_catalogue()).unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::InvalidLandmarkDistribution { .. }))
        );
        assert!(
            errors
                .iter()
                .any(|e| e.to_string().contains("marker landmark"))
        );
    }

    #[test]
    fn rejects_region_with_no_major_role() {
        let spec = RegionSpec {
            name: "No Major".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "brooding".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Stone".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "stone".to_string(),
                },
                LandmarkSpec {
                    name: "Monument".to_string(),
                    kind: LandmarkKind::Monument,
                    description: "monument".to_string(),
                },
                LandmarkSpec {
                    name: "Shrine".to_string(),
                    kind: LandmarkKind::Shrine,
                    description: "shrine".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["grey".to_string()],
                density: "sparse".to_string(),
                atmosphere: "misty".to_string(),
            },
        };

        let errors = compile_region(&spec, &make_test_catalogue()).unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::InvalidLandmarkDistribution { .. }))
        );
        assert!(
            errors
                .iter()
                .any(|e| e.to_string().contains("major landmark"))
        );
    }

    #[test]
    fn rejects_region_without_terrain_affine_role() {
        let spec = RegionSpec {
            name: "Flat Coast".to_string(),
            terrain_type: TerrainType::Coast,
            mood: "brooding".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Settlement".to_string(),
                    kind: LandmarkKind::Settlement,
                    description: "settlement".to_string(),
                },
                LandmarkSpec {
                    name: "Ruin".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "ruin".to_string(),
                },
                LandmarkSpec {
                    name: "Stone".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "stone".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["blue".to_string()],
                density: "sparse".to_string(),
                atmosphere: "windy".to_string(),
            },
        };

        let errors = compile_region(&spec, &make_test_catalogue()).unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::InvalidLandmarkDistribution { .. }))
        );
        assert!(
            errors
                .iter()
                .any(|e| e.to_string().contains("terrain-affine landmark"))
        );
    }

    #[test]
    fn rejects_missing_archetype_family() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = AssetCatalogue::from_entries(vec![]);

        let result = compile_region(&spec, &catalogue);
        assert!(result.is_err());
        let errors = result.unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::UnresolvedArchetypeFamily { .. }))
        );
    }

    #[test]
    fn uses_terrain_specific_tag_when_present() {
        let spec = RegionSpec {
            name: "Forest Test".to_string(),
            terrain_type: TerrainType::Forest,
            mood: "brooding".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Forest Tower ".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "A forest tower".to_string(),
                },
                LandmarkSpec {
                    name: "Forest Ruin".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "A forest ruin".to_string(),
                },
                LandmarkSpec {
                    name: "Forest Stone".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "A forest stone".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["green".to_string()],
                density: "medium".to_string(),
                atmosphere: "misty".to_string(),
            },
        };

        let catalogue = AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("forest_tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/forest_tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
            AssetEntry {
                tag: tag("stone_ruin_medium"),
                path: Arc::new(PathBuf::from("meshes/ruin.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 5.0,
            },
            AssetEntry {
                tag: tag("standing_stone"),
                path: Arc::new(PathBuf::from("meshes/stone.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 3.0,
            },
        ]);

        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        assert!(
            world
                .entities
                .iter()
                .any(|entity| entity.archetype.as_str() == "forest_tower_ruined")
        );
    }

    #[test]
    fn forest_settlement_prefers_forest_family_when_present() {
        let spec = RegionSpec {
            name: "Area Settlement ".to_string(),
            terrain_type: TerrainType::Forest,
            mood: "quiet".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Area Hamlet ".to_string(),
                    kind: LandmarkKind::Settlement,
                    description: "A woodland hamlet.".to_string(),
                },
                LandmarkSpec {
                    name: "Forest Tower".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "A tower at the treeline.".to_string(),
                },
                LandmarkSpec {
                    name: "Forest Stone".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "A marker stone in the forest.".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["green".to_string()],
                density: "medium".to_string(),
                atmosphere: "misty".to_string(),
            },
        };

        let catalogue = AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("forest_settlement_small"),
                path: Arc::new(PathBuf::from("meshes/forest_settlement.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 7.0,
            },
            AssetEntry {
                tag: tag("forest_tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/forest_tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
            AssetEntry {
                tag: tag("standing_stone"),
                path: Arc::new(PathBuf::from("meshes/stone.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 3.0,
            },
        ]);

        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        assert!(
            world
                .entities
                .iter()
                .any(|entity| entity.archetype.as_str() == "forest_settlement_small")
        );
        assert!(
            world
                .entities
                .iter()
                .any(|entity| entity.archetype.as_str() == "forest_tower_ruined")
        );
    }

    #[test]
    fn desert_tower_prefers_desert_family_when_present() {
        let spec = RegionSpec {
            name: "Red Dunes".to_string(),
            terrain_type: TerrainType::Desert,
            mood: "scorched".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Red Spire".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "A desert watch tower.".to_string(),
                },
                LandmarkSpec {
                    name: "Dust Monument".to_string(),
                    kind: LandmarkKind::Monument,
                    description: "A desert monument.".to_string(),
                },
                LandmarkSpec {
                    name: "Bridge Remnant".to_string(),
                    kind: LandmarkKind::Bridge,
                    description: "A desert crossing.".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["amber".to_string()],
                density: "sparse".to_string(),
                atmosphere: "dry".to_string(),
            },
        };

        let catalogue = AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("desert_tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/desert_tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.2,
            },
            AssetEntry {
                tag: tag("desert_standing_stone"),
                path: Arc::new(PathBuf::from("meshes/desert_stone.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 3.2,
            },
            AssetEntry {
                tag: tag("desert_stone_bridge"),
                path: Arc::new(PathBuf::from("meshes/desert_bridge.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.0,
            },
        ]);

        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        let tower = world
            .entities
            .iter()
            .find(|entity| entity.name == "Red Spire")
            .expect("tower entity should exist");

        assert_eq!(tower.archetype.as_str(), "desert_tower_ruined");
    }

    #[test]
    fn highlands_tower_prefers_highlands_family_when_present() {
        let spec = RegionSpec {
            name: "Highland Tower".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "windswept".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Ridge Tower".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "A tower on the ridge.".to_string(),
                },
                LandmarkSpec {
                    name: "Ridge Stones".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "Ancient stones.".to_string(),
                },
                LandmarkSpec {
                    name: "Ridge Ruin".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "An old ruin.".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec!["grey".to_string()],
                density: "sparse".to_string(),
                atmosphere: "clear".to_string(),
            },
        };

        let catalogue = AssetCatalogue::from_entries(vec![
            AssetEntry {
                tag: tag("highlands_tower_ruined"),
                path: Arc::new(PathBuf::from("meshes/highlands_tower.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 6.5,
            },
            AssetEntry {
                tag: tag("standing_stone"),
                path: Arc::new(PathBuf::from("meshes/stone.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 3.0,
            },
            AssetEntry {
                tag: tag("stone_ruin_medium"),
                path: Arc::new(PathBuf::from("meshes/ruin.glb")),
                kind: AssetKind::Mesh,
                tags: vec![],
                footprint_radius: 5.0,
            },
        ]);

        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        assert!(
            world
                .entities
                .iter()
                .any(|entity| entity.archetype.as_str() == "highlands_tower_ruined")
        );
    }

    #[test]
    fn includes_spawn_point() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let world = compile_region(&spec, &catalogue).expect("compile valid spec ");

        let spawn = world
            .entities
            .iter()
            .find(|entity| entity.kind == EntityKind::SpawnPoint);

        assert!(spawn.is_some(), "world should contain a spawn point");
    }

    #[test]
    fn rejects_unknown_connection_region() {
        let specs = vec![make_test_spec(
            "Misty Highlands",
            "brooding",
            LandmarkKind::Monument,
        )];
        let connections = vec![ConnectionSpec {
            name: "Broken Link".to_string(),
            from_region: "Misty Highlands".to_string(),
            to_region: "Missing Region".to_string(),
            kind: ConnectionKind::Road,
            directionality: Directionality::Bidirectional,
        }];

        let result = compile_world(&specs, &connections, &make_test_catalogue());
        assert!(result.is_err());
        let errors = result.unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::UnknownRegionInConnection { .. }))
        );
    }

    #[test]
    fn rejects_unreachable_region() {
        let specs = vec![
            make_test_spec("Region A", "brooding", LandmarkKind::Monument),
            make_test_spec("Region B", "brooding", LandmarkKind::Settlement),
            make_test_spec("Region C", "brooding", LandmarkKind::Ruin),
        ];
        let connections = vec![ConnectionSpec {
            name: "A to B".to_string(),
            from_region: "Region A".to_string(),
            to_region: "Region B".to_string(),
            kind: ConnectionKind::Path,
            directionality: Directionality::Bidirectional,
        }];

        let result = compile_world(&specs, &connections, &make_test_catalogue());
        assert!(result.is_err());
        let errors = result.unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::UnreachableRegion(_)))
        );
    }

    #[test]
    fn deterministic_output() {
        let specs = vec![
            make_test_spec("Misty Highlands", "brooding", LandmarkKind::Monument),
            make_test_spec("Dark Forest", "ominous", LandmarkKind::Settlement),
        ];
        let connections = vec![ConnectionSpec {
            name: "Highland Path".to_string(),
            from_region: "Misty Highlands".to_string(),
            to_region: "Dark Forest".to_string(),
            kind: ConnectionKind::Path,
            directionality: Directionality::Bidirectional,
        }];
        let catalogue = make_test_catalogue();

        let world_a = compile_world(&specs, &connections, &catalogue).expect("compile valid spec ");
        let world_b = compile_world(&specs, &connections, &catalogue).expect("compile valid spec ");

        let json_a = serde_json::to_string(&world_a).expect("serialize world a");
        let json_b = serde_json::to_string(&world_b).expect("serialize world b");

        assert_eq!(json_a, json_b, "compiler output should be deterministic");
    }

    #[test]
    fn serde_roundtrip() {
        let specs = vec![make_test_spec(
            "Test Highlands",
            "brooding",
            LandmarkKind::Monument,
        )];
        let catalogue = make_test_catalogue();
        let world = compile_world(&specs, &[], &catalogue).expect("compile valid spec ");

        let json = serde_json::to_string_pretty(&world).expect("serialize world");
        let deserialized: WorldAuthored = serde_json::from_str(&json).expect("deserialize world");

        assert_eq!(world.regions.len(), deserialized.regions.len());
        assert_eq!(world.entities.len(), deserialized.entities.len());
        assert_eq!(world.connections.len(), deserialized.connections.len());
        assert_eq!(
            world.asset_refs.entries.len(),
            deserialized.asset_refs.entries.len()
        );
        assert_eq!(
            world.metadata.history_events_digest,
            deserialized.metadata.history_events_digest
        );
    }

    #[test]
    fn world_validation_rejects_invalid_history_events() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let world = compile_region(&spec, &catalogue)
            .expect("compile valid world")
            .with_history_events(vec![HistoryEvent {
                damage_type: anvil_core::DamageType::Fire,
                magnitude: 1.5,
                epicenter: [0.0, 0.0, 0.0],
                radius: 20.0,
                tick: 1,
            }]);

        let errors = world.validate();
        assert!(!errors.is_empty());
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::InvalidHistoryEvent { index: 0, .. }))
        );
    }

    #[test]
    fn world_validation_rejects_history_events_digest_mismatch() {
        let spec = make_test_spec("Test Highlands", "brooding", LandmarkKind::Monument);
        let catalogue = make_test_catalogue();
        let mut world = compile_region(&spec, &catalogue).expect("compile valid world");
        world.metadata.history_events_digest = "bad-digest".to_string();

        let errors = world.validate();
        assert!(!errors.is_empty());
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::HistoryEventsDigestMismatch { .. }))
        );
    }

    // ─── History event generation tests ────────────────────────────────────

    #[test]
    fn generate_history_events_empty_specs_produces_no_events() {
        // Empty specs should produce empty history
        let events = generate_history_events(&[], &[]);
        assert!(events.is_empty(), "empty specs should produce no events");
    }

    #[test]
    fn generate_history_events_highlands_produces_appropriate_damage() {
        let spec = RegionSpec {
            name: "Highlands".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "brooding".to_string(),
            landmarks: vec![LandmarkSpec {
                name: "Monument".to_string(),
                kind: LandmarkKind::Monument,
                description: "Test monument".to_string(),
            }],
            style_hints: StyleHints {
                palette: vec![],
                density: String::new(),
                atmosphere: String::new(),
            },
        };
        let events = generate_history_events(&[spec], &[]);

        // Highlands should produce earthquake, fire, or drought
        for event in &events {
            assert!(
                matches!(
                    event.damage_type,
                    anvil_core::DamageType::Earthquake
                        | anvil_core::DamageType::Fire
                        | anvil_core::DamageType::Drought
                ),
                "highlands should produce earthquake/fire/drought, got {:?}",
                event.damage_type
            );
        }
    }

    #[test]
    fn generate_history_events_forest_produces_appropriate_damage() {
        let spec = RegionSpec {
            name: "Forest".to_string(),
            terrain_type: TerrainType::Forest,
            mood: "mysterious".to_string(),
            landmarks: vec![LandmarkSpec {
                name: "Tower".to_string(),
                kind: LandmarkKind::Tower,
                description: "Test tower".to_string(),
            }],
            style_hints: StyleHints {
                palette: vec![],
                density: String::new(),
                atmosphere: String::new(),
            },
        };
        let events = generate_history_events(&[spec], &[]);

        // Forest should produce fire, flood, or drought
        for event in &events {
            assert!(
                matches!(
                    event.damage_type,
                    anvil_core::DamageType::Fire
                        | anvil_core::DamageType::Flood
                        | anvil_core::DamageType::Drought
                ),
                "forest should produce fire/flood/drought, got {:?}",
                event.damage_type
            );
        }
    }

    #[test]
    fn generate_history_events_deterministic_same_input_same_output() {
        let spec = RegionSpec {
            name: "Highlands".to_string(),
            terrain_type: TerrainType::Highlands,
            mood: "brooding".to_string(),
            landmarks: vec![LandmarkSpec {
                name: "Monument".to_string(),
                kind: LandmarkKind::Monument,
                description: "Test monument".to_string(),
            }],
            style_hints: StyleHints {
                palette: vec![],
                density: String::new(),
                atmosphere: String::new(),
            },
        };

        let events1 = generate_history_events(std::slice::from_ref(&spec), &[]);
        let events2 = generate_history_events(std::slice::from_ref(&spec), &[]);

        // Two calls with same input should produce identical output
        assert_eq!(
            events1.len(),
            events2.len(),
            "event count should be deterministic"
        );
        for (e1, e2) in events1.iter().zip(events2.iter()) {
            assert_eq!(
                e1.damage_type, e2.damage_type,
                "damage type should be deterministic"
            );
            assert!(
                (e1.magnitude - e2.magnitude).abs() < 0.001,
                "magnitude should be deterministic"
            );
        }
    }

    #[test]
    fn generate_history_events_no_duplicate_damage_per_region() {
        let spec = RegionSpec {
            name: "Desert".to_string(),
            terrain_type: TerrainType::Desert,
            mood: "harsh".to_string(),
            // Many landmarks to potentially generate multiple events
            landmarks: vec![
                LandmarkSpec {
                    name: "Ruin1".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "Test ruin 1".to_string(),
                },
                LandmarkSpec {
                    name: "Ruin2".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "Test ruin 2".to_string(),
                },
                LandmarkSpec {
                    name: "Ruin3".to_string(),
                    kind: LandmarkKind::Ruin,
                    description: "Test ruin 3".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec![],
                density: String::new(),
                atmosphere: String::new(),
            },
        };
        let events = generate_history_events(&[spec], &[]);

        // No duplicate damage types for the same region
        let damage_types: Vec<_> = events.iter().map(|e| e.damage_type).collect();
        let unique: HashSet<String> = damage_types.iter().map(|dt| format!("{}", dt)).collect();
        assert_eq!(
            damage_types.len(),
            unique.len(),
            "no duplicate damage types per region"
        );
    }

    #[test]
    fn compile_world_with_history_uses_provided_events_not_synthetic() {
        let spec = make_test_spec("TestRegion", "stoic", LandmarkKind::Ruin);
        let catalogue = make_test_catalogue();
        let authored_events = vec![HistoryEvent {
            damage_type: anvil_core::DamageType::Flood,
            magnitude: 0.55,
            epicenter: [100.0, 0.0, 100.0],
            radius: 80.0,
            tick: 200,
        }];
        let world =
            compile_world_with_history(std::slice::from_ref(&spec), &[], &catalogue, authored_events.clone())
                .expect("compile_world_with_history must succeed with valid events");

        // Authored events must be present, not synthetic.
        assert_eq!(*world.history_events, authored_events);
        // Must not contain the synthetic events that compile_world() would have generated.
        let synthetic = generate_history_events(&[spec], &[]);
        assert_ne!(
            *world.history_events, synthetic,
            "authored history must differ from synthetic fallback"
        );
    }

    #[test]
    fn compile_world_with_history_digest_matches_events() {
        let spec = make_test_spec("TestRegion", "stoic", LandmarkKind::Ruin);
        let catalogue = make_test_catalogue();
        let authored_events = vec![HistoryEvent {
            damage_type: anvil_core::DamageType::Fire,
            magnitude: 0.70,
            epicenter: [50.0, 0.0, 50.0],
            radius: 60.0,
            tick: 100,
        }];
        let world = compile_world_with_history(&[spec], &[], &catalogue, authored_events.clone())
            .expect("compile must succeed");

        let expected_digest = history_events_digest(&authored_events);
        assert_eq!(
            world.metadata.history_events_digest, expected_digest,
            "digest stored in WorldMetadata must match authored events"
        );
    }

    #[test]
    fn compile_world_with_history_rejects_invalid_events() {
        let spec = make_test_spec("TestRegion", "stoic", LandmarkKind::Ruin);
        let catalogue = make_test_catalogue();
        // magnitude > 1.0 is invalid.
        let bad_events = vec![HistoryEvent {
            damage_type: anvil_core::DamageType::Earthquake,
            magnitude: 1.5,
            epicenter: [100.0, 0.0, 100.0],
            radius: 80.0,
            tick: 100,
        }];
        let result = compile_world_with_history(&[spec], &[], &catalogue, bad_events);
        assert!(
            result.is_err(),
            "compile_world_with_history must reject invalid events"
        );
        let errors = result.unwrap_err();
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, CompileError::InvalidHistoryEvent { index: 0, .. })),
            "error must be InvalidHistoryEvent at index 0"
        );
    }

    #[test]
    fn compile_world_with_empty_history_does_not_generate_synthetic() {
        let spec = make_test_spec("TestRegion", "stoic", LandmarkKind::Ruin);
        let catalogue = make_test_catalogue();
        let world = compile_world_with_history(&[spec], &[], &catalogue, vec![])
            .expect("compile with empty history must succeed");
        assert!(
            world.history_events.is_empty(),
            "empty authored history must produce world with no events, not synthetic fallback"
        );
        let expected_digest = history_events_digest(&[]);
        assert_eq!(
            world.metadata.history_events_digest, expected_digest,
            "digest for empty history must be consistent"
        );
    }
}

/// Weather state for simulation contexts.
pub mod weather;
pub use weather::WeatherState;
