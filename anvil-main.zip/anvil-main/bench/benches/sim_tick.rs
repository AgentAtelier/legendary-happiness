use criterion::{black_box, criterion_group, criterion_main, Criterion, BenchmarkId};
use anvil_sim::{CatastropheSystem, DeterministicRng, JoySystem, NpcSystem, PhysicsSystem, SimContext, SimError, SimSystem, WorldEnv, WorldRuntime};
use anvil_sim::settlement::{Person, Settlement, SettlementId};
use anvil_sim::settlement::ids::PersonId;
use anvil_core::RegionId;

fn create_test_world() -> WorldRuntime {
    WorldRuntime::default()
}

/// Helper to tick a system with minimal setup
fn tick_system<S: SimSystem>(system: &mut S, world: &mut WorldRuntime, rng: &mut DeterministicRng, tick: u64) -> Result<(), SimError> {
    let events_in: Vec<anvil_sim::SimEvent> = Vec::new();
    let mut events_out: Vec<anvil_sim::SimEvent> = Vec::new();
    let world_env = WorldEnv::default();
    let mut ctx = SimContext::new(tick, 16666, rng, world, &world_env, &events_in, &mut events_out);
    system.tick(&mut ctx)
}

/// Create a test settlement with N persons for benchmarking.
fn create_test_settlement(num_persons: usize) -> (Settlement, Vec<Person>) {
    let settlement = Settlement::new_with_defaults(
        SettlementId::new(1),
        "Benchmark Settlement".to_string(),
        RegionId::new(0),
        num_persons as u32,
    );
    
    // Create persons
    let mut persons = Vec::new();
    for i in 0..num_persons {
        let person = Person::new_simple(
            PersonId::new(i as u64),
            format!("Person {}", i),
            anvil_sim::settlement::FamilyId::new(1),
        );
        persons.push(person);
    }
    
    (settlement, persons)
}

/// Create an NPC system with N persons for benchmarking.
fn create_npc_system(num_persons: usize) -> NpcSystem {
    let mut system = NpcSystem::new();
    let (settlement, persons) = create_test_settlement(num_persons);
    system.add_settlement(settlement);
    for person in persons {
        system.add_person(person);
    }
    system
}

// ============================================================================
// Steady-state benchmarks: systems are warmed up before measurement
// ============================================================================

fn bench_physics_steady_state(c: &mut Criterion) {
    let mut system = PhysicsSystem::new();
    system.create_player(glam::Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);
    let mut world = create_test_world();
    let mut rng = DeterministicRng::new(42);
    
    // Warm up with 100 ticks
    for tick in 0..100 {
        tick_system(&mut system, &mut world, &mut rng, tick).ok();
    }
    
    c.bench_function("physics_steady_state", |b| {
        b.iter(|| {
            tick_system(&mut system, &mut world, &mut rng, black_box(1000)).ok();
        })
    });
}

fn bench_npc_tick(c: &mut Criterion) {
    let mut group = c.benchmark_group("npc_tick");
    
    for n in [10, 50, 100, 500].iter() {
        group.bench_with_input(
            BenchmarkId::new("n_persons", n),
            n,
            |b, &n| {
                let mut system = create_npc_system(n);
                let mut world = create_test_world();
                let mut rng = DeterministicRng::new(42);
                
                // Warm up with 10 ticks
                for tick in 0..10 {
                    tick_system(&mut system, &mut world, &mut rng, tick).ok();
                }
                
                b.iter(|| {
                    tick_system(&mut system, &mut world, &mut rng, black_box(100)).ok();
                })
            },
        );
    }
    
    group.finish();
}

fn bench_full_sim_tick(c: &mut Criterion) {
    let mut physics = PhysicsSystem::new();
    physics.create_player(glam::Vec3::new(0.0, 5.0, 0.0), 0.5, 1.8);
    let mut catastrophe = CatastropheSystem::new();
    let mut joy = JoySystem::new();
    let mut npc = create_npc_system(50); // 50 persons for full sim
    
    let mut world = create_test_world();
    let mut rng = DeterministicRng::new(42);
    
    // Warm up all systems
    for tick in 0..10 {
        tick_system(&mut physics, &mut world, &mut rng, tick).ok();
        tick_system(&mut catastrophe, &mut world, &mut rng, tick).ok();
        tick_system(&mut joy, &mut world, &mut rng, tick).ok();
        tick_system(&mut npc, &mut world, &mut rng, tick).ok();
    }
    
    c.bench_function("full_sim_tick_4_systems", |b| {
        b.iter(|| {
            let tick = black_box(1000);
            tick_system(&mut physics, &mut world, &mut rng, tick).ok();
            tick_system(&mut catastrophe, &mut world, &mut rng, tick).ok();
            tick_system(&mut joy, &mut world, &mut rng, tick).ok();
            tick_system(&mut npc, &mut world, &mut rng, tick).ok();
        })
    });
}

// ============================================================================
// Legacy benchmarks: kept for comparison, but measure init + first tick
// ============================================================================

fn bench_legacy_sim_tick(c: &mut Criterion) {
    // Benchmark physics system tick (measures init + one tick)
    c.bench_function("legacy/physics_tick", |b| {
        b.iter(|| {
            let mut world = create_test_world();
            let mut rng = DeterministicRng::new(42);
            let mut system = PhysicsSystem::new();
            tick_system(&mut system, &mut world, &mut rng, black_box(0)).unwrap();
        })
    });
    
    // Benchmark catastrophe system tick (measures init + one tick)
    c.bench_function("legacy/catastrophe_tick", |b| {
        b.iter(|| {
            let mut world = create_test_world();
            let mut rng = DeterministicRng::new(42);
            let mut system = CatastropheSystem::new();
            tick_system(&mut system, &mut world, &mut rng, black_box(0)).unwrap();
        })
    });
    
    // Benchmark Joy system tick (measures init + one tick)
    c.bench_function("legacy/joy_tick", |b| {
        b.iter(|| {
            let mut world = create_test_world();
            let mut rng = DeterministicRng::new(42);
            let mut system = JoySystem::new();
            tick_system(&mut system, &mut world, &mut rng, black_box(0)).unwrap();
        })
    });
    
    // Long-running simulation test: 1000 ticks
    c.bench_function("legacy/sim_1000_ticks", |b| {
        b.iter(|| {
            let mut world = create_test_world();
            let mut rng = DeterministicRng::new(42);
            let mut physics = PhysicsSystem::new();
            let mut catastrophe = CatastropheSystem::new();
            
            for tick in 0..1000u64 {
                tick_system(&mut physics, &mut world, &mut rng, tick).unwrap();
                tick_system(&mut catastrophe, &mut world, &mut rng, tick).unwrap();
            }
        })
    });
}

criterion_group!(
    benches,
    // Steady-state benchmarks (preferred)
    bench_physics_steady_state,
    bench_npc_tick,
    bench_full_sim_tick,
    // Legacy benchmarks (for comparison)
    bench_legacy_sim_tick,
);
criterion_main!(benches);
