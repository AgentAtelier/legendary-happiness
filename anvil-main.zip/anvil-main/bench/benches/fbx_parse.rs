use criterion::{black_box, Criterion, criterion_group, criterion_main};
use anvil_assets_pipeline::fbx::inspect_fbx_source;
use std::path::Path;
use walkdir::WalkDir;

fn fbx_inspect(c: &mut Criterion) {
    // Use the first FBX file found in the vendor directory
    let fbx_dir = Path::new("vendor/emberwood/models");
    let mut fbx_path: Option<std::path::PathBuf> = None;

    if fbx_dir.exists() {
        fbx_path = WalkDir::new(fbx_dir)
            .into_iter()
            .filter_map(|e| e.ok())
            .find(|e| e.path().extension().is_some_and(|ext| ext == "fbx"))
            .map(|e| e.into_path());
    }

    if let Some(path) = &fbx_path {
        c.bench_function("fbx_inspect", |b| {
            b.iter(|| {
                let result = inspect_fbx_source(black_box(path.as_path()));
                black_box(result)
            })
        });
    } else {
        eprintln!("No FBX file found in vendor/emberwood/models/ — skipping FBX bench");
    }
}

criterion_group!(benches, fbx_inspect);
criterion_main!(benches);
