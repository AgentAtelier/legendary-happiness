use criterion::{black_box, Criterion, criterion_group, criterion_main};
use anvil_core::{ArchetypeTag, DamageType};
use anvil_assets::{AssetCatalogue, CatalogueQuery};

fn resolve_query(c: &mut Criterion) {
    // Load the real Emberwood catalogue
    let catalogue_path = std::path::Path::new("assets/catalogue.json");
    let catalogue = if catalogue_path.exists() {
        AssetCatalogue::load(catalogue_path, None).expect("Failed to load catalogue")
    } else {
        // Create a minimal catalogue for benchmarking if file not found
        use anvil_assets::{AssetEntry, CatalogueBuilder};
        use anvil_core::ArchetypeTag;
        use std::sync::Arc;
        use std::path::PathBuf;
        
        let entry = AssetEntry {
            tag: ArchetypeTag::new("test_mesh").unwrap(),
            path: Arc::new(PathBuf::from("meshes/test.glb")),
            kind: anvil_assets::AssetKind::Mesh,
            tags: vec![],
            footprint_radius: 1.0,
        };
        CatalogueBuilder::new()
            .entry(entry)
            .build()
    };

    let tag = ArchetypeTag::new("highlands_standing_stone")
        .expect("valid tag");

    c.bench_function("resolve_query_warm", |b| {
        let query = CatalogueQuery::new(tag.clone())
            .with_damage(DamageType::Fire);
        b.iter(|| {
            let result = catalogue.resolve_query(black_box(&query));
            black_box(result)
        })
    });

    c.bench_function("resolve_query_cold", |b| {
        b.iter(|| {
            let tag = ArchetypeTag::new("nm_forest_env_tree_beech_tree_00_a")
                .expect("valid tag");
            let query = CatalogueQuery::new(tag)
                .with_damage(DamageType::Fire);
            let result = catalogue.resolve_query(black_box(&query));
            black_box(result)
        })
    });
}

criterion_group!(benches, resolve_query);
criterion_main!(benches);
