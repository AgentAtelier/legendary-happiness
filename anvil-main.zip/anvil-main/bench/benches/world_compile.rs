use criterion::{black_box, Criterion, criterion_group, criterion_main};
use anvil_core::{
    ConnectionKind, ConnectionSpec, LandmarkKind, LandmarkSpec,
    RegionSpec, StyleHints, TerrainType,
};
use anvil_assets::AssetCatalogue;
use anvil_world::compile_world;

fn compile_world_bench(c: &mut Criterion) {
    let catalogue_path = std::path::Path::new("assets/catalogue.json");
    let catalogue = if catalogue_path.exists() {
        AssetCatalogue::load(catalogue_path, None).expect("Failed to load catalogue")
    } else {
        // Create a minimal catalogue for benchmarking if file not found
        use anvil_assets::{AssetEntry, CatalogueBuilder};
        use anvil_core::ArchetypeTag;
        use std::sync::Arc;
        use std::path::PathBuf;
        
        let entry = AssetEntry {
            tag: ArchetypeTag::new("test_mesh").unwrap(),
            path: Arc::new(PathBuf::from("meshes/test.glb")),
            kind: anvil_assets::AssetKind::Mesh,
            tags: vec![],
            footprint_radius: 1.0,
        };
        CatalogueBuilder::new()
            .entry(entry)
            .build()
    };

    fn make_spec(name: &str, terrain: TerrainType) -> RegionSpec {
        RegionSpec {
            name: name.to_string(),
            terrain_type: terrain,
            mood: "test".to_string(),
            landmarks: vec![
                LandmarkSpec {
                    name: "Tower".to_string(),
                    kind: LandmarkKind::Tower,
                    description: "Test tower".to_string(),
                },
                LandmarkSpec {
                    name: "Stone".to_string(),
                    kind: LandmarkKind::StandingStone,
                    description: "Test stone".to_string(),
                },
                LandmarkSpec {
                    name: "Shrine".to_string(),
                    kind: LandmarkKind::Shrine,
                    description: "Test shrine".to_string(),
                },
            ],
            style_hints: StyleHints {
                palette: vec![],
                density: "sparse".into(),
                atmosphere: "clear".into(),
            },
        }
    }

    let specs: Vec<_> = (0..10)
        .map(|i| make_spec(&format!("Region {i}"), TerrainType::Highlands))
        .collect();

    let connections = vec![
        ConnectionSpec {
            name: "Path 0-1".into(),
            from_region: "Region 0".into(),
            to_region: "Region 1".into(),
            kind: ConnectionKind::Path,
            directionality: anvil_core::Directionality::Bidirectional,
        },
    ];

    c.bench_function("compile_world_10_regions", |b| {
        b.iter(|| {
            let result = compile_world(
                black_box(&specs),
                black_box(&connections),
                black_box(&catalogue),
            );
            black_box(result)
        })
    });

    // 100-region benchmark
    let many_specs: Vec<_> = (0..100)
        .map(|i| make_spec(&format!("Region {i}"), TerrainType::Highlands))
        .collect();

    c.bench_function("compile_world_100_regions", |b| {
        b.iter(|| {
            let result = compile_world(
                black_box(&many_specs),
                black_box(&connections),
                black_box(&catalogue),
            );
            black_box(result)
        })
    });
}

criterion_group!(benches, compile_world_bench);
criterion_main!(benches);
