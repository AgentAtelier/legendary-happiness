# Performance Baseline Report

**Generated:** 2025-01-02  
**Commit Hash:** `2dbf5ef`  
**Machine:** Linux forgebox 6.19.14-arch1-1 x86_64 GNU/Linux  
**CPU:** 12 cores (x86_64)  
**RAM:** 31 GiB  

---

## Benchmark Results

All benchmarks run with `cargo bench -p anvil_bench`. Times are median values.

### Catalogue Resolve

| Benchmark | Time | Notes |
|----------|------|-------|
| resolve_query_warm | 23.1 ns | Warm cache, known tag |
| resolve_query_cold | 72.3 ns | Cold cache, new tag lookup |

**Status:** ✅ Within budget (target: <100ns for warm, <200ns for cold)

### World Compile

| Benchmark | Regions | Time | Notes |
|----------|---------|------|-------|
| compile_world_10_regions | 10 | 5.65 µs | 10 regions, 3 landmarks each |
| compile_world_100_regions | 100 | 59.65 µs | 100 regions, 3 landmarks each |

**Status:** ✅ Within budget (target: <100µs for 100 regions)

### Simulation Tick

| Benchmark | Time | Notes |
|----------|------|-------|
| physics_tick | 336 ns | Single physics tick, empty world |
| catastrophe_tick | 2.52 µs | Single catastrophe tick, empty world |
| joy_tick | 29.3 ns | Single joy tick, empty settlements |
| sim_1000_ticks | 923 µs | 1000 ticks (physics + catastrophe) |

**Status:** ✅ Within budget (target: <1ms for 1000 ticks with empty world)

### FBX Parse

| Benchmark | File | Time | Notes |
|----------|------|------|-------|
| fbx_inspect | N/A | SKIPPED | No vendor/emberwood/models/ directory available |

**Status:** ⚠️ Skipped - vendor files not present

---

## Budget Analysis

All measured benchmarks are within their target budgets:

- **Catalogue resolve:** Warm ~23ns (budget: 100ns), Cold ~72ns (budget: 200ns) ✅
- **World compile:** 10 regions ~5.6µs, 100 regions ~59.6µs (budget: 100µs) ✅
- **Sim tick:** Individual systems 29ns-2.5µs, 1000 ticks ~923µs ✅

### Compile Time

| Configuration | Time | Budget | Status |
|---------------|------|--------|--------|
| Release build (clean) | 2m 55s (175s) | 120s | ❌ EXCEEDS BUDGET |

**Note:** The compile time exceeds the 120s budget by 55s. This is primarily due to:
- Debug build of dependencies taking significant time
- nalgebra compilation warnings (future incompatibility)
- Large number of crates in workspace

**Action Items:**
1. Investigate incremental compilation benefits
2. Consider splitting workspace into smaller units
3. Address nalgebra future incompatibility warnings

---

## Hardware Specification

- **OS:** Linux 6.19.14-arch1-1 x86_64
- **CPU:** 12 cores, x86_64 architecture
- **Memory:** 31 GiB RAM
- **Rust Version:** (see rust-toolchain.toml)

---

## Operation Budget Status

| Operation | Measured | Budget | Status |
|-----------|----------|--------|--------|
| Catalogue resolve (warm) | 23.1 ns | 100 ns | ✅ |
| Catalogue resolve (cold) | 72.3 ns | 200 ns | ✅ |
| World compile (10 regions) | 5.65 µs | 100 µs | ✅ |
| World compile (100 regions) | 59.65 µs | 100 µs | ✅ |
| Physics tick | 336 ns | 1 µs | ✅ |
| Catastrophe tick | 2.52 µs | 10 µs | ✅ |
| Joy tick | 29.3 ns | 1 µs | ✅ |
| Sim 1000 ticks | 923 µs | 2 ms | ✅ |

**All operations within budget.** No regressions detected.

---

## Methodology

- Benchmarks use the Criterion.rs framework
- Each benchmark runs for 3s warmup + 5s measurement
- 100 samples collected per benchmark
- Median values reported
- All benchmarks run on release profile with optimizations
