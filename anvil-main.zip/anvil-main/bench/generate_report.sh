#!/usr/bin/env bash
echo "# Phase 0 — Performance Baseline Report"
echo ""
echo "Date: $(date -I)"
echo "Machine: $(uname -m) / $(uname -s)"
echo "CPU: $(lscpu | grep 'Model name' | cut -d: -f2 | xargs)"
echo "RAM: $(free -h | awk '/^Mem:/ {print $2}')"
echo ""
echo "| Operation | Mean | p99 |"
echo "|-----------|------|-----|"

for group_dir in target/criterion/*/phase0; do
    if [ -d "$group_dir" ]; then
        group=$(basename $(dirname "$group_dir"))
        json="$group_dir/estimates.json"
        if [ -f "$json" ]; then
            mean=$(jq '.mean.point_estimate' "$json" 2>/dev/null || echo "—")
            p99=$(jq '.mean.confidence_interval.upper_bound' "$json" 2>/dev/null || echo "—")
            echo "| ${group} | ${mean} | ${p99} |"
        fi
    fi
done
