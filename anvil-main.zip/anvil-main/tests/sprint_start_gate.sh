#!/usr/bin/env bash
set -euo pipefail

echo "=== Sprint Start Gate ==="
echo ""
echo "--- check_placeholder_debt.sh ---"
./scripts/check_placeholder_debt.sh

echo ""
echo "=== Sprint Start Gate PASSED ==="
