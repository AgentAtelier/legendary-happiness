#!/usr/bin/env bash
set -euo pipefail

echo "=== Phase 3 Gate ==="
echo ""

# Change to the repository root (where this script is located)
cd "$(dirname "$0")/.."

echo "--- Firewall ---"
./scripts/check_firewall.sh

echo ""
echo "--- File sizes ---"
./scripts/check_size.sh

echo ""
echo "--- Validate signatures ---"
./scripts/check_validate_signature.sh

echo ""
echo "--- Error codes ---"
./scripts/check_error_codes.sh

echo ""
echo "--- Placeholder debt ---"
./scripts/check_placeholder_debt.sh

echo ""
echo "--- Schema migration ---"
./scripts/check_schema_migration.sh

echo ""
echo "--- Clippy ---"
cargo clippy --workspace --all-targets -- -D warnings

echo ""
echo "--- Tests ---"
cargo test --workspace

echo ""
echo "--- Phase 3 determinism ---"
cargo test -p anvil_sim --test phase3_determinism

echo ""
echo "--- Snapshot round-trip ---"
cargo test -p anvil_sim --test phase3_snapshot_roundtrip

echo ""
echo "=== Phase 3 Gate: ALL PASS ==="
