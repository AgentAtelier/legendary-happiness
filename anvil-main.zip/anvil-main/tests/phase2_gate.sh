#!/usr/bin/env bash
set -euo pipefail

echo "=== Phase 2 Gate ==="
echo ""

echo "--- check_firewall.sh ---"
./scripts/check_firewall.sh

echo ""
echo "--- check_size.sh ---"
./scripts/check_size.sh

echo ""
echo "--- check_validate_signature.sh ---"
./scripts/check_validate_signature.sh

echo ""
echo "--- check_placeholder_debt.sh ---"
./scripts/check_placeholder_debt.sh

echo ""
echo "--- cargo clippy (deny warnings) ---"
cargo clippy --workspace --all-targets -- -D warnings

echo ""
echo "--- cargo test (workspace) ---"
cargo test --workspace

echo ""
echo "--- three_region_streaming gate ---"
cargo test -p anvil_runtime --test three_region_streaming

echo ""
echo "=== Phase 2 Gate PASSED ==="
