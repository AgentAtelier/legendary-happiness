# sim_bridge
```rust
// anvil_demo/src/sim_bridge.rs
use bevy::prelude::*;
use anvil_bevy::sim_bridge::{SimSnapshot, TimeSnapshot, WeatherSnapshot, CatastropheSnapshot, CatastropheKind};

use crate::app::RuntimeResource;

/// Reads the deterministic runtime and populates the presentation-side snapshot.
/// Runs in PreUpdate, before interpolation and apply.
pub fn sim_bridge_system(
    runtime: Res<RuntimeResource>,
    mut snapshot: ResMut<SimSnapshot>,
) {
    // Access the runtime's public API.
    let sim = &runtime.runtime;

    // Time
    snapshot.time = TimeSnapshot {
        time_of_day: sim.time.day_phase(),
        day: (sim.time.seconds_since_start / 86400.0) as u32,
    };
    snapshot.tick = 0; // Will be set by simulation tick counter

    // Weather
    let w = &sim.weather;
    snapshot.weather = WeatherSnapshot {
        temperature_c: w.temperature,
        humidity: w.humidity,
        wind_speed_ms: w.wind_speed,
        wind_direction: w.wind_direction,
        precipitation: match w.current_weather {
            anvil_runtime::weather::WeatherPhase::Rain => 0.8,
            anvil_runtime::weather::WeatherPhase::Storm => 1.0,
            _ => 0.0,
        },
        cloud_cover: match w.current_weather {
            anvil_runtime::weather::WeatherPhase::Clear => 0.0,
            anvil_runtime::weather::WeatherPhase::Overcast => 0.75,
            anvil_runtime::weather::WeatherPhase::Rain => 0.88,
            anvil_runtime::weather::WeatherPhase::Fog => 0.60,
            anvil_runtime::weather::WeatherPhase::Storm => 1.0,
        },
        pressure_hpa: w.pressure,
    };

    // Catastrophes (active events with stable VFX seed)
    if let Some(cat_system) = sim.catastrophe_system() {
        snapshot.catastrophes = cat_system.active_events
            .iter()
            .filter_map(|c| {
                let kind = match c.catastrophe_type {
                    anvil_sim::catastrophe::CatastropheType::Wildfire => CatastropheKind::Wildfire,
                    anvil_sim::catastrophe::CatastropheType::Flood => CatastropheKind::Flood,
                    anvil_sim::catastrophe::CatastropheType::Earthquake => CatastropheKind::Earthquake,
                    _ => return None,
                };
                Some(CatastropheSnapshot {
                    id: c.id,
                    kind,
                    origin: Vec3::new(c.epicentre.position.x, c.epicentre.position.y, c.epicentre.position.z),
                    intensity: c.magnitude,
                    vfx_seed: stable_seed_from_id(c.id, c.trigger_tick),
                })
            })
            .collect();
    }
}

// Deterministic seed helper
fn stable_seed_from_id(id: u64, onset_tick: u64) -> u64 {
    let mut h = id ^ (onset_tick.wrapping_shl(32) | onset_tick.wrapping_shr(32));
    h ^= h >> 30;
    h = h.wrapping_mul(0xBF58476D1CE4E5B9);
    h ^= h >> 27;
    h = h.wrapping_mul(0x94D049BB133111EB);
    h ^= h >> 31;
    h
}
```

# plugins/registration.rs
```rust
//! Plugin and system registration for anvil_demo.
//!
//! This module contains the centralized registration function that adds all
//! plugins, resources, and systems to the Bevy app.

use bevy::prelude::*;

use anvil_bevy::{AnvilAssetPlugin, debug_fallback_summary, AssetOriginTag};
use anvil_bevy::environment::plugin::{EnvironmentPlugin, EnvironmentSet};
use anvil_bevy::sky::SkyPlugin;
use bevy::asset::AssetPlugin;
use bevy::diagnostic::FrameTimeDiagnosticsPlugin;
use bevy::gltf::GltfAssetLabel;
use bevy::log::LogPlugin;
use bevy::pbr::StandardMaterial;
use bevy_egui::{EguiContexts, EguiPlugin, EguiPrimaryContextPass, egui};
// TODO Phase 1: replaced by FpsController
use std::path::{Path, PathBuf};
use tracing::info;

use crate::app::{AppPlugin, AppState, RuntimeResource};
use crate::spawn_sun::spawn_sun;
use crate::sim_bridge::sim_bridge_system;
use anvil_bevy::audio::AudioPlugin;
use crate::audio::AshveilAudioPlugin;
use crate::player::PlayerPlugin;
use crate::world::AtmosphereDriverPlugin;
use crate::camera::{despawn_gltf_cameras, handle_camera_shortcuts, handle_mouse_wheel_zoom, setup_main_camera, update_focus_camera, CameraState};


use crate::catastrophe_panel::{handle_catastrophe_shortcuts, process_pending_catastrophes, render_catastrophe_panel, setup_catastrophe_panel, CatastrophePanelState};
use crate::demo::DemoSequencerPlugin;
use crate::dev_experience::{render_dev_panel, setup_dev_experience, EguiContextsExt};
use crate::event_log::{add_test_events, render_event_log, setup_event_log, EventLog};
use crate::npc::{update_npc_movement, update_npc_rotation_toward_targets};
use crate::npc_visuals::{despawn_npc_visuals, spawn_npc_visuals, update_action_halos, update_npc_breathing_system, update_selection_ring_visibility, update_selection_rings, NpcVisualState};
use crate::oracle_overlay::{render_oracle_overlay, setup_oracle_overlay};
use crate::overlays::{NeedsBarPlugin, SkillFlashPlugin, render_network_line_legend, setup_overlays, update_emotion_lines, update_status_rings, OverlayState};
use crate::performance_panel::{render_performance_panel, setup_performance_panel, PerformancePanelState};
use crate::plugins::SimBridgePlugin;
use crate::rendering::GlbRenderingPlugin;
use crate::scenarios::ScenarioLoaderPlugin;
use crate::sim::{SimRng, SimTickCounter, tick_simulation_systems};
use crate::states::options::{AccessibilityOptions, AudioOptions, DisplayOptions};
use crate::time_travel::{render_time_travel_panel, setup_time_travel};
use crate::ui::config::{apply_loaded_config, load_config, save_config_on_exit};
use crate::ui::controls::{CheckpointState, handle_deliberate_crash, handle_time_controls, update_crash_reporter_context, update_sim_time_hash};
use crate::ui::inspector_panel::InspectorState;
use crate::ui::panel::{handle_toggle_shortcuts, render_toggle_panel, setup_ui_state, SimTime, UiState};
use crate::ui::transitions::TransitionPlugin;
use crate::ui::{apply_color_blind_mode, apply_ui_scale, apply_ui_theme, setup_oracle, setup_ui_theme, update_window_title, DemoHudPlugin, InspectorPanelPlugin, OraclePlugin, PanelsPlugin, SideReplayPlugin, UiTheme};
use crate::vfx::{DebrisPlugin, FireSpreadPlugin, SmokePlugin, render_screen_edge_indicators, setup_vfx, spawn_event_particles, update_attention_pulse_animations, update_attention_pulses, update_cpu_particles, VfxState};
use crate::world::{setup_full_atmosphere, setup_ground_with_texture, spawn_settlement_visuals, setup::PendingGltfSpawn, settlement::update_settlement_visuals};

use crate::crash_reporter;

// ============================================================================
// Resolve Asset Path
// ============================================================================

/// Resolve the asset directory path with multiple fallback strategies.
///
/// Strategy (in order):
/// 1. If ANVIL_ASSETS env var is set, use that
/// 2. Try to find assets relative to the executable location
/// 3. Try to find assets relative to CARGO_MANIFEST_DIR (dev mode)
/// 4. Try to find assets relative to current working directory
/// 5. Climb up from executable to find repo root (for dev builds)
/// 6. Fall back to "./assets"
fn resolve_asset_path() -> PathBuf {
    if let Ok(asset_path) = std::env::var("ANVIL_ASSETS") {
        let path = PathBuf::from(asset_path);
        info!("Using ANVIL_ASSETS override: {}", path.display());
        return path;
    }
    
    if let Ok(exe_path) = std::env::current_exe() {
        let exe_dir = exe_path.parent().unwrap_or(Path::new("."));
        let candidate = exe_dir.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
        let parent_candidate = exe_dir.parent().map(|p| p.join("assets"));
        if let Some(p) = parent_candidate {
            if p.exists() {
                info!("Found assets at: {}", p.display());
                return p;
            }
        }
        let mut current = exe_dir.to_path_buf();
        for _ in 0..5 {
            current = current.parent().unwrap_or(Path::new(".")).to_path_buf();
            let candidate = current.join("assets");
            if candidate.exists() {
                info!("Found assets at: {}", candidate.display());
                return candidate;
            }
            if current.join("Cargo.toml").exists() {
                let candidate = current.join("assets");
                if candidate.exists() {
                    info!("Found assets at: {}", candidate.display());
                    return candidate;
                }
            }
        }
    }
    
    if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        let mut path = PathBuf::from(manifest_dir);
        for _ in 0..2 {
            if let Some(parent) = path.parent() {
                path = parent.to_path_buf();
            }
        }
        let candidate = path.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    if let Ok(cwd) = std::env::current_dir() {
        let candidate = cwd.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    PathBuf::from("./assets")
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Resource to control debug overlay visibility
#[derive(Resource, Default)]
struct DebugOverlayVisible(bool);

/// Transition from Loading to InGame once runtime exists
fn transition_to_running(
    runtime: Option<Res<RuntimeResource>>,
    mut app_state: ResMut<NextState<AppState>>,
) {
    if runtime.is_some() {
        app_state.set(AppState::InGame);
    }
}

/// Toggle debug overlay visibility when tilde (backtick) is pressed
fn toggle_debug_overlay(
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut debug_visible: ResMut<DebugOverlayVisible>,
) {
    if keyboard_input.just_pressed(KeyCode::Backquote) {
        debug_visible.0 = !debug_visible.0;
    }
}

/// Setup system that initializes the world
#[allow(unused_mut)]
fn setup(
    mut commands: Commands,
    mut materials: ResMut<Assets<StandardMaterial>>,
    asset_server: Res<AssetServer>,
) {
    crate::world::setup::setup_world(commands, materials, asset_server);
}

/// Spawn pending GLTF entities
fn spawn_pending_gltfs(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    pending: Query<(Entity, &PendingGltfSpawn)>,
) {
    for (entity, pending) in pending.iter() {
        let scene_handle = asset_server.load(
            GltfAssetLabel::Scene(0).from_asset(pending.path.clone())
        );
        commands.spawn((
            SceneRoot(scene_handle),
            Transform::from_xyz(pending.position.x, pending.position.y, pending.position.z),
            AssetOriginTag(pending.origin.clone()),
        ));
        commands.entity(entity).despawn();
    }
}

/// Debug overlay rendering system
fn debug_overlay(
    mut egui_contexts: EguiContexts,
    query: Query<&AssetOriginTag>,
    runtime: Res<RuntimeResource>,
    tick_counter: Res<SimTickCounter>,
    sim_time: Res<SimTime>,
    debug_visible: Res<DebugOverlayVisible>,
) {
    if !debug_visible.0 {
        return;
    }
    let (total, fallback_count) = debug_fallback_summary(&query);

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::Window::new("Anvil Debug Overlay").show(ctx, |ui| {
            ui.label(format!("Assets rendered: {}", total));
            ui.label(format!(
                "Using fallback: {} {}",
                fallback_count,
                if fallback_count > 0 { "\u{26a0}" } else { "\u{2705}" }
            ));
            if fallback_count > 0 {
                ui.colored_label(egui::Color32::YELLOW, "Some assets are using fallback materials.");
            }
            ui.label(format!("Runtime: {} loaded regions", runtime.runtime.loaded_regions.len()));
            ui.label(format!("State hash: {}", sim_time.hash));

            ui.separator();
            ui.label("Phase 3 Systems:");
            ui.label(format!(
                "  NPC System: {} persons, {} settlements",
                runtime.runtime.npc_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.npc_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Catastrophe System: {} active events",
                runtime.runtime.catastrophe_system().map_or(0, |s| s.active_events.len())
            ));
            ui.label(format!(
                "  Joy System: {} persons, {} settlements",
                runtime.runtime.joy_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.joy_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Physics System: {} rigid bodies",
                runtime.runtime.physics_system().map_or(0, |s| s.rigid_body_set.len())
            ));
            ui.separator();
            ui.label(format!("Sim Tick: {}", tick_counter.count));
        });
    }
}

// ============================================================================
// Plugin Registration
// ============================================================================

/// Register all demo plugins, resources, and systems with the Bevy app.
pub fn register_demo_plugins(app: &mut App) {
    let asset_path = resolve_asset_path();
    let asset_path_str = asset_path.to_string_lossy().into_owned();

    app
        .add_plugins(DefaultPlugins.set(AssetPlugin {
            file_path: asset_path_str,
            ..default()
        }).disable::<LogPlugin>())
        .init_state::<AppState>()
        .add_plugins(EguiPlugin::default())
        .add_plugins(AnvilAssetPlugin)
        .add_plugins(PlayerPlugin)
        .add_plugins(AtmosphereDriverPlugin)
        .add_plugins((
            AudioPlugin,
            AshveilAudioPlugin,
        ))
        .add_plugins((
            EnvironmentPlugin,
            SkyPlugin,
        ))
        .add_plugins(AppPlugin)
        .add_plugins(TransitionPlugin)
        .add_plugins(ScenarioLoaderPlugin)
        .add_plugins(SimBridgePlugin)
        .add_plugins(DemoSequencerPlugin)
        .add_plugins(GlbRenderingPlugin)
        .add_plugins(FireSpreadPlugin)
        .add_plugins(SmokePlugin)
        .add_plugins(DebrisPlugin)
        .add_plugins(NeedsBarPlugin)
        .add_plugins(SkillFlashPlugin)
        .add_plugins(DemoHudPlugin)
        .add_plugins(InspectorPanelPlugin)
        .add_plugins(PanelsPlugin)
        .add_plugins(SideReplayPlugin)
        .add_plugins(OraclePlugin)
        .add_plugins(FrameTimeDiagnosticsPlugin::default())
        .init_resource::<SimTickCounter>()
        .init_resource::<SimRng>()
        .init_resource::<UiState>()
        .init_resource::<SimTime>()
        .init_resource::<CheckpointState>()
        .init_resource::<DisplayOptions>()
        .init_resource::<AudioOptions>()
        .init_resource::<AccessibilityOptions>()
        .init_resource::<CameraState>()
        .init_resource::<EventLog>()
        .init_resource::<CatastrophePanelState>()
        .init_resource::<InspectorState>()
        .init_resource::<PerformancePanelState>()
        .init_resource::<NpcVisualState>()
        .init_resource::<OverlayState>()
        .init_resource::<UiTheme>()
        .init_resource::<VfxState>()
        .init_resource::<DebugOverlayVisible>()
        .add_systems(Startup, (
            setup,
            load_config,
            setup_ui_state,
            setup_main_camera,
            setup_event_log,
            setup_catastrophe_panel,
            setup_performance_panel,
            setup_overlays,
            setup_time_travel,
            setup_oracle_overlay,
            setup_oracle,
            setup_vfx,
            setup_dev_experience,
            setup_ui_theme,
            spawn_sun,
            crash_reporter::startup_update_last_session,
        ))
        .add_systems(OnEnter(AppState::Loading), (
            setup_full_atmosphere,
            setup_ground_with_texture,
            spawn_settlement_visuals,
        ))
        .add_systems(Startup, apply_loaded_config.after(setup_ui_state))
        .add_systems(PreUpdate, crate::world::decorate_new_cameras)
        .add_systems(PreUpdate, (apply_ui_theme, apply_ui_scale, apply_color_blind_mode))
        .add_systems(PreUpdate, update_window_title)
        .configure_sets(PreUpdate, (
            EnvironmentSet::Bridge,
            EnvironmentSet::Interpolate,
            EnvironmentSet::Apply,
        ).chain())
        .add_systems(PreUpdate, (
            sim_bridge_system.in_set(EnvironmentSet::Bridge),
        ))
        .add_systems(PreUpdate, (
            handle_camera_shortcuts,
        ))
        .add_systems(PostUpdate, despawn_gltf_cameras)
        .add_systems(Update, (
            tick_simulation_systems.run_if(resource_exists::<RuntimeResource>),
            spawn_pending_gltfs,
            process_pending_catastrophes.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulses.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulse_animations,
            update_cpu_particles,
            spawn_event_particles.run_if(resource_exists::<RuntimeResource>),
            despawn_npc_visuals,
            update_emotion_lines,
            update_status_rings,
            update_settlement_visuals.run_if(resource_exists::<RuntimeResource>),
            update_npc_breathing_system,
            update_npc_rotation_toward_targets,
            update_npc_movement,
            update_selection_rings,
            update_selection_ring_visibility,
        ).run_if(in_state(AppState::InGame)))
        .add_systems(Update, (
            handle_toggle_shortcuts,
            handle_time_controls.run_if(resource_exists::<RuntimeResource>.and(resource_exists::<crate::app::WorldResource>)),
            handle_catastrophe_shortcuts,
            add_test_events,
        ))
        .add_systems(Last, (
            update_focus_camera,
            save_config_on_exit,
        ))
        .add_systems(Update, (
            handle_mouse_wheel_zoom,
            update_action_halos,
        ))
        .add_systems(Update, spawn_npc_visuals
            .after(tick_simulation_systems)
            .run_if(in_state(AppState::InGame))
            .run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(Update, (
            transition_to_running.run_if(in_state(AppState::Loading)),
        ))
        .add_systems(Update, (
            toggle_debug_overlay,
        ))
        .add_systems(PreUpdate, update_sim_time_hash.run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(PreUpdate, update_crash_reporter_context)
        .add_systems(PreUpdate, handle_deliberate_crash)
        .add_systems(EguiPrimaryContextPass, (render_toggle_panel, render_event_log, render_catastrophe_panel, render_performance_panel, render_time_travel_panel, render_oracle_overlay, render_dev_panel, debug_overlay.run_if(resource_exists::<RuntimeResource>), render_network_line_legend, render_screen_edge_indicators.run_if(resource_exists::<RuntimeResource>)));
}
```

# plugins/mod.rs
```rust
//! Plugins for anvil_demo
//!
//! This module contains all the Bevy plugins for the demo application.

pub mod registration;
pub mod sim_bridge;

pub use sim_bridge::{SimBridgePlugin, SimBridgeSet};
```

# main.rs (demo)
```rust
#![allow(dead_code)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]
//!
//! anvil_demo — a live viewport into the Anvil simulation.
//!
//! Cap list (v2 - Demo Integration Sprint Phase 2):
//! 1. Tick the simulation in the demo loop
//! 2. Toggle panel with simulation controls
//! 3. Show Phase 3 systems in the debug overlay
//! 4. Load a real catalogue
//! 5. Spawn entities for every family + biome combination
//! 6. Apply material overrides per entity
//! 7. Debug overlay: highlight fallback assets
//! 8. Fly camera and basic lighting

mod animation;
mod app;
mod audio;
mod camera;
mod catastrophe_panel;
mod character;
mod crash_reporter;
mod demo;
mod dev_experience;
mod event_log;
mod npc;
mod oracle_overlay;
mod overlays;
mod performance_panel;
mod player;
mod plugins;
mod rendering;
mod scenarios;
mod sim;
mod sim_bridge;
mod spawn_sun;
mod states;
mod time_travel;
mod ui;
mod vfx;
mod world;
mod npc_visuals;

use bevy::prelude::*;
use std::path::{Path, PathBuf};
use tracing::info;

use tracing_appender::rolling::{RollingFileAppender, Rotation};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt, EnvFilter, Layer};

// Re-export from plugins for main
use plugins::registration::register_demo_plugins;

// ============================================================================
// Logging and Tracing
// ============================================================================

/// Parse --log-level CLI argument
/// Returns the log level filter string, or default
fn get_log_level_filter() -> String {
    let args: Vec<String> = std::env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--log-level" && i + 1 < args.len() {
            return args[i + 1].clone();
        }
    }
    // Default: warn level globally, info for anvil_sim
    "warn,anvil_sim=info".to_string()
}

/// Set up tracing with console and file layers.
/// Console: human-readable, compact format, filtered by RUST_LOG or --log-level
/// File: JSON format, rolling file with daily rotation, max 7 files
fn setup_tracing() -> tracing_appender::non_blocking::WorkerGuard {
    // Create logs directory if it doesn't exist
    let logs_dir = Path::new("logs");
    std::fs::create_dir_all(logs_dir).ok();

    // Get log level from CLI or default
    let log_filter = get_log_level_filter();

    // File appender with rolling: daily rotation, max 7 files
    #[allow(clippy::expect_used)]
    let file_appender = RollingFileAppender::builder()
        .rotation(Rotation::DAILY)
        .filename_prefix("anvil_sim")
        .filename_suffix("json")
        .max_log_files(7)
        .build(logs_dir)
        .expect("Failed to create rolling file appender");

    // Non-blocking writer for the file layer
    let (non_blocking_file, _guard) = tracing_appender::non_blocking(file_appender);

    // Console layer: compact format
    let console_layer = tracing_subscriber::fmt::layer()
        .compact()
        .with_filter(EnvFilter::new(&log_filter));

    // File layer: JSON format (always writes warn+ and anvil_sim=info)
    let file_filter = EnvFilter::new("warn,anvil_sim=info");
    let file_layer = tracing_subscriber::fmt::layer()
        .json()
        .with_writer(non_blocking_file)
        .with_filter(file_filter);

    // Combine layers and initialize
    tracing_subscriber::registry()
        .with(console_layer)
        .with(file_layer)
        .init();

    _guard
}

/// Resolve the asset directory path with multiple fallback strategies.
///
/// Strategy (in order):
/// 1. If ANVIL_ASSETS env var is set, use that
/// 2. Try to find assets relative to the executable location
/// 3. Try to find assets relative to CARGO_MANIFEST_DIR (dev mode)
/// 4. Try to find assets relative to current working directory
/// 5. Climb up from executable to find repo root (for dev builds)
/// 6. Fall back to "./assets"
fn resolve_asset_path() -> PathBuf {
    // Check for explicit environment variable override
    if let Ok(asset_path) = std::env::var("ANVIL_ASSETS") {
        let path = PathBuf::from(asset_path);
        info!("Using ANVIL_ASSETS override: {}", path.display());
        return path;
    }
    
    // Try to find assets relative to the executable location (standalone builds)
    if let Ok(exe_path) = std::env::current_exe() {
        let exe_dir = exe_path.parent().unwrap_or(Path::new("."));
        let candidate = exe_dir.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
        // Also check parent directory (common for bundled apps)
        let parent_candidate = exe_dir.parent().map(|p| p.join("assets"));
        if let Some(p) = parent_candidate {
            if p.exists() {
                info!("Found assets at: {}", p.display());
                return p;
            }
        }
        // Climb up to find repo root from executable location
        let mut current = exe_dir.to_path_buf();
        for _ in 0..5 {
            current = current.parent().unwrap_or(Path::new(".")).to_path_buf();
            let candidate = current.join("assets");
            if candidate.exists() {
                info!("Found assets at: {}", candidate.display());
                return candidate;
            }
            if current.join("Cargo.toml").exists() {
                let candidate = current.join("assets");
                if candidate.exists() {
                    info!("Found assets at: {}", candidate.display());
                    return candidate;
                }
            }
        }
    }
    
    // Try CARGO_MANIFEST_DIR
    if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        let mut path = PathBuf::from(manifest_dir);
        for _ in 0..2 {
            if let Some(parent) = path.parent() {
                path = parent.to_path_buf();
            }
        }
        let candidate = path.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    // Try current working directory
    if let Ok(cwd) = std::env::current_dir() {
        let candidate = cwd.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    PathBuf::from("./assets")
}

// ============================================================================
// Main
// ============================================================================

fn main() {
    // Initialize tracing with console and file layers
    let _tracing_guard = setup_tracing();

    // Initialize crash reporter (must be first to catch any panics)
    crash_reporter::init();

    // Check for unreported crashes from previous session
    crash_reporter::print_crash_detections();

    let mut app = App::new();
    register_demo_plugins(&mut app);
    app.run();
}
```

# app.rs
```rust
//! Application state machine and plugin setup for the Application Shell Sprint.
//!
//! This module defines the `AppState` enum that drives the application flow and
//! the `AppPlugin` that sets up all the state-related systems.

use bevy::prelude::*;
use anvil_runtime::Runtime;
use anvil_world::WorldAuthored;

use crate::states::credits::CreditsPlugin;
use crate::states::error::ErrorPlugin;
use crate::states::ingame::InGamePlugin;
use crate::states::loading::LoadingPlugin;
use crate::states::menu::MainMenuPlugin;
use crate::states::options::OptionsPlugin;
use crate::states::paused::PausedPlugin;
use crate::states::splash::SplashPlugin;

/// The application state machine.
///
/// State transitions:
/// ```text
/// Boot → Splash → MainMenu ↔ Options
///                    ↓
///                 Loading
///                    ↓
///                 InGame ↔ Paused ↔ Options
///                              ↓
///                          MainMenu
///                    ↓
///                  Error
/// ```
#[derive(States, Default, Clone, Eq, PartialEq, Debug, Hash)]
pub enum AppState {
    /// Initial state - splash screen
    #[default]
    Splash,
    /// Main menu screen
    MainMenu,
    /// Options menu
    Options,
    /// Credits screen
    Credits,
    /// Loading screen
    Loading,
    /// In-game state
    InGame,
    /// Paused state
    Paused,
    /// Error state
    Error,
}

/// Resource to track the selected scenario.
#[derive(Resource, Clone, Debug)]
#[allow(dead_code)]
pub struct ScenarioSelection {
    /// The identifier of the selected scenario
    pub scenario_id: String,
    /// The display name of the scenario
    pub display_name: String,
    /// The description of the scenario
    pub description: String,
}

impl Default for ScenarioSelection {
    fn default() -> Self {
        Self {
            scenario_id: "greyridge".to_string(),
            display_name: "Greyridge".to_string(),
            description: "A highland settlement faces water scarcity".to_string(),
        }
    }
}

/// Resource to track the current sim speed multiplier for the menu background.
/// - 0.0 = paused (no ticks)
/// - 0.1 = slow (1 tick per 10 frames)
/// - 1.0 = normal (default ticks per frame)
#[derive(Resource, Debug, Clone, Copy)]
pub struct SimSpeed(pub f32);

impl Default for SimSpeed {
    fn default() -> Self {
        Self(0.1) // Menu runs at 0.1x speed
    }
}

impl SimSpeed {
    /// Returns true if simulation is paused (multiplier is 0.0).
    pub fn paused(&self) -> bool {
        self.0 <= 0.0
    }

    /// Returns the display string for the speed.
    pub fn display(&self) -> String {
        if self.paused() {
            "PAUSED".to_string()
        } else {
            match self.0 {
                0.1 => "0.1x".to_string(),
                0.5 => "0.5x".to_string(),
                1.0 => "1x".to_string(),
                2.0 => "2x".to_string(),
                5.0 => "5x".to_string(),
                10.0 => "10x".to_string(),
                _ => format!("{}x", self.0),
            }
        }
    }

    /// Returns the color for the speed display.
    pub fn color(&self) -> egui::Color32 {
        if self.paused() {
            egui::Color32::RED
        } else {
            match self.0 {
                0.1 | 0.5 => egui::Color32::LIGHT_BLUE,
                1.0 => egui::Color32::WHITE,
                2.0 => egui::Color32::LIGHT_GREEN,
                5.0 => egui::Color32::LIGHT_YELLOW,
                10.0 => egui::Color32::ORANGE,
                _ => egui::Color32::WHITE,
            }
        }
    }
}

/// Runtime resource wrapper for Bevy.
#[derive(Resource)]
pub struct RuntimeResource {
    pub runtime: Runtime,
}

impl Default for RuntimeResource {
    fn default() -> Self {
        Self { runtime: Runtime::new(WorldAuthored::default()) }
    }
}

/// World resource wrapper for Bevy.
#[derive(Resource, Clone, Default)]
pub struct WorldResource {
    pub world: WorldAuthored,
}

/// Plugin that sets up the application state machine and all state-related systems.
pub struct AppPlugin;

impl Plugin for AppPlugin {
    fn build(&self, app: &mut App) {
        // Add all state plugins
        app.add_plugins((
            SplashPlugin,
            MainMenuPlugin,
            OptionsPlugin,
            CreditsPlugin,
            LoadingPlugin,
            InGamePlugin,
            PausedPlugin,
            ErrorPlugin,
        ));

        // Initialize resources
        app.init_resource::<ScenarioSelection>()
            .init_resource::<SimSpeed>();
    }
}
```

# environment/plugin.rs (bevy side)
```rust
// crates/anvil_bevy/src/environment/plugin.rs
use bevy::light::GlobalAmbientLight;
use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

use super::config::EnvironmentConfig;
use super::state::EnvironmentState;
use super::solar::resolve_targets;
use crate::sim_bridge::SimSnapshot;
use crate::markers::{SunLight, CameraFog};

// ---------------------------------------------------------------------------
// SystemSet – guarantees Bridge → Interpolate → Apply ordering
// ---------------------------------------------------------------------------
/// Environment system ordering sets.
#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub enum EnvironmentSet {
    /// Bridge set where sim_bridge_system writes SimSnapshot (registered in anvil_demo).
    Bridge,
    /// Interpolate set where resolve_targets + state.tick() runs.
    Interpolate,
    /// Apply set where smoothed state is written to Bevy components (sun, fog, ambient).
    Apply,
}

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------
/// Plugin that manages environment interpolation and application.
///
/// This plugin:
/// - Inserts default EnvironmentConfig, EnvironmentState, and SimSnapshot resources
/// - Configures system ordering: Bridge → Interpolate → Apply
/// - Runs interpolation system (resolve_targets + tick)
/// - Runs apply system (writes to sun, fog, ambient)
pub struct EnvironmentPlugin;

impl Plugin for EnvironmentPlugin {
    fn build(&self, app: &mut App) {
        let config = EnvironmentConfig::default();
        app.insert_resource(EnvironmentState::new(&config))
           .insert_resource(config)
           .insert_resource(SimSnapshot::default())
           .configure_sets(
               PreUpdate,
               (
                   EnvironmentSet::Bridge,
                   EnvironmentSet::Interpolate,
                   EnvironmentSet::Apply,
               ).chain(),
           )
           .add_systems(
               PreUpdate,
               (
                   environment_interpolate_system.in_set(EnvironmentSet::Interpolate),
                   environment_apply_system.in_set(EnvironmentSet::Apply),
               ),
           );
    }
}

// ---------------------------------------------------------------------------
// System 1 — derive targets → tick smoothing
// ---------------------------------------------------------------------------
fn environment_interpolate_system(
    snapshot: Res<SimSnapshot>,
    config:   Res<EnvironmentConfig>,
    mut env:  ResMut<EnvironmentState>,
    time:     Res<Time>,
) {
    resolve_targets(&snapshot, &config, &mut env);
    env.tick(time.delta_secs());
}

// ---------------------------------------------------------------------------
// System 2 — push smoothed state into Bevy's lights and fog
// ---------------------------------------------------------------------------
fn environment_apply_system(
    env:          Res<EnvironmentState>,
    mut sun_q:    Query<(&mut DirectionalLight, &mut Transform), With<SunLight>>,
    mut fog_q:    Query<&mut DistanceFog, With<CameraFog>>,
    mut ambient:  ResMut<GlobalAmbientLight>,
) {
    // ── Sun ──────────────────────────────────────────────────────────
    match sun_q.single_mut() {
        Ok((mut light, mut transform)) => {
            light.color = Color::LinearRgba(env.sun_color.current);
            light.illuminance = env.sun_illuminance.current;
            let dir = env.sun_dir_vec();
            if dir.length_squared() > 0.001 {
                let up = if dir.y.abs() > 0.98 { Vec3::X } else { Vec3::Y };
                transform.look_to(dir, up);
            }
        }
        Err(_) => {
            warn_once!("EnvironmentPlugin: no SunLight entity found");
        }
    }

    // ── Fog ──────────────────────────────────────────────────────────
    match fog_q.single_mut() {
        Ok(mut fog) => {
            fog.color = Color::LinearRgba(env.fog_color.current);
            fog.falloff = FogFalloff::Exponential { density: env.fog_density.current };
        }
        Err(_) => {
            warn_once!("EnvironmentPlugin: no CameraFog entity found");
        }
    }

    // ── Ambient ──────────────────────────────────────────────────────
    ambient.color = Color::LinearRgba(env.ambient_color.current);
    ambient.brightness = env.ambient_brightness.current;
}


```

# lib.rs (anvil_bevy)
```rust
//! # anvil_bevy
//!
//! **Layer:** PRESENTATION
//!
//! **Purpose:** Converts `anvil_assets` types into Bevy components and materials,
//! enabling the Anvil pipeline to render in a Bevy application.
//!
//! **Main Entry Points:**
//! - [`AnvilAssetPlugin`] — Bevy plugin that registers Anvil asset types and components
//! - [`to_standard_material()`] — converts `MaterialOverride` to Bevy `StandardMaterial`
//! - [`load_mesh()`] — loads mesh assets from resolved asset paths
//! - [`AssetOriginTag`] — component tracking material origin (authored vs fallback)
//! - [`debug_fallback_summary()`] — debug utility for counting fallback assets

#![deny(missing_docs)]

#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]

use anvil_assets::prelude::*;
use bevy::asset::AssetServer;
use bevy::mesh::Mesh;
use bevy::prelude::*;
use std::path::PathBuf;
use std::sync::Arc;

/// Convert a `MaterialOverride` into a Bevy `StandardMaterial`.
///
/// This function maps Anvil's material properties to Bevy's standard material:
/// - `albedo_texture` → `base_color_texture`
/// - `normal_texture` → `normal_map_texture`
/// - `roughness_metallic_texture` → `metallic_roughness_texture`
/// - `base_color_tint` → `base_color` (with warm clay fallback if missing)
/// - `perceptual_roughness` → `perceptual_roughness`
/// - `metallic` → `metallic`
/// - `emissive` → `emissive`
///
/// Textures are loaded via the `AssetServer` and return handles.
pub fn to_standard_material(
    overrides: &MaterialOverride,
    asset_server: &AssetServer,
) -> StandardMaterial {
    let mut mat = StandardMaterial::default();

    if let Some(ref albedo_tex) = overrides.albedo_texture {
        let path = albedo_tex.to_string_lossy().to_string();
        mat.base_color_texture = Some(asset_server.load(path));
    }
    if let Some(ref normal_tex) = overrides.normal_texture {
        let path = normal_tex.to_string_lossy().to_string();
        mat.normal_map_texture = Some(asset_server.load(path));
    }
    if let Some(ref orm_tex) = overrides.roughness_metallic_texture {
        let path = orm_tex.to_string_lossy().to_string();
        mat.metallic_roughness_texture = Some(asset_server.load(path));
    }
    if let Some(tint) = overrides.base_color_tint {
        mat.base_color = Color::srgba(tint[0], tint[1], tint[2], tint[3]);
    } else {
        mat.base_color = Color::srgb(0.8, 0.5, 0.3); // warm clay fallback
    }
    if let Some(roughness) = overrides.perceptual_roughness {
        mat.perceptual_roughness = roughness;
    }
    if let Some(metallic) = overrides.metallic {
        mat.metallic = metallic;
    }
    if let Some(emissive) = overrides.emissive {
        mat.emissive = Color::srgb(emissive[0], emissive[1], emissive[2]).into();
    }
    mat
}

/// Load a mesh from an `Arc<PathBuf>` (as stored in `ResolvedAsset`).
///
/// This is a synchronous operation that returns a `Handle<Mesh>`. The mesh data
/// is loaded asynchronously by Bevy's asset server.
///
/// # Errors
/// This function does not return errors directly; invalid paths will result
/// in failed asset loads that can be detected through Bevy's asset events.
pub fn load_mesh(path: &Arc<PathBuf>, asset_server: &AssetServer) -> Handle<Mesh> {
    asset_server.load(path.to_string_lossy().to_string())
}

/// Tag component marking whether an entity uses explicit or fallback material.
///
/// This component is attached to Bevy entities that were spawned from Anvil assets.
/// It carries a [`MaterialOrigin`] value indicating whether the entity's material
/// came from an authored asset (`MaterialOrigin::Authored`) or was generated
/// as a fallback (`MaterialOrigin::Fallback`).
///
/// Use this for debugging and runtime inspection of asset loading.
#[derive(Component)]
pub struct AssetOriginTag(pub MaterialOrigin);

/// Count fallback assets and return a summary tuple.
///
/// This debug utility function iterates over a query of [`AssetOriginTag`] components
/// and returns a tuple of `(total_entities, fallback_count)`. It is primarily used
/// in debug builds to monitor asset loading and identify entities that failed
/// to load their authored materials.
///
/// # Usage
/// ```ignore
/// let (total, fallbacks) = debug_fallback_summary(&query);
/// println!("Loaded {} entities, {} using fallback materials", total, fallbacks);
/// ```
pub fn debug_fallback_summary(query: &Query<&AssetOriginTag>) -> (usize, usize) {
    let fallback = query.iter().filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
    let total = query.iter().count();
    (total, fallback)
}

/// Bevy plugin that registers Anvil asset types and components.
///
/// This plugin is a placeholder for future Anvil-specific asset loaders.
/// Currently it serves as the central registration point for Anvil asset integration.
#[derive(Default)]
pub struct AnvilAssetPlugin;

impl Plugin for AnvilAssetPlugin {
    fn build(&self, _app: &mut App) {
        // Future: register custom asset loaders here
        // e.g., app.init_asset_loader::<AnvilAssetLoader>()
    }
}

// ---------------------------------------------------------------------------

pub mod audio;

/// Simulation bridge types for presentation layer.
pub mod sim_bridge;

/// Environment systems and configuration.
pub mod environment;

/// Sky sphere rendering.
pub mod sky;

/// Marker components for entity identification.
pub mod markers;

/// Terrain material extension for batch rendering.
pub mod terrain;

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use bevy::asset::AssetPlugin;
    use bevy::prelude::{App, Color, Image, MinimalPlugins, World};
    use std::sync::Arc;

    #[test]
    fn test_to_standard_material_albedo_propagation() {
        // Create a mock asset server for testing
        // We can't fully test asset loading without initializing all Bevy asset types,
        // but we can verify the color fallback behavior
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, AssetPlugin::default()));
        
        // Initialize the Image asset type to avoid panics
        app.init_asset::<Image>();
        
        let asset_server = app.world().get_resource::<AssetServer>().unwrap();

        let overrides = MaterialOverride {
            albedo_texture: Some(Arc::new(PathBuf::from("test_albedo.png"))),
            normal_texture: None,
            roughness_metallic_texture: None,
            base_color_tint: None,
            perceptual_roughness: None,
            metallic: None,
            emissive: None,
        };

        let material = to_standard_material(&overrides, asset_server);

        // Should have the albedo texture loaded
        assert!(material.base_color_texture.is_some());
        // Should use warm clay fallback for base_color since no tint provided
        assert_eq!(material.base_color, Color::srgb(0.8, 0.5, 0.3));
    }

    #[test]
    fn test_to_standard_material_fallback_colour() {
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, AssetPlugin::default()));
        app.init_asset::<Image>();
        
        let asset_server = app.world().get_resource::<AssetServer>().unwrap();

        let overrides = MaterialOverride {
            albedo_texture: None,
            normal_texture: None,
            roughness_metallic_texture: None,
            base_color_tint: None,
            perceptual_roughness: None,
            metallic: None,
            emissive: None,
        };

        let material = to_standard_material(&overrides, asset_server);

        // Should use warm clay fallback when no albedo or tint
        assert_eq!(material.base_color, Color::srgb(0.8, 0.5, 0.3));
        assert!(material.base_color_texture.is_none());
    }

    #[test]
    fn test_debug_fallback_summary_empty() {
        // Test with an empty world - no entities with AssetOriginTag
        // Create a world and verify there are no AssetOriginTag components
        let mut world = World::new();
        let entity_count = world.query::<&AssetOriginTag>().iter(&world).count();
        let fallback_count = world.query::<&AssetOriginTag>().iter(&world)
            .filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
        
        assert_eq!(entity_count, 0);
        assert_eq!(fallback_count, 0);
    }

    #[test]
    fn test_debug_fallback_summary_non_empty() {
        // Test with a world that has AssetOriginTag entities
        let mut world = World::new();
        
        // Spawn entities directly without using Commands
        // MaterialOrigin has Explicit and Fallback variants
        world.spawn((AssetOriginTag(MaterialOrigin::Explicit),));
        world.spawn((AssetOriginTag(MaterialOrigin::Explicit),));
        world.spawn((AssetOriginTag(MaterialOrigin::Fallback),));
        
        let entity_count = world.query::<&AssetOriginTag>().iter(&world).count();
        let fallback_count = world.query::<&AssetOriginTag>().iter(&world)
            .filter(|tag| tag.0 == MaterialOrigin::Fallback).count();
        
        assert_eq!(entity_count, 3);
        assert_eq!(fallback_count, 1);
    }
    
    #[allow(dead_code)]
    fn _unused_check() {
        // Used to prevent unused import warnings in test module
    }
}
```

# lib.rs (anvil_demo)
```rust
(file not found)
```
