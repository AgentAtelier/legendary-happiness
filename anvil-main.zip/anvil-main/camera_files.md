
### crates/anvil_demo/src/camera/demo_spline.rs
```rust
//! Demo camera spline system.
//!
//! Provides a hand-authored camera path through the Ashveil demo.

#![allow(dead_code)]

use bevy::camera::Camera3d;
use bevy::prelude::*;

/// A single keyframe in the camera spline.
#[derive(Clone, Debug)]
pub struct SplineKeyframe {
    /// Camera position at this keyframe.
    pub position: Vec3,
    /// Point the camera should look at.
    pub look_target: Vec3,
    /// Duration in seconds to reach this keyframe from the previous one.
    pub duration_s: f32,
}

/// Camera control mode.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CameraMode {
    /// Camera follows the scripted spline path.
    Scripted,
    /// Camera is free (player controlled).
    Free,
}

/// Resource holding the demo camera spline state.
#[derive(Resource)]
pub struct DemoSpline {
    /// Sequence of keyframes defining the camera path.
    pub keyframes: Vec<SplineKeyframe>,
    /// Current position along the spline in seconds.
    pub current_time: f32,
    /// Current camera mode.
    pub mode: CameraMode,
    /// Whether the spline is paused.
    pub paused: bool,
}

impl Default for DemoSpline {
    fn default() -> Self {
        // Keyframe sequence from DEMO_VISION.md §3
        // Times are approximate
        Self {
            keyframes: vec![
                // 0:00 - Descending from above (600m up, 400m north) to settlement
                SplineKeyframe {
                    position: Vec3::new(0.0, 600.0, 400.0),
                    look_target: Vec3::new(0.0, 0.0, 0.0),
                    duration_s: 1.0,
                },
                // Approach to settlement
                SplineKeyframe {
                    position: Vec3::new(0.0, 100.0, 150.0),
                    look_target: Vec3::new(0.0, 0.0, 0.0),
                    duration_s: 44.0, // Reach at ~0:45
                },
                // 0:45 - Pull out to 900m, revealing eastern ridge
                SplineKeyframe {
                    position: Vec3::new(0.0, 900.0, -300.0),
                    look_target: Vec3::new(0.0, 0.0, 0.0),
                    duration_s: 45.0, // Reach at ~1:30
                },
                // 1:30 - Mid-shot tracking Senne at the watchtower
                SplineKeyframe {
                    position: Vec3::new(50.0, 50.0, 20.0),
                    look_target: Vec3::new(50.0, 10.0, 20.0),
                    duration_s: 45.0, // Reach at ~2:15
                },
                // 2:15 - Wide shot, fire ignition on ridge
                SplineKeyframe {
                    position: Vec3::new(-200.0, 300.0, -100.0),
                    look_target: Vec3::new(-150.0, 0.0, -50.0),
                    duration_s: 45.0, // Reach at ~3:00
                },
                // 3:00 - Low angle behind Yarra at the granary
                SplineKeyframe {
                    position: Vec3::new(-30.0, 10.0, -10.0),
                    look_target: Vec3::new(-20.0, 5.0, -5.0),
                    duration_s: 20.0, // Reach at ~3:20
                },
                // 3:20 - Wide shot of Elder Maren at the commons
                SplineKeyframe {
                    position: Vec3::new(0.0, 150.0, -150.0),
                    look_target: Vec3::new(0.0, 0.0, -100.0),
                    duration_s: 20.0, // Reach at ~3:40
                },
                // 3:40 - Physics beat: debris falling, camera follows
                SplineKeyframe {
                    position: Vec3::new(100.0, 80.0, -50.0),
                    look_target: Vec3::new(120.0, 0.0, -30.0),
                    duration_s: 50.0, // Reach at ~4:30
                },
                // 4:30 - Wide shot, rain begins
                SplineKeyframe {
                    position: Vec3::new(0.0, 400.0, -200.0),
                    look_target: Vec3::new(0.0, 0.0, 0.0),
                    duration_s: 45.0, // Reach at ~5:15
                },
                // 5:15 - Evening, commons gathering
                SplineKeyframe {
                    position: Vec3::new(0.0, 120.0, -80.0),
                    look_target: Vec3::new(0.0, 0.0, -60.0),
                    duration_s: 30.0, // Reach at ~5:45
                },
                // 5:45 - Final hold (logo fade)
                SplineKeyframe {
                    position: Vec3::new(0.0, 120.0, -80.0),
                    look_target: Vec3::new(0.0, 0.0, -60.0),
                    duration_s: 15.0, // Hold
                },
            ],
            current_time: 0.0,
            mode: CameraMode::Scripted,
            paused: false,
        }
    }
}

/// Plugin for the demo camera spline system.
pub struct DemoSplinePlugin;

impl Plugin for DemoSplinePlugin {
    fn build(&self, app: &mut App) {
        app
            .init_resource::<DemoSpline>()
            .add_systems(Update, advance_demo_spline);
    }
}

/// Total duration of the spline in seconds.
pub fn spline_total_duration(spline: &DemoSpline) -> f32 {
    spline.keyframes.iter().map(|k| k.duration_s).sum()
}

/// Find the current keyframe index and progress within that segment.
fn find_keyframe_segment(spline: &DemoSpline) -> (usize, f32) {
    let mut accumulated_time = 0.0;

    for (i, keyframe) in spline.keyframes.iter().enumerate() {
        if accumulated_time + keyframe.duration_s >= spline.current_time {
            let segment_time = spline.current_time - accumulated_time;
            let segment_progress = segment_time / keyframe.duration_s;
            return (i, segment_progress.clamp(0.0, 1.0));
        }
        accumulated_time += keyframe.duration_s;
    }

    // Past the end - hold on last frame
    let last_idx = spline.keyframes.len().saturating_sub(1);
    (last_idx, 1.0)
}

/// Advance the demo spline and update camera transform.
pub fn advance_demo_spline(
    time: Res<Time>,
    mut spline: ResMut<DemoSpline>,
    mut camera_query: Query<&mut Transform, With<Camera3d>>,
) {
    // Only advance if in scripted mode and not paused
    if spline.mode != CameraMode::Scripted || spline.paused {
        return;
    }

    let delta = time.delta_secs();
    let total_duration = spline_total_duration(&spline);

    // Advance time, clamping at total duration
    spline.current_time = (spline.current_time + delta).min(total_duration);

    // Find which segment we're in
    let (frame_idx, progress) = find_keyframe_segment(&spline);

    // Get the current and next keyframes
    let current_kf = &spline.keyframes[frame_idx];
    let next_kf = if frame_idx + 1 < spline.keyframes.len() {
        &spline.keyframes[frame_idx + 1]
    } else {
        current_kf // Hold on last frame
    };

    // Use smoothstep for interpolation
    let t = progress * progress * (3.0 - 2.0 * progress); // smoothstep

    // Interpolate position and look target
    let position = current_kf.position.lerp(next_kf.position, t);
    let look_target = current_kf.look_target.lerp(next_kf.look_target, t);

    // Update camera transform
    for mut transform in camera_query.iter_mut() {
        *transform = Transform::from_translation(position).looking_at(look_target, Vec3::Y);
    }
}
```

### crates/anvil_demo/src/camera/mod.rs
```rust
//! Camera and navigation systems for anvil_demo.
//!
//! This module provides enhanced camera controls including:
//! - Flycam with inertia/smoothing
//! - Zoom with mouse wheel
//! - Focus mode (lock to selected NPC)
//! - NPC cycling
//! - Reset view
//! - Turbo mode
//! - Demo camera spline (scripted camera path)

use bevy::camera::{Camera, Camera3d};
use bevy::prelude::*;

use crate::npc_visuals::NpcVisual;
use crate::player::PlayerCamera;

pub mod demo_spline;
pub mod spline;

#[allow(unused_imports)]
pub use demo_spline::{CameraMode, DemoSpline, DemoSplinePlugin};
#[allow(unused_imports)]
pub use spline::{CameraPoint, CameraSpline, CameraSplinePlugin, CameraSplineSet};

/// Resource tracking camera state.
#[derive(Resource, Default)]
pub struct CameraState {
    /// Whether focus mode is active.
    pub focus_mode: bool,
    /// The entity being focused on (if any).
    pub focused_entity: Option<Entity>,
    /// Camera speed multiplier (turbo mode).
    pub speed_multiplier: f32,
    /// Default camera transform for reset.
    pub default_transform: Transform,
}

/// System that sets up the main camera.
pub fn setup_main_camera(mut commands: Commands) {
    // The flycam plugin already spawns a camera, so we just need to tag it
    // and set up the default transform
    commands.insert_resource(CameraState {
        focus_mode: false,
        focused_entity: None,
        speed_multiplier: 1.0,
        default_transform: Transform::from_xyz(0.0, 5.0, 10.0).looking_at(Vec3::ZERO, Vec3::Y),
    });
}

/// Sets explicit camera priorities to avoid ambiguity warnings.
/// UI camera (Camera2d) gets order=1, scene camera (Camera3d) gets order=0.
///
/// **Note.** Mutates the *existing* `Camera` component in place rather than
/// re-inserting one. Re-inserting `Camera { order, ..default() }` replaces
/// the whole component, which clears the render-graph configuration that
/// Bevy attaches to a camera based on its companion marker (`Camera2d` /
/// `Camera3d`). After such a replacement Bevy logs:
///
/// > Entity NNNvK has a `Camera` component, but it doesn't have a render
/// > graph configured.
///
/// Mutating only the `order` field keeps the render graph intact.
pub fn set_camera_priorities(
    mut ui_cameras: Query<&mut Camera, (With<bevy::camera::Camera2d>, Without<bevy::camera::Camera3d>)>,
    mut player_cameras: Query<&mut Camera, (With<PlayerCamera>, With<bevy::camera::Camera3d>)>,
    mut scene_cameras: Query<&mut Camera, (With<bevy::camera::Camera3d>, Without<bevy::camera::Camera2d>, Without<PlayerCamera>)>,
) {
    // UI camera: order = 1 (renders on top)
    for mut camera in &mut ui_cameras {
        camera.order = 1;
    }

    // Player camera: order = -1 (renders first, before other scene cameras)
    for mut camera in &mut player_cameras {
        camera.order = -1;
    }

    // Other scene cameras: order = 0 (renders after player camera)
    for mut camera in &mut scene_cameras {
        camera.order = 0;
    }
}

/// System that fixes bare Camera components by adding Camera3d marker.
/// This handles cameras spawned from GLTF files that don't have Bevy-specific
/// marker components. Without Camera3d or Camera2d, Bevy logs a warning about
/// missing render graph configuration.
pub fn fix_bare_cameras(
    mut commands: Commands,
    bare_cameras: Query<Entity, (With<Camera>, Without<Camera3d>, Without<Camera2d>)>,
) {
    for entity in bare_cameras.iter() {
        commands.entity(entity).insert(Camera3d::default());
    }
}

/// System that disables GLTF scene cameras that would hijack the viewport.
/// GLTF files can contain their own cameras. After fix_bare_cameras adds Camera3d
/// to them, they become fully functional and render at order 0, on top of the
/// player camera at order -1. This system removes the Camera component from
/// any non-player camera to prevent this.
pub fn disable_gltf_cameras(
    mut commands: Commands,
    gltf_cameras: Query<Entity, (With<Camera>, Without<PlayerCamera>)>,
) {
    for entity in &gltf_cameras {
        commands.entity(entity).remove::<Camera>();
    }
}

/// System that handles camera keyboard shortcuts.
pub fn handle_camera_shortcuts(
    mut camera_state: ResMut<CameraState>,
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut camera_query: Query<&mut Transform, (With<Camera3d>, Without<NpcVisual>)>,
    npc_visuals: Query<Entity, With<NpcVisual>>,
) {
    // Turbo: Shift increases camera speed
    if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
        camera_state.speed_multiplier = 2.0;
    } else {
        camera_state.speed_multiplier = 1.0;
    }

    // Focus mode: F locks camera to selected NPC
    if keyboard_input.just_pressed(KeyCode::KeyF) {
        camera_state.focus_mode = !camera_state.focus_mode;
        
        if camera_state.focus_mode && camera_state.focused_entity.is_none() {
            // Focus on first NPC if none selected
            if let Some(first_npc) = npc_visuals.iter().next() {
                camera_state.focused_entity = Some(first_npc);
            }
        }
        
        println!("Focus mode: {}", if camera_state.focus_mode { "ON" } else { "OFF" });
    }

    // Cycle NPCs: Tab / Shift+Tab
    if keyboard_input.just_pressed(KeyCode::Tab) {
        let npcs: Vec<Entity> = npc_visuals.iter().collect();
        if !npcs.is_empty() {
            let current_idx = camera_state.focused_entity
                .and_then(|e| npcs.iter().position(|&x| x == e));
            
            let next_idx = if keyboard_input.pressed(KeyCode::ShiftLeft) || keyboard_input.pressed(KeyCode::ShiftRight) {
                // Shift+Tab: previous
                current_idx.map(|i| (i + npcs.len() - 1) % npcs.len()).unwrap_or(0)
            } else {
                // Tab: next
                current_idx.map(|i| (i + 1) % npcs.len()).unwrap_or(0)
            };
            
            camera_state.focused_entity = Some(npcs[next_idx]);
            camera_state.focus_mode = true;
            println!("Focused on NPC: {:?}", camera_state.focused_entity);
        }
    }

    // Reset view: Home
    if keyboard_input.just_pressed(KeyCode::Home) {
        camera_state.focus_mode = false;
        camera_state.focused_entity = None;
        
        for mut transform in camera_query.iter_mut() {
            *transform = camera_state.default_transform;
        }
        
        println!("Camera reset to default view");
    }

    // Release focus: Esc
    if keyboard_input.just_pressed(KeyCode::Escape) {
        let was_focused = camera_state.focus_mode;
        camera_state.focus_mode = false;
        camera_state.focused_entity = None;
        if was_focused {
            println!("Focus released");
        }
    }
}

/// System that implements focus mode camera tracking.
/// Uses exponential smoothing: pos += (target - pos) * (1.0 - exp(-10.0 * delta))
/// Settles in ~0.4s as specified in Visual Uplift Sprint.
pub fn update_focus_camera(
    time: Res<Time>,
    camera_state: Res<CameraState>,
    mut camera_query: Query<&mut Transform, (With<Camera3d>, Without<NpcVisual>)>,
    npc_transforms: Query<&Transform, (With<NpcVisual>, Without<Camera3d>)>,
) {
    if !camera_state.focus_mode || camera_state.focused_entity.is_none() {
        return;
    }

    let delta = time.delta_secs();

    if let Some(focused) = camera_state.focused_entity
        && let Ok(npc_transform) = npc_transforms.get(focused)
    {
        for mut camera_transform in camera_query.iter_mut() {
            // Calculate target position: slightly offset from NPC
            let target_position = npc_transform.translation + Vec3::new(0.0, 2.0, 5.0);
            let target_rotation = Quat::from_rotation_arc(
                (target_position - npc_transform.translation).normalize(),
                Vec3::Y,
            );

            // Exponential smoothing for position
            // pos += (target - pos) * (1.0 - exp(-10.0 * delta))
            let smoothing_factor = 1.0 - (-10.0 * delta).exp();
            let current_pos = camera_transform.translation;
            camera_transform.translation = current_pos + (target_position - current_pos) * smoothing_factor;

            // Exponential smoothing for rotation (slerp)
            // Snap if dot < 0.0 to prevent 180° spin
            let dot = camera_transform.rotation.dot(target_rotation);
            if dot < 0.0 {
                // Snap instantly
                camera_transform.rotation = target_rotation;
            } else {
                // Slerp with same smoothing factor
                camera_transform.rotation = camera_transform.rotation.slerp(target_rotation, smoothing_factor * 8.0);
            }
        }
    }
}

/// System that handles mouse wheel zoom.
/// 
/// Note: This is a placeholder. For proper event handling, we'd need EventReader,
/// but that requires bevy::ecs::event which has version compatibility issues
/// with the workspace glam version. Zoom functionality is deferred to a
/// future iteration when the dependency conflict is resolved.
pub fn handle_mouse_wheel_zoom() {
    // Placeholder for mouse wheel zoom functionality.
    // Requires EventReader<MouseWheel> which has version compatibility issues.
}


```

### crates/anvil_demo/src/camera/spline.rs
```rust
//! Camera Spline System
//!
//! Provides a beat-driven camera system that moves through the Ashveil world,
//! driven by the demo's beat sequence. The camera follows the narrative from
//! DEMO_VISION.md, with each camera point triggered by specific beats.

use bevy::camera::Camera3d;
use bevy::ecs::observer::On;
use bevy::ecs::schedule::*;
use bevy::prelude::*;
use anvil_demo_core::beat::BeatId;

use crate::camera::CameraState;
use crate::plugins::BeatEvent;

/// A single camera point in the spline.
///
/// Each point defines where the camera should be positioned and what it should
/// be looking at. Points can be triggered by specific beats from the sequencer.
#[derive(Debug, Clone)]
pub struct CameraPoint {
    /// Camera position in world space.
    pub position: Vec3,
    /// Point the camera should look at (target).
    pub target: Vec3,
    /// Field of view in degrees.
    pub fov: f32,
    /// The beat that triggers this camera point.
    /// When a BeatEvent with a matching beat ID is received, the camera
    /// transitions to this point.
    pub beat_trigger: Option<BeatId>,
}

/// Resource holding the camera spline state.
///
/// This resource manages the sequence of camera points and the current
/// transition state between points.
#[derive(Resource, Debug)]
pub struct CameraSpline {
    /// All camera points in the spline.
    pub points: Vec<CameraPoint>,
    /// Current active point index.
    pub current_index: usize,
    /// Duration of transitions between points in seconds.
    pub transition_duration: f32,
    /// Current transition progress (0.0 to 1.0).
    pub transition_timer: f32,
    /// Whether a transition is currently in progress.
    pub is_transitioning: bool,
}

impl Default for CameraSpline {
    fn default() -> Self {
        Self {
            points: Vec::new(),
            current_index: 0,
            transition_duration: 2.0,
            transition_timer: 0.0,
            is_transitioning: false,
        }
    }
}

/// System set for camera spline systems.
/// Runs after SimBridgePlugin systems to ensure beat events are processed.
#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub struct CameraSplineSet;

/// Plugin for the camera spline system.
///
/// This plugin:
/// 1. Sets up the initial camera spline with all points from DEMO_VISION.md
/// 2. Adds systems to handle beat-triggered camera movements
/// 3. Updates camera position with smooth interpolation between points
pub struct CameraSplinePlugin;

impl Plugin for CameraSplinePlugin {
    fn build(&self, app: &mut App) {
        app
            // Register the CameraSplineSet
            .configure_sets(
                Update,
                (
                    CameraSplineSet,
                    // Run after SimBridgeSet to process BeatEvents
                    crate::plugins::SimBridgeSet,
                ),
            )
            // Add systems
            .add_systems(Startup, setup_camera_spline)
            .add_observer(handle_beat_camera_triggers)
            .add_systems(
                Update,
                update_camera_position.in_set(CameraSplineSet),
            );
    }
}

/// System that initializes the CameraSpline with all points from DEMO_VISION.md.
///
/// This sets up the complete camera path that follows the narrative sequence.
pub fn setup_camera_spline(
    mut commands: Commands,
    camera_spline: Option<Res<CameraSpline>>,
) {
    // Only initialize if not already done
    if camera_spline.is_none() {
        // Camera positions and targets from DEMO_VISION.md §3 Sequence of Events
        let points = vec![
            // 0:00–0:45 — "Dawn over Ashveil"
            // Establishing shot begins 600m above and 400m north of the settlement, descending slowly
            CameraPoint {
                position: Vec3::new(0.0, 600.0, 400.0),
                target: Vec3::new(0.0, 0.0, 0.0),
                fov: 60.0,
                beat_trigger: Some(BeatId::new(1)), // "Dawn Establishing" beat
            },
            // Approach to settlement (continuing from opening shot)
            CameraPoint {
                position: Vec3::new(0.0, 100.0, 150.0),
                target: Vec3::new(0.0, 0.0, 0.0),
                fov: 60.0,
                beat_trigger: Some(BeatId::new(2)), // "Ridge Stream In" beat
            },
            // 0:45–1:30 — "Eastern Ridge Streams In"
            // Pulls out to 900m altitude, looking at eastern ridge
            CameraPoint {
                position: Vec3::new(0.0, 900.0, -300.0),
                target: Vec3::new(0.0, 0.0, 0.0),
                fov: 70.0,
                beat_trigger: Some(BeatId::new(2)), // "Ridge Stream In" beat
            },
            // 1:30–2:15 — "Senne Sees It"
            // Mid-shot tracking Senne at the watchtower
            CameraPoint {
                position: Vec3::new(50.0, 50.0, 20.0),
                target: Vec3::new(50.0, 10.0, 20.0), // Looking at Senne on watchtower
                fov: 45.0,
                beat_trigger: Some(BeatId::new(3)), // "Senne Sees Fire" beat
            },
            // Follow Senne down the watchtower stairs
            CameraPoint {
                position: Vec3::new(45.0, 25.0, 15.0),
                target: Vec3::new(48.0, 5.0, 18.0),
                fov: 50.0,
                beat_trigger: Some(BeatId::new(3)), // Also triggered by Senne sees fire
            },
            // 2:15–3:00 — "The Fire Arrives"
            // Slow pull out and up to 400m altitude, looking southeast
            CameraPoint {
                position: Vec3::new(-200.0, 400.0, -100.0),
                target: Vec3::new(-150.0, 0.0, -50.0),
                fov: 75.0,
                beat_trigger: Some(BeatId::new(5)), // "Fire Wide Shot" beat (fire_tick=780)
            },
            // 3:00–4:00 — "What the Settlement Does Without Instructions"
            // Shot 1 (3:00–3:20): Low angle behind Yarra at the granary
            CameraPoint {
                position: Vec3::new(-30.0, 10.0, -10.0),
                target: Vec3::new(-20.0, 5.0, -5.0), // Looking at Yarra at granary
                fov: 55.0,
                beat_trigger: Some(BeatId::new(6)), // "Shot 1: Yarra at Granary"
            },
            // Shot 2 (3:20–3:40): Wide shot of Elder Maren at the commons
            CameraPoint {
                position: Vec3::new(0.0, 150.0, -150.0),
                target: Vec3::new(0.0, 0.0, -100.0),
                fov: 65.0,
                beat_trigger: Some(BeatId::new(7)), // "Shot 2: Maren at Commons"
            },
            // Shot 3 (3:40–4:00): Physics beat — burning debris falls from ridge
            CameraPoint {
                position: Vec3::new(100.0, 80.0, -50.0),
                target: Vec3::new(120.0, 0.0, -30.0),
                fov: 60.0,
                beat_trigger: Some(BeatId::new(8)), // "Shot 3: Debris Physics"
            },
            // 4:00–4:30 — "What Dak's Fear Costs Him"
            // Tracks Dak moving west
            CameraPoint {
                position: Vec3::new(-80.0, 60.0, 40.0),
                target: Vec3::new(-100.0, 0.0, 50.0), // Looking west along Dak's path
                fov: 50.0,
                beat_trigger: Some(BeatId::new(9)), // "Dak Returns" beat
            },
            // Static shot of the settlement behind him
            CameraPoint {
                position: Vec3::new(-150.0, 120.0, 0.0),
                target: Vec3::new(0.0, 0.0, 0.0),
                fov: 70.0,
                beat_trigger: Some(BeatId::new(9)), // Also Dak Returns
            },
            // 4:30–5:15 — "Rain Changes Everything"
            // Wide shot, looking west from above the settlement
            CameraPoint {
                position: Vec3::new(0.0, 400.0, -200.0),
                target: Vec3::new(0.0, 0.0, 0.0),
                fov: 75.0,
                beat_trigger: Some(BeatId::new(10)), // "Rain Begins" beat
            },
            // 5:15–5:45 — "Determinism Proven"
            // Evening, commons gathering
            CameraPoint {
                position: Vec3::new(0.0, 120.0, -80.0),
                target: Vec3::new(0.0, 0.0, -60.0),
                fov: 60.0,
                beat_trigger: Some(BeatId::new(12)), // "Ashveil Stands" beat
            },
            // 5:45–6:00 — Final hold (logo fade)
            CameraPoint {
                position: Vec3::new(0.0, 120.0, -80.0),
                target: Vec3::new(0.0, 0.0, -60.0),
                fov: 60.0,
                beat_trigger: Some(BeatId::new(13)), // "Demo Complete" beat
            },
        ];

        commands.insert_resource(CameraSpline {
            points,
            current_index: 0,
            transition_duration: 2.0,
            transition_timer: 0.0,
            is_transitioning: false,
        });
    }
}

/// System that listens for BeatEvents and triggers camera movements.
///
/// When a BeatEvent is received, this system checks if any CameraPoint
/// has a matching beat_trigger. If so, it initiates a transition to that point.
pub fn handle_beat_camera_triggers(
    beat_event: On<BeatEvent>,
    mut spline: ResMut<CameraSpline>,
) {
    let event = beat_event.event();
    let beat_id = event.beat.id;

    // Find a camera point that matches this beat trigger
    for (index, point) in spline.points.iter().enumerate() {
        if point.beat_trigger == Some(beat_id) {
            // Found a matching point - start transition
            if index != spline.current_index {
                spline.current_index = index;
                spline.is_transitioning = true;
                spline.transition_timer = 0.0;

                tracing::info!(
                    "Camera spline: transitioning to point {} triggered by beat {} ({})",
                    index,
                    beat_id.get(),
                    event.beat.name
                );
            }
            // If we already have this point as current, no transition needed
            break; // Assuming one beat maps to one camera point
        }
    }
}

/// System that interpolates camera position between points over time.
///
/// Uses smooth interpolation (smoothstep) for natural camera movement.
/// Note: FOV changes are not yet implemented as they require accessing the Camera component.
/// For now, only position and rotation are updated.
pub fn update_camera_position(
    time: Res<Time>,
    mut spline: ResMut<CameraSpline>,
    mut camera_query: Query<&mut Transform, With<Camera3d>>,
    camera_state: Res<CameraState>,
) {
    // Don't update if in free camera mode or if we have no points
    if camera_state.focus_mode || spline.points.is_empty() {
        return;
    }

    let delta = time.delta_secs();

    if spline.is_transitioning {
        // Advance transition timer
        spline.transition_timer += delta;
        
        let t = (spline.transition_timer / spline.transition_duration).clamp(0.0, 1.0);
        
        // Use smoothstep for natural easing: 3t² - 2t³
        let t_smooth = t * t * (3.0 - 2.0 * t);
        
        // Get current and previous points
        let prev_index = spline.current_index.saturating_sub(1);
        let current_point = &spline.points[spline.current_index];
        let prev_point = &spline.points[prev_index];
        
        // Interpolate between previous and current point
        let position = prev_point.position.lerp(current_point.position, t_smooth);
        let target = prev_point.target.lerp(current_point.target, t_smooth);
        
        // Update all cameras with Camera3d marker
        for mut transform in camera_query.iter_mut() {
            *transform = Transform::from_translation(position).looking_at(target, Vec3::Y);
        }
        
        // Check if transition is complete
        if t >= 1.0 {
            spline.is_transitioning = false;
            spline.transition_timer = 0.0;
        }
    } else {
        // No transition - snap to current point (e.g., after manual jump or at start)
        let current_point = &spline.points[spline.current_index];
        
        for mut transform in camera_query.iter_mut() {
            *transform = Transform::from_translation(current_point.position).looking_at(current_point.target, Vec3::Y);
        }
    }
}

/// System that resets the camera spline to the initial point.
/// Useful for replaying the demo.
pub fn reset_camera_spline(
    mut spline: ResMut<CameraSpline>,
    mut camera_query: Query<&mut Transform, With<Camera3d>>,
    camera_state: Res<CameraState>,
) {
    if camera_state.focus_mode {
        return;
    }

    spline.current_index = 0;
    spline.is_transitioning = false;
    spline.transition_timer = 0.0;
    
    if let Some(current_point) = spline.points.first() {
        for mut transform in camera_query.iter_mut() {
            *transform = Transform::from_translation(current_point.position).looking_at(current_point.target, Vec3::Y);
        }
    }
}

/// Marker resource to indicate the camera spline has been initialized.
#[derive(Resource, Default)]
pub struct CameraSplineInitialized;

#[cfg(test)]
mod tests {
    use super::*;

    /// Test that CameraSpline initializes with the correct number of points.
    #[test]
    fn test_camera_spline_initialization() {
        let mut app = App::new();
        app.add_systems(Startup, setup_camera_spline);
        
        app.update();
        
        let spline = app.world().get_resource::<CameraSpline>().unwrap();
        
        // We should have points for each major beat in DEMO_VISION.md
        assert!(spline.points.len() > 0, "Camera spline should have at least one point");
        
        // All points should have valid positions
        for (i, point) in spline.points.iter().enumerate() {
            assert!(!point.position.is_nan(), "Point {} position is NaN", i);
            assert!(!point.target.is_nan(), "Point {} target is NaN", i);
            assert!(point.fov > 0.0, "Point {} FOV must be positive", i);
        }
    }

    /// Test that camera points can be matched by beat ID.
    #[test]
    fn test_beat_trigger_matching() {
        let mut app = App::new();
        app.add_systems(Startup, setup_camera_spline);
        app.update();
        
        let spline = app.world().get_resource::<CameraSpline>().unwrap();
        
        // Should be able to find points with beat triggers
        let mut points_with_triggers = 0;
        for point in &spline.points {
            if point.beat_trigger.is_some() {
                points_with_triggers += 1;
            }
        }
        
        // Most points should have triggers
        assert!(points_with_triggers > 0, "At least one point should have a beat trigger");
    }

    /// Test smoothstep interpolation.
    #[test]
    fn test_smoothstep_interpolation() {
        // Test the smoothstep function: 3t² - 2t³
        let test_smoothstep = |t: f32| t * t * (3.0 - 2.0 * t);
        
        // At t=0, should be 0
        assert_eq!(test_smoothstep(0.0), 0.0);
        
        // At t=1, should be 1
        assert_eq!(test_smoothstep(1.0), 1.0);
        
        // At t=0.5, should be 0.5
        assert!((test_smoothstep(0.5) - 0.5).abs() < 0.001);
        
        // Should be smooth (first derivative continuous)
        let t = 0.5;
        let h = 0.001;
        let deriv_forward = (test_smoothstep(t + h) - test_smoothstep(t)) / h;
        let deriv_backward = (test_smoothstep(t) - test_smoothstep(t - h)) / h;
        assert!((deriv_forward - deriv_backward).abs() < 0.01);
    }
}
```

### crates/anvil_demo/src/player/camera.rs
```rust
//! First-person camera systems for the Ashveil demo player.
//!
//! This module provides:
//! - Player camera entity spawning with proper hierarchy (body + camera child)
//! - Mouse look with pitch clamping
//! - Cursor capture/release logic

use bevy::prelude::*;

use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::window::{CursorGrabMode, CursorOptions, PrimaryWindow};

use crate::player::movement::{Grounded, PlayerVelocity};

/// Resource for tracking head bob state.
#[derive(Resource, Default)]
pub struct HeadBob {
    /// Current head bob offset.
    pub offset: Vec3,
    /// Accumulated time for head bob oscillation.
    pub time: f32,
}

/// Resource tracking player camera state.
#[derive(Resource, Default)]
pub struct PlayerCameraState {
    /// Current camera yaw (radians).
    pub yaw: f32,
    /// Current camera pitch (radians).
    pub pitch: f32,
    /// Whether the cursor is currently captured.
    pub cursor_captured: bool,
    /// Entity of the camera.
    pub camera_entity: Option<Entity>,
    /// Entity of the player body (parent of camera).
    pub body_entity: Option<Entity>,
}

/// Marker component for the player body entity.
#[derive(Component)]
pub struct PlayerBody;

/// Marker component for the player camera entity.
#[derive(Component)]
pub struct PlayerCamera;

/// System that spawns the player camera and body entity.
pub fn setup_player_camera(mut commands: Commands) {
    // Spawn player body at (0, 2, 0) looking east
    let body_entity = commands
        .spawn((
            Transform::from_xyz(0.0, 2.0, 0.0),
            GlobalTransform::default(),
            PlayerBody,
            Name::new("Player Body"),
        ))
        .id();

    // Spawn camera as child of body
    let camera_entity = commands
        .spawn((
            Camera3d::default(),
            Camera {
                order: -1,
                ..default()
            },
            Transform::from_xyz(0.0, 0.0, 0.0),
            GlobalTransform::default(),
            PlayerCamera,
            Name::new("Player Camera"),
            // FIX 5: Add SpatialListener for future spatial audio features
            SpatialListener::default(),
        ))
        .id();
    
    // Set parent after both entities exist
    commands.entity(body_entity).add_child(camera_entity);

    // Add velocity and grounded components to player body
    commands.entity(body_entity)
        .insert(PlayerVelocity::default())
        .insert(Grounded { is_grounded: true });

    // Update camera state with entity references
    commands.insert_resource(PlayerCameraState {
        yaw: 0.0,
        pitch: 0.0,
        cursor_captured: true,
        camera_entity: Some(camera_entity),
        body_entity: Some(body_entity),
    });
}

/// System that continuously maintains cursor grab state.
/// 
/// On Wayland/Linux, the initial cursor grab at startup can silently fail
/// if the window doesn't have focus yet. This system continuously enforces
/// the grab state every frame, so even if the initial grab fails, it will
/// be re-applied once the window gains focus.
///
/// - Releases grab on Escape
/// - Re-acquires grab on left click
/// - Enforces grab state every frame while captured
pub fn maintain_cursor_grab(
    mut camera_state: ResMut<PlayerCameraState>,
    mut cursor_options: Query<&mut CursorOptions, With<PrimaryWindow>>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
) {
    let Ok(mut opts) = cursor_options.single_mut() else { return };

    // Release on Escape
    if keys.just_pressed(KeyCode::Escape) && camera_state.cursor_captured {
        opts.grab_mode = CursorGrabMode::None;
        opts.visible = true;
        camera_state.cursor_captured = false;
        return;
    }

    // Re-acquire on left click
    if mouse.just_pressed(MouseButton::Left) && !camera_state.cursor_captured {
        camera_state.cursor_captured = true;
    }

    // Enforce grab every frame while captured
    if camera_state.cursor_captured {
        opts.grab_mode = CursorGrabMode::Locked;
        opts.visible = false;
    }
}

/// System that handles mouse movement for camera look.
///
/// Reads the frame's accumulated mouse motion delta (Bevy 0.14+ idiom),
/// updates the cached yaw/pitch in `PlayerCameraState`, and applies them:
/// - yaw to the body transform (so WASD moves relative to look direction),
/// - pitch to the camera transform (so vertical look doesn't tilt the body).
///
/// Pitch is clamped to ±89° (i.e. ±π/2 with a small margin) to prevent
/// the camera from flipping upside down at the zenith / nadir.
pub fn handle_mouse_look(
    mouse_motion: Res<AccumulatedMouseMotion>,
    sensitivity: Res<crate::player::MouseSensitivity>,
    mut camera_state: ResMut<PlayerCameraState>,
    mut body_query: Query<&mut Transform, (With<PlayerBody>, Without<PlayerCamera>)>,
    mut camera_query: Query<&mut Transform, (With<PlayerCamera>, Without<PlayerBody>)>,
) {
    if !camera_state.cursor_captured {
        return;
    }
    let delta = mouse_motion.delta;
    if delta == Vec2::ZERO {
        return;
    }

    // Update cached yaw and pitch.
    camera_state.yaw -= delta.x * sensitivity.0;
    camera_state.pitch -= delta.y * sensitivity.0;
    let pitch_limit = std::f32::consts::FRAC_PI_2 - 0.01;
    camera_state.pitch = camera_state.pitch.clamp(-pitch_limit, pitch_limit);

    // Apply yaw to the body so WASD respects look direction.
    if let Some(body) = camera_state.body_entity {
        if let Ok(mut body_transform) = body_query.get_mut(body) {
            body_transform.rotation = Quat::from_rotation_y(camera_state.yaw);
        }
    }
    // Apply pitch to the camera.
    if let Some(cam) = camera_state.camera_entity {
        if let Ok(mut camera_transform) = camera_query.get_mut(cam) {
            camera_transform.rotation = Quat::from_rotation_x(camera_state.pitch);
        }
    }
}
```

### crates/anvil_demo/src/player/idle.rs
```rust
//! Idle takeover system for the Ashveil demo player.
//!
//! This module implements the "idle takeover" mechanism where the player's
//! body is transferred to NPC control after 60 seconds of inactivity.
//! This expresses Pillar I: "the player is an inhabitant, not a hero."
//!
//! The viewer's body continues living in the simulation even when they
//! are not providing input.

use bevy::prelude::*;

use crate::app::RuntimeResource;
use anvil_sim::settlement::ids::{FamilyId, PersonId};

/// Time threshold (in seconds) before idle takeover activates.
const IDLE_THRESHOLD: f32 = 60.0;
/// Time to fade in the vignette (seconds).
const VIGNETTE_FADE_IN: f32 = 2.0;
/// Time to fade out the vignette (seconds).
const VIGNETTE_FADE_OUT: f32 = 0.5;
/// Maximum vignette opacity.
const VIGNETTE_MAX_OPACITY: f32 = 0.15;
/// Viewer NPC ID - the ninth villager.
const VIEWER_PERSON_ID: u64 = 9;

/// Tracks time since the last player input.
#[derive(Resource)]
pub struct TimeSinceLastInput {
    /// Time in seconds since last input.
    pub seconds: f32,
}

impl Default for TimeSinceLastInput {
    fn default() -> Self {
        Self { seconds: 0.0 }
    }
}

/// Idle state machine for player control.
#[derive(Resource, Default, PartialEq, Eq, Clone, Copy, Debug)]
pub enum IdleState {
    /// Player has active control.
    #[default]
    PlayerControlled,
    /// NPC system has taken over control.
    TakenOver,
}

/// Marker component for the idle vignette UI entity.
#[derive(Component)]
pub struct IdleVignette;

/// Tracks the viewer's NPC entry in the simulation.
/// None means the viewer NPC has not been created yet.
#[derive(Resource)]
pub struct ViewerNpcEntity {
    pub person_id: Option<PersonId>,
}

impl Default for ViewerNpcEntity {
    fn default() -> Self {
        Self { person_id: None }
    }
}

/// System that detects player input and resets the idle timer.
/// 
/// Checks for: WASD, Space, Shift, mouse buttons.
/// Mouse motion detection is deferred pending Bevy 0.18 event system compatibility.
pub fn detect_input_and_reset_timer(
    keyboard: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    time: Res<Time>,
    mut idle_timer: ResMut<TimeSinceLastInput>,
    mut idle_state: ResMut<IdleState>,
) {
    // Check if any relevant input is active
    let has_keyboard_input = keyboard.any_pressed([
        KeyCode::KeyW,
        KeyCode::KeyA,
        KeyCode::KeyS,
        KeyCode::KeyD,
        KeyCode::Space,
        KeyCode::ShiftLeft,
        KeyCode::ShiftRight,
    ]);

    let has_mouse_button_input = mouse_buttons.any_pressed([
        MouseButton::Left,
        MouseButton::Right,
        MouseButton::Middle,
    ]);

    // TODO: Add mouse motion detection when Bevy 0.18 event system is sorted
    // For now, we only check keyboard and mouse buttons
    let has_input = has_keyboard_input || has_mouse_button_input;

    if has_input {
        // Reset timer on any input
        idle_timer.seconds = 0.0;
        
        // If we were taken over, mark that we want to return
        // The actual return happens in handle_idle_return
        if *idle_state == IdleState::TakenOver {
            // Transition back immediately on input
            // In a full implementation, we'd wait for the NPC action to complete
            *idle_state = IdleState::PlayerControlled;
        }
    } else {
        // Accumulate idle time
        idle_timer.seconds += time.delta_secs() as f32;
    }
}

/// System that applies idle takeover when threshold is exceeded.
pub fn apply_idle_takeover(
    mut commands: Commands,
    idle_timer: Res<TimeSinceLastInput>,
    mut idle_state: ResMut<IdleState>,
    mut viewer_npc: ResMut<ViewerNpcEntity>,
    mut runtime: Option<ResMut<RuntimeResource>>,
) {
    // Only transition if we're currently player-controlled and threshold exceeded
    if *idle_state == IdleState::PlayerControlled && idle_timer.seconds >= IDLE_THRESHOLD {
        *idle_state = IdleState::TakenOver;
        
        // Log the transition
        info!("Idle takeover activated: viewer body transferred to NPC control");
        
        // Ensure viewer NPC exists in the simulation
        ensure_viewer_npc_exists(&mut commands, runtime.as_deref_mut(), &mut viewer_npc);
    }
}

/// Ensures the viewer NPC exists in the NpcSystem.
/// 
/// The viewer is the ninth villager (PersonId::new(9)). If it doesn't exist,
/// we create a minimal NPC entry with neutral substrate.
fn ensure_viewer_npc_exists(
    _commands: &mut Commands,
    runtime: Option<&mut RuntimeResource>,
    viewer_npc: &mut ResMut<ViewerNpcEntity>,
) {
    // Check if viewer NPC already exists
    if viewer_npc.person_id.is_some() {
        return;
    }

    if let Some(runtime) = runtime {
        // Try to find the viewer NPC in existing systems
        let viewer_id = PersonId::new(VIEWER_PERSON_ID);
        
        // Check if viewer already exists in any NpcSystem
        for system in &runtime.runtime.systems {
            if let Some(npc_system) = system.as_any().downcast_ref::<anvil_sim::NpcSystem>() {
                if npc_system.persons.iter().any(|p| p.id.get() == VIEWER_PERSON_ID) {
                    viewer_npc.person_id = Some(viewer_id);
                    return;
                }
            }
        }

        // Viewer NPC doesn't exist - we need to add it
        // For now, we add it to the first NpcSystem we find
        // TODO: This should be done through proper runtime commands
        for system in &mut runtime.runtime.systems {
            if let Some(npc_system) = system.as_any_mut().downcast_mut::<anvil_sim::NpcSystem>() {
                // We need a family for the person
                // Check if there's an existing family or create one
                let family_id = FamilyId::new(9); // Viewer family
                
                // Check if family exists
                let has_family = npc_system.families.iter().any(|f| f.id.get() == 9);
                if !has_family {
                    let family = anvil_sim::settlement::Family::new(
                        family_id,
                        vec![viewer_id],
                    );
                    npc_system.add_family(family);
                }
                
                // Create the viewer person with neutral substrate
                let person = anvil_sim::settlement::Person::new_simple(
                    viewer_id,
                    "Viewer".to_string(),
                    family_id,
                );
                
                npc_system.add_person(person);
                viewer_npc.person_id = Some(viewer_id);
                
                info!("Created viewer NPC with PersonId({})", VIEWER_PERSON_ID);
                return;
            }
        }
        
        // If no NpcSystem found, log a warning
        warn!("No NpcSystem found to add viewer NPC");
    }
}

/// System that handles the return from idle takeover to player control.
/// 
/// This provides a soft return: the vignette fades out over 0.5 seconds
/// and control returns to the player.
pub fn handle_idle_return(
    keyboard: Res<ButtonInput<KeyCode>>,
    mouse_buttons: Res<ButtonInput<MouseButton>>,
    mut idle_state: ResMut<IdleState>,
    mut idle_timer: ResMut<TimeSinceLastInput>,
) {
    // If we're in TakenOver state and any input is detected, return control
    if *idle_state == IdleState::TakenOver {
        let has_keyboard_input = keyboard.any_just_pressed([
            KeyCode::KeyW,
            KeyCode::KeyA,
            KeyCode::KeyS,
            KeyCode::KeyD,
            KeyCode::Space,
            KeyCode::ShiftLeft,
            KeyCode::ShiftRight,
        ]);

        let has_mouse_button_input = mouse_buttons.any_just_pressed([
            MouseButton::Left,
            MouseButton::Right,
            MouseButton::Middle,
        ]);

        // TODO: Add mouse motion detection when Bevy 0.18 event system is sorted
        if has_keyboard_input || has_mouse_button_input {
            *idle_state = IdleState::PlayerControlled;
            idle_timer.seconds = 0.0;
            
            info!("Idle takeover ended: control returned to player");
        }
    }
}

/// System that spawns the idle vignette UI entity.
pub fn spawn_idle_vignette(
    mut commands: Commands,
) {
    // Spawn a full-screen node for the vignette
    // The node is initially hidden and will be shown when takeover activates
    commands.spawn((
        Node {
            position_type: bevy::ui::PositionType::Absolute,
            ..default()
        },
        BackgroundColor::from(Color::srgba(0.0, 0.0, 0.0, 0.0)),
        IdleVignette,
        Name::new("Idle Vignette"),
        Visibility::Hidden,
    ));
}

/// System that updates the vignette visibility and opacity based on idle state.
pub fn update_vignette(
    idle_state: Res<IdleState>,
    idle_timer: Res<TimeSinceLastInput>,
    mut vignette_query: Query<(&mut BackgroundColor, &mut Visibility), With<IdleVignette>>,
) {
    // Get the first vignette entity (there should only be one)
    if let Some((mut bg_color, mut visibility)) = vignette_query.iter_mut().next() {
        match *idle_state {
            IdleState::PlayerControlled => {
                // Fade out: when returning from takeover, fade over FADE_OUT seconds
                // or when timer is below threshold, hide completely
                if idle_timer.seconds >= IDLE_THRESHOLD - VIGNETTE_FADE_IN {
                    // We're approaching takeover - start fading in
                    let fade_progress = (idle_timer.seconds - (IDLE_THRESHOLD - VIGNETTE_FADE_IN)) 
                        / VIGNETTE_FADE_IN;
                    let opacity = (fade_progress.clamp(0.0, 1.0) * VIGNETTE_MAX_OPACITY).min(VIGNETTE_MAX_OPACITY);
                    bg_color.0 = Color::srgba(0.0, 0.0, 0.0, opacity);
                    *visibility = Visibility::Visible;
                } else {
                    // Fully hidden
                    bg_color.0 = Color::srgba(0.0, 0.0, 0.0, 0.0);
                    *visibility = Visibility::Hidden;
                }
            }
            IdleState::TakenOver => {
                // Fully visible at max opacity
                bg_color.0 = Color::srgba(0.0, 0.0, 0.0, VIGNETTE_MAX_OPACITY);
                *visibility = Visibility::Visible;
            }
        }
    }
}

/// System that locks cursor when player regains control.
/// 
/// TODO: Implement cursor grab when Bevy 0.18 window API is sorted.
/// For now, this is a placeholder - cursor control is deferred.
#[allow(dead_code)]
pub fn update_cursor_grab(
    idle_state: Res<IdleState>,
) {
    // Cursor grab implementation deferred pending Bevy 0.18 API compatibility
    let _ = idle_state;
}

/// System that prevents player movement systems from running during takeover.
/// 
/// This is done by adding/removing a marker component that movement systems
/// can check, or by using system ordering. For now, we use the state directly.
/// 
/// In the movement systems, we should check for IdleState::TakenOver and skip
/// applying player input. The NPC system will handle movement instead.
///
/// The `idle_state` resource is referenced via the system signature so that
/// Bevy schedules this marker system after any other system that mutates
/// `IdleState`; the body of the system is intentionally empty. The leading
/// underscore is the warning-suppressing form for parameters that exist for
/// scheduling effect only.
#[allow(dead_code)]
pub fn block_player_movement_during_takeover(
    _idle_state: Res<IdleState>,
    // This system doesn't need to do anything - movement systems should check the state
) {
    // Marker system for ordering. Movement systems should run after this
    // and check the idle state before applying input.
}
```

### crates/anvil_demo/src/player/mod.rs
```rust
//! First-person player systems for the Ashveil demo.
//!
//! This module owns the player's camera, movement, and idle-takeover
//! behaviour. It replaces the former `bevy_flycam` dependency with a
//! hand-rolled first-person controller integrated with the Rapier3D
//! physics world and the player's NPC entry in the simulation.

mod camera;
mod idle;
mod movement;

use bevy::prelude::*;

pub use camera::{HeadBob, PlayerBody, PlayerCamera, PlayerCameraState};
pub use idle::{IdleState, TimeSinceLastInput, ViewerNpcEntity};
use camera::{setup_player_camera, maintain_cursor_grab, handle_mouse_look};
use idle::{detect_input_and_reset_timer, apply_idle_takeover, handle_idle_return, spawn_idle_vignette, update_vignette, update_cursor_grab};
use movement::{handle_keyboard_movement, apply_head_bob, regenerate_stamina, check_grounded};

/// Mouse sensitivity setting (radians per pixel).
#[derive(Resource)]
pub struct MouseSensitivity(pub f32);

impl Default for MouseSensitivity {
    fn default() -> Self {
        Self(0.003)
    }
}

/// Head bob settings.
#[derive(Resource)]
pub struct HeadBobSettings {
    pub enabled: bool,
}

impl Default for HeadBobSettings {
    fn default() -> Self {
        Self { enabled: true }
    }
}

/// Player stamina for sprinting.
#[derive(Resource)]
pub struct PlayerStamina {
    pub current: f32,
    pub max: f32,
}

impl Default for PlayerStamina {
    fn default() -> Self {
        Self {
            current: 100.0,
            max: 100.0,
        }
    }
}

/// Plugin that installs all player systems.
///
/// Add this to the app during Phase 1 to activate the first-person
/// controller and idle-takeover behaviour.
pub struct PlayerPlugin;

impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        // Insert resources
        app.init_resource::<MouseSensitivity>()
            .init_resource::<HeadBobSettings>()
            .init_resource::<PlayerStamina>()
            .init_resource::<PlayerCameraState>()
            .init_resource::<HeadBob>()
            .init_resource::<TimeSinceLastInput>()
            .init_resource::<IdleState>()
            .init_resource::<ViewerNpcEntity>();

        // Add systems
        app.add_systems(Startup, (
            setup_player_camera,
            spawn_idle_vignette,
        ))
        .add_systems(PreUpdate, (
            maintain_cursor_grab,
        ))
        .add_systems(Update, (
            // Input detection must run first
            detect_input_and_reset_timer,
            handle_mouse_look,
            // Apply idle takeover after input detection
            apply_idle_takeover,
            // Handle return from takeover
            handle_idle_return,
            // Update cursor grab based on state
            update_cursor_grab,
            // Player movement - runs after idle detection
            handle_keyboard_movement,
            check_grounded,
            apply_head_bob,
            regenerate_stamina,
            // Update vignette visualization last
            update_vignette,
        ));
    }
}
```

### crates/anvil_demo/src/player/movement.rs
```rust
//! First-person movement systems for the Ashveil demo player.
//!
//! This module provides:
//! - WASD keyboard movement with configurable speeds
//! - Sprint with stamina drain
//! - Jump with vertical impulse
//! - Head bob effect (gated by HeadBobSettings)

use bevy::prelude::*;

use super::{HeadBob, HeadBobSettings, IdleState, PlayerBody, PlayerCameraState, PlayerStamina};

/// Walk speed in m/s.
const WALK_SPEED: f32 = 1.4;
/// Sprint speed in m/s.
const SPRINT_SPEED: f32 = 4.5;
/// Stamina drain rate per second while sprinting.
const STAMINA_DRAIN_RATE: f32 = 15.0;
/// Stamina regeneration rate per second.
const STAMINA_REGEN_RATE: f32 = 8.0;
/// Jump impulse strength.
const JUMP_IMPULSE: f32 = 7.0;
/// Gravity for grounded check.
const GRAVITY: f32 = -9.81;
/// Grounded check ray length.
const GROUNDED_RAY_LENGTH: f32 = 0.15;
/// Walk head bob amplitude.
const HEAD_BOB_WALK_AMPLITUDE: f32 = 0.015;
/// Sprint head bob amplitude.
const HEAD_BOB_SPRINT_AMPLITUDE: f32 = 0.025;
/// Head bob frequency multiplier.
const HEAD_BOB_FREQUENCY: f32 = 2.0 * std::f32::consts::PI;

/// Marker component for the ground plane.
#[derive(Component)]
pub struct GroundPlane;

/// Velocity component for the player body.
#[derive(Component, Default)]
pub struct PlayerVelocity {
    pub velocity: Vec3,
}

/// Grounded state for jump checking.
#[derive(Component, Default)]
pub struct Grounded {
    pub is_grounded: bool,
}

/// System that handles keyboard movement input and jump.
/// 
/// This system checks the idle state and skips applying player input
/// when the player is in TakenOver state (NPC control).
pub fn handle_keyboard_movement(
    keyboard: Res<ButtonInput<KeyCode>>,
    camera_state: Res<PlayerCameraState>,
    idle_state: Res<IdleState>,
    mut stamina: ResMut<PlayerStamina>,
    time: Res<Time>,
    mut body_query: Query<(&mut Transform, &mut PlayerVelocity, &Grounded), With<PlayerBody>>,
) {
    if camera_state.body_entity.is_none() {
        return;
    }

    // Skip player input when in TakenOver state
    // NPC system handles movement instead
    if *idle_state == IdleState::TakenOver {
        return;
    }

    let body_entity = camera_state.body_entity.unwrap();
    let Ok((mut body_transform, mut velocity, grounded)) = body_query.get_mut(body_entity) else {
        return;
    };

    // Handle jump
    if keyboard.just_pressed(KeyCode::Space) && grounded.is_grounded {
        velocity.velocity.y = JUMP_IMPULSE;
    }

    // Calculate movement direction relative to body rotation (ignore pitch)
    let mut move_dir = Vec3::ZERO;
    let forward = Vec3::new(body_transform.forward().x, 0.0, body_transform.forward().z).normalize();
    let right = Vec3::new(body_transform.right().x, 0.0, body_transform.right().z).normalize();

    if keyboard.pressed(KeyCode::KeyW) {
        move_dir += forward;
    }
    if keyboard.pressed(KeyCode::KeyS) {
        move_dir -= forward;
    }
    if keyboard.pressed(KeyCode::KeyA) {
        move_dir -= right;
    }
    if keyboard.pressed(KeyCode::KeyD) {
        move_dir += right;
    }

    // Normalize if moving
    let speed = if move_dir != Vec3::ZERO {
        move_dir = move_dir.normalize();
        if keyboard.pressed(KeyCode::ShiftLeft) || keyboard.pressed(KeyCode::ShiftRight) {
            // Check stamina
            if stamina.current > 0.0 {
                stamina.current -= STAMINA_DRAIN_RATE * time.delta_secs() as f32;
                SPRINT_SPEED
            } else {
                WALK_SPEED
            }
        } else {
            WALK_SPEED
        }
    } else {
        0.0
    };

    if speed > 0.0 {
        // Apply movement to horizontal plane only
        velocity.velocity.x = move_dir.x * speed;
        velocity.velocity.z = move_dir.z * speed;
    } else {
        // Apply friction when not moving
        velocity.velocity.x *= 0.8;
        velocity.velocity.z *= 0.8;
    }

    // Apply gravity
    if !grounded.is_grounded {
        velocity.velocity.y += GRAVITY * time.delta_secs() as f32;
    } else if velocity.velocity.y < 0.0 {
        // Stop falling velocity when grounded
        velocity.velocity.y = 0.0;
    }

    // Apply velocity to position
    body_transform.translation += velocity.velocity * time.delta_secs() as f32;
}

/// System that applies head bob effect based on movement.
/// 
/// Head bob is disabled during NPC takeover since the NPC system
/// controls the camera independently.
pub fn apply_head_bob(
    keyboard: Res<ButtonInput<KeyCode>>,
    camera_state: Res<PlayerCameraState>,
    idle_state: Res<IdleState>,
    head_bob_settings: Res<HeadBobSettings>,
    time: Res<Time>,
    mut head_bob: ResMut<HeadBob>,
    mut camera_query: Query<&mut Transform, With<super::PlayerCamera>>,
) {
    // Skip head bob when in TakenOver state
    // NPC system controls camera movement
    if *idle_state == IdleState::TakenOver {
        head_bob.offset = Vec3::ZERO;
        if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
            camera_transform.translation.y = 0.0;
        }
        return;
    }
    if !head_bob_settings.enabled {
        head_bob.offset = Vec3::ZERO;
        if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
            camera_transform.translation.y = 0.0;
        }
        return;
    }

    // Check if player is moving
    let is_moving = keyboard.pressed(KeyCode::KeyW)
        || keyboard.pressed(KeyCode::KeyS)
        || keyboard.pressed(KeyCode::KeyA)
        || keyboard.pressed(KeyCode::KeyD);

    if is_moving {
        // Determine amplitude based on sprint
        let amplitude = if keyboard.pressed(KeyCode::ShiftLeft) 
            || keyboard.pressed(KeyCode::ShiftRight) {
            HEAD_BOB_SPRINT_AMPLITUDE
        } else {
            HEAD_BOB_WALK_AMPLITUDE
        };

        // Update head bob time and calculate offset
        head_bob.time += time.delta_secs() as f32 * HEAD_BOB_FREQUENCY;
        head_bob.offset.y = (head_bob.time.sin() * amplitude) - (head_bob.time.sin() * head_bob.time.sin() * 0.5 * amplitude);
    } else {
        // Dampen head bob when not moving
        head_bob.time = 0.0;
        head_bob.offset = head_bob.offset * 0.9;
    }

    // Apply head bob offset to camera
    if let Ok(mut camera_transform) = camera_query.get_mut(camera_state.camera_entity.unwrap()) {
        camera_transform.translation = head_bob.offset;
    }
}

/// System that checks if player is grounded using raycast.
pub fn check_grounded(
    camera_state: Res<PlayerCameraState>,
    mut body_query: Query<(&Transform, &mut Grounded), With<PlayerBody>>,
) {
    if camera_state.body_entity.is_none() {
        return;
    }

    let body_entity = camera_state.body_entity.unwrap();
    let Ok((transform, mut grounded)) = body_query.get_mut(body_entity) else {
        return;
    };

    // Simple raycast downward to check if player is grounded
    // In a real implementation with Rapier, we'd use Rapier's raycast
    // For now, we'll use a simple height check as a placeholder
    // The player is considered grounded if Y position is near the ground
    grounded.is_grounded = transform.translation.y <= 2.1;
}

/// System that regenerates stamina when not sprinting.
/// 
/// Stamina only regenerates when the player is in control.
/// During NPC takeover, the NPC system manages its own energy state.
pub fn regenerate_stamina(
    keyboard: Res<ButtonInput<KeyCode>>,
    idle_state: Res<IdleState>,
    time: Res<Time>,
    mut stamina: ResMut<PlayerStamina>,
) {
    // Only regenerate when player is in control
    if *idle_state == IdleState::TakenOver {
        return;
    }

    // Only regenerate if not sprinting
    let is_sprinting = keyboard.pressed(KeyCode::ShiftLeft) || keyboard.pressed(KeyCode::ShiftRight);
    
    if !is_sprinting && stamina.current < stamina.max {
        stamina.current = (stamina.current + STAMINA_REGEN_RATE * time.delta_secs() as f32).min(stamina.max);
    }
}
```

### crates/anvil_demo/src/plugins/registration.rs
```rust
//! Plugin and system registration for anvil_demo.
//!
//! This module contains the centralized registration function that adds all
//! plugins, resources, and systems to the Bevy app.

use bevy::prelude::*;

use anvil_bevy::{AnvilAssetPlugin, debug_fallback_summary, AssetOriginTag};
use bevy::asset::AssetPlugin;
use bevy::diagnostic::FrameTimeDiagnosticsPlugin;
use bevy::gltf::GltfAssetLabel;
use bevy::log::LogPlugin;
use bevy::pbr::StandardMaterial;
use bevy_egui::{EguiContexts, EguiPlugin, EguiPrimaryContextPass, egui};
// TODO Phase 1: replaced by FpsController
use std::path::{Path, PathBuf};
use tracing::info;

use crate::app::{AppPlugin, AppState, RuntimeResource};
use anvil_bevy::audio::AudioPlugin;
use crate::audio::AshveilAudioPlugin;
use crate::player::PlayerPlugin;
use crate::world::AtmosphereDriverPlugin;
use crate::camera::{CameraSplinePlugin, DemoSplinePlugin, disable_gltf_cameras, handle_camera_shortcuts, handle_mouse_wheel_zoom, set_camera_priorities, setup_main_camera, update_focus_camera, CameraState};
use crate::catastrophe_panel::{handle_catastrophe_shortcuts, process_pending_catastrophes, render_catastrophe_panel, setup_catastrophe_panel, CatastrophePanelState};
use crate::demo::DemoSequencerPlugin;
use crate::dev_experience::{render_dev_panel, setup_dev_experience, EguiContextsExt};
use crate::event_log::{add_test_events, render_event_log, setup_event_log, EventLog};
use crate::npc::{update_npc_movement, update_npc_rotation_toward_targets};
use crate::npc_visuals::{despawn_npc_visuals, spawn_npc_visuals, update_action_halos, update_npc_breathing_system, update_selection_ring_visibility, update_selection_rings, NpcVisualState};
use crate::oracle_overlay::{render_oracle_overlay, setup_oracle_overlay};
use crate::overlays::{NeedsBarPlugin, SkillFlashPlugin, render_network_line_legend, setup_overlays, update_emotion_lines, update_status_rings, OverlayState};
use crate::performance_panel::{render_performance_panel, setup_performance_panel, PerformancePanelState};
use crate::plugins::SimBridgePlugin;
use crate::rendering::GlbRenderingPlugin;
use crate::scenarios::ScenarioLoaderPlugin;
use crate::sim::{SimRng, SimTickCounter, tick_simulation_systems};
use crate::states::options::{AccessibilityOptions, AudioOptions, DisplayOptions};
use crate::time_travel::{render_time_travel_panel, setup_time_travel};
use crate::ui::config::{apply_loaded_config, load_config, save_config_on_exit};
use crate::ui::controls::{CheckpointState, handle_deliberate_crash, handle_time_controls, update_crash_reporter_context, update_sim_time_hash};
use crate::ui::inspector_panel::InspectorState;
use crate::ui::panel::{handle_toggle_shortcuts, render_toggle_panel, setup_ui_state, SimTime, UiState};
use crate::ui::transitions::TransitionsPlugin;
use crate::ui::{apply_color_blind_mode, apply_ui_scale, apply_ui_theme, setup_oracle, setup_ui_theme, update_window_title, DemoHudPlugin, InspectorPanelPlugin, OraclePlugin, PanelsPlugin, SideReplayPlugin, UiTheme};
use crate::vfx::{DebrisPlugin, FireSpreadPlugin, SmokePlugin, render_screen_edge_indicators, setup_vfx, spawn_event_particles, update_attention_pulse_animations, update_attention_pulses, update_cpu_particles, VfxState};
use crate::world::{setup_full_atmosphere, setup_ground_with_texture, spawn_settlement_visuals, setup::PendingGltfSpawn, settlement::update_settlement_visuals};

use crate::crash_reporter;

// ============================================================================
// Resolve Asset Path
// ============================================================================

/// Resolve the asset directory path with multiple fallback strategies.
///
/// Strategy (in order):
/// 1. If ANVIL_ASSETS env var is set, use that
/// 2. Try to find assets relative to the executable location
/// 3. Try to find assets relative to CARGO_MANIFEST_DIR (dev mode)
/// 4. Try to find assets relative to current working directory
/// 5. Climb up from executable to find repo root (for dev builds)
/// 6. Fall back to "./assets"
fn resolve_asset_path() -> PathBuf {
    if let Ok(asset_path) = std::env::var("ANVIL_ASSETS") {
        let path = PathBuf::from(asset_path);
        info!("Using ANVIL_ASSETS override: {}", path.display());
        return path;
    }
    
    if let Ok(exe_path) = std::env::current_exe() {
        let exe_dir = exe_path.parent().unwrap_or(Path::new("."));
        let candidate = exe_dir.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
        let parent_candidate = exe_dir.parent().map(|p| p.join("assets"));
        if let Some(p) = parent_candidate {
            if p.exists() {
                info!("Found assets at: {}", p.display());
                return p;
            }
        }
        let mut current = exe_dir.to_path_buf();
        for _ in 0..5 {
            current = current.parent().unwrap_or(Path::new(".")).to_path_buf();
            let candidate = current.join("assets");
            if candidate.exists() {
                info!("Found assets at: {}", candidate.display());
                return candidate;
            }
            if current.join("Cargo.toml").exists() {
                let candidate = current.join("assets");
                if candidate.exists() {
                    info!("Found assets at: {}", candidate.display());
                    return candidate;
                }
            }
        }
    }
    
    if let Ok(manifest_dir) = std::env::var("CARGO_MANIFEST_DIR") {
        let mut path = PathBuf::from(manifest_dir);
        for _ in 0..2 {
            if let Some(parent) = path.parent() {
                path = parent.to_path_buf();
            }
        }
        let candidate = path.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    if let Ok(cwd) = std::env::current_dir() {
        let candidate = cwd.join("assets");
        if candidate.exists() {
            info!("Found assets at: {}", candidate.display());
            return candidate;
        }
    }
    
    PathBuf::from("./assets")
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Resource to control debug overlay visibility
#[derive(Resource, Default)]
struct DebugOverlayVisible(bool);

/// Transition from Loading to InGame once runtime exists
fn transition_to_running(
    runtime: Option<Res<RuntimeResource>>,
    mut app_state: ResMut<NextState<AppState>>,
) {
    if runtime.is_some() {
        app_state.set(AppState::InGame);
    }
}

/// Toggle debug overlay visibility when tilde (backtick) is pressed
fn toggle_debug_overlay(
    keyboard_input: Res<ButtonInput<KeyCode>>,
    mut debug_visible: ResMut<DebugOverlayVisible>,
) {
    if keyboard_input.just_pressed(KeyCode::Backquote) {
        debug_visible.0 = !debug_visible.0;
    }
}

/// Setup system that initializes the world
#[allow(unused_mut)]
fn setup(
    mut commands: Commands,
    mut materials: ResMut<Assets<StandardMaterial>>,
    asset_server: Res<AssetServer>,
) {
    crate::world::setup::setup_world(commands, materials, asset_server);
}

/// Spawn pending GLTF entities
fn spawn_pending_gltfs(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    pending: Query<(Entity, &PendingGltfSpawn)>,
) {
    for (entity, pending) in pending.iter() {
        let scene_handle = asset_server.load(
            GltfAssetLabel::Scene(0).from_asset(pending.path.clone())
        );
        commands.spawn((
            SceneRoot(scene_handle),
            Transform::from_xyz(pending.position.x, pending.position.y, pending.position.z),
            AssetOriginTag(pending.origin.clone()),
        ));
        commands.entity(entity).despawn();
    }
}

/// Debug overlay rendering system
fn debug_overlay(
    mut egui_contexts: EguiContexts,
    query: Query<&AssetOriginTag>,
    runtime: Res<RuntimeResource>,
    tick_counter: Res<SimTickCounter>,
    sim_time: Res<SimTime>,
    debug_visible: Res<DebugOverlayVisible>,
) {
    if !debug_visible.0 {
        return;
    }
    let (total, fallback_count) = debug_fallback_summary(&query);

    if let Some(ctx) = egui_contexts.try_ctx_mut() {
        egui::Window::new("Anvil Debug Overlay").show(ctx, |ui| {
            ui.label(format!("Assets rendered: {}", total));
            ui.label(format!(
                "Using fallback: {} {}",
                fallback_count,
                if fallback_count > 0 { "\u{26a0}" } else { "\u{2705}" }
            ));
            if fallback_count > 0 {
                ui.colored_label(egui::Color32::YELLOW, "Some assets are using fallback materials.");
            }
            ui.label(format!("Runtime: {} loaded regions", runtime.runtime.loaded_regions.len()));
            ui.label(format!("State hash: {}", sim_time.hash));

            ui.separator();
            ui.label("Phase 3 Systems:");
            ui.label(format!(
                "  NPC System: {} persons, {} settlements",
                runtime.runtime.npc_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.npc_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Catastrophe System: {} active events",
                runtime.runtime.catastrophe_system().map_or(0, |s| s.active_events.len())
            ));
            ui.label(format!(
                "  Joy System: {} persons, {} settlements",
                runtime.runtime.joy_system().map_or(0, |s| s.persons.len()),
                runtime.runtime.joy_system().map_or(0, |s| s.settlements.len())
            ));
            ui.label(format!(
                "  Physics System: {} rigid bodies",
                runtime.runtime.physics_system().map_or(0, |s| s.rigid_body_set.len())
            ));
            ui.separator();
            ui.label(format!("Sim Tick: {}", tick_counter.count));
        });
    }
}

// ============================================================================
// Plugin Registration
// ============================================================================

/// Register all demo plugins, resources, and systems with the Bevy app.
pub fn register_demo_plugins(app: &mut App) {
    let asset_path = resolve_asset_path();
    let asset_path_str = asset_path.to_string_lossy().into_owned();

    app
        .add_plugins(DefaultPlugins.set(AssetPlugin {
            file_path: asset_path_str,
            ..default()
        }).disable::<LogPlugin>())
        .init_state::<AppState>()
        .add_plugins(EguiPlugin::default())
        .add_plugins(AnvilAssetPlugin)
        .add_plugins(PlayerPlugin)
        .add_plugins(AtmosphereDriverPlugin)
        .add_plugins((
            AudioPlugin,
            AshveilAudioPlugin,
        ))
        .add_plugins(AppPlugin)
        .add_plugins(TransitionsPlugin)
        .add_plugins(ScenarioLoaderPlugin)
        .add_plugins(SimBridgePlugin)
        .add_plugins(DemoSequencerPlugin)
        .add_plugins(CameraSplinePlugin)
        .add_plugins(DemoSplinePlugin)
        .add_plugins(GlbRenderingPlugin)
        .add_plugins(FireSpreadPlugin)
        .add_plugins(SmokePlugin)
        .add_plugins(DebrisPlugin)
        .add_plugins(NeedsBarPlugin)
        .add_plugins(SkillFlashPlugin)
        .add_plugins(DemoHudPlugin)
        .add_plugins(InspectorPanelPlugin)
        .add_plugins(PanelsPlugin)
        .add_plugins(SideReplayPlugin)
        .add_plugins(OraclePlugin)
        .add_plugins(FrameTimeDiagnosticsPlugin::default())
        .init_resource::<SimTickCounter>()
        .init_resource::<SimRng>()
        .init_resource::<UiState>()
        .init_resource::<SimTime>()
        .init_resource::<CheckpointState>()
        .init_resource::<DisplayOptions>()
        .init_resource::<AudioOptions>()
        .init_resource::<AccessibilityOptions>()
        .init_resource::<CameraState>()
        .init_resource::<EventLog>()
        .init_resource::<CatastrophePanelState>()
        .init_resource::<InspectorState>()
        .init_resource::<PerformancePanelState>()
        .init_resource::<NpcVisualState>()
        .init_resource::<OverlayState>()
        .init_resource::<UiTheme>()
        .init_resource::<VfxState>()
        .init_resource::<DebugOverlayVisible>()
        .add_systems(Startup, (
            setup,
            load_config,
            setup_ui_state,
            setup_main_camera,
            setup_event_log,
            setup_catastrophe_panel,
            setup_performance_panel,
            setup_overlays,
            setup_time_travel,
            setup_oracle_overlay,
            setup_oracle,
            setup_vfx,
            setup_dev_experience,
            setup_ui_theme,
            crash_reporter::startup_update_last_session,
        ))
        .add_systems(OnEnter(AppState::Loading), (
            setup_full_atmosphere,
            setup_ground_with_texture,
            spawn_settlement_visuals,
        ))
        .add_systems(Startup, apply_loaded_config.after(setup_ui_state))
        .add_systems(PostStartup, (
            set_camera_priorities,
            disable_gltf_cameras,
        ))
        .add_systems(PreUpdate, (
            crate::camera::fix_bare_cameras,
            set_camera_priorities,
            crate::world::decorate_new_cameras,
        ))
        .add_systems(PreUpdate, (apply_ui_theme, apply_ui_scale, apply_color_blind_mode))
        .add_systems(PreUpdate, update_window_title)
        .add_systems(PreUpdate, (
            handle_camera_shortcuts,
        ))
        .add_systems(Update, (
            tick_simulation_systems.run_if(resource_exists::<RuntimeResource>),
            spawn_pending_gltfs,
            process_pending_catastrophes.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulses.run_if(resource_exists::<RuntimeResource>),
            update_attention_pulse_animations,
            update_cpu_particles,
            spawn_event_particles.run_if(resource_exists::<RuntimeResource>),
            despawn_npc_visuals,
            update_emotion_lines,
            update_status_rings,
            update_settlement_visuals.run_if(resource_exists::<RuntimeResource>),
            update_npc_breathing_system,
            update_npc_rotation_toward_targets,
            update_npc_movement,
            update_selection_rings,
            update_selection_ring_visibility,
        ).run_if(in_state(AppState::InGame)))
        .add_systems(Update, (
            handle_toggle_shortcuts,
            handle_time_controls.run_if(resource_exists::<RuntimeResource>.and(resource_exists::<crate::app::WorldResource>)),
            handle_catastrophe_shortcuts,
            add_test_events,
        ))
        .add_systems(Last, (
            update_focus_camera,
            save_config_on_exit,
        ))
        .add_systems(Update, (
            handle_mouse_wheel_zoom,
            update_action_halos,
        ))
        .add_systems(Update, spawn_npc_visuals
            .after(tick_simulation_systems)
            .run_if(in_state(AppState::InGame))
            .run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(Update, (
            transition_to_running.run_if(in_state(AppState::Loading)),
        ))
        .add_systems(Update, (
            toggle_debug_overlay,
        ))
        .add_systems(PreUpdate, update_sim_time_hash.run_if(resource_exists::<RuntimeResource>.and(resource_changed::<RuntimeResource>)))
        .add_systems(PreUpdate, update_crash_reporter_context)
        .add_systems(PreUpdate, handle_deliberate_crash)
        .add_systems(EguiPrimaryContextPass, (render_toggle_panel, render_event_log, render_catastrophe_panel, render_performance_panel, render_time_travel_panel, render_oracle_overlay, render_dev_panel, debug_overlay.run_if(resource_exists::<RuntimeResource>), render_network_line_legend, render_screen_edge_indicators.run_if(resource_exists::<RuntimeResource>)));
}
```

### crates/anvil_demo/src/world/atmosphere_driver.rs
```rust
//! Atmosphere driver system for the Ashveil demo.
//!
//! This module implements the `AtmosphereDriver` system that reads live weather
//! and game time from the simulation and writes to the renderer every frame
//! so the world visibly reacts.

use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

use crate::app::RuntimeResource;
use anvil_sim::catastrophe::CatastropheType;

/// Colour temperature lookup table entries.
/// Maps day phase [0, 1] to RGB colour.
const COLOUR_TEMPERATURE_TABLE: [(f32, Color); 6] = [
    // Dawn (0.20): warm amber
    (0.20, Color::srgb(1.0, 0.6, 0.2)),
    // Mid-morning (0.35): soft white
    (0.35, Color::srgb(0.95, 0.85, 0.7)),
    // Noon (0.50): cool white
    (0.50, Color::srgb(0.95, 0.95, 1.0)),
    // Mid-afternoon (0.65): soft white
    (0.65, Color::srgb(0.95, 0.85, 0.7)),
    // Dusk (0.80): warm amber
    (0.80, Color::srgb(1.0, 0.6, 0.2)),
    // Night (0.0/1.0): deep blue
    (0.0, Color::srgb(0.2, 0.2, 0.4)),
];

/// Base fog colour (#121416).
const BASE_FOG_COLOR: Color = Color::srgb(0.0706, 0.0784, 0.0863);
/// Fire bias colour - warm orange.
const FIRE_BIAS_COLOR: Color = Color::srgb(1.0, 0.4, 0.1);
/// Cool blue bias for dusk.
const DUSK_BIAS_COLOR: Color = Color::srgb(0.3, 0.4, 0.6);
/// Neutral grey bias for rain.
const RAIN_BIAS_COLOR: Color = Color::srgb(0.4, 0.4, 0.4);

/// Interpolates colour from the temperature lookup table based on day phase.
fn interpolate_colour_temperature(day_phase: f32) -> Color {
    // Normalize day_phase to [0, 1]
    let phase = day_phase.fract();

    // Find the two closest entries in the table. We track `prev_phase` /
    // `prev_color` directly; the index of the previous entry is not needed
    // for the interpolation itself, only `next_idx` for wrap-around at the
    // night boundary.
    let mut next_idx = 0usize;
    let mut prev_phase = COLOUR_TEMPERATURE_TABLE[0].0;
    let mut prev_color = COLOUR_TEMPERATURE_TABLE[0].1;

    for (i, &(table_phase, table_color)) in COLOUR_TEMPERATURE_TABLE.iter().enumerate() {
        if table_phase <= phase {
            prev_phase = table_phase;
            prev_color = table_color;
        } else {
            next_idx = i;
            break;
        }
    }

    // Handle wrap-around for night (phase near 0 or 1)
    if next_idx == 0 && phase > prev_phase {
        next_idx = 1;
    }

    let next_phase = COLOUR_TEMPERATURE_TABLE[next_idx % COLOUR_TEMPERATURE_TABLE.len()].0;
    let next_color = COLOUR_TEMPERATURE_TABLE[next_idx % COLOUR_TEMPERATURE_TABLE.len()].1;

    // Calculate interpolation factor
    let range = next_phase - prev_phase;
    if range <= 0.0 {
        return prev_color;
    }
    let t = (phase - prev_phase) / range;

    prev_color.mix(&next_color, t.clamp(0.0, 1.0))
}

/// Checks if a wildfire is currently active in the catastrophe system.
fn is_fire_active(runtime: &RuntimeResource) -> bool {
    for system in &runtime.runtime.systems {
        if let Some(catastrophe_system) = system.as_any().downcast_ref::<anvil_sim::CatastropheSystem>() {
            for event in &catastrophe_system.active_events {
                if event.catastrophe_type == CatastropheType::Wildfire {
                    return true;
                }
            }
        }
    }
    false
}

/// Checks if it's currently raining based on weather phase.
fn is_raining(weather: &anvil_runtime::weather::WeatherSimulation) -> bool {
    use anvil_runtime::weather::WeatherPhase;
    matches!(
        weather.current_weather,
        WeatherPhase::Rain | WeatherPhase::Storm
    )
}

/// System that updates atmosphere settings based on simulation state.
pub fn update_atmosphere(
    runtime: Option<Res<RuntimeResource>>,
    mut directional_lights: Query<(&mut DirectionalLight, &mut Transform)>,
    mut fog_query: Query<&mut DistanceFog, With<Camera3d>>,
    mut ambient_lights: Query<&mut AmbientLight>,
) {
    let Some(runtime) = runtime else {
        return;
    };

    let game_time = &runtime.runtime.time;
    let weather = &runtime.runtime.weather;

    // ========================================================================
    // Sun direction
    // ========================================================================
    // hour = game_time.hour_of_day() equivalent
    // day_phase is [0, 1] where 0 = start of day, 1 = end of day
    // Map to: -30 deg at night (phase 0 or 1), 90 deg at noon (phase 0.5)
    // Using: pitch_rad = (day_phase - 0.25) * PI for smoother curve
    // This gives: dawn at ~0.25 -> ~0°, noon at 0.5 -> ~90°, dusk at ~0.75 -> ~0°, night -> ~-90°
    // Clamped to [-30°, 90°] range
    let day_phase = game_time.day_phase();
    let sun_pitch_rad = (day_phase - 0.25) * std::f32::consts::PI;
    let sun_pitch_deg = sun_pitch_rad.sin() * 90.0 - 30.0; // Shift and scale
    let sun_pitch = sun_pitch_deg * std::f32::consts::PI / 180.0;

    // Apply rotation to directional lights (sun points along -Z by default)
    for (mut light, mut transform) in directional_lights.iter_mut() {
        transform.rotation = Quat::from_rotation_x(-sun_pitch);

        // ====================================================================
        // Sun colour
        // ====================================================================
        let sun_color = interpolate_colour_temperature(day_phase);

        // Apply humidity bias (grey out when humidity > 0.5)
        let mut final_color = sun_color;
        if weather.humidity > 0.5 {
            let grey_factor = (weather.humidity - 0.5) / 0.5; // [0, 1] for humidity [0.5, 1.0]
            let grey = Color::srgb(0.5, 0.5, 0.5);
            final_color = final_color.mix(&grey, grey_factor);
        }

        // Apply fire bias when wildfire is active
        if is_fire_active(&runtime) {
            final_color = final_color.mix(&FIRE_BIAS_COLOR, 0.3);
        }

        light.color = final_color;
    }

    // ========================================================================
    // Fog
    // ========================================================================
    // Base density: 0.0008 * (1.0 + humidity * 2.0) + 0.0004 * precipitation
    let base_density = 0.0008 * (1.0 + weather.humidity * 2.0) + 0.0004 * weather.accumulated_precipitation;

    // Fog colour: base #121416
    let mut fog_color = BASE_FOG_COLOR;

    // Lerp warm orange when fire active
    if is_fire_active(&runtime) {
        fog_color = fog_color.mix(&FIRE_BIAS_COLOR, 0.4);
    }

    // Cool blue at dusk (day phase ~0.75-0.85)
    if day_phase >= 0.70 && day_phase <= 0.85 || day_phase <= 0.05 {
        fog_color = fog_color.mix(&DUSK_BIAS_COLOR, 0.5);
    }

    // Neutral grey during rain
    if is_raining(weather) {
        fog_color = fog_color.mix(&RAIN_BIAS_COLOR, 0.6);
    }

    // Update fog on all 3D cameras
    for mut fog in fog_query.iter_mut() {
        fog.color = fog_color;
        // Use ExponentialSquared falloff
        if let FogFalloff::ExponentialSquared { density } = &mut fog.falloff {
            *density = base_density;
        } else {
            fog.falloff = FogFalloff::ExponentialSquared {
                density: base_density,
            };
        }
    }

    // ========================================================================
    // Ambient light
    // ========================================================================
    // Base intensity 0.15
    // Drop 30% when humidity > 0.7
    // Boost 15% at midday (day phase ~0.5)
    let mut ambient_brightness = 0.15;

    if weather.humidity > 0.7 {
        ambient_brightness *= 0.7; // Drop 30%
    }

    // Boost at midday (around phase 0.5, +/- 0.1)
    if day_phase >= 0.4 && day_phase <= 0.6 {
        // Linear boost: max 15% at exact midday
        let midday_dist = (day_phase - 0.5).abs();
        let boost_factor = 1.0 - (midday_dist / 0.1).min(1.0);
        ambient_brightness *= 1.0 + 0.15 * boost_factor;
    }

    // Update all ambient lights
    for mut ambient in ambient_lights.iter_mut() {
        ambient.brightness = ambient_brightness.clamp(0.0, 2.0);
    }
}

/// Plugin that registers the atmosphere driver systems.
pub struct AtmosphereDriverPlugin;

impl Plugin for AtmosphereDriverPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Update, update_atmosphere);
    }
}
```

### crates/anvil_demo/src/world/atmosphere.rs
```rust
//! Atmosphere rendering systems.
//!
//! This module handles fog, lighting, and tonemapping for the scene.
//! All values match the Visual Uplift Sprint Phase 1 specifications.

use bevy::core_pipeline::tonemapping::{DebandDither, Tonemapping};
use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

/// Sky top color - deep blue (#1B2433).
#[allow(dead_code)]
pub const SKY_TOP_COLOR: Color = Color::srgb(0.1059, 0.1451, 0.20);

/// Sky horizon color - blue-grey (#2E3E55).
#[allow(dead_code)]
pub const SKY_HORIZON_COLOR: Color = Color::srgb(0.1804, 0.2431, 0.3333);

/// Sun color - warm orange (#F59E0B).
#[allow(dead_code)]
pub const SUN_COLOR: Color = Color::srgb(0.9608, 0.6196, 0.0431);

/// Fog color - dark near-black (#121416).
pub const FOG_COLOR: Color = Color::srgb(0.0706, 0.0784, 0.0863);

/// Fog density for exponential squared falloff.
pub const FOG_DENSITY: f32 = 0.0008;

/// Sun light color - slightly warm white (#FFF4E5).
pub const SUN_LIGHT_COLOR: Color = Color::srgb(1.0, 0.9569, 0.898);

/// Sun light intensity.
pub const SUN_LIGHT_INTENSITY: f32 = 120000.0;

/// Ambient light color - cool blue-grey (#CBD5E1).
pub const AMBIENT_LIGHT_COLOR: Color = Color::srgb(0.7961, 0.8353, 0.8824);

/// Ambient light intensity.
pub const AMBIENT_LIGHT_INTENSITY: f32 = 0.15;

/// Marker component for the sun directional light.
#[derive(Component)]
pub struct SunLight;

/// Combined setup for all atmosphere elements:
/// - Camera clear color (sky top color #1B2433)
/// - Directional light (sun) at 45 degree elevation with color #FFF4E5, intensity 120000
/// - Ambient light with color #CBD5E1 at intensity 0.15
/// - Tonemapping: TonyMcMapface with DebandDither enabled
/// - Fog: ExponentialSquared with density 0.0008 and color #121416
pub fn setup_full_atmosphere(
    mut commands: Commands,
    mut cameras: Query<(Entity, &mut Camera)>,
) {
    for (entity, mut camera) in cameras.iter_mut() {
        // Camera clear color: sky top color #1B2433
        camera.clear_color = ClearColorConfig::Custom(SKY_TOP_COLOR);
        
        // Add Tonemapping component to the camera entity
        commands.entity(entity).insert(Tonemapping::TonyMcMapface);
        
        // Add DebandDither component to the camera entity
        commands.entity(entity).insert(DebandDither::Enabled);
        
        // Add DistanceFog component to the camera entity
        commands.entity(entity).insert(DistanceFog {
            color: FOG_COLOR,
            directional_light_color: SUN_COLOR,
            directional_light_exponent: 1.0,
            falloff: FogFalloff::ExponentialSquared {
                density: FOG_DENSITY,
            },
        });
    }
    
    // Spawn directional light (sun) at 45 degree elevation
    // In Bevy, light points along -Z by default. To get 45° elevation,
    // we rotate around X by -45° (pi/4 radians) so it points down and forward.
    commands.spawn((
        DirectionalLight {
            illuminance: SUN_LIGHT_INTENSITY,
            color: SUN_LIGHT_COLOR,
            shadows_enabled: true,
            ..default()
        },
        SunLight,
        Transform::from_rotation(Quat::from_euler(
            EulerRot::ZYX,
            0.0,
            0.0,
            -std::f32::consts::FRAC_PI_4, // -45 degrees pitch
        )),
    ));

    // Setup ambient light
    commands.spawn(AmbientLight {
        color: AMBIENT_LIGHT_COLOR,
        brightness: AMBIENT_LIGHT_INTENSITY,
        ..default()
    });
}

/// Legacy system for fog setup - now handled in setup_full_atmosphere.
#[allow(dead_code)]
pub fn setup_fog() {}

/// System that decorates newly-added cameras with the atmospheric
/// configuration (clear colour, tonemapping, fog) that `setup_full_atmosphere`
/// applies to the cameras present at startup.
///
/// Gated by `Added<Camera3d>` so it does no work on the steady state.
pub fn decorate_new_cameras(
    mut commands: Commands,
    new_cameras: Query<Entity, Added<Camera3d>>,
) {
    for entity in new_cameras.iter() {
        commands.entity(entity).insert((
            Camera {
                clear_color: ClearColorConfig::Custom(SKY_TOP_COLOR),
                ..default()
            },
            Tonemapping::TonyMcMapface,
            DebandDither::Enabled,
            DistanceFog {
                color: FOG_COLOR,
                directional_light_color: SUN_COLOR,
                directional_light_exponent: 1.0,
                falloff: FogFalloff::ExponentialSquared { density: FOG_DENSITY },
            },
        ));
    }
}
```
