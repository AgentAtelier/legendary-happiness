# Refactor Execution Manual

**Status:** Operational manual. Not a constitution; not a principles document. Bridges the binding constraints (`ANVIL_PHILOSOPHY.md`, `ANVIL_DETERMINISM.md`, plus the five prior specifications) to day-to-day refactoring decisions a solo developer can make without Opus consultation.

**Authority:** Subordinate to `ANVIL_PHILOSOPHY.md`. If this manual contradicts a commandment, the commandment wins.

---

## Document Structure (with departures from the brief)

The brief specified seven sections. I have added four because each addresses a friction point that would otherwise force an Opus session:

| § | Title | Status | Reason for addition |
|---|---|---|---|
| 1 | Pre-Refactor Protocol | as briefed | — |
| 2 | Constraint Application Matrix | as briefed | — |
| 3 | **Refactor Sequencing Protocol** | added | When multiple violations exist (the audit found 7 simultaneously), order matters. Fixing #5 before #3 creates rework. Sequencing is a routine decision the dev makes weekly; it must be in the manual. |
| 4 | Bevy-Native Solution Lookup Table | as briefed | — |
| 5 | "Work With Bevy" Pattern Catalog | as briefed | — |
| 6 | **Anti-Pattern Catalog** | added | The pattern catalog teaches what to do. The anti-pattern catalog teaches what to recognize as wrong. The audit found 7 anti-patterns; future audits will find more. Solo dev needs a checklist of shapes to flag. |
| 7 | Dead Code Archaeology Protocol | as briefed | — |
| 8 | **Symptom-to-Cause Diagnostic** | added | When tests fail or behaviour drifts, the layer that produced the symptom is rarely the layer to fix. Decision tree saves hours per occurrence. |
| 9 | **Rollback Protocol** | added | Atomic-commit discipline; `git reflog` recovery procedures. Solo devs without code review lose time when a refactor goes wrong; a rollback drill closes that gap. |
| 10 | Escalation Criteria | as briefed | — |
| 11 | Verification Checklist | as briefed | — |
| 12 | **Decision Log Format** | added | The brief's §7 requires a "Decision Log entry" but the format was never specified. Without a template, entries drift in shape and become un-greppable. A solo dev's decision log is their only second reviewer. |

Each added section has a single, specific job. If during use it turns out to overlap an existing section, the dupes are merged on next revision of this manual.

---

## Section 1: The Pre-Refactor Protocol

Before opening any file for modification, run this five-question checklist. The first question that returns "no" or "unknown" terminates the refactor and routes to the indicated procedure.

### 1.1 — Is this file imported or called anywhere?

```bash
# Find module declarations
rg --type rust "mod\s+$(basename "$FILE" .rs)\b" crates/

# Find use statements referencing it (path-based, fuzzy)
MOD=$(basename "$FILE" .rs)
rg --type rust "use\s+.*::${MOD}(::|;|\s|$)" crates/

# Find references to types/functions defined in the file
# (extract public items first)
rg --type rust '^pub\s+(fn|struct|enum|trait|const|static|type)\s+\w+' "$FILE" \
  | awk '{print $3}' | sed 's/[(:<{].*//' | sort -u \
  | while read sym; do
      hits=$(rg --type rust --count-matches "\b${sym}\b" crates/ \
             --glob "!$FILE" 2>/dev/null | wc -l)
      echo "$sym: $hits files reference"
    done
```

If every public item shows zero external references, go to §7 (Dead Code Archaeology). Do not refactor unreferenced code; delete it.

### 1.2 — Is it reachable from `main()` or a public API?

```bash
# Start from the binary's main, walk through plugins, find what registers what
rg --type rust "fn main\(\)" crates/
rg --type rust "add_plugins\|add_systems\(" crates/

# For a SimSystem candidate
rg --type rust "register_system\|register_canonical_systems" crates/

# For a Bevy plugin
rg --type rust "fn build\(\s*&self,\s*app:" crates/
```

If reachable from `main()` only through a `#[cfg(test)]` path, treat as test-only — file goes to `tests/` or `#[cfg(test)] mod`. If reachable only from a `#[cfg(feature = "...")]` flag, verify the feature is actually used (`rg "feature\s*=\s*\"<name>\"" Cargo.toml`).

If unreachable, go to §7.

### 1.3 — When was it last modified? What commit introduced it?

```bash
# Last touch
git log -1 --format='%h %an %ad %s' -- "$FILE"

# Birth commit
git log --follow --diff-filter=A --format='%h %ad %s' -- "$FILE" | tail -1

# Full history
git log --follow --format='%h %ad %s' -- "$FILE"
```

**Decision rules:**

- Birth commit is older than 6 months and last touch is older than 3 months → cold code. Check §7 before refactoring; the original author's context is lost.
- Birth commit was a port (`PLACEHOLDER FROM forge_*` header per Commandment 6) → check `PLACEHOLDER_DEBT.md`. If review date passed, queue the placeholder review *before* refactoring.
- Birth commit is part of a sprint marked "Phase 3 Gate" or similar → cross-reference `ANVIL_DETERMINISM.md` for the system's coverage status. If it's a determinism-verified system, the refactor must include a re-run of its determinism test (§11).

### 1.4 — Does it have a Bevy-native equivalent?

Cross-reference §4 (Bevy-Native Solution Lookup). The answer is one of:

- **Native exists, same shape.** Replace the custom code with the native. Go to §11.
- **Native exists, partial overlap.** Document which capability the native lacks. If the gap is incidental, take the native. If the gap is essential to gameplay, the custom stays; record the gap in `DECISIONS.md` per §12.
- **No native equivalent.** Proceed with custom refactor. The "Work With Bevy" patterns in §5 still apply.
- **Native exists but in a banned crate** (e.g., Bevy facility in a deterministic crate). The Bevy native is **not available** to this code; treat as "no native equivalent."

### 1.5 — Does it violate any binding constraint?

Run the constraint detection commands from §2 against the file:

```bash
# Production panic surface
rg "\.unwrap\(\)\|\.expect\(\|panic!\|unreachable!\|todo!" "$FILE" \
  | grep -v "// SAFETY:" | grep -v "// PANIC-OK:"

# File size
test_start=$(awk '/^#\[cfg\(test\)\]/{print NR; exit}' "$FILE")
prod=$([ -n "$test_start" ] && echo $((test_start - 1)) || wc -l < "$FILE")
echo "Production lines: $prod"

# Function size — clippy will catch but pre-check
awk '/^[[:space:]]*(pub )?(async )?fn / {start=NR; name=$0}
     /^}/ {if (start) {print NR-start, name; start=0}}' "$FILE" \
  | sort -rn | head -5

# Firewall — banned imports
if echo "$FILE" | grep -qE 'crates/(anvil_core|anvil_world|anvil_sim|anvil_runtime|anvil_assets|anvil_physics|anvil_ai)/' ; then
    rg "^use bevy|^use tokio|^use reqwest" "$FILE"
fi

# WorldView Spec §4.2 — bridge layer reading sim directly
if echo "$FILE" | grep -qE 'anvil_(bevy|demo)/' ; then
    rg "use anvil_(sim|runtime)::" "$FILE" \
      | grep -v "sim_bridge\.rs"   # bridge file is permitted
fi
```

Every violation listed by these greps either needs fixing as part of this refactor or is the reason for the refactor. If you find violations *not* related to your stated refactor scope, log them in `DECISIONS.md` (§12) as follow-ups and do not silently fix them in this commit. **One refactor = one concern** (Commandment 5 / Process Principles).

### 1.6 — The `build.rs` Case Study

The audit identified `build.rs` as dead code that the protocol would have flagged. Walking the protocol:

| Q | Result for `build.rs` | What the protocol would have said |
|---|---|---|
| 1.1: Imported anywhere? | `build.rs` is a Cargo convention; not "imported" in Rust sense. Run `cargo build -v 2>&1 \| grep "Compiling.*build.rs"` to see if Cargo invokes it, and `grep "build = " Cargo.toml` to see if any crate explicitly references it. If `build = ` is absent and `build.rs` exists, Cargo invokes it implicitly. So the question is: does it *do* anything? | `grep -v '^\s*$\|^\s*//\|^\s*fn main()\s*{\s*}\s*$' build.rs` — if this returns empty, the file has zero effect. |
| 1.2: Reachable from main? | Build scripts are not in the runtime graph. The question reframes to: does Cargo's behaviour change if the file is deleted? | `cp build.rs /tmp/build.rs.bak && rm build.rs && cargo check --workspace`. If `cargo check` succeeds, the file is dead. |
| 1.3: When introduced? | `git log --follow --diff-filter=A -- build.rs` | If the commit message says "scaffold for codegen" and no codegen ever materialised, the file is fossilised intent. |
| 1.4: Native equivalent? | N/A — build scripts are the Cargo native; the question is whether *anything* needs to happen at build time. | If the answer is no, there is no refactor: there is a deletion. |
| 1.5: Constraint violation? | A no-op `build.rs` is not a violation per se, but it adds to crate size accounting and pollutes dependency invalidation (every workspace member re-runs `build.rs` on every clean build). | Recommend deletion. |

**Lesson:** the protocol's first three questions, applied honestly, terminate the refactor before any code is touched. The dev's time spent on the build.rs question is bounded by `cargo check --workspace`, ~30s on a warm cache.

---

## Section 2: The Constraint Application Matrix

One row per binding constraint. The Detection Tool column is the command the dev runs *before* refactoring; the Fix Pattern is the named pattern in §5; the Exception Path is the only legal escape; the Verification Command is what proves the fix.

| Constraint | Detection Tool | Fix Pattern | Exception Path | Verification Command |
|---|---|---|---|---|
| **C1: No production panics without `// SAFETY:` proof** (Commandment 3) | `cargo clippy --workspace --all-targets -- -D warnings` plus the audit grep `rg "clippy::expect_used\|clippy::unwrap_used\|clippy::panic" crates/*/src --include='*.rs' \| grep -v "// SAFETY:"` | Pattern P-RESULT-PROPAGATION (§5.1): replace with `Result<T, E>` and propagate via `?`. Pattern P-OPTION-FAIL-FAST (§5.2): for `Query::single()` and `Option::Some` cases, use `let Ok(x) = ... else { return Err(...); }`. | Two only: (a) `#[cfg(test)]` body — clippy auto-permits; (b) visual-layer panic with `// PANIC-OK: <reason>` annotation per the prior Doctrine §2.2. **Never** in `anvil_core/anvil_world/anvil_sim/anvil_runtime/anvil_assets/anvil_physics/anvil_ai`. | `cargo clippy -p <crate> -- -D clippy::unwrap_used -D clippy::expect_used -D clippy::panic -D clippy::unreachable -D clippy::todo` returns 0. |
| **C2: Size budgets** (Commandment 4 — file ≤ 500, function ≤ 50, crate ≤ 5000) | File: `bash scripts/check_size.sh`. Function: `cargo clippy --workspace -- -D clippy::too_many_lines`. Crate: `find crates/<name>/src -name '*.rs' -exec awk '/^#\[cfg\(test\)\]/{exit} 1' {} \; \| wc -l` | Split. Identify the boundary along which the file is doing two things; split there. For functions, extract the inner loop body or the per-element logic into a helper. For crates, draw a vertical line between subsystems and create a sibling crate. | None. The numeric budget is the budget. The 400/40/4000 warning thresholds give 4 weeks of grace; once a file crosses the warning, the next PR that touches it must split. | `bash scripts/check_size.sh` returns 0; `cargo clippy --workspace -- -D clippy::too_many_lines` returns 0. |
| **C3: Cross-platform bit-identical state hashes** (`ANVIL_DETERMINISM.md`) | `bash tests/phase3_gate.sh` on each of x86_64-linux, aarch64-linux, aarch64-darwin. For local-only check: run any determinism test twice consecutively, compare logged hashes. | Pattern P-CTX-RNG (§5.3): replace any local RNG with `ctx.rng.next_f32()`. Pattern P-BTREEMAP (§5.4): replace `HashMap` with `BTreeMap` in sim-state structs. Pattern P-TO-BITS (§5.5): hash floats via `to_bits()`. | One only: physics simulation (Rapier3D). `ANVIL_DETERMINISM.md` §"Systems with Known Platform Dependencies" documents the canary test. Any new platform-dependent code requires a Phase 4 platform-restriction decision in `DECISIONS.md`. | `cargo test -p anvil_sim --test phase3_determinism` returns 0; output hash matches the same test run twice on the same machine; if multi-platform, the hashes match across platforms. |
| **C4: Typed errors, four-tier degradation** (Error Handling Doctrine) | `rg "String\)" crates/*/src --include='*.rs' \| grep -E "(SimError\|RuntimeError\|BridgeError\|UiError)::"` should return zero. `rg "impl From<SimError> for (BridgeError\|UiError)" crates/` should return zero (skipping layers is forbidden, Doctrine §3.1). | Pattern P-TYPED-ERROR (§5.6): use the structured variant from Doctrine §1. Pattern P-LAYER-WRAP (§5.7): translate at each crate boundary via `From` impl. | One only: `anyhow::Error` is permitted in visual-layer interop with Bevy asset loaders (Doctrine §4.5). | `cargo check -p <crate>`; absence of `String` payload greps; presence of degradation tier in `DECISIONS.md` entry. |
| **C5: All visual reads via WorldView** (WorldView Specification) | `rg "Res<RuntimeResource>" crates/anvil_bevy crates/anvil_demo --type rust \| grep -v sim_bridge \| grep -v tick_simulation_systems` should return zero. `rg "use anvil_(sim\|runtime)::" crates/anvil_bevy crates/anvil_demo --type rust \| grep -v sim_bridge` should return zero. | Pattern P-WORLDVIEW-READ (§5.8): replace `runtime.runtime.X` reads with `world_view.X` reads. For writes, use `RuntimeCommand` (P-RUNTIME-COMMAND, §5.9). | The bridge layer itself (`crates/anvil_demo/src/sim_bridge/`, `crates/anvil_bevy/src/sim_bridge.rs`) is permitted to read both sides — it is the translation seam. | After refactor: visual-side greps return zero; `cargo test --test phase3_snapshot_roundtrip` passes; UI smoke test still renders. |
| **C6: DeterministicRng is sole entropy; BTreeMap; bincode** (Simulation Core Reliability) | `rg "LCG\|::thread_rng\|SystemTime::now" crates/anvil_(sim\|runtime\|core\|world)` returns zero. `rg "HashMap" crates/anvil_sim crates/anvil_runtime --type rust \| grep -v "^\s*//"` requires manual review. `rg "serde_json::to_vec\(.*system" crates/anvil_sim/src` returns zero. | P-CTX-RNG (§5.3), P-BTREEMAP (§5.4), P-BINCODE (§5.10). | None for RNG. `HashMap` permitted in `SimContext` ephemeral (cleared per tick) and `anvil_assets` (build-time data). bincode required for `SimSystem::snapshot()`; outer `SaveFile` may use serde_json for metadata. | `cargo test -p anvil_sim --test phase3_determinism`; manual review of any new `HashMap` import. |

---

## Section 3: The Refactor Sequencing Protocol

Refactors don't compose by adding effort; some refactors *block* others or *invalidate* others' tests. When the dev has a backlog of N candidate refactors, the order matters.

### 3.1 — The Five Sequencing Rules

**Rule R1 — Doctrine before everything.** Any refactor that changes an error variant or its propagation path goes first. Doctrine changes invalidate every layer's error handling above the change point; doing them last means redoing them.

**Rule R2 — Determinism before bridging.** Any refactor that affects `state_hash` (RNG, iteration order, snapshot format) goes before any refactor that affects how visual systems read state. Otherwise, the determinism tests pass with old hashes and fail with new ones, and the failure looks like it came from the bridge change.

**Rule R3 — Splits before consolidations.** If you need to split a file (§4-violation) and also consolidate two systems' state (boundary violation), split first. Consolidation needs both halves to be in their final files so the move is local.

**Rule R4 — Deletions before refactors.** Any code you intend to delete (§7 candidates) goes before any refactor that would touch the same area. Deleting reduces the surface that subsequent refactors must consider.

**Rule R5 — Tests before refactors.** If a refactor target lacks a determinism test or a unit test that covers its behaviour, the test ships in a separate, prior commit. **The test on the unrefactored code must pass.** If you write the test on the refactored code, you have no baseline to confirm equivalence.

### 3.2 — The Sequencing Worksheet

For any candidate refactor R, fill out:

```
Refactor: <name>
Touches files: <list>
Touches state_hash? Y/N
Touches error types? Y/N
Touches bridge boundary? Y/N
Touches size budget? Y/N (split? consolidate?)
Touches dead code? Y/N
Has pre-existing test coverage? Y/N
   If N: what test must ship first?
Blocked by other refactor in backlog? <names>
Blocks other refactor in backlog? <names>
```

Then rank by:

1. R5: every R with `Has pre-existing test coverage? N` becomes two refactors (test, then refactor).
2. R4: every R that is a deletion goes first within its rank tier.
3. R1: R touching error types goes next.
4. R2: R touching state_hash goes next.
5. R3: splits go before consolidations.
6. Topological sort on "blocks" / "blocked by".

### 3.3 — Worked Example: The Day 2 Audit Backlog

The Day 2 audit found 7 violations + 6 determinism threats. Applied to the worksheet:

| Refactor | hash | err | bridge | size | dead | tests | depends |
|---|---|---|---|---|---|---|---|
| Threat 5 fix: `RegionColliderMap` → BTreeMap | **Y** | N | N | N | N | exists (phase3_determinism) | independent |
| Threat 1 fix: physics LCG + catastrophe fork | **Y** | N | N | N | N | partial — needs new physics RNG test | needs SimError variant |
| Threat 3 fix: priority constants + assertion | **Y** | Y (RegistrationConflict variant) | N | N | N | exists | independent |
| Threat 4 fix: WorldEnv HashMap → BTreeMap | latent | N | N | N | N | none — write test first | independent |
| Threat 6 fix: bincode standardisation + v9→v10 | **Y** | Y (SerializationFailed variant) | N | N | N | needs new migration test | needs SAVE_FORMAT bump infrastructure |
| Violation 1: weather phase translation | N | N | bridge writer | N | N | bridge test exists | depends on Threat 6 (save format) |
| Violation 3: delete AtmosphereDriverPlugin | N | N | visual reader | N | **Y** (whole plugin is dead-shaped) | atmosphere has integration test | depends on WorldView extraction extension |
| Violation 4: glb_rendering AuthoredView | N | N | visual reader | N | N | none — need authored-view test | depends on AuthoredView resource creation |
| Violation 5: idle.rs SpawnViewerNpc command | N | Y (CommandRejectionReason variant) | write path | N | N | need command-handler test | needs RuntimeCommand extension |
| Violation 6: weather panel WorldView read | N | N | visual reader | N | N | UI smoke test | depends on WeatherView.phase_label |
| Violation 7: sync_regions runtime reads | N | N | bridge writer | N | N | none — need RegionView test | depends on RegionView definition |
| Violation 2: world_integrity narrowing | N | N | (acceptable) | N | N | exists | independent |
| Error doctrine String purge | N | **Y** | N | N | N | exists across crates | **blocks everything else** |

Sorted by the rules:

1. **Doctrine String purge** (R1) — blocks every subsequent error variant change.
2. **Threat 3 priority constants** (R1) — adds `RegistrationConflict` variant; quick.
3. **Threat 4 WorldEnv BTreeMap** + **Threat 5 RegionColliderMap BTreeMap** (R2, latent — bundle them, single audit grep find/replace).
4. **Threat 1 RNG fork removal** (R2) — once `SimError::DeterminismViolated` exists.
5. **Threat 6 bincode standardisation** (R2) — single SAVE_FORMAT bump v9→v10.
6. **WorldView extension** (regions, npcs, settlements, weather phase_label) — bridge-side.
7. **Violation 1, 6, 7** — clean reader migrations now that WorldView has the fields.
8. **Violation 5 — RuntimeCommand::SpawnViewerNpc** + idle.rs migration.
9. **Violation 4 — AuthoredView** + glb_rendering migration.
10. **Violation 3 — Delete AtmosphereDriverPlugin** (R4 last, because the merge of its effects into EnvironmentPlugin must be tested first).

This ordering minimises rework: each step's tests stay valid once written, and no step invalidates a prior step's commits.

### 3.4 — The "One Refactor Per Commit" Discipline

Every refactor produces exactly one commit (excluding the prior-test commit from R5). The commit message has three lines:

```
<area>: <one-sentence summary>

<paragraph: why this refactor is needed, citing constraint or audit finding>

DECISIONS.md: <link to entry>
```

Rationale: `git bisect` exists. A single-concern commit lets `bisect` localise regressions to one change. A grab-bag commit means `bisect` lands on a change that touches 50 files and the dev re-bisects manually. The cost of writing a focused commit is ~10 minutes; the cost of debugging a multi-concern commit gone wrong is hours.

---

## Section 4: Bevy-Native Solution Lookup Table

For each situation, the table specifies: the Bevy module path, the type or API, a minimal working example, the verification command, and the conditions under which a custom implementation is justified. **All API references are confirmed for Bevy 0.18** unless otherwise noted.

### 4.1 — Schedule a system to run at a fixed simulation rate

| Field | Value |
|---|---|
| Situation | "I need this system to run at exactly N Hz, regardless of frame rate" |
| Bevy native | `bevy::time::Fixed` + `FixedUpdate` schedule |
| Module path | `bevy::time::Fixed`, `bevy::app::FixedUpdate` |
| Bevy version | 0.18 (API stable since 0.13; default 64 Hz) |
| Minimal example | `app.insert_resource(Time::<Fixed>::from_hz(64.0)); app.add_systems(FixedUpdate, my_system);` |
| Verify it's active | `rg "FixedUpdate" crates/<your_crate>` and add an `info!` to `my_system`; observe log frequency. |
| When custom is justified | Sub-tick stepping (multiple sim ticks per frame at variable rate, e.g., catch-up loops with hand-rolled accumulators). The audit found `tick_simulation_systems` calls `runtime.apply(Tick)` 60 times per frame multiplied by `SimSpeed`; this is fundamentally incompatible with `FixedUpdate` because the loop is internal to a single Bevy system, not a per-frame schedule iteration. Keep custom in this case. **Justification entered in `DECISIONS.md`**: "Sim runs at variable speed via `SimSpeed`; `FixedUpdate` cannot model speed-multiplied catch-up." |

### 4.2 — Tag a singleton entity (sun, primary camera)

| Field | Value |
|---|---|
| Situation | "I have exactly one X in the world; I want queries to find it without ambiguity" |
| Bevy native | Marker component (zero-sized struct deriving `Component`) + `With<Marker>` query filter |
| Module path | `bevy::ecs::component::Component` |
| Bevy version | 0.18 (component derivation stable since pre-0.10) |
| Minimal example | `#[derive(Component)] struct SunLight; fn rotate_sun(mut q: Query<&mut Transform, With<SunLight>>) { /* ... */ }` |
| Verify singleton at runtime | Add a startup-end system `fn check(q: Query<(), With<SunLight>>) { debug_assert_eq!(q.iter().count(), 1); }`. |
| When custom is justified | Never. The audit found two duplicate `SunLight` marker types (one in `anvil_bevy::markers`, one local to `anvil_demo::world::atmosphere`); the fix is to delete the duplicate, not to invent a custom registry. |

### 4.3 — Parent-child entity hierarchy (e.g., player body + camera child)

| Field | Value |
|---|---|
| Situation | "I need entity B's transform to inherit from entity A" |
| Bevy native | `ChildOf` relationship component + `Children` collection component |
| Module path | `bevy::ecs::hierarchy::{ChildOf, Children}`, re-exported via `bevy::prelude::*` |
| Bevy version | 0.18 (replaces pre-0.16 `Parent`/`Child`; hook-driven bidirectional sync) |
| Minimal example | `let parent = commands.spawn(...).id(); let child = commands.spawn((..., ChildOf(parent))).id();` or `commands.spawn(...).with_children(|p| { p.spawn(...); });` |
| Verify it's wired | `q_parent.iter_descendants(parent).count()` returns expected child count. |
| When custom is justified | Almost never. Note the audit finding: `setup_player_camera` does `commands.entity(camera).insert(ChildOf(body))` *after* spawning both, which is the documented pattern. There is also a Bevy 0.18 known issue (#23258) where `DynamicScene::write_to_world` doesn't fire `ChildOf` hooks; if importing scenes, the documented workaround is to re-insert `ChildOf` after load. |

### 4.4 — Apply distance fog to a camera

| Field | Value |
|---|---|
| Situation | "I want fog visible from this camera with controllable color/density" |
| Bevy native | `DistanceFog` component on a `Camera3d` entity, with `FogFalloff` for the curve |
| Module path | `bevy::pbr::{DistanceFog, FogFalloff}` |
| Bevy version | 0.18 |
| Minimal example | `commands.spawn((Camera3d::default(), DistanceFog { color: Color::srgb(0.07, 0.08, 0.09), falloff: FogFalloff::ExponentialSquared { density: 0.0008 }, ..default() }));` |
| Verify | Run scene; with `density > 0`, distant objects fade. Set `density = 0` to disable as a sanity check. |
| When custom is justified | Volumetric fog driven by simulation state (e.g., a region-confined storm cloud) — use Bevy's `VolumetricFog` + `FogVolume` rather than custom. Pure 2D screen-space fog overlay (not depth-aware) is one of the few cases where a custom post-process is justified; document the gameplay reason. |

### 4.5 — Pass simulation state to a UI panel

| Field | Value |
|---|---|
| Situation | "I want the weather panel to display current humidity/temperature" |
| Bevy native | A Bevy `Resource` (the WorldView-side snapshot) populated by a bridge system, read by the UI system via `Res<T>` |
| Module path | `bevy::ecs::system::{Res, Resource}`, derive `Resource` |
| Bevy version | 0.18 (Resource derive stable) |
| Minimal example | `#[derive(Resource, Default, Clone)] struct WorldView { weather: WeatherView, /* ... */ }` and `fn render_weather(world_view: Res<WorldView>) { /* ... */ }` |
| Verify | Resource exists at startup: `app.init_resource::<WorldView>();` before any system reads it. UI panel reads `world_view.weather.*` directly. |
| When custom is justified | Multi-frame staleness tracking is needed (the WorldView spec specifies `Tracked<T> { value, last_updated_tick }`). The custom wrapper goes around the `Resource`, not in place of it. |

### 4.6 — One system reacts to another's output

| Field | Value |
|---|---|
| Situation | "When sim emits a CatastropheTriggered event, the audio system plays a sound and the UI shows a banner" |
| Bevy native | `Event` + `EventReader<E>` / `EventWriter<E>` |
| Module path | `bevy::ecs::event::{Event, EventReader, EventWriter}`, derive `Event` |
| Bevy version | 0.18 |
| Minimal example | `#[derive(Event)] struct CatastropheTriggered { id: u64 }`; producer: `mut events: EventWriter<CatastropheTriggered>` then `events.send(...)`; consumer: `mut events: EventReader<CatastropheTriggered>` then `for ev in events.read() { ... }`. |
| Verify | `app.add_event::<CatastropheTriggered>();` is called once. Producer and consumer systems are both registered. Events are cleared after one frame's worth of `read()` calls. |
| When custom is justified | Cross-tick event durability: Bevy events are dropped after two frames. If the consumer might not see them in that window (e.g., the UI panel was disabled), use a Vec-based queue in a Resource. Recommendation: don't fight Bevy here; either always-on consumers, or accept the loss and document it. |

### 4.7 — Per-system state (counter, last-updated time)

| Field | Value |
|---|---|
| Situation | "I want this one system to remember the last tick it ran without exposing the value as a Resource" |
| Bevy native | `Local<T>` parameter |
| Module path | `bevy::ecs::system::Local` |
| Bevy version | 0.18 (stable since pre-0.10) |
| Minimal example | `fn my_system(mut last_tick: Local<u64>, world_view: Res<WorldView>) { let delta = world_view.tick - *last_tick; *last_tick = world_view.tick; /* ... */ }` |
| Verify | `*last_tick` advances on each invocation; not visible from outside. |
| When custom is justified | Never. `Local` is exactly the right tool. If you find yourself reaching for a Resource just to store one system's bookkeeping, switch to `Local`. |

### 4.8 — Reactive system (react to a component changing)

| Field | Value |
|---|---|
| Situation | "When the selected NPC changes, rebuild the inspector panel data" |
| Bevy native | `Changed<T>` query filter |
| Module path | `bevy::ecs::query::Changed` |
| Bevy version | 0.18 |
| Minimal example | `fn rebuild_inspector(changed: Query<&NpcId, Changed<NpcSelection>>) { for id in &changed { /* rebuild */ } }` |
| Verify | Component is updated by some other system; this system fires only on those frames. |
| When custom is justified | When the "change" you care about is in a `Resource`, not a `Component` — use `Res<T>::is_changed()` instead. When the change is in a `Local`, you don't need `Changed`; you just compare values. |

### 4.9 — System sets for ordering

| Field | Value |
|---|---|
| Situation | "I have ten bridge systems and they must all run before the UI panels read state" |
| Bevy native | `#[derive(SystemSet, ...)]` + `.in_set(MySet)` + `.configure_sets(Schedule, MySet.after(OtherSet))` |
| Module path | `bevy::ecs::schedule::SystemSet` |
| Bevy version | 0.18 |
| Minimal example | See the Bevy cheat-book code path: `#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)] struct SimBridgeSet; app.add_systems(Update, (sync_a, sync_b).in_set(SimBridgeSet)); app.configure_sets(Update, SimBridgeSet.after(tick_simulation_systems));` |
| Verify | `cargo test -p anvil_demo` integration test asserts UI sees post-bridge state. |
| When custom is justified | Custom priority-descending stable-sort schedulers (which is what `Runtime::register_system` does for `SimSystem`s) are not Bevy-replaceable — they live in `anvil_runtime`, which is firewalled from Bevy. The two scheduler systems coexist: the `SimSystem` priority scheduler runs inside `tick_simulation_systems`, which is itself in Bevy's `SystemSet`. **Do not** try to express SimSystem priority via Bevy SystemSets; the firewall forbids it. |

### 4.10 — Run conditions (skip a system if a state doesn't hold)

| Field | Value |
|---|---|
| Situation | "Don't run the weather panel if the player is in the main menu" |
| Bevy native | `.run_if(condition)` |
| Module path | `bevy::ecs::schedule::common_conditions` (built-in conditions) + `Condition` trait for custom |
| Bevy version | 0.18 |
| Minimal example | `app.add_systems(Update, render_weather_panel.run_if(in_state(GameState::Playing)).run_if(resource_exists::<WorldView>));` |
| Verify | Disable the resource or state; observe the system stops firing. |
| When custom is justified | Custom run conditions are fine for game-specific predicates (e.g., `run_if(world_view_fresh)`). Don't write a wrapping system that does `if condition { return }` at the top; use `.run_if`. |

### 4.11 — Loading assets (GLTF, textures)

| Field | Value |
|---|---|
| Situation | "I need to load a GLTF model and spawn it" |
| Bevy native | `AssetServer::load` + `Handle<Scene>` + `SceneRoot` component |
| Module path | `bevy::asset::AssetServer`, `bevy::scene::SceneRoot`, `bevy::gltf::GltfAssetLabel` |
| Bevy version | 0.18 |
| Minimal example | `let scene: Handle<Scene> = asset_server.load(GltfAssetLabel::Scene(0).from_asset("models/maren.glb"));` then `commands.spawn(SceneRoot(scene));` |
| Verify | `Res<Assets<Scene>>::contains(&handle)` becomes true; entity appears in world. |
| When custom is justified | Custom asset pipeline that generates assets at build time (e.g., procedural content) — that's `anvil_assets_pipeline`. Runtime loading should use the Bevy asset server. |

### 4.12 — Per-frame timing

| Field | Value |
|---|---|
| Situation | "I need `delta_secs()` for camera smoothing" |
| Bevy native | `Res<Time>` (or `Res<Time<Virtual>>`, or `Res<Time<Fixed>>`) |
| Module path | `bevy::time::Time` |
| Bevy version | 0.18 |
| Minimal example | `fn smooth_camera(time: Res<Time>) { let dt = time.delta_secs(); /* ... */ }` |
| Verify | `dt` matches frame interval (~16ms at 60fps); in `FixedUpdate`, matches the fixed timestep. |
| When custom is justified | Bridge systems need `world_view.tick` (sim time), not Bevy `Time` (real time). Use `Time` for visual smoothing and `world_view.tick` for sim-driven logic. **Never** drive simulation state from `Time` — that breaks determinism. |

### 4.13 — Plugin-style modular registration

| Field | Value |
|---|---|
| Situation | "I want a group of systems + resources + setup all registered with one call" |
| Bevy native | `impl Plugin for MyPlugin { fn build(&self, app: &mut App) { ... } }` |
| Module path | `bevy::app::Plugin` |
| Bevy version | 0.18 |
| Minimal example | `pub struct WeatherUiPlugin; impl Plugin for WeatherUiPlugin { fn build(&self, app: &mut App) { app.init_resource::<WeatherUiConfig>().add_systems(Update, render_weather_panel); } }` |
| Verify | `app.add_plugins(WeatherUiPlugin)` is sufficient registration. Test: remove the line; observe failure. |
| When custom is justified | Never. Empty `Plugin::build()` is a red flag (the audit found `AnvilAssetPlugin::build()` was empty — that's dead code, §7). |

---

## Section 5: The "Work With Bevy, Not Next To It" Pattern Catalog

Each pattern names the underlying Bevy design principle, shows a "before" extracted from the audit, and the "after" that aligns with Bevy. Code blocks are illustrative — pseudocode where exact APIs aren't loaded into context.

### P-RESULT-PROPAGATION (Replace panics with `Result` propagation)

**Bevy principle:** Bevy systems can return `Result<(), BevyError>`; failures route through Bevy's error handler. (Pre-0.18 systems returned `()`; the adapter pattern from the Doctrine §3.4 wraps a `Result`-returning function into a closure system.)

**Before** (from the audit — `actions/catalogue.rs`):
```rust
pub fn actions() -> &'static [Action] {
    ACTIONS_CACHE.get().expect("Failed to load actions catalogue")
}
```

**After**:
```rust
pub fn actions() -> Result<&'static [Action], SimError> {
    let cached = ACTIONS_CACHE.get_or_init(|| {
        load_actions_from_disk().map_err(|cause| SimError::CatalogueUnavailable {
            resource: "actions.json",
            cause,
        })
    });
    cached.as_ref().map(|v| v.as_slice()).map_err(SimError::clone)
}
```

**Concrete benefit:** A startup with a missing/corrupt actions.json fails gracefully via the Doctrine's Pause tier rather than crashing the binary. The error carries structured payload that a future telemetry system can categorise without parsing strings. `OnceLock` semantics ensure one filesystem read per process.

### P-OPTION-FAIL-FAST (Bevy `Query` and `Option` without `unwrap`)

**Bevy principle:** `Query::single()` returns `Result<&T, QuerySingleError>`. `Option<Res<T>>` lets a system run without crashing when a resource is missing.

**Before** (synthesised from audit findings on `update_atmosphere`):
```rust
fn render_weather_panel(runtime: Res<RuntimeResource>) {
    let weather = &runtime.runtime.weather;
    let phase = format!("{:?}", weather.current_weather);   // panics if not Pretty
    ui.label(phase);
}
```

**After**:
```rust
fn render_weather_panel(world_view: Option<Res<WorldView>>) -> Result<(), UiError> {
    let Some(world_view) = world_view else {
        return Err(UiError::ResourceMissing { resource: UiResourceKind::WorldView });
    };
    ui.label(world_view.weather.value.phase_label);   // &'static str, no panic
    Ok(())
}
```

**Concrete benefit:** The panel renders a placeholder when the WorldView isn't yet populated (first frame after load); after WorldView populates, the panel reads a pre-translated label that never panics regardless of the underlying sim enum's `Debug` impl.

### P-CTX-RNG (Single deterministic RNG source)

**Bevy principle:** Bevy is irrelevant here — this is pure sim discipline. Stated for completeness because the audit found the violation alongside Bevy-side code.

**Before** (from audit — `apply_earthquake`):
```rust
fn apply_earthquake(&mut self, epicenter: Vec3, radius: f32) {
    for (handle, body) in self.rigid_body_set.iter_mut() {
        let seed = (handle.into_raw_parts().0 as u64) << 32 | (handle.into_raw_parts().1 as u64);
        let mut rng = LCG { state: seed };
        let magnitude = rng.next_f32() * 7.0 + 2.0;
        // ...
    }
}
```

**After**:
```rust
fn apply_earthquake(&mut self, epicenter: Vec3, radius: f32, rng: &mut DeterministicRng) {
    let magnitude = rng.next_f32_range(2.0, 9.0);
    for (handle, body) in self.rigid_body_set.iter_mut() {
        // Apply uniform magnitude scaled by distance; no per-body RNG
    }
}
```

**Concrete benefit:** Cross-machine reproducibility. `RigidBodyHandle::into_raw_parts()` returns Rapier-internal slab indices that depend on allocator behaviour and Rapier version. A `DeterministicRng` advanced through `ctx.rng` produces identical sequences regardless of host.

### P-BTREEMAP (Deterministic iteration in sim state)

**Bevy principle:** Bevy itself uses `HashMap` extensively for its own state (component storage, asset slots). The sim crates are firewalled from Bevy; the constraint is that **sim state must serialise deterministically**.

**Before** (from audit — `RegionColliderMap`):
```rust
pub type RegionColliderMap = std::collections::HashMap<u64, Vec<ColliderHandle>>;
```

**After**:
```rust
pub type RegionColliderMap = std::collections::BTreeMap<u64, Vec<ColliderHandle>>;
```

**Concrete benefit:** Bincode-serialised output is byte-identical across processes. Any iteration over `RegionColliderMap` produces keys in sorted order, eliminating the iteration-order class of determinism failures.

### P-TO-BITS (Hash floats by bit pattern)

**Bevy principle:** Bevy stores floats as raw `f32` everywhere; comparing for equality or hashing needs explicit bit-level discipline.

**Before**:
```rust
fn state_hash(&self) -> u64 {
    let mut hasher = DefaultHasher::new();
    self.position.x.hash(&mut hasher);   // f32 doesn't implement Hash; this won't compile
    // ...
}
```

**After** (as documented in `ANVIL_DETERMINISM.md` §"State Hashing"):
```rust
fn state_hash(&self) -> u64 {
    let mut hasher = DefaultHasher::new();
    self.position.x.to_bits().hash(&mut hasher);
    self.position.y.to_bits().hash(&mut hasher);
    self.position.z.to_bits().hash(&mut hasher);
    hasher.finish()
}
```

**Concrete benefit:** A `NaN` or subnormal value hashes consistently (every `NaN` bit pattern hashes to itself; PartialEq considers them unequal, so naïve hashing is broken).

### P-TYPED-ERROR (Structured error variants)

**Bevy principle:** Bevy itself uses `BevyError` (since 0.16) with a structured payload. Aligning your error types with this idiom makes Bevy interop straightforward.

**Before** (from audit — `RuntimeError::General`):
```rust
pub enum RuntimeError {
    General(String),
    InvalidSaveFile(u64),
    // ...
}
```

**After** (per Doctrine §1.3):
```rust
#[non_exhaustive]
pub enum RuntimeError {
    SystemErrored { source: SimError },
    WorldHashMismatch { save_hash: [u8; 32], world_hash: [u8; 32] },
    UnsupportedSaveFormat { save_version: u32, minimum_supported: u32, maximum_supported: u32 },
    // ...
}
```

**Concrete benefit:** A telemetry pipeline can categorise errors by variant without parsing strings. Tests can match on specific variants without false positives from changed string text. The `#[non_exhaustive]` allows future variant addition without breaking downstream `match`es.

### P-LAYER-WRAP (Translate at the boundary, never skip)

**Bevy principle:** Bevy's `BevyError` is `From<Box<dyn Error>>` — it wraps, doesn't replace. Your error chain does the same.

**Before**:
```rust
fn ui_load_save(path: &Path) -> Result<(), UiError> {
    let bytes = std::fs::read(path).map_err(|e| UiError::Internal(format!("{e}")))?;
    let save: SaveFile = serde_json::from_slice(&bytes).map_err(|e| UiError::Internal(format!("{e}")))?;
    let runtime = Runtime::restore_with_world(&save, world).map_err(|e| UiError::Internal(format!("{e}")))?;
    Ok(())
}
```

**After**:
```rust
fn ui_load_save(path: &Path) -> Result<(), UiError> {
    let bytes = std::fs::read(path).map_err(|cause| UiError::AssetLoadFailed {
        archetype: ArchetypeId::for_save_file(path),
        path_hash: hash_path(path),
        cause: AssetFailureKind::FileNotFound,
    })?;
    let save: SaveFile = parse_and_upgrade_save(&bytes)?;     // RuntimeError → UiError::BridgeErrored
    let runtime = Runtime::restore_with_world(&save, world)?; // RuntimeError → UiError::BridgeErrored
    Ok(())
}
```

**Concrete benefit:** The error reaching UI carries the full chain (`UiError::BridgeErrored { source: BridgeError::RuntimeErrored { source: RuntimeError::WorldHashMismatch { .. } } }`). A handler can match on the root cause without losing the abstraction at each layer.

### P-WORLDVIEW-READ (Bridge-injected state, not direct sim reads)

**Bevy principle:** Bevy systems read `Res<T>`, where `T` is the canonical Bevy resource. Our `WorldView` is a `Resource`; reading it is the most-idiomatic Bevy pattern.

**Before** (from audit — atmosphere driver):
```rust
fn update_atmosphere(runtime: Res<RuntimeResource>, mut suns: Query<&mut DirectionalLight>) {
    let weather = &runtime.runtime.weather;
    let day_phase = runtime.runtime.time.day_phase();
    for mut sun in &mut suns {
        sun.color = compute_color(weather, day_phase);
    }
}
```

**After** (per WorldView Spec §4.5):
```rust
fn environment_apply_system(
    state: Res<EnvironmentState>,
    mut suns: Query<(&mut DirectionalLight, &mut Transform), With<SunLight>>,
) -> Result<(), UiError> {
    let Ok((mut sun, mut sun_tf)) = suns.single_mut() else {
        return Err(UiError::ResourceMissing { resource: UiResourceKind::EnvironmentState });
    };
    sun.color = state.current_sun_color;
    sun.illuminance = state.current_sun_illuminance;
    sun_tf.rotation = Quat::from_rotation_x(-state.current_sun_pitch_rad);
    Ok(())
}
```

**Concrete benefit:** The visual system has no compile-time dependency on `anvil_runtime` or `anvil_sim`. Replacing the simulation with a recording for replay testing is a one-line change (swap which system populates `EnvironmentState`).

### P-RUNTIME-COMMAND (Bridge-mediated writes, not direct sim mutation)

**Bevy principle:** Bevy systems issue `Commands` to mutate the World; the mutation is applied at a sync point, not during the system body. Our `RuntimeCommand` is the same pattern, scoped to the sim crate.

**Before** (from audit — `idle.rs::ensure_viewer_npc_exists`):
```rust
fn ensure_viewer_npc_exists(runtime: Option<&mut RuntimeResource>, /* ... */) {
    if let Some(runtime) = runtime {
        for system in &mut runtime.runtime.systems {
            if let Some(npc_system) = system.as_any_mut().downcast_mut::<anvil_sim::NpcSystem>() {
                let family = anvil_sim::settlement::Family::new(/* ... */);
                npc_system.add_family(family);
                let person = anvil_sim::settlement::Person::new_simple(/* ... */);
                npc_system.add_person(person);
                return;
            }
        }
    }
}
```

**After** (per WorldView Spec §5.2):
```rust
fn ensure_viewer_npc_exists(mut ui_commands: EventWriter<UiCommand>) {
    ui_commands.send(UiCommand::SpawnViewer {
        person_id: NonZeroU64::new(VIEWER_PERSON_ID).expect("9 is nonzero"), // PANIC-OK: constant
        family_id: NonZeroU64::new(9).expect("9 is nonzero"),
        name: "Viewer".to_string(),
        substrate: SubstrateInit::neutral(),
        initial_position: Vec3::ZERO,
    });
}
```

**Concrete benefit:** The Visual layer has no `anvil_sim` import. The mutation is applied through `Runtime::apply(&RuntimeCommand::SpawnViewerNpc { .. })`, which goes through the same validation as every other state change and triggers `RuntimeEvent::NpcSpawned`, which the bridge can observe.

### P-BINCODE (Float-exact snapshot format)

**Bevy principle:** Bevy's own snapshot/reflection system uses configurable serializers (RON, JSON); for byte-exact reproducibility, bincode is the canonical choice.

**Before** (from audit — JoySystem, NpcSystem, CatastropheSystem):
```rust
fn snapshot(&self) -> Vec<u8> {
    serde_json::to_vec(self).expect("snapshot failed")
}
```

**After** (per Simulation Core Reliability §A5.1):
```rust
fn snapshot(&self) -> Result<Vec<u8>, SimError> {
    validate_no_nan(self)?;
    bincode::serde::encode_to_vec(self, bincode_config())
        .map_err(|_| SimError::InvalidSnapshot {
            system: SystemName(self.name()),
            kind: SnapshotFailureKind::EncodingMismatch,
        })
}
```

**Concrete benefit:** Floats survive round-trip byte-for-byte. NaN encodes (where serde_json can't). The output is denser, making save files smaller and `state_hash` cheaper to compute.

### P-EVENT-DRIVEN (Bevy Events for cross-system reactions)

**Bevy principle:** Use `Event` + `EventReader` instead of polling resources for state changes.

**Before**:
```rust
fn ui_react_to_catastrophe(world_view: Res<WorldView>, mut last_count: Local<usize>) {
    let active = world_view.catastrophes.iter().filter(|c| c.is_active).count();
    if active > *last_count {
        play_alarm_sound();
    }
    *last_count = active;
}
```

**After**:
```rust
#[derive(Event)]
pub struct CatastropheTriggered { pub id: u64, pub kind: CatastropheKindView }

// Bridge writer (in sim_bridge):
fn sync_catastrophes_events(
    world_view: Res<WorldView>,
    mut events: EventWriter<CatastropheTriggered>,
    mut last_seen: Local<BTreeSet<u64>>,
) {
    let current: BTreeSet<u64> = world_view.catastrophes.iter().map(|c| c.id).collect();
    for id in current.difference(&*last_seen) {
        events.send(CatastropheTriggered { id: *id, /* ... */ });
    }
    *last_seen = current;
}

// Consumer:
fn react_to_catastrophe(mut events: EventReader<CatastropheTriggered>) {
    for ev in events.read() {
        play_alarm_sound();
    }
}
```

**Concrete benefit:** The consumer doesn't poll. Multiple consumers (UI banner, audio, screen-shake) can subscribe without each reimplementing the diff logic. The diff logic lives in one place, in the bridge.

---

## Section 6: Anti-Pattern Catalog

Concrete shapes the dev recognises as wrong on sight. Each anti-pattern names the symptom, the underlying mistake, and the §5 pattern that replaces it.

### A1: Untargeted `Query<&mut T>` when multiple instances exist

**Symptom:** `Query<&mut DirectionalLight>` without a `With<Marker>` filter, when the scene contains both a sun and a moon directional light.

**Why wrong:** The system silently writes to every directional light, including ones the system has no business touching. The audit found `update_atmosphere` doing exactly this.

**Replacement:** §4.2 (marker components) + the `With<>` filter. Pattern P-OPTION-FAIL-FAST handles the singleton case.

### A2: Polling `Res<X>` to detect change

**Symptom:** A system reads a `Res<X>` and stores the previous value in `Local<X>` to detect changes.

**Why wrong:** Bevy provides `Res<X>::is_changed()` and `Changed<C>` query filters; the polling pattern reimplements them. For state changes that other systems need to react to, polling can also miss events that happen and revert within one frame.

**Replacement:** §4.6 (Events) for cross-system signals; §4.8 (`Changed<T>`) for components; `is_changed()` for resources.

### A3: Storing simulation state in a Bevy `Resource`

**Symptom:** `#[derive(Resource)] struct PersonState { hunger: f32, position: Vec3 }` in `anvil_bevy`.

**Why wrong:** Simulation state lives in `anvil_sim`, behind the firewall. A Bevy Resource holding sim state means Bevy is the authority — and Bevy is non-deterministic. The audit found this anti-pattern in `RegionStates` (which mirrored simulation state via hardcoded strings rather than via the bridge).

**Replacement:** §5.8 (P-WORLDVIEW-READ): sim state lives in `Runtime`; the bridge extracts a view into a `Resource` named `WorldView`; UI reads `Res<WorldView>`. The Resource holds the **view**, not the state.

### A4: `as_any().downcast_ref()` in a visual system

**Symptom:** `for system in &runtime.runtime.systems { if let Some(s) = system.as_any().downcast_ref::<NpcSystem>() { ... } }` in `anvil_demo`.

**Why wrong:** Visual systems crossing into sim internals by name. The audit found four occurrences. Each one represents missing surface area on `WorldView`.

**Replacement:** Extend `WorldView` with the field the downcast was reading; populate it from the bridge writer. Pattern P-WORLDVIEW-READ.

### A5: Hardcoded data masquerading as bridge-extracted

**Symptom:** A bridge writer that ignores `Res<RuntimeResource>` and populates the target Resource with literal values (the audit found this in `sync_regions`).

**Why wrong:** The UI displays values that have no relation to the simulation. The dev (or a player) sees a region's food at "65%" when the actual settlement food is 30%, and there is no way to detect the discrepancy by inspection.

**Replacement:** Read from `runtime.runtime.world.regions` and `runtime.runtime.npc_system().settlements`, joined by region id. Use the existing audit pattern for spotting hardcoded strings: `rg '"\\w+_\\w+"' crates/anvil_demo/src/sim_bridge/` and review every match.

### A6: Empty `Plugin::build()`

**Symptom:** `impl Plugin for FooPlugin { fn build(&self, _app: &mut App) {} }`.

**Why wrong:** A plugin is the registration mechanism. An empty `build` means the plugin does nothing; registering it is dead-code-shaped (see §7). The audit found `AnvilAssetPlugin::build()` empty.

**Replacement:** Delete the plugin and its `add_plugins` call. If the plugin is a placeholder for future work, mark with `// PLACEHOLDER FROM ...` per Commandment 6 and add a `PLACEHOLDER_DEBT.md` entry.

### A7: `serde_json` for system snapshots

**Symptom:** `bincode::serde::encode_to_vec(self, /* config */)` in `PhysicsSystem` but `serde_json::to_vec(self)` in three other systems.

**Why wrong:** Float exactness is lost on the JSON systems (precision varies at extreme values), NaN cannot be encoded, and the `state_hash` becomes serializer-dependent.

**Replacement:** P-BINCODE. All `SimSystem::snapshot()` use bincode.

### A8: Local LCG for "fast" RNG

**Symptom:** `struct LCG { state: u64 }` next to a `DeterministicRng` that is already available via `ctx.rng`.

**Why wrong:** Two RNG streams, one isolated from the canonical seed tree. Any code change that reads `ctx.rng` upstream shifts the seed of the LCG indirectly via timing, breaking replay. Even if it doesn't, the two streams must both be serialised to maintain bit-identical replay, and the audit confirmed the LCG was not in the snapshot.

**Replacement:** P-CTX-RNG. Delete the LCG. Thread `&mut DeterministicRng` through the function signature.

### A9: `String` payload inside an error variant

**Symptom:** `pub enum SimError { Internal(String), /* ... */ }`.

**Why wrong:** Type-level matching fails (you'd have to substring-match). Telemetry can't aggregate by failure mode. Tests assert on text and break when wording changes.

**Replacement:** P-TYPED-ERROR. Each variant carries structured fields (`SystemName`, `SnapshotFailureKind`, `[u8; 32]`, etc.).

### A10: Reading `runtime.weather.X` from a UI panel

**Symptom:** `let weather = &runtime.runtime.weather; ui.label(format!("{:.1}°C", weather.temperature));` in a panel system.

**Why wrong:** The panel has a direct dependency on `anvil_runtime::weather::WeatherSimulation` field layout. Adding `Debug`-fed formatting (`format!("{:?}", weather.current_weather)`) puts the enum's debug representation into the UI string — meaning a field rename or variant rename appears in the user interface.

**Replacement:** P-WORLDVIEW-READ. The panel reads `Res<WorldView>` and uses pre-translated `&'static str` labels.

---

## Section 7: The Dead Code Archaeology Protocol

When §1 returns "not imported" or "not reachable", the file is a candidate for deletion. The protocol below determines whether to delete, archive, or refactor.

### 7.1 — The Five Questions

**Q1: Is the symbol referenced anywhere?**

```bash
# For a file foo.rs, extract its public items, then check each
FILE="crates/anvil_demo/src/foo.rs"
SYMS=$(rg --type rust '^pub\s+(fn|struct|enum|trait|const|static|type|mod)\s+(\w+)' \
       "$FILE" -o -r '$2' | sort -u)
for sym in $SYMS; do
    refs=$(rg --type rust --files-with-matches "\b${sym}\b" crates/ --glob "!$FILE" | wc -l)
    printf "%-30s %d files\n" "$sym" "$refs"
done
```

Zero references = candidate for deletion.

**Q2: Is the file declared as a module?**

```bash
F=$(basename "$FILE" .rs)
rg --type rust "^\s*(pub\s+)?mod\s+${F}(;|\s*\{)" crates/
```

If no `mod foo;` declares the file, Cargo does not compile it. Cargo's behaviour is unchanged if the file is deleted.

**Q3: When was it introduced and when was it last touched?**

```bash
git log --follow --format='%h %ad %an %s' --date=short -- "$FILE"
```

A file with one introducing commit and no subsequent touches is a strong deletion candidate. A file with two commits where the second is "remove from registration" but the file was not deleted is a cleanup miss.

**Q4: Does it have a `// PLACEHOLDER FROM <crate>` header?**

```bash
head -3 "$FILE" | grep -i "PLACEHOLDER FROM"
```

If yes, check `PLACEHOLDER_DEBT.md`:

```bash
grep -A5 "$(basename "$FILE")" PLACEHOLDER_DEBT.md
```

If the review date has passed (current date > scheduled review), `scripts/check_placeholder_debt.sh` should already be failing. The placeholder review must be queued before any further action — it's a sprint-start blocker per Commandment 6.

**Q5: Does deletion break the build?**

```bash
git mv "$FILE" "/tmp/$(basename "$FILE").bak"
cargo check --workspace --all-targets 2>&1 | tee /tmp/check.log
```

If `cargo check` passes, the file is dead. Move it back temporarily, record the finding, then delete in a single commit.

### 7.2 — The Decision Matrix

| Q1 | Q2 | Q3 | Q4 | Q5 | Action |
|---|---|---|---|---|---|
| zero refs | no `mod` | introduced once, never touched | not a placeholder | check passes | **Delete.** Single commit with reason in body. |
| zero refs | has `mod` (private) | doesn't matter | not a placeholder | check passes | **Delete file + module declaration.** Single commit. |
| zero refs | no `mod` | recent (< 2 weeks) | not a placeholder | check passes | **Hold for one sprint** before deletion. Author intent may not be in the commit message yet. |
| zero refs | doesn't matter | doesn't matter | **is a placeholder, review overdue** | doesn't matter | **Placeholder review first.** Sprint blocker; do not delete or refactor. |
| zero refs | doesn't matter | doesn't matter | **is a placeholder, review current** | doesn't matter | **Skip.** Wait for review trigger. |
| some refs | has `mod` | doesn't matter | doesn't matter | doesn't matter | **Not dead.** Return to §1. |

### 7.3 — Case Studies

#### Case A: `build.rs`

```bash
$ cat build.rs
fn main() {}
$ grep "build = " Cargo.toml */Cargo.toml
$ git log --follow -- build.rs
abc1234 2024-08-14 dev "scaffold for future codegen"
$ rm build.rs && cargo check --workspace
   Compiling ... (everything succeeds)
```

Protocol verdict:
- Q1: no symbols to reference.
- Q2: not a module; it's a Cargo convention.
- Q3: introduced once, never touched.
- Q4: not a placeholder.
- Q5: build passes without it.

**Delete.** Commit: `chore: remove empty build.rs (no codegen ever materialised; see DECISIONS.md)`.

#### Case B: `sky.rs` (audit batch 9)

```bash
$ rg "mod sky" crates/anvil_demo/src/world/
crates/anvil_demo/src/world/mod.rs:mod sky;
$ rg "use .*sky::" crates/anvil_demo/src/
# (no results — module is declared but unused)
$ head -3 crates/anvil_demo/src/world/sky.rs
//! Procedural sky gradient rendering.
//! Sun disk glow ... — see atmosphere.rs.
$ git log --follow -- crates/anvil_demo/src/world/sky.rs
def5678 2024-10-22 dev "Phase 6 sky placeholder for per-vertex shader work"
```

Protocol verdict:
- Q1: public symbols `SKY_RADIUS`, `SkyMarker`, `setup_sky` — zero references outside the file.
- Q2: declared as `mod sky;` but `pub use sky::*;` is **deliberately omitted** per audit batch 9 (comment in `world/mod.rs`).
- Q3: introduced once, never touched.
- Q4: comment marks it as future-work intent, not a port placeholder.
- Q5: `cargo check` passes without it.

**Verdict:** complex. The file is dead code today but its comment claims future use. Two paths:

(a) Delete now; reintroduce when actually needed. The git history preserves the reference.
(b) Keep, but add to a "future work" registry document so the intent is greppable.

**Recommendation:** delete. Future work that isn't done is indistinguishable from dead code; the commit history is the future-work registry.

#### Case C: `update_settlement_visuals` (audit batch 8)

```bash
$ grep -B1 "fn update_settlement_visuals" crates/anvil_demo/src/world/settlement.rs
#[allow(dead_code)]
pub fn update_settlement_visuals(
$ rg "update_settlement_visuals" crates/
crates/anvil_demo/src/world/settlement.rs:#[allow(dead_code)]
crates/anvil_demo/src/world/settlement.rs:pub fn update_settlement_visuals(
# Only declaration site
$ rg "add_systems.*update_settlement" crates/
# (no results — never registered)
```

Protocol verdict:
- Q1: zero references.
- Q2: in a registered module (`pub mod settlement;`), but the function itself is never used.
- Q3: check `git log` for context.
- Q4: not a placeholder header.
- Q5: deletion is the function only, not the whole module.

**Delete the function**, keep the module (the sibling `spawn_settlement_visuals` may still be used). The `#[allow(dead_code)]` annotation is the explicit acknowledgement that the function was dead at write time; the annotation doesn't expire on its own.

#### Case D: `AnvilAssetPlugin::build()` (audit batch reference)

```rust
impl Plugin for AnvilAssetPlugin {
    fn build(&self, _app: &mut App) {}
}
```

Protocol verdict:
- Q1: `AnvilAssetPlugin` is referenced if anyone calls `app.add_plugins(AnvilAssetPlugin)`. Check: `rg "AnvilAssetPlugin"`.
- Q2: it's a struct, not a file module.
- Q3: check history.
- Q4: possibly a port placeholder; check header.
- Q5: deletion of the plugin + all `add_plugins` calls of it.

**Verdict:** if no `add_plugins(AnvilAssetPlugin)` exists, delete the type. If callers exist, this is anti-pattern A6 (§6) — the empty `build` is the bug, not the type. Either:
- Add the actual asset registration logic, or
- Delete the type and the `add_plugins` call simultaneously.

### 7.4 — The Anti-Drift Habit

Once per month, run:

```bash
# Files marked dead-code-tolerant
rg "#\[allow\(dead_code\)\]" crates/ | wc -l

# Empty plugin builds
rg -A2 "fn build\(&self, .*app:" crates/ | rg "^\s*\}\s*$" -B1

# Unused public items (requires cargo-machete: cargo install cargo-machete)
cargo machete    # REQUIRES INSTALLATION: cargo install cargo-machete
```

A growing count of `#[allow(dead_code)]` is a leading indicator of drift. The monthly check is a 5-minute review of what's been added and whether it should still be there.

---

## Section 8: The Symptom-to-Cause Diagnostic Protocol

When something breaks — a test fails, a UI renders wrong, the sim diverges, the build slows — the layer that produced the symptom is rarely the layer to fix. This decision tree localises the cause.

### 8.1 — The Triage Question

Before investigating, classify the symptom along two axes:

| Axis | Values |
|---|---|
| **Determinism axis** | Reproducible (same seed → same break) / Non-reproducible (different runs → different breaks) |
| **Layer axis** | Sim (state_hash diverges, NPC behaviour wrong) / Bridge (WorldView fields stale) / Visual (rendering wrong, UI wrong) / Cross-cutting (build, lint, performance) |

Four-by-four matrix; each cell has a different first investigation step.

### 8.2 — The Diagnostic Tree

**Symptom: `state_hash` differs between two runs from the same seed**

1. Was the run-pair on the same machine? If not, this is the cross-platform determinism question — check `ANVIL_DETERMINISM.md` §"Systems with Known Platform Dependencies". Physics is the only known platform-dependent system. If the test is non-physics and platforms differ, **it's a new bug**.
2. Was there a `cargo update` between the runs? If yes, run `cargo update --dry-run` to see what changed. Pin the prior versions in `Cargo.lock` and rerun. If the bug disappears, the divergence is in a dependency.
3. Run the determinism test with `RUST_LOG=trace` and bisect by tick: find the first tick at which the hash diverges.
4. At the divergent tick, dump each system's snapshot bytes and diff: `cargo test ... -- --nocapture 2>&1 | grep "snapshot:"`. The system whose bytes changed is the cause.
5. In that system, the candidates are: P-CTX-RNG violations (anti-pattern A8), P-BTREEMAP violations (HashMap iteration order), P-TO-BITS violations (float hashing). Run the §2 detection commands scoped to that one system.

**Symptom: UI shows wrong data**

1. Is the data in `WorldView`? If no, the field needs to be added (WorldView Spec §3). If yes, continue.
2. Is the data being populated by the bridge writer? `rg "world_view.weather.X" crates/anvil_demo/src/sim_bridge/`. If the field is read by UI but no writer mentions it, it's stale at default (anti-pattern: the bridge has a gap).
3. Is the data being read correctly by the UI? Add a transient `info!("weather: {:?}", world_view.weather.value)` in the UI system; observe values in logs.
4. If logs show correct values but UI shows wrong: the rendering code has a bug (mis-format, wrong color mapping). Not a bridge issue.
5. If logs show wrong values: the bridge writer is the bug. Add `info!` in the writer; trace back to the simulation source.

**Symptom: Save load fails after sprint update**

1. Was `SAVE_FORMAT_VERSION` bumped this sprint?
2. If yes: was a migration step added? `rg "upgrade_to_v[0-9]+" crates/anvil_runtime/src/snapshot/migration.rs`. If the new version number doesn't have an `upgrade_to_v<N>` function, the migration is missing.
3. If no: a snapshot format changed without the version bump. This is a contract violation. Identify which `SimSystem`'s snapshot bytes changed (check `git log -p crates/anvil_sim/src/system/`) and decide: rollback the change, or do the proper migration.
4. In either case, the v6 / v7 / v8 fixtures in `crates/anvil_runtime/tests/save_*.json` should still load. If they don't, migration is broken.

**Symptom: `cargo clippy` fails with `unwrap_used` violation**

1. The lint location is the symptom. The cause is one of three (per the Doctrine §2.3):
    - The function lacks proper `Result` plumbing → P-RESULT-PROPAGATION.
    - The Bevy `Query::single()` is being unwrapped → P-OPTION-FAIL-FAST.
    - It's a genuine invariant (compile-time-known constant, post-validation invariant) → add `// SAFETY: <proof>` + `#[allow(clippy::unwrap_used)]`.
2. The decision is purely: do you have a proof? Write the proof in the comment. If you can't, you don't have an invariant; you have a panic. Fix per (1) or (2).

**Symptom: A file is over 500 lines**

1. Identify the logical seam: what two things does this file do?
2. Split along that seam. Use `git mv` to preserve history for the larger half; copy the smaller half to a new file.
3. Update `mod.rs` in the parent directory.
4. Run `cargo check --workspace` to confirm.
5. Run `bash scripts/check_size.sh` to confirm both new files are under budget.

If the file is over 500 lines and has no clear logical seam, the type itself is too big. Split the type. This is rare; the audit didn't find a case.

**Symptom: A function is over 50 lines**

1. The clippy `too_many_lines` lint already caught it. Identify the inner loop body or the per-element computation.
2. Extract a helper function whose signature is the inner operation. Inner closures are often the natural extraction site.
3. Re-run clippy.

If a function is structurally one logical step but happens to be > 50 lines (a long match arm with simple bodies, e.g.), the threshold may be relaxed *per-function* with `#[allow(clippy::too_many_lines)]` and a `// SAFETY: <reason>` comment per Commandment 3's general discipline. This carve-out should be exceedingly rare. The audit found no cases that needed it.

**Symptom: `cargo check` takes more than 90 seconds on a warm cache**

1. Is one crate dominating compile time? `cargo build --workspace --timings` then open `target/cargo-timings/cargo-timing.html`.
2. Has a crate crossed the 5000-line crate budget? Count: `find crates/<name>/src -name '*.rs' -exec wc -l {} \; | awk '{s+=$1} END{print s}'`. If yes, split.
3. Is a new dependency the cause? `cargo tree -p <crate> --duplicates`. Deduplicate where possible.
4. Has `bevy` been depended on by a deterministic crate? Run `bash scripts/check_firewall.sh`. If it returns nonzero, the firewall is breached.

---

## Section 9: The Rollback Protocol

When a refactor goes wrong mid-stream, recovery procedure matters. The protocol below uses Git primitives only; no special tooling required.

### 9.1 — Pre-Refactor Safety Net

Before starting any refactor:

```bash
# 1. Verify clean working tree
git status   # must show "nothing to commit, working tree clean"

# 2. Note the current HEAD
git rev-parse HEAD > /tmp/refactor-rollback.txt
echo "Starting refactor of: <description>" >> /tmp/refactor-rollback.txt

# 3. Run the baseline tests; record they pass
cargo test --workspace 2>&1 | tail -5 | tee -a /tmp/refactor-rollback.txt

# 4. Note the determinism hash (if relevant)
cargo test -p anvil_sim --test phase3_determinism 2>&1 \
    | grep -oE 'hash: [0-9a-f]+' | head -1 \
    | tee -a /tmp/refactor-rollback.txt

# 5. Create a branch (optional but recommended for non-trivial refactors)
git switch -c refactor/<short-name>
```

### 9.2 — Mid-Refactor Recovery

If, during the refactor:

**Build is broken and you don't see a path forward in <30 minutes**

```bash
git stash push -m "wip: refactor of <name>, broken at $(date -Iminutes)"
# Examine the stash later with: git stash show -p
git switch main   # or wherever you started
```

The stash is a snapshot; nothing is lost. You can resume later or, after consideration, `git stash drop` the stash if the approach is wrong.

**Build is broken and you want to roll back completely**

```bash
git restore --staged --worktree .
git clean -fd   # WARNING: deletes untracked files
# Working tree is now exactly at HEAD
```

**A commit was made that broke determinism, and you only noticed several commits later**

```bash
# Find the breaking commit
git bisect start
git bisect bad HEAD
git bisect good $(cat /tmp/refactor-rollback.txt | head -1)
# git will checkout intermediate commits; at each:
cargo test -p anvil_sim --test phase3_determinism
git bisect good   # or: git bisect bad
# Continue until git identifies the breaking commit
git bisect reset
```

Once identified, the breaking commit is either:
- Reverted: `git revert <hash>` — preserves history, makes a new commit undoing the change.
- Rebased away (if not yet pushed): `git rebase -i <parent-of-bad>` and drop the commit.

### 9.3 — The Atomic Refactor Contract

Each refactor produces:

1. A test-prep commit, if the refactor changes behaviour and the existing tests don't fully cover the changed code path. The commit ships a failing test (or a test that passes against the unrefactored code).
2. A refactor commit. Single concern, single area of the codebase, one ≤ 500-line file modified or split.
3. A docs commit, if `DECISIONS.md` needs an entry (see §12).

The three commits land in `main` in this order. If a commit needs amending, use `git commit --amend` (before push) or `git revert` (after push).

### 9.4 — The `git reflog` Safety Net

If you destroy work with a misuse of `git reset --hard` or similar:

```bash
git reflog              # shows every HEAD movement, including destroyed commits
git checkout <hash>     # detached HEAD at the rescued state
git switch -c rescue/<name>   # save it to a branch
```

The reflog persists for 90 days by default. **You can recover almost any committed work** — even after `reset --hard`. The exception is uncommitted changes overwritten by `git restore` or `git clean`. Stash before destructive operations.

---

## Section 10: Escalation Criteria — When to Queue an Opus Session

Opus is a limited resource. Use it for problems whose cost-of-being-wrong exceeds the cost-of-thirty-minutes-of-Claude-time. Use this manual + Sonnet for everything else.

### 10.1 — Mandatory Escalation Triggers

Stop and queue Opus if **any** of the following is true:

| Trigger | Why Opus |
|---|---|
| The refactor would change a binding constraint (modify `ANVIL_PHILOSOPHY.md` or `ANVIL_DETERMINISM.md`). | Constitutional amendment per Philosophy §"Amendment Process"; mandatory wait + self-review. |
| The refactor would invalidate ≥ 3 existing determinism tests. | The tests are the project's only insurance against silent state-hash drift; their replacement requires Day-3-class analysis. |
| The refactor crosses ≥ 4 binding constraints simultaneously (e.g., touches state_hash, error types, save format, and file size). | Each constraint imposes a sequencing rule; their composition is non-trivial and merits the higher-quality reasoning. |
| You're proposing a new variant in any error enum, AND that variant's payload includes a sim-crate type. | Doctrine §1.1's structural rule against sim types in non-sim layers must be checked against the propagation chain. |
| You're proposing a new `SimSystem` (not refactoring an existing one). | New systems require a priority assignment, a snapshot format, a determinism test, and updates to `register_canonical_systems`. The integration is broad enough that one missed step is hard to catch in CI. |
| The refactor touches the save format (`SAVE_FORMAT_VERSION` bump). | Migration logic must round-trip; old fixtures must continue to load; new fixtures must be added. The whole-system view matters. |
| The refactor would split a crate (one `crates/` directory becomes two). | Workspace-level change; affects `Cargo.toml`, lockfile, and every dependent crate's `Cargo.toml`. |
| You're stuck for more than 2 hours on what looked like a 1-hour task. | The thing you thought you understood, you don't. Step back, queue Opus for a re-scoping session, in the meantime work on the lowest-risk shelf-ready refactor. |

### 10.2 — Soft Escalation Indicators

These mean "Opus would help" but aren't mandatory:

- The refactor would touch ≥ 8 files in a single concern.
- A determinism test fails after a refactor that doesn't obviously touch determinism — the surprise itself is a signal.
- The dev has revised the plan three times in one session — context isn't holding.
- A grep returns substantially more matches than expected (you thought 3 sites; it's 47).

### 10.3 — The "Save-State" Practice for Opus Sessions

When queueing Opus, write a single markdown file `notes/opus-queue/<date>-<topic>.md` containing:

```markdown
# Opus Session Queue: <topic>

## Current state
<one paragraph describing where the codebase is>

## What I tried
<bulleted list of attempts and what they showed>

## What I think is wrong
<the dev's current hypothesis>

## What I'd like Opus to do
<specific question, not "fix it">

## Files relevant
<list of file paths, ≤ 10>
```

This lets Opus start from a hot context rather than rebuilding it from scratch. The format also forces the dev to articulate the question before the session — half the time, writing the question reveals the answer.

---

## Section 11: The Verification Checklist

After completing a refactor, **every** item below must pass before the refactor commits land in `main`. Skipping items is the failure mode that produces silent regressions.

### 11.1 — Per-Refactor Gates

- [ ] `cargo check --workspace --all-targets` returns 0.
- [ ] `cargo build --workspace --all-targets` returns 0.
- [ ] `cargo clippy --workspace --all-targets -- -D warnings` returns 0.
- [ ] `cargo test --workspace` returns 0.
- [ ] `cargo fmt --check` returns 0 (or `cargo fmt` is run as part of the commit).
- [ ] `bash scripts/check_firewall.sh` returns 0.
- [ ] `bash scripts/check_validate_signature.sh` returns 0.
- [ ] `bash scripts/check_size.sh` returns 0.
- [ ] `bash scripts/check_error_codes.sh` returns 0.
- [ ] `bash scripts/check_placeholder_debt.sh` returns 0.

### 11.2 — Determinism Gate (mandatory when refactor touches sim or state_hash)

- [ ] `cargo test -p anvil_sim --test phase3_determinism` returns 0.
- [ ] `cargo test -p anvil_sim --test phase3_snapshot_roundtrip` returns 0.
- [ ] Hash output captured before refactor matches hash output after refactor — *if* the refactor is intended to be behaviour-preserving. If the refactor intentionally changes behaviour (e.g., fixing a bug that affected the hash), the new hash is recorded in `DECISIONS.md`.
- [ ] If save format was bumped: `cargo test -p anvil_runtime --test save_migration` returns 0; old fixtures (v6, v7, v8, …) still load.

### 11.3 — Visual Layer Gate (mandatory when refactor touches bridge or UI)

- [ ] Manual smoke test: launch the binary, observe scene renders, observe UI panels populate.
- [ ] If a panel was modified: verify its display matches the WorldView field it claims to read (transient `info!` in the writer; cross-check against UI).
- [ ] `rg "Res<RuntimeResource>" crates/anvil_bevy crates/anvil_demo --type rust | grep -v sim_bridge | grep -v tick_simulation_systems` returns zero new lines compared to before refactor.

### 11.4 — Documentation Gate

- [ ] If the refactor introduced a new error code, it's in `ERROR_CODES.md`.
- [ ] If the refactor changed a binding constraint's interpretation, `DECISIONS.md` has an entry (§12).
- [ ] If the refactor was non-trivial (≥ 100 lines changed, or crosses ≥ 2 files), `DECISIONS.md` has an entry.
- [ ] If the refactor changed a public API, that API's doc comment was updated.

### 11.5 — Commit Hygiene Gate

- [ ] Commit message starts with `<area>: <one-line>`.
- [ ] Commit body has a paragraph explaining the *why*, citing constraint or audit finding.
- [ ] Commit references the `DECISIONS.md` entry by anchor.
- [ ] One refactor = one commit (excluding the prior test commit per §3.4).
- [ ] `[ai]` prefix added if AI was the primary author (Commandment 5).

### 11.6 — Process Gate

- [ ] `git status` is clean.
- [ ] No untracked files remain that should be committed (especially: forgotten new files in a split).
- [ ] `git log -1 --stat` shows only the expected files.

---

## Section 12: The Decision Log Format

`DECISIONS.md` is the project's only second reviewer for a solo developer. An undocumented decision is an unreviewed decision. The format below is the minimum that makes future-you able to reconstruct past-you's reasoning.

### 12.1 — Template

```markdown
## YYYY-MM-DD: <one-line decision title>

**Tags:** #refactor #determinism #boundary (etc — for greppability)

### Context

<1-3 sentences: what state was the codebase in, what triggered the decision>

### Decision

<1-3 sentences: what was decided, in plain language>

### Alternatives considered

- **Option A: <name>.** <one-line description and one-line reason it was rejected>
- **Option B: <name>.** <same>
- **Chosen: Option C.** <one-line description and reason>

### Constraints invoked

- ANVIL_PHILOSOPHY.md Commandment <N>: <how it applied>
- ANVIL_DETERMINISM.md §<section>: <how it applied>
- Day-N Specification §<section>: <how it applied>

### Audit findings cited

- <e.g.: Day 2 Boundary Violation #3 (atmosphere_driver direct sim reads)>

### Verification

<commands run, results recorded, hash captured if relevant>

### Follow-up

- [ ] <any deferred work, with target date if known>
- [ ] <any tests to write later>
- [ ] <any documentation to update later>
```

### 12.2 — Greppability Rules

- Tags are `#kebab-case`. Always include at least one. The fixed vocabulary is small: `#refactor #determinism #boundary #firewall #error-handling #worldview #atmosphere #camera #ui #snapshot #migration #dead-code #placeholder`.
- Date format is ISO-8601 (`YYYY-MM-DD`). Sortable.
- One H2 per decision. Never combine decisions into one entry.
- Decisions are append-only. To supersede, write a new entry referencing the prior one's date and title:

```markdown
## 2026-06-15: WorldView regions sourced from runtime.world (supersedes 2026-03-01)

<context: the 2026-03-01 entry decided hardcoded; this entry undoes it because audit found it produced fictional UI data>
```

### 12.3 — When Not to Write an Entry

Not every action needs a decision-log entry:

- A typo fix.
- A clippy auto-fix.
- A rename that's clearly an improvement (`x` → `entity_id`).
- A test added for an existing function with no behaviour change.

The trigger is **was there an alternative I considered and rejected?** If yes, write the entry. If no, don't.

### 12.4 — Quarterly Review Hygiene

Every 90 days, scan `DECISIONS.md`:

- Verify every entry's "Follow-up" checkboxes are either ticked or moved to the current sprint.
- Look for repeated tag patterns — if `#dead-code` appears five times in three months, dead code is accumulating and warrants a dedicated cleanup sprint.
- Look for decisions that no longer hold (the codebase moved past them); annotate but do not delete.

---

## Appendix A: Required & Recommended Tooling

| Tool | Status | Install Command | Purpose |
|---|---|---|---|
| `cargo clippy` | bundled with toolchain | (default) | C1, C2, lint enforcement |
| `cargo fmt` | bundled | (default) | Format consistency |
| `cargo test` | bundled | (default) | Test gates |
| `cargo tree` | bundled | (default) | Firewall enforcement, dependency analysis |
| `ripgrep` (`rg`) | likely already installed | `apt install ripgrep` / `brew install ripgrep` | All grep-pattern commands in this manual |
| `cargo-llvm-cov` | **REQUIRES INSTALLATION** | `cargo install cargo-llvm-cov` | Commandment 7 coverage threshold |
| `cargo-machete` | **REQUIRES INSTALLATION** | `cargo install cargo-machete` | §7 dead-dependency detection |
| `cargo-modules` | optional | `cargo install cargo-modules` | §1.2 reachability analysis (alternative to grep) |
| `cargo-fuzz` | optional | `cargo install cargo-fuzz` | Commandment 7 fuzz layer (nightly job) |

---

## Appendix B: A 30-Second Refactor Drill

For trivial refactors (rename, extract method, formatting), the full protocol is overkill. The 30-second drill:

```bash
git status                                          # clean?
cargo check --workspace                              # baseline?
# ... make the change ...
cargo check --workspace                              # still builds?
cargo clippy --workspace -- -D warnings              # no new warnings?
cargo test --workspace                               # tests pass?
git add -p && git commit -m "rename: foo -> bar"     # atomic
```

If any of these returns non-zero, fall back to the full §1 protocol. The 30-second drill assumes the refactor is genuinely trivial; if it isn't, the protocol catches it.

---

## Appendix C: Manual Self-Audit Cadence

This manual is maintained code, not write-once documentation. Schedule:

- **Per refactor:** if the refactor revealed a missing pattern or anti-pattern, add it to §5 or §6 in the same PR.
- **Monthly:** scan §6 anti-pattern catalog against `rg` outputs; if new instances appear, the catalog is not deterring; add tooling.
- **Per quarter:** revisit §3 sequencing rules against the past quarter's actual refactor history; if rules were violated and the dev got away with it, the rule was too strict. If rules were violated and pain followed, the rule needs sharper enforcement.
- **Per Bevy minor version bump:** revisit §4 lookup table; mark version-dependent rows.
- **Per binding-constraint amendment** (in `ANVIL_PHILOSOPHY.md` or `ANVIL_DETERMINISM.md`): revisit §2 matrix; update detection commands and fix patterns.

The manual's quality is measured by how often the dev needs to escalate to Opus despite having the manual. The escalation log (per §10.3) is the data source for what the manual is missing.

---

**End of Refactor Execution Manual.**