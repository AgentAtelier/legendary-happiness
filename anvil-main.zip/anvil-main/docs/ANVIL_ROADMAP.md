---
id: ANVIL_ROADMAP
title: Roadmap, Sprints, and Registries
status: active
audience: [developer, agent, contributor]
last_reviewed: 2026-05-11
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_STATUS, ANVIL_DECISIONS, ANVIL_AUDIT, ANVIL_GAME_DESIGN, ANVIL_DEMO]
owner: project_lead
version: 1.1
gate_scripts: [scripts/check_placeholder_debt.sh]
code_paths: []
---

## Summary

Three time horizons in one document.

- **Strategy** (§1) — what Forgeborn is trying to be over a 3–10 year horizon, what success looks like, what risks the project lead actively manages.
- **Phases and active work** (§2–§3) — Phase 1–3 closed (2026-05-02). Demo Integration is active; sprint sequence in §3.
- **Sprint plan** (§4) — concrete Demo Integration sprints (23–28+) and the future-phase outline.
- **Registries** (§5–§6) — Placeholder Registry (port-as-placeholder code, schema preserved) and Infrastructure Registry (gates, tooling, observability).
- **Future design work** (§7) — open design questions surfaced by the GDD rewrite.

This document supersedes four earlier files. Detailed strategic narrative and phase rationale archived under `docs/archive/` for reference; the sections kept here are the parts that drive decisions today.

---

## 1. Strategy

### 1.1 The thing being built

Forgeborn is a single-player simulation game on a hostile continent, built on the Anvil engine. The engine separates deterministic simulation from presentation by a strict dependency firewall. The game is described in [`ANVIL_GAME_DESIGN`](ANVIL_GAME_DESIGN.md).

The defining technical claim: same world + same RNG seed = same outcome, byte-identical, across hardware. That guarantee makes everything else affordable — saves work, replays work, automated testing works, the dual-seed demo (see [`ANVIL_DEMO`](ANVIL_DEMO.md) §5:15) is a real proof rather than a parlour trick.

The defining design claim: the player is an inhabitant, not a hero. Every NPC system that touches the player also touches every NPC. Social integration is a survival strategy, not a quest reward.

### 1.2 What success looks like

| Horizon | Success state |
|---|---|
| 6 months | The demo ships publicly. Phases 1–3 closed, Demo Integration done. CC0 assets only; no licensing risk. |
| 18 months | Steam launch. Phase 4 closed. One biome end-to-end, ~5 hours of content per playthrough. Reviews mention "the village remembered." |
| 3 years | Multiple biomes. Modding API exposed. A community of authors building plans the LLM loop validates. |
| 5–10 years | Forgeborn is the game it set out to be: a solo-dev project that became a small studio, content-driven, deterministic, modded heavily, technically referenced for its simulation. |

Each horizon's goal is unblocked by closing the audit findings on the current horizon. The 6-month goal is gated by the four CRIT findings in [`ANVIL_AUDIT`](ANVIL_AUDIT.md). The 18-month goal is gated by Phase 4's release-prep work below.

### 1.3 What's already working (preserve list)

A 10-year project needs to know what to keep. These properties are what Anvil has that Forge (the predecessor) lacked:

1. **Dependency firewall holds at the source level.** Verified by `scripts/check_firewall.sh`. Bevy and LLM dependencies appear only in `anvil_bevy`, `anvil_demo`, `anvil_streaming`. Deterministic crates have zero engine deps.
2. **Multi-error validation with a registered code system.** Every validator returns `ValidationErrors` (or one of two equivalent shapes still being normalised — see [`ANVIL_AUDIT`](ANVIL_AUDIT.md)). 100+ codes registered in [`ANVIL_ERROR_CODES`](ANVIL_ERROR_CODES.md).
3. **Documentation triad.** [`ANVIL_PHILOSOPHY`](ANVIL_PHILOSOPHY.md) + [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md) + [`ANVIL_ERROR_CODES`](ANVIL_ERROR_CODES.md). A new contributor can rebuild the mental model from these three files.
4. **Newtype pattern is pervasive.** No bare `usize` for IDs, no bare `String` for tags. `ArchetypeTag`, `RegionId`, `ConnectionId`, `AuthoredEntityId`, `AssetPath` all carry construction-time validation.
5. **The FBX parser is hardened.** Fuzz target in `anvil_assets/fuzz/`. Version gating, size caps, recursion limits, overflow checks. The exact attack surface that helped sink Forge is closed.
6. **A real demo.** `crates/anvil_demo` runs an end-to-end compiled world with a live simulation. The integration is exercised on every build, not aspirational.
7. **The deterministic-simulation guarantee.** Phase 3 closed with byte-identical state hashes verified across 5,000 ticks with 50 NPCs, full catastrophe sequence, snapshot/restore round-trip — see [`ANVIL_DETERMINISM`](ANVIL_DETERMINISM.md).

The roadmap below is about preserving and extending these wins, not building from scratch.

### 1.4 The risks (active management)

Sorted by likelihood × impact. Items 1–3 are the ones the project lead actively manages; 4–10 are tracked but the mitigation is in place.

| # | Risk | Mitigation today | Early-warning signal |
|---|---|---|---|
| 1 | **File-size creep.** ~100 functions over the 50-line limit, 20 files over 500 lines. Forge collapsed at 18,991 lines in one file. | Workspace `clippy.toml` enforcement + audit-finding HIGH-02/HIGH-03. | Any new file landing > 600 prod lines. |
| 2 | **Solo-developer burnout** on a 10-year project. | Realistic milestones; recovery quarters; no death marches; the doc system is *for* this. | Velocity dropping for two consecutive months. |
| 3 | **Bus factor of 1, by definition.** Cannot be raised by adding reviewers. Tacit knowledge in `anvil_assets_pipeline` is the highest exposure. | Documentation-first discipline; per-decision entry in DECISIONS; 24-hour cooling-off for changes in `anvil_assets_pipeline`. | Decisions in pipeline crates not reflected in DECISIONS within 7 days. |
| 4 | Validation contract drift. | `scripts/check_validate_signature.sh`. | New `Result<(), E>`-returning validate in a PR. |
| 5 | Bevy plugin churn. | Pin Bevy version; firewall keeps blast radius to two crates; 6-month buffer per Bevy major. | RFCs touching core ECS API. |
| 6 | Determinism breakage from compiler upgrades. | `rust-toolchain.toml`; nightly determinism CI; physics isolated. | Rustc release notes mentioning codegen changes. |
| 7 | Vendor lock-in: NatureManufacture pack. **CC0 replacement is gating public release** (audit HIGH-07). | CC0 sources catalogued; replacement plan in [`ANVIL_ASSETS`](ANVIL_ASSETS.md). | Already mitigated; replacement is in flight. |
| 8 | Save-game schema drift. | `Versioned` trait; mandatory migration test for every schema change. | Schema-change PR without migration test. |
| 9 | Cargo registry / supply-chain attack. | `Cargo.lock` committed; `cargo-deny`; weekly `cargo audit`. | RustSec advisory matching workspace dep. |
| 10 | LLM-authored content quality regresses. | Cache LLM outputs in `assets/external/`; never call LLM at runtime. | Provider auth/API change. |

A wider 18-risk register lives in archived `ANVIL_STRATEGIC_ANALYSIS_v3.md` for reference.

---

## 2. Phase summary

| Phase | Status | Closed | Reference |
|---|---|---|---|
| 1 — Foundation Hardening | **CLOSED** | 2026-04-30 | Sprints 1–5; closed via `tests/phase1_gate.sh` |
| 2 — Pipeline Completion | **CLOSED** | 2026-05-01 | Sprints 6–13; closed via `tests/phase2_gate.sh` |
| 3 — Gameplay Systems | **CLOSED** | 2026-05-02 | Sprints 14–22; closed via `tests/phase3_gate.sh`. See [`ANVIL_DETERMINISM`](ANVIL_DETERMINISM.md) |
| **Demo Integration** | **ACTIVE** | — | Sprints 23+, this document §3–§4 |
| 4 — Steam Release Prep | UPCOMING | — | §4.5 below |
| 5 — Post-Release Evolution | FAR | — | §4.6 below |

Phases 1–3 closed eight-of-nine sprint plans (Sprint 21 networking explicitly declined as out of scope — see [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md)). All systems built: catastrophes, emotional network, joy, NPC utility AI, diegetic progression, teaching, multi-axis emotion, continuous age/time, children's foundation, deterministic physics, save format v7.

---

## 3. Active phase: Demo Integration

The current sprint phase. Goal: make all Phase 3 simulation systems visually observable in `anvil_demo`, and clear the four CRIT audit findings that block public release.

The demo today runs end-to-end. The presentation and content infrastructure is mostly built (see [`ANVIL_DEMO`](ANVIL_DEMO.md) §3 "What shipped"). What's missing is integration polish: replacing the placeholder data branches in `sim_bridge.rs`, fixing the dual `SimSpeed` resource, replacing startup-system assertions with proper error handling, and extending save/restore beyond physics. CC0 asset replacement runs in parallel.

### Active priority list (the 10 systems from Phase 3 close)

These are the simulation systems that need visible-in-demo wiring, in roughly this order:

1. Catastrophe system — visual representation of floods, earthquakes, etc.
2. Settlement emotional network — mood visualisation for NPCs.
3. CatalystEvent joy system — celebration/festivity visuals.
4. NPC utility AI — visible NPC actions and decision-making.
5. Diegetic progression — skill progression UI/feedback.
6. Teaching system — observation and learning visual cues.
7. Multi-axis emotional state — NPC emotion display.
8. Age curves — visual differentiation between children, adults, elders.
9. Physics — player movement and catastrophe physics effects.
10. Save v7 — save/load UI integration.

Most of these are partially or fully shipped (see the comparison table in [`ANVIL_DEMO`](ANVIL_DEMO.md) §3). The remaining wiring is the work below.

### Six proposed demo extensions

[`ANVIL_DEMO`](ANVIL_DEMO.md) §4 proposes six extensions that fit within Phase 1–3 capability — each implementable in `anvil_demo` without touching deterministic crates. Cross-referenced into the sprint plan below if approved by the project lead.

---

## 4. Sprint plan

The Demo Integration sprints below sequence the audit-finding remediation against the demo extensions. Each sprint is sized for one focused work-week. A sprint completes when its named tasks are done and the gates still pass.

### 4.1 Sprint 23 — Foundation cleanup

**Goal:** Lock the gates that have been drifting; no new behaviour.

| Task | Tracking |
|---|---|
| Add the production deny-block to the 5 missing crates | [`ANVIL_AUDIT`](ANVIL_AUDIT.md) HIGH-05 |
| Introduce the `arche!` macro and sed-replace 30 sites | HIGH-01 |
| Delete dead Ashveil duplicate (739 lines unused) | HIGH-04 |
| Switch `anvil_streaming` to `parking_lot::Mutex` | MED-05 |
| Trim `tokio` features from `anvil_streaming` | MED-06 |

**Effort:** ~5 work-days. **Gate:** all current gates still pass; line count drops by ~750.

### 4.2 Sprint 24 — Plumbing and CI

**Goal:** Wire the existing infrastructure that isn't surfacing today.

| Task | Tracking |
|---|---|
| Wire runtime errors to `EventLog` (replace `.ok()` in `tick_simulation_systems`) | HIGH-06 |
| Ship `scripts/check_docs.sh` in CI | MED-09 |
| Workspace `clippy.toml` with `too-many-lines-threshold = 50` | MED-01 + amendment A2 |
| Build the one-time function-size exception list to enable enforcement | MED-01 |
| Enable `#![deny(missing_docs)]` on the crates that are clean | MED-02 |

**Effort:** ~5 work-days. **Gate:** `check_docs.sh` runs in CI; `cargo clippy` enforces the 50-line limit on new code; runtime errors visible in the demo.

### 4.3 Sprint 25 — Placeholder purge

**Goal:** Make the demo show real simulation data, not fixtures.

| Task | Tracking |
|---|---|
| Delete `get_npc_details_placeholder` (278 lines) and `populate_placeholder_integrity` (81 lines) | [`ANVIL_AUDIT`](ANVIL_AUDIT.md) CRIT-03 |
| Replace placeholder branches with empty-state UI in panels that need it | CRIT-03 |
| Gate any genuinely-needed fixtures behind `cfg(feature = "demo_fixtures")` | CRIT-03 |
| Fix dual `SimSpeed` resource — keep `app::SimSpeed`, delete the other, point UI at it | CRIT-01 |
| Replace startup-system assertions with `error!` log + early return | CRIT-02 |
| Implement the **E5** demo extension (precursor visibility cue) — small, immediate value | [`ANVIL_DEMO`](ANVIL_DEMO.md) §4 |

**Effort:** ~5 work-days. **Gate:** demo no longer shows fictional NPC data; UI speed controls work; startup contract violations log instead of crash.

### 4.4 Sprint 26 — Save format v8

**Goal:** End-to-end save/restore that actually restores all the simulation, not just physics.

| Task | Tracking |
|---|---|
| Promote `snapshot()`/`restore()` to `SimSystem` trait methods (default no-op) | [`ANVIL_AUDIT`](ANVIL_AUDIT.md) CRIT-04 |
| Override on `NpcSystem`, `CatastropheSystem`, `JoySystem` | CRIT-04 |
| Bump save format to v8 with system-keyed map | CRIT-04 |
| Add v7→v8 migration with round-trip test | CRIT-04 |
| Add `RuntimeError::WorldHashMismatch { save_hash, world_hash }` structured variant | MED-07 |
| Wire `time_travel/` slider as **E4** demo extension (scrubbing now functional end-to-end) | [`ANVIL_DEMO`](ANVIL_DEMO.md) §4 |

**Effort:** ~7 work-days. **Gate:** save → modify world for 1000 ticks → load → state hash matches the saved tick. Physics + NPCs + catastrophe + joy all restore.

### 4.5 Sprints 27+ — Demo phases, polish, and CC0 replacement

After the foundation sprints (23–26) the demo's six-phase visual roadmap drives sprint sequencing. The phases are defined in [`ANVIL_DEMO`](ANVIL_DEMO.md) §5; this section schedules them.

### Sprint NN — Audio rebuild (2026-05-11)

Replaces the v1.x audio module entirely. Delivers:

- `crates/anvil_bevy/src/audio/` — engine-class audio infrastructure
  (nine files, all under 500 lines, all functions under 50 lines, all
  documented). Owns: seed/RNG, director state, stem registry, zone
  registry, cue events, ducking, score helpers, output stage. Tests
  cover seed determinism, cue dispatch, end-to-end mix determinism.
- `crates/anvil_demo/src/audio/ashveil.rs` — Ashveil-specific
  configuration: six score stems, four ambient zones, stinger map
  placeholder. All artistic constants marked `TUNE:`.
- Three blocking bugs closed: AmbientAudioPlugin double-registration,
  screech-from-uncounted-spawns, zones-at-narrative-coordinates.
- `docs/ANVIL_AUDIO.md` — full architecture spec.
- `docs/AUDIO_SHOPPING_LIST.md` — 12-file sourcing brief.
- `docs/ANVIL_DECISIONS.md` — 2026-05-11 entry capturing all session
  ratifications (Q1–Q11 from the session transcript).

The audio system **runs without assets**. Missing files resolve to
`Handle::default()` and the spawn pipeline skips them. Sourcing is
parallel work; each file dropped into `assets/audio/...` becomes
audible the next run.

Procedural synthesis (the old `generator.rs`) is **retired**, not
deferred. Notebook polish ideas for the procedural path (PolyBLEP,
Xorshift64 swap, pink noise) are retired indefinitely per the
session's Q11 decision.

#### Deferred (tracked, not blocking)

- Cue → stinger mapping table. Resolver returns None universally;
  wiring is in place.
- `MoodCurve` artistic tuning. Provisional values ship; tuning needs
  ear work with real assets.
- Audio debugging egui panel.
- Hot-reloadable RON zone definitions.
- Stinger priority enum.
- Time-of-day zone variants.

#### Outside scope

- The `anvil_assets_pipeline` crate has 25 unrelated compilation
  errors (syntax error in `selection.rs`, missing derives, dead
  imports under `#![deny(warnings)]`). Surgical fix instructions in
  `PIPELINE_FIX.md` in the audio rebuild bundle. Apply as a separate
  doc-style PR — does not block the audio rebuild or the demo binary.

---

**Sprint 27 — Phase 1 + Phase 2 foundations.** First-person controller, idle takeover, AtmosphereDriver, ambient zones, watched-pass eerie levers. Plus Phase 2's GazeDriver and OrientationDriver (the two with highest legibility-per-line). ~7 work-days. Removes `bevy_flycam`, intro splash, dual-viewport replay (moved to dev tool), camera spline as primary mode.

**Sprint 28 — Phase 2 completion + Phase 3 start.** ProximityDriver, MovementSignature, LifeRhythm complete the village-as-system. Phase 3 starts with TerrainAudio and BreathingSystem (the two highest-impact somatic systems). ~5 work-days.

**Sprint 29 — Phase 3 completion + CC0/CC-BY replacement (parallelised).** Heartbeat, CameraShake/HandTremor, PeripheralVignette, BodyState aggregator, hand-check input. In parallel: replace NatureManufacture-derived assets with CC0/CC-BY equivalents (HIGH-07, gates public release). Update [`ANVIL_ASSETS`](ANVIL_ASSETS.md) registry. Remove `vendor/emberwood/` from Git history before tagging. **Effort: large.** ~7–10 work-days, parallelisable.

**Sprint 30 — Phase 4 catastrophe.** FireParticleField, EmberSystem, SmokeColumn, ValleySmoke, FireLightSource, three-layer CatastropheAudio, PostCatastropheState. Replaces single-cube `vfx/fire_spread.rs`, static `vfx/smoke.rs`, hardcoded wind in `vfx/debris.rs`. ~7 work-days. Profile after; if 30 fps threatened, particle counts and bloom tuning fall back per Phase 6 discipline.

**Sprint 31 — Function size burn-down.** Move data-as-code to JSON. Phase A2 amendment exception list closes here. ~5 work-days. Tracking HIGH-02 part 2.

**Sprint 32 — File splits.** Split the 20 files over the 500-line limit. ~7–10 work-days, parallelisable. Tracking HIGH-03.

**Sprint 33 — Phase 5 score.** MoodReader, ScoreState, ~7-stem library (sourced or curated), SpatialMixing, ScoreTrigger. ~5 work-days plus stem-sourcing time.

**Sprint 34+ — Phase 6 polish.** The polish phase is structured as **passes**, not sprints. Each pass runs until the project lead decides it has reached the achievable level. Outcomes documented in [`ANVIL_DEMO_LIMITS`](ANVIL_DEMO_LIMITS.md). Five passes total: lighting, weather, sound, glitch elimination, integration polish. **No effort estimate** — Phase 6 ends when the demo is as good as solo-dev can make it, with documented walls. Treated as the most important phase per the project lead's view that polish is the threshold component of a playable game.

After Phase 6, Demo Integration is complete and Phase 4 (Steam Release Prep) begins.

#### Mapping to former E1–E6 plan

The E1–E6 demo extensions ratified 2026-05-09 are absorbed into the phase plan:

| Former extension | New home |
|---|---|
| E1 multi-axis emotion display | Implicit in Phase 3 (`BodyState` aggregator surfaces Emotional Axes diegetically; Inspector panel work deprioritised since UI is its own roadmap) |
| E2 age-curve silhouettes | Phase 6 polish, lighting + weather pass adjacent (visual continuity work) |
| E3 observation halos | Phase 2 LifeRhythm (rolled in) |
| E4 time-travel scrubbing | Sprint 26 (CRIT-04) + post-Phase 6 dev tool (not in shipping demo) |
| E5 precursor visibility cue | Phase 1 watched-pass eerie levers (rolled in) |
| E6 joy as ambient layer | Phase 5 score recovery state (rolled in) |


### 4.6 Phase 4 — Steam Release Preparation (Months 13–18)

Calendar-shifted by Demo Integration's actual length. Content largely unchanged from earlier strategic analysis.

- 6 weeks of bug-fixing only.
- Platforms: Windows + Linux + macOS, Steam Deck verified.
- Telemetry: opt-in crash reports.
- Modding API: expose `anvil_assets` and authored JSON formats.
- Localisation: extract every user-facing string.
- Marketing build cadence.
- Submit a vertical slice to Steam Direct mid-phase for feedback, not at the end.

Phase 4 also runs the Infrastructure Sprint (§6 below) — the work in the registry that is "scheduled" rather than "open."

### 4.7 Phase 5 — Post-Release Evolution (Years 3+)

Specificity is appropriate to the time horizon.

- Year 3: content cadence; technical-debt repayment quarter.
- Year 4–5: multiplayer or major content expansion.
- Year 6–7: engine retargeting risk window; 6-month port for next Bevy major.
- Year 8–10: MMO scaling, if pursued.

---

## 5. Placeholder Registry

Every file ported from Forge as a placeholder (a port whose semantics are provisional and depend on a Forgeborn GDD section not yet written) is recorded here. The schema is preserved from the original `PLACEHOLDER_DEBT.md`.

**Discipline:** A placeholder review date that has passed is a hard blocker on the next sprint. Enforced by `scripts/check_placeholder_debt.sh`. This is the "option 1" gate the project lead chose.

### 5.1 Schema

Each entry has the same shape:

```
PD-XXX — <module name>

- Source:           forge_<crate>/src/<file>.rs
- Anvil destination: anvil_<crate>/src/<module>.rs (after split)
- Lines ported:     <prod lines>
- Why placeholder:  one paragraph explaining what is provisional
- What is provisional: specific list of fields, behaviours, weights,
                       or design choices depending on a GDD section
- Review trigger:   the GDD section, sprint, or external decision
                    whose completion forces a review
- Review date (no later than): YYYY-MM-DD
- Review outcome:   (filled at review time) one of:
                      promoted to port-as-foundation
                      rewritten
                      abandoned
                      review deferred to <new date> with reason
- Status:           open / under review / resolved
```

### 5.2 Active entries (open or under review)

| ID | Module | Source | Status | Review date | Notes |
|---|---|---|---|---|---|
| PD-001 | DemoVistaLayout subsystem | `forge_world/src/lib.rs` lines 81–650 (~570) | Open | 2026-08-01 | Provisional model; depends on whether Forgeborn first-hour scene is procedural or hand-authored. |
| PD-002 | Scenario bundle reporting | `forge_assembly/src/scenario.rs` (~340) | Open | 2026-09-01 | Provisional reporting shape; ties to GDD section on demo telemetry. |
| PD-003 | Quest state machine | `forge_assembly/src/quest.rs` (~480) | Open | 2026-10-15 | Quests-as-emergent-events vs. quests-as-state — see GDD §5.6. |
| PD-005 | WorldLive layered runtime state | `forge_runtime/src/lib.rs` (~620) | Open | 2026-09-15 | Provisional layering; resolves with save format v8 (CRIT-04). |
| PD-006 | Live evidence consequences | `forge_runtime/src/evidence.rs` (~290) | Open | 2026-11-01 | Tied to design of player-action-consequence visibility. |
| PD-008 | Route planning logic | `forge_assembly/src/routing.rs` (~410) | Open | 2026-10-01 | Provisional pathfinding; depends on continental-economy decisions (GDD §7). |
| PD-011 | HUD overlay | `forge_bevy/src/hud.rs` (~530) | Open | 2026-08-15 | Provisional UI shape; resolves with Demo Integration. |
| PD-012 | Fauna systems | `forge_sim/src/fauna.rs` (~380) | Open | 2026-12-01 | Open design question (GDD §7 — biome design). |

### 5.3 Resolved entries

| ID | Module | Resolution | Date |
|---|---|---|---|
| PD-004 | Survey diagnosis system | Rewritten as part of Phase 3 NPC observation system | 2026-04-15 |
| PD-007 | Region investigation priority scoring | Promoted to port-as-foundation; lives in `anvil_sim::utility::scoring` | 2026-04-22 |
| PD-009 | Expedition completion detection | Abandoned — Forgeborn does not have expeditions in this sense | 2026-04-25 |
| PD-010 | Survey submission and judgment | Abandoned — replaced by emergent NPC observation | 2026-04-25 |

When an entry is resolved, the resolution flows into [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md) as a dated entry. The original placeholder source remains in `docs/archive/PLACEHOLDER_DEBT_v1.md` for reference.

### 5.4 Adding a new placeholder

When a new port-as-placeholder is added:

1. The file gets a `// PLACEHOLDER FROM forge_<crate>` header.
2. A new `PD-XXX` row appears in §5.2 above. ID is the next free integer.
3. A `[ai]` commit message if AI-assisted.
4. The relevant GDD section's TBD list (in [`ANVIL_GAME_DESIGN`](ANVIL_GAME_DESIGN.md) §7) gets a backlink to the placeholder ID.
5. Sprint-start gate (`scripts/check_placeholder_debt.sh`) verifies no review dates are overdue before allowing the next sprint.

### 5.5 Reviewing a placeholder

When a review trigger fires:

1. Read the relevant GDD section (now written).
2. Decide: promote to port-as-foundation, rewrite, abandon, or defer.
3. Record the outcome in §5.2 above (move to §5.3 if resolved).
4. Add a [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md) entry naming PD-XXX and the outcome.
5. If rewritten, the rewrite is its own work item — schedule into the next available sprint.
6. If abandoned, delete the file in the same PR. Keep the registry entry as historical record.

---

## 6. Infrastructure Registry

Infrastructure, performance, testing, and observability targets. Schema preserved from the original `INFRASTRUCTURE_EXCELLENCE.md`.

**Sprint linkage:** at sprint boundaries, open entries are reviewed alongside the Placeholder Registry. The Infrastructure Sprint (§6.1 below) addresses a specific subset before Phase 4 kickoff.

### 6.1 The Infrastructure Sprint

A dedicated ~7-work-day sprint scheduled before Phase 4 kickoff. Items addressed: I-001, I-002, I-006, I-014, I-016, I-018, I-020.

**Scope:**

- I-001 — Performance baseline measurement (RESOLVED 2025-01-02; baseline collected; bench/REPORT.md exists)
- I-002 — Cross-platform CI matrix (RESOLVED 2025-05-03; 4-platform matrix shipping)
- I-006 — Structured tracing (open)
- I-014 — Observability instrumentation (open)
- I-016 — Compile time tracking (open; current dev build is 175 s, exceeds 120 s budget — root cause is `nalgebra` future-incompat, see I-022)
- I-018 — Local dev environment script (open)
- I-020 — Determinism bisect script (open)

**Gate:** all acceptance criteria met, all CI checks pass.

### 6.2 Schema

```
I-XXX — Title

- Current state:     one sentence
- Target state:      one paragraph describing what "excellent" looks like
- Implementation approach: concrete steps, tools, crates
- Phase / Review date: when this will be done or reviewed
- Acceptance criteria: measurable outcome
- Status:            open / in progress / resolved
- Review log:        (filled at resolution) what was actually delivered
```

### 6.3 Open and partial entries

Twelve entries currently open or partial. Detailed text lives in archived `INFRASTRUCTURE_EXCELLENCE_v1.md`.

| ID | Title | Status | Phase / Trigger |
|---|---|---|---|
| I-004 | Memory profiling | Open | Phase 4 |
| I-005 | Crash reporting skeleton | Open | Phase 4 |
| I-006 | Structured tracing | Open | Infrastructure Sprint |
| I-007 | Adversarial asset pipeline testing | Open | Phase 4 Month 2 |
| I-008 | Visual regression testing | Open | Phase 4 Month 3 |
| I-010 | Test depth and breadth | Open | Continuous |
| I-014 | Observability instrumentation | Open | Infrastructure Sprint |
| I-015 | Pre-push gate | Open | Demo Integration Sprint 24 |
| I-016 | Compile time tracking | Open (blocked on I-022) | Infrastructure Sprint |
| I-017 | Dependency update automation | Open | Phase 4 |
| I-018 | Local dev environment script | Open | Infrastructure Sprint |
| I-019 | Save file corruption resilience | Open | Phase 4 |
| I-020 | Determinism bisect script | Open | Infrastructure Sprint |
| I-021 | Unused dependency check | Open | Sprint 23 (rolls in with Sprint 23 cleanup) |
| I-022 | nalgebra future-incompatibility | Open | Phase 4 (drives I-016) |

### 6.4 Resolved entries

Seventeen items resolved. Highlights below; full review log per item lives in archived `INFRASTRUCTURE_EXCELLENCE_v1.md`.

| ID | Title | Resolved |
|---|---|---|
| I-001 | Performance baseline measurement | 2025-01-02 |
| I-002 | Cross-platform CI matrix | 2025-05-03 |
| I-003 | Nightly determinism fuzzing | 2025-05-03 |
| I-009 | Benchmark regression CI gate | 2025-05-03 |
| I-011 | CI pipeline depth | 2026-04-15 |
| I-012 | Error code infrastructure | 2026-04-22 |
| I-013 | Snapshot determinism (cross-version) | 2026-05-01 |

(plus I-001 through I-022, the rest resolved in routine sprints — see archive for the full list)

A "Known constraint" exists for `cargo-llvm-cov` on shared CI runners: LLVM-instrumented linking exceeds the runner's 7 GB RAM. Coverage will return when a larger runner is used or the dependency chain shrinks.

### 6.5 Adding a new infrastructure target

A new target gets an `I-XXX` row with the next free ID. Its schema fields are filled. If it's blocked on Phase work, the "Phase" field names that phase. If its work is parallelisable, it can be addressed in a sprint of opportunity. The Infrastructure Sprint is the catch-all for anything that didn't fit into a regular sprint by the time Phase 4 starts.

---

## 7. Future design work

Open design questions surfaced by the GDD rewrite ([`ANVIL_GAME_DESIGN`](ANVIL_GAME_DESIGN.md) §7). Each becomes a future GDD section, written one at a time, measured against the seven principles and the system constraints established there.

| Topic | Trigger | Status |
|---|---|---|
| Combat mechanics | Phase 4 (release prep makes combat polish concrete) | Open |
| Continental economy (inter-settlement trade) | Phase 5 first content quarter | Open |
| Save metadata and world drift | Linked to CRIT-04 closure | Open (in Sprint 26) |
| Continuous-lives mechanic (player death and replacement) | Phase 4 | Open |
| The time-recovery skill | Phase 4 | Open |
| Specific biome designs (which regions flood, which burn, which quake) | Phase 4 + Phase 5 first content quarter | Open |
| First-hour player experience | Phase 4 | Open |
| Substrate self-deformation (cicatrices) | Sprint 18+ | Sprint planned |
| Tension field model (Layer-3 evolution from utility-AI) | Long-term | Open |

These items are tracked here, not in the GDD, because they are work-items rather than design content. When one resolves, it becomes a GDD section and this row moves to a "Resolved design work" log in [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md).

---

## Appendix — Archive references

The merged source documents:

- Strategic narrative and detailed phase rationale: `docs/archive/ANVIL_STRATEGIC_ANALYSIS_v3.md`
- Detailed sprint-task breakdowns for Phases 2–3: `docs/archive/PHASE_SPRINTS_v2.md`
- Original placeholder registry with full per-entry text: `docs/archive/PLACEHOLDER_DEBT_v1.md`
- Original infrastructure registry with full per-entry text: `docs/archive/INFRASTRUCTURE_EXCELLENCE_v1.md`

Refer to those when the summary tables above are not enough — for example, when porting a new file from Forge and needing the schema and review-trigger guidance from the original `PLACEHOLDER_DEBT.md` per-entry text. The archived versions are frozen; this document is the live one.
