---
id: ANVIL_AUDIO
title: Audio architecture
status: active
audience: [agent, developer]
last_reviewed: 2026-05-11
supersedes: []
tags: [architecture, audio]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_DEMO, ANVIL_DECISIONS, ANVIL_DETERMINISM]
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: [crates/anvil_bevy/src/audio, crates/anvil_demo/src/audio]
---

## Summary

The audio system is **asset-driven** (no procedural synthesis), **reactive**
(stem volumes follow simulation state), and **bit-deterministic at the mix
level** (same seed → same mix decisions). It is implemented in
`crates/anvil_bevy/src/audio/` and consumed by the demo through a thin
configuration shim at `crates/anvil_demo/src/audio/ashveil.rs`.

The architecture follows the same firewall discipline as the rest of
`anvil_bevy`: it reads simulation state but never writes back into the
deterministic crates. It exposes a small API (six public types) and uses
Bevy's event system for cue dispatch — never polling — so the simulation
can announce events to audio without coupling the two systems.

## §1 Module layout

```
crates/anvil_bevy/src/audio/
├── mod.rs           AudioPlugin (the one plugin to add)
├── seed.rs          AudioSeed + Xorshift64 (determinism anchor)
├── director.rs      AudioDirector + update_director system (state aggregator)
├── stems.rs         StemRegistry + Stem + update_stems system (score)
├── zones.rs         ZoneRegistry + Zone + update_zones system (positional ambience)
├── cues.rs          Cue events + StingerMap (communication channel)
├── ducking.rs       DuckingState + update_ducking (stinger ducking)
├── score.rs         MoodCurve helpers (catastrophe_arc, weather_threat, etc.)
├── output.rs        play_stingers system (one-shot playback)
└── tests/
    ├── determinism.rs   bit-deterministic mix proof
    └── cue_dispatch.rs  cue → stinger event flow proof
```

```
crates/anvil_demo/src/audio/
├── mod.rs        thin re-export
└── ashveil.rs    Ashveil-specific configuration (stems, zones, stinger map)
```

## §2 The five core types

| Type | Role | Mutability |
|---|---|---|
| `AudioSeed` | Master RNG seed. Subsystems derive sub-RNGs via stable hash. | Set once at startup. |
| `AudioDirector` | Central state: mood, phase, time, weather, body state. | Written by `update_director` once per frame. |
| `StemRegistry` | Owns the score's stems. | Mutated by `update_stems` (entity bookkeeping). |
| `ZoneRegistry` | Owns positional ambient zones. | Mutated by `update_zones` (entity bookkeeping). |
| `StingerMap` | Cue → stinger resolver. Per-project configuration. | Inserted by game code. |

Plus two event types (`Cue`, `PlayStinger`) and one ducking state resource.

## §3 Data flow

```
[Simulation]              [Audio system]                  [bevy_audio]
                                                                
  weather    ────┐                                              
  catastrophe ───┼─→ update_director ─→ AudioDirector ──┐       
  game_time  ────┘                                       │      
                                                          ▼      
                                       update_stems ──→ AudioPlayer entities
                                       update_zones ──→ AudioPlayer entities
                                                          ▲      
  cue events ─→ CueEmitter ─→ dispatch_cues ─→ PlayStinger event ──→ play_stingers
                                                  │              ▲
                                                  ▼              │
                                              update_ducking ────┘
                                              (DuckingState)
```

Every arrow is a Bevy `Res<T>` / `ResMut<T>` / `EventReader<E>` /
`EventWriter<E>`. No globals. No thread-locals. No `unsafe`.

## §4 The screech-bug invariant

The previous architecture had a class of bugs where a system checked
whether a stem was playing via one map and recorded the spawn via
another, with the two getting out of sync. The new architecture makes
this structurally impossible by enforcing three invariants:

1. **The bookkeeping field lives on the same struct as the spawn handle.**
   `Stem::entity` and `Zone::entity` are owned by the asset's own struct.
   There is no second map.
2. **The spawn and the bookkeeping write happen in the same function
   body, in the same `match` arm.** See `update_stems` in `stems.rs` and
   `update_zones` in `zones.rs`. Three lines apart, no early return,
   atomic with respect to the frame.
3. **A `debug_assert!` catches drift in dev builds.** If anyone in the
   future introduces a parallel spawn path, the debug build will panic
   the moment the bookkeeping disagrees with reality.

## §5 Determinism

The system promises **bit-deterministic mix decisions** given:
- Same `AudioSeed::from_world_seed(...)` input.
- Same per-frame `AudioDirector` state at each tick.
- Same sequence of `Cue` events.

It does **not** promise sample-accurate speaker output. OS audio backends
(PipeWire / ALSA / CoreAudio) buffer audio in chunks of variable size,
and the time at which a `set_volume` call reaches the speakers can drift
by up to one buffer period (~10 ms). The *content* of the mix is
identical run-to-run; the *time of arrival at the speaker* may not be.

This is acceptable because:
- Sim determinism is preserved (audio doesn't write back into the sim).
- Replays sound functionally identical to listeners.
- Recording two runs and diffing the resulting WAVs would show offset by
  up to one buffer; the samples themselves are bit-identical past that
  offset.

The `tests/determinism.rs` test proves the mix-decision claim by running
the plugin twice with identical inputs and asserting bit-equal stem
volumes after N frames.

### 5.1 RNG discipline

Audio code must never use:
- `rand::thread_rng()`
- `std::time::Instant::now()` or `SystemTime` for RNG seeding
- Any global mutable state for selection or jitter
- `f32` operations that are not commutative/associative when called in
  parallel (audio runs single-threaded via `chain()` in the plugin)

All RNG flows through `AudioSeed::rng_for(label)` where `label` is a
`'static str` identifying the subsystem. Same world seed + same label =
same RNG stream.

### 5.2 Stability caveat

`AudioSeed` uses `std::collections::hash_map::DefaultHasher` for the
master-seed-plus-label hash. This is stable *within a Rust release* but
not guaranteed across compiler versions. For cross-version determinism
we would need a custom stable hash function (e.g. fnv or wyhash with a
pinned implementation). This is out of scope for the current session;
flagged here so the constraint is visible.

## §6 Cue layer

Cues are the audio system's HUD substitute. The simulation announces
events; the audio system responds via stingers, ducking, and stem-state
shifts.

| Cue category | Examples | Audio response |
|---|---|---|
| `EmotionalCue` | ThreatRising, JoyPulse | Heartbeat shift, breath cadence (Phase 3) |
| `EnvironmentalCue` | PrecursorSignal, CatastropheIgnition, DebrisImpact | Stinger play, zone-bed shift |
| `NarrativeCue` | Beat, CommunityResilience | Score state transition |

Cues are consumed via `EventReader<Cue>`. **No polling**. The simulation
side is responsible for emitting cues at the right moment; the audio
system never inspects sim state to derive triggers.

## §7 Stem/zone distinction

| | Stems | Zones |
|---|---|---|
| Mixing | Global | Positional (distance falloff) |
| Use case | Score, drone, music | Wind, river, birds, village hum |
| Bookkeeping | `Stem::entity` | `Zone::entity` |
| Update system | `update_stems` | `update_zones` |
| Curve type | `MoodCurve = fn(&AudioDirector) -> f32` | `ZoneCurve = fn(&AudioDirector) -> f32` |

Both registries follow the same spawn/despawn/update discipline. The
split exists because mixing stems positionally would force every score
stem to carry a no-op position, and would couple two unrelated concerns.

## §8 Configuration vs infrastructure

The infrastructure in `anvil_bevy/src/audio/` knows nothing about
Ashveil. It does not know that there are six score stems, four zones, or
five catastrophe kinds. All of that is in `anvil_demo/src/audio/ashveil.rs`.

This means:
- The main game uses the same engine; it inserts its own `StemRegistry`,
  `ZoneRegistry`, and `StingerMap` contents.
- The demo can be reconfigured without touching the engine.
- Tests can exercise the engine with synthetic stems and zones.

## §9 What's deferred

The following are explicitly out of scope for the current session and
are tracked for future work:

- **Artistic curve tuning.** Every `MoodCurve` in `ashveil.rs` is marked
  `TUNE:` and uses provisional values. These must be tuned by ear with
  real assets playing.
- **Cue → stinger mapping table.** The `AshveilStingerResolver` returns
  `None` for everything. The mapping is data the project lead authors
  when stingers are sourced.
- **Audio debugging UI.** An egui panel showing stem volumes, active
  stingers, ducking state. Worth doing as its own focused session.
- **Hot-reloadable RON zone definitions.** Static `&'static [Zone]` for
  now; RON loader added when zones change frequently.
- **Stinger priority enum.** Add when the stinger catalogue grows past
  ~3–5 concurrent stingers.
- **Time-of-day zone variants** (day birds vs. night crickets).
  Requires double the asset count; defer until both sets exist.
- **Custom stable hash for cross-Rust-version determinism.** See §5.2.

These do not block any current deliverable. They are also non-blocking
for Phase 5 (reactive score arc) — the architecture supports them, the
content gates them.

## §10 Performance notes

The `update_stems` system iterates the stem registry once per frame.
Cost is O(stem count). For Ashveil (6 stems) this is trivially cheap.
`update_zones` is O(zone count) with one distance computation per zone.
For Ashveil (4 zones) also trivial.

Cue dispatch is O(cue events per frame), which is bounded by the
simulation's cue emission rate (typically <5 per second).

The audio system as a whole consumes <0.1 ms per frame on the dev
hardware. The cost dominators are inside `bevy_audio`'s decoding and the
OS audio subsystem, neither of which is under our control.

## §11 Tests

| Test | Proves |
|---|---|
| `seed::tests::same_world_seed_same_rng_stream` | Determinism contract holds at the RNG level. |
| `seed::tests::different_labels_diverge` | Subsystems don't accidentally share RNG state. |
| `stems::tests::registry_replaces_on_duplicate_id` | Registry idempotency. |
| `score::tests::*` | Mood-curve helpers behave as documented. |
| `tests/determinism.rs::same_seed_produces_same_volume_after_n_frames` | End-to-end mix determinism. |
| `tests/cue_dispatch.rs::*` | Cue → stinger event flow. |

Run with `cargo test -p anvil_bevy`.

## §12 Migration from v1.x

The old audio module (in `crates/anvil_demo/src/audio/`) had:

- `mod.rs` — `AmbientAudioPlugin` (the source of the double-registration crash)
- `demo_soundtrack.rs` — the screech bug's home
- `generator.rs` — procedural synthesis (now retired)
- `zones.rs` — positional zones with hardcoded narrative coordinates

All four are **deleted** by this migration. See `DELETIONS.md` in the
bundle for the exact removal list and the plugin-registration updates.

## §13 Changelog

- **2026-05-11 — v1.0.** Initial architecture. Replaces v1.x demo audio
  in full. Implements decisions from the 2026-05-11 audio session (see
  [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md)).
