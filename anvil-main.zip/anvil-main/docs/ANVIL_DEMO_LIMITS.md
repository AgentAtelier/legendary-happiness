---
id: ANVIL_DEMO_LIMITS
title: Demo Fidelity Limits and Walls
status: draft
audience: [agent, developer]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_DEMO, ANVIL_ROADMAP, ANVIL_DECISIONS]
owner: project_lead
version: 0.1
gate_scripts: []
code_paths: []
---

## Summary

Phase 6 of the Ashveil demo (see [`ANVIL_DEMO`](ANVIL_DEMO.md) §5.6) attempts AAA-level polish in lighting, weather, and sound, falling back to lower fidelity only when forced. This document records every fall: what was attempted, how far it got, what would be needed to close the remaining gap. The file is the *honest record* of where solo-dev with the current toolchain hits a wall.

The file is intended as input to the main project's planning. Some walls will be acknowledged and accepted ("we can't reach this fidelity without commissioning this work, defer to post-release"). Others will become engineering targets ("this gap is closable with N weeks of focused work; schedule it for Phase 4 of the main project").

The document is `status: draft` until Phase 6 begins. During Phase 6 it accumulates entries pass-by-pass. After Phase 6 closes, status promotes to `active` and the file becomes a permanent reference for main-project planning.

---

## Schema

Each entry is a Pass × Item record. The schema:

```
### <Pass>: <Item>

- **Target.** What AAA-level looks like for this item. One paragraph.
- **What we tried.** The specific implementation attempted.
- **Where we got.** The fidelity actually delivered, in concrete terms.
- **Wall.** What blocked further progress. Performance / engineering effort / asset cost / tooling gap / etc.
- **Gap.** What would close the wall. Specific.
- **Recommendation.** One of: accept-and-move-on / schedule for main project / commission / defer indefinitely.
- **Date.** When this entry was filled.
```

Entries are appended chronologically per pass. Order within the document follows the Phase 6 pass order: lighting, weather, sound, glitch elimination, integration polish.

---

## Pass 1 — Lighting

*(Empty until Phase 6 begins.)*

---

## Pass 2 — Weather

*(Empty until Phase 6 begins.)*

---

## Pass 3 — Sound

*(Empty until Phase 6 begins.)*

---

## Pass 4 — Glitch elimination

*(Empty until Phase 6 begins. Will record any class of glitch that resisted elimination, with rationale.)*

---

## Pass 5 — Integration polish

*(Empty until Phase 6 begins.)*

---

## Aggregate observations

*(Empty until Phase 6 closes. After Phase 6, this section synthesises across passes: which classes of wall recurred, which areas hit walls together, what the pattern says about solo-dev fidelity ceiling for an engine of this shape.)*

---

## How this file is used

- **By the project lead during Phase 6.** Each pass's exploration produces entries here as it proceeds. The act of writing the entry is part of the discipline — articulating *why* something is at the level it is forces the level itself to be honest.
- **By the project lead after Phase 6.** When planning the main project, every wall that's reasonable to close becomes a candidate work-item with known scope.
- **By future contributors and AI agents.** The file is the project's institutional memory of "here's where we hit ceilings and what they were." Without it, future planning re-derives walls that this file already names.

---

## Discipline

- Entries should be specific. "The fog wasn't quite right" is not an entry. "Volumetric fog at density 0.4 holds 30 fps; AAA Stalker-2 look needs density ~1.2; the gap is GPU-bound under bloom + dynamic lights" is an entry.
- Acceptance is a valid recommendation. Not every wall must be closable. Recording acceptance with rationale is part of the file's value.
- Entries must not be deleted. If a wall is later closed, the original entry stays and a follow-up entry records the closure with reference. Walls and their closures both teach.
