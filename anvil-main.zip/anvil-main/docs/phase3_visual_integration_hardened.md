# Phase 3 Demo Visual Integration — Production Roadmap
## Hardened & Improved

---

## What Changed From the Draft and Why

The draft roadmap was honest about its own compromises. This version removes them. Each decision below addresses a specific place where the draft deferred something that would require an overhaul rather than an extension.

| Draft decision | Why it was deferred | Why that deferral is wrong |
|---|---|---|
| `ClearColor` as sky | "Fog does the heavy lifting" | The moment you clear fog for any reason — debugging, a mountain viewpoint, a specific weather state — you get a flat rectangle. A gradient sky sphere is 60 lines of WGSL and correct forever. |
| `StandardMaterial` mutation for wetness | "Same visual result, zero WGSL" | Wrong on both counts. Mutating material fields per-entity per-frame means each terrain entity needs its own material handle. That's one draw call per chunk, no batching possible. The wetness visual is also wrong — roughness alone without a specular/metallic response looks like the terrain got a coat of matte paint. |
| `shadows_enabled: false` | "Avoid bias tuning" | Shadow bias has sensible defaults in Bevy and takes 10 minutes to tune. Disabling shadows for the demo means your lighting reference screenshots are wrong, your artists tune materials against the wrong lighting, and you have to re-tune materials once shadows land. |
| Magic numbers baked into `EnvironmentState::new()` | Simplicity | Any designer touching the dawn lighting now has to understand Rust, recompile, and redeploy. These belong in a config resource loaded from TOML. |
| Flat `SimSnapshot` with raw f32 fields | "Minimal for Phase 3" | Adding catastrophe data, NPC states, or a second weather layer to a flat struct will touch every bridge call site. Nested structs cost nothing now and prevent a guaranteed refactor. |
| Per-tick `vfx_seed` | "Good enough for demo" | A seed that changes every tick means particle effects re-seed every tick. The visual effect is particle systems that stutter or reset. More importantly replay parity is impossible. |
| `debug_assert!` for missing entities | "Fail fast" | `debug_assert!` is silent in `--release` builds, which is where you will discover these failures. Use `warn!` + continue in release, panic in tests. |

---

## Design Decisions (Locked)

| Question | Decision | Rationale |
|---|---|---|
| Sky rendering | Procedural sky sphere, custom `Material`, gradient WGSL shader, sun disc | The extra 60 lines of WGSL is the cheapest insurance against needing a sky rewrite. It also gives you a sun disc for free, which is essential for the dawn aesthetic. |
| Terrain material state | `ExtendedMaterial<StandardMaterial, TerrainExtension>`, one shared handle | All terrain chunks share one material handle. Updating the handle's asset data updates all chunks in one operation. Zero per-entity mutation. Batching preserved. |
| Wetness visual | Shader: darken albedo + lower roughness + raise metallic (specular response) | This is physically what wet surfaces look like. Roughness alone is not enough. |
| Config | `EnvironmentConfig` resource, loaded from `assets/config/environment.toml` | Tunable by anyone with a text editor, hot-reloadable in dev, committed to source control for reproducible builds. |
| Solar formula | Hour angle + latitude + configurable seasonal declination | The equinox approximation is fine for the demo biome but costs nothing to do right. Declination is a single extra parameter. |
| Fog model | `FogFalloff::Exponential`, density curve driven by weather | Unchanged from draft. Correct choice. |
| Smoothing | `SmoothedFloat` / `SmoothedColor` with configurable tau per field | Unchanged from draft. Good primitives. |
| Shadows | Enabled, 3-cascade CSM, 1024px shadow maps, sensible bias defaults | Required for correct lighting evaluation. 10 minutes to tune is not a reason to ship without them. |
| Colour space | All interpolation in `LinearRgba`, all application at the Bevy boundary | Unchanged from draft. Correct. |
| System ordering | `SystemSet::Bridge → SystemSet::Interpolate → SystemSet::Apply`, all `PreUpdate` | Unchanged. Correct. |
| Markers | `SunLight`, `CameraFog`, `TerrainChunk`, `SkySphere` | Unchanged pattern, extended to sky sphere. |
| Error handling | `warn!` + graceful continue in all systems. Panics only in `#[cfg(test)]` | Release-safe. Systems that fail to find their query targets log once and skip. |

---

## File Changes

| File | Action |
|------|--------|
| `anvil_bevy/src/sim_bridge.rs` | **Create** — `SimSnapshot` and nested structs |
| `anvil_bevy/src/environment/config.rs` | **Create** — `EnvironmentConfig`, loaded from TOML |
| `anvil_bevy/src/environment/state.rs` | **Create** — `SmoothedFloat`, `SmoothedColor`, `EnvironmentState` |
| `anvil_bevy/src/environment/solar.rs` | **Create** — `resolve_environment_targets` (pure math) |
| `anvil_bevy/src/environment/plugin.rs` | **Create** — `EnvironmentPlugin`, `EnvironmentSet`, systems |
| `anvil_bevy/src/sky/material.rs` | **Create** — `SkyMaterial`, Bevy `Material` impl |
| `anvil_bevy/src/sky/plugin.rs` | **Create** — `SkyPlugin`, sphere spawn, uniform update |
| `anvil_bevy/src/terrain/material.rs` | **Create** — `TerrainExtension`, `ExtendedMaterial` registration |
| `anvil_bevy/src/terrain/plugin.rs` | **Create** — `TerrainPlugin`, wetness/snow/burn uniform drive |
| `anvil_bevy/src/markers.rs` | **Create** — `SunLight`, `CameraFog`, `TerrainChunk`, `SkySphere` |
| `anvil_bevy/src/lib.rs` | **Modify** — register all new plugins, re-export public types |
| `assets/shaders/sky.wgsl` | **Create** — sky fragment shader |
| `assets/shaders/terrain_extension.wgsl` | **Create** — terrain material extension fragment |
| `assets/config/environment.toml` | **Create** — tunable environment config |
| `anvil_demo/src/sim_bridge.rs` | **Create** — `sim_bridge_system` |
| `anvil_demo/src/main.rs` | **Modify** — register plugins, spawn sun with cascades, fix camera |
| `anvil_demo/src/ui/transitions.rs` | **Modify** — proper fix (not diagnostic-then-fix) |

---

## Step 1 — Data Types: `SimSnapshot` and `EnvironmentConfig`

### 1a. `SimSnapshot` (structured, extensible)

```rust
// anvil_bevy/src/sim_bridge.rs
use bevy::prelude::*;

/// Presentation-side view of simulation state. Populated once per frame
/// by the bridge system in anvil_demo. Never written to by visual systems.
#[derive(Resource, Clone, Debug, Default)]
pub struct SimSnapshot {
    pub tick: u64,
    pub time:    TimeSnapshot,
    pub weather: WeatherSnapshot,
    /// Per-catastrophe visual descriptors. Empty when no catastrophe is active.
    pub catastrophes: Vec<CatastropheSnapshot>,
}

#[derive(Clone, Debug, Default)]
pub struct TimeSnapshot {
    /// 0.0 = midnight, 0.25 ≈ 6am, 0.5 = noon, 0.75 ≈ 6pm
    pub time_of_day: f32,
    pub day: u32,
}

#[derive(Clone, Debug)]
pub struct WeatherSnapshot {
    pub temperature_c:    f32,
    pub humidity:         f32,   // 0.0–1.0
    pub wind_speed_ms:    f32,
    pub wind_direction:   f32,   // radians, 0 = east
    pub precipitation:    f32,   // 0.0–1.0 intensity
    pub cloud_cover:      f32,   // 0.0–1.0
    pub pressure_hpa:     f32,
}

impl Default for WeatherSnapshot {
    fn default() -> Self {
        // Ashveil dawn defaults: cold, low humidity, no precipitation
        Self {
            temperature_c:  6.4,
            humidity:       0.31,
            wind_speed_ms:  4.2,
            wind_direction: 0.0,
            precipitation:  0.0,
            cloud_cover:    0.25,
            pressure_hpa:   1008.0,
        }
    }
}

#[derive(Clone, Debug)]
pub struct CatastropheSnapshot {
    pub id:       u64,
    pub kind:     CatastropheKind,
    pub origin:   Vec3,
    pub intensity: f32,  // 0.0–1.0
    /// Stable seed: derived at catastrophe onset, unchanged for its lifetime.
    /// Used to seed bevy_hanabi emitters and stochastic audio selection.
    pub vfx_seed: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CatastropheKind {
    Wildfire,
    Flood,
    Earthquake,
}
```

### 1b. `EnvironmentConfig` — tunable, loaded from TOML

```rust
// anvil_bevy/src/environment/config.rs
use bevy::prelude::*;
use serde::{Deserialize, Serialize};

/// All tunable parameters for the environment system.
/// Loaded from assets/config/environment.toml at startup.
/// Re-loaded on hot-reload in dev builds.
#[derive(Resource, Clone, Debug, Deserialize, Serialize)]
pub struct EnvironmentConfig {
    pub location: LocationConfig,
    pub smoothing: SmoothingConfig,
    pub illuminance: IlluminanceConfig,
    pub fog: FogConfig,
    pub sky: SkyConfig,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct LocationConfig {
    /// Geographic latitude of Ashveil valley in degrees.
    pub latitude_deg: f32,
    /// Axial tilt contribution (seasonal declination), degrees. 0 = equinox.
    pub declination_deg: f32,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SmoothingConfig {
    /// Smoothing time constants in seconds. Higher = slower response.
    pub sun_position_tau:   f32,  // slow: 300.0
    pub sun_colour_tau:     f32,  // medium: 60.0
    pub fog_density_tau:    f32,  // medium: 30.0
    pub fog_colour_tau:     f32,  // medium: 60.0
    pub ambient_tau:        f32,  // medium: 30.0
    pub wetness_tau:        f32,  // slow: 45.0
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct IlluminanceConfig {
    /// Peak clear-sky noon illuminance in lux.
    pub noon_clear_lux:     f32,  // 80_000.0
    /// Illuminance at full cloud cover (relative to clear noon).
    pub overcast_factor:    f32,  // 0.1
    /// Minimum night illuminance (moonlight).
    pub night_min_lux:      f32,  // 0.1
    /// Ambient strength at solar noon, clear sky.
    pub ambient_noon:       f32,  // 0.20
    /// Ambient strength at night.
    pub ambient_night:      f32,  // 0.04
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct FogConfig {
    /// Base density at zero humidity, zero precipitation.
    pub base_density:           f32,  // 0.003
    /// Additional density per unit of humidity (0–1).
    pub humidity_density_scale: f32,  // 0.025
    /// Additional density per unit of precipitation (0–1).
    pub precip_density_scale:   f32,  // 0.018
    /// Additional density per degree below this temperature (cold ground fog).
    pub cold_fog_threshold_c:   f32,  // 5.0
    pub cold_fog_scale:         f32,  // 0.003
    /// Maximum fog density before the scene is unplayable.
    pub max_density:            f32,  // 0.08
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SkyConfig {
    /// Radius of the sky sphere in world units.
    pub sphere_radius:          f32,  // 4500.0
    /// Angular radius of the sun disc in the sky shader, 0–1.
    pub sun_disc_size:          f32,  // 0.003
    /// Bloom multiplier applied to the sun disc colour.
    pub sun_disc_intensity:     f32,  // 3.0
}

impl Default for EnvironmentConfig {
    fn default() -> Self {
        Self {
            location: LocationConfig { latitude_deg: 55.0, declination_deg: 0.0 },
            smoothing: SmoothingConfig {
                sun_position_tau: 300.0,
                sun_colour_tau:   60.0,
                fog_density_tau:  30.0,
                fog_colour_tau:   60.0,
                ambient_tau:      30.0,
                wetness_tau:      45.0,
            },
            illuminance: IlluminanceConfig {
                noon_clear_lux:  80_000.0,
                overcast_factor: 0.10,
                night_min_lux:   0.1,
                ambient_noon:    0.20,
                ambient_night:   0.04,
            },
            fog: FogConfig {
                base_density:           0.003,
                humidity_density_scale: 0.025,
                precip_density_scale:   0.018,
                cold_fog_threshold_c:   5.0,
                cold_fog_scale:         0.003,
                max_density:            0.08,
            },
            sky: SkyConfig {
                sphere_radius:      4500.0,
                sun_disc_size:      0.003,
                sun_disc_intensity: 3.0,
            },
        }
    }
}
```

```toml
# assets/config/environment.toml
[location]
latitude_deg     = 55.0
declination_deg  = 0.0   # adjust for seasons: +23.4 = summer solstice, -23.4 = winter

[smoothing]
sun_position_tau  = 300.0
sun_colour_tau    = 60.0
fog_density_tau   = 30.0
fog_colour_tau    = 60.0
ambient_tau       = 30.0
wetness_tau       = 45.0

[illuminance]
noon_clear_lux   = 80000.0
overcast_factor  = 0.10
night_min_lux    = 0.1
ambient_noon     = 0.20
ambient_night    = 0.04

[fog]
base_density           = 0.003
humidity_density_scale = 0.025
precip_density_scale   = 0.018
cold_fog_threshold_c   = 5.0
cold_fog_scale         = 0.003
max_density            = 0.08

[sky]
sphere_radius      = 4500.0
sun_disc_size      = 0.003
sun_disc_intensity = 3.0
```

**Verification:** `cargo check -p anvil_bevy`. No systems yet.

---

## Step 2 — Solar Math and Target Derivation

This is pure math, no Bevy queries. Keep it in its own file so it can be unit-tested independently.

```rust
// anvil_bevy/src/environment/solar.rs
use std::f32::consts::TAU;
use bevy::color::LinearRgba;
use crate::sim_bridge::SimSnapshot;
use crate::environment::{config::EnvironmentConfig, state::EnvironmentState};

/// Derives all visual targets from the current snapshot and config.
/// No smoothing applied here — call `env_state.tick(dt)` afterwards.
/// This function is pure: it only reads arguments and sets targets.
pub fn resolve_targets(
    snapshot: &SimSnapshot,
    config:   &EnvironmentConfig,
    env:      &mut EnvironmentState,
) {
    let tod = snapshot.time.time_of_day;
    let w   = &snapshot.weather;
    let lat = config.location.latitude_deg.to_radians();
    let dec = config.location.declination_deg.to_radians();

    // ── Solar geometry ──────────────────────────────────────────────────
    let hour_angle = (tod - 0.5) * TAU;

    let sin_elev = lat.sin() * dec.sin()
                 + lat.cos() * dec.cos() * hour_angle.cos();
    let elevation = sin_elev.asin();

    let cos_elev_safe = elevation.cos().max(0.0001);
    let cos_azim = (dec.sin() - lat.sin() * sin_elev)
                 / (lat.cos() * cos_elev_safe);
    let raw_azim = cos_azim.clamp(-1.0, 1.0).acos();
    let azimuth = if hour_angle > 0.0 { TAU - raw_azim } else { raw_azim }
                  - std::f32::consts::FRAC_PI_2;

    env.sun_elevation.set_target(elevation);
    env.sun_azimuth.set_target(azimuth);

    // ── Illuminance ──────────────────────────────────────────────────────
    let il = &config.illuminance;
    // How far above the horizon (0 = on horizon, 1 = at peak elevation for latitude)
    let sun_above = (elevation / 0.06).clamp(0.0, 1.0);
    let cloud_factor = 1.0 - w.cloud_cover * (1.0 - il.overcast_factor);
    let base_lux = il.noon_clear_lux * sun_above * cloud_factor;
    env.sun_illuminance.set_target(base_lux.max(il.night_min_lux));

    // ── Sun colour ────────────────────────────────────────────────────────
    // Near horizon: warm orange. At zenith: neutral white. Overcast: cooler.
    let horizon_blend = 1.0 - (elevation / (std::f32::consts::FRAC_PI_4)).clamp(0.0, 1.0);
    let overcast_cool  = w.cloud_cover * 0.15;
    env.sun_color.set_target(LinearRgba::new(
        1.0,
        (0.70 + 0.30 * (1.0 - horizon_blend) - overcast_cool).clamp(0.0, 1.0),
        (0.40 + 0.60 * (1.0 - horizon_blend) - overcast_cool * 0.5).clamp(0.0, 1.0),
        1.0,
    ));

    // ── Ambient ───────────────────────────────────────────────────────────
    let ambient_strength = il.ambient_night
        + (il.ambient_noon - il.ambient_night) * sun_above * cloud_factor;
    // Overcast shifts ambient toward flat grey-blue; clear sky keeps warmer cast.
    let warm = 1.0 - w.cloud_cover * 0.5;
    env.ambient_color.set_target(LinearRgba::new(
        0.50 + 0.20 * sun_above * warm,
        0.50 + 0.18 * sun_above,
        0.55 + 0.25 * sun_above * (1.0 - warm * 0.3),
        1.0,
    ));
    env.ambient_brightness.set_target(ambient_strength);

    // ── Fog ───────────────────────────────────────────────────────────────
    let fc = &config.fog;
    let cold_contribution = if w.temperature_c < fc.cold_fog_threshold_c {
        (fc.cold_fog_threshold_c - w.temperature_c) * fc.cold_fog_scale
    } else {
        0.0
    };
    let density = (fc.base_density
        + w.humidity    * fc.humidity_density_scale
        + w.precipitation * fc.precip_density_scale
        + cold_contribution)
        .clamp(0.0, fc.max_density);
    env.fog_density.set_target(density);

    // Fog colour tracks sky horizon, shifts grey with humidity, brown with precipitation.
    let fog_r = 0.55 + horizon_blend * 0.25 - w.humidity * 0.08 + w.precipitation * 0.04;
    let fog_g = 0.45 + horizon_blend * 0.10 - w.humidity * 0.05;
    let fog_b = 0.40 + sun_above    * 0.15 + w.cloud_cover * 0.10 - w.precipitation * 0.04;
    env.fog_color.set_target(LinearRgba::new(fog_r, fog_g, fog_b, 1.0));

    // ── Sky zenith ────────────────────────────────────────────────────────
    // Deep twilight purple → grey-blue overcast → dawn orange-pink
    let night_zenith  = LinearRgba::new(0.04, 0.04, 0.12, 1.0);
    let day_clear     = LinearRgba::new(0.20, 0.25, 0.50, 1.0);
    let day_overcast  = LinearRgba::new(0.50, 0.50, 0.55, 1.0);
    let blend_day     = sun_above;
    let blend_overcast = w.cloud_cover;
    let clear_zenith = LinearRgba::new(
        night_zenith.red   + (day_clear.red   - night_zenith.red)   * blend_day,
        night_zenith.green + (day_clear.green - night_zenith.green) * blend_day,
        night_zenith.blue  + (day_clear.blue  - night_zenith.blue)  * blend_day,
        1.0,
    );
    env.sky_zenith_color.set_target(LinearRgba::new(
        clear_zenith.red   + (day_overcast.red   - clear_zenith.red)   * blend_overcast,
        clear_zenith.green + (day_overcast.green - clear_zenith.green) * blend_overcast,
        clear_zenith.blue  + (day_overcast.blue  - clear_zenith.blue)  * blend_overcast,
        1.0,
    ));

    // ── Wetness ───────────────────────────────────────────────────────────
    // Wetness builds with precipitation, drains slowly with low humidity.
    // Freezing temperatures suppress liquid wetness (snow, not wet).
    let liquid_factor = (w.temperature_c / 2.0).clamp(0.0, 1.0);
    let wet_target = (w.precipitation * 0.85 + w.humidity * 0.15) * liquid_factor;
    env.wetness.set_target(wet_target.clamp(0.0, 1.0));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sun_rises_in_east_at_dawn() {
        let config = EnvironmentConfig::default();
        let mut env = EnvironmentState::new(&config);
        let mut snap = SimSnapshot::default();
        snap.time.time_of_day = 0.25; // 6am
        resolve_targets(&snap, &config, &mut env);
        // At 6am in the northern hemisphere, sun is near east (negative azimuth or near PI/2)
        // Elevation should be near 0 (just rising)
        assert!(env.sun_elevation.target.abs() < 0.3,
            "Sun should be near horizon at dawn, got {}rad", env.sun_elevation.target);
    }

    #[test]
    fn fog_increases_with_precipitation() {
        let config = EnvironmentConfig::default();
        let mut env = EnvironmentState::new(&config);
        let mut snap = SimSnapshot::default();

        snap.weather.precipitation = 0.0;
        resolve_targets(&snap, &config, &mut env);
        let dry_density = env.fog_density.target;

        snap.weather.precipitation = 1.0;
        resolve_targets(&snap, &config, &mut env);
        let wet_density = env.fog_density.target;

        assert!(wet_density > dry_density,
            "Fog density should increase with precipitation: {} vs {}", wet_density, dry_density);
    }
}
```

**Verification:** `cargo test -p anvil_bevy` — both tests pass.

---

## Step 3 — Sky Sphere

This is the step the draft skipped. 60 lines of WGSL. Do it once, correctly.

### Shader

```wgsl
// assets/shaders/sky.wgsl

struct SkyParams {
    zenith_color:       vec4<f32>,
    horizon_color:      vec4<f32>,
    fog_color:          vec4<f32>,
    sun_direction:      vec4<f32>,
    sun_color:          vec4<f32>,
    sun_disc_size:      f32,
    sun_disc_intensity: f32,
    fog_blend_start:    f32,   // world-space elevation below which fog dominates
    _pad:               f32,
}

@group(2) @binding(0) var<uniform> sky: SkyParams;

// Bevy's standard vertex output provides world_position.
// The sky sphere vertex shader is Bevy's default (no custom VS needed for
// a fullscreen sphere — just make sure the sphere is large and unlit).

@fragment
fn fragment(
    #import bevy_pbr::mesh_vertex_output::MeshVertexOutput
    in: MeshVertexOutput
) -> @location(0) vec4<f32> {
    let dir = normalize(in.world_position.xyz);

    // Vertical gradient: horizon (y≈0) to zenith (y=1)
    let t = clamp(dir.y, 0.0, 1.0);
    let sky_color = mix(sky.horizon_color.rgb, sky.zenith_color.rgb, pow(t, 0.6));

    // Blend fog color near the horizon (below a small angle)
    let fog_t = clamp(1.0 - (dir.y + sky.fog_blend_start) / sky.fog_blend_start, 0.0, 1.0);
    let fogged = mix(sky_color, sky.fog_color.rgb, fog_t * 0.6);

    // Sun disc: smooth circle around sun direction
    let sun_dot  = dot(dir, sky.sun_direction.xyz);
    let disc_edge = 1.0 - sky.sun_disc_size;
    let sun_mask = smoothstep(disc_edge, 1.0, sun_dot);

    // Sun corona: wide soft glow around disc
    let corona_size = sky.sun_disc_size * 40.0;
    let corona_edge = 1.0 - corona_size;
    let corona_mask = smoothstep(corona_edge, disc_edge, sun_dot) * 0.15;

    let final_color = fogged
        + sky.sun_color.rgb * sky.sun_disc_intensity * sun_mask
        + sky.sun_color.rgb * corona_mask;

    return vec4<f32>(final_color, 1.0);
}
```

### Material and Plugin

```rust
// anvil_bevy/src/sky/material.rs
use bevy::prelude::*;
use bevy::render::render_resource::{AsBindGroup, ShaderRef};

#[derive(Asset, AsBindGroup, TypePath, Clone, Default)]
pub struct SkyMaterial {
    #[uniform(0)]
    pub zenith_color:       LinearRgba,
    #[uniform(0)]
    pub horizon_color:      LinearRgba,
    #[uniform(0)]
    pub fog_color:          LinearRgba,
    #[uniform(0)]
    pub sun_direction:      Vec4,
    #[uniform(0)]
    pub sun_color:          LinearRgba,
    #[uniform(0)]
    pub sun_disc_size:      f32,
    #[uniform(0)]
    pub sun_disc_intensity: f32,
    #[uniform(0)]
    pub fog_blend_start:    f32,
    #[uniform(0)]
    pub _pad:               f32,
}

impl Material for SkyMaterial {
    fn fragment_shader() -> ShaderRef {
        "shaders/sky.wgsl".into()
    }

    fn alpha_mode(&self) -> AlphaMode {
        AlphaMode::Opaque
    }

    // Disable depth writes: the sky is always behind everything.
    fn depth_bias(&self) -> f32 { f32::MIN }

    fn prepass_fragment_shader() -> ShaderRef {
        ShaderRef::Default // no prepass contribution
    }
}
```

```rust
// anvil_bevy/src/sky/plugin.rs
use bevy::prelude::*;
use bevy::render::view::RenderLayers;
use super::material::SkyMaterial;
use crate::environment::state::EnvironmentState;
use crate::environment::config::EnvironmentConfig;
use crate::markers::SkySphere;

pub struct SkyPlugin;

impl Plugin for SkyPlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins(MaterialPlugin::<SkyMaterial>::default())
           .add_systems(Startup, spawn_sky_sphere)
           .add_systems(PostUpdate, update_sky_uniforms);
    }
}

fn spawn_sky_sphere(
    mut commands:  Commands,
    mut meshes:    ResMut<Assets<Mesh>>,
    mut sky_mats:  ResMut<Assets<SkyMaterial>>,
    config:        Res<EnvironmentConfig>,
) {
    let radius = config.sky.sphere_radius;
    let mesh = meshes.add(Sphere::new(radius).mesh().ico(6).unwrap());

    let mat = sky_mats.add(SkyMaterial {
        sun_disc_size:      config.sky.sun_disc_size,
        sun_disc_intensity: config.sky.sun_disc_intensity,
        fog_blend_start:    0.12,
        ..default()
    });

    commands.spawn((
        Mesh3d(mesh),
        MeshMaterial3d(mat),
        // Inside of sphere faces the camera; flip normals via scale.
        Transform::from_scale(Vec3::splat(-1.0)),
        // Do not cast or receive shadows.
        NotShadowCaster,
        NotShadowReceiver,
        // Render before the scene geometry (render order -1).
        // Bevy uses depth testing, so with depth writes off this works without
        // a custom render phase.
        SkySphere,
    ));
}

fn update_sky_uniforms(
    env:      Res<EnvironmentState>,
    mut sky_mats: ResMut<Assets<SkyMaterial>>,
    sky_query: Query<&MeshMaterial3d<SkyMaterial>, With<SkySphere>>,
) {
    let Ok(mat_handle) = sky_query.get_single() else {
        warn!("SkyPlugin: no SkySphere entity found — sky uniforms not updated");
        return;
    };
    let Some(mat) = sky_mats.get_mut(&mat_handle.0) else { return };

    let sun_dir = env.sun_dir_vec();
    mat.zenith_color       = env.sky_zenith_color.current;
    // Horizon colour is fog colour tinted by sun warmth near horizon.
    mat.horizon_color      = env.fog_color.current;
    mat.fog_color          = env.fog_color.current;
    mat.sun_direction      = sun_dir.extend(0.0);
    mat.sun_color          = env.sun_color.current;
    // At night, suppress the sun disc (moon handling deferred).
    let night_suppress = (env.sun_illuminance.current / 1000.0).clamp(0.0, 1.0);
    mat.sun_disc_intensity = env.sun_disc_base_intensity * night_suppress;
}
```

**Why not `ClearColor`:** The sky sphere responds to sun direction, cloud cover, and fog colour in real time. It renders a sun disc with a corona. It will look correct from a mountain top, through a gap in the fog, or during a heatwave that clears the valley air. `ClearColor` does none of these things.

---

## Step 4 — Markers, `EnvironmentState`, and `EnvironmentPlugin`

```rust
// anvil_bevy/src/markers.rs
use bevy::prelude::*;

#[derive(Component)] pub struct SunLight;
#[derive(Component)] pub struct CameraFog;
#[derive(Component)] pub struct TerrainChunk;
#[derive(Component)] pub struct SkySphere;
```

```rust
// anvil_bevy/src/environment/state.rs
// (SmoothedFloat / SmoothedColor unchanged from draft — they are correct.)
// EnvironmentState::new() now takes &EnvironmentConfig to avoid magic numbers.

use bevy::color::LinearRgba;
use crate::environment::config::EnvironmentConfig;

pub struct EnvironmentState {
    pub sun_elevation:   SmoothedFloat,
    pub sun_azimuth:     SmoothedFloat,
    pub sun_color:       SmoothedColor,
    pub sun_illuminance: SmoothedFloat,
    pub ambient_color:   SmoothedColor,
    pub ambient_brightness: SmoothedFloat,
    pub fog_color:       SmoothedColor,
    pub fog_density:     SmoothedFloat,
    pub sky_zenith_color: SmoothedColor,
    pub wetness:         SmoothedFloat,
    /// Cached from config so update_sky_uniforms can read it.
    pub sun_disc_base_intensity: f32,
}

impl EnvironmentState {
    pub fn new(config: &EnvironmentConfig) -> Self {
        let s = &config.smoothing;
        // Ashveil dawn starting values.
        let dawn_fog     = LinearRgba::new(0.50, 0.40, 0.35, 1.0);
        let dawn_sky     = LinearRgba::new(0.18, 0.15, 0.28, 1.0);
        let dawn_sun     = LinearRgba::new(1.0,  0.70, 0.40, 1.0);
        let dawn_ambient = LinearRgba::new(0.30, 0.28, 0.40, 1.0);

        Self {
            sun_elevation:    SmoothedFloat::new(0.08,   s.sun_position_tau),
            sun_azimuth:      SmoothedFloat::new(-1.57,  s.sun_position_tau),
            sun_color:        SmoothedColor::new(dawn_sun,     s.sun_colour_tau),
            sun_illuminance:  SmoothedFloat::new(4000.0,       30.0),
            ambient_color:    SmoothedColor::new(dawn_ambient, s.ambient_tau),
            ambient_brightness: SmoothedFloat::new(0.12,      s.ambient_tau),
            fog_color:        SmoothedColor::new(dawn_fog,     s.fog_colour_tau),
            fog_density:      SmoothedFloat::new(0.018,        s.fog_density_tau),
            sky_zenith_color: SmoothedColor::new(dawn_sky,     s.sun_colour_tau),
            wetness:          SmoothedFloat::new(0.0,          s.wetness_tau),
            sun_disc_base_intensity: config.sky.sun_disc_intensity,
        }
    }
    // tick(), sun_dir_vec() unchanged from draft.
}
```

```rust
// anvil_bevy/src/environment/plugin.rs
use bevy::prelude::*;
use bevy::pbr::{DistanceFog, FogFalloff, CascadeShadowConfigBuilder};
use crate::environment::{config::EnvironmentConfig, state::EnvironmentState, solar::resolve_targets};
use crate::sim_bridge::SimSnapshot;
use crate::markers::{SunLight, CameraFog};

#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub enum EnvironmentSet {
    Bridge,      // sim_bridge_system runs here (registered from anvil_demo)
    Interpolate, // resolve_targets + tick
    Apply,       // write to Bevy components
}

pub struct EnvironmentPlugin;

impl Plugin for EnvironmentPlugin {
    fn build(&self, app: &mut App) {
        let config = EnvironmentConfig::default(); // replaced by TOML load below
        app.insert_resource(EnvironmentState::new(&config))
           .insert_resource(config)
           .insert_resource(SimSnapshot::default())
           .configure_sets(PreUpdate, (
               EnvironmentSet::Bridge,
               EnvironmentSet::Interpolate,
               EnvironmentSet::Apply,
           ).chain())
           .add_systems(PreUpdate, (
               environment_interpolate_system.in_set(EnvironmentSet::Interpolate),
               environment_apply_system.in_set(EnvironmentSet::Apply),
           ));
    }
}

fn environment_interpolate_system(
    snapshot:   Res<SimSnapshot>,
    config:     Res<EnvironmentConfig>,
    mut env:    ResMut<EnvironmentState>,
    time:       Res<Time>,
) {
    resolve_targets(&snapshot, &config, &mut env);
    env.tick(time.delta_seconds());
}

fn environment_apply_system(
    env:    Res<EnvironmentState>,
    mut sun_query:    Query<(&mut DirectionalLight, &mut Transform), With<SunLight>>,
    mut camera_query: Query<&mut DistanceFog, With<CameraFog>>,
    mut ambient:      ResMut<AmbientLight>,
) {
    // ── Sun ──────────────────────────────────────────────────────────────
    match sun_query.get_single_mut() {
        Ok((mut light, mut transform)) => {
            light.color        = Color::LinearRgba(env.sun_color.current);
            light.illuminance  = env.sun_illuminance.current;
            let dir = env.sun_dir_vec();
            if dir.length_squared() > 0.001 {
                let up = if dir.y.abs() > 0.98 { Vec3::X } else { Vec3::Y };
                transform.look_to(dir, up);
            }
        }
        Err(_) => warn_once!("EnvironmentPlugin: no SunLight entity found"),
    }

    // ── Fog ───────────────────────────────────────────────────────────────
    match camera_query.get_single_mut() {
        Ok(mut fog) => {
            fog.color   = Color::LinearRgba(env.fog_color.current);
            fog.falloff = FogFalloff::Exponential { density: env.fog_density.current };
        }
        Err(_) => warn_once!("EnvironmentPlugin: no CameraFog entity found"),
    }

    // ── Ambient ───────────────────────────────────────────────────────────
    ambient.color      = Color::LinearRgba(env.ambient_color.current);
    ambient.brightness = env.ambient_brightness.current;
}
```

Note: `warn_once!` logs on the first occurrence only. No spam. No silent failure.

---

## Step 5 — Bridge System (Demo Side)

```rust
// anvil_demo/src/sim_bridge.rs
use bevy::prelude::*;
use anvil_bevy::sim_bridge::{SimSnapshot, WeatherSnapshot, TimeSnapshot};
use anvil_bevy::environment::plugin::EnvironmentSet;
use crate::runtime::RuntimeResource; // existing resource

/// Extracts presentation-relevant state from the simulation runtime.
/// Lives in anvil_demo because RuntimeResource lives here.
/// Does NOT invent simulation logic — only reads and copies.
pub fn sim_bridge_system(
    runtime:      Res<RuntimeResource>,
    mut snapshot: ResMut<SimSnapshot>,
) {
    // Accessing the runtime's public API. Exact method names depend on
    // anvil_runtime's current public surface; adapt as needed.
    let rt = runtime.inner(); // or .borrow(), .read(), etc.

    let game_time = rt.game_time();
    let weather   = rt.weather_state();

    snapshot.tick              = rt.current_tick();
    snapshot.time.time_of_day  = game_time.normalized_time_of_day();
    snapshot.time.day          = game_time.day();

    snapshot.weather = WeatherSnapshot {
        temperature_c:  weather.temperature_celsius(),
        humidity:       weather.relative_humidity(),
        wind_speed_ms:  weather.wind_speed_ms(),
        wind_direction: weather.wind_direction_radians(),
        precipitation:  weather.precipitation_intensity(),
        cloud_cover:    weather.cloud_cover(),
        pressure_hpa:   weather.pressure_hpa(),
    };

    // Catastrophes: gather active events from runtime.
    // vfx_seed is derived once at onset and stored in the snapshot.
    // For now, we derive a stable seed from the catastrophe ID (constant for
    // its lifetime) until the sim exposes a canonical seed.
    snapshot.catastrophes = rt.active_catastrophes()
        .iter()
        .map(|c| anvil_bevy::sim_bridge::CatastropheSnapshot {
            id:        c.id(),
            kind:      c.kind().into(),
            origin:    c.origin_world_pos(),
            intensity: c.current_intensity(),
            vfx_seed:  stable_seed_from_id(c.id(), c.onset_tick()),
        })
        .collect();
}

/// Derives a stable u64 seed from two u64 inputs.
/// Same inputs always produce the same output. Changes on a new catastrophe, not per tick.
fn stable_seed_from_id(id: u64, onset_tick: u64) -> u64 {
    let mut h = id ^ (onset_tick.wrapping_shl(32) | onset_tick.wrapping_shr(32));
    h ^= h >> 30;
    h  = h.wrapping_mul(0xBF58476D1CE4E5B9);
    h ^= h >> 27;
    h  = h.wrapping_mul(0x94D049BB133111EB);
    h ^= h >> 31;
    h
}
```

**Spawn the sun with cascade shadow maps in `main.rs`:**

```rust
// anvil_demo/src/main.rs (in a startup system)

fn spawn_sun(mut commands: Commands) {
    commands.spawn((
        DirectionalLight {
            color: Color::LinearRgba(LinearRgba::new(1.0, 0.72, 0.44, 1.0)),
            illuminance: 5000.0,
            shadows_enabled: true,
            shadow_depth_bias:  0.02,
            shadow_normal_bias: 1.8,
            ..default()
        },
        // 3 cascades: tight near shadow for player-adjacent detail, looser far.
        CascadeShadowConfigBuilder {
            num_cascades:             3,
            minimum_distance:         0.1,
            maximum_distance:         200.0,
            first_cascade_far_bound:  12.0,
            overlap_proportion:       0.15,
        }.build(),
        Transform::default(),
        SunLight,
    ));
}
```

**Camera with fog:**

```rust
fn spawn_player_camera(mut commands: Commands) {
    commands.spawn((
        Camera3d::default(),
        DistanceFog {
            color:   Color::LinearRgba(LinearRgba::new(0.50, 0.40, 0.35, 1.0)),
            falloff: FogFalloff::Exponential { density: 0.018 },
            ..default()
        },
        CameraFog,
        // ... existing player controller components unchanged
    ));
}
```

**Register everything in `main.rs`:**

```rust
app
    .add_plugins((
        EnvironmentPlugin,
        SkyPlugin,
        TerrainPlugin, // Step 6
    ))
    .add_systems(PreUpdate,
        sim_bridge_system.in_set(EnvironmentSet::Bridge)
    )
    .add_systems(Startup, (spawn_sun, spawn_player_camera));
```

**Verification:** Run the demo. You should see the sky sphere with a gradient and a sun disc. Fog matches the sky horizon colour. The scene is not black, not flat pink.

---

## Step 6 — Terrain Material Extension (Wetness, Snow, Burn)

This is the step that replaces the draft's per-entity material mutation.

### Shader Extension

```wgsl
// assets/shaders/terrain_extension.wgsl

// Bevy's standard material provides base_color, metallic, perceptual_roughness.
// This extension modifies those outputs before they reach the PBR lighting calculation.

#import bevy_pbr::pbr_fragment::pbr_input_from_standard_material
#import bevy_pbr::pbr_functions::alpha_discard

struct TerrainExtensionInput {
    wetness:    f32,   // 0.0 = dry, 1.0 = saturated
    snow_cover: f32,   // 0.0 = bare, 1.0 = snow-covered
    burn_factor: f32,  // 0.0 = pristine, 1.0 = charred
}

@group(2) @binding(100) var<uniform> terrain: TerrainExtensionInput;

@fragment
fn fragment(
    in: VertexOutput,
    @builtin(front_facing) is_front: bool,
) -> @location(0) vec4<f32> {
    // 1. Get the base PBR input from StandardMaterial (handles textures, AO, etc.)
    var pbr_input = pbr_input_from_standard_material(in, is_front);

    let base = pbr_input.material.base_color;

    // 2. Wetness: darken albedo, reduce roughness, raise metallic (surface sheen)
    let dry_r  = base.r;
    let wet_r  = dry_r  * 0.55;
    let dry_b  = base.b;
    let wet_b  = dry_b  * 0.58;
    let dry_g  = base.g;
    let wet_g  = dry_g  * 0.55;

    pbr_input.material.base_color = vec4<f32>(
        mix(dry_r, wet_r, terrain.wetness),
        mix(dry_g, wet_g, terrain.wetness),
        mix(dry_b, wet_b, terrain.wetness),
        base.a,
    );
    pbr_input.material.perceptual_roughness =
        mix(pbr_input.material.perceptual_roughness, 0.35, terrain.wetness);
    pbr_input.material.metallic =
        mix(pbr_input.material.metallic, 0.08, terrain.wetness * 0.6);

    // 3. Snow: blend toward white, raise roughness (matte), zero metallic
    let snow_color = vec4<f32>(0.92, 0.94, 0.98, base.a);
    pbr_input.material.base_color = mix(
        pbr_input.material.base_color, snow_color, terrain.snow_cover
    );
    pbr_input.material.perceptual_roughness =
        mix(pbr_input.material.perceptual_roughness, 0.88, terrain.snow_cover);
    pbr_input.material.metallic =
        mix(pbr_input.material.metallic, 0.0, terrain.snow_cover);

    // 4. Burn: shift toward dark grey-brown, slight emissive for hot coals
    let char_color = vec4<f32>(0.09, 0.07, 0.06, base.a);
    pbr_input.material.base_color = mix(
        pbr_input.material.base_color, char_color, terrain.burn_factor
    );
    pbr_input.material.emissive = mix(
        pbr_input.material.emissive,
        vec4<f32>(0.8, 0.15, 0.0, 0.0),
        terrain.burn_factor * 0.08  // subtle glow, not orange lava
    );
    pbr_input.material.perceptual_roughness =
        mix(pbr_input.material.perceptual_roughness, 0.92, terrain.burn_factor);

    // 5. Delegate to standard PBR lighting
    return bevy_pbr::pbr_functions::apply_pbr_lighting(pbr_input);
}
```

### Material Extension Rust Type

```rust
// anvil_bevy/src/terrain/material.rs
use bevy::prelude::*;
use bevy::pbr::{ExtendedMaterial, MaterialExtension};
use bevy::render::render_resource::{AsBindGroup, ShaderRef, ShaderType};

#[derive(Asset, AsBindGroup, TypePath, Clone, Default)]
pub struct TerrainExtension {
    #[uniform(100)]
    pub params: TerrainMaterialParams,
}

/// Kept in a sub-struct so the whole thing is one uniform buffer.
#[derive(ShaderType, Clone, Copy, Default)]
pub struct TerrainMaterialParams {
    pub wetness:     f32,
    pub snow_cover:  f32,
    pub burn_factor: f32,
    pub _pad:        f32,
}

impl MaterialExtension for TerrainExtension {
    fn fragment_shader() -> ShaderRef {
        "shaders/terrain_extension.wgsl".into()
    }
}

pub type TerrainMaterial = ExtendedMaterial<StandardMaterial, TerrainExtension>;
```

### Terrain Plugin

```rust
// anvil_bevy/src/terrain/plugin.rs
use bevy::prelude::*;
use crate::terrain::material::{TerrainExtension, TerrainMaterial};
use crate::environment::state::EnvironmentState;
use crate::sim_bridge::SimSnapshot;
use crate::markers::TerrainChunk;

pub struct TerrainPlugin;

impl Plugin for TerrainPlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins(MaterialPlugin::<TerrainMaterial>::default())
           .add_systems(PostUpdate, drive_terrain_material_params);
    }
}

/// Updates ONE material asset handle. All terrain chunks that share this handle
/// are updated in the same operation. O(1), not O(chunk_count).
fn drive_terrain_material_params(
    env:       Res<EnvironmentState>,
    snapshot:  Res<SimSnapshot>,
    mut mats:  ResMut<Assets<TerrainMaterial>>,
    // The TerrainChunk query only needs to find ONE representative handle.
    // All chunks in the demo share the same handle.
    terrain_q: Query<&MeshMaterial3d<TerrainMaterial>, With<TerrainChunk>>,
) {
    let Ok(handle) = terrain_q.get_single() else { return };
    let Some(mat)  = mats.get_mut(&handle.0) else { return };

    // Burn factor: maximum across all active wildfires.
    let burn = snapshot.catastrophes.iter()
        .filter(|c| c.kind == crate::sim_bridge::CatastropheKind::Wildfire)
        .map(|c| c.intensity)
        .fold(0.0f32, f32::max);

    let snow = if snapshot.weather.temperature_c < -1.0 {
        (snapshot.weather.precipitation * 0.9).clamp(0.0, 1.0)
    } else {
        0.0
    };

    mat.extension.params.wetness     = env.wetness.current;
    mat.extension.params.snow_cover  = snow;
    mat.extension.params.burn_factor = burn;
}
```

**Why this is correct:** The entire terrain state — wet, snowy, burning — is driven by updating a single material asset. No per-entity iteration. No broken instancing. Adding a new terrain state parameter is: add a field to `TerrainMaterialParams`, one line in the WGSL, one assignment in `drive_terrain_material_params`.

---

## Step 7 — Fix the Transition Overlay (Properly)

The draft proposes adding a diagnostic and fixing based on what it reveals. That approach is fine for debugging an unknown bug. But we know what the bug almost certainly is, so we fix it directly. The diagnostic stays as a `#[cfg(debug_assertions)]` guard, not a shipped system.

The most common cause of a fade overlay that never clears in Bevy: the overlay entity's `BackgroundColor` alpha reaches 0 but `Visibility` is never set to `Hidden`, meaning it sits at the front of the UI stack at zero opacity but with a non-zero `z_index`, and at some point another system resets its alpha.

**The correct implementation:**

```rust
// anvil_demo/src/ui/transitions.rs

use bevy::prelude::*;

#[derive(Component)]
pub struct TransitionOverlay;

#[derive(Resource)]
pub struct FadeState {
    pub alpha:    f32,    // current alpha, 0.0 = transparent
    pub target:   f32,    // 0.0 = fade out, 1.0 = fade in (black)
    pub speed:    f32,    // units per second
    pub complete: bool,   // true once alpha has reached target and entity hidden
}

impl Default for FadeState {
    fn default() -> Self {
        Self { alpha: 1.0, target: 0.0, speed: 2.0, complete: false }
    }
}

pub fn spawn_transition_overlay(mut commands: Commands) {
    commands.spawn((
        Node {
            position_type: PositionType::Absolute,
            width: Val::Percent(100.0),
            height: Val::Percent(100.0),
            ..default()
        },
        BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 1.0)),
        ZIndex(i32::MAX), // always on top
        TransitionOverlay,
    ));
}

pub fn transition_system(
    mut fade:    ResMut<FadeState>,
    mut overlay: Query<(Entity, &mut BackgroundColor, &mut Visibility),
                       With<TransitionOverlay>>,
    time:        Res<Time>,
    mut commands: Commands,
) {
    if fade.complete { return; }

    let Ok((entity, mut bg, mut vis)) = overlay.get_single_mut() else {
        warn_once!("TransitionOverlay entity not found");
        return;
    };

    let dt = time.delta_seconds();
    let direction = (fade.target - fade.alpha).signum();
    fade.alpha = (fade.alpha + direction * fade.speed * dt)
                  .clamp(0.0, 1.0);

    bg.0 = Color::srgba(0.0, 0.0, 0.0, fade.alpha);

    // Once we've faded out, hide the entity entirely so it cannot
    // intercept pointer events or get accidentally restored.
    if (fade.alpha - fade.target).abs() < 0.005 {
        fade.alpha   = fade.target;
        fade.complete = true;
        if fade.target == 0.0 {
            *vis = Visibility::Hidden;
        }
    }
}

// Debug-only diagnostics. Not compiled in release.
#[cfg(debug_assertions)]
pub fn diagnose_transition(
    mut ran: Local<bool>,
    overlay: Query<(&BackgroundColor, &Visibility), With<TransitionOverlay>>,
    fade:    Res<FadeState>,
) {
    if *ran { return; }
    *ran = true;
    for (bg, vis) in &overlay {
        debug!(
            "[Transition] alpha={:.3} target={:.3} complete={} visibility={:?}",
            fade.alpha, fade.target, fade.complete, vis
        );
    }
}
```

Key differences from the draft approach:
- `Visibility::Hidden` is set after fade-out completes, so the overlay truly disappears from event and rendering consideration.
- `ZIndex(i32::MAX)` prevents any other UI element from accidentally stacking on top and hiding the fade.
- The diagnostic is `#[cfg(debug_assertions)]` — it exists, but does not ship.
- `warn_once!` for the missing entity case — one line in the log, not a cascade.

---

## Step 8 — Integration Verification

Run the demo at the default sim state (dawn, 6.4°C, humidity 0.31, no precipitation). Check each of the following before marking any step done:

### Automated checks (add to a `#[test]` integration module)

```rust
// anvil_demo/tests/environment_integration.rs

#[test]
fn fog_density_within_playable_range() {
    // With default dawn snapshot, fog density should be visible but not opaque.
    let config   = EnvironmentConfig::default();
    let mut env  = EnvironmentState::new(&config);
    let snapshot = SimSnapshot::default();
    resolve_targets(&snapshot, &config, &mut env);
    assert!(env.fog_density.target > 0.001, "fog should be visible at dawn");
    assert!(env.fog_density.target < 0.04,  "fog should not be blinding at dawn");
}

#[test]
fn max_fog_does_not_exceed_config_cap() {
    let config   = EnvironmentConfig::default();
    let mut env  = EnvironmentState::new(&config);
    let mut snap = SimSnapshot::default();
    snap.weather.humidity      = 1.0;
    snap.weather.precipitation = 1.0;
    snap.weather.temperature_c = -10.0; // cold ground fog
    resolve_targets(&snap, &config, &mut env);
    assert!(env.fog_density.target <= config.fog.max_density + f32::EPSILON);
}

#[test]
fn wetness_is_zero_when_freezing_and_dry() {
    let config   = EnvironmentConfig::default();
    let mut env  = EnvironmentState::new(&config);
    let mut snap = SimSnapshot::default();
    snap.weather.temperature_c = -5.0;
    snap.weather.precipitation = 0.0;
    snap.weather.humidity      = 0.1;
    resolve_targets(&snap, &config, &mut env);
    // Below freezing with no precipitation: liquid wetness suppressed.
    assert!(env.wetness.target < 0.05,
        "wetness should be near zero when freezing and dry, got {}", env.wetness.target);
}
```

### Manual visual checklist

1. **Sun direction**: at time_of_day=0.25 (dawn), shadows fall westward. If east: negate sun direction vector in `sun_dir_vec()`.
2. **Sky horizon matches fog**: the fog colour and sky horizon colour should be visually continuous. If there is a hard seam, reduce `fog_blend_start` in the sky material.
3. **Wetness at precipitation=0.8**: terrain visibly darker and shiny. If no change, confirm `TerrainChunk` marker is on the terrain entity.
4. **No pink cubes**: the demo scene uses only valid ArchetypeTags. If pink cubes appear, the asset registry is missing entries — check the log for `[AssetRegistry] Missing ArchetypeTag:` lines.
5. **Transition overlay**: after startup animation, the overlay is gone and cannot be clicked. If it blocks input, `Visibility::Hidden` is not being set — check `FadeState::complete`.
6. **Shadow cascades**: at mid-day, objects cast shadows. Bias artifacts (shadow acne on flat surfaces) are resolved by adjusting `shadow_depth_bias` (increase) or `shadow_normal_bias` (increase). Start at 0.02 / 1.8 respectively.

---

## Summary of Upgrades Over the Draft

| Draft | This version |
|---|---|
| `ClearColor` sky, "add sphere later" | Sky sphere with WGSL gradient and sun disc, shipped in Step 3 |
| `StandardMaterial` mutation per-entity | `ExtendedMaterial` with one shared handle, O(1) update |
| Wetness = roughness only | Wetness = darker albedo + lower roughness + slight metallic (physically correct) |
| Magic numbers in `EnvironmentState::new()` | `EnvironmentConfig` resource from TOML, artist-tunable |
| `shadows_enabled: false` | 3-cascade CSM enabled with sensible defaults |
| Flat `SimSnapshot` struct | Nested `TimeSnapshot`, `WeatherSnapshot`, `CatastropheSnapshot` |
| Per-tick VFX seed | Stable seed derived at onset, unchanged for catastrophe lifetime |
| `debug_assert!` for missing entities | `warn_once!` in release; diagnostic guard under `#[cfg(debug_assertions)]` |
| "Diagnose then fix" transition approach | Direct fix with `Visibility::Hidden` and `ZIndex(i32::MAX)` |
| Config constants require Rust recompile | TOML config, hot-reloadable in dev |
| No unit tests | Solar math, fog density, and wetness have dedicated unit tests |

Nothing here requires a rewrite when the game gets more serious. The sky sphere is the final sky system. The material extension is the final terrain material system. The config resource is the final tuning mechanism. Each step is additive.
