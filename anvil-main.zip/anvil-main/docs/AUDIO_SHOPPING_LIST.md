---
id: AUDIO_SHOPPING_LIST
title: Audio asset shopping list — Ashveil
status: active
audience: [developer, designer]
last_reviewed: 2026-05-11
supersedes: []
tags: [audio, assets, sourcing]
related_docs: [ANVIL_AUDIO, ANVIL_ASSETS, ANVIL_DEMO]
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: [assets/audio]
---

## Summary

Ten stems sourced from CC0 / CC-BY catalogues are enough to land the
Ashveil demo's reactive audio. Plus two stinger banks (precursor signals
and catastrophe ignition) gives full Phase 1 audio coverage. Twelve
files total, all 48000 Hz OGG Vorbis.

The system runs without these — handles for missing files resolve to
`Handle::default()` and the spawn pipeline skips them — so sourcing can
proceed in parallel with development. Each stem dropped into
`assets/audio/...` becomes audible the next time the demo runs.

## Aesthetic

**North American boreal-margin.** Temperate forest valley, cold dawn,
gusty-not-howling wind, low strings + sparse percussion. Stalker SoC
mood translated into what Freesound's CC0 catalogue actually contains.

## §1 Ambient zones (4 files)

### `assets/audio/ambient/wind_strong.ogg`

| Field | Value |
|---|---|
| Length | 30–60 s, seamlessly loopable |
| Channels | Mono |
| Sample rate | 48000 Hz |
| Use | The watchtower wind zone. Loud when weather threatens. |
| Mood | Gusty, mid-tonal. Not howling. The wind through a wooden structure at the edge of a settled valley. |
| Frequency content | Mid-low dominant (200–800 Hz). Roll off below 80 Hz. |
| Avoid | Howling/whistling extreme highs. Any voices, animals, birds. Loop seams. |

**Search terms:** `wind gusts forest`, `boreal wind`, `windy plains mono`,
`wind through trees ambient`. **Sources:** Freesound (CC0/CC-BY), BBC
Sound Effects (CC-BY non-commercial — verify licence before use), Free
Music Archive.

### `assets/audio/ambient/river.ogg`

| Field | Value |
|---|---|
| Length | 30–60 s, seamlessly loopable |
| Channels | Mono |
| Sample rate | 48000 Hz |
| Use | The river zone. Always running. |
| Mood | Moderate flow. Not a torrent. The bend of a small river through a settled valley. |
| Frequency content | Broad-spectrum hiss with low burble. |
| Avoid | Waterfall recordings. Splashy/violent water. Any human voices in background. |

**Search terms:** `river ambient mono`, `stream flowing`, `creek ambience`,
`river bend natural`.

### `assets/audio/ambient/birds_general.ogg`

| Field | Value |
|---|---|
| Length | 60 s, loopable |
| Channels | Mono |
| Sample rate | 48000 Hz |
| Use | The eastern forest zone. Goes silent as the catastrophe approaches. |
| Mood | Sparse boreal birdsong — distant, not chorus. A few species, intermittent calls. |
| Frequency content | High (2–8 kHz), tonal. |
| Avoid | Tropical bird recordings. Owl/nighttime species. Dense dawn chorus. |

**Search terms:** `boreal forest birds`, `temperate forest birdsong sparse`,
`distant birdsong ambient`.

### `assets/audio/ambient/village_hum.ogg`

| Field | Value |
|---|---|
| Length | 30–60 s, loopable |
| Channels | Mono |
| Sample rate | 48000 Hz |
| Use | The commons zone. Always present when in the village. |
| Mood | The almost-presence of people. Distant indistinct voices, faint tool sounds, a fire crackling somewhere. |
| Frequency content | Mid-range (200 Hz – 2 kHz). |
| Avoid | Recognisable words, modern sounds (vehicles, electricity, etc.). |

**Search terms:** `medieval village ambient`, `crowd murmur distant`,
`market ambience low`, `tavern background ambient`.

## §2 Score stems (6 files)

### `assets/audio/score/drone.ogg`

| Field | Value |
|---|---|
| Length | 30 s, loopable |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Sustained drone beneath everything. The texture of the morning. |
| Mood | Low, breathing, slightly inharmonic. One note that isn't quite one note. |
| Instrumentation | Cello sustain, processed; or synth pad with slow LFO. |
| Frequency content | 40–200 Hz dominant. |

**Search terms:** `cello drone low`, `ambient drone seamless`, `dark drone
loop`. Free Music Archive's ambient section is rich in this.

### `assets/audio/score/low_strings.ogg`

| Field | Value |
|---|---|
| Length | 30 s, loopable |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Enters as mood darkens. Catastrophe arc. |
| Mood | Sustained low strings, slow tremolo OK, no melody. |
| Instrumentation | Cello/double bass section. |

**Search terms:** `low strings sustained dark`, `cinematic strings cello
sustain`, `dark string pad loop`.

### `assets/audio/score/high_strings.ogg`

| Field | Value |
|---|---|
| Length | 30 s, loopable |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Precursor and Imminent phases. The "something is wrong" voice. |
| Mood | High strings, sparse, with occasional sul ponticello-like edge. Tense, not pretty. |
| Instrumentation | Violin/viola, processed. |

**Search terms:** `high strings tension`, `tense violin pad`, `thriller
strings sustain`.

### `assets/audio/score/percussion.ogg`

| Field | Value |
|---|---|
| Length | 30 s, loopable |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Active catastrophe phase only. |
| Mood | Sparse, irregular, low. No groove. Felt taiko or low frame drum, struck irregularly. |
| Instrumentation | Low felt mallets, taiko, frame drum. **No metallic** (no cymbals, no bells, no chimes). |

**Search terms:** `taiko ambient sparse`, `low percussion drone`, `dark
percussion loop`.

### `assets/audio/score/melodic_voice.ogg`

| Field | Value |
|---|---|
| Length | 20 s, loopable but rare-use |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Suppressing and Aftermath only. The recovery voice. |
| Mood | A simple descending phrase, sparse, with space between notes. |
| Instrumentation | Solo cello or clarinet, intimate recording. |

**Search terms:** `lament cello solo`, `recovery ambient melody`,
`reflective solo strings`.

### `assets/audio/score/time_voice.ogg`

| Field | Value |
|---|---|
| Length | 30 s, loopable |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Dawn/dusk emphasis. The "time passing" voice. |
| Mood | Slow, warm, tonal. The most pretty stem in the set. |
| Instrumentation | Strings + soft pad. |

**Search terms:** `ambient pad warm`, `dawn ambient music`, `morning
ambient loop`.

## §3 Stinger banks (2 files, multi-sample)

These are one-shot sounds played in response to specific cues.

### `assets/audio/stingers/precursor_signal.ogg` (or directory of OGGs)

| Field | Value |
|---|---|
| Length | 2–4 s each, 3–6 variants |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Fires when `EnvironmentalCue::PrecursorSignal` reaches threshold. |
| Mood | Subtle warning. A held breath, a swelling tone, a crow's distant call. |

**Search terms:** `tension swell short`, `whoosh subtle`, `cinematic
warning sting low`.

### `assets/audio/stingers/catastrophe_ignition.ogg`

| Field | Value |
|---|---|
| Length | 4–8 s |
| Channels | Stereo |
| Sample rate | 48000 Hz |
| Use | Fires once when catastrophe goes from Imminent to Active. The biggest sound the demo plays. |
| Mood | Authored impact. Low rumble + mid-range crash + high sparkle. Slowly decaying. |

**Search terms:** `cinematic impact hit`, `disaster boom rumble`, `epic
impact decay long`.

## §4 Sourcing notes

- **Verify licence on every download.** Freesound has CC0 *and* CC-BY
  *and* mixed-license content. CC-BY requires attribution per the
  policy in [`ANVIL_ASSETS`](ANVIL_ASSETS.md) §1.
- **Reject anything with copyrighted music samples or voices** unless
  explicitly CC0.
- **Append every download to `docs/CREDITS.txt`** with attribution
  (CC-BY) or as courtesy (CC0). One line per asset.
- **Mono for zones, stereo for score.** Zone mixing is positional;
  stereo would clash with the positional pan. Score is global.
- **Loop seams matter.** Test in Audacity: select the whole region,
  enable looping, play through three loops. Any audible click means the
  file needs a 50 ms crossfade applied at the boundary.

## §5 Acceptance criteria per file

For each file before it ships:

- [ ] Correct length (within the range listed).
- [ ] Correct channel count (mono/stereo as specified).
- [ ] Correct sample rate (48000 Hz).
- [ ] No loop click (tested in Audacity or equivalent).
- [ ] No clipping (peak < -3 dBFS).
- [ ] Correct mood (sourced or curated by ear).
- [ ] Attribution in `CREDITS.txt`.

## §6 Order of acquisition

If sourcing one file at a time, this order maximises immediate audible
impact:

1. `village_hum.ogg` — the demo's "you are in a place" anchor.
2. `wind_strong.ogg` — the demo's eerie weight.
3. `drone.ogg` — the score's anchor.
4. `river.ogg` — fills out the natural soundscape.
5. `birds_general.ogg` — adds life that *can be taken away*.
6. The rest in any order.

After files 1–3, the demo already has a substantial audio identity.
