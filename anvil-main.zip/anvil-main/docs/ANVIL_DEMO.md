---
id: ANVIL_DEMO
title: Ashveil Demo Specification
status: active
audience: [agent, developer, designer]
last_reviewed: 2026-05-10
supersedes: []
tags: [gameplay, presentation]
related_docs: [ANVIL_GAME_DESIGN, ANVIL_ROADMAP, ANVIL_STATUS, ANVIL_AUDIT, ANVIL_DETERMINISM, ANVIL_ASSETS]
owner: project_lead
version: 2.0
gate_scripts: []
code_paths: [crates/anvil_demo, crates/anvil_demo_core, crates/anvil_bevy]
---

## Summary

The Ashveil demo is a 60–90 minute first-person experience in a settled valley on a hostile continent at dawn. The viewer wakes up as the ninth villager — random substrate, no character creation screen, no UI hints — and walks Ashveil while the world progresses in real time. A wildfire ignites on the eastern ridge roughly 13 minutes in, sweeps the valley, suppresses under rain, and the village recovers. Whether the viewer witnesses any of this directly is up to where they look. The world does not pause for them.

The demo's purpose is twofold: (1) demonstrate the engine's claim that simulation, atmosphere, body, and consequence compose into something inhabitable; (2) act as exploration ground for the project lead to learn where solo-dev fidelity hits its ceiling — input data for the main project's planning.

This document supersedes the v1.x scripted-cinematic spec. The pivot to first-person was made on 2026-05-10 (see [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md)).

---

## §1. Demo at a glance

| Property | Value |
|---|---|
| Mode | First-person, viewer-controlled |
| Duration (1× speed) | 60–90 minutes of real time |
| Speed toggle | 1× default, 5× available for review |
| Sim-time : real-time | 1:1 at 1×; 5:1 at 5× |
| Viewer | Ninth villager, integrated in `WorldAuthored` |
| Substrate | Random per seed, persistent across loads, never displayed |
| Idle takeover | After 60s of no input; subtle vignette darkens; soft return on input |
| Catastrophe missability | Full — viewer may face the wrong way and not see it |
| Camera spline | Off by default (debug toggle for cinematic mode) |
| Dual-viewport replay | Removed from demo; moved to dev tool |
| Performance target | ≥ 30 fps on Arch Linux + Vulkan, dev hardware |

### Controls

| Input | Effect |
|---|---|
| WASD | Move (1.4 m/s walk) |
| Shift (held) | Sprint (4.5 m/s, stamina-limited) |
| Mouse | Look |
| H | Raise hands briefly into view (Phase 3+) |
| Esc | Pause / quit menu |
| F5 | Toggle 1× / 5× sim speed (review only) |

No interaction with NPCs, doors, or objects in v2.0 demo scope. Interaction is a separate roadmap; see [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §7.

---

## §2. The setting

### 2.1 World

Ashveil is one settlement compiled from a `WorldAuthored` plan via `anvil_assembly::compile_plan`. Three regions:

| Region | Role | Streaming |
|---|---|---|
| `ashveil_valley` | Settlement core | Always loaded |
| `eastern_ridge` | Wildfire origin | Streams in early (visible from spawn) |
| `western_ford` | Evacuation route | Streams in during catastrophe |

A fourth region (`deep_forest`) is descriptor-only — never loaded; present to declare the world extends beyond the viewport.

**Biome:** Temperate boreal-margin, river valley. **Terrain:** River bend (Rapier3D static mesh from `generate_terrain_mesh`); gentle eastern slope to ~180m ridge.

**Pre-demo weather state** (live `WeatherSimulation` field):

| Field | Value |
|---|---|
| `temperature` | 6.4°C (cold dawn) |
| `humidity` | 0.31 (drought-class) |
| `wind_speed` | 4.2 m/s easterly |
| `pressure` | 1008 hPa |
| `accumulated_precipitation` | 0.0 |

### 2.2 Settlement

| Field | Value |
|---|---|
| Settlement ID | `settlement_0001` |
| Name | Ashveil |
| Population | 8 named NPCs + viewer (9 total) |
| Family groups | `family_ironbark` (Settled), `family_wanderers` (Transient) |
| Buildings | Timber long houses, stone granary, central commons (packed earth), stone watchtower |
| Initial resource state | Food 0.65, Water 0.71, Materials 0.58, Structural 0.74 |

### 2.3 The eight named NPCs

Defined in `crates/anvil_demo_core/src/ashveil/npcs/` (8 files, one per NPC). Behavior is `NpcSystem::tick()` output — no scripted overrides.

| # | Name | Age | CF / GS / SA | Defining skill | Demo role |
|---|---|---|---|---|---|
| 1 | Maren Ironbark | 70 | +0.88 / +0.91 / +0.82 | SocialWeaving Expert | Anchor; `cooperation_modifier` keeps `organize_evacuation` dominant |
| 2 | Dak Voss | 34 | -0.73 / -0.51 / -0.62 | Woodcraft Expert | Skilled+frightened; flees, returns when settlement safety crosses threshold |
| 3 | Senne Ironbark | 28 | +0.55 / +0.71 / +0.44 | WeatherSense Smooth | Watchtower scout; `fire_sign_recognition` perceives precursor first |
| 4 | Tibor Ironbark | 19 | 0.0 / +0.62 / -0.38 | Woodcraft Awkward | Observation learner; gains credits watching Dak |
| 5 | Lora Vance | 45 | -0.42 / +0.84 / +0.51 | Foraging Smooth, Pathfinding Competent | Generosity overrides fear; leads Cael to ford |
| 6 | Cael Ironbark | 8 | +0.21 / +0.55 / +0.10 | Child (limited action set) | Emotional throughline |
| 7 | Yarra Keld | 52 | -0.31 / -0.44 / +0.62 | Stonework Expert | `coping_modifier` keeps her at the granary; granary survives because of her |
| 8 | Pell Vance | 31 | 0.0 / +0.45 / -0.71 | SocialWeaving Competent | Anxiety vector; substrate amplifies incoming negative signals 1.4× |

Substrate axes: `courage_fear` / `generosity_selfishness` / `stability_anxiety`. Range −1.0 to +1.0.

### 2.4 Catastrophe seed

The wildfire is held at tick 0 with `magnitude: 0.0` and a trigger predicate evaluated each sim-tick:

```
trigger_score = temperature_factor × wind_factor × humidity_factor × vegetation_factor
```

At 1× sim-speed, `trigger_score` crosses 0.65 around game-time minute 13. At 5×, around real-time minute 2:36. The fire is not scripted to fire at a time — it fires when the live weather state drives the predicate over threshold. Different weather → no fire. Different seed → fire approaches from a different direction.

---

## §3. The viewer

### 3.1 The ninth villager

A ninth NPC is authored into Ashveil's `WorldAuthored`. Substrate values are seeded from the world seed (deterministic per seed, random across seeds). Connections to the eight named NPCs are minimal but present — the viewer is a known villager, not a stranger.

| Property | Value |
|---|---|
| Authored in | `crates/anvil_demo_core/src/ashveil/npcs/viewer.rs` |
| Substrate source | `Substrate::from_seed(world.seed)` |
| Connection set | Family: 0–2, Proximity: 2–4, Village: rest (per seed) |
| Visible to AI | Yes — other NPCs perceive the viewer per substrate |
| Display of own substrate | **Never** (no UI, no endgame reveal, no debug menu in shipping demo) |

### 3.2 Idle takeover

Specified in [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md) entry 2026-05-10.

| Stage | Behavior |
|---|---|
| Idle threshold | 60 seconds with no input (no movement, no mouse motion, no key) |
| Visual cue | Subtle vignette darkening (uses the Phase 3 `PeripheralVignette` system) |
| Audio cue | None |
| Control transfer | `NpcSystem` evaluates and runs the viewer NPC like any other |
| Camera | Stays first-person — viewer sees what the body sees |
| Resume | On any input. Soft return: body finishes its current micro-step, then responds |

### 3.3 Hand-check input

| Input | Effect |
|---|---|
| H | Raise both hands briefly into view, then lower |

Hands surface body state diegetically: tremor amplitude when raised reflects substrate × current `EmotionalAxes` × fatigue. No always-visible hand HUD.

---

## §4. The arc

What happens during a real-time playthrough at 1× sim-speed. Timestamps are *approximate* — the simulation drives the events, not a script. Different seeds shift timings.

| Real time | Game time | Event | Driver | Code reference |
|---|---|---|---|---|
| 00:00 | 06:14 | Viewer wakes (random spawn point) | World loader | `world/spawn.rs` |
| 00:00 | 06:14 | Atmosphere live: dawn light, eastern fog, audible wind | AtmosphereDriver | `world/atmosphere_driver.rs` |
| 00:00–13:00 | 06:14–06:27 | Village morning rhythm; precursor signals begin to fire | `NpcSystem`, `CatastropheSystem` | various |
| ~05:00 | ~06:19 | Senne perceives `SmokeOnHorizon` precursor (intensity ~0.31) | `Perceptibility` system | `crates/anvil_sim/src/skill/perceptibility.rs` |
| ~13:00 | ~06:27 | Wildfire ignites (`magnitude` rises from 0) | `CatastropheSystem` | `crates/anvil_sim/src/system/catastrophe.rs` |
| ~13:30 | ~06:28 | Atmosphere shifts: fog thickens, sun warms, ambient drops | AtmosphereDriver reading active catastrophe | `world/atmosphere_driver.rs` |
| ~14:00 | ~06:29 | Maren begins `organize_evacuation` action | NPC utility AI | `crates/anvil_sim/src/utility/scoring.rs` |
| ~16:00 | ~06:32 | Yarra at granary, `reinforce_mortared_joint` | NPC utility AI | same |
| ~17:00 | ~06:34 | Dak begins `self_evacuate_west` | NPC utility AI | same |
| ~30:00 | ~06:50 | Dak's `self_evacuate_west` score drops below `reinforce_wall`; he turns back | NPC utility AI | same |
| ~35:00 | ~06:55 | Rain transition: `WeatherPhase` advances | `WeatherSimulation` | `crates/anvil_runtime/src/weather.rs` |
| ~40:00 | ~07:00 | Fire magnitude decays; smoke layer disperses | `CatastropheSystem` | catastrophe.rs |
| ~50:00 | ~07:10 | `JoySystem` evaluates `CatalystEvent::CommunityResilience`; emits if conditions met | `JoySystem` | `crates/anvil_sim/src/system/joy.rs` |
| ~60:00 | ~07:20 | Demo's narrative arc complete; sim continues | — | — |

At 5×, divide all real times by 5. Game-time stays anchored to sim-tick.

The arc is **not** a sequence of beats the demo plays. It is the consequences of the simulation running on its initial state. The viewer's experience of the arc depends entirely on where they walked and where they looked.

---

## §5. Phase roadmap

The demo is built across six phases. Each delivers a visible/audible/somatic improvement and is permanent in the engine — no phase work is throwaway. Phases are sequenced so that each builds on the last; running one phase out of order gives weaker results.

Phase definitions and rationale: [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md) entry 2026-05-10.
Sprint sequencing: [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §4.

### 5.1 Phase 1 — *The valley feels watched*

**Goal.** A viewer who walks Ashveil for five minutes, before any named event, feels eerie weight. The world is alive, watched, indifferent.

**Components.**

| Component | Path | Reads |
|---|---|---|
| First-person controller | `crates/anvil_demo/src/player/` | Rapier3D, terrain mesh |
| Idle takeover | `crates/anvil_demo/src/player/idle.rs` | `NpcSystem`, viewer NPC `Substrate` |
| AtmosphereDriver | `crates/anvil_demo/src/world/atmosphere_driver.rs` | `WeatherSimulation`, `GameTime`, `CatastropheSystem::active_precursors()` |
| Ambient zones | `crates/anvil_demo/src/audio/zones.rs` | `WeatherSimulation`, NPC `current_action`, region |
| Watched-pass eerie levers | (in zones + atmosphere) | `WeatherSimulation::wind_speed`, NPC presence |

**Removes.** `bevy_flycam`, intro splash, dual-viewport replay (moved to dev tool), camera spline as primary.

### 5.2 Phase 2 — *The village is a system*

**Goal.** The social graph is legible without UI. Casual viewer feels life. Curious viewer notices patterns. Patient viewer can trace the family graph.

**Components.**

| Component | Path | Reads |
|---|---|---|
| GazeDriver | `crates/anvil_demo/src/npc_visuals/gaze.rs` | `current_action`, `current_target`, `EmotionalAxes`, `Connection` graph |
| ProximityDriver | `crates/anvil_demo/src/npc_visuals/proximity.rs` | `Connection::strength`, pathfinding terminal node |
| OrientationDriver | `crates/anvil_demo/src/npc_visuals/orientation.rs` | `current_action`, group composition, `Connection` graph |
| MovementSignature | `crates/anvil_demo/src/npc_visuals/movement_signature.rs` | `EmotionalAxes::security_threat`, `current_action` class, `Person::injuries` |
| LifeRhythm | `crates/anvil_demo/src/npc_visuals/life_rhythm.rs` | NPC tick timing, action completion, `WeatherSimulation::humidity` |

**Removes.** Nothing. Phase 2 is purely additive.

### 5.3 Phase 3 — *Your body knows*

**Goal.** Somatic resonance — terrain, cold, exertion, threat, substrate all surface through the viewer's body. Substrate is learned by living, never displayed.

**Components.**

| Component | Path | Reads |
|---|---|---|
| TerrainAudio | `crates/anvil_demo/src/player/somatic/terrain_audio.rs` | Controller raycast, terrain material tags |
| BreathingSystem | `crates/anvil_demo/src/player/somatic/breathing.rs` | `temperature`, `Substrate`, `EmotionalAxes`, exertion |
| Heartbeat | `crates/anvil_demo/src/player/somatic/heartbeat.rs` | `EmotionalAxes`, exertion, precursors, nearby action class |
| CameraShake / HandTremor | `crates/anvil_demo/src/player/somatic/shake.rs` | `Substrate`, `EmotionalAxes`, `Person::fatigue`, threat events |
| PeripheralVignette | `crates/anvil_demo/src/player/somatic/vignette.rs` (+ WGSL) | Idle, threat, fatigue |
| BodyState (aggregator) | `crates/anvil_demo/src/player/somatic/body_state.rs` | All of the above |

**Removes.** Phase 1 vignette darkening becomes one of three modulators in `PeripheralVignette`.

### 5.4 Phase 4 — *The fire is a thing that happens to a place*

**Goal.** The wildfire arrives across the senses — light, heat (sound, screen, breath), air, weight — even if the viewer faces the wrong way.

**Components.**

| Component | Path | Reads |
|---|---|---|
| FireParticleField | `crates/anvil_demo/src/vfx/fire_particle_field.rs` | `CatastropheEvent::affected_areas`, `magnitude`, `wind_vector` |
| EmberSystem | `crates/anvil_demo/src/vfx/embers.rs` | `wind_vector`, building/terrain meshes |
| SmokeColumn / ValleySmoke | `crates/anvil_demo/src/vfx/smoke_column.rs`, `valley_smoke.rs` | `CatastropheEvent`, `humidity` |
| FireLightSource | `crates/anvil_demo/src/vfx/fire_light.rs` | `magnitude`, AtmosphereDriver |
| CatastropheAudio (3-layer) | `crates/anvil_demo/src/audio/catastrophe.rs` | `CatastropheEvent`, viewer position, `WeatherSimulation` |
| PostCatastropheState | `crates/anvil_demo/src/vfx/post_catastrophe.rs` | `Building::structural_integrity`, consequence history |

**Removes.** Single-cube `vfx/fire_spread.rs`, static `vfx/smoke.rs` billboard, hardcoded `wind_speed = 4.2` in `vfx/debris.rs`.

### 5.5 Phase 5 — *The morning has a voice*

**Goal.** The score interprets the simulation. Drone holds the morning; layers enter as mood drifts; the catastrophe's full layered score earns its weight; recovery has its own descending arc.

**Components.**

| Component | Path | Reads |
|---|---|---|
| MoodReader | `crates/anvil_demo/src/audio/score/mood_reader.rs` | NPC `EmotionalAxes`, `Connection` weights, `CatastropheSystem`, `GameTime`, `WeatherSimulation`, `BodyState` |
| ScoreState | `crates/anvil_demo/src/audio/score/score_state.rs` | MoodReader |
| Stems library | `assets/audio/score/` (~7 stems for Ashveil) | Asset registry |
| SpatialMixing | `crates/anvil_demo/src/audio/score/spatial_mixing.rs` | Phase 1 ambient zones, viewer position |
| ScoreTrigger | `crates/anvil_demo/src/audio/score/triggers.rs` | Catastrophe events, time-of-day transitions, viewer location |

**Removes.** Existing global ambient track in `audio/demo_soundtrack.rs`. Asset slots become inputs to the new system.

### 5.6 Phase 6 — *The work that finds the wall*

**Goal.** Push lighting, weather, and sound toward AAA polish where possible. Document where solo-dev hits the wall. Eliminate flicker and atmosphere-breaks.

This phase is structured as **passes**, not deliverables. Each pass continues until the project lead decides it has reached the achievable level. Outcomes documented in [`ANVIL_DEMO_LIMITS`](ANVIL_DEMO_LIMITS.md).

| Pass | Targets |
|---|---|
| Lighting | Time-of-day palette, volumetric fog, shadow tuning, light/weather composition, HDR exposure |
| Weather | Particle density per intensity, wind on foliage, surface wetness, wind audibility differential, precipitation transition |
| Sound | Stem replacement, ambient zone polish, footstep palette expansion, catastrophe audio finish, heartbeat/breath finish |
| Glitch elimination | Z-fighting, pop-in, animation discontinuities, mismatched lighting reactions, camera artifacts, audio glitches |
| Integration polish | Lighting buffer composition audit, audio mix master pass, post-process layer order, per-scene-state global tuning |

**Performance discipline.** Profile after each pass. If 30 fps threatened, the most expensive AAA pass falls back. Document falls in `ANVIL_DEMO_LIMITS`.

---

## §6. Signature moments

Specific moments that have outsized impact when they land. None is scripted — all are simulation outputs. The phase work amplifies their delivery, but the moment itself happens because the engine produces it.

### 6.1 Senne perceives the smoke

| Field | Value |
|---|---|
| Trigger | `PrecursorSignal::SmokeOnHorizon` intensity crosses Senne's perceptibility threshold (~0.5) given her `fire_sign_recognition` affordance |
| Timing | ~5–7 minutes real-time at 1× |
| Code | `crates/anvil_sim/src/skill/perceptibility.rs` evaluation; `NpcSystem` action transition |
| Viewer experience | If at the watchtower path: Senne breaks her horizon-scan pattern, head turns east, body posture changes. Audible breath shift. If elsewhere: the village re-orients around her warning shout (Phase 2 GazeDriver pulls connected NPCs' gaze east) |
| Why it lands | The engine *predicts* the fire before it ignites. Senne's skill is what makes prediction visible |

### 6.2 Cael watches the smoke

| Field | Value |
|---|---|
| Trigger | Cael's stagger interval delays his action re-evaluation; he stands idle while the precursor intensity rises |
| Timing | ~10–11 minutes real-time at 1× |
| Code | NPC stagger offset in `crates/anvil_sim/src/system/npc/mod.rs` |
| Viewer experience | If looking at Cael: a child stands still, watching east. He doesn't know what he's seeing yet. Then the fire arrives |
| Why it lands | Emergent. The child is watching because his action timer hasn't fired, not because he's been told to. The viewer infers feeling |

### 6.3 Dak's return

| Field | Value |
|---|---|
| Trigger | Maren's ongoing `organize_evacuation` raises `settlement.safety_level` enough that Dak's `self_evacuate_west` falls below `reinforce_wall` in his utility scoring |
| Timing | ~30 minutes real-time at 1× |
| Code | `crates/anvil_sim/src/utility/scoring.rs`; ~0.05 score margin at the moment of decision |
| Viewer experience | If Dak is in line of sight: a man walking west stops, stands still, turns, walks back. His posture (Phase 2 MovementSignature) straightens. He passes the viewer without acknowledgment |
| Why it lands | The engine's most important mechanic — substrate × situation determines action — produces a visible, decisive, uncoached moment. No annotation, no UI; just a man who came back |

### 6.4 The rain begins

| Field | Value |
|---|---|
| Trigger | `WeatherPhase` transition (humidity rising → precipitation); `accumulated_precipitation` rises from 0 |
| Timing | ~35 minutes real-time at 1× |
| Code | `crates/anvil_runtime/src/weather.rs` |
| Viewer experience | Across the senses simultaneously: Phase 1 atmosphere (sun colour shifts cool, fog stops thickening), Phase 4 catastrophe audio (fire roar fades), Phase 5 score (drone thins, melodic-voice stem enters for first time) |
| Why it lands | All four major systems converge on one event. The first time the melodic-voice stem plays is the moment recovery becomes audible |

### 6.5 The community holds

| Field | Value |
|---|---|
| Trigger | `JoySystem` evaluates and emits `CatalystEvent::CommunityResilience` when conditions met (post-catastrophe, structural_integrity > threshold, all persons accounted for) |
| Timing | ~50 minutes real-time at 1× |
| Code | `crates/anvil_sim/src/system/joy.rs` |
| Viewer experience | Late-afternoon damp light. NPCs gather at the commons (Phase 2 OrientationDriver pulls them in). Score is in its recovery state. Single Joy boost (+0.21) propagates through the social network |
| Why it lands | Pillar II — people cope, people find joy — landing as the demo's last moment. Joy cannot be sought (`Need::can_be_satisfied()` returns false for Joy); it arrives because of what happened |

---

## §7. Missability policy

The demo commits to **full missability**. The viewer may walk to the western ford at minute 1 and stay there for an hour; they will not see Senne perceive the smoke, will not see Dak walk west and back, will not see Yarra at the granary. They will hear the catastrophe (positional audio + score), feel it (Phase 3 somatic), and see its atmospheric effects (Phase 1 fog/sun shifts; Phase 4 valley smoke). They will not see the village's response.

This is the design, not a failure. Justification:

1. **Pillar I in extremis.** The world is not paused for the viewer. Missability is the strongest expression of "the player is an inhabitant, not a hero."
2. **Replay value.** A viewer who notices what they missed wants to walk it again differently.
3. **Stalker/Rust mood.** Both reference titles commit to non-curation. Ashveil's eerie weight depends on the same commitment.

**Risks.**

| Risk | Mitigation |
|---|---|
| Non-gamer audience misses the centerpiece event entirely | Phase 4's cross-sensory broadcast (light/sound/atmosphere) ensures *something* is felt regardless of camera angle |
| Reviewer plays once, sees little, writes "walking sim" | Accepted. Demo is for the project lead's exploration, not for review by external audiences. Public release strategy is downstream |
| Viewer assumes nothing is happening | The atmosphere-driven score (Phase 5) provides ambient signal that the world is responding to events. A viewer who hears the score shift knows *something* is different, even if they don't see the cause |

No nudges, no soft pulls, no prompts. The curious see everything. The directionless see emptiness.

---

## §8. Definition of done

The demo is "done" when:

- [ ] Phase 1 lands. AtmosphereDriver writes to sun/fog/ambient/sky reading live `WeatherSimulation`. First-person controller replaces `bevy_flycam`. Idle takeover ships. Ambient zones positional.
- [ ] Phase 2 lands. GazeDriver, ProximityDriver, OrientationDriver, MovementSignature, LifeRhythm all running. Eight NPCs visibly form a colony.
- [ ] Phase 3 lands. TerrainAudio + BreathingSystem + Heartbeat + Shake/Tremor + Vignette + BodyState aggregator. Hand-check input works.
- [ ] Phase 4 lands. FireParticleField + EmberSystem + SmokeColumn/ValleySmoke + FireLightSource + CatastropheAudio + PostCatastropheState. Old fire-cube and static smoke removed.
- [ ] Phase 5 lands. MoodReader + ScoreState + Stems library + SpatialMixing + ScoreTrigger. The morning has a voice.
- [ ] Phase 6 passes complete. Each documented in `ANVIL_DEMO_LIMITS.md` with what was attempted, what landed, what hit a wall.
- [ ] All four CRIT findings in [`ANVIL_AUDIT`](ANVIL_AUDIT.md) closed.
- [ ] CC0 + CC-BY asset replacement complete (HIGH-07). No `vendor/emberwood` references in shipping build.
- [ ] All eight named NPCs exhibit substrate-predicted behaviour across at least three different seeds without intervention.
- [ ] 30 fps held on Arch Linux + Vulkan, dev hardware, worst-case (catastrophe peak with all NPCs visible).
- [ ] A non-gamer viewer can walk Ashveil for 60 minutes and produce, after, a sentence describing one NPC's emotional state without prompt.

---

## §9. Open debt

Tracked in [`ANVIL_AUDIT`](ANVIL_AUDIT.md). Status as of 2026-05-10:

| Finding | Description | Current state | Sprint |
|---|---|---|---|
| CRIT-01 | Dual `SimSpeed` resources never synchronised | Open | Sprint 25 (per ROADMAP §4.3) |
| CRIT-02 | Assertions inside Bevy startup system | Open | Sprint 25 |
| CRIT-03 | `sim_bridge.rs` placeholder NPC data in production | Open | Sprint 25 — also closed by Philosophy A3 amendment (no fixtures in production paths) |
| CRIT-04 | `Runtime::restore_with_world` only restores PhysicsSystem | Open | Sprint 26 — gates Phase 4 demo extension E4 (time-travel scrubbing) |
| HIGH-07 | NatureManufacture assets cannot ship publicly | Open | Sprint 29 — gates public release |

---

## §10. What got removed (historical record)

The v2.0 pivot removed several v1.x deliverables. Recorded here for clarity to future readers / agents who encounter v1.x references in commit history.

| Removed | Reason | When |
|---|---|---|
| Camera spline as primary mode | First-person commitment makes spline incompatible with viewer-driven experience. Spline retained as `cinematic` debug toggle. | 2026-05-10 (this rewrite) |
| Dual-viewport replay (§5:15 of v1.x) | Split-screen breaks first-person presence. Determinism gets a separate dev-facing replay tool. | 2026-05-10 |
| Intro splash / pre-game state | First-person opens directly into world; no menu. | 2026-05-10 |
| Free-cam toggle (`Tab` to enter Free mode) | The whole demo is free-cam now. Toggle is meaningless. | 2026-05-10 |
| Demo extensions E1–E6 as a separate plan | Folded into Phase 1–6 roadmap; E4 specifically lands in Phase 4 / Sprint 26 (still gated by CRIT-04). | 2026-05-10 |
| `bevy_flycam` dependency | Replaced by hand-rolled FPS controller in Phase 1. | Sprint 23 |
| Single-cube `vfx/fire_spread.rs` | Replaced by FireParticleField in Phase 4. | Sprint 27 (estimated) |
| Hardcoded `wind_speed = 4.2` in `vfx/debris.rs` | Replaced by live `WeatherSimulation::wind_vector()` reads in Phase 4. | Sprint 27 |
| Global ambient track in `audio/demo_soundtrack.rs` | Replaced by Phase 5 reactive score. | Sprint 28 (estimated) |

---

## §11. Changelog

- **2026-05-10 — v2.0.** Major rewrite. Demo pivots from 6-minute scripted cinematic at 10× sim-speed to 60–90 minute first-person experience at 1× sim-speed. Viewer becomes ninth villager with random substrate. Six-phase roadmap (atmosphere, village, body, catastrophe, score, polish) replaces E1–E6 extension list. Original v1.x archived under `docs/archive/ANVIL_DEMO_v1.md`.
- **2026-05-09 — v1.1.** E1–E6 ratification, sprint mapping. (See archive.)
- **2026-05-09 — v1.0.** First reconciliation against actual code state. (See archive.)
