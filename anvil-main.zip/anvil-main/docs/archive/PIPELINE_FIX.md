# Pipeline crate fix — `anvil_assets_pipeline`

Twenty-five errors. All surgical. Three categories:

1. One syntax error (missing struct/enum keyword after doc comment).
2. Two missing `#[derive(...)]` attributes.
3. Twenty-two dead imports caught by `#![deny(warnings)]`.

None of the errors indicates a design problem. The crate was clearly in
the middle of a refactor — some imports were left behind, two derives
were dropped, and one file lost its struct keyword.

Apply in order. Each is independent; the build only goes green after all
three categories are addressed (the `#![deny(warnings)]` makes warnings
fail the build).

---

## Fix 1 — Syntax error at `selection.rs:16`

**File:** `crates/anvil_assets_pipeline/src/normalization/batch/selection.rs`

The error `expected item after attributes` at line 16 means the doc
comment at lines 12-15 is followed by `#[derive(...)]` but no `struct`,
`enum`, or other item declaration follows the derive attribute.

**View the file around line 16.** The likely fix is that a struct
declaration is missing. The doc comment references
`BatchCompositionPolicy` so the type is likely
`ExternalAssetNormalizationBatchSelection` or similar — the canonical
fix is to add the missing `pub struct` line.

```rust
// At line 16, after the #[derive(...)] attribute, add the missing
// struct declaration that the doc comment introduces. Without seeing
// the file's intended contents I cannot be 100% certain of the exact
// type name; the build error makes it clear that *some* item is
// supposed to follow the derive.

// Likely fix (verify name from surrounding context in this file):
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationBatchSelection {
    pub assets: Vec<ExternalAssetNormalizationCandidate>,
}
```

If the file is supposed to be empty pending design, the doc comment and
the `#[derive]` line should both be deleted.

---

## Fix 2 — Missing `#[derive(Debug)]` on `EligibilityValidationErrors`

**File:** `crates/anvil_assets_pipeline/src/eligibility/part2a/validation.rs`
**Line:** ~5 (struct declaration)

The struct currently declares:

```rust
pub struct EligibilityValidationErrors(pub Vec<ExternalAssetNormalizationEligibilityError>);
```

Line 50 implements `std::error::Error`, which requires `Debug`. Add the
derive:

```rust
#[derive(Debug)]
pub struct EligibilityValidationErrors(pub Vec<ExternalAssetNormalizationEligibilityError>);
```

Add `Clone` too if it's used elsewhere; the build error only mentions
`Debug` so that's the minimum.

---

## Fix 3 — Missing `Serialize`/`Deserialize` on `ExternalAssetNormalizationBatchManifest`

**File:** `crates/anvil_assets_pipeline/src/normalization/batch/manifest.rs`
**Line:** 22 (struct declaration)

Line 152 calls `serde_json::from_str` on the struct, which requires
`Deserialize`. The current declaration is missing the derive. Add:

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExternalAssetNormalizationBatchManifest {
    // ... existing fields
}
```

Note: line 1 already has `use serde::{Deserialize, Serialize};` — but it's
flagged as unused because the derive isn't there. Fix 3 makes the import
needed; Fix 4 (below) does not delete this import.

---

## Fix 4 — Twenty-two dead imports

The `#![deny(warnings)]` at `lib.rs:19` promotes unused-import warnings
to errors. Each of the following imports must be deleted from its file.

Order doesn't matter; do them in one pass.

### `eligibility/part2a/classifier.rs`

Delete lines 1-4 entirely (all four are dead). If any of these types are
used elsewhere in the file, leave only the ones that are.

```rust
// DELETE:
use anvil_core::ArchetypeTag;
use crate::external_pilot::{ExternalAssetFamily, ExternalAssetPilotManifest, PackIdentityError};
use crate::Vendor;
```

### `eligibility/part2a/default_classifier.rs`

Lines 1-4 are all dead. Line 7 has one dead name (`ExternalAssetMaterialClass`).

```rust
// DELETE lines 1-4:
use anvil_assets::AssetKind;
use anvil_core::ArchetypeTag;
use crate::external_pilot::{ExternalAssetFamily, PackIdentityError};
use crate::pipeline::ManifestError;

// In line 7, remove `ExternalAssetMaterialClass` from the import list.
// Before: ExternalAssetTextureSetCompleteness, ExternalAssetMaterialClass,
// After:  ExternalAssetTextureSetCompleteness,
```

### `eligibility/part2a/errors.rs`

Line 5:

```rust
// DELETE:
use crate::ExternalAssetPilotManifest;
```

### `eligibility/part2a/manifest.rs`

Lines 5, 7, 8, 9, 10, 11 contain dead imports. Delete the dead names from each.

```rust
// Line 5 — remove these from the import group:
//   error_buffer, push_validation_error, FailureClass, ValidationErrors
// Keep whatever else was in that import (e.g. ArchetypeTag if used).

// Line 7 — remove PackIdentityError from the group:
// Before: use crate::external_pilot::{ExternalAssetPilotManifest, PackIdentityError};
// After:  use crate::external_pilot::ExternalAssetPilotManifest;

// Line 8: DELETE entirely:
use crate::ExternalAssetFamily;

// Line 9: DELETE entirely:
use crate::ExternalAssetPackIdentity;

// Line 10: DELETE entirely:
use crate::ExternalAssetNormalizedOutputKind;

// Line 11 — remove these three names from the group:
//   ExternalAssetNormalizationExecutionRecord
//   NormalizationStageError
//   ExternalAssetNormalizationExecutionError
// (Keep whatever else was there; the error log truncates the list.)
```

### `eligibility/part2a/record.rs`

Line 3:

```rust
// DELETE:
use crate::external_pilot::ExternalAssetFamily;
```

### `normalization/batch/glb.rs`

Line 3 — remove `NormalizationStageError`:

```rust
// Before: use ...::{...ExecutionRecord, NormalizationStageError};
// After:  use ...::{...ExecutionRecord};
```

### `normalization/batch/manifest.rs`

This file has both Fix 3 (the missing derive) and a few dead imports.
**Apply Fix 3 first.** That makes line 1 (`use serde::{Deserialize, Serialize}`)
needed and resolves the line-1 warning.

Then delete the remaining dead imports:

```rust
// Line 11: DELETE entirely:
use crate::ExternalAssetFamily;

// Line 13: DELETE entirely:
use crate::ExternalAssetPackIdentity;

// Line 16 — remove these two names from the group:
//   ExternalAssetNormalizationExecutionRecord
//   ExternalAssetNormalizationExecutionError
// Keep NormalizationStageError if it's used elsewhere in the file.

// Line 17: DELETE entirely:
use crate::normalization::batch::glb::NormalizedGlb;
```

---

## Verification

After all four fixes:

```bash
cargo check -p anvil_assets_pipeline
```

Should print `Finished` with no errors. If a previously-dead import turns
out to be used in code I couldn't see from the build log, undo that
specific deletion — the deny-warnings block will tell you if so.

Then run the full workspace check to confirm nothing downstream breaks:

```bash
cargo check --workspace
```

---

## Why this happened

The crate is mid-refactor. Types were renamed or merged, but the
import sites and a couple of derives weren't updated. `#![deny(warnings)]`
is the right defensive posture — it caught the drift. Once the cleanup
is applied, the deny-block will continue to catch new drift the same way.
