---
id: ANVIL_DEMO_v1
title: Ashveil Demo Specification
status: active
audience: [developer, designer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [gameplay, presentation]
related_docs: [ANVIL_GAME_DESIGN, ANVIL_ROADMAP, ANVIL_STATUS, ANVIL_AUDIT, ANVIL_DETERMINISM]
owner: project_lead
version: 1.1
gate_scripts: []
code_paths: [crates/anvil_demo, crates/anvil_demo_core]
---
