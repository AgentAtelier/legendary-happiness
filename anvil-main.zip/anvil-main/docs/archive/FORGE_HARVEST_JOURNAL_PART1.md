---
id: FORGE_HARVEST_JOURNAL_PART1
title: FORGE HARVEST JOURNAL PART1
status: archived
audience: [developer]
last_reviewed: 2026-05-10
supersedes: []
tags: [historical]
related_docs: []
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: []
---

# Forge Harvest Journal — Part 1

**Date:** 2026-04-30 (v2, maximalist pass with file-by-file coverage)
**Author of the audit:** Claude Opus 4.7
**Reader:** the Anvil project lead (you)

---

## Foreword from the auditor

This document is not the engineering audit it pretends to be. It is a
*design journal*. You asked for it to serve two purposes at once:
to record, file by file, what happens to every line of Forge — and to
teach something about the choices behind those decisions, so that
re-reading this six months from now, or a year from now, will produce
new understanding.

I have tried to honour both purposes. The technical prose stays in the
third person, neutral and verifiable. The lessons-learned blocks — set
off and clearly marked — speak in your voice, as you'd write them
yourself looking at the same code. They are *hypotheses* about what
you'd take away, not pronouncements. Where I've guessed at a lesson
that isn't yours, mark it with a strikethrough and rewrite it. The
journal is not finished until you've owned every voice in it.

A coverage script (`scripts/audit_coverage.sh`) verifies that every
`.rs` file in Forge is mentioned somewhere in this journal or in its
companion **Part 2**. Nothing is rejected in silence. That was the
discipline you set; this document tries to honour it.

Granularity is **module-level** — meaning, in practice, one Rust source
file or one closely-related sub-directory per entry. Function-level or
line-level would have produced something nobody reads twice. Module
level is the right resolution to talk about decisions; it is also the
resolution at which the philosophy's file-size budget operates, so it
matches the rest of the project's mental model.

The verdicts are in five categories:

| Verdict | Meaning |
|---|---|
| **migrated** | The Anvil equivalent already exists. No work. Forge file is reference only. |
| **port-as-foundation** | Port with refactor. The code is sound, the design generalises, the Anvil version will resemble it closely. |
| **port-as-placeholder** | Port with refactor *and* an explicit debt entry in `PLACEHOLDER_DEBT.md`. The code's *form* is useful but its *semantics* are tied to a Forge-specific design choice that may not survive Forgeborn's GDD. The placeholder is held until a date of review when the design has clarified. |
| **rewrite** | Conceptually relevant but practically unsound — the file is too large, too entangled, or too coupled to Forge's failure modes. The replacement is written fresh against the philosophy. |
| **abandon** | No place in Anvil. Nothing to port. This category requires the most care — every entry must explain *why* it has no place, because "abandon" is the verdict that produces silent forgetting. |

Each module entry has the same shape:

> **Verdict:** one of the five above.
> **Lines (prod / total):** counted from the snapshot.
> **What it does:** technical description.
> **Why this verdict:** justification grounded in the philosophy and
> the GDD.
> **(optional) Lesson learned:** in your voice, marked.

Coverage statistics appear at the end of Part 2. There are 78 unique
production source files in Forge (113 total minus 35 duplicates and
test files); every one is listed in this journal or Part 2.

---

## Section 1 — `forge_core` (606 prod lines, 8 files)

`forge_core` is the foundation crate — the data types every other
crate uses. Every type in this crate is also in Anvil. The work here
is done.

### 1.1 — `forge_core/src/lib.rs`

**Verdict:** migrated.
**Lines:** 24 prod / 111 total.
**What it does:** The crate root. Declares the modules (`artifact`,
`connections`, `error`, `ids`, `path`, `semantic`, `world`) and
re-exports their public types.

**Why this verdict:** Anvil's `anvil_core/src/lib.rs` performs the same
function with the same set of modules (with `world/` as a directory
rather than a single file, per Commandment #4). No work to do.

### 1.2 — `forge_core/src/artifact.rs`

**Verdict:** migrated.
**Lines:** 9 prod / 9 total.
**What it does:** Defines `Versioned` and `SemanticArtifact` traits.
Every authored data type implements both — `Versioned` for save-format
compatibility, `SemanticArtifact` for validation.

**Why this verdict:** Migrated to `anvil_core::semantic`. The signature
changed from `fn validate(&self) -> Result<(), ForgeCoreError>` to
`fn validate(&self) -> ValidationErrors` — the multi-error contract that
became Commandment #2.

> **Lesson learned (yours):** This 9-line file is the *single most
> important architectural decision in either project*. A 9-line trait
> declaration commits every authored data type to a validation
> protocol. When Forge's authors changed it from `Result<(), String>`
> to `Result<(), ForgeCoreError>` — and again later when Anvil changed
> it to `ValidationErrors` — they were doing language design. I should
> remember that the smallest files often carry the heaviest weight.

### 1.3 — `forge_core/src/error.rs`

**Verdict:** migrated.
**Lines:** 41 prod / 41 total.
**What it does:** Defines `FailureClass` (Structural / Semantic / Asset /
External / Pipeline) and `ForgeCoreError` (a thiserror-derived enum).

**Why this verdict:** The classifier survives in Anvil as
`anvil_core::error::FailureClass`. The error type was rebuilt around
`ValidationErrors`, error codes (E000–E112), and the
`push_validation_error!` macro. Anvil's version is structurally
better — but Forge had the right idea about classifying errors at a
coarse level rather than treating every error type as unique.

### 1.4 — `forge_core/src/ids.rs`

**Verdict:** migrated.
**Lines:** 36 prod / 36 total.
**What it does:** Newtype IDs: `AuthoredEntityId(u64)`, `ArchetypeTag`,
`AssetPath`. Each with construction validation.

**Why this verdict:** Migrated identically. Anvil's `anvil_core::ids`
made the inner field private (`AuthoredEntityId(u64)` was `pub u64` in
Forge). A small but real privacy improvement.

### 1.5 — `forge_core/src/connections.rs`

**Verdict:** migrated.
**Lines:** 24 prod / 42 total.
**What it does:** `ConnectionId(usize)`, `ConnectionKind`,
`ConnectionSpec` — the data types for the graph between regions.

**Why this verdict:** All migrated. Anvil's version uses
`ValidationErrors` in `validate()`.

### 1.6 — `forge_core/src/world.rs`

**Verdict:** migrated.
**Lines:** 199 prod / 444 total.
**What it does:** `RegionId`, `EntityKind`, `DamageType`,
`VegetationState`, `SettlementOccupancyState`,
`SettlementReconstructionState`, `HistoryEvent`, plus a handful of
`*_label` functions.

**Why this verdict:** Anvil split this single file into a `world/`
directory: `damage.rs`, `vegetation.rs`, `settlement.rs`, `history.rs`,
`entity.rs`. The `*_label` functions were replaced by `Display`
implementations. `HistoryEvent::validate` returns `ValidationErrors`,
not `Result<(), String>`. New: `validate_event_ordering` for full event
sequences.

> **Lesson learned (yours):** This file at 199 prod lines was already
> uncomfortable. It contained six independent enums, each with its own
> `*_label` formatter function. I now see why splitting a file into
> a directory of focused modules is worth the cost — it forces each
> module to be about one thing. The `*_label` → `Display` change is the
> same insight at a smaller scale: when you find yourself writing a
> function that does what a trait could do, the trait is usually right.

### 1.7 — `forge_core/src/semantic.rs`

**Verdict:** migrated.
**Lines:** 199 prod / 332 total.
**What it does:** `TerrainType`, `RegionSpec`, `LandmarkSpec`,
`StyleHints` — the types describing the *authored* world before
compilation.

**Why this verdict:** Migrated to `anvil_core::semantic`. The
`SemanticArtifact` impls return `ValidationErrors`. Anvil added
`AssetRequestSpec` (an enrichment over `LandmarkSpec`) — that type does
not exist in Forge.

### 1.8 — `forge_core/src/path.rs`

**Verdict:** migrated.
**Lines:** 74 prod / 74 total.
**What it does:** `repo_root()` — returns the workspace root, computed
from `CARGO_MANIFEST_DIR` and a fixed depth (every Forge crate is two
levels below the repo root).

**Why this verdict:** Migrated to `anvil_core::path`, with a known
caveat: the `expect()` calls at lines 75 and 82 of the Anvil version
are flagged in the Phase-1 work as marginal panics. Forge has the same
calls and the same risk — fixing it in Anvil also gives the discipline
to fix it in any future port.

### Summary, `forge_core`

- **Files: 8.** All migrated.
- **Prod lines: 606.** Already in Anvil.
- **Work to do: zero.**

The migration of this crate is the part of Anvil that is in the
healthiest state. The rest of this journal exists, in part, because
the crates above this one are not yet in equally good shape.

---

## Section 2 — `forge_world` (1,505 prod lines, 1 file)

A single 1,505-line file. The largest production file in any
non-`forge_bevy` crate. Most of it is migrated; a substantial chunk —
the DemoVista subsystem — is not.

### 2.1 — `forge_world/src/lib.rs`

**Verdict:** mixed (split below).

The file decomposes into roughly four sections:

#### 2.1.a — Core compile pipeline (lines 1–80, 651–1,300)

**Verdict:** migrated.
**What it does:** `WorldAuthored`, `Region`, `AuthoredEntity`,
`AuthoredConnection`, `AssetReferenceTable`, `AssetReference`,
`WorldMetadata`, `CompileError`, `compile_region`, `compile_world`,
`compile_world_with_history`, `generate_history_events`,
`compute_specs_hash`, `hash_to_seed`, `history_events_digest`,
`report_history_digest`, `HistoryDigestReport`,
`WorldAuthored::validate`.

**Why migrated:** Anvil's `anvil_world` has all of these, refactored
into multiple files (`compiler.rs`, `validation.rs`, `hashing.rs`,
`history.rs`). The `generate_history_events` SplitMix64 RNG is the
same in both projects — verified by direct code comparison. Determinism
is preserved.

#### 2.1.b — DemoVistaLayout subsystem (lines 81–650, ~570 lines)

**Verdict:** port-as-placeholder.
**What it does:** Defines a hand-authored vista layout for a single
demo scenario. Includes `DemoVistaAnchorRole` (an enum of named
positions: LeftRidgeTower, RightRidgeTower, BasinFocus, etc.),
`DemoVistaCameraGuide` (for fixed cinematic camera shots),
`DemoVistaTerrainMacroform`, `DemoVistaSurfaceBand`,
`DemoVistaVegetationZone`, `DemoVistaSurfaceReadAuthority`,
`DemoVistaHeroAssetRole`, `DemoVistaVegetationFamilyRole`,
`DemoVistaHeroAssetSelection`, `DemoVistaHeroResolution`,
`DemoVistaVegetationFamilySelection`, `DemoVistaHeroAssetKit`,
`DemoVistaSurfaceReadSample`, `DemoVistaAnchor`, `DemoVistaLayout`,
`DemoVistaLayout::validate_band`.

**Why port-as-placeholder:** the system encodes a **specific demo
scenario's authored layout**. It is not generic worldbuilding — it is
a fixture for a hand-curated showcase. Forgeborn's first demo will not
necessarily be a curated showcase; it might be a procedurally-generated
3-region scenario. If the latter, this entire subsystem is dead weight.
If the former, it is exactly what's needed.

The placeholder is held until the GDD's first-hour-experience section
is drafted (Phase 3 sprint 14 in the revised sprint plan). At that
point a decision is taken: port the DemoVista as `anvil_world::vista`,
or delete the placeholder and write something simpler.

> **Lesson learned (yours):** I see the trap. Forge built a beautiful
> showcase scenario as a *programming exercise*, then committed to it
> as a feature. Once `DemoVistaLayout` was a dependency of
> `forge_bevy`, deleting it became expensive. Anvil should not inherit
> that lock-in. The placeholder pattern is precisely how to avoid it:
> hold the design space open, decide later, **write the decision down**.

#### 2.1.c — Region utility functions (~50 lines, scattered)

**Verdict:** migrated.
**What it does:** Small helpers like `WorldAuthored::validate`,
`WorldAuthored::find_region`, etc.

**Why migrated:** Equivalents in `anvil_world`.

#### 2.1.d — Tests (lines 1300+)

**Verdict:** abandon (as code), reference (as test patterns).
**What it does:** A unit-test suite covering `compile_world`,
`generate_history_events`, hashing, etc.

**Why abandon:** Anvil has its own tests. Forge's tests are a useful
*reference* — they show what behaviours the authors thought worth
testing — but the actual code is not portable because the API and
error types have drifted. The patterns may be lifted; the lines should
not be copied.

### Summary, `forge_world`

- **Files: 1.** Split into four logical sections at port time.
- **Prod lines: 1,505.** ~860 migrated, ~570 port-as-placeholder, ~75
  reference-only.
- **Work to do (port-as-placeholder path):** estimated 5 days if
  pursued.

> **Lesson learned (yours):** A 1,505-line file is what happens when
> you don't enforce file size *and* the same crate handles two
> separable concerns. The compile pipeline and the DemoVista layout
> have nothing to do with each other except that they both produce
> data structures consumed by `forge_bevy`. Splitting them at the
> file level was the obvious move; nobody made it. Anvil's
> Commandment #4 exists to make sure I don't make the same omission.

---

## Section 3 — `forge_semantic` (358 prod lines, 7 files)

This crate is the LLM-driven region generator. It builds prompts,
calls an LLM, parses the response, and maps errors to `FailureClass`.

### 3.1 — `forge_semantic/src/lib.rs`

**Verdict:** abandon.
**Lines:** ~10 prod.
**What it does:** Re-exports `LlmConfig`, `call_llm`, `LlmError`,
`SemanticError`, `generate_region`, `extract_json`,
`parse_region_response`, `build_region_prompt`.

**Why abandon:** Anvil's pipeline does not include an in-process LLM
client. The Anvil philosophy (Commandment #1) bans LLM crates from
the deterministic crates entirely. LLM-driven content authoring is
build-time tooling that lives outside the game's runtime — most
naturally in a separate authoring repository or as ad-hoc scripts.
Forgeborn does not need to ship with `reqwest` and an LLM dependency
in its production graph.

### 3.2 — `forge_semantic/src/client.rs`

**Verdict:** abandon.
**What it does:** `LlmConfig`, `call_llm` — HTTP client that posts to
an Anthropic-compatible endpoint and returns the response body.

**Why abandon:** Same reason. If Forgeborn ever wants this capability
again, it will live in a build-time tool, not in a published crate.
The HTTP boilerplate is 5 minutes to rewrite.

### 3.3 — `forge_semantic/src/errors.rs`

**Verdict:** abandon.
**What it does:** `LlmError` (connection/timeout/empty/etc),
`SemanticError`. Maps each to a `FailureClass`.

**Why abandon:** The mapping discipline is good (LLM errors are
classified rather than treated as opaque). When the LLM tooling is
rebuilt elsewhere, this classification belongs there too. The Anvil
crates do not need to know LLMs exist.

### 3.4 — `forge_semantic/src/generate.rs`

**Verdict:** abandon.
**What it does:** `generate_region(config: &LlmConfig, prompt: &str) ->
Result<RegionSpec, SemanticError>` — orchestrates prompt build, call,
parse, retry on parse failure.

**Why abandon:** Same reason; the orchestration logic is simple.

### 3.5 — `forge_semantic/src/parser.rs`

**Verdict:** abandon, with one exception.
**What it does:** `extract_json(text: &str) -> Result<&str, SemanticError>` —
finds and extracts the JSON portion of an LLM response that may
contain markdown fences and prose. Plus `parse_region_response`.

**Why abandon:** The same reason as the rest of the crate — but
`extract_json` is a useful 30-line utility that any future LLM tooling
will want. **Keep a copy in your notes.** Don't put it in Anvil.

### 3.6 — `forge_semantic/src/prompt.rs`

**Verdict:** abandon.
**What it does:** `build_region_prompt(seed: &str, terrain: TerrainType)` —
constructs the prompt string for region generation.

**Why abandon:** The actual prompt is a Forge-specific design choice;
Forgeborn's prompt strategy will differ. The patterns of structured
prompts are general; the specific text is not.

### 3.7 — `forge_semantic/examples/generate_region.rs` and `forge_semantic/examples/llm_smoke.rs`

**Verdict:** abandon.
**What they do:** `generate_region.rs` is an example binary that calls
`generate_region` against a configured LLM and prints the resulting
`RegionSpec` as JSON. `llm_smoke.rs` is a tiny smoke test that
verifies the LLM endpoint responds at all.

**Why abandon:** Bound to the abandoned `forge_semantic` crate. Both
are 30–50 line demo binaries that would take longer to port than to
rewrite if/when the LLM tooling reappears outside the production
graph.

### Summary, `forge_semantic`

- **Files: 7.** All abandoned.
- **Prod lines: 358.** None go into Anvil.
- **Work to do: zero** (in Anvil); however, if/when LLM build-tooling
  is reconstituted separately, `parser::extract_json` is a good
  starting reference.

> **Lesson learned (yours):** Forge embedded an LLM client inside its
> production crates. That was a category error: the LLM is an authoring
> tool, not a runtime dependency. Anvil's firewall (Commandment #1)
> draws this line explicitly. Re-reading this in six months, I should
> remember that crates I add to Anvil's workspace become *part of the
> game*. Tools belong elsewhere.

---

## Section 4 — `forge_materialize` (2,270 prod lines, 4 files)

This crate transforms an `AssemblyPlan` (entities with abstract
positions) into a `MaterializedWorld` (entities with concrete
world-space coordinates, on a heightmap, with terrain, with
narrative-driven decoration). It is the bridge between authored
content and rendered scene.

### 4.1 — `forge_materialize/src/lib.rs`

**Verdict:** port-as-foundation.
**Lines:** ~150 prod.
**What it does:** Module declarations and the public API:
`materialize`, `compute_materialized_hash`, `MaterializedAuthorityReport`,
`report_materialized_authority`, `MaterializeError`.

**Why port-as-foundation:** This is exactly what `anvil_runtime` needs
as its world-materialisation layer. The signature is right:
`fn materialize(plan: &AssemblyPlan, world: &WorldAuthored, ...) ->
Result<MaterializedWorld, MaterializeError>`. Refactor for
`ValidationErrors`, file-size budget, and Anvil's error taxonomy.

### 4.2 — `forge_materialize/src/types.rs`

**Verdict:** port-as-foundation.
**Lines:** ~150 prod.
**What it does:** `MaterializedWorld`, `MaterializedRegion`,
`MaterializedConnection`, `TerrainData` (heights + splat),
`PlacedEntity`, `DecorationProfile`, `WorldBounds`,
`MaterializeMetadata`. All `Serialize`/`Deserialize`.

**Why port-as-foundation:** These types define the runtime-ready scene.
They survive porting cleanly. The one design call: `PlacedEntity`
includes `albedo_texture` and `normal_texture` paths — texture
resolution that Anvil's pipeline already handles at the catalogue
layer. Anvil's `PlacedEntity` should reference an `AssetEntry` instead
of repeating the texture paths. Trivial change at port time.

### 4.3 — `forge_materialize/src/terrain.rs`

**Verdict:** port-as-foundation.
**Lines:** ~750 prod (estimated; the file is 750 total).
**What it does:** `generate_terrain(...)` — produces a `TerrainData`
from a region spec. Uses Perlin noise with terrain-type-specific
parameters (Highlands: amplitude 30, frequency 0.008, 5 octaves;
Marsh: amplitude 4, frequency 0.020; etc.). Plus `calculate_slope_at`.

**Why port-as-foundation:** Pure function. Deterministic. Already
parameterised by `TerrainType`. The exact noise parameters per
terrain are calibrated values that should survive porting; the
*choice* of Perlin noise is a starting point that Forgeborn might
revisit (more on this in the lesson below).

> **Lesson learned (yours):** The terrain-generation module shows the
> right way to structure pure deterministic systems: parameter struct
> per terrain type, single noise generator, calibrated by hand. When
> I rewrite the catastrophe system in Phase 3, I should follow the
> same shape: parameters per `DamageType`, deterministic generator,
> calibrations as `const`. The data flow Forge got right is also the
> data flow Anvil should respect.

### 4.4 — `forge_materialize/src/layout.rs`

**Verdict:** port-as-foundation, with hard refactor.
**Lines:** 2,531 prod / 6,556 total. *This is the second-largest file
in Forge.*
**What it does:** `place_entities_for_region`, `apply_history_to_placements`,
`inject_surface_storytelling_patches`, plus internal helpers for
collision avoidance, footprint computation, density rules, and
narrative decoration (e.g., burned ground patches near history-event
epicenters).

**Why port-as-foundation with hard refactor:** the *design* is sound —
this is real, working entity placement. But the *file* is a maintenance
disaster. At port time it must split into:
- `layout/place.rs` (entity placement core)
- `layout/footprint.rs` (collision and density)
- `layout/history.rs` (post-placement history mutation)
- `layout/storytelling.rs` (narrative patches)

Each module under 500 prod lines per Commandment #4. The work is
substantial — splitting a 6,500-line file requires understanding what
its sub-functions do — but the alternative (rewriting placement from
scratch) is much larger.

> **Lesson learned (yours):** This is the file that, by itself,
> proves why Anvil's file-size CI gate is non-negotiable. At 6,556
> lines, no human can fully review a change to this file. Forge let
> it grow because there was no enforcement; Anvil's gate would have
> stopped it at 500. When I port `layout.rs`, the *first* commit
> after the port should be the four-way split — not later, not
> "when I have time", but immediately, before any other change lands.

### Summary, `forge_materialize`

- **Files: 4.** All port-as-foundation.
- **Prod lines: 2,270.** ~2,200 portable.
- **Work to do:** ~10 work-days. Most of it is splitting `layout.rs`.

---

*Section 5 — `forge_assembly`, Section 6 — `forge_sim`, Section 7 —
`forge_bevy`, and the conclusion are in **Part 2**. They are the
larger and more design-loaded sections; splitting the document keeps
each part readable in one sitting.*
