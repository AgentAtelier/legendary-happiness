---
id: FORGE_HARVEST_JOURNAL_PART2
title: FORGE HARVEST JOURNAL PART2
status: archived
audience: [developer]
last_reviewed: 2026-05-10
supersedes: []
tags: [historical]
related_docs: []
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: []
---

# Forge Harvest Journal — Part 2

*Continuation of Part 1. Sections 5, 6, 7, and the conclusion.*

---

## Section 5 — `forge_assembly` (3,758 prod lines, 1 file)

A single 3,758-line file with two distinct responsibilities. The
file's name suggests one — assembling a `WorldAuthored` into an
`AssemblyPlan` — but the file actually does two things, and the
second (scenario-bundle reporting) accounts for nearly half of its
size. Both are useful; the verdicts differ.

### 5.1 — `forge_assembly/src/lib.rs`

**Verdict:** mixed (split below).

#### 5.1.a — AssemblyPlan core (~1,800 prod lines)

**Verdict:** port-as-foundation.
**What it does:** `AssemblyPlan`, `EntityPlan`, `RegionPlan`,
`ConnectionPlan`, `Transform3D`, `ResourceDecl`, `ResourceKind`,
`GameRulesResource`, `TerrainResource`, `LightingResource`,
`PlayerStartResource`, `LocalEffectEmitter`,
`LocalEffectEmittersResource`, `compile_plan(world: &WorldAuthored,
materialized: &MaterializedWorld) -> Result<AssemblyPlan, ...>`,
`compute_plan_hash`, `WorldPlanAuthorityReport`,
`report_world_plan_authority`.

**Why port-as-foundation:** This is the data structure that bridges
`WorldAuthored` (logical) and `MaterializedWorld` (concrete) to give
the runtime everything it needs in one place: entities with
transforms, regions with terrain references, lighting setup, the
player's start position, the resource graph. It is exactly the input
shape `anvil_runtime::Runtime::new` should accept.

The `WorldPlanAuthorityReport` is a small but interesting addition:
it's a hash-and-digest comparison that proves a given `AssemblyPlan`
was actually derived from a given `WorldAuthored`. This guards against
loading a plan against the wrong world by accident. Worth keeping.

> **Lesson learned (yours):** The Forge authors built an authority
> chain: `world.json` produces `plan.json` produces `materialized.json`,
> and each layer carries a hash of the previous. If any layer is
> regenerated and another layer is stale, the report flags it. This
> is a real failure mode in any deterministic pipeline — and Anvil
> doesn't yet have it. Phase 1 should add this. Three modest reports
> (`WorldPlanAuthority`, `MaterializedAuthority`, `SaveHistoryIntegrity`)
> form a chain that catches stale-artefact bugs without requiring a
> full rebuild every time. Cheap, deterministic, valuable.

#### 5.1.b — Scenario bundle reporting (~1,500 prod lines)

**Verdict:** port-as-placeholder.
**What it does:** `ScenarioArtifactBundleReport`,
`ScenarioBundleReproducibilityReport`,
`ScenarioBundleReproducibilitySuiteReport`,
`ScenarioBundleManifest`, `ScenarioBundleManifestError`,
`ScenarioBundleMembershipSource`,
`ScenarioBundleMaintenanceReport`,
`ScenarioBundleMaintenanceSuiteReport`,
`ScenarioBundleRefreshReport`,
`ScenarioBundleRefreshSuiteReport`,
`ScenarioBundleWriteStatus`,
`report_scenario_artifact_bundle`,
`report_scenario_bundle_reproducibility`,
`report_scenario_bundle_maintenance`,
`report_scenario_bundle_suite`,
`report_scenario_bundle_reproducibility_suite`,
`report_scenario_bundle_refresh`,
`report_scenario_bundle_refresh_suite`.

**Why port-as-placeholder:** I previously classified this as
"infrastructure overgrowth — abandon." That was wrong. On closer
reading, this is a *scenario-bundle audit pipeline*: it verifies that
a directory containing `world.json` + `plan.json` + `materialized.json`
+ scenario inputs is internally consistent (right hashes everywhere),
and it can refresh the bundle when scenarios are edited.

This is genuinely useful machinery — *if Anvil ships scenario
bundles*. It's not yet clear that Forgeborn will. The save format
travels separately from the bundle format. The placeholder is held
until the scenario distribution model is defined (probably during
Phase 4 modding-API work). At that point, either port the bundle
auditor as `anvil_assembly::scenarios`, or delete the placeholder.

> **Lesson learned (yours):** I was too quick to dismiss this section
> the first time. "Reports about reports" is a glib summary; the
> actual machinery is solving a real problem (stale bundles in shared
> repos). My initial reaction reflected the philosophy's bias against
> infrastructure-for-its-own-sake — which is correct as a default, but
> defaults must be challenged when the code is read carefully. The
> placeholder pattern lets me hold the question open without losing
> the work.

### Summary, `forge_assembly`

- **Files: 1** (split conceptually into two halves).
- **Prod lines: 3,758.** ~1,800 port-as-foundation, ~1,500
  port-as-placeholder, ~450 boilerplate / Display impls / tests.
- **Work to do:** 8 work-days for the foundation half (in Phase 2);
  the placeholder is held with a debt entry.

---

## Section 6 — `forge_sim` (7,868 prod lines, 14 source files + `live/` directory)

This is the crate that justifies the harvest audit. It is the
deterministic gameplay simulation: time, weather, regions, quests,
saves, invariants. It is also the largest non-`forge_bevy` crate, by
some distance. Most of it is portable; some of it is portable only as
placeholder; almost none of it is abandoned.

I'm going to take more space with this section because the design
choices in `forge_sim` are the ones most directly relevant to
Forgeborn's gameplay sections of the GDD.

### 6.1 — `forge_sim/src/lib.rs`

**Verdict:** port-as-foundation.
**Lines:** 68 prod.
**What it does:** Module declarations and a long list of public
re-exports. Defines a `trace_record!` macro that compiles to nothing
in production (gated behind `progression_trace` feature flag).

**Why port-as-foundation:** Becomes the shape of `anvil_runtime/src/lib.rs`.
The `trace_record!` macro pattern — feature-gated debug instrumentation
that's a no-op in release — is worth keeping. It's a clean way to
add observability without paying for it in the steady state.

### 6.2 — `forge_sim/src/types.rs`

**Verdict:** port-as-foundation.
**Lines:** 202 prod.
**What it does:** `SimWorld` (the central simulation state container),
`EvidenceSeverityBand` (Trace/Faint/Pronounced/Severe), and other
shared types.

**Why port-as-foundation:** `SimWorld` corresponds directly to what
`anvil_runtime` needs as its top-level state. The severity bands are
useful for any `DamageType`-driven gameplay. Port with refactor.

### 6.3 — `forge_sim/src/time.rs`

**Verdict:** port-as-foundation.
**Lines:** 233 prod / 472 total.
**What it does:** `GameTime` struct with `seconds_since_start` and
`day_length_seconds` (default 120s). `tick_time(time, dt)` advances
time. `day_phase()` returns [0, 1] for the current point in the day.

**Why port-as-foundation:** Exactly the time scaffolding the GDD
needs. The day-night cycle in the Forgeborn preamble (austere world,
joy events at specific times) maps onto `day_phase`. The 120-second
default is a Forge calibration that Forgeborn will probably change —
but the *shape* is right.

> **Lesson learned (yours):** A 233-line file for time. That feels
> excessive at first glance, but reading it: time is harder than it
> looks. There's the `GameTime` struct, an `advance_time` for explicit
> jumps (used by save/restore), serialization, default day length,
> phase computation with safe-guard for zero division, conversion
> helpers between phase and 0..1, and tests. Each piece is necessary.
> The lesson is: when something feels "obviously simple," it usually
> isn't. The 50-line function budget will sometimes feel constraining
> on time-like systems; this file argues that 50 is a reasonable
> *function* limit, not necessarily a reasonable *file* limit. Forge's
> 233 prod lines split across 7 functions (~33 lines each) is fine.

### 6.4 — `forge_sim/src/weather.rs`

**Verdict:** port-as-foundation.
**Lines:** 328 prod / 473 total.
**What it does:** `WeatherState` enum (Clear/Overcast/Rain/Fog/Storm).
`WeatherSimulation` struct with `temperature`, `humidity`, `pressure`,
`wind_speed`, `wind_direction`, `accumulated_precipitation`,
`current_weather`, `transition_progress`, `next_weather`,
`phase_remaining_secs`, `rng_state`. Constants:
`MIN_PHASE_SECONDS=40`, `MAX_PHASE_SECONDS=180`,
`TRANSITION_SECONDS=20`, `RAIN_RATE=0.05 mm/s`, `STORM_RATE=0.18 mm/s`.
Per-state cloud cover and base fog intensity tables.
`tick_weather(sim, dt)` advances the state machine deterministically.
`from_seed(seed)` constructs a deterministic initial state.

**Why port-as-foundation:** This is the cleanest piece of code in
Forge. It implements a deterministic weather state machine with
calibrated transition timings, includes humidity and wind as
first-class observable values (which the GDD's Pillar I explicitly
needs as precursor signals), and the LCG-based RNG is reproducible
across machines.

This file also illustrates exactly what Phase 3 sprint 15
(catastrophe system) should look like *after generalisation*:
the same shape extended from 5 weather states to N catastrophe types.
The work in Phase 3 is to keep this structure and add `Earthquake`,
`Fire`, `Flood`, `Drought` events, with their own precursor signals
(humidity → flood; wind → fire; tremors → quake).

> **Lesson learned (yours):** This is the model file for the GDD's
> "predictable in kind, unpredictable in timing" principle. Every
> weather event has a *kind* (Rain, Storm, etc.) the player can learn
> to recognise; the *timing* is bounded by `MIN_PHASE_SECONDS` and
> `MAX_PHASE_SECONDS` but pseudo-random within that window. Reading
> this code, I now see how to express the GDD principle as machinery:
> a state machine, a phase duration distribution, and observable
> precursor variables. Anvil's catastrophe system in Phase 3 sprint
> 15 should look very much like this file, generalised.

### 6.5 — `forge_sim/src/region.rs`

**Verdict:** port-as-foundation.
**Lines:** 122 prod / 289 total.
**What it does:** `current_region_for_position`,
`nearest_region_for_position`, `region_for_position`,
`connection_allows_region_transition`, `resolve_region_transition`.
Pure spatial queries against a compiled `WorldAuthored`.

**Why port-as-foundation:** Region resolution is exactly what
`anvil_streaming` needs to decide which region the player is in. Port
with no semantic changes.

### 6.6 — `forge_sim/src/step.rs`

**Verdict:** port-as-foundation.
**Lines:** 110 prod / 418 total.
**What it does:** `step_sim_world(sim: &mut SimWorld, dt: f32)` —
the central tick function. Calls `tick_time`, `tick_weather`,
`tick_quests`, region update, plus a few hooks for evidence
consequences and route plans.

**Why port-as-foundation:** The dispatch pattern is right. Anvil's
`Runtime::apply(RuntimeCommand::Tick { dt })` should route through
something very similar. The list of subsystems will differ
(`anvil_sim::settlements` and `anvil_sim::npcs` join the list, the
quest piece is replaced by emergent-quest logic per GDD Principle 3),
but the orchestration shape survives.

### 6.7 — `forge_sim/src/player.rs`

**Verdict:** port-as-foundation.
**Lines:** 97 prod / 188 total.
**What it does:** `PLAYER_GROUND_OFFSET` (1.5m above ground),
`PLAYER_MOVE_SPEED` (4.5 m/s). `step_player(sim, input, dt)` updates
the player's position based on input. Performs ground-following and
basic collision against the heightmap.

**Why port-as-foundation:** Survives almost as-is. The constants
might be tuned in Forgeborn (slower walk speed for the austere
tone?), but the structure is right. Note: this is currently a
*custom* movement implementation, not Rapier. Phase 3 sprint 19
replaces it with Rapier; until then, the simple version is good
enough.

### 6.8 — `forge_sim/src/terrain.rs`

**Verdict:** port-as-foundation.
**Lines:** 56 prod / 94 total.
**What it does:** Small helpers for terrain queries against
`MaterializedWorld::terrain.heights`.

**Why port-as-foundation:** Tiny, pure, useful. Port.

### 6.9 — `forge_sim/src/invariants.rs`

**Verdict:** port-as-foundation.
**Lines:** 228 prod / 316 total.
**What it does:** Runtime invariant assertions. Things like "every
active quest's region exists in the authored world", "every
participating entity ID resolves", "no entity is in two regions at
once". Returns a `Vec<InvariantFailure>` for inspection.

**Why port-as-foundation:** This is the runtime equivalent of the
authority-report pattern from `forge_assembly`. It catches state
corruption before it propagates. Anvil should have this; today it
does not. Phase 2 sprint 7 is the natural home.

> **Lesson learned (yours):** Forge built two complementary
> integrity systems: *authority reports* (verify hash chains across
> static artefacts) and *invariants* (verify dynamic state during
> simulation). Together they form a quiet defence against the failure
> mode where state silently goes wrong and only manifests as a crash
> hours later. Anvil deserves the same defence. The cost is small —
> a few hundred lines, mostly assertions — and the payoff is in bugs
> caught before they reach players.

### 6.10 — `forge_sim/src/save.rs`

**Verdict:** port-as-foundation, with hard refactor.
**Lines:** 725 prod / 2,630 total. *The largest file in `forge_sim`.*
**What it does:** `SaveFile` struct (current version v5).
`SaveFileV4` struct for migration. `parse_and_upgrade_save` with v4 →
v5 path. `SAVE_FORMAT_VERSION = 5`. `SaveError` enum.
`SaveHistoryIntegrityReport` and `inspect_save_history_integrity`.
Actual serialization to/from JSON.

**Why port-as-foundation with hard refactor:** Save format design is
something Forge got right: explicit version field, migration path
between consecutive versions, integrity check that the save's
history-events match its claimed digest. The implementation needs to
be split per Commandment #4: `snapshot/format.rs` (the structs and
version constant), `snapshot/migration.rs` (v4→v5, future v5→v6),
`snapshot/integrity.rs` (digest verification),
`snapshot/serde_helpers.rs` (any custom deserialisers).

The migration story is also a teaching moment: Forge can load a v4
save and produce a v5 in memory by adding `notes: None`. That is
the *minimum viable migration*. Anvil's save layer should require a
migration test for *every* version bump, no exceptions.

> **Lesson learned (yours):** A 725-line file for save format is
> what real save formats look like. JSON serialization with explicit
> version handling, migration logic, integrity reporting — none of
> it is exciting, all of it is necessary. The discipline is to keep
> migrations simple enough to read in one screen. v4 → v5 here is
> seven lines. Future migrations can be just as clean if I never let
> a single migration handle two unrelated changes at once.

### 6.11 — `forge_sim/src/quest.rs`

**Verdict:** port-as-placeholder.
**Lines:** 86 prod / 738 total. *Much of this file's bulk is tests.*
**What it does:** `QuestId(u64)`, `QuestState` (Inactive/Active with
objectives/Completed), `QuestObjective` enum (VisitRegion,
VisitSettlementInState, InvestigateFactionPresence,
InvestigateDamagedNonSettlement, ActivateLandmark,
SubmitSurveyJudgment), `NonSettlementArchetypeFamily`
(Tower/Ruin/Stone), helpers to build expedition objectives, and
`tick_quests`.

**Why port-as-placeholder:** This is a quest system. The Forgeborn
GDD's Principle 3 explicitly forbids quest logs and exclamation-mark
quest-givers. *But* the underlying machinery — a state-machine that
tracks objectives, completion, and lets the simulation surface
"things to do" — is exactly the substrate that *emergent* quests
need too. The visible UX changes; the data structures might not.

The placeholder is held until the Forgeborn GDD's
emergent-quest section is drafted (Phase 3 sprint 14). Possible
outcomes: keep `QuestState` and `QuestObjective` with new
variant names that match the GDD's vocabulary (e.g., "errand" or
"open thread"); or replace entirely with a different model
(e.g., NPCs ask for help and forget if you don't respond).

> **Lesson learned (yours):** "Quest" is a loaded word. Reading
> Forge's `quest.rs`, I see that the underlying machinery is just
> a state machine over named objectives — which is also what
> "emergent things to do" looks like internally. The GDD's rejection
> of quest *logs* and quest *markers* doesn't necessarily reject
> quest *state*. The visible UX changes; the substrate might not.
> This is the right time to remember that "diegetic" is about
> *presentation*, not implementation.

### 6.12 — `forge_sim/src/survey.rs`

**Verdict:** port-as-placeholder.
**Lines:** 201 prod / 407 total.
**What it does:** `derive_survey_chain`, `route_after_judgment`,
`route_message`, plus `diagnosis_for_damage`. Forge's survey system
is a guided-investigation gameplay loop where the player diagnoses
damaged landmarks and is recommended a chain of follow-up
investigations.

**Why port-as-placeholder:** Forgeborn does not yet have a
declared survey-style gameplay loop. The investigation pattern is
interesting machinery — chain-recommendation logic — and
generalises beyond the specific Forge gameplay. Hold the placeholder
until Forgeborn's gameplay sections are drafted.

### 6.13 — `forge_sim/src/trace.rs`

**Verdict:** port-as-foundation.
**Lines:** 136 prod / 183 total.
**What it does:** Optional progression tracing, feature-gated. Records
state transitions during simulation runs for debugging. Compiles to
nothing in release builds.

**Why port-as-foundation:** Cheap, useful for catching determinism
regressions. The pattern (feature-gated compilation, in-memory
buffer, dump on demand) is correct. Port.

### 6.14 — `forge_sim/src/build.rs`

**Verdict:** port-as-foundation.
**Lines:** 8 prod / 918 total. *Most of this file is tests.*
**What it does:** Build-script that emits a constant for the build
timestamp or commit hash. Used in the save format's metadata field.

**Why port-as-foundation:** 8 lines. Trivial.

### 6.15 — `forge_sim/src/live/mod.rs`

**Verdict:** port-as-foundation.
**Lines:** 6 prod / 157 total.
**What it does:** Module declarations for `live/`.

### 6.16 — `forge_sim/src/live/state.rs`

**Verdict:** port-as-placeholder.
**Lines:** 293 prod.
**What it does:** `WorldLive` struct (the dynamic gameplay state
layered on top of `WorldAuthored`). Contains entity activations,
survey state, route plans, evidence consequences, completed regions,
expedition timestamps. `EntityLiveState`, `SurveyDiagnosis`,
`SurveyEntryState`, `SurveyState`, `EvidenceConsequence`,
`SurveyRouteDecision`, `SurveyRouteReason`, `SurveyRouteHop`,
`SurveyRoutePlan`.

**Why port-as-placeholder:** `WorldLive` is conceptually right — it
is the runtime-mutable layer above the immutable `WorldAuthored`. The
specific fields are tied to Forge's gameplay (survey, expeditions).
For Forgeborn the field set will be different (settlements, NPCs,
catalysts, active catastrophes), but the *layered* design is correct.

The placeholder holds the design pattern; the field list will be
rewritten as gameplay is defined.

### 6.17 — `forge_sim/src/live/evidence.rs`

**Verdict:** port-as-placeholder.
**Lines:** 101 prod.
**What it does:** Helpers for converting `HistoryEvent`s and
`PlacedEntity` damage states into `EvidenceConsequence` records used
by the survey gameplay.

**Why port-as-placeholder:** Same reason as `state.rs`. The pattern
of "translate world data into gameplay-shaped data" is right; the
specific shapes will change.

### 6.18 — `forge_sim/src/live/recommendations.rs`

**Verdict:** port-as-placeholder.
**Lines:** 983 prod.
**What it does:** Region investigation priority scoring. A weighted
sum of signals: severity, damaged landmark count, vegetation
variety, faction variety, damaged settlements, abandoned settlements,
razed settlements, repairing settlements, heavy/moderate damaged
non-settlements (towers, ruins, stones), active route bonuses, route
history bonuses, incorrect-diagnosis penalties, remaining-landmark
weights. ~30 weight constants. Computes a per-region priority score
and recommends the next expedition target.

**Why port-as-placeholder:** This is the most interesting placeholder
in Forge. The *file* is dense — 983 prod lines of weight tuning and
scoring logic — but the *pattern* is exactly utility-AI scoring. The
GDD's NPC behaviour will need utility-AI scoring (Phase 3 sprint 17).
The Forge weights are calibrated for survey gameplay; the Forgeborn
weights will be calibrated for NPC needs (Food, Shelter, Safety,
Sleep, Companionship, Purpose, Joy). The structure is reusable; the
constants are not.

> **Lesson learned (yours):** I dismissed this file in my first
> audit pass as "gameplay-tied to Forge's specific quest design,"
> and that was lazy. Reading it now, I see that it's a real
> implementation of weighted-utility scoring — exactly the substrate
> NPCs in Forgeborn need to make decisions. The weights are wrong
> for me; the *machinery* is right. The placeholder pattern lets me
> port the machinery and rewrite the weights when the GDD says what
> NPCs care about. This is the kind of file the maximalist port
> strategy is *for*.

### 6.19 — `forge_sim/src/live/routes.rs`

**Verdict:** port-as-placeholder.
**Lines:** 361 prod.
**What it does:** Route-planning logic for the survey expedition
gameplay. Scores candidate next-hops by damage type match, archetype
family match, vegetation match, settlement occupancy match, faction
overlap, raw severity. Builds `SurveyRoutePlan` with hop sequences.

**Why port-as-placeholder:** Same pattern as `recommendations.rs` —
weighted scoring of candidates, applied to route hops instead of
regions. Reusable substrate; rewrite the weights for Forgeborn's
gameplay.

### 6.20 — `forge_sim/src/live/completion.rs`

**Verdict:** port-as-placeholder.
**Lines:** 330 prod.
**What it does:** Detects when an expedition is complete based on
quest objectives and survey submissions. Computes overall progress
percentages.

**Why port-as-placeholder:** Forgeborn may not have "expeditions" as
a discrete concept. But the underlying machinery — detect when a
collection of objectives reaches a satisfaction threshold — is
useful for any task model.

### 6.21 — `forge_sim/src/live/submission.rs`

**Verdict:** port-as-placeholder.
**Lines:** 168 prod.
**What it does:** Handles the player's submission of survey
diagnoses, with judgment-correctness scoring against the authored
ground truth. Triggers route-decision events.

**Why port-as-placeholder:** Tied to survey gameplay. Hold.

### 6.22 — `forge_sim/src/live/tests.rs`

**Verdict:** abandon (as code), reference (as test patterns).
**Lines:** 3,026 prod.
**What it does:** Comprehensive test suite for the live/ subsystem.

**Why abandon:** Forgeborn's gameplay tests will look different;
copying these tests verbatim would test the wrong thing. They serve
as reference for *what scenarios to test* — coverage patterns, edge
cases, sequence-of-events tests — but not as code to lift.

### 6.23 — `forge_sim/tests/expedition_full_integration.rs` and `progression_transitions.rs`

**Verdict:** abandon (as code), reference.
**What they do:** Integration tests that run a full expedition
end-to-end and verify state transitions.

**Why abandon:** Same reason as `live/tests.rs`. Tied to Forge's
gameplay specifics.

### Summary, `forge_sim`

- **Files: 14 + `live/` directory of 7.**
- **Prod lines: 7,868.**
- **Verdict breakdown:** ~3,500 port-as-foundation; ~2,400
  port-as-placeholder (mostly `live/`); ~2,000 abandon (tests).
- **Work to do:** ~30 work-days for foundation porting (Phase 2);
  placeholders held until corresponding GDD sections are drafted.

> **Lesson learned (yours):** `forge_sim` is the strongest crate in
> Forge by quality of code and design-per-line. The fact that it
> survives so much of the maximalist port is not coincidence: the
> design problems it solved (deterministic time, state-machine
> weather, save format with migrations, runtime invariants) are
> general problems with general answers. The crates that do not
> survive the port (`forge_semantic`, large parts of `forge_bevy`)
> are the ones that solved Forge-specific problems with
> Forge-specific code. The lesson generalises: code that solves
> *general* problems is recoverable; code that solves *specific*
> problems usually isn't.

---

## Section 7 — `forge_bevy` (31,281 prod lines, 32 source files)

The presentation crate. This is where Forge's failure crystallised
in `lib.rs` at 18,991 lines. But the crate also contains many small,
focused files that ARE portable. The harvest here is highly
selective: by file, not by crate.

I will be brief on each file because the patterns repeat. The lesson
of `forge_bevy` is at the crate level, not in any individual entry.

### 7.1 — `forge_bevy/src/lib.rs`

**Verdict:** rewrite.
**Lines:** 18,991 prod.
**What it does:** *Everything*. The crate's plugin orchestration,
48 Resource definitions, 160 functions, scenario loading, plan
loading, runtime world setup, demo execution, dev diagnostics, plus
inline tests scattered through.

**Why rewrite:** 18,991 lines is the failure mode this entire project
exists to avoid. Splitting a file this large into modules requires
reading and understanding every line — at which point rewriting from
scratch against the philosophy is competitive in cost and yields
better code. The replacement `anvil_bevy/src/lib.rs` is a thin plugin
orchestrator (estimated 200–500 lines) that wires together the
ported small modules below.

> **Lesson learned (yours):** This is the file that taught me what
> not to do. Reading the entry list — 48 Resource definitions, 160
> functions, all in one file — I see clearly what happens when no
> one is enforcing structure. Each individual addition was probably
> defensible at the time ("just one more system"); the cumulative
> effect is unmaintainable. The Phase 1 file-size CI gate (Commandment
> #4) is precisely the antibody. Reading this in six months, I should
> remember: 500 lines is not arbitrary. It's the line at which
> "individually defensible additions" stop adding up to a whole.

### 7.2 — `forge_bevy/src/atmosphere_math.rs`

**Verdict:** port-as-foundation.
**Lines:** ~250 prod (estimated; not in the size table I extracted).
**What it does:** Defines `DAY_NIGHT_KEYFRAMES` — a list of
hand-tuned atmosphere parameters at specific phases of the day
(midnight, pre-dawn, dawn, morning, noon, etc.). Each keyframe has
sun colour, illuminance, fog colour, sky colour. Plus interpolation
helpers.

**Why port-as-foundation:** The keyframe data is calibration that
took someone hours to tune. Lifting it directly is a gift.

### 7.3 — `forge_bevy/src/audio.rs`

**Verdict:** port-as-foundation.
**Lines:** 376 prod.
**What it does:** Audio system: ambient loops, weather-driven sound
mixing, footstep sounds, wildlife sounds. Bevy systems and resources.

**Why port-as-foundation:** Self-contained, well-bounded. Port.

### 7.4 — `forge_bevy/src/camera.rs`

**Verdict:** port-as-foundation.
**Lines:** 686 prod.
**What it does:** First-person camera. Mouse look, movement input
mapping, post-effects setup (Bloom, DoF, motion blur, SSAO, SMAA),
exposure, tonemapping, fog parameters.

**Why port-as-foundation:** Substantial work to recreate; not enough
problem to rewrite. Refactor for file-size budget — splits into
`camera/controller.rs`, `camera/post_fx.rs`, `camera/setup.rs`.

### 7.5 — `forge_bevy/src/cloud_layer_material.rs`

**Verdict:** port-as-foundation.
**Lines:** ~150 prod.
**What it does:** Custom Bevy material for a cloud layer. Shader
parameters, uniforms, asset loading.

**Why port-as-foundation:** Custom shaders are expensive to write.
Port.

### 7.6 — `forge_bevy/src/decorations/mod.rs` and `decorations/systems.rs`

**Verdict:** port-as-foundation.
**Lines:** ~600 prod combined.
**What it does:** Spawns decorative entities (grass, ferns, small
rocks) on terrain based on `MaterializedRegion::decoration_profile`.
Bevy systems for spawn and de-spawn.

**Why port-as-foundation:** Surface decoration is exactly what the
GDD's atmosphere needs. Port.

### 7.7 — `forge_bevy/src/disaster_particles.rs`

**Verdict:** port-as-foundation.
**Lines:** 749 prod.
**What it does:** Fire flame billboards, smoke plumes, ember sparks,
volcanic ash particles, drought terrain tint. Distance-based
activation thresholds. Particle caps (32 flames, 200 smoke, 100
embers).

**Why port-as-foundation:** This is the visible expression of the
catastrophe system's *aftermath*. Necessary for Pillar I's "world
remembers" subprinciple. Port.

### 7.8 — `forge_bevy/src/external_asset_inspector.rs` and `bin/external_asset_inspector.rs`

**Verdict:** abandon.
**Lines:** ~500 prod combined.
**What it does:** A standalone debug binary that loads Forge's
asset catalogue and lets the user inspect entries.

**Why abandon:** Internal tooling that grew organically. Anvil has
its own catalogue and its own tooling needs; rebuild on demand.

### 7.9 — `forge_bevy/src/fauna.rs` and `forge_bevy/src/fauna_ground.rs`

**Verdict:** port-as-placeholder.
**Lines:** 550 + 944 = 1,494 prod combined.
**What it does:** Wildlife spawning and movement. Birds, ground
animals, with semi-deterministic flocking and grazing behaviours.

**Why port-as-placeholder:** Wildlife in Forgeborn is a GDD-deferred
question. The mechanics here (deterministic flocking, fauna with
positions over time) are useful patterns; whether Forgeborn ships
with this exact level of fauna detail is yet to be decided.

### 7.10 — `forge_bevy/src/footstep_dust.rs`

**Verdict:** port-as-foundation.
**Lines:** ~200 prod.
**What it does:** Small dust puffs at the player's feet, modulated
by terrain type and weather (no dust in rain).

**Why port-as-foundation:** Tiny detail, big atmospheric payoff. Port.

### 7.11 — `forge_bevy/src/heat_shimmer_material.rs`

**Verdict:** port-as-foundation.
**Lines:** ~150 prod.
**What it does:** Custom shader for heat-shimmer effect over fire.

**Why port-as-foundation:** Custom shader. Port.

### 7.12 — `forge_bevy/src/hud.rs`

**Verdict:** port-as-placeholder.
**Lines:** 602 prod.
**What it does:** HUD overlay with quest objectives, region name,
current diagnosis, etc.

**Why port-as-placeholder:** The Forgeborn GDD's Principle 7 ("joy is
an event, not a texture") and its general austere tone strongly
suggest *less* HUD, not more. The Forge HUD is too much for
Forgeborn. The placeholder holds the data layer (what info exists
to display); the presentation will be redesigned almost entirely.

### 7.13 — `forge_bevy/src/plan_queries.rs`

**Verdict:** port-as-foundation.
**Lines:** ~200 prod.
**What it does:** Query helpers over a loaded `AssemblyPlan` —
"give me all entities of region X with archetype Y".

**Why port-as-foundation:** Useful utilities. Port.

### 7.14 — `forge_bevy/src/post_process.rs`

**Verdict:** port-as-foundation.
**Lines:** ~200 prod.
**What it does:** Post-processing pipeline configuration.

**Why port-as-foundation:** Visual tuning. Port.

### 7.15 — `forge_bevy/src/preset_params.rs`

**Verdict:** port-as-foundation.
**Lines:** ~200 prod.
**What it does:** Bundle of named visual presets ("morning",
"overcast", "stormy"). Parameter loadouts for camera, weather,
lighting.

**Why port-as-foundation:** Useful for visual development and
showcase. Port.

### 7.16 — `forge_bevy/src/rain_overlay.rs`

**Verdict:** port-as-foundation.
**Lines:** ~250 prod.
**What it does:** Screen-space rain droplet overlay for first-person
immersion.

**Why port-as-foundation:** Sensory detail that supports Pillar I.
Port.

### 7.17 — `forge_bevy/src/region_culling.rs`

**Verdict:** port-as-foundation.
**Lines:** ~250 prod.
**What it does:** `RegionCullable` component + `region_culling_system`
that hides entities whose region is not in the active set. Plus
terrain-chunk distance culling.

**Why port-as-foundation:** This is **exactly** the mechanism
`anvil_streaming` needs at the rendering layer. Port to
`anvil_bevy::region_culling`. Critical piece.

### 7.18 — `forge_bevy/src/region_markers.rs`

**Verdict:** port-as-foundation.
**Lines:** 652 prod.
**What it does:** Marker entities at region boundaries, transition
visuals, name display when entering a region.

**Why port-as-foundation:** Useful UX layer. Port with file split.

### 7.19 — `forge_bevy/src/review_mode.rs` and `review_mode/tests.rs`

**Verdict:** abandon.
**Lines:** 814 prod (review_mode.rs).
**What it does:** Internal review/debugging mode where the team can
fly through scenes, capture screenshots, log atmosphere parameters.

**Why abandon:** Internal tooling. Useful pattern (a debug-fly mode
is easy to add later); the specific implementation is not worth
porting.

### 7.20 — `forge_bevy/src/sky_atmosphere_material.rs`

**Verdict:** port-as-foundation.
**Lines:** ~200 prod.
**What it does:** Custom shader for sky dome with horizon and zenith
gradients, sun position, scattering approximations.

**Why port-as-foundation:** Custom shader. Port.

### 7.21 — `forge_bevy/src/spawn_visuals.rs`

**Verdict:** port-as-foundation.
**Lines:** 514 prod.
**What it does:** Spawn-time visual effects (glow at the player's
spawn point, fade-in for newly streamed entities).

**Why port-as-foundation:** Polish layer. Port.

### 7.22 — `forge_bevy/src/surface_decorations.rs`

**Verdict:** port-as-foundation, with hard refactor.
**Lines:** 2,488 prod.
**What it does:** Detailed surface decoration: distributed grass
clumps, rock scatters, mushroom clusters, ground ferns, sticks. With
biome-aware density rules and weather/season variants.

**Why port-as-foundation with hard refactor:** Real, tuned content.
The file is too big — splits into `surface_decorations/{distribution,
biome_rules, density, variants, spawn}.rs` per Commandment #4.

### 7.23 — `forge_bevy/src/terrain_material.rs`

**Verdict:** port-as-foundation.
**Lines:** 354 prod.
**What it does:** Custom terrain shader with 4-channel splat blending
(grass/rock/dirt/sand) modulated by wetness and weather.

**Why port-as-foundation:** Custom shader, working integration with
the splat data from `forge_materialize::TerrainData`. Port.

### 7.24 — `forge_bevy/src/terrain_mesh.rs`

**Verdict:** port-as-foundation.
**Lines:** 576 prod.
**What it does:** Generates the runtime terrain mesh from
`TerrainData`. Chunked, with LOD.

**Why port-as-foundation:** Direct port. Critical performance code.

### 7.25 — `forge_bevy/src/water_material.rs`

**Verdict:** port-as-foundation.
**Lines:** ~250 prod.
**What it does:** Water shader with ripples, foam, depth fog.

**Why port-as-foundation:** Custom shader. Port.

### 7.26 — `forge_bevy/src/weather/effects.rs`, `weather/state.rs`, `weather/systems.rs`

**Verdict:** port-as-foundation.
**Lines:** ~700 combined.
**What it does:** Visual weather projection: rain particles, lightning
flashes, cloud movement, wet-terrain shader parameter, cloud shadow
modulation. Reads from `forge_sim::weather::WeatherSimulation` and
projects it to visual state.

**Why port-as-foundation:** The presentation half of the weather
system. Port together with `forge_sim/weather.rs`.

### 7.27 — `forge_bevy/src/weather_runtime.rs`

**Verdict:** port-as-foundation, with hard refactor.
**Lines:** 2,688 prod.
**What it does:** Weather rendering runtime — cloud ensemble
simulation, wind state, lightning timing, rain density
calculations, fog interpolation.

**Why port-as-foundation with hard refactor:** Same as
`surface_decorations.rs`: real working code, but too big for one
file. Splits required.

### 7.28 — `forge_bevy/src/world/mod.rs`, `world/setup.rs`, `world/streaming.rs`

**Verdict:** port-as-foundation.
**Lines:** ~800 combined (estimated).
**What it does:** Loaded-plan setup, region streaming integration,
spawn coordination.

**Why port-as-foundation:** This is the rendering side of
`anvil_streaming`. Port together.

### 7.29 — `forge_bevy/src/tests/disaster_atmosphere_tests.rs`, `lib_tests.rs`, `water_material_tests.rs`

**Verdict:** abandon (as code), reference.
**What they do:** Bevy integration tests — visual regression, system
order, material rendering checks.

**Why abandon:** Bevy 0.18-tied; will not survive a Bevy version
bump unchanged. Useful as patterns when writing new tests.

### Summary, `forge_bevy`

- **Files: 32.**
- **Prod lines: 31,281.** Of which 18,991 are in `lib.rs`.
- **Verdict breakdown:**
  - ~12,000 port-as-foundation (the small, focused modules).
  - ~2,000 port-as-placeholder (HUD, fauna).
  - ~18,991 rewrite (`lib.rs`).
  - ~1,500 abandon (review tooling, asset inspector, integration tests).
- **Work to do:** ~25 work-days for the port-as-foundation modules
  spread across Phase 2 sprints; the `lib.rs` rewrite is a
  ~10-day clean implementation against the philosophy.

> **Lesson learned (yours):** `forge_bevy` is the crate where the
> harvest pays off most surprisingly. Reading just the file sizes,
> I would have written it off — 31k lines, the failed monolith.
> Reading file by file, I find that the failure is concentrated in
> exactly one file (`lib.rs`) and the rest of the crate is mostly
> well-structured small modules. The lesson is to never judge a
> crate by its total size. The structure inside matters more than
> the totals on the outside. Anvil's CI gate enforces this *per
> file* for exactly this reason: the average file size lies; the
> max file size tells the truth.

---

## Conclusion — Coverage and final accounting

### Coverage statistics

- **Forge total `.rs` files (excluding duplicates and tests):** 78
- **Files mentioned in this journal (Parts 1+2):** 78 (100%)
- **Files left silent: 0**

The script `scripts/audit_coverage.sh` (to be added in Phase 1
sprint 2) verifies this by listing every `.rs` file in Forge and
asserting each appears at least once in this journal as a section
heading or in a verdict table.

### Verdict totals (production lines)

| Verdict | Lines | % of Forge |
|---|---|---|
| Migrated (already in Anvil) | 964 | 2.0% |
| Port-as-foundation | ~14,000 | 29.3% |
| Port-as-placeholder | ~3,500 | 7.3% |
| Rewrite (`forge_bevy/lib.rs` + a few large files) | ~21,000 | 44.0% |
| Abandon (with explicit reason) | ~8,300 | 17.4% |
| Reference-only (tests, examples) | ~0* | 0.0%* |

*Tests are accounted for under "abandon (as code), reference (as
patterns)" — they appear in totals as abandon, but they're not
deleted from the snapshot because the patterns are useful even when
the code isn't.

### Maximalist port total

**~17,500 lines** of Forge enter Anvil with refactor (foundation +
placeholder), against the original audit's estimate of ~7,500. The
larger total is the cost of taking the harvest seriously rather than
dismissing the parts that look unfamiliar.

### Net effort delta (vs. v3 strategic analysis)

Phase 2 effort: **95.5 work-days** (vs. v3's 120). Net savings
vs. starting from scratch: ~25 days.

Phase 3 effort: **103.5 work-days** (vs. v3's 150). Net savings:
~45 days. The larger phase-3 saving comes from `forge_sim/live/`
porting as placeholders — the utility-AI scoring substrate is
substantial code that Forgeborn would otherwise rebuild.

Combined: **~70 work-days saved**, equivalent to roughly **3 months
of solo elapsed time**.

The work-day savings are **conditional on porting discipline**.
Every ported file must:
- Pass the Phase-1 gates on the day it lands (file size, validate
  signature, panic safety, error code registration).
- Carry an explicit `// Source: forge_<crate>/<file>.rs as of
  <date>` header.
- Have a corresponding entry in `DECISIONS.md` recording what was
  kept and what was changed during port.
- For port-as-placeholder files: have a corresponding entry in
  `PLACEHOLDER_DEBT.md` with a review date.

Without that discipline, the harvest produces Forge 2 instead of
Anvil. The savings vanish in the first six months and what's left
is a workspace too large to fix.

### Closing note from the auditor

You said this document is for learning, and "documenting your
journey." If that's true, then the most important sections are not
the verdict tables. They are the marked **lesson learned** blocks.
Read those first when you re-open this. Edit them. Disagree with
them. Replace them with what you actually learned.

The technical content is checkable; the lessons are yours.
