---
id: ANVIL_CONTRIBUTING
title: Contributing to Anvil/Forgeborn
status: active
audience: [contributor, developer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_DEVELOPER_GUIDE, AGENTS, ANVIL_DOC_SYSTEM]
owner: project_lead
version: 1.0
gate_scripts: [tests/phase3_gate.sh, scripts/check_docs.sh]
code_paths: []
---
