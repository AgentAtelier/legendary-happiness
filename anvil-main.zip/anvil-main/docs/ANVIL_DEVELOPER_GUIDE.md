---
id: ANVIL_DEVELOPER_GUIDE
title: Developer Guide
status: active
audience: [developer, agent, contributor]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_CONTRIBUTING, ANVIL_ROADMAP]
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: []
---

# Developer Guide

Anvil is the simulation and asset-pipeline engine for *Forgeborn* — a single-player game where the world is the principal threat and the player is subject to the same rules as every NPC. This guide covers what a developer needs to be productive in the workspace from day one.

For the project constitution read `ANVIL_PHILOSOPHY.md`. For design decisions read `DECISIONS.md`. For the error-code registry read `ERROR_CODES.md`. For the asset pipeline read `ASSET_PIPELINE.md`. This guide links to those files rather than repeating them.

---

## Build & Test

All day-to-day commands are in `justfile`. Run `just` with no args to list them.

```bash
just check        # cargo check --workspace
just lint         # cargo clippy --workspace --all-targets -- -D warnings
just fmt          # cargo fmt --all
just test         # cargo test --workspace
just gate         # check + lint + firewall + size (fast local gate)
just phase1       # gate + tests + Cargo.lock/rust-toolchain.toml presence (full CI gate)
just run-demo     # launch the interactive Bevy viewport
just bench        # criterion benchmarks (workspace)
just fuzz         # run FBX fuzzer (24 h recommended)
```

### Running a single test

```bash
cargo test -p <crate> --test <test_file> -- <filter> --nocapture
# e.g.
cargo test -p anvil_sim --test determinism -- test_region_compile --nocapture
```

### Determinism canary (run after any sim/physics change)

```bash
cargo test -p anvil_sim --test physics_determinism -- --nocapture
```

### Nightly 100 k-tick fuzz (slow; CI runs this daily at 03:00 UTC)

```bash
cargo test --release -p anvil_sim --test determinism_fuzz \
    -- test_fuzz_determinism_100k_ticks --nocapture
```

---

## Architecture

### The Dependency Firewall

The single most important rule in this codebase. Three layers; authority never flows upward:

```
PRESENTATION   anvil_bevy · anvil_streaming · anvil_demo · anvil_cli
                    │  may use: Bevy, tokio, async, audio, egui
DETERMINISTIC  anvil_runtime · anvil_world · anvil_sim · anvil_assembly
               anvil_assets · anvil_assets_pipeline · anvil_core
                    │  forbidden: Bevy, tokio, any async runtime, network,
                    │             LLM/openai, reqwest, hyper
SEMANTICS      LLMs and human authors (build-time only; never a runtime dep)
```

`scripts/check_firewall.sh` enforces this transitively via `cargo tree` on every CI push. If your change pulls a banned crate into a deterministic crate the CI fails. See `ANVIL_PHILOSOPHY.md §1` for the full script.

### Crate map

| Crate | Layer | Responsibility |
|-------|-------|---------------|
| `anvil_core` | Det | Foundation types: `ArchetypeTag`, `RegionSpec`, `ConnectionSpec`, `DamageType`, error infrastructure. No deps beyond serde/thiserror. |
| `anvil_world` | Det | Compiled world state: regions, entities, connections. Serialised via blake3 + bincode. |
| `anvil_sim` | Det | Pure deterministic simulation — time, faction, needs, settlement, catastrophe, physics (Rapier3D). All randomness seeded. No Bevy, no async. |
| `anvil_runtime` | Det | Tick-driven state machine over `WorldAuthored`. Savestate serialisation with version migration. |
| `anvil_assembly` | Det | Compiles authored specs into `WorldAuthored`; noise generation, authority validation. |
| `anvil_assets` | Det | Asset catalogue, material resolution, FBX→GLB builder types. |
| `anvil_assets_pipeline` | Det | Seven-stage async-ish pipeline: FBX parse → pilot → staging → eligibility → normalisation → sidecar → payload. |
| `anvil_streaming` | Pres | Async (tokio) streaming of world data from disk/network. |
| `anvil_bevy` | Pres | Bevy integration: converts `anvil_assets` types to Bevy components and materials. |
| `anvil_demo` | Pres | Full Bevy viewport with egui panels, fly camera, `bevy_kira_audio`, tweening. |
| `anvil_cli` | Pres | Clap CLI for batch asset processing. |

Data flow for a simulation tick:

```
authored JSON / LLM output
        │ compile
        ▼
WorldAuthored  (anvil_assembly)
        │ materialise
        ▼
WorldRuntime   (anvil_runtime)
        │ tick
        ▼
anvil_sim systems (deterministic)
        │ read-only
        ▼
anvil_bevy / anvil_streaming / anvil_demo (presentation)
```

---

## Core Patterns

### Newtype identifiers

IDs are newtypes, never bare integers or strings:

```rust
pub struct RegionId(u64);
pub struct ArchetypeTag(String); // validated on construction
pub struct ConnectionId(u64);
```

`ArchetypeTag` validates its inner string on `new()`. Always construct IDs through their constructors; do not reach into the inner field.

### Multi-error validation

Every type that represents authored data implements `SemanticArtifact` and returns all errors in a single call — never `Result<(), E>`:

```rust
impl SemanticArtifact for RegionSpec {
    fn validate(&self) -> ValidationErrors {
        let mut errors = error_buffer();
        if self.name.is_empty() {
            push_validation_error!(
                errors, Structural, "E001", "RegionSpec", "name",
                &self.name, "Region name must not be empty", ""
            );
        }
        // ... collect every problem before returning
        errors
    }
}
```

Return type must be `ValidationErrors`, period. `scripts/check_validate_signature.sh` rejects any `fn validate` that returns something else.

**Why:** LLM-generated authored content with five errors takes five round trips to fix if validation stops at the first error. One pass surfaces everything.

### Panic safety

Production code runs with:

```rust
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]
```

Every justified panic site must have a `// SAFETY:` comment immediately before it that proves the panic cannot fire, paired with a local `#[allow]`:

```rust
#[allow(clippy::expect_used)]
// SAFETY: parsed_len was checked >= 4 on line 12; the slice cannot be shorter.
let n = u32::from_le_bytes(bytes[..4].try_into().expect("4-byte slice"));
```

Builders return `Result<T, BuildError>` from `try_build()`, not a panicking `build()`.

### Trait-based extensibility

Strategies are swappable traits, not hard-coded implementations. Examples:

| Trait | Crate | Purpose |
|-------|-------|---------|
| `FallbackProvider` | `anvil_assets` | Default textures and PBR parameters |
| `StyleProvider` | `anvil_assets` | LLM prompt style suffixes |
| `EligibilityClassifier` | `anvil_assets_pipeline` | Vendor-specific asset filtering |
| `BatchCompositionPolicy` | `anvil_assets_pipeline` | Batch construction strategy |
| `PipelineManifest` | `anvil_assets_pipeline` | Unifies seven external pipeline stages |
| `SimSystem` | `anvil_sim` | Simulation subsystems (name, priority, tick, validate) |

### Builder pattern

```rust
pub struct SpecBuilder { ... }
impl SpecBuilder {
    pub fn with_<field>(mut self, val: T) -> Self { ... }
    pub fn try_build(self) -> Result<Spec, BuildError> { ... }
}
```

`try_build()` validates the built object before returning it; callers must handle the `Result`.

### Enums

- All public enums that may grow in future versions carry `#[non_exhaustive]`.
- All enums serialised to JSON use `#[serde(rename_all = "snake_case")]`.
- Never add a `*_label()` function; implement `Display` instead.

---

## Error Codes

Error codes use an `Exxx`-style scheme. **Register the code in `ERROR_CODES.md` before using it in code.** `scripts/check_error_codes.sh` runs on CI and fails if a code appears in source but is not in the registry.

Every error carries: code, artifact type, field, invalid value, message, optional hint, and source location. Use the `push_validation_error!` macro from `anvil_core`.

Code ranges:

| Range | Crate |
|-------|-------|
| E000–E039 | `anvil_core` |
| E040–E099 | `anvil_assets` |
| E100–E139 | `anvil_world` |
| E140–E189 | `anvil_sim` |

---

## Adding a New Feature

### 1. Choose the right crate layer

Ask: does this code produce deterministic, reproducible output independent of I/O? → deterministic layer. Does it render, stream, or depend on Bevy/tokio? → presentation layer. Check with `scripts/check_firewall.sh` after.

### 2. Add domain types to `anvil_core` if shared

If the type is referenced by more than one crate, it belongs in `anvil_core`. Add a re-export in `anvil_core/src/lib.rs`.

### 3. Implement `SemanticArtifact` on authored data

Every struct that a human or LLM authors must implement `SemanticArtifact::validate() -> ValidationErrors`. Register any new error codes in `ERROR_CODES.md` first.

### 4. Write tests at every level

- Unit test in the same file (`#[cfg(test)]` at bottom).
- Integration test in `crates/<crate>/tests/` for crate-level behaviour.
- If the function has `validate` in its name or is a deterministic compiler: add a property test.
- If the function parses external bytes (FBX, JSON, binary savestate): add a fuzz target.

### 5. Gate before pushing

```bash
just gate    # fast check: check + lint + firewall + size
just test    # full test suite
```

### Adding a `SimSystem`

Implement the `SimSystem` trait in `crates/anvil_sim/src/system/`:

```rust
pub struct MySystem;
impl SimSystem for MySystem {
    fn name(&self) -> &'static str { "my_system" }
    fn priority(&self) -> i32 { 100 }
    fn tick(&mut self, ctx: &mut SimContext<'_>) -> Result<(), SimError> { ... }
    fn validate(&self, world: &WorldRuntime) -> ValidationErrors { ... }
}
```

Register it in the system registry in `crates/anvil_sim/src/system/mod.rs`. All randomness must go through `ctx.rng` (`DeterministicRng`); never use `rand` or `thread_rng`.

### Adding a new asset type to the pipeline

Follow the pattern in `ASSET_PIPELINE.md`. Assets must be CC0-licensed, committed to the repo (or Git LFS if > 10 MB), and catalogued in `ASSET_REGISTRY.md`.

---

## Documentation Standards

### What is currently enforced

| Rule | Mechanism |
|------|-----------|
| Public items have `///` docs | `#![deny(missing_docs)]` in `anvil_sim` only; manual review for other crates |
| Error codes registered before use | `scripts/check_error_codes.sh` (CI) |
| Validate signature shape | `scripts/check_validate_signature.sh` (CI) |
| File ≤ 500 production lines | `scripts/check_size.sh` (CI, hard limit) |
| Placeholder ports have review dates | `scripts/check_placeholder_debt.sh` (CI) |

### Standards to follow

- Every crate root has a `//!` module-level doc comment explaining what the crate does, what its layer is, and what its main types are.
- Every public struct, enum, trait, and function has a `///` doc comment. Builder setter methods must be documented.
- `#[must_use]` on all builder `try_build()` methods and query constructors.
- `#[must_use]` on functions whose return value is the point of the call (query results, `try_build()` results).
- `#[non_exhaustive]` on public enums that may add variants.
- No `*_label()` functions; use `impl Display`.
- AI-produced commits carry the prefix `[ai]` in the commit message.

---

## CI

Three GitHub Actions workflows:

| Workflow | Trigger | What it runs |
|----------|---------|--------------|
| `phase1-gate.yml` | Push/PR to main | `just phase1` (ubuntu-latest) |
| `ci.yml` | Push/PR to main | `just phase1` + physics canary on Linux x86/arm, macOS, Windows |
| `nightly-fuzz.yml` | Daily 03:00 UTC | 100 k-tick determinism fuzz + FBX parser fuzz |

The phase1 gate is the blocking gate; the cross-platform CI uploads platform result artefacts and requires at least Linux x86 and aarch64 to pass.

Coverage gating via `cargo-llvm-cov` is tracked but currently disabled on free GitHub runners (memory limit). See `INFRASTRUCTURE_EXCELLENCE.md`.

---

## Placeholder Ports

Files ported from the predecessor codebase (Forge) as provisional implementations carry a `// PLACEHOLDER FROM forge_<crate>` header and an entry in `PLACEHOLDER_DEBT.md` with a review date and a trigger condition. An overdue entry is a sprint-start blocker (`scripts/check_placeholder_debt.sh`). Placeholder files are not decisions deferred indefinitely; they are decisions waiting on game-design context.

---

## Toolchain

Rust **1.94.1**, pinned in `rust-toolchain.toml`. Components: rustfmt, clippy. Workspace uses `resolver = "2"`, `edition = "2024"`.