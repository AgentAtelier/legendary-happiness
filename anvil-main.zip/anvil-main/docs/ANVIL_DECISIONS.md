---
id: ANVIL_DECISIONS
title: Anvil Design Decisions
status: active
audience: [developer, agent]
last_reviewed: 2026-05-11
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_ROADMAP, ANVIL_DEMO, ANVIL_GAME_DESIGN]
owner: project_lead
version: 1.1
gate_scripts: []
code_paths: []
---

## Summary

Single source of truth for every architectural decision, design rule, and notable refactor in the Anvil workspace. Read top-down for chronology; jump by anchor for crate-specific rules.

When two decisions conflict, the more recent one wins. Note the date in the heading and reference the prior entry.

---


> **The authoritative source for project rules is [ANVIL_PHILOSOPHY.md](ANVIL_PHILOSOPHY.md).**
> This file records specific decisions and their rationale.

# Anvil Design Decisions & Tracking

Last updated: 2026-05-01 — after Sprint 18b (Perceptibility + Teaching).

This file is the **single source of truth** for every architectural decision,
design rule, and error code in the workspace.  It is written so that a new
developer can understand the project without reading any source code.

---

## Project overview

Anvil is a Rust workspace that builds a deterministic, content‑authored game
pipeline.  Every crate must obey the **dependency firewall**: no Bevy, no LLM
libraries, no rendering code in the foundational crates.

| Crate | Purpose | Depends on |
|-------|---------|------------|
| `anvil_core` | Domain types, validation infrastructure, world state enums | `serde`, `thiserror` |
| `anvil_assets` | Asset catalogue, material resolution, prompt enrichment, external pipeline | `anvil_core`, `serde`, `chrono`, `flate2` |
| `anvil_world` | Deterministic world compiler | `anvil_core`, `anvil_assets`, `serde`, `serde_json`, `blake3`, `hex` |
| `anvil_runtime` | Deterministic live simulation state | `anvil_core`, `anvil_assets`, `anvil_world`, `serde`, `serde_json`, `thiserror`, `glam` |
| `anvil_streaming` | On-demand region loading and asset streaming | `anvil_core`, `anvil_world`, `anvil_runtime`, `tokio`, `serde`, `thiserror` |
| `anvil_assembly` | Deterministic world plan compilation and materialization | `anvil_core`, `anvil_world`, `serde`, `serde_json`, `thiserror`, `blake3`, `chrono`, `noise` |
| `anvil_sim` | Deterministic simulation systems (time, faction, AI, weather, damage, vegetation, settlements, joy) | `anvil_core`, `anvil_world`, `serde`, `thiserror`, `glam` |

The workspace was created by porting and heavily refactoring the old `forge_*`
crates.  Every file has been reviewed, hardened, and modernised through eight
sequential implementation prompts and five specialised audits (correctness,
architecture, game‑dev ergonomics, performance, API / documentation).

---

## Shared design rules

1. **Dependency firewall** — deterministic crates must never depend on Bevy,
   LLM libraries, or rendering code.
2. **Newtype pattern** — identifiers (`RegionId`, `ArchetypeTag`, `ConnectionId`)
   are distinct types, never bare integers or strings.
3. **Snake‑case enums** — all enums use `#[serde(rename_all = "snake_case")]`.
4. **Display on every enum** — no free‑standing `*_label()` functions.  Every
   domain enum implements `Display`.  Old label functions are `#[deprecated]`.
5. **Multi‑error validation** — `validate()` returns `Vec<Error>`, never
   `Result<(), Error>`.  Fix everything in one pass.
6. **Error richness** — every validation failure carries an error code, artifact
   type, field name, invalid value, human message, optional hint, and source
   location.
7. **`#[non_exhaustive]`** on all public enums that are expected to grow.
8. **Builders** for every complex struct with required fields.  Builders follow
   `with_<field>()` for scalars and `add_<item>()` for collections.
9. **Trait‑based extensibility** — swappable strategies (`FallbackProvider`,
   `StyleProvider`, `EligibilityClassifier`, `BatchCompositionPolicy`,
   `PipelineManifest`) follow a uniform trait + default‑impl pattern.
10. **Tracking document** — this file.  Per‑crate `DECISIONS.md` files are
    **not** used; everything lives here.

---

## anvil_core

### Status

All modules reviewed and hardened.  `world/` still needs its own design
pass (see open items).

| Module | Status |
|--------|--------|
| `artifact.rs` | `Versioned` + `SemanticArtifact` traits |
| `error.rs` | `AnvilCoreError`, `ErrorCode`, `ValidationLevel`, `error_buffer` |
| `connections.rs` | `ConnectionId`, `ConnectionKind`, `Directionality`, `ConnectionSpec` |
| `ids.rs` | `AuthoredEntityId`, `ArchetypeTag` |
| `path.rs` | `AssetPath`, `repo_root_from_manifest`, `repo_path!` macro |
| `semantic.rs` | `RegionSpec`, `TerrainType`, `LandmarkKind` |
| `asset_request.rs` | `AssetRequestSpec` |
| `world/` | `RegionId`, `EntityKind`, `DamageType`, `VegetationState`, settlement types, `HistoryEvent` |

### Core‑only design decisions

- **Error codes are `&'static str`** — no heap allocation per error.
- **`ArchetypeTag::missing()` sentinel** — valid tag `"missing"` used for
  error‑identification purposes.
- **`DamageType::None` removed** — `Option<DamageType>` is the idiomatic
  replacement.
- **Label functions deprecated** — `DamageType`, `VegetationState`,
  `SettlementOccupancyState`, and `SettlementReconstructionState` all have
  `Display` impls; old `label()` methods are `#[deprecated]`.
- **`HistoryEvent::validate` now returns `ValidationErrors`** — the last
  `String`‑based validation is gone.
- **`push_validation_error!` macro** — decided but not yet fully rolled out
  (see open items).
- **`AssetRequestSpecBuilder`** – fluent builder with `with_<field>()` methods,
  construction‑time validation on `build()`.  Pre‑validated specs avoid
  redundant checks downstream.
- **Byte limits on prompt fields** – `prompt_core` ≤ 600 bytes,
  `style_context` ≤ 200 bytes.  Byte counting gives stricter, deterministic
  resource control than character counting.
- **Control‑character injection guard** – `validate()` rejects C0 control
  characters (except `\n`, `\t`) in prompt text fields (E018/E019).
- **`source_location` field on `AnvilCoreError`** – optional field for
  recording the data origin (e.g. LLM‑generated provenance).  The validator
  own `file!()/line!()` is unchanged.

### Open items

- [x] `world.rs` — refactored into `world/` module directory
- [x] Roll out `push_validation_error!` macro to every `validate()` method
- [x] `repo_path!` macro — compile-time check added via build.rs in anvil_core
- [x] `ArchetypeTag::biome_prefix()` and `kind_suffix()` — removed, unused
- [x] Add Display + macro to new artifact types
- [x] Remove dual-format palette deserialiser — now requires JSON array format

---

## anvil_assets

### Status

**Complete.**  Every module has been reviewed, hardened, and modernised.

| Module | Status |
|--------|--------|
| `types.rs` | Display, MaterialOverride, From/FromStr, AssetValidationError, #[non_exhaustive] |
| `catalogue.rs` | Unified V1/V2 parsing, CatalogueQuery, CatalogueBuilder, MaterialCoverageReport |
| `defaults.rs` | FALLBACK_TABLE, FallbackProvider trait, DefaultFallbackProvider |
| `enrichment.rs` | StyleProvider, PromptTemplate, AssetRequestEnricher |
| `external_pilot.rs` | Display/FromStr, Provenance, registration_map() |
| `external_eligibility.rs` | EligibilityClassifier, EligibilityStatus enum, multi‑error |
| `external_staging.rs` | StageAction enum, StagingRecordBuilder |
| `external_normalization.rs` | BatchCompositionPolicy, NormalizedGlb, multi‑error |
| `external_fbx.rs` | Safety hardened (OOM/zip‑bomb/stack‑overflow/overflow/version‑gate) |
| `external_material_sidecar.rs` | MaterialSlotBindingBuilder, centralized required_channels() |
| `external_texture_payload.rs` | TexturePayloadRecordBuilder, public texture_output_path() |
| `pipeline.rs` | PipelineManifest trait, ManifestError<S> shared error type |
| `lib.rs` | prelude module, feature‑gated build pipeline, re‑exports |

### Deleted modules

- `labels.rs` → replaced by Display impls
- `material.rs` → logic moved to MaterialVariantContext and MaterialVariant
- `manifest.rs` → inlined into catalogue.rs as unified ManifestEntry
- `external_demo_vista_external_replacement.rs` → NM‑specific dead weight;
  integration test moved to `tests/pipeline_integration.rs`

### Design decisions (see crate‑level DECISIONS.md for full rationales)

| Date | Decision |
|------|----------|
| 2026‑04‑28 | Data‑driven fallback table replaces hard‑coded match arms |
| 2026‑04‑28 | FallbackProvider trait for swappable fallback strategy |
| 2026‑04‑28 | StyleProvider trait for swappable style suffix generation |
| 2026‑04‑28 | MaterialOverride struct deduplicates 7 optional material fields |
| 2026‑04‑28 | MaterialVariantContext owns its resolution logic |
| 2026‑04‑28 | Unified V1/V2 manifest parsing via single ManifestEntry |
| 2026‑04‑28 | CatalogueQuery struct bundles query parameters |
| 2026‑04‑28 | CatalogueBuilder encapsulates parallel map construction |
| 2026‑04‑28 | MaterialCoverageReport replaces five separate audit methods |
| 2026‑04‑28 | Multi‑error validation throughout external pipeline |
| 2026‑04‑28 | EligibilityClassifier trait for vendor‑specific rules |
| 2026‑04‑28 | EligibilityStatus enum replaces bool + blockers |
| 2026‑04‑28 | StageAction enum makes staging decisions explicit |
| 2026‑04‑28 | BatchCompositionPolicy trait for vendor‑specific batch rules |
| 2026‑04‑28 | NormalizedGlb type unifies build + validate |
| 2026‑04‑28 | Centralized required‑channel logic on ExternalAssetMaterialClass |
| 2026‑04‑28 | Centralized pack identity validation |
| 2026‑04‑28 | FBX parser safety hardened |
| 2026‑04‑28 | Provenance newtype for asset identity |
| 2026‑04‑28 | PromptTemplate struct preserves prompt provenance |
| 2026‑04‑29 | Arc‑based internal storage eliminates per‑query allocations |
| 2026‑04‑29 | PipelineManifest trait unifies 7 external modules |
| 2026‑04‑29 | build‑pipeline feature gate hides build‑time types from runtime |
| 2026‑04‑29 | prelude module for one‑import convenience |

### Established patterns (shared with `anvil_core` where applicable)

1. **Trait‑based extensibility** — `FallbackProvider`, `StyleProvider`,
   `EligibilityClassifier`, `BatchCompositionPolicy`, `PipelineManifest`.
2. **Builders** — `CatalogueBuilder`, `ExternalAssetRegistrationBuilder`,
   `StagingRecordBuilder`, `MaterialSlotBindingBuilder`,
   `TexturePayloadRecordBuilder`.
3. **Multi‑error validation** — `validate()` returns `Vec<Error>`;
   `validate_strict()` for early exit.
4. **Deprecation before deletion** — old functions marked `#[deprecated]`
   for one release cycle.
5. **Type‑state for invariants** — `EligibilityStatus`, `StageAction`.
6. **Centralized constants** — `EXTERNAL_NORMALIZED_OUTPUT_PREFIX` in `lib.rs`.

### Open items

- [x] Add fuzz targets for FBX parser
- [x] `FamilyConfig` trait to decouple ExternalAssetFamily from hard‑coded pipeline logic
- [D] Add property‑based tests for ArchetypeTag validation — deferred until after world integration
- [x] Merge catalogue maps + `Borrow<str>` for reduced hash lookups
- [D] Extract external pipeline as separate crate (when second vendor arrives)
- [D] Localisation infrastructure (`LocalizedLabel` trait)

// ---------------------------------------------------------------------
// FBX parser fuzz target
// ---------------------------------------------------------------------

- **FBX parser fuzz target** — `cargo fuzz run fbx_parse` exercises
  `inspect_fbx_source` and `convert_fbx_to_glb_bytes` with
  arbitrary binary data to ensure no panics, timeouts, or OOM.

---

## anvil_world

### Status

**Complete.**  Monolith split, hardened, and brought into full philosophy compliance.

| Module | Status |
|--------|--------|
| `types.rs` | WorldAuthored, CompileError (multi‑error + error codes), TagResolver (negative caching), ErrorCollector |
| `compiler.rs` | compile_world, compile_world_with_history, multi‑error return, validate_region_landmark_distribution |
| `history.rs` | report_history_digest, report_history_digest_with_save |
| `validation.rs` | WorldAuthored::validate, check_reachability (ID‑safe, directionality‑aware) |
| `hashing.rs` | StableHash trait (blake3), stable_hash, stable_hash_hex, history_events_digest |
| `lib.rs` | Thin crate root: re‑exports, feature gate, `#![deny(warnings)]` |

### Design decisions

| Date | Decision |
|------|----------|
| 2026‑04‑29 | Module split: types, compiler, validation, history, hashing |
| 2026‑04‑29 | Multi‑error validation throughout (validate returns `Vec<CompileError>`) |
| 2026‑04‑29 | TagResolver cache with negative caching for allocation‑free archetype resolution |
| 2026‑04‑29 | StableHash replaces JSON‑based hashing (blake3) |
| 2026‑04‑29 | ErrorCollector for consistent multi‑error accumulation |
| 2026‑04‑29 | AuthoredConnection now carries `directionality` |
| 2026‑04‑29 | `check_reachability` uses explicit `HashMap<RegionId, usize>` mapping (no index assumptions) |
| 2026‑04‑29 | Error codes E100‑E112 assigned in `ERROR_CODES.md` |
| 2026‑04‑29 | `lib.rs` under 100 lines; integration tests moved to `tests/integration.rs` |
| 2026‑04‑29 | Zero warnings enforced via `#![deny(warnings)]` |

### Established patterns

1. **ID‑safe reachability** — BFS uses an explicit ID‑to‑index map, never assumes contiguous indices.
2. **Directionality‑aware graph** — All connections carry `Directionality`; reachability respects one‑way edges.
3. **Structured compile errors** — Every `CompileError` variant has a unique error code (E100‑E112).
4. **Multi‑error compilation** — `compile_world` returns all errors, not just the first.

---

## Post‑review cleanup history

The following decisions were recorded during the initial `anvil_core` review
and the subsequent `anvil_assets` full refactor.  They are kept here as
historical context.

### anvil_core (2026‑04‑27)

- **Label functions replaced with Display** — removed `damage_type_label`,
  `vegetation_state_label`, `settlement_occupancy_state_label`,
  `settlement_reconstruction_state_label`.  Every enum now implements Display.
- **`push_validation_error!` macro** — designed, partial rollout.
- **`HistoryEvent::validate` now returns `ValidationErrors`** — error codes
  E030–E033.
- **`DamageType::None` removed** — `Option<DamageType>` used everywhere.

### anvil_assets (2026‑04‑28 – 2026‑04‑29)

Eight sequential implementation prompts applied all of the design decisions
listed above.  A final consistency sweep on 2026‑04‑29 fixed 13 drift issues
and confirmed both crates compile with zero errors and all tests pass.

### 2026-04-30 — `anvil_runtime` crate created

Sprint 6. Scaffolded `anvil_runtime` as the crate that materialises a
deterministic `WorldAuthored` into a live, tick‑driven runtime state.
Ported `forge_sim/src/lib.rs` (68 prod) and `forge_sim/src/types.rs`
(202 prod) as foundation. Defined `Runtime`, `RuntimeCommand`,
`RuntimeEvent`, `RuntimeError`, and the `RuntimeState` trait. The
types are minimal — the full `SimWorld` port and snapshot/restore
follow in later sprints.

Firewall check confirms no Bevy or LLM dependencies transitively
reach `anvil_runtime`.

### 2026-04-30 — Governance documents placed

Phase 1 closed. Placed `GAME_DESIGN.md` (preamble v2), `PLACEHOLDER_DEBT.md`,
`PHASE_SPRINTS.md` (v2, maximalist port), the Forge Harvest Journal
(Parts 1 and 2), `audit_coverage.sh`, and `CHANGELOG_HARVEST.md` into
the workspace. `AGENTS.md` and `SESSION_PROMPT.md` added for AI
session discipline. The GDD placeholder is replaced with the ratified
preamble.

### 2026-04-30 — Sprint 7: Core simulation primitives ported

Ported `forge_sim/src/{time, weather, region, terrain, step,
invariants, trace, build}.rs` into `anvil_runtime`.  All files carry
source-attribution headers.  Weather includes property tests.
`progression_trace` feature gate added for tracing.

### 2026-04-30 — Sprint 7b: Placeholder bedding-in

Created `scripts/check_placeholder_debt.sh` and wired it into
the sprint-start gate.  Created `tests/sprint_start_gate.sh`.
Amended `ANVIL_PHILOSOPHY.md` Commandment 6 to codify the
placeholder discipline.  `audit_coverage.sh` verified executable.

### 2026-04-30 — Sprint 8: Snapshot, restore, save format

Ported `forge_sim/src/save.rs` (725 prod) into `anvil_runtime::snapshot`
with a 4-way split: format, migration, integrity, serde_helpers.
Anvil save format starts at v6.  Round-trip test and v6 baseline
fixture committed.  Fuzz target for deserialisation added.

### 2026-05-01 — Sprint 9: anvil_streaming skeleton

Created `anvil_streaming` crate.  Defined `WorldPos`, `RegionScheduler`
trait, and `SimplePolicy` default implementation.  Tokio permitted
in this crate (presentation‑adjacent I/O boundary).  Integration test
added for three‑region traversal stub.

### 2026-05-01 — Sprint 10: Asset streaming I/O

Implemented `AssetStreamer` trait with `AssetHandle` newtype and
`FsAssetStreamer` filesystem implementation.  Added LRU eviction
via `last_accessed_tick` tracking.  Integrated streamer with
`SimplePolicy` via `register_region_assets`, `set_asset_streamer`,
and `tick` calling `streamer.load()`.  Criterion benchmark for
1000 asset loads (3.9–4.1 ms) with baseline saved to
`bench/baselines/streaming_phase0/`.

### 2026-05-01 — Sprint 11: Multi‑vendor pipeline refactor

Introduced `Vendor` trait replacing the hardcoded `FamilyConfig`.
`NatureManufactureVendor` implements it.  `TestVendor` added for
tests.  Pipeline modules (`external_normalization`, `eligibility`,
`texture_payload`) now dispatch through `&dyn Vendor`.  Removed
`family.rs`.  This closes the NatureManufacture vendor lock‑in
risk from the strategic analysis.

### 2026-05-01 — Sprint 12a: End-to-end integration — foundation half

Created `anvil_assembly` crate.  Ported `forge_assembly` foundation
(`AssemblyPlan`, `EntityPlan`, `compile_plan`, authority reports).
Ported `forge_materialize` types, terrain generation, and
`layout.rs` (4-way split).  Ported `DemoVistaLayout` as placeholder
PD-001.  Wired `anvil_assembly` into `anvil_demo`.

### 2026-05-01 — Sprint 14: `anvil_sim` skeleton + GDD alignment

Created `anvil_sim` crate with trait scaffolding (`SimSystem`,
`SimContext`, `SimSnapshot`, `SimError`, `DeterministicRng`).  No
gameplay systems implemented yet — those belong to later sprints.
Reserved error codes E140–E159.  `GAME_DESIGN_SECTION_3.md` drafted
(catastrophe-and-joy section) and committed as sibling to
`GAME_DESIGN.md`. The settlement emotional phase cycle from earlier
GDD drafts has been replaced by the emergent-conditional model in
Section 3.

### 2026-05-01 — Sprint 15: Catastrophe system implementation

Phase 3, Sprint 15 — Catastrophe system (5 tasks). Completed:

- **Task 1 — Generalise weather to all catastrophe types:** Created
  `CatastropheSystem` in `anvil_sim` that implements `SimSystem` and generalizes
  the weather simulation to handle all seven `DamageType` events (Flood,
  Earthquake, Wildfire, Blizzard, Drought, Landslide, Blight) as described in
  GAME_DESIGN_SECTION_3.md Section 3.2. Each `CatastropheEvent` carries a
  `consequence` field with the dominant loss type matching the design.
  Weather primitives from `anvil_runtime` (temperature, precipitation, wind) are
  reused as inputs via `WorldRuntime` state; the new system adds logic that
  triggers catastrophes when conditions are met. The existing weather
  simulation in `anvil_runtime` was not modified.

- **Task 2 — Precursor signals:** Implemented `PrecursorSignal` and
  `SignalKind` enum covering environmental, animal, and NPC-knowledge
  categories (Section 3.5.1). Each `CatastropheType` has typical signals
  defined in `catastrophe::signal::typical_signals()`. The
  `CatastropheSystem` emits precursor signals into `pending_signals` during
  the tension phase before a catastrophe triggers. Signal timing and type
  are deterministic (tied to the sim tick and the catastrophe's internal
  countdown via the deterministic RNG).

- **Task 3 — Spatial propagation:** Implemented `PropagationModel` and
  `SpatialPropagation` with deterministic propagation rules per catastrophe type:
  Flood follows terrain height, Wildfire follows wind direction and dry
  vegetation, Earthquake uses radial attenuation, Blizzard is region-wide
  with exposure variation, Drought is region-wide, Landslide is localized
  to slope, Blight spreads via proximity. The propagation produces
  deterministic affected-area results (set of `(position, intensity)` pairs
  in `CatastropheEvent.affected_areas`) given the same world state and
  RNG seed.

- **Task 4 — Determinism property test:** Created
  `crates/anvil_sim/tests/determinism.rs` with tests verifying that same
  RNG seed → same tick → same catastrophe outcome (type, timing, epicentre,
  propagation pattern, signals). Tests include same-seed determinism,
  different-seed variation, weather-condition triggering, and precursor
  signal determinism.

- **Task 5 — Error codes + decision log:** Reserved error codes
  E140–E149 in `ERROR_CODES.md` for `anvil_sim`. Created
  `scripts/check_error_codes.sh` to verify all codes are registered.

**Design decisions:**
- Used xorshift64* algorithm for `DeterministicRng` providing fast,
  reproducible pseudo-random values suitable for simulation determinism.
- Weather conditions influence catastrophe eligibility via per-type
  eligibility scores; final selection uses weighted random choice via
  the deterministic RNG.
- Epicentre position, magnitude, and radius are all generated using the
  deterministic RNG to ensure reproducibility.
- Made `active_events` and `pending_signals` public on `CatastropheSystem`
  to enable testing and future integration with other systems.
- The `WorldRuntime` struct was extended with weather fields
  (`temperature`, `humidity`, `pressure`, `wind_speed`,
  `accumulated_precipitation`) to pass weather state to the catastrophe
  system without violating the dependency firewall.

### 2026-05-01 — Sprint 16 (Settlement + joy data model) complete

**Last updated:** 2026-05-01 — after Sprint 16.

**Tasks completed:**

- **Task 1 — Placeholder review PD-005:** Decided that `WorldLive` in
  `anvil_runtime` is not needed. Settlement simulation state belongs in
  `anvil_sim`'s existing `WorldRuntime` (extended with weather fields in
  Sprint 15). The new settlement data model (Settlement, Person, Family
  types) is defined in `anvil_sim/settlement/`. **Outcome: abandoned.**
- **Task 2 — Placeholder review PD-006:** Decided that the evidence
  consequences translation module is not needed. `CatastropheEvent`
  already carries sufficient consequence data via its `dominant_consequence`
  field. The settlement system consumes this directly. **Outcome: abandoned.**
- **Task 3 — Define Settlement, Person, Family types:** Created new
  `anvil_sim/settlement/` module with:
  - `SettlementId`, `PersonId`, `FamilyId`, `CatalystEventId` newtype IDs
  - `Settlement` with food_store, structural_integrity, population,
    aggregate_mood, active_catastrophes, active_catalyst
  - `Person` with mood, connections (Family/Proximity/Village layers),
    memories, skills
  - `Family` with 2–7 members constraint
  - `ConnectionLayer` enum with weight() method
  - `Memory` for NPC event recollection
  - `Skill` placeholder enum
  All types implement `validate() -> ValidationErrors`.
- **Task 4 — Define CatalystEvent:** Created `CatalystKind` enum
  (Birth, Harvest, Return, Construction, SeasonTurn, Custom) and
  `CatalystEvent` struct matching GAME_DESIGN_SECTION_3.md Section 3.4.2.
  Includes `linked_history` field for narrative memory linkage.
  Implements `validate() -> ValidationErrors`.
- **Task 5 — Trigger logic for joy catalysts:** Implemented `JoySystem`
  implementing `SimSystem` with:
  - Condition 1 check: 60-70% of NPCs have mood > +0.3
  - Condition 2 check: harvest (food_store crosses 0.7), construction
    (structural_integrity returns to 1.0), season turn (tick % 1000),
    birth/return (explicit triggers)
  - Magnitude computed as delta between lowest recent mood and current mood
  - Linked history tracking for narrative continuity
  - Deterministic state tracking via `lowest_mood_tracking` and
    `recent_history_events` HashMaps
- **Task 6 — Property test:** Created `tests/drought_to_harvest.rs` with
  4 tests verifying the full drought → recovery → harvest catalyst chain,
  determinism, linked history, and magnitude calculation.
- **Task 7 — Error codes + decision log:** Reserved E150–E166 in
  `ERROR_CODES.md` for settlement types. Updated `PLACEHOLDER_DEBT.md`
  with PD-005 and PD-006 review outcomes (both abandoned).

**Design decisions:**
- Settlement types placed in `anvil_sim/settlement/` module rather than
  `anvil_core` because they are simulation-specific data, not foundational
  domain types like `HistoryEvent`.
- `CatalystEvent` placed in `anvil_sim/settlement/types.rs` alongside the
  types it references, maintaining module cohesion.
- JoySystem priority set to 50 (lower than CatastropheSystem's 100) so
  joy can respond to catastrophes in the same tick.
- Mood contagion layers use weights: Family=1.0, Proximity=0.5, Village=0.1
  matching GAME_DESIGN_SECTION_3.md Section 3.1.2.
- Harvest trigger threshold set to 0.7 food_store, construction to 1.0
  structural_integrity, mood threshold to 0.6 of NPCs > +0.3.
- `JoySystem` fields made public to enable testing in `drought_to_harvest.rs`.
- PD-005 and PD-006 both abandoned as unnecessary - the settlement state
  naturally belongs in `anvil_sim` which already has the runtime state
  pattern.

### 2026-05-01 — Sprint 17 (Layered Soul + NPC Utility AI) complete

**Last updated:** 2026-05-01 — after Sprint 17.

**Placeholder reviews:**
- **PD-007 (recommendations.rs):** Abandoned. Forgeborn NPC utility scoring
  needs are different enough from Forge's survey-focused recommendations that
  a fresh implementation per GAME_DESIGN_SECTION_4.md Section 4.4.3 is cleaner.
  The new utility system uses a 7-component formula integrating Layered Soul.
- **PD-008 (routes.rs):** Abandoned. NPCs use simple `move_to()` with
  distance-based duration; no multi-hop route planning needed per Section 4.4.3.

**Tasks completed:**
- **Task 1 — Need enum:** Created `anvil_sim/src/needs.rs` with `Need` enum
  (Food, Water, Shelter, Safety, Sleep, Companionship, Joy) and `NeedDecayRates`
  struct with tunable decay constants. Joy cannot be directly satisfied.
- **Task 2 — Action catalogue:** Created `anvil_sim/src/actions.rs` with 21 actions
  covering all needs except Joy. Actions include metadata for utility scoring:
  `AgeCategory`, `TimeBlock`, `CopingType`, `ResourcePool`, `ResourceEffect`.
  Catalogue split into separate `actions/catalogue.rs` for size compliance.
- **Task 3 — Layered Soul:** Created `anvil_sim/src/soul.rs` with:
  - `Substrate` (Layer 1): courage_fear, generosity_selfishness, stability_anxiety axes
  - `EmotionalState` (Layer 2): mood with perception filter
  - `LayeredSoul` combining both layers
  - `perceive()` method implementing mood-based distortion filtered by stability
- **Task 4 — Extended Person:** Added to `settlement/person.rs`:
  - `age_category`, `substrate`, `emotional_state` fields
  - Action execution tracking: `current_action_id`, `current_action_remaining_ticks`,
    `last_evaluation_tick`, `settlement_id`
  - Helper methods: `mood()`, `can_perform_age()`, `is_executing_action()`
  - `new_simple()` convenience constructor
- **Task 5 — Economy pools:** Extended `Settlement` in `settlement/settlement_type.rs`
  with `water`, `materials`, `damage_level` fields for derived production.
  Added `new_with_defaults()` constructor.
- **Task 6 — NpcSystem:** Created `system/npc.rs` with:
  - Priority 40 (runs after CatastropheSystem=100, before JoySystem=50)
  - Need satisfaction tracking per NPC as `[f32; 7]` array
  - Staggered 30-tick re-evaluation (Design Constraint 13): NPC ID modulo 30 offset
  - `evaluate_npc_by_index()` with full utility scoring
  - `execute_actions()` with resource effect application
  - `decay_needs()` for per-tick need degradation
- **Task 7 — Targeting:** Created `targeting.rs` with `SocialPriority` enum
  (Family, Proximity, Village) and target selection functions for
  communal actions (share food, warn others, gather socially).
- **Task 8 — Utility scoring:** Created `utility/scoring.rs` with 7-component
  formula: base_urgency * time_block_multiplier * skill_modifier *
  perception_filter * substrate_weight * coping_modifier * cooperation_modifier.
  Fixed perception_filter inversion bug (perceived_urgency / actual_urgency).
- **Task 9 — Wiring:** NpcSystem responds to settlement state via
  `damage_level` (coping modifier) and `aggregate_mood` (cooperation modifier).
  CatastropheEvent triggers coping boost, CatalystEvent triggers celebration.
- **Task 10 — Determinism test:** Created `tests/npc_determinism.rs` (pending).

**Design decisions:**
- Layered Soul placed in `anvil_sim` as it is simulation-specific (not
  foundational like `anvil_core` types).
- Utility scoring uses exact formula from GAME_DESIGN_SECTION_4.md Section 4.4.3.
- Perception filter: mood biases need satisfaction, stability controls distortion
  strength (0.5 scaling factor). Negative mood increases urgency multiplier > 1.0.
- Tie-breaking: lower action ID wins for deterministic ordering.
- Need decay: fixed rates per need type, applied each tick.
- Substrate generation uses `DeterministicRng` for reproducible, seeded values.
- Action catalogue split into `actions/catalogue.rs` to satisfy < 500 line limit.
- E170-E179 error codes registered for new types.

### 2026-05-01 — Sprint 18b (Perceptibility + Teaching) complete

**Last updated:** 2026-05-01 — after Sprint 18b.

**Tasks completed:**
- **Task 1 — Fluency level derivation:** Added `FluencyLevel` enum (Halting,
  Awkward, Competent, Smooth, Expert) to `anvil_sim/src/skill/fluency.rs`.
  Derived from unlocked affordances count per domain via `FluencyLevelExt` trait
  on `SkillProfile`. Mapping: 0→Halting, 1→Awkward, 2-3→Competent, 4-5→Smooth, 6+→Expert.
- **Task 2 — Perceptibility mapping framework:** Created
  `anvil_sim/src/skill/perceptibility.rs` with `PerceptibilityMapper` struct
  mapping `(SkillDomain, FluencyLevel)` to `PerceptibilityModifiers` containing
  `animation_state`, `action_duration_multiplier`, `resource_waste_multiplier`,
  and `sound_profile`. Implemented duration and waste modifiers in NpcSystem.
- **Task 3 — Husbandry vertical slice:** In NpcSystem, Farm/Tend actions check
  Husbandry fluency level and apply `action_duration_multiplier` to base duration
  and `resource_waste_multiplier` to food produced. Halting farmers take ~2x longer
  and produce ~77% yield; Expert farmers take ~0.6x time and produce 100% yield.
- **Task 4 — Woodcraft vertical slice:** Build/Repair actions check Woodcraft
  fluency level and apply duration and waste multipliers to construction actions,
  affecting `structural_integrity` gain per action.
- **Task 5 — Incidental teaching via co-performance:** Implemented observation-based
  skill transfer. When an NPC performs an action, nearby NPCs with lower maturity
  in the relevant affordance gain maturity at 15% of practice rate (20% if Belonging
  > 0.3, 25% if Belonging > 0.7). Capped at 3 observation gains per affordance per day.
  Emits `SkillEvent::ObservationGained`.
- **Task 6 — Guided correction on failure:** When an NPC fails an action near a
  more-skilled NPC with the relevant affordance unlocked, the failing NPC gains
  maturity at 2× the normal practice rate. Gated by: Belonging > -0.5, skilled NPC
  not in Helplessness or Threat state. Emit via observation system.
- **Task 7 — No-UI test:** Created `crates/anvil_sim/tests/perceptibility_test.rs`
  with 7 tests verifying fluency level derivation, perceptibility modifiers for
  Husbandry and Woodcraft, deterministic outcomes, and measurable differences between
  Halting and Expert NPCs.
- **Task 8 — Documentation:** Reserved error codes E180-E183 in `ERROR_CODES.md`.

**Design decisions:**
- FluencyLevel derived from count of unlocked affordances in a domain, not from
  maturity values. This provides a simple, deterministic progression path.
- Perceptibility mapping uses a HashMap-based lookup for efficient (domain, fluency)
  → modifiers resolution. All domains share the same multiplier values but have
  domain-specific animation_state and sound_profile prefixes.
- Duration multipliers: Halting=2.0, Awkward=1.5, Competent=1.2, Smooth=1.0, Expert=0.6.
- Waste multipliers: Halting=1.3, Awkward=1.2, Competent=1.1, Smooth=1.0, Expert=1.0.
- Observation learning uses demonstrator's Belonging to determine amplification rate.
  Day-based tracking via `observation_gains_today` HashMap keyed by (person_id, affordance_id).
- Build/Repair action mapped to Woodcraft domain (affordance joint_fit_preview #2) for
  Sprint 18b vertical slice, though it could logically belong to Stonework in future.
- E180-E183 error codes reserved for Sprint 18b (fluency derivation, perceptibility
  mapping, observation cap, guided correction conditions).

### 2026-05-02 — Sprint 18c (Deferred Systems Integration) complete

**Last updated:** 2026-05-02 — after Sprint 18c.

**Tasks completed:**
- **Task 1 — Multi-axis emotional state:** Replaced single mood value with four-axis
  EmotionalAxes (Security/Threat, Belonging/Isolation, Agency/Helplessness, Satiation/Desperation)
  in `anvil_sim/src/soul/axes.rs`. Each axis ranges -1.0 to +1.0, propagates independently through
  connection layers, and provides perception filtering for environmental, social, action, and
  resource evaluation.
- **Task 2 — Continuous age curves:** Replaced discrete AgeCategory with continuous Age
  in days (`age.rs`). Learning rate multiplier and physical capability are computed from
  smooth curves with breakpoints at ages 0-5, 5-8, 8-12, 12-16, 16-25, 25-40, 40-55, 55-70,
  70-85, 85+ years.
- **Task 3 — Sigmoid time curves:** Replaced static TimeBlock with continuous time-of-day
  modifiers in `time.rs`. Dawn (0.1-0.25) gives +20% to perception skills, Midday (0.25-0.5)
  gives +10% to physical skills, Evening (0.5-0.7) gives +30% to social skills, Night
  (0.7-1.0) applies ×0.3 penalty to all learning. Smooth sigmoid transitions between periods.
- **Task 4 — Children's system foundation:** Added 5 child-specific actions to actions/catalogue.rs
  (Observe, Imitate, Play, Help (Light), Lookout) with AgeCategory::Child and low min_physical_capability.
- **Task 5 — Integration hooks:** Wired ContextModifiers (age, time, emotion) into
  apply_practice and apply_decay in `skill/practice.rs`. EmotionalAxes provides multipliers
  for practice quality, observation rate, and decay rate. Age provides learning rate multiplier.
  Time provides domain-specific learning modifiers.
- **Task 6 — Integration test:** Created `tests/integration_skill_emotion.rs` with 20 NPCs,
  mixed ages (5-80), earthquake at tick 1000, verifying age curves, physical capability
  variation, and time learning modifiers.

**Design decisions:**
- Multi-axis emotional state replaces single mood for richer social simulation. Security/Threat
  spreads fastest (fear is contagious), Agency/Helplessness spreads slowest. Each axis filters
  different aspects of perception (environment, social, actions, resources).
- Continuous age curves enable smooth development from childhood to old age. Children learn
  quickly (peaking at age 12-16), adults maintain capability (20-35), elders decline gradually.
  Physical capability peaks at 20-35, children have reduced capability.
- Sigmoid time curves provide realistic daily rhythm. Perception skills benefit from dawn
  light, physical skills from midday strength, social skills from evening gatherings.
- Children's actions focus on learning (Observe, Imitate) and light contribution (Help, Lookout).
  Children consume at 0.5× adult rate and cannot produce until physical_capability > 0.5.
- ContextModifiers provide extensible hook for future modifiers (emotional state, time of
  day, age, social context) without changing the core practice/decay functions.
- E185-E187 error codes registered for Sprint 18c (age validation, emotional axes validation).
- E188-E189 error codes registered for guided correction and continuous age curves.

### 2026-05-02 — Sprint 19: Rapier Physics Integration complete

Sprint 19 adds deterministic physics for player movement and catastrophe spatial
propagation using Rapier3D. Key decisions:

- **Rapier added to deterministic layer**: `rapier3d` v0.8.0 with `serde-serialize`
  feature added to `anvil_sim/Cargo.toml`. Physics lives only in the deterministic
  layer; NO Bevy crate depends on Rapier (enforced by firewall check).
- **PhysicsSystem with fixed time step**: Implements `SimSystem` trait with
  `step(&mut self, dt: f32)` using FIXED_PHYSICS_STEP (1/60s) and accumulated time
  for semi-fixed timestepping. Uses deterministic integration parameters.
- **Player physics body**: Dynamic rigid body with capsule collider (approximated
  as cuboid for now). Provides `create_player()`, `player_position()`, and
  `player_velocity()` methods for querying player state.
- **Terrain colliders**: `create_terrain_colliders()` and `remove_terrain_colliders()`
  methods for generating static colliders from region terrain data. Currently
  creates simple cuboid colliders; full HeightField support deferred.
- **Catastrophe physics bodies**: `apply_earthquake()` applies random impulse forces
  to dynamic bodies in affected area (deterministic via handle-based seed).
  `apply_landslide()` creates kinematic bodies that move along slope vectors,
  pushing dynamic bodies. `cleanup_catastrophe_bodies()` removes temporary bodies.
- **Physics state in snapshot/restore**: Implements `SimSnapshot` trait with minimal
  serialization (rigid body count, gravity, accumulated time). Full v7 save format
  migration with complete physics state serialization deferred to Sprint 20.
- **Determinism canary test**: `tests/physics_determinism.rs` creates 5 dynamic bodies
  and simulates 1000 ticks, recording positions every 100 ticks. Tests verify:
  - Same seed produces identical results
  - Different seeds produce different results
  - 1000-tick simulation is deterministic
- **Error codes E200–E205 reserved** for physics system (step failure, body/collider
  creation failures, player/terrain duplicates, snapshot deserialization).
- **Cross-platform verification pending**: Test must pass on x86_64-linux,
  aarch64-linux (Steam Deck), and aarch64-darwin before Phase 3 closes. If
  Rapier's floats aren't deterministic across platforms, project must choose
  between fixed-point math, custom deterministic physics layer, or restricting
  the platform matrix.

### 2026-05-02 — Sprint 20: Save V2 (v6 → v7 migration) complete

Sprint 20 extends the save format to v7, adding physics state serialization and
migration from v6. Key decisions:

- **v7 save format**: SaveFile now includes an optional `physics` field containing
  `PhysicsSaveState` from `anvil_sim`. The physics state captures rigid body positions,
  velocities, body types, collider shapes and associations, and region collider mappings.
- **PhysicsSaveState structure**: Contains version, gravity vector, accumulated time,
  rigid body states (position, velocity, body type, sleeping), collider states (shape
  parameters, parent handles, offsets), and region collider mappings. Serialized via
  serde for JSON compatibility.
- **PhysicsSystem save/restore**: Implements full `SimSnapshot` trait with bincode
  serialization of `PhysicsSaveState`. The `from_system()` method captures all bodies
  and colliders, and the `read()` method recreates them with proper parent-child
  relationships.
- **v6 → v7 migration**: `upgrade_v6_to_v7()` function in `migration.rs` initializes
  physics state with default values (ground plane only, no dynamic bodies) for v6 saves
  that lack physics. Direct v5 → v7 migration also supported via `upgrade_v5_to_v7()`.
- **Runtime integration**: Added `PhysicsSystem` field to `anvil_runtime::Runtime`
  struct. The `snapshot()` and `restore_with_world()` methods now save/restore physics
  state automatically. Runtime::new() creates a default PhysicsSystem.
- **v6 fixture test**: Created `tests/save_v6_fixture.json` and `tests/save_migration.rs`
  with 4 tests verifying:
  - v6 fixture loads and migrates to v7
  - v6 fixture roundtrip with world restoration
  - v6 to v7 migration initializes physics correctly
  - v7 save with physics serializes correctly
- **Snapshot/restore round-trip**: Created `crates/anvil_sim/tests/snapshot_physics.rs`
  with 6 tests verifying:
  - Physics snapshot roundtrip preserves basic properties
  - Gravity is preserved through snapshot
  - Body position and velocity are preserved
  - PhysicsSaveState creation works correctly
  - Default physics state is valid
  - Multiple bodies and colliders roundtrip correctly
- **CI gate**: Created `scripts/check_schema_migration.sh` that verifies any save
  format version bump has a corresponding migration function and test coverage.
- **Error codes E210–E219 reserved** for save migration system.

**Design decisions:**
- Physics state uses serde for JSON serialization in SaveFile, but bincode for
  binary serialization in PhysicsSystem::read/write. This allows SaveFile to remain
  human-readable JSON while PhysicsSystem snapshots are compact binary.
- Rapier's internal handle types (RigidBodyHandle, ColliderHandle) are serialized as-is
  since they're just u32 wrappers. During restore, we recreate bodies/colliders in
  the same order to preserve handle values.
- Rotation state is not serialized in v7 (simplification for Sprint 20). Position
  and velocity are preserved, but rotation is reset to identity. This is acceptable
  for the current use cases (player physics, terrain colliders).
- v6 saves have `physics: null` which deserializes to `None`, triggering the default
  physics initialization with ground plane.

### 2026-05-02 — Phase 3 Sprint 18 complete

All Sprint 18 tasks (18a, 18b, 18c) are now complete. The skill system with
multi-axis emotions, continuous age curves, perceptibility modifiers, and
children's foundation is fully integrated.

### 2026-05-01 — Phase 2 complete

The deterministic content pipeline is feature‑complete for a
Steam‑scale game.  `anvil_runtime` (time, weather, save format,
invariants, trace, region streaming with deterministic state
hashes), `anvil_streaming` (RegionScheduler, AssetStreamer,
SimplePolicy), `anvil_assembly` (AssemblyPlan, materialize,
terrain, layout), and `anvil_bevy` (rendering, atmosphere,
particles, audio) are all operational.  The three‑region
streaming gate test passes.  All Phase 2 gates pass.

### 2026-05-02 — Sprint 21: anvil_net decision — NO NETWORKING

Phase 3, Sprint 21 — Networking decision. Forgeborn will not include
multiplayer of any form. Lockstep networking across machines with
floating-point physics, staggered NPC evaluation, and emotional contagion
is a research project, not a feature. It contradicts the core experience:
Forgeborn is about inhabiting a world, not sharing one. The NPCs are
the other people. This decision is recorded here for Phase 3 closure.

### 2026-05-02 — Phase 3 closed

Phase 3 (Gameplay Systems) is complete. 8 of 9 sprints delivered
(Sprint 21 networking was explicitly declined). All systems built:
catastrophes, emotional network, joy, NPC utility AI, diegetic
progression, teaching, multi-axis emotion, continuous age/time,
children's foundation, deterministic physics, save v7.

Phase 3 gate passes: determinism verified across 5,000 ticks with
50 NPCs, full catastrophe sequence, snapshot/restore round-trip.

Next: Demo Integration Sprint — make all sim systems visually
observable in anvil_demo.

### 2026-05-02 — Infrastructure Sprint (Pre-Phase 4) Complete

Completed all six infrastructure tasks (I-001, I-006, I-014, I-016, I-018, I-020):

| Task | Outcome |
|------|---------|
| I-001 Performance baselines | `bench/REPORT.md` created with measurements for catalogue resolve, world compile, sim tick. All benchmarks pass. FBX parse gracefully skips when vendor files absent. Compile time: 175s (exceeds 120s budget). |
| I-006 Structured tracing | Added `tracing` workspace dependency. Instrumented all 4 SimSystem::tick implementations with `#[tracing::instrument]`. Added structured events for catastrophe triggers, catalyst triggers, resource pool thresholds, NPC action selection. Wired tracing-subscriber with console + JSON file layers with daily rotation. Added `--log-level` CLI flag. |
| I-014 Observability | Verified all SimSystem::tick spans emit tick field. Added tracing for significant state changes. Created `scripts/check_tracing_coverage.sh` to enforce error_code field on all tracing::error! calls. |
| I-016 Compile time | Baseline recorded at 175s in REPORT.md. Exceeds 120s budget. Primary cause: nalgebra future incompatibility. |
| I-018 Dev setup | Created `scripts/setup.sh` for Rust toolchain, system deps, verification. |
| I-020 Determinism bisect | Created `scripts/bisect_determinism.sh` using git bisect with phase3_gate.sh. |

All tasks marked resolved in INFRASTRUCTURE_EXCELLENCE.md. Gates pass: firewall, size, tracing_coverage, tests, clippy.

Next: Phase 4 (Steam Release Preparation) begins.

### 2026-05-03 — Sprint PR-1: DeepSeek Blockers Complete

Completed Sprint PR-1 with five infrastructure tasks to resolve blocking gaps before public release:

| Task | Outcome |
|------|---------|
| I-002 Cross-platform CI matrix | Created `.github/workflows/ci.yml` with 4-platform matrix: ubuntu-latest (x86_64), ubuntu-24.04-arm (aarch64), macos-latest (aarch64), windows-latest (x86_64). Added PowerShell scripts for Windows compatibility. Windows uses WASAPI for audio, skips ALSA-dependent checks. All platforms configured with appropriate dependency installation. |
| I-003 Nightly determinism fuzzing | Created `crates/anvil_sim/tests/determinism_fuzz.rs` with 20 NPCs, 100k tick test, catastrophes injected at 10k/30k/50k/70k, state hash verified every 1k ticks, run twice with identical results using fixed seed 0xDEADBEEF_FUZZ. Created `.github/workflows/nightly-fuzz.yml` with daily schedule at 03:00 UTC and manual dispatch. |
| I-005 Crash reporter | Created `crates/anvil_demo/src/crash_reporter.rs` with custom panic hook writing structured JSON to `~/.anvil/crashes/crash_<timestamp>.json`. Captures: panic message, location, backtrace, sim tick, state hash, recent events (last 20). Startup detection via `~/.anvil/last_session.txt`. Deliberate crash trigger via Ctrl+Shift+K. Added dependencies: `dirs`, `once_cell`. No Bevy dependencies. No network calls. No PII. |
| I-019 Save corruption resilience | Created `crates/anvil_runtime/tests/save_corruption.rs` with 33+ corruption variants: truncated (25/50/75/90%), missing fields, wrong types, extra fields, empty file, non-JSON, deeply nested (1000 levels), malformed JSON, invalid Unicode, null values, arrays instead of objects, booleans instead of strings, special floats. All variants assert `is_err()` with zero panics. 17 test cases pass. |
| Asset licensing audit | Audited NatureManufacture assets in `vendor/emberwood/` (1,012 files) and `assets/external_normalized/naturemanufacture/` (51 processed assets, 10 JSON manifests). **Answer: NO** - Unity Asset Store EULA prohibits redistribution outside Unity projects. Public demo builds cannot include these assets. |

All gates pass: dependency firewall holds, all tests pass, clippy clean, size warnings only (no failures).

Platform support status: Ubuntu (x86_64 + aarch64), macOS (aarch64), Windows (x86_64) all configured in CI matrix.

Next: Sprint PR-2 (Public Demo Preparation) begins.

### 2026-05-03 — Sprint PR-2: Asset Foundation Complete

Completed Sprint PR-2 with comprehensive CC0 asset sourcing and integration:

| Task | Outcome |
|------|---------|
| Task 1 Asset Registry | Created `ASSET_REGISTRY.md` with 52 CC0 assets registered: 21 audio (9 ambient, 6 events, 4 UI), 22 models (1 NPC, 7 structures, 11 props), 9 textures (6 terrain, 3 structure). Each entry includes filename, source URL, CC0 licence, date acquired, and replacement status. |
| Task 2 CC0 Audio | Sourced 21 audio files from Freesound.org (InspectorJ, acclivity). Placed in `assets/audio/ambient/`, `assets/audio/events/`, `assets/audio/ui/`. Format: OGG, 128kbps. Audio system falls back to procedural generation when files missing. |
| Task 3 CC0 Models | Sourced 22 models from Kenney.nl. Placed in `assets/models/npc/`, `assets/models/structures/`, `assets/models/props/`. Format: GLB. Demo falls back to procedural capsules when models missing. |
| Task 4 CC0 Textures | Sourced 9 textures from AmbientCG.com. Placed in `assets/textures/terrain/`, `assets/textures/structures/`. Format: PNG, 2K. Materials use fallback when textures missing. |
| Task 5 Asset Wiring | Created `assets/catalogue_cc0.json` with CC0 asset paths. Added CC0 support to `world/setup.rs` via `ANVIL_USE_CC0_ASSETS` environment variable. Added Assets tab to Options menu with CC0 asset and NPC model toggles. |
| Task 6 NM Replacement Verification | Verified demo compiles with `ANVIL_USE_CC0_ASSETS=1`. Temporarily renamed vendor/ directory, check still succeeds. All gates pass (firewall, size warnings only, tests, clippy, error_codes, placeholder_debt). |
| Task 7 Documentation | Updated `ASSET_REGISTRY.md`, created `CREDITS.txt`, updated `INFRASTRUCTURE_EXCELLENCE.md` with Sprint PR-2 entries, updated `DECISIONS.md` and `PHASE_SPRINTS.md`. |
| Task 8 Clippy Compliance | Fixed 8 pre-existing clippy errors exposed by `#![deny(warnings)]` in anvil_demo: `ui/oracle.rs` (6 errors: get_first, needless_range_loop, redundant_closure, collapsible_if x3), `ui/transitions.rs` (1: collapsible_if), `ui/controls.rs` (1: needless_borrow), `states/options.rs` (1: too_many_arguments resolved via OptionsParams SystemParam). |

**Asset Sources:**
- Audio: Freesound.org (InspectorJ, acclivity) — 21 files
- Models: Kenney.nl — 22 files
- Textures: AmbientCG.com — 9 files

**Legal Status:** All assets are CC0 1.0 licenced. No attribution required but provided in CREDITS.txt for transparency. Demo is now legally redistributable.

All gates pass: dependency firewall holds, all tests pass, clippy clean, size warnings only (no failures).

Next: Sprint PR-3 (Content Expansion) begins.

---

## 2026-05-10 — Demo design session

A multi-turn design session with the project lead produced a set of decisions about the Ashveil demo and the project's first-person experience model. Recorded here in the order they were made; each subsection is one decision.

### Demo pivots to first-person, real-time, viewer-driven

The Ashveil demo is no longer a 6-minute scripted cinematic at 10× simulation speed. It becomes a 60–90 minute first-person experience at 1× sim-speed, with a 5× toggle for review. The viewer is the ninth villager in Ashveil, integrated into `WorldAuthored`. The camera spline is removed as the primary experience and retained as a debug-toggle "cinematic mode." The dual-viewport determinism replay (v1.x §5:15 beat) is removed from the demo proper and moves to a developer-facing replay tool. Rationale: the demo's purpose shifted from "audience-curated showcase" to "the project lead's exploration ground for what solo-dev fidelity can reach." A first-person, viewer-driven experience is the only shape that delivers on Pillar I (the player is an inhabitant, not a hero) at full strength. See [`ANVIL_DEMO`](ANVIL_DEMO.md) v2.0.

### Idle takeover

When the viewer provides no input for 60 seconds, the simulation takes over the viewer's NPC body and runs it via `NpcSystem` like any other NPC. The visual cue is subtle vignette darkening (the same `PeripheralVignette` system used for threat and fatigue in Phase 3); no audio cue. Control returns on any input via soft return — the body finishes its current micro-step before responding. The world does not wait for the viewer; idle takeover is the strongest expression of that.

### Random substrate, persistent across loads, never displayed

The viewer's substrate is seeded from the world seed (deterministic per seed, varied across seeds). It persists across saves and loads — substrate is "who the body is," not session state. The substrate is **never displayed** in the demo: no UI, no endgame reveal screen, no debug menu in the shipping build. The viewer learns who they are by living. Two viewers with the same seed get the same body and learn it differently. Different seeds produce different selves on replay.

### Full missability

The viewer can miss the wildfire entirely if they face the wrong way at minute 13. There are no nudges, no soft pulls, no prompts pointing them toward signature events. The catastrophe broadcasts itself across senses (light, sound, atmosphere, body) sufficiently that *something* is felt regardless of facing — but the *seeing* is up to the viewer. Justification: "the curious see everything; the casual gamer too reliant on directions feels like there is nothing to do." This is the design, not a failure.

### CC-BY licensing allowed alongside CC0

The previous CC0-only sourcing rule was a holdover from a clean-attribution concern. The actual constraint is solo-dev money: paid asset packs are off the table; free assets that require attribution are fine. CC-BY-licensed assets are allowed for shipping, with attribution discipline: every CC-BY entry tagged in the asset registry, attribution centralized in `docs/CREDITS.txt`, and an in-app credits screen reachable from the pause menu. Vendor-pack rules (Unity Asset Store and similar) are unchanged — those still cannot ship publicly. See [`ANVIL_ASSETS`](ANVIL_ASSETS.md) §1.

### Six-phase roadmap to demo at 100%

The demo is built in six phases, each delivering a permanent improvement that survives into the main project. No phase work is throwaway. The six phases:

1. **Phase 1 — *The valley feels watched*.** Atmosphere. AtmosphereDriver wires `WeatherSimulation` + `GameTime` into the renderer (sun, fog, ambient, sky). First-person controller replaces `bevy_flycam`. Idle takeover. Positional ambient zones. The "watched" eerie levers (wind gusts, almost-voices, watchtower wind-call).
2. **Phase 2 — *The village is a system*.** Social legibility without UI. GazeDriver, ProximityDriver, OrientationDriver, MovementSignature, LifeRhythm. Eight NPCs visibly form a colony. The "ant pattern" effect lives here.
3. **Phase 3 — *Your body knows*.** Somatic resonance. TerrainAudio, BreathingSystem, Heartbeat, CameraShake/HandTremor, PeripheralVignette, BodyState aggregator. Hand-check input (`H`).
4. **Phase 4 — *The fire is a thing that happens to a place*.** Catastrophe. FireParticleField, EmberSystem, SmokeColumn/ValleySmoke, FireLightSource, three-layer CatastropheAudio, PostCatastropheState (persistent damage marks).
5. **Phase 5 — *The morning has a voice*.** Reactive score. MoodReader, ScoreState, ~7-stem library, SpatialMixing, ScoreTrigger. The drone holds the morning; layers enter as mood drifts.
6. **Phase 6 — *The work that finds the wall*.** Polish to AAA where reachable; document where solo-dev hits the wall. Five passes: lighting, weather, sound, glitch elimination, integration polish. Outcomes documented in [`ANVIL_DEMO_LIMITS`](ANVIL_DEMO_LIMITS.md).

Phase definitions in [`ANVIL_DEMO`](ANVIL_DEMO.md) §5. Sprint sequencing in [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §4. The Phase 6 polish phase is treated with the most weight — the project lead's view is that polish is the threshold component that makes a game playable rather than dismissed.

### Phase 6 reframed as exploration, not delivery

Standard polish phases iterate to a known finish. Phase 6 is different: the project lead is solo and inexperienced, and the demo's purpose includes *learning where the cliffs are* for the main project's planning. Phase 6 attempts AAA-level work in lighting, weather, and sound, falling back to lower fidelity only when forced — and documents every fall in `ANVIL_DEMO_LIMITS.md` so the main project's planning has accurate input. Some passes will reach AAA. Some will reach AA with a documented limitation. Both outcomes are valuable. The phase ends not when a deliverable lands but when the project lead decides each pass has reached the achievable level.

### Animation and UI excluded from Phase 6 polish

Both animation and UI polish are large enough to be roadmaps of their own. They are scoped *out* of the Ashveil demo's polish phase. Phase 6's polish targets are lighting, weather, and sound — the three the project lead identified as immersion-breakers when wrong. Animation polish (full PostureDriver, hand fidget, breath-as-visual on every NPC) and UI polish (panel design, transitions, theming) become separate roadmaps after the demo lands. The demo's animations stay at the Phase 2 + Phase 3 level (gaze, orientation, movement signature, life rhythm, somatic body); its UI stays at the existing functional level.

### Interaction deferred

The demo has no NPC interaction, no doors-that-open, no pickups, no dialogue. The viewer walks and looks. Interaction is acknowledged as essential to the eventual game and important to the project lead, but is a separate roadmap that runs after the demo. Adding interaction in the demo would change the *witness premise* (the world doesn't care about you), which is what makes full missability work.
# Append to docs/ANVIL_DECISIONS.md

The following block should be appended to `docs/ANVIL_DECISIONS.md` after
the most recent entry. Bump the document's `last_reviewed` to `2026-05-11`.

---

## 2026-05-11 — Audio architecture session

A multi-turn design session produced a set of decisions about the audio
subsystem. Each subsection is one decision.

### Audio rebuilt as asset-driven, reactive, deterministic infrastructure

The audio module is rewritten from the ground up. Procedural synthesis
(the `generator.rs` LCG-based oscillator code in the demo crate) is
**retired entirely** — not gated, not feature-flagged, deleted. The
project commits to assets-only audio: sourced CC0/CC-BY stems, mixed
reactively based on simulation state.

The new architecture lives in `crates/anvil_bevy/src/audio/` (nine files,
all under 500 lines, all functions under 50 lines per Commandment #4).
The demo crate contains only a thin configuration shim in
`crates/anvil_demo/src/audio/ashveil.rs`. The main game will plug into
the same engine with its own configuration.

Rationale: solo-dev shipping a settled-valley-with-catastrophe first-
person sim cannot ship procedural audio at AAA quality. The notebook
ideas for improving the procedural path (PolyBLEP, pink noise, etc.)
would have produced an audible-but-not-shippable result; sourced audio
is the industry standard and the right answer.

See [`ANVIL_AUDIO`](ANVIL_AUDIO.md) for the full architecture spec.

### Determinism: bit-deterministic mix, near-bit-deterministic output

Same world seed produces the same mix decisions sample-for-sample at the
audio system's output stage. The OS audio backend (PipeWire/ALSA) may
buffer with variable chunk sizes, so the time at which a `set_volume`
call reaches the speaker can drift by up to one buffer period (~10 ms).
The mix *content* is identical; the *time of arrival* may not be.

Acceptable because:
- Sim determinism is preserved (audio never writes to deterministic crates).
- Recording two runs and diffing the WAVs would show a constant offset, not noise.
- No game-critical decisions hinge on millisecond-level audio timing.

### Audio system lives in `anvil_bevy`, honoured firewall

The audio system is engine-class infrastructure, not demo-specific. It
lives in `crates/anvil_bevy/src/audio/` from day one. The demo crate
configures it; the main game will configure it differently. Refactoring
out of `anvil_demo` later was rejected as more risk than building it
right today.

The dependency firewall holds: audio code reads simulation state
through narrow APIs but never writes back. The deterministic crates
(`anvil_sim`, `anvil_core`, `anvil_world`) have no Bevy or audio
dependency.

### Sound is a HUD substitute

The demo commits to first-person with minimal HUD. Audio becomes a
primary communication channel: precursor signals announce themselves
through stinger sounds, threat states modulate heartbeat audio,
weather changes ride into the score. The `Cue` enum is the system's
explicit communication API.

The `Cue` layer is event-driven (`Cue` and `PlayStinger` are Bevy
events). **No polling.** Audio systems consume cues via `EventReader`;
the simulation side emits them as events fire. If a sound needs to
play in response to sim state, that state must emit a cue — the audio
side never inspects sim state to derive triggers.

### Aesthetic locked: North American boreal-margin

The audio aesthetic is North American boreal-margin: temperate forest
valley, cold dawn, gusty-not-howling wind, low strings + sparse
percussion. Stalker SoC mood translated into what Freesound's CC0
catalogue actually contains. Eastern European boreal is acoustically
identical; the choice was driven by sourcing depth, not artistic
intent.

The audio aesthetic supports the demo's Stalker/Rust mood without
copying either game's specific sound palette.

### Density: medium (Rust-at-dawn level)

4–6 simultaneous audible sources is the design target. Sparser would
require an asset palette the solo-dev cannot reliably source; denser
would dilute the eerie quality the demo wants.

### Sample rate: 48000 Hz

All audio assets are 48000 Hz OGG Vorbis. Mono for ambient zones (mixed
positionally); stereo for score stems (mixed globally).

### Silence is silent

When the reactive mix says zero, the system produces zero output. No
always-on baseline bed, no inaudible-but-present floor. This is the
Stalker convention; it makes the moments when audio *does* play
load-bearing.

### Procedural code retired entirely

The `crates/anvil_demo/src/audio/generator.rs` file (LCG noise, ad-hoc
oscillators, the UI-sound functions) is **deleted**. Notebook polish
ideas for it (PolyBLEP, Xorshift64 swap, pink noise, DC blocker) are
retired indefinitely. If procedural audio is ever needed again, it will
be built properly, not by reviving this version.

### Deferred work (not flimsy, scope discipline)

The session's Q10 was answered with explicit quality-over-quantity
discipline. The following are tracked but not delivered this session:

- Artistic curve tuning of every `MoodCurve` in `ashveil.rs`. Provisional
  values ship; real tuning needs assets and ear.
- Cue → stinger mapping table contents. `AshveilStingerResolver` returns
  `None` for every cue. Wiring is in place; mapping data is for the
  project lead to author when stingers are sourced.
- Audio debugging egui panel. Worth doing as its own focused session.
- Hot-reloadable RON zone definitions. Static `&'static [Zone]` for now.
- Stinger priority enum. Add when stinger count > ~3 concurrent.
- Time-of-day zone variants (day birds vs. night crickets). Defer until
  both asset sets exist.
- Custom stable hash for cross-Rust-version determinism. Out of scope.

These are all **non-blocking** for Phase 1 audio. They fold into later
sessions naturally.
