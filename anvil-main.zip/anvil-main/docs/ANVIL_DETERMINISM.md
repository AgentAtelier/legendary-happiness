---
id: ANVIL_DETERMINISM
title: Determinism Guarantees and Tests
status: active
audience: [developer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [determinism, simulation, runtime]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_ROADMAP]
owner: crate:anvil_sim
version: 1.0
gate_scripts: [tests/phase3_gate.sh]
code_paths: [crates/anvil_sim, crates/anvil_runtime]
---

# Phase 3 Determinism Documentation

**Date:** 2026-05-02  
**Status:** Phase 3 Gate - Sprint 22  
**Owner:** anvil_sim crate

---

## Overview

This document describes the determinism guarantees, verification procedure, and known limitations for Phase 3 (Gameplay Systems) of the Anvil/Forgeborn project.

### What Determinism Means for This Project

**Byte-identical state hashes given identical inputs, regardless of platform.**

This means:
- The same RNG seed, same initial world state, and same input events must produce the exact same simulation state at every tick
- State hashes must be identical across x86_64-linux, aarch64-linux, and aarch64-darwin
- Floating-point values are hashed using their bit representation (`to_bits()`) to avoid precision-related mismatches
- The hash includes all relevant simulation state: NPC positions, emotional state, skill maturities, settlement resources, active catastrophes, and triggered catalyst events

### Determinism Scope

Phase 3 determinism covers the following systems built during Phase 3:

| System | Determinism Status | Test Coverage | Notes |
|--------|-------------------|---------------|-------|
| Catastrophe System | ✅ Verified | `determinism.rs`, `phase3_determinism.rs` | All 7 catastrophe types, precursor signals, spatial propagation |
| Settlement Emotional Network | ✅ Verified | `drought_to_harvest.rs`, `phase3_determinism.rs` | Mood contagion, 4 emotional axes, 3 connection layers |
| CatalystEvent Joy System | ✅ Verified | `drought_to_harvest.rs`, `phase3_determinism.rs` | Conditional emergence, linked history |
| NPC Utility AI | ✅ Verified | `npc_determinism.rs`, `phase3_determinism.rs` | Needs, actions, layered soul, targeting |
| Diegetic Progression | ✅ Verified | `skill_determinism.rs`, `perceptibility_test.rs`, `phase3_determinism.rs` | Skills, practice/decay, perceptibility |
| Teaching | ✅ Verified | `perceptibility_test.rs` | Incidental co-performance, guided correction |
| Multi-axis Emotional State | ✅ Verified | `integration_skill_emotion.rs`, `phase3_determinism.rs` | 4 axes (Security/Threat, Belonging/Isolation, Agency/Helplessness, Satiation/Desperation) |
| Continuous Age Curves | ✅ Verified | `integration_skill_emotion.rs` | Smooth capability curves from childhood to elder |
| Sigmoid Time Curves | ✅ Verified | `time.rs` unit tests | Daily rhythm modifiers |
| Children's Foundation | ✅ Verified | `integration_skill_emotion.rs` | Child-specific actions and constraints |
| Deterministic Physics | ⚠️ Platform-dependent | `physics_determinism.rs` (Sprint 19), `snapshot_physics.rs` | Rapier3D floats may vary across platforms |
| Save v7 | ✅ Verified | `save_migration.rs` | Physics state serialization, v6→v7 migration |

---

## Verified Deterministic Systems

### 1. Catastrophe System

**Test files:**
- `crates/anvil_sim/tests/determinism.rs` — property tests for catastrophe triggering, timing, and precursor signals
- `crates/anvil_sim/tests/phase3_determinism.rs` — comprehensive Phase 3 integration test

**Verified aspects:**
- Same seed produces same catastrophe types at same ticks
- Same seed produces same epicentre positions and magnitudes
- Same seed produces same precursor signals with same timing and intensity
- Different seeds produce different catastrophe patterns
- Flood and earthquake triggers are deterministic

**Implementation:** `anvil_sim::system::catastrophe::CatastropheSystem`

### 2. Settlement Emotional Network

**Test files:**
- `crates/anvil_sim/tests/drought_to_harvest.rs` — drought → recovery → harvest catalyst chain
- `crates/anvil_sim/tests/integration_skill_emotion.rs` — multi-axis emotion with age curves
- `crates/anvil_sim/tests/phase3_determinism.rs` — comprehensive Phase 3 integration test

**Verified aspects:**
- Mood contagion spreads deterministically through connection layers (Family, Proximity, Village)
- Each of the 4 emotional axes propagates independently
- Weighted propagation (Family=1.0, Proximity=0.5, Village=0.1) produces deterministic results
- Aggregate settlement mood is deterministic

**Implementation:** 
- `anvil_sim::settlement::Settlement` — resource pools, aggregate mood
- `anvil_sim::soul::EmotionalAxes` — 4-axis emotional state
- `anvil_sim::settlement::connection::ConnectionLayer` — social network layers

### 3. CatalystEvent Joy System

**Test files:**
- `crates/anvil_sim/tests/drought_to_harvest.rs` — catalyst triggering tests
- `crates/anvil_sim/tests/phase3_determinism.rs` — catalyst event recording

**Verified aspects:**
- Condition 1 (60-70% of NPCs with mood > +0.3) evaluated deterministically
- Condition 2 (trigger events: birth, harvest, return, construction, season turn) detected deterministically
- Catalyst magnitude calculation (delta between lowest recent mood and current mood) is deterministic
- Linked history tracking is deterministic
- Catalyst event IDs are assigned deterministically

**Implementation:** `anvil_sim::system::joy::JoySystem`

### 4. NPC Utility AI

**Test files:**
- `crates/anvil_sim/tests/npc_determinism.rs` — NPC action selection determinism
- `crates/anvil_sim/tests/phase3_determinism.rs` — comprehensive Phase 3 integration test

**Verified aspects:**
- Need satisfaction tracking is deterministic
- Staggered 30-tick re-evaluation (Design Constraint 13) produces deterministic ordering
- Utility scoring formula (7 components) produces deterministic results
- Action selection tie-breaking by NPC ID is deterministic
- Need decay is deterministic
- Skill practice and decay are deterministic

**Implementation:**
- `anvil_sim::system::npc::NpcSystem` — main NPC simulation system
- `anvil_sim::needs::Need` — 7 NPC needs
- `anvil_sim::actions` — action catalogue with metadata
- `anvil_sim::utility` — utility scoring

### 5. Diegetic Progression (Skills)

**Test files:**
- `crates/anvil_sim/tests/skill_determinism.rs` — skill practice and decay determinism
- `crates/anvil_sim/tests/perceptibility_test.rs` — fluency-based modifiers
- `crates/anvil_sim/tests/integration_skill_emotion.rs` — integrated skill/emotion testing
- `crates/anvil_sim/tests/phase3_determinism.rs` — skill maturities recorded

**Verified aspects:**
- Skill practice curves are deterministic
- Skill decay is deterministic
- Affordance unlocking is deterministic
- Fluency level derivation (Halting, Awkward, Competent, Smooth, Expert) is deterministic
- Perceptibility modifiers (duration, waste) are deterministic
- Incidental teaching via co-performance is deterministic
- Guided correction on failure is deterministic

**Implementation:**
- `anvil_sim::skill::` — skill profile, affordance, practice, decay, fluency, perceptibility
- `anvil_sim::system::npc::NpcSystem` — integrates skill system

### 6. Multi-axis Emotional State

**Test files:**
- `crates/anvil_sim/tests/integration_skill_emotion.rs` — emotional state integration
- `crates/anvil_sim/tests/phase3_determinism.rs` — 4 emotional axes recorded

**Verified aspects:**
- Security/Threat axis propagates deterministically
- Belonging/Isolation axis propagates deterministically
- Agency/Helplessness axis propagates deterministically
- Satiation/Desperation axis propagates deterministically
- Each axis filters perception independently
- Axis values remain in [-1.0, 1.0] range

**Implementation:** `anvil_sim::soul::EmotionalAxes`

### 7. Continuous Age Curves

**Test files:**
- `crates/anvil_sim/tests/integration_skill_emotion.rs` — age-based capability testing
- `crates/anvil_sim/tests/phase3_determinism.rs` — mixed age NPCs

**Verified aspects:**
- Age in days produces deterministic capability multipliers
- Learning rate peaks at ages 12-16
- Physical capability peaks at ages 20-35
- Children (5-12) have reduced capability
- Elders (55+) have gradually declining capability

**Implementation:** `anvil_sim::age::Age`

### 8. Sigmoid Time Curves

**Test files:**
- `anvil_sim/src/time.rs` — unit tests for time modifiers
- `crates/anvil_sim/tests/phase3_determinism.rs` — time-based simulation

**Verified aspects:**
- Dawn (0.1-0.25) gives +20% to perception skills
- Midday (0.25-0.5) gives +10% to physical skills
- Evening (0.5-0.7) gives +30% to social skills
- Night (0.7-1.0) applies ×0.3 penalty to all learning
- Smooth sigmoid transitions between periods

**Implementation:** `anvil_sim::time::`

### 9. Children's Foundation

**Test files:**
- `crates/anvil_sim/tests/integration_skill_emotion.rs` — child NPCs
- `crates/anvil_sim/tests/phase3_determinism.rs` — mixed age NPCs

**Verified aspects:**
- Child-specific actions (Observe, Imitate, Play, Help Light, Lookout) are available
- Children have reduced physical capability
- Children cannot produce until physical_capability > 0.5
- Children consume at 0.5× adult rate
- Children learn quickly (peaking at age 12-16)

**Implementation:** `anvil_sim::actions::catalogue` — child actions

### 10. Save v7 with Physics State

**Test files:**
- `crates/anvil_runtime/tests/save_migration.rs` — v6→v7 migration tests
- `crates/anvil_runtime/tests/save_v6_fixture.json` — v6 fixture
- `crates/anvil_sim/tests/snapshot_physics.rs` — physics snapshot tests
- `crates/anvil_sim/tests/phase3_snapshot_roundtrip.rs` — Phase 3 snapshot round-trip

**Verified aspects:**
- v6 saves migrate to v7 correctly
- v7 saves include physics state
- Physics state serialization via bincode is deterministic
- Physics snapshot/restore produces identical state
- Migration from v5→v7 is supported

**Implementation:**
- `anvil_runtime::snapshot::format::SaveFile` — v7 save format
- `anvil_runtime::snapshot::migration` — migration functions
- `anvil_sim::system::physics_snapshot::` — PhysicsSystem SimSnapshot impl

---

## Systems with Known Platform Dependencies

### Physics System (Rapier3D)

**Test file:** `crates/anvil_sim/tests/physics_determinism.rs` (Sprint 19 canary test)

**Issue:** Rapier3D uses floating-point arithmetic for physics simulation. While the library provides deterministic integration parameters, floating-point behavior may vary across:
- CPU architectures (x86_64 vs ARM)
- Operating systems (Linux vs macOS vs Windows)
- Compiler optimizations
- SIMD instructions

**Current status:** The canary test in `physics_determinism.rs` verifies determinism on the current platform. Cross-platform verification is **pending** and must pass before Phase 4 release preparation.

**Test procedure:**
```bash
# On each target platform:
cargo test -p anvil_sim --test physics_determinism
```

**Expected result:** All tests pass with identical results across x86_64-linux, aarch64-linux, and aarch64-darwin.

**Remediation path (if tests fail):**
1. **Fixed-point math:** Replace floating-point physics with fixed-point arithmetic. This is the most robust solution but requires significant implementation effort.
2. **Custom deterministic physics layer:** Implement a custom physics engine with guaranteed cross-platform determinism. This isolates the project from Rapier's floating-point behavior.
3. **Platform restriction:** Restrict the game to platforms where Rapier's determinism is verified. This is the shortest-term solution but limits the player base.

**Recommendation:** Start with option 3 (platform restriction) for Phase 4, then implement option 1 or 2 as a Phase 4 or Phase 5 task.

---

## Cross-Platform Verification Procedure

Before Phase 4 release preparation, the following must be verified on all target platforms:

### Target Platforms
- **x86_64-linux** — Primary development platform (GNU/Linux x86_64)
- **aarch64-linux** — Steam Deck and other ARM64 Linux devices
- **aarch64-darwin** — Apple Silicon Macs

### Verification Steps

1. **Clone the repository on each platform**
   ```bash
   git clone <repository-url>
   cd Anvil
   ```

2. **Ensure identical toolchain**
   ```bash
   # The rust-toolchain.toml pins the exact compiler version
   cat rust-toolchain.toml
   ```

3. **Run all determinism tests**
   ```bash
   cargo test -p anvil_sim --test phase3_determinism
   cargo test -p anvil_sim --test physics_determinism
   cargo test -p anvil_sim --test determinism
   cargo test -p anvil_sim --test npc_determinism
   cargo test -p anvil_sim --test skill_determinism
   cargo test -p anvil_sim --test drought_to_harvest
   cargo test -p anvil_sim --test integration_skill_emotion
   cargo test -p anvil_sim --test perceptibility_test
   ```

4. **Run snapshot round-trip tests**
   ```bash
   cargo test -p anvil_sim --test phase3_snapshot_roundtrip
   cargo test -p anvil_sim --test snapshot_physics
   ```

5. **Run save migration tests**
   ```bash
   cargo test -p anvil_runtime --test save_migration
   ```

6. **Compare test outputs**
   - All tests should pass on all platforms
   - Test execution times may differ, but results must be identical
   - Hash values in test output must match across platforms

### Expected Results

| Test | x86_64-linux | aarch64-linux | aarch64-darwin |
|------|--------------|---------------|----------------|
| `phase3_determinism` | ✅ Pass | ✅ Pass | ✅ Pass |
| `physics_determinism` | ✅ Pass | ✅ Pass | ✅ Pass |
| `determinism` | ✅ Pass | ✅ Pass | ✅ Pass |
| `npc_determinism` | ✅ Pass | ✅ Pass | ✅ Pass |
| `skill_determinism` | ✅ Pass | ✅ Pass | ✅ Pass |
| `drought_to_harvest` | ✅ Pass | ✅ Pass | ✅ Pass |
| `integration_skill_emotion` | ✅ Pass | ✅ Pass | ✅ Pass |
| `perceptibility_test` | ✅ Pass | ✅ Pass | ✅ Pass |
| `phase3_snapshot_roundtrip` | ✅ Pass | ✅ Pass | ✅ Pass |
| `snapshot_physics` | ✅ Pass | ✅ Pass | ✅ Pass |
| `save_migration` | ✅ Pass | ✅ Pass | ✅ Pass |

### Failure Handling

If any test fails on a target platform:

1. **Physics determinism failure:**
   - Check if the failure is consistent (same test fails every time)
   - Check if the failure is platform-specific (passes on one platform, fails on another)
   - If platform-specific, implement one of the remediation paths above

2. **Non-physics determinism failure:**
   - This is a critical issue - non-physics systems should be fully deterministic
   - Investigate the root cause immediately
   - Check for non-deterministic operations (HashMap iteration, floating-point comparisons, etc.)

3. **Snapshot/restore failure:**
   - Verify that serialization/deserialization is deterministic
   - Check for missing state in snapshots
   - Ensure all systems implement proper snapshot/restore

---

## Determinism Implementation Patterns

### 1. Deterministic RNG

All simulation systems use `anvil_sim::DeterministicRng` for pseudo-random number generation:

```rust
use anvil_sim::DeterministicRng;

let mut rng = DeterministicRng::new(seed);
let value = rng.next_f32_range(0.0, 1.0);  // Deterministic in [0.0, 1.0)
```

The xorshift64* algorithm provides:
- Fast generation (suitable for per-tick simulation)
- Good statistical properties
- Reproducible output from identical seed
- No platform dependencies

### 2. State Hashing

State hashes are computed using `DefaultHasher` with bit-level comparison for floating-point values:

```rust
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

let mut hasher = DefaultHasher::new();
// For f32 values, hash the bit representation
f32_value.to_bits().hash(&mut hasher);
// For Vec3, hash each component
pos.x.to_bits().hash(&mut hasher);
pos.y.to_bits().hash(&mut hasher);
pos.z.to_bits().hash(&mut hasher);
let hash = hasher.finish();
```

### 3. Deterministic Collections

When iteration order matters, use deterministic collection types:

```rust
// Use Vec with deterministic ordering (e.g., sort by ID)
let mut items: Vec<Item> = ...;
items.sort_by(|a, b| a.id.cmp(&b.id));

// Or use BTreeMap for ordered iteration
use std::collections::BTreeMap;
let map: BTreeMap<Id, Value> = ...;
// Iteration is always in key order
```

Avoid `HashMap` iteration for determinism-critical code, as iteration order is non-deterministic.

### 4. Snapshot/Restore Pattern

Systems that support snapshot/restore implement the `SimSnapshot` trait:

```rust
use anvil_sim::SimSnapshot;

pub struct MySystem {
    // System state
}

impl SimSnapshot for MySystem {
    fn write(&self, out: &mut Vec<u8>) {
        // Serialize state to bytes
        bincode::serialize_into(out, &self.state).unwrap();
    }
    
    fn read(bytes: &[u8]) -> Result<Self, SimError> {
        // Deserialize state from bytes
        let state = bincode::deserialize(bytes)?;
        Ok(Self { state })
    }
}
```

---

## Determinism Test Architecture

### Phase 3 Determinism Gate Test (`phase3_determinism.rs`)

The definitive determinism test for Phase 3. It:

1. **World setup:** Creates 1 settlement with 50 NPCs
   - Mixed ages (5–80 years)
   - Varied substrates (stable traits)
   - Varied initial emotional state (4 axes)
   - Varied initial positions (circular layout)

2. **Catastrophe injection:**
   - Flood at tick 500
   - Earthquake at tick 1500

3. **Simulation duration:** 5,000 ticks

4. **Recording:** Every 100 ticks, records:
   - State hash of the full simulation
   - All NPC positions (Vec3)
   - All NPC mood axes (4 emotional axes per NPC)
   - All NPC skill maturities (from skill profile)
   - Settlement resource pools (food, water, materials, structural integrity)
   - Active catastrophe event IDs
   - Triggered catalyst event IDs

5. **Assertions:**
   - Same seed → same state hash at every recorded tick
   - Same seed → same NPC positions at every recorded tick
   - Same seed → same emotional state at every recorded tick
   - Same seed → same skill maturities at every recorded tick
   - Different seed → different state (at least one value differs by tick 5000)

### Test Execution

```bash
# Run Phase 3 determinism gate
cargo test -p anvil_sim --test phase3_determinism

# Run with verbose output
cargo test -p anvil_sim --test phase3_determinism -- --nocapture
```

---

## Snapshot/Round-Trip Gate Test (`phase3_snapshot_roundtrip.rs`)

Verifies that simulation state can be snapshotted and restored:

1. **Setup:** Same as `phase3_determinism.rs` (50 NPCs, mixed ages, settlement)
2. **Simulation:** Runs to tick 2,500
3. **Snapshot:** Takes a snapshot of all systems that support it
4. **Restore:** Creates fresh simulation and restores from snapshot
5. **Continue:** Runs restored simulation for 2,500 more ticks
6. **Verify:** Compares final state hash against uninterrupted run

### Current Limitations

As of Sprint 22, only `PhysicsSystem` has full snapshot/restore support via `SimSnapshot`. The test:
- Verifies `PhysicsSystem` snapshot/restore works correctly
- Provides a framework for testing additional systems as they gain snapshot support
- Should be extended to include `NpcSystem`, `CatastropheSystem`, and `JoySystem` in future sprints

### Test Execution

```bash
# Run snapshot round-trip gate
cargo test -p anvil_sim --test phase3_snapshot_roundtrip
```

---

## Related Documentation

- [ANVIL_PHILOSOPHY.md](ANVIL_PHILOSOPHY.md) — Commandment #7 (Test at Every Level)
- [DECISIONS.md](DECISIONS.md) — Phase 3 decisions and Sprint 19/20 notes
- [PHASE_SPRINTS.md](PHASE_SPRINTS.md) — Phase 3 sprint breakdown
- [ERROR_CODES.md](ERROR_CODES.md) — Error codes for simulation systems
- [scripts/check_schema_migration.sh](scripts/check_schema_migration.sh) — CI gate for save format changes

---

## Maintenance

This document should be updated when:
- New systems are added to Phase 3
- Determinism tests are added or modified
- Cross-platform verification results are available
- Remediation paths for physics determinism are implemented

Last verified: 2026-05-02 (Sprint 22)
