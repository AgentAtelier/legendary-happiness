---
id: ANVIL_MIGRATION_PLAN
title: Documentation Migration Plan (May 2026)
status: active
audience: [developer]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_DOC_SYSTEM]
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: []
---
