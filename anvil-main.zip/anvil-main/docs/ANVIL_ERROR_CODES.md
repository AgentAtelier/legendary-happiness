---
id: ANVIL_ERROR_CODES
title: Anvil Error Code Registry
status: active
audience: [developer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_PHILOSOPHY]
owner: project_lead
version: 1.0
gate_scripts: [scripts/check_error_codes.sh]
code_paths: []
---

# Anvil Error Codes

Single registry for every structured error code in the workspace.
Codes are unique across all crates.

---

## anvil_core (E000–E039)

| Code | File | Type | Cause |
|------|------|------|-------|
| E000 | lib.rs (test) | DummyArtifact | missing required field |
| E001 | connections.rs | ConnectionSpec | from_region empty |
| E002 | connections.rs | ConnectionSpec | to_region empty |
| E003 | connections.rs | ConnectionSpec | from_region == to_region |
| E004 | semantic.rs | RegionSpec | name empty |
| E005 | semantic.rs | RegionSpec | mood empty |
| E006 | semantic.rs | RegionSpec | landmark count out of range |
| E007 | semantic.rs | LandmarkSpec | name empty |
| E008 | semantic.rs | LandmarkSpec | description empty |
| E009 | semantic.rs | RegionSpec | palette empty |
| E010 | semantic.rs | RegionSpec | density not valid |
| E011 | semantic.rs | RegionSpec | atmosphere empty |
| E012 | asset_request.rs | AssetRequestSpec | style_context empty |
| E013 | asset_request.rs | AssetRequestSpec | prompt_core empty |
| E014 | asset_request.rs | AssetRequestSpec | prompt_core exceeds 600 bytes |
| E015 | semantic.rs | RegionSpec | landmark name not unique |
| E016 | asset_request.rs | AssetRequestSpec | style_context exceeds 200 bytes |
| E017 | asset_request.rs | AssetRequestSpec | unknown quality_hint or source_hint variant |
| E018 | asset_request.rs | AssetRequestSpec | prompt_core contains prohibited control characters |
| E019 | asset_request.rs | AssetRequestSpec | style_context contains prohibited control characters |
| E020 | ids.rs | ArchetypeTag | tag empty |
| E021 | ids.rs | ArchetypeTag | tag format invalid |
| E022 | path.rs | repo_root | directory structure wrong |
| E023 | path.rs | AssetPath | path empty |
| E024 | connections.rs | ConnectionSpec | from_region not known |
| E025 | connections.rs | ConnectionSpec | to_region not known |
| E030 | world/history.rs | HistoryEvent | magnitude not in [0.0, 1.0] |
| E031 | world/history.rs | HistoryEvent | radius not positive |
| E032 | world/history.rs | HistoryEvent | epicenter contains non-finite values |
| E033 | world/history.rs | HistoryEvent | ticks must be strictly ascending |
| E998 | error.rs (test) | TestError | test error code for macro validation |
| E999 | error.rs (test) | TestError | test error code for macro validation |

E034–E039: Reserved for future anvil_core additions.

---

## anvil_assembly (A000–A099)

| Code | File | Type | Cause |
|------|------|------|-------|
| A001 | authority.rs | WorldPlanAuthorityReport | authority mismatch (unused archetype) |
| A002 | authority.rs | WorldPlanAuthorityReport | unused archetype in regions |
| A003 | authority.rs | WorldPlanAuthorityReport | unused archetype in entities |
| A010 | compile.rs | AssemblyPlan | plan serialization error |

A004–A009: Reserved for future `anvil_assembly` additions.
A011–A099: Reserved for future `anvil_assembly` additions.

---

## anvil_assets (E040–E099)

### Asset & catalogue validation (E040–E049)

| Code | File | Type | Cause |
|------|------|------|-------|
| E040 | types.rs | AssetEntry | path empty |
| E041 | types.rs | AssetEntry | footprint_radius <= 0 |
| E042 | types.rs | MaterialVariantEntry | material_key empty |
| E043 | types.rs | AssetMetadata | display_name empty |
| E044 | catalogue.rs | ManifestEntry | archetype tag empty |
| E045 | catalogue.rs | ManifestEntry | mesh path empty |
| E046 | catalogue.rs | ManifestEntry | footprint_radius <= 0 |
| E047 | catalogue.rs | ManifestEntry | invalid validation_date |

### External pipeline (E050–E079)

| Code | File | Type | Cause |
|------|------|------|-------|
| E050 | external_pilot.rs | ExternalAssetRegistration | display_name empty |
| E051 | external_pilot.rs | ExternalAssetRegistration | source_files empty |
| E052 | external_pilot.rs | ExternalAssetRegistration | source_file empty |
| E053 | pilot/registration.rs | ExternalAssetPackIdentity | vendor must not be blank |
| E054 | pilot/registration.rs | ExternalAssetPackIdentity | pack_name must not be blank |
| E055 | pilot/registration.rs | ExternalAssetPackIdentity | source_root must be an absolute path |
| E056 | pilot/registration.rs | ExternalAssetPackIdentity | source_manifest must be an absolute path |
| E057 | pilot/registration.rs | ExternalAssetPackIdentity | source_manifest not found |
| E058 | pilot/manifest.rs | ExternalAssetPilotManifest | records must not be empty |
| E059 | pilot/manifest.rs | ExternalAssetPilotManifest | source_manifest not found |
| E060 | pilot/manifest.rs | ExternalAssetPilotManifest | failed to read source_manifest |
| E061 | pilot/manifest.rs | ExternalAssetPilotManifest | record has mismatched pack identity |
| E062 | pilot/manifest.rs | ExternalAssetPilotManifest | record is missing source files |
| E063 | pilot/manifest.rs | ExternalAssetPilotManifest | blank source file reference |
| E064 | pilot/manifest.rs | ExternalAssetPilotManifest | duplicate normalized id |
| E065 | pilot/manifest.rs | ExternalAssetPilotManifest | manifest is not deterministically ordered |
| E066 | pilot/manifest.rs | ExternalAssetPilotManifest | display_name must not be blank |
| E067 | pilot/manifest.rs | ExternalAssetPilotManifest | texture reference not found |
| E068 | staging/manifest.rs | ExternalAssetNormalizationStageManifest | records must not be empty |
| E069 | staging/manifest.rs | ExternalAssetNormalizationStageManifest | source_manifest not found |
| E070 | staging/manifest.rs | ExternalAssetNormalizationStageManifest | duplicate normalized id |
| E071 | staging/manifest.rs | ExternalAssetNormalizationStageManifest | manifest is not deterministically ordered |
| E072 | staging/manifest.rs | ExternalAssetNormalizationStageManifest | record is missing source files |
| E073 | staging/manifest.rs | NormalizedOutputPath | path must not be absolute |
| E074 | staging/manifest.rs | NormalizedOutputPath | path must start with EXTERNAL_NORMALIZED_OUTPUT_PREFIX |
| E075 | normalization/batch.rs | ExternalAssetNormalizationBatchManifest | records must not be empty |
| E076 | normalization/batch.rs | ExternalAssetNormalizationBatchManifest | source_manifest not found |
| E077 | normalization/batch.rs | ExternalAssetNormalizationBatchManifest | duplicate normalized id |
| E078 | normalization/batch.rs | ExternalAssetNormalizationStageManifest | manifest is not deterministically ordered |

E079–E099: Reserved for future `anvil_assets` additions.

---

## anvil_world (E100–E139)

| Code | File | Type | Cause |
|------|------|------|-------|
| E100 | compiler.rs | World | Compilation failed |
| E101 | compiler.rs | Entity | Duplicate entity ID |
| E102 | compiler.rs | Region | Duplicate region ID |
| E103 | validation.rs | Connection | Dangling region reference |
| E104 | validation.rs | Entity | Dangling entity reference |
| E105 | compiler.rs | Entity | Unresolved archetype |
| E106 | compiler.rs | Region | Invalid landmark distribution |
| E107 | validation.rs | Region | Unreachable region |
| E108 | validation.rs | History | History digest mismatch |
| E110 | validation.rs | Connection | Duplicate connection ID |
| E111 | validation.rs | Entity | Missing asset reference |
| E112 | compiler.rs | History | Invalid history event |

E113–E139: Reserved for future `anvil_world` additions.

---

## anvil_sim (E140–E189)

| Code | File | Type | Cause |
|------|------|------|-------|
| E140 | system/physics_snapshot.rs | PhysicsSystem | Failed to deserialize physics state |
| E150 | settlement/ids.rs | SettlementId | Invalid settlement ID (must be non-zero) |
| E151 | settlement/ids.rs | PersonId | Invalid person ID (must be non-zero) |
| E152 | settlement/ids.rs | FamilyId | Invalid family ID (must be non-zero) |
| E153 | settlement/ids.rs | CatalystEventId | Invalid catalyst event ID (must be non-zero) |
| E154 | settlement/memory.rs | Memory | Invalid event ID (must be non-zero) |
| E155 | settlement/memory.rs | Memory | Invalid vividness value (must be in [0.0, 1.0]) |
| E156 | settlement/person.rs | Person | Invalid name (cannot be empty) |
| E157 | settlement/person.rs | Person | Invalid mood value (must be in [-1.0, 1.0]) |
| E158 | settlement/family.rs | Family | Invalid member count (must be 2-7 members) |
| E160 | settlement/catalyst.rs | CatalystEvent | Invalid magnitude value (must be in [0.0, 1.0]) |
| E161 | settlement/settlement_type.rs | Settlement | Invalid name (cannot be empty) |
| E162 | settlement/settlement_type.rs | Settlement | Invalid population (must be positive) |
| E163 | settlement/settlement_type.rs | Settlement | Invalid food_store value (must be in [0.0, 1.0]) |
| E164 | settlement/settlement_type.rs | Settlement | Invalid structural_integrity value (must be in [0.0, 1.0]) |
| E165 | settlement/settlement_type.rs | Settlement | Invalid aggregate_mood value (must be in [-1.0, 1.0]) |
| E166 | settlement/settlement_type.rs | Settlement | Invalid active_catalyst |
| E170 | actions.rs | ResourceEffect | Invalid rate (must be in [0.0, 1.0]) |
| E171 | actions.rs | Action | Invalid action ID (must be non-zero) |
| E172 | actions.rs | Action | Invalid action name (cannot be empty) |
| E173 | actions.rs | Action | Invalid duration (must be positive) |
| E174 | soul.rs | Substrate | Invalid axis value (must be in [-1.0, 1.0]) |
| E176 | settlement/settlement_type.rs | Settlement | Invalid water value (must be in [0.0, 1.0]) |
| E177 | settlement/settlement_type.rs | Settlement | Invalid materials value (must be in [0.0, 1.0]) |
| E178 | settlement/settlement_type.rs | Settlement | Invalid damage_level value (must be in [0.0, 1.0]) |
| E179 | system/npc.rs | NpcSystem | Invalid need satisfaction value (must be in [0.0, 1.0]) |
| E180 | skill/fluency.rs | FluencyLevel | Invalid fluency level derivation (reserved for Sprint 18b) |
| E181 | skill/perceptibility.rs | PerceptibilityMapper | Invalid perceptibility mapping lookup (reserved for Sprint 18b) |
| E182 | system/npc.rs | NpcSystem | Observation learning cap exceeded (reserved for Sprint 18b) |
| E183 | system/npc.rs | NpcSystem | Guided correction conditions not met (reserved for Sprint 18b) |
| E184 | skill/affordance.rs | MaturityState | Invalid peak maturity value (must be in [0.0, 1.0]) |
| E185 | age.rs | Age | Invalid age (must be non-negative and finite) |
| E186 | age.rs | Age | Age exceeds maximum reasonable value |
| E187 | soul/axes.rs | EmotionalAxes | Invalid axis value (must be in [-1.0, 1.0]) |

E188–E199: Reserved for future `anvil_sim` additions.

---

## anvil_runtime (E190–E239)

| Code | File | Type | Cause |
|------|------|------|-------|
| E190 | invariants.rs | Runtime | Invariant failure (generic runtime invariant violation) |
| E191 | time.rs | GameTime | seconds_since_start must be finite |
| E192 | time.rs | GameTime | day_length_seconds must be finite and positive |
| E193 | weather.rs | WeatherSimulation | temperature must be finite |
| E194 | weather.rs | WeatherSimulation | humidity must be finite and in [0.0, 1.0] |
| E195 | weather.rs | WeatherSimulation | pressure must be finite |
| E196 | weather.rs | WeatherSimulation | wind_speed must be finite and non-negative |
| E197 | weather.rs | WeatherSimulation | accumulated_precipitation must be finite and non-negative |
| E198 | weather.rs | WeatherSimulation | transition_progress must be finite and in [0.0, 1.0] |
| E199 | weather.rs | WeatherSimulation | phase_remaining_secs must be finite and non-negative |

E200–E239: Reserved for future `anvil_runtime` additions.

---

## Adding a new error code

1. Choose the next available code in the appropriate range.
2. Add a row to this file.
3. Add a corresponding documentation comment in the source file.
4. Use the code in validation.
