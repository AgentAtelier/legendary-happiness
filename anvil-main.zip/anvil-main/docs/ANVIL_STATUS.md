---
id: ANVIL_STATUS
title: Project Status (current state and next steps)
status: active
audience: [developer, agent, contributor]
last_reviewed: 2026-05-11
supersedes: []
tags: [meta, process]
related_docs: [ANVIL_ROADMAP, ANVIL_DECISIONS, ANVIL_DEMO, AGENTS]
owner: project_lead
version: 1.0
gate_scripts: [tests/phase3_gate.sh, scripts/check_docs.sh]
code_paths: []
---

## Active phase

**Demo Integration, Phase 1 (visuals + audio foundation).**

The demo runs as a 60–90 minute first-person experience in Ashveil at
dawn. The visual side has landed: AtmosphereDriver, FPS controller,
ambient zones, GLTF scene streaming. The audio side has now been
rebuilt from scratch as engine-class infrastructure
(see [`ANVIL_AUDIO`](ANVIL_AUDIO.md)).

## What just shipped (2026-05-11)

- Full audio architecture rebuild in `crates/anvil_bevy/src/audio/`.
- Plugin-registration crash fixed (AmbientAudioPlugin was registered twice).
- Screech bug fixed structurally (single source of entity bookkeeping).
- Audio determinism contract documented and tested.
- Demo's `crates/anvil_demo/src/audio/` replaced by thin Ashveil config.
- Audio asset shopping list authored ([`AUDIO_SHOPPING_LIST`](AUDIO_SHOPPING_LIST.md)).

## What's open

- **Asset sourcing.** See `AUDIO_SHOPPING_LIST.md`. The system runs without
  files (silently per stem), so sourcing is parallelisable with development.
- **`anvil_assets_pipeline` crate.** 25 compilation errors — syntax,
  derives, dead imports. Surgical fixes documented in `PIPELINE_FIX.md`
  in this bundle. Out of scope for the audio session; apply as a
  separate doc-style PR.
- **Phase 1 visuals.** Atmosphere driver and FPS controller landed.
  Outstanding polish: subtle camera bob, breath visibility at low temp
  (Phase 3 territory).
- **Phase 2 villagers.** Not started. GazeDriver, ProximityDriver,
  OrientationDriver, MovementSignature, LifeRhythm — all queued.

## Cross-cutting debt

- **Repo-root doc drift.** Many pre-doc-system files at the repo root
  (`DECISIONS.md`, `DEMO_VISION.md`, `EXECUTION_PLAN.md`, etc.)
  duplicate or pre-date the consolidated `docs/` set. Cleanup is a
  half-day task; not in any phase plan but worth doing before the next
  major design session.
- **Pipeline crate broken.** Demo binary compiles around it (cargo's
  per-crate isolation), but no work using the pipeline can proceed
  until the surgical fixes in `PIPELINE_FIX.md` land.

## Next session

Either:
- Apply audio rebuild + pipeline fix, then start Phase 2 villager work.
- Or apply audio rebuild, source the first 3 audio files
  (`village_hum`, `wind_strong`, `drone`), and tune the `MoodCurve`s
  against real audio before moving to Phase 2.

The second option produces a more audible demo for an evening's
sourcing work; the first preserves engineering momentum.
