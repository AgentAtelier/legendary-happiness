---
id: ANVIL_AUDIT
title: Active Audit Findings
status: active
audience: [developer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [audit, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_DECISIONS, ANVIL_ROADMAP]
owner: project_lead
version: 1.0
gate_scripts: []
code_paths: []
---
