<!--
GENERATED FILE — DO NOT EDIT BY HAND.
Regenerate with: bash scripts/build_index.sh
Last generated: 2026-05-10
-->

# Documentation Index

This file is auto-generated from the frontmatter of every doc in this directory. See [ANVIL_DOC_SYSTEM](ANVIL_DOC_SYSTEM.md) for the schema and how the index is built.

For a CLI agent: this is the entry point. Read this first; then open the most relevant doc by status, audience, and tag.

## Active

Canonical, current. These are the docs you should rely on.

| ID | Title | File | Audience | Tags | Last reviewed | Version |
|----|-------|------|----------|------|---------------|---------|
| `AGENTS` | Agent Instructions | [AGENTS.md](AGENTS.md) | agent, developer | meta, agent, process | 2026-05-10 | 2.0 |
| `ANVIL_ASSETS` | Asset Pipeline, Registry, and Licensing | [ANVIL_ASSETS.md](ANVIL_ASSETS.md) | developer, contributor, designer | assets, process | 2026-05-10 | 1.1 |
| `ANVIL_AUDIT` | Active Audit Findings | [ANVIL_AUDIT.md](ANVIL_AUDIT.md) | developer, agent | audit, process | 2026-05-10 | 1.0 |
| `ANVIL_CONTRIBUTING` | Contributing to Anvil/Forgeborn | [ANVIL_CONTRIBUTING.md](ANVIL_CONTRIBUTING.md) | contributor, developer, agent | meta, process | 2026-05-10 | 1.0 |
| `ANVIL_DECISIONS` | Anvil Design Decisions | [ANVIL_DECISIONS.md](ANVIL_DECISIONS.md) | developer, agent | meta, process | 2026-05-10 | 1.1 |
| `ANVIL_DEMO` | Ashveil Demo Specification | [ANVIL_DEMO.md](ANVIL_DEMO.md) | agent, developer, designer | gameplay, presentation | 2026-05-10 | 2.0 |
| `ANVIL_DEMO_v1` | Ashveil Demo Specification | [archive/ANVIL_DEMO_v1.md](archive/ANVIL_DEMO_v1.md) | developer, designer, agent | gameplay, presentation | 2026-05-10 | 1.1 |
| `ANVIL_DETERMINISM` | Determinism Guarantees and Tests | [ANVIL_DETERMINISM.md](ANVIL_DETERMINISM.md) | developer, agent | determinism, simulation, runtime | 2026-05-10 | 1.0 |
| `ANVIL_DEVELOPER_GUIDE` | Developer Guide | [ANVIL_DEVELOPER_GUIDE.md](ANVIL_DEVELOPER_GUIDE.md) | developer, agent, contributor | meta, process | 2026-05-10 | 1.0 |
| `ANVIL_DOC_SYSTEM` | Documentation System Contract | [ANVIL_DOC_SYSTEM.md](ANVIL_DOC_SYSTEM.md) | developer, agent | meta, constitution, process | 2026-05-10 | 1.0 |
| `ANVIL_ERROR_CODES` | Anvil Error Code Registry | [ANVIL_ERROR_CODES.md](ANVIL_ERROR_CODES.md) | developer, agent | meta, process | 2026-05-10 | 1.0 |
| `ANVIL_GAME_DESIGN` | Forgeborn Game Design | [ANVIL_GAME_DESIGN.md](ANVIL_GAME_DESIGN.md) | developer, designer, contributor | gameplay | 2026-05-10 | 1.1 |
| `ANVIL_MIGRATION_PLAN` | Documentation Migration Plan (May 2026) | [ANVIL_MIGRATION_PLAN.md](ANVIL_MIGRATION_PLAN.md) | developer | meta, process | 2026-05-10 | 1.0 |
| `ANVIL_PHILOSOPHY` | Anvil Project Philosophy (the Constitution) | [ANVIL_PHILOSOPHY.md](ANVIL_PHILOSOPHY.md) | developer, agent, contributor | meta, constitution, process, architecture | 2026-05-10 | 3.0 |
| `ANVIL_ROADMAP` | Roadmap, Sprints, and Registries | [ANVIL_ROADMAP.md](ANVIL_ROADMAP.md) | developer, agent, contributor | meta, process | 2026-05-10 | 1.1 |
| `ANVIL_STATUS` | Project Status (current state and next steps) | [ANVIL_STATUS.md](ANVIL_STATUS.md) | developer, agent, contributor | meta, process | 2026-05-10 | 1.0 |

## Draft

Provisional. The content is real but not yet canonical. Treat as informative, not binding.

| ID | Title | File | Tags | Last reviewed |
|----|-------|------|------|---------------|
| `ANVIL_DEMO_LIMITS` | Demo Fidelity Limits and Walls | [ANVIL_DEMO_LIMITS.md](ANVIL_DEMO_LIMITS.md) | meta, process | 2026-05-10 |

## Archived

Frozen. Reference only — these capture decisions, audits, and design states from earlier in the project.

- [`FORGE_HARVEST_JOURNAL_PART1`](archive/FORGE_HARVEST_JOURNAL_PART1.md) — FORGE HARVEST JOURNAL PART1
- [`FORGE_HARVEST_JOURNAL_PART2`](archive/FORGE_HARVEST_JOURNAL_PART2.md) — FORGE HARVEST JOURNAL PART2

---

## How to use this index

**As a developer:** open by topic. The "active" table has every canonical doc. Tags are searchable; filter on `tag:assets`, `tag:gameplay`, etc.

**As a CLI agent:** read this file first. Filter by `audience: agent`, then by tag relevant to the task. If you cannot find what you need, the answer is *not* to invent — say "the doc set does not cover this" and ask.

**As a contributor:** read `ANVIL_CONTRIBUTING.md`. It links to the docs that govern your work area.

