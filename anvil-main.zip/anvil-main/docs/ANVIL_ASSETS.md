---
id: ANVIL_ASSETS
title: Asset Pipeline, Registry, and Licensing
status: active
audience: [developer, contributor, designer]
last_reviewed: 2026-05-10
supersedes: []
tags: [assets, process]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_DECISIONS, ANVIL_AUDIT, ANVIL_ROADMAP]
owner: project_lead
version: 1.1
gate_scripts: []
code_paths: [assets, crates/anvil_assets, crates/anvil_assets_pipeline]
---

## Summary

Forgeborn ships with CC0 assets only. The pipeline ingests source assets (FBX, OBJ, PNG, OGG), normalises them, validates them, and produces a deterministic asset catalogue used by the deterministic crates. Vendor packs (Unity Asset Store and similar) are usable for development but cannot ship publicly — the licensing chapter (§6) is the binding rule.

This document supersedes the four-file split (pipeline, registry, audit, licensing). Sourcing rules are in §1, directory layout in §2, the seven-stage pipeline in §3, the CC0 registry in §4, open issues in §5-pack rules in §6, contributor workflow in §7.

The single most important rule: **every asset has a row in §4 before it is committed**. The script-level enforcement is on the to-do list (no asset gate today), so for now the discipline is the registry.

---

## 1. Sourcing rules

The rules every asset obeys, in priority order.

### 1.1 CC0 and CC-BY (acceptable). Everything else (not).

For shipping. **CC0 (no attribution required) and CC-BY (attribution required) are both acceptable.** No GPL, no "free for non-commercial use," no Unity Asset Store, no other vendor-pack licences (see §6).

The 2026-05-10 decision (see [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md)) revised this rule. The previous CC0-only restriction was a clean-attribution preference, not a real constraint. The actual constraint is solo-dev money — paid asset packs are unaffordable; free assets that require attribution are fine. Attribution discipline, when CC-BY assets are used:

1. The asset's row in §4 has `attribution_required: true` and a populated `attribution` column with the form the licence requires (typically: author name + asset title + source URL + licence name).
2. The same line is appended to `docs/CREDITS.txt`.
3. The shipping application has a Credits screen reachable from the pause menu that displays the contents of `CREDITS.txt`.
4. Attribution travels with the binary in any redistribution.

CC0 assets continue to be attributed in `CREDITS.txt` as a courtesy (CC0 does not require it; we do it because most CC0 authors appreciate it and because future-us may want to find the source again).

### 1.2 Preferred sources

| Asset type | Preferred CC0 source |
|---|---|
| 3D models | [Kenney.nl](https://kenney.nl), [Quaternius](https://quaternius.com), [Poly Pizza](https://poly.pizza) (CC0 filter), [Poly Haven](https://polyhaven.com) |
| Audio | [Freesound.org](https://freesound.org) (CC0 filter), Pixabay Sound Effects, Mixkit |
| Textures | [AmbientCG](https://ambientcg.com), [Poly Haven](https://polyhaven.com) |
| Fonts | [Google Fonts](https://fonts.google.com) (OFL), [Font Squirrel](https://fontsquirrel.com) (OFL/CC0) |
| Animations | Mixamo (CC0; requires free Adobe account) |

### 1.3 Every asset is registered

Every asset committed to the repository has a row in §4 below with: filename, source URL, licence, attribution-required flag, date acquired, replacement status, and notes. **An asset committed without a registry entry is a bug**, fixed by adding the row in the same PR.

### 1.4 No hot-linking

Assets are committed to the repository. If an asset exceeds 10 MB, it lives in Git LFS — not on a remote server pulled at build time. Determinism requires the build to have all inputs locally.

### 1.5 Attribution

`docs/CREDITS.txt` is the authoritative attribution file. Every asset (CC0 or CC-BY) gets a line: `<filename> — <author> — <source URL> — <licence>`. The file ships alongside the binary. The application has an in-app Credits screen reachable from the pause menu, which displays `CREDITS.txt` content directly. CC-BY assets *require* this; CC0 assets are attributed as courtesy.

### 1.6 Procedural assets

Assets generated at runtime (noise textures, particle sprites, procedural audio if CC0 unavailable) live in memory only. They are not stored under `assets/`. Their generation parameters are documented in the relevant system's module docs and reproducible from the simulation seed.

---

## 2. Directory structure

```
assets/
├── audio/
│   ├── ambient/        # Wind, rain, birds, village hum
│   ├── events/         # Catastrophe sounds, celebration sounds
│   ├── npc/            # Vocalisations (murmurs, work, laughter, weeping)
│   ├── ui/             # Menu sounds, button clicks, transitions
│   └── music/          # Menu music (if any)
├── models/
│   ├── npc/            # Humanoid meshes, rigs, animations
│   ├── structures/     # Buildings, walls, bridges, wells
│   ├── terrain/        # Ground textures, rock meshes
│   └── props/          # Tools, furniture, market stalls, debris
├── textures/
│   ├── terrain/        # Ground, rock, grass, sand, snow
│   ├── structures/     # Wood, stone, thatch
│   └── vfx/            # Particle sprites (smoke, fire, dust, rain)
├── animations/
│   ├── ual1/           # Universal Animation Library 1 (Quaternius CC0)
│   └── ual2/           # Universal Animation Library 2 (Quaternius CC0)
├── fonts/              # CC0 fonts
├── shaders/            # Custom WGSL shaders (project-authored)
├── scenarios/          # Scenario RON/JSON files (project-authored)
├── external/           # Vendor manifest JSON files (build-time inputs)
├── external_normalized/ # Pipeline output: normalised GLB + textures
└── catalogue.json      # The catalogue. Generated; committed.
catalogue_cc0.json      # The CC0-only catalogue. Used when ANVIL_USE_CC0_ASSETS=1
```

**`vendor/`** — separate top-level directory at the repository root. Holds source vendor packs (e.g. `vendor/emberwood/` for the NatureManufacture Forest Environment). **Never shipped.** See §6.

---

## 3. The pipeline

The asset pipeline is implemented in `crates/anvil_assets_pipeline`. It runs at build time, deterministically, and produces the artifacts the simulation reads. Seven stages, each with its own validator and output.

### 3.1 Stage 1 — FBX parse

Parse vendor-supplied FBX files. The parser (`external_fbx.rs`) is hardened against malformed input: explicit version gating, size caps, recursion limits, overflow checks. A fuzz target lives in `anvil_assets/fuzz/fuzz_targets/fbx_parse.rs` and runs on every PR; it has been hammering the parser for months without finding a crash.

Output: raw FBX node tree.

### 3.2 Stage 2 — Pilot

Identify which assets in a vendor pack are candidates for ingestion. Drives off a `*_pilot.json` manifest in `assets/external/`. The pilot stage gates on tag presence (e.g. only assets tagged `tree`, `rock`, `building`); everything else is filtered out.

Output: pilot list.

### 3.3 Stage 3 — Staging

Copy the pilot-list assets into `assets/external_staging/<vendor>/`. Naming is normalised: `<vendor>_<category>_<name>.<ext>`. Driven by `*_staging.json`. This stage is allowed to do simple filename rewriting; nothing semantic.

Output: staged asset directory.

### 3.4 Stage 4 — Eligibility

Validate that each staged asset meets the project's quality bar: triangle count caps, texture size caps, rig compatibility, normal-map presence. Driven by `*_eligibility.json`. An ineligible asset is rejected here (it never makes it into the catalogue). Validation returns `ValidationErrors` per philosophy §2 — multiple problems reported in one pass.

Output: eligibility report. Failed assets logged with codes; passed assets continue.

### 3.5 Stage 5 — Normalisation

Convert FBX → GLB. Rebuild material assignments. Normalise texture references. Generate variant tags (`state_intact`, `state_damaged`, `state_burned`). Output structure mirrors `assets/external_staging/` but renamed `assets/external_normalized/<vendor>/`.

This is where the bulk of the pipeline runtime is spent. Per-asset; cacheable; deterministic given the same inputs.

### 3.6 Stage 6 — Sidecar

Generate per-asset metadata: triangle count, bounding box, material count, archetype tags. Sidecar files live alongside the GLB. Driven by `*_material_sidecar.json` for vendor-specific material remapping.

Output: `<asset>.sidecar.json` per asset.

### 3.7 Stage 7 — Payload

Bundle the normalised GLB + sidecar + texture set into a `Payload` consumed by `anvil_assets`. The payload is the unit the catalogue references. Implemented in `external_texture_payload.rs`.

Output: `assets/external_normalized/<vendor>/<asset>.glb` + textures + `<asset>.sidecar.json`, all referenced from `assets/catalogue.json` by `ArchetypeTag`.

### 3.8 The catalogue

`assets/catalogue.json` is the registry the simulation queries. Each entry has an `ArchetypeTag` (e.g. `building_timber_longhouse`), a payload reference, material variants, and per-variant material parameters. `CatalogueQuery::with_damage(0.30)` returns the right material variant at runtime.

`assets/catalogue_cc0.json` is a parallel catalogue containing only CC0-derived entries. The demo uses it when `ANVIL_USE_CC0_ASSETS=1`. This is what ships publicly.

The catalogue itself is generated; do not hand-edit.

### 3.9 Determinism

Every stage is deterministic given identical inputs. Same FBX + same eligibility rules + same normalisation parameters = byte-identical normalised output. This is verified by a determinism test: two clean runs of the pipeline produce identical hashes.

The pipeline is **build-time**. The deterministic crates never invoke pipeline code; they consume the pre-baked catalogue. No FBX parsing happens at runtime.

---

## 4. CC0 Registry

The authoritative inventory of every CC0 asset in the project. Format: `| filename | source URL | licence | attribution required | date acquired | replacement status | notes |`. Categories below.

**Total CC0 assets:** 52 (21 audio + 22 models + 9 textures). Plus animations and Quaternius packs; details inline.

### 4.1 Audio — Ambient loops

| Filename | Source | Licence | Replaces | Notes |
|---|---|---|---|---|
| `assets/audio/ambient/wind_light.ogg` | Freesound 411089 (InspectorJ) | CC0 1.0 | NM ambient_wind_01 | 30s loop, mono 128kbps |
| `assets/audio/ambient/wind_strong.ogg` | Freesound 411090 (InspectorJ) | CC0 1.0 | NM ambient_wind_02 | 30s loop, mono 128kbps |
| `assets/audio/ambient/rain_light.ogg` | Freesound 411087 (InspectorJ) | CC0 1.0 | NM weather_rain_light | 30s loop, mono 128kbps |
| `assets/audio/ambient/rain_heavy.ogg` | Freesound 411088 (InspectorJ) | CC0 1.0 | NM weather_rain_heavy | 30s loop, mono 128kbps |
| `assets/audio/ambient/birds_dawn.ogg` | Freesound 241996 (acclivity) | CC0 1.0 | NM ambient_birds | Dawn chorus, 30s loop |
| `assets/audio/ambient/birds_general.ogg` | Freesound 241997 (acclivity) | CC0 1.0 | NM ambient_birds_forest | Woodland birds, 30s loop |
| `assets/audio/ambient/village_hum.ogg` | Freesound 411091 (InspectorJ) | CC0 1.0 | NM ambient_village | Distant voices, market murmur |
| `assets/audio/ambient/night.ogg` | Freesound 411092 (InspectorJ) | CC0 1.0 | NM ambient_night | Crickets, owls, 30s loop |
| `assets/audio/ambient/river.ogg` | Freesound 411093 (InspectorJ) | CC0 1.0 | NM ambient_water | River flow, 30s loop |

### 4.2 Audio — Event sounds

| Filename | Source | Licence | Replaces | Notes |
|---|---|---|---|---|
| `assets/audio/events/flood.ogg` | Freesound 411094 | CC0 1.0 | NM catastrophe_flood | Rushing water, debris |
| `assets/audio/events/wildfire.ogg` | Freesound 411095 | CC0 1.0 | NM catastrophe_wildfire | Crackling, roaring |
| `assets/audio/events/earthquake.ogg` | Freesound 411096 | CC0 1.0 | NM catastrophe_earthquake | Low rumble |
| `assets/audio/events/blizzard.ogg` | Freesound 411097 | CC0 1.0 | NM catastrophe_blizzard | Howling wind |
| `assets/audio/events/drought.ogg` | Freesound 411098 | CC0 1.0 | NM catastrophe_drought | Dry wind, cracking earth |
| `assets/audio/events/celebration.ogg` | Freesound 411099 | CC0 1.0 | NM celebration | Crowd cheering, laughter |

### 4.3 Audio — UI

| Filename | Source | Licence | Notes |
|---|---|---|---|
| `assets/audio/ui/hover.ogg` | Freesound 411100 | CC0 1.0 | Subtle tone |
| `assets/audio/ui/click.ogg` | Freesound 411101 | CC0 1.0 | Confirmation |
| `assets/audio/ui/transition.ogg` | Freesound 411102 | CC0 1.0 | Swipe/whoosh |
| `assets/audio/ui/error.ogg` | Freesound 411103 | CC0 1.0 | Negative tone |

### 4.4 3D Models — NPC and structures

| Filename | Source | Licence | Notes |
|---|---|---|---|
| `assets/models/npc/humanoid.glb` | Kenney.nl | CC0 1.0 | Low-poly, 450 tris, rigged |
| `assets/models/structures/house.glb` | Kenney.nl | CC0 1.0 | 300 tris |
| `assets/models/structures/communal.glb` | Kenney.nl | CC0 1.0 | Communal hall, 500 tris |
| `assets/models/structures/well.glb` | Kenney.nl | CC0 1.0 | Stone well, 200 tris |
| `assets/models/structures/bridge.glb` | Kenney.nl | CC0 1.0 | Wooden bridge, 150 tris |
| `assets/models/structures/wall.glb` | Kenney.nl | CC0 1.0 | Wooden wall segment |
| `assets/models/structures/tower.glb` | Kenney.nl | CC0 1.0 | Watchtower, 350 tris |
| `assets/models/structures/granary.glb` | Kenney.nl | CC0 1.0 | Storehouse, 400 tris |

### 4.5 3D Models — Props

| Filename | Source | Licence | Notes |
|---|---|---|---|
| `assets/models/props/hoe.glb` | Kenney.nl | CC0 1.0 | 30 tris |
| `assets/models/props/axe.glb` | Kenney.nl | CC0 1.0 | 30 tris |
| `assets/models/props/hammer.glb` | Kenney.nl | CC0 1.0 | 30 tris |
| `assets/models/props/table.glb` | Kenney.nl | CC0 1.0 | 80 tris |
| `assets/models/props/bench.glb` | Kenney.nl | CC0 1.0 | 60 tris |
| `assets/models/props/bed.glb` | Kenney.nl | CC0 1.0 | 100 tris |
| `assets/models/props/stall.glb` | Kenney.nl | CC0 1.0 | Market stall, 150 tris |
| `assets/models/props/cart.glb` | Kenney.nl | CC0 1.0 | 120 tris |
| `assets/models/props/campfire.glb` | Kenney.nl | CC0 1.0 | Firepit, 100 tris |
| `assets/models/props/debris.glb` | Kenney.nl | CC0 1.0 | Ruined pieces, 50 tris |

### 4.6 Textures

| Filename | Source | Licence | Notes |
|---|---|---|---|
| `assets/textures/terrain/grass.png` | AmbientCG Grass001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/terrain/dirt.png` | AmbientCG Dirt001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/terrain/rock.png` | AmbientCG Rock001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/terrain/sand.png` | AmbientCG Sand001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/terrain/snow.png` | AmbientCG Snow001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/terrain/mud.png` | AmbientCG Mud001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/structures/wood.png` | AmbientCG Wood001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/structures/stone.png` | AmbientCG Stone001 | CC0 1.0 | 2K seamless albedo |
| `assets/textures/structures/thatch.png` | AmbientCG Thatch001 | CC0 1.0 | 2K seamless albedo |

### 4.7 Quaternius packs

The Quaternius packs are CC0 and replace several NM categories at scale. Listed in summary; full per-file inventory archived in `docs/archive/ASSET_REGISTRY_v1.md`.

| Pack | Destination | Status | Replaces |
|---|---|---|---|
| Medieval Village MegaKit | `assets/models/structures/{balconies,corners,door_frames,doors,floors,...}/` | Placeholder pending integration | NM building/structure tags |
| Universal Animation Library 1 | `assets/animations/ual1/` | Placeholder pending integration | NM character animations |
| Universal Animation Library 2 | `assets/animations/ual2/` | Placeholder pending integration | NM character animations |
| Quaternius Textures | `assets/textures/terrain/t_*` | Placeholder pending integration | NM material textures |

For per-file detail (~300 rows), see archive.

---

## 5. Open issues

Active asset findings. Open findings are tracked here; resolved ones flow into [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md).

### 5.1 Critical: missing files referenced by catalogues

The original `ASSET_AUDIT.md` (now archived) found 30+ critical files referenced by `assets/catalogue.json` but missing from disk. These cause demo crashes when the world spawns entities with these meshes. Status: **partial** — the CC0 replacements in §4 cover most missing files; some test-only mesh stubs (e.g. `crates/anvil_demo/assets/meshes/stone.glb`) may still be missing. To verify against current state:

```bash
# Run from repo root.
python3 scripts/check_assets.py --catalogue assets/catalogue.json   # not yet implemented
```

The `scripts/check_assets.py` script is open work (see §5.4).

### 5.2 HIGH-07 — NatureManufacture replacement

[`ANVIL_AUDIT`](ANVIL_AUDIT.md) HIGH-07. The NatureManufacture Forest Environment pack is purchased under the Unity Asset Store EULA and **cannot ship publicly** (see §6 below for the licensing rules). Replacement plan tracked in [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §4.5 Sprint 29.

Migration approach:

| NM category | CC0 replacement source | Status |
|---|---|---|
| Trees (beech) | Quaternius, Poly Haven | Quaternius placeholder shipped; final selection open |
| Ground cover (fern, grass) | Poly Haven, Texture Haven | Same |
| Rocks | Poly Haven, AmbientCG | Same |
| Stumps and logs | Poly Haven | Same |
| Mushrooms | Poly Haven | Same |
| Terrain textures | Texture Haven, Poly Haven | Done (§4.6) |

**Estimated effort:** 3–5 work-days end-to-end:

- 1 day: Source identification and download.
- 1–2 days: Re-run asset pipeline for each category.
- 1 day: Update catalogue.json references.
- 1 day: Test in demo, verify visual consistency.
- 0.5 day: Update §4 of this document.

After migration: remove `vendor/emberwood/` from Git history (§6.4) before any public release tag.

### 5.3 Catalogue references to vendor paths

`assets/catalogue.json` currently references 5 NM-derived mesh entries (highlands_tower_ruined, tower_ruined, highlands_standing_stone, standing_stone, highlands_shrine_weathered). Until §5.2 closes, these references must either:

- Resolve to CC0 equivalents in `catalogue_cc0.json` (the case today when `ANVIL_USE_CC0_ASSETS=1`), or
- Be replaced with CC0 paths in the main catalogue.

The interim solution is the env-var split. The final solution is to have only `catalogue_cc0.json` in the public build.

### 5.4 No asset gate script

There is no automated check that every committed asset has a registry row. **Adding an asset without registering it is currently a contributor-discipline matter, not a CI gate.** A `scripts/check_assets.sh` would walk `assets/`, parse §4 of this document, and fail on unregistered files. Open work; deferred to Phase 4 Infrastructure Sprint (registered as a candidate I-XXX in [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §6 once the project lead approves).

### 5.5 LFS threshold

Some payloads exceed the GitHub 100 MB hard limit. They live in Git LFS. Current LFS size is small (~50 MB) but will grow as more textures and meshes land. When LFS hits 1 GB, evaluate whether to migrate to S3 or similar — but only at that point.

---

## 6. Vendor packs

Vendor packs (Unity Asset Store, paid Blendermarket bundles, etc.) are usable for development but **cannot ship publicly**. The rules below are binding.

### 6.1 The licensing answer

| Question | Answer |
|---|---|
| Can NatureManufacture assets be included in a public Anvil demo build? | **NO.** Unity Asset Store EULA prohibits redistribution outside Unity projects. |
| Can NM assets be used for internal development/testing? | **YES.** Internal use within the developer's machine is fine. |
| Can processed/normalised GLB files derived from NM be distributed? | **NO.** Derived works inherit the source licence. Normalisation does not relicense. |
| Is the Unity Companion License more permissive? | **NO.** Same restriction: Unity-only usage. |

The same logic applies to any vendor pack with similar terms. **A vendor pack is shippable only if its licence explicitly permits redistribution outside the original platform** — vanishingly rare.

### 6.2 Vendor directory rules

`vendor/` is a top-level directory at the repository root. Subdirectories per pack: `vendor/emberwood/` for the NatureManufacture Forest Environment, etc. Rules:

1. **`vendor/` is in `.gitignore` for binary distributions.** It is *not* in `.gitignore` for the source repository today (the project lead decided to keep it tracked during development for reproducibility), but it must be removed before any public release tag.
2. **Catalogue entries that depend on vendor assets are env-var-gated.** `assets/catalogue.json` may reference vendor paths; `assets/catalogue_cc0.json` must not. The demo uses `catalogue_cc0.json` when `ANVIL_USE_CC0_ASSETS=1`.
3. **No vendor path appears in shipping code.** Source attribution comments may mention the vendor (`// SourceVendor: NatureManufacture/ForestEnvironment`), but no `include_str!` or path constant resolves to a vendor file in a release build.

### 6.3 Setting `ANVIL_USE_CC0_ASSETS=1`

```bash
ANVIL_USE_CC0_ASSETS=1 cargo run --release -p anvil_demo
```

When set, the demo loads `catalogue_cc0.json` instead of `catalogue.json`. CC0 assets only. This is the configuration that ships.

### 6.4 Removing vendor history before release

Before any public release tag:

1. Run `git filter-repo` to scrub `vendor/` from history. (`git filter-branch` is deprecated; do not use.)
2. Force-push to a release branch. **Never** force-push main without backup.
3. Verify with `git log --all -- 'vendor/**'` that no vendor paths remain.
4. Re-run `tests/phase3_gate.sh` and the demo end-to-end.
5. Tag the release.

Forge had a leaked vendor pack issue in its past. Anvil's procedure is the answer.

---

## 7. Workflow

How a contributor adds a new asset.

### 7.1 Add a CC0 asset

```bash
# 1. Source the asset from a CC0 site (§1.2).
# 2. Place it under the appropriate assets/ subdirectory (§2).
$ cp ~/Downloads/cool_tree.glb assets/models/structures/cool_tree.glb

# 3. Add a row to §4 of this document.
$ $EDITOR docs/ANVIL_ASSETS.md   # Add row in §4.X
# Filename: full path. Source: URL. Licence: CC0 1.0.
# Replaces: NM-tag if applicable. Notes: tris/dimensions/use.

# 4. If the asset participates in catalogue resolution, add an
#    ArchetypeTag entry to assets/catalogue_cc0.json (and catalogue.json
#    if needed).

# 5. Run the docs gate.
$ ./scripts/check_docs.sh

# 6. Commit.
$ git add assets/models/structures/cool_tree.glb \
          docs/ANVIL_ASSETS.md \
          assets/catalogue_cc0.json
$ git commit -m "assets: add cool_tree.glb (CC0, Kenney)"
```

### 7.2 Replace a vendor asset with CC0

```bash
# 1. Source the CC0 replacement (§1.2).
# 2. Place it at the same path as the vendor asset, OR at a new
#    canonical path, depending on whether the catalogue references the
#    path or the ArchetypeTag.
$ cp ~/Downloads/cc0_tree.glb assets/external_normalized/quaternius/trees/cool_tree.glb

# 3. Update the row in §4 (mark "Replacement: NM tag X").
# 4. Update assets/catalogue_cc0.json to point at the new path.
# 5. If the original vendor asset was in catalogue.json (not just _cc0),
#    update catalogue.json too.
# 6. Run the demo end-to-end with ANVIL_USE_CC0_ASSETS=1 to verify.
$ ANVIL_USE_CC0_ASSETS=1 cargo run --release -p anvil_demo

# 7. Commit. Vendor pack file stays in vendor/ for now (removed before
#    public release per §6.4).
```

### 7.3 Process a vendor pack into the pipeline

(Internal-development workflow only; vendor packs cannot ship.)

```bash
# 1. Place the vendor pack source under vendor/<pack_name>/.
# 2. Author the four pipeline manifest JSON files in assets/external/:
#      <pack>_pilot.json
#      <pack>_staging.json
#      <pack>_eligibility.json
#      <pack>_normalization_batch.json
#      <pack>_material_sidecar.json
# 3. Run the pipeline.
$ cargo run -p anvil_assets_pipeline -- --pack <pack_name>
# 4. Inspect the output under assets/external_normalized/<pack>/.
# 5. Add the new entries to catalogue.json (NOT catalogue_cc0.json — they
#    are not shippable).
# 6. Update §4 of this document with vendor-pack rows (marked "Vendor:
#    not shippable").
```

### 7.4 Remove an asset

```bash
# 1. Verify nothing references it.
$ grep -r "<asset_path>" crates/ assets/

# 2. Delete the file.
$ git rm <asset_path>

# 3. Remove the row from §4 (or move to a "Removed" subsection if
#    historical record is wanted).

# 4. Update catalogue.json / catalogue_cc0.json if needed.

# 5. Commit.
```

---

## 8. Crate ownership

| Crate | Role |
|---|---|
| `anvil_core` | Defines `ArchetypeTag`, `AssetPath`, `Provenance`. The vocabulary every other crate uses. |
| `anvil_assets` | Catalogue type, `CatalogueQuery`, material variants. Reads the catalogue at startup. |
| `anvil_assets_pipeline` | The seven-stage pipeline. Build-time only; not depended on by simulation crates. |
| `anvil_bevy` | Translates `AssetEntry` into Bevy `StandardMaterial` via `AnvilAssetPlugin`. The boundary where the asset system meets the renderer. |

The dependency firewall holds: simulation crates depend on `anvil_assets` for the catalogue type but never on `anvil_assets_pipeline` (which is build-time only). `anvil_bevy` is the only crate that translates assets into renderable form.

---

## Appendix — Archive references

The merged source documents:

- Pipeline operations narrative: `docs/archive/ASSET_PIPELINE_v1.md`
- Full per-file CC0 registry (~300 rows): `docs/archive/ASSET_REGISTRY_v1.md`
- Original missing-files audit (Jan 2026): `docs/archive/ASSET_AUDIT_2026-01.md`
- NatureManufacture licensing audit (May 2026): `docs/archive/ASSET_LICENSING_AUDIT_2026-05.md`

Refer to the archived versions when the summary tables above are not enough — for example, when looking up the per-file audit findings or the original detailed registry rows for Quaternius pack files. The archived versions are frozen; this document is the live one.

Plain-text attribution for shipping: `docs/CREDITS.txt`. Maintained outside the frontmatter system.
