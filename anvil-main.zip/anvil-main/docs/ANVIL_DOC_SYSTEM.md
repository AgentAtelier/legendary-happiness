---
id: ANVIL_DOC_SYSTEM
title: Documentation System Contract
status: active
audience: [developer, agent]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, constitution, process]
related_docs: [AGENTS, ANVIL_PHILOSOPHY]
owner: project_lead
version: 1.0
gate_scripts: [scripts/check_docs.sh, scripts/build_index.sh]
code_paths: []
---
