---
id: ANVIL_PHILOSOPHY
title: Anvil Project Philosophy (the Constitution)
status: active
audience: [developer, agent, contributor]
last_reviewed: 2026-05-10
supersedes: []
tags: [meta, constitution, process, architecture]
related_docs: [AGENTS, ANVIL_DOC_SYSTEM, ANVIL_DECISIONS, ANVIL_ERROR_CODES]
owner: project_lead
version: 3.0
gate_scripts: [scripts/check_firewall.sh, scripts/check_validate_signature.sh, scripts/check_size.sh, scripts/check_error_codes.sh, scripts/check_placeholder_debt.sh]
code_paths: []
---

# Anvil Project Philosophy — v2.2

*The constitution. Every rule has a numeric budget and an enforcement
mechanism. If a mechanism does not exist as real tooling on stable Rust
today, the rule is not enforceable, and an unenforceable rule is a wish.*

**Version history:** v2 → v2.1 (enforcement realism pass) → v2.2
(rationale blocks added under numeric commandments).

---

## The Dependency Firewall (Non-Negotiable)

```
PRESENTATION   anvil_bevy, anvil_streaming, binaries
                    │ consumes
DETERMINISTIC  anvil_runtime, anvil_world, anvil_sim, anvil_ai,
               anvil_physics, anvil_assets, anvil_assets_pipeline,
               anvil_core
                    │ consumes
SEMANTICS      LLMs and human authors (build-time only;
               never invoked at runtime)
```

Authority never moves upward. Presentation cannot invent simulation logic.
Deterministic crates cannot invent semantics. LLMs are an authoring tool,
not a runtime dependency.

---

## The 10 Commandments

Each commandment lists its **enforcement** as a real, named tool. If the
mechanism is "code review only," the commandment says so. There are no
custom dylint plugins. There is no fictional clippy lint.

### 1. The Dependency Firewall is Inviolable

No Bevy, LLM, network, or async runtime dependency in deterministic crates.

**Enforcement:** `scripts/check_firewall.sh`. The script:

```bash
#!/usr/bin/env bash
set -euo pipefail

DETERMINISTIC=(anvil_core anvil_assets anvil_assets_pipeline anvil_world \
               anvil_sim anvil_ai anvil_physics anvil_runtime)
BANNED=(bevy bevy_app bevy_ecs bevy_render bevy_pbr bevy_internal \
        tokio reqwest hyper actix async-std smol \
        openai async-openai langchain-rs candle-core)

for crate in "${DETERMINISTIC[@]}"; do
    if ! cargo metadata --format-version 1 --no-deps -p "$crate" \
         > /dev/null 2>&1; then
        continue   # crate doesn't exist yet; skip
    fi
    deps=$(cargo tree --prefix none --no-dedupe -p "$crate" -e normal,build \
           2>/dev/null | awk '{print $1}' | sort -u)
    for ban in "${BANNED[@]}"; do
        if echo "$deps" | grep -qE "^${ban}$"; then
            echo "FAIL: $crate transitively depends on banned crate $ban"
            exit 1
        fi
    done
done
echo "OK: dependency firewall holds"
```

This works because `cargo tree` resolves the *transitive* graph, which is
what the firewall actually cares about. `cargo-deny` is workspace-scoped and
cannot express "ban X in some crates but not others"; this script can.

**CI step:** run on every push.

### 2. Validate Everything, Multi-Error Always

Every type representing authored data implements `SemanticArtifact` and
exposes:

```rust
fn validate(&self) -> ValidationErrors;
```

No other return type is acceptable. Not `Result<(), E>`, not
`Result<(), Vec<E>>`, not bare `Vec<E>`. Validators collect all errors
before returning. Early returns inside `validate()` are forbidden.

Every error carries: code (`Exxx`-style, registered in `ERROR_CODES.md`),
artifact type, field, invalid value, message, optional hint, source
location.

**Rationale:** The cost of running an authored-content workflow is round-trip
latency between the author (often an LLM, sometimes a human) and the
validator. A `Result<(), E>` validator stops at the first error, which means
an authored region with five problems takes five round trips to fix — each
trip costs an LLM call or a human edit cycle. A multi-error validator
returns all five problems on the first call. Over the lifetime of a project
that compiles thousands of authored artefacts, this difference is hours of
saved time and, more importantly, it preserves the author's mental context:
fixing one problem at a time loses the thread of what the artefact was
supposed to be.

The single-shape rule (`ValidationErrors`, period) exists because Forge had
three string-based validation shapes and consumers reinvented the contract
each time. The cost of consolidation later is much higher than the cost of
enforcing one shape from the start.

**Enforcement:** `scripts/check_validate_signature.sh`. Twelve lines:

```bash
#!/usr/bin/env bash
set -euo pipefail

# Find any fn named validate whose return type is not ValidationErrors.
# False positives on commented-out code are acceptable; reviewer can
# add a one-line ignore.
violations=$(grep -rEn "^\s*(pub )?fn validate\(.*\) ->" \
                crates/*/src --include='*.rs' | \
             grep -v "ValidationErrors" | \
             grep -v "^[^:]*:[0-9]*:\s*//")

if [ -n "$violations" ]; then
    echo "Validators must return ValidationErrors. Offending lines:"
    echo "$violations"
    exit 1
fi
```

**Known false-positive carve-outs:** the trait method
`PipelineManifest::validate(&self) -> Vec<ManifestError<S>>` predates this
rule and is generic over a stage error. The script's allowlist (a header
comment in the script) names this single exception.

### 3. No Production Panics Without a Safety Proof

`unwrap()`, `expect(...)`, `panic!`, `unreachable!`, `todo!` in production
code require a `// SAFETY:` comment **immediately before** the call that
proves the panic cannot fire.

**Rationale:** A panic in production is a crash without a stack-trace
explanation that a player can act on. Every production panic site is one
of three things: (a) a real invariant the type system cannot express, in
which case the proof should be written down so a future reader does not
"clean it up" by removing the unreachable arm; (b) a leftover from
prototyping that should be replaced with proper error handling before
release; (c) a misuse of the API (a builder that requires fields), in which
case the API itself is the bug. The `// SAFETY:` comment forces every panic
to declare which category it belongs to. Category (a) survives review;
categories (b) and (c) get fixed.

The grep-for-`SAFETY` audit catches the regression where a previously
proven panic loses its proof through a refactor — the panic is still there,
the comment got deleted, the audit fails. This is a real failure mode in
Forge: panic-bearing lines were re-indented during a refactor and the
preceding comment was lost.

**Enforcement:** built-in clippy lints, no custom code required.

In every production crate's `lib.rs`:

```rust
#![cfg_attr(not(test), deny(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::unreachable,
    clippy::todo,
))]
```

Each justified panic site uses:

```rust
#[allow(clippy::expect_used)]
// SAFETY: parsed_len was checked >= 4 on line 12; the slice cannot fail to
// convert into [u8; 4].
let n = u32::from_le_bytes(bytes[..4].try_into().expect("…"));
```

The pattern of `#[allow]` + `// SAFETY:` is grep-able for review:

```bash
grep -rn "clippy::expect_used\|clippy::unwrap_used\|clippy::panic" \
     crates/*/src --include='*.rs' | grep -v "// SAFETY:"
```

That grep is the audit, not the gate. The gate is the clippy `deny`.

**CI step:** `cargo clippy --workspace --all-targets -- -D warnings`.

Builders return `Result<T, BuildError>` from `try_build()`. A panicking
`build()` is a deprecated convenience only.

### 4. File and Function Size Budgets

| Unit | Hard limit | Warning |
|------|-----------|---------|
| Production source file | 500 lines | 400 lines |
| Function | 50 lines | 40 lines |
| Crate | 5,000 prod lines | 4,000 |
| Public re-exports per crate | 100 items | 80 |

"Production line" = line outside `#[cfg(test)]`.

**Rationale (file size, 500 lines):** Beyond ~500 lines of production code,
a file becomes difficult to navigate in a standard editor without folding,
takes more than one screenful of git-diff to review in a pull request, and
exceeds the working memory of a developer returning to the code after a
week away. The 500-line threshold was chosen because it is the point at
which every one of those failure modes has been observed in the Forge
codebase. The extreme case — `forge_bevy/src/lib.rs` at **18,991 lines** —
is the failure mode taken to its limit: no one could review a change to
that file with confidence, and no one could return to it after time away
without re-learning the structure. 500 lines is the largest threshold
where every failure mode is still rare; 400 lines is the warning threshold
where they begin to appear occasionally.

**Rationale (function size, 50 lines):** Working-memory studies suggest a
person can hold 7±2 distinct concepts in mind simultaneously. A 50-line
function that does one thing typically corresponds to 5–9 logical steps,
which fits. Empirically, every `validate()` function in `anvil_core` (the
longest is `RegionSpec::validate` at 47 lines) is readable as a single
unit, while functions in the old `anvil_world` monolith that ran past 70
lines required scrolling and lost the reader's place. 50 is the threshold
at which "read it top to bottom without scrolling" remains true on a
1080p monitor at typical font size.

**Rationale (crate size, 5,000 lines):** A crate is a compilation unit; it
is also a unit of conceptual ownership. Past ~5,000 production lines, the
crate stops being one concern. The remedy is to split — but the split is
much cheaper at 5,000 than at 18,991. The threshold gives the team a
forcing function to consider whether a crate is still doing one thing.

**Enforcement:** `scripts/check_size.sh`:

```bash
#!/usr/bin/env bash
set -euo pipefail
HARD=500
WARN=400

bad=0
while IFS= read -r f; do
    test_start=$(awk '/^#\[cfg\(test\)\]/{print NR; exit}' "$f")
    if [ -n "$test_start" ]; then
        prod=$((test_start - 1))
    else
        prod=$(wc -l < "$f")
    fi
    if [ "$prod" -gt "$HARD" ]; then
        echo "FAIL: $f has $prod prod lines (limit $HARD)"
        bad=1
    elif [ "$prod" -gt "$WARN" ]; then
        echo "WARN: $f has $prod prod lines (warning $WARN)"
    fi
done < <(find crates/*/src -name '*.rs')

[ "$bad" -eq 0 ]
```

Function-size enforcement is via `clippy::too_many_lines`:

```rust
#![deny(clippy::too_many_lines)]
```

(Default threshold is 100; override in `clippy.toml`:
`too-many-lines-threshold = 50`.)

There is no automatic enforcement of crate size or re-export count. Both
are review-time checks. **This is honest;** automating them would require a
custom tool that does not exist.

### 5. Use AI as a Tool, Not a Teammate

AI assists, humans decide. Every commit produced primarily by AI carries
the prefix `[ai]` in its message. PRs containing `[ai]` commits require
explicit human-review checkbox before merge.

**Enforcement:**
- `commit-msg` git hook in `.githooks/` that prompts (does not block) when
  changes look AI-shaped (heuristics: large diff, many files, perfectly
  uniform style).
- Pull-request template with mandatory checkbox: *"I have reviewed every
  AI-generated change line by line."*

This is **the only commandment whose primary enforcement is process, not
tooling.** That is honest. There is no automated way to detect AI authorship.

### 6. Document Every Decision

`DECISIONS.md`, `ERROR_CODES.md`, and `ANVIL_PHILOSOPHY.md` are the project
constitution. Every public item in every crate has a doc comment. New error
codes are registered in `ERROR_CODES.md` *before* being used in code.

**Enforcement:**

```rust
#![deny(missing_docs)]
```

in every crate root. Plus `scripts/check_error_codes.sh`:

```bash
#!/usr/bin/env bash
set -euo pipefail
declared=$(grep -oE '"E[0-9]+"' ERROR_CODES.md | sort -u)
used=$(grep -rohE '"E[0-9]+"' crates/*/src --include='*.rs' | sort -u)
missing=$(comm -23 <(echo "$used") <(echo "$declared"))
if [ -n "$missing" ]; then
    echo "Error codes used in code but not registered in ERROR_CODES.md:"
    echo "$missing"
    exit 1
fi
```

**Placeholder ports** — a port‑as‑placeholder file carries a
`// PLACEHOLDER FROM forge_<crate>` header, an entry in
`PLACEHOLDER_DEBT.md` with a review date no later than six
months from the port date, and a review trigger.  An overdue
review date is a sprint‑start blocker, enforced by
`scripts/check_placeholder_debt.sh`.  A placeholder is not a
decision deferred indefinitely; it is a decision whose context
has not yet been provided by the game design document.

### 7. Test at Every Level

Unit tests for every module. Integration tests for every crate. Property
tests for any function with `validate` in its name or any deterministic
compile function. Fuzz tests for any parser of external bytes.
Determinism regression tests: same input compiled twice, bytes diffed.

**Rationale (coverage threshold, 80 %):** 80 % is the industry-observed
threshold at which the remaining uncovered code is typically error-handling
branches and rare edge cases — not core logic. Below 80 %, core paths
routinely slip through unchecked, and bugs that should have been caught by
a unit test reach integration. Above 95 %, the marginal cost of new tests
exceeds their value: the remaining branches are usually unreachable
defensive code or platform-specific arms. 80 % is the inflection point
where the cost-per-prevented-bug curve is flattest. The threshold applies
workspace-wide so a heavily-tested crate can subsidise a less-tested one
*temporarily*; new crates ship at ≥ 80 % from day one to prevent the debt
from accumulating.

The threshold is **statement coverage**, not branch coverage. Branch
coverage at 80 % is a much higher bar and would require disproportionate
effort for marginal value at this stage of the project. Phase 4 (release
prep) may revisit branch coverage if telemetry shows specific subsystems
producing more crashes than expected.

**Enforcement:**

| Layer | Tool | CI command |
|-------|------|------------|
| Unit + integration | `cargo test` | `cargo test --workspace` |
| Coverage threshold | `cargo-llvm-cov` | `cargo llvm-cov --workspace --fail-under-lines 80` |
| Property tests | `proptest` | (collected by `cargo test`) |
| Fuzz | `cargo-fuzz` | nightly job: `cargo fuzz run fbx_parse -- -max_total_time=600` |
| Determinism | inline | dedicated test in each compiler crate that compiles twice and diffs `serde_json::to_vec` output |

Coverage applies to all crates in the workspace.

### 8. Reproducible Builds

`rust-toolchain.toml` pins the exact compiler version. `Cargo.lock` is
committed. Compilation is deterministic: same source + same toolchain →
byte-identical artifacts.

**Currently false in this workspace:** neither file exists. Phase 1, week 1,
deliverable: create both.

**Enforcement:**

```bash
test -f rust-toolchain.toml || { echo "missing rust-toolchain.toml"; exit 1; }
test -f Cargo.lock          || { echo "missing Cargo.lock";          exit 1; }
```

Plus a nightly determinism job:

```bash
cargo build --release
sha256sum target/release/anvil_cli > /tmp/sha1
cargo clean
cargo build --release
sha256sum target/release/anvil_cli > /tmp/sha2
diff /tmp/sha1 /tmp/sha2
```

Note: byte-identical binary builds across machines with the same toolchain
require `--remap-path-prefix` and `SOURCE_DATE_EPOCH`. The nightly job
runs on the same machine, so this is sufficient for our use case.

### 9. Observability

Every error code path emits a structured log line. Every operation expected
to take more than 50 ms emits a span. Every panic — even a justified one —
is captured with full context.

**Enforcement:**

- `tracing` and `tracing-subscriber` are workspace dependencies, listed in
  `[workspace.dependencies]`.
- `clippy::let_underscore_must_use` is `deny`-level (catches discarded
  `Result`s).
- A code-review heuristic: every `Err(...)` variant should appear in a
  `tracing::error!` or `tracing::warn!` call somewhere in its propagation
  chain. **This is review-only.** No tool checks it.

This commandment was overstated in v2 ("a clippy lint flags discarded
errors that don't flow through tracing"). No such lint exists. v2.1
demoted the unenforceable part to review.

### 10. Bounded Slices, No Scope Creep

The demo cap list is sacred. New systems require an explicit philosophy
amendment merged before the first line of code. Decisions are recorded in
`DECISIONS.md` with date and rationale.

**Enforcement:** code review only. No tool can detect scope creep. The
friction is procedural: a doc-only PR must merge before the implementation
PR opens.

---

## Removed in v2

"Close the Feedback Loop" (v1's #7) was removed in v2. v2.1 keeps it
removed and adds a one-line reference: *"feedback-loop telemetry is a
phase-5 roadmap item, not a constitutional commandment."*

---

## Performance Budgets — calibrated

The numbers below are split into three tiers. Provenance is mandatory.

### Measured baselines

**Currently empty.** Phase 0 (week 0 of phase 1) populates this table by
running the criterion suite on a reference machine and committing the
JSON output to `bench/baselines/<commit-hash>.json`.

| Operation | Mean | p99 | Hardware | Date | Commit |
|-----------|------|-----|----------|------|--------|
| *(populated by phase 0)* | — | — | — | — | — |

### Target budgets (depend on baselines)

After phase 0 runs, each measured baseline B becomes a budget of B × 1.10.
A regression > 10 % from the committed baseline fails CI on the dedicated
bench runner.

### Aspirational ceilings (game-feel goals)

These describe end-user experience, not engineering targets. They are
placed here to remind reviewers what the budgets ladder up to.

| Goal | Ceiling | Rationale |
|------|---------|-----------|
| Frame time at 60 fps | 16.6 ms | Steam Deck minimum |
| Frame time at 30 fps | 33.3 ms | Console minimum if pursued |
| Cold compile, full workspace, dev build | 90 s | Developer iteration |
| Cold compile, full workspace, release build | 8 min | CI budget |
| World load → first frame, hot disk | 2 s | Player expectation |

### Regression-detection mechanism

1. `cargo bench --workspace -- --save-baseline current` produces JSON.
2. `scripts/compare_bench.py current bench/baselines/HEAD.json` exits
   non-zero on > 10 % regression in any named operation.
3. The bench runs on a **dedicated bench runner**, not shared CI.
   Shared runners have 2–3× variance and produce false alarms that erode
   trust in the gate.
4. If a dedicated runner is unaffordable, the bench job runs nightly and
   is non-blocking. The team reviews regressions weekly.

This is honest: a small project cannot enforce strict perf gates on shared
hardware, and pretending otherwise produces a flaky CI that the reviewer
learns to ignore.

---

## Core Design Patterns

(unchanged from v2)

- Newtype pattern; validation at construction.
- `#[non_exhaustive]` on every public enum that may grow.
  - **Enforcement:** `clippy::exhaustive_enums` is set to `warn`. New public
    enums need either `#[non_exhaustive]` or an explicit `#[allow]` with
    rationale.
- `Display` on every public enum.
- Builders with `try_build() -> Result<T, BuildError>`.
- Traits for extensibility.
- `Arc` for shared catalogue data.
- Type-state for invariants.

---

## Resolved Contradictions

(unchanged from v2)

- "Functions ≤ 50 lines" vs "no unnecessary indirection": numeric vs
  heuristic, no conflict.
- "Measure before optimizing" vs "optimize the critical path": resolved
  by the Performance Budgets section.

---

## Process Principles

- One prompt, one concern. Vibe prompts must verify with `cargo check`
  before continuing.
- Zero warnings. `#![deny(warnings)]` in every crate root.
- Bounded slices.
- Vibe reviews, we decide.
- Repository is the source of truth. If docs and code disagree, fix the
  docs in the same PR.

---

## Amendment Process

Changes to this document require:

1. A pull request that touches **only** `ANVIL_PHILOSOPHY.md` and
   (optionally) `DECISIONS.md`. PRs that mix philosophy edits with code
   changes are auto-rejected by `scripts/check_philosophy_pr.sh`.
2. A rationale in the PR description naming the rule changed and the
   evidence motivating the change.
3. A self-review pass after at least 24 hours have elapsed since the
   PR was opened. (Solo project: this is the substitute for a second
   reviewer.)
4. CI passing. CI runs `scripts/check_philosophy_shape.sh`, which asserts:
   - Every `### N. <Commandment>` heading is followed within 30 lines by
     a line containing "Enforcement:" or "Enforcement only via review".
   - The Performance Budgets section contains the three named tiers.
   - Removed commandments are listed under "Removed in vX".

This is the only document in the repository whose modification procedure
is specified and gate-checked inside the document itself. That is
intentional.
