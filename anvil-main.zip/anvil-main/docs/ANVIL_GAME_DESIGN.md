---
id: ANVIL_GAME_DESIGN
title: Forgeborn Game Design
status: active
audience: [developer, designer, contributor]
last_reviewed: 2026-05-10
supersedes: []
tags: [gameplay]
related_docs: [ANVIL_PHILOSOPHY, ANVIL_DEMO, ANVIL_DETERMINISM, ANVIL_ROADMAP, ANVIL_DECISIONS]
owner: project_lead
version: 1.1
gate_scripts: []
code_paths: [crates/anvil_sim, crates/anvil_world, crates/anvil_runtime]
---

## Summary

Forgeborn is a single-player game on a hostile continent where the world is the antagonist. Storms, droughts, floods, blights, earthquakes, and the slow turn of seasons shape every life — including the player's. People live here because they were born here, and they survive by working with one another. They find joy because joy is what people do when they survive, and the game is as much about the joy as about the surviving.

The player is one of these people. Not chosen, not prophesied, not exceptional. The player wakes up in this world the same way the neighbours did, lives in it under the same rules, and rejoins it on its own clock if they ever leave.

This document is the canonical Game Design Document. It supersedes the earlier three-file split (`GAME_DESIGN.md` preamble + `_SECTION_3.md` + `_SECTION_4.md`). Vocabulary throughout matches the implemented types in `crates/anvil_sim`: `Substrate`, `EmotionalState`, `EmotionalAxes`, `Settlement`, `Person`, `CatastropheEvent`, `CatalystEvent`. Where the design specifies behaviour the code does not yet exhibit, the section is marked `[planned]` and links to a [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) entry.

---

## 1. Vision and pillars

### 1.1 What Forgeborn is

A single-player game about inhabiting a world rather than conquering it. The continent is hostile, the seasons are real, the people are not waiting for a hero. The player is an inhabitant — born here, no different from the neighbours in what they can do or what threatens them.

The default tone is austere: quiet weather, sparse dialogue, work that takes time. Against this default, moments of warmth land hard. A shared meal indoors while sleet hits the window. A song one elder starts and the rest of the room slowly joins. These are not breaks in the tone — they are the reason the tone exists.

### 1.2 What Forgeborn is not

No chosen one. No prophecy. No XP bar. No quest log. Combat exists but is calibrated *underneath* environmental threat, not parallel to it; a well-equipped player can fight off raiders, but the same player caught unprepared by a flood will drown.

These omissions are the consequence of placing the player among the inhabitants instead of above them. They are not stylistic.

### 1.3 The two pillars

Every design decision answers to one of two pillars. A proposed mechanic that serves neither is cut.

**Pillar I — The world is the principal threat.** A bandit ambush is dangerous; a blizzard arriving at dusk while the player is two hours from shelter is more dangerous; a wildfire in a dry valley is more dangerous still. The hierarchy is preserved by **composition, not segregation**: environmental threats do not pause when combat begins. Fighting in a storm is fighting *and* being battered by the storm. Combat does not become a refuge from the environment because the environment refuses to step out of the room.

**Pillar II — People cope, and people find joy.** Inhabitants do not exist to give quests. They live: they store food before winter, repair roofs after storms, mourn the dead, raise the young, gossip, drink, sing, throw festivals when the harvest comes in. Joy is not decoration. It is the rational human response to a hard world, and it is shown with the same care as the hardship.

### 1.4 The seven principles

The operating consequences of the two pillars. Every later section is measured against these.

1. **The player is an inhabitant, not a hero.** No prophecy, no unique abilities, no reputation that precedes them. NPCs grow, age, and acquire skills on the same clock as the player.
2. **Progression is diegetic.** The player gets better at things by doing them, learning from those who already know, and using better tools. There is no XP bar, no level-up. Growth shows in gameplay: a steadier aim, a recognised face, a roof that no longer leaks. The same rule applies to NPCs.
3. **Quests emerge from the world, not from a list.** A neighbour mentions her son has not come back from the high pasture. A merchant offers a reward for salt before the river freezes. A landslide reveals an unknown ore vein. None of these appear in a quest log.
4. **Combat is dangerous, rare, and never central.** Engaging a group of opponents without preparation is usually fatal.
5. **Catastrophes are predictable in kind, unpredictable in timing.** The player learns over a season that this region floods, that valley burns, those mountains avalanche. What they cannot predict is *when*.
6. **The continent has variable density.** Some regions are richly simulated; others are wilderness. Travel matters; everywhere is not the same.
7. **Joy is an event, not a texture.** Villagers do not sing in the background to set a mood. A song breaks out because a child has been born, because a missing caravan has come home, because the storm has passed. Without the hardness, the joy would be sentimental; without the joy, the hardness would be bleak.

### 1.5 The player and time

Death and reload are gamified — the player can save and load. What is *not* gamified is the world. The simulation runs on its own clock; that clock does not stop when the player saves, dies, or reloads. A player who loads a save from three game-days ago does not rewind the world; the world has continued for those three days, and the player rejoins it mid-stride.

This is not punishment for dying. It is the mechanical expression of Pillar I: the principal threat does not pause for any one person. A neighbour who needed help three days ago has either found it, given up, or buried her son. A storm has either passed or struck. The player who reloads is not the player who left — they have lost three days of standing.

A corollary opens design space rather than closing it: **time is a resource of the game**. A rare and difficult skill — learnable, like all skills, by practice and mentorship — runs the player's clock backward, undoing some of the world's drift. This is not magic in the heroic sense; it is one diegetic skill among many. Time costs are felt by everyone, and the only way to recover lost time is to learn how. Detailed mechanics are deferred to [planned] (see §7).

---

## 2. The world

### 2.1 The continent

A landmass with variable density. Settled valleys with named NPCs and festivals. Wilderness with a scattering of travellers. Travel is meaningful: distances are large, terrain is real, the climate shifts with latitude and altitude. The map is not infinite, but it is large enough that no single player traverses it all in one playthrough.

Authoring of the continent is deterministic (see §6). Each region is described in a `WorldAuthored` artifact compiled by `anvil_world`. `ArchetypeTag` validates content references. `Region`, `Connection`, and `Landmark` are the structural primitives.

### 2.2 Catastrophe types

Seven types are implemented. Each has **one dominant consequence**. The player who learns the type can predict what will be hit hardest.

| Type | Dominant consequence | Tempo | Implemented in |
|---|---|---|---|
| Flood | Resource loss (food stores washed away) | Sudden | `crates/anvil_sim/src/catastrophe/event.rs` |
| Earthquake | Structural damage (walls collapse, roads split) | Sudden | same |
| Wildfire | Displacement (the village may be erased) | Fast spread | same |
| Blizzard | Deaths by exposure (cold kills those caught outside) | Hours | same |
| Drought | Slow resource depletion (the rate, not the store) | Weeks | same |
| Landslide | Sudden localised deaths | Instant, contained | same |
| Blight | Crop and animal disease (insidious, demoralising) | Slow | same |

**Composition.** Catastrophes do not exist in isolation. A drought that depletes food reserves creates a village physically weakened *and* emotionally fragile. If a wildfire then sweeps through, it must evacuate with no stores. The system does not calculate composition explicitly — it emerges from state. If `food_store` is low when the fire hits, post-fire recovery is slower because coping requires food and there is none. Sequence matters as much as severity.

**Precursor signals.** Each catastrophe type has signs that get louder as the event approaches. Three channels of warning:

1. **Environmental signs** — the world itself changes (sky darkens, river rises, soil cracks).
2. **Animal behaviour** — animals react before people do (birds leave, livestock crowd together).
3. **NPC knowledge** — the most valuable channel. An elder who has lived through three droughts recognises signs a newcomer does not.

The third channel is **gated by social integration**. A stranger overhears nothing. A trusted player is warned directly. Information as a consequence of relationship.

`PrecursorSignal` is implemented; perceptibility per NPC is computed via the `Perceptibility` system in `crates/anvil_sim/src/skill/perceptibility.rs`, gated by `AffordanceId` unlocks within each `SkillDomain`.

### 2.3 Time and weather

Time of day is a continuous scalar 0.0–1.0. For Sprint 17, four static blocks (Dawn, Day, Dusk, Night, plus the catch-all Anytime) modulate action utility — code in `crates/anvil_sim/src/actions.rs::TimeBlock`. Sigmoid curves [planned] in Sprint 18 will produce smooth transitions.

Weather is a live `WeatherSimulation` field in `anvil_runtime/src/weather.rs`, ticked every frame and forwarded into `SimContext.world.weather` before each sim tick. The fields the catastrophe system reads — `temperature`, `humidity`, `wind_speed`, `pressure`, `accumulated_precipitation` — are the same fields the renderer reads for fog density and lighting. There is one source of truth.

---

## 3. The people

Every NPC — and the player — is driven by a three-layer architecture that replaces traditional behaviour trees and utility functions. The layers operate on different timescales and are implemented in `crates/anvil_sim/src/soul.rs`.

### 3.1 Layer 1 — The Substrate

Who the NPC *is*. Three axes, each a continuous value from -1.0 to +1.0. Changes only under extraordinary circumstances; for all practical purposes during normal gameplay, the substrate is fixed.

| Axis | Direction (-1 → +1) | Example behavioural consequence |
|---|---|---|
| `courage_fear` | fearful → courageous | Stays vs. flees in danger; volunteers for scouting; threshold for fight-or-flight |
| `generosity_selfishness` | selfish → generous | Shares food when stores are low; helps neighbours before securing own needs |
| `stability_anxiety` | anxious → stable | Absorbs vs. amplifies shocks; recovers faster after catastrophe; anchors others |

Neither pole is "better." A courageous NPC dies in situations the fearful one survives. A selfish NPC survives famines that the generous do not. An anxious NPC notices precursor signals first because hypervigilance is a survival skill paid for personally.

**Implementation:** `Substrate { courage_fear, generosity_selfishness, stability_anxiety }`. Three `f32`s per NPC. Initial values come from a seeded distribution per settlement (some villages are braver; some are more anxious because they live in earthquake country and anxiety has been selected for).

**[planned] Cicatrices** (Sprint 18+). Permanent substrate deformations from extreme experiences. An NPC who nearly drowned shifts measurably toward Fear. An NPC betrayed by a friend shifts toward Selfishness. Rare, triggered only by extreme events; the mechanism by which the game's history writes itself onto its people.

### 3.2 Layer 2 — The Emotional State

What the NPC *feels right now*. Implemented as a four-axis state in `crates/anvil_sim/src/soul/axes.rs::EmotionalAxes`, since Sprint 18c.

| Axis | What it filters |
|---|---|
| `security_threat` | Environmental evaluation (a threatened NPC perceives danger more strongly) |
| `belonging_isolation` | Social evaluation (an isolated NPC reads neutral interactions as cold) |
| `agency_helplessness` | Action availability (a helpless NPC perceives fewer options) |
| `satiation_desperation` | Resource evaluation (a desperate NPC's internal estimate of food is biased downward) |

**The critical mechanic is not the state, it is what the state does to perception.** An NPC at low security/threat does not neutrally evaluate the world and then decide pessimistically — the negative state *filters what they perceive*. They estimate scarcity as more severe than it is, hoard, panic, possibly steal — not because they decided to be selfish, but because they *see* less food than there is.

The substrate determines how *strongly* mood affects perception (a stable NPC's perception is less distorted than an anxious NPC's); the emotional state determines the *direction* of distortion. The bridge between Layer 1 and Layer 3.

### 3.3 Layer 3 — The Action Surface

What the NPC *does*. The only layer that produces visible behaviour.

The long-term vision is a **tension field** model where each NPC exists in a field of competing forces — hunger pulling toward food, fear pushing away from threats, loyalty creating gravity toward specific people. The Sprint 17 implementation is a utility-AI that respects the architecture without yet implementing the full tension field. Each NPC evaluates a catalogue of possible actions, each scored as:

```
score = base_urgency(need)
      × time_block_multiplier(action, current_time)
      × skill_modifier(npc, action)
      × perception_filter(npc.emotional_state, action.primary_need)
      × substrate_weight(npc.substrate, action)
      × coping_modifier(settlement.damage, action.coping_type)
      × cooperation_modifier(settlement.aggregate_mood, action.communal_benefit)
```

The NPC selects the highest-scoring action and executes it. Re-evaluation runs every 30 ticks staggered by NPC ID modulo 30 — at any tick, only 1/30 of the population is evaluating. Implementation in `crates/anvil_sim/src/utility/scoring.rs`.

The tension field is the destination. Utility-AI is the first step. Every step is playable: Sprint 17's implementation is a complete game, not a stub. **Constraint:** no Sprint-17 decision should *close* a path toward the tension field model.

### 3.4 Needs and actions

Seven needs drive all NPC behaviour. Six can be satisfied by actions. One — Joy — cannot.

| Need | Decay | Depleted by | Satisfied by |
|---|---|---|---|
| Food | Moderate | Time, exertion | Eating |
| Water | Moderate-fast | Time, heat, exertion | Drinking |
| Shelter | Slow (unless exposed) | Weather, structural damage | Being in an intact building |
| Safety | Context-dependent | Active threats, precursor signals, low village mood | Distance from threat, group, indoors |
| Sleep | Slow | Time awake | Sleeping |
| Companionship | Slow | Time alone | Conversation, communal activity |
| **Joy** | Very slow | Time | **No action satisfies this — only `CatalystEvent` (§4.2)** |

Joy's special status is Principle 7 made mechanical. The Joy need exists; NPCs feel its absence as low-grade dissatisfaction. But no action in the catalogue has Joy as primary output. A village that survives but never celebrates is functional but bleak — not a bug; a load-bearing constraint enforced at the system level.

**The action catalogue.** Approximately 21 actions are implemented in `crates/anvil_sim/src/actions/catalogue.rs`. Each carries metadata: primary need served, age category (child/adult/elder/all), communal benefit flag, spatial vs. minor, coping type, resource effect, time-block preference. Highlights:

- **Food:** Farm/Tend, Hunt, Gather, Fish, Cook/Prepare, Share Food.
- **Water:** Fetch Water.
- **Shelter:** Build/Repair, Seek Shelter.
- **Safety:** Secure/Reinforce, Warn Others, Lookout/Observe, Flee.
- **Sleep:** Sleep, Rest.
- **Companionship:** Gather Socially, Tell Story, Mourn, Small Act of Normality.
- **Desperate (extreme need only):** Steal, Scavenge/Salvage.

### 3.5 Skills

Seven domains, each with a hierarchy of `AffordanceId`s unlocked by practice and observation. From `crates/anvil_sim/src/skill/domain.rs`:

`Woodcraft`, `Stonework`, `Husbandry`, `Pathfinding`, `Foraging`, `WeatherSense`, `SocialWeaving`.

Fluency within a domain (Halting → Awkward → Smooth → Competent → Expert) is computed from unlocked affordances in that domain. Fluency drives:

- **Skill modifier** in the utility score above (an Expert farmer's farm action is more productive).
- **Perceptibility** of relevant precursor signals (an NPC with `WeatherSense::fire_sign_recognition` perceives smoke at a threshold others miss).
- **Visible motion quality** (an Expert's animations differ from an Awkward's; the same animation graph plays back at different fluency weights).

Practice happens by performing skill-gated actions. Observation happens when an NPC with sufficient `belonging` watches a more skilled NPC perform a relevant action — implemented in `crates/anvil_sim/src/system/npc/observation.rs`. Both routes generate observation credits; enough credits unlock a new affordance.

This is **Principle 2 in code**: the player learns by doing or watching, identically to NPCs. There is no XP path that exists only for the player.

### 3.6 Age and life stage

Age is a continuous scalar; AgeCategory (Child / Adult / Elder) is derived. From `crates/anvil_sim/src/age.rs`. Continuous age curves [planned] for Sprint 18 will replace the three-category step function with smooth capability transitions.

- **Children** (age < 15) have a filtered action set: no heavy physical work; can observe, play, fetch water, gather, attend gatherings. Economically dependent. Their primary contribution is social — children improve connected adults' mood through Layer 1 (family) contagion.
- **Adults** are the default. Full action set.
- **Elders** (age > 60) have reduced physical capability but enhanced social influence. Lower farming and construction skill modifiers; higher storytelling, warning, and mentoring utilities. Their high connection count amplifies their network influence: a calm elder stabilises the village, a frightened elder destabilises it.

### 3.7 Memory

Every NPC remembers personal events ("I lost my mother in the flood"), village events ("the year the river took the bridge"), and player actions ("you brought food when we had nothing"). Memories decay slowly; recent ones are vivid, old ones vague but present. An elder's memories span decades; a child's span years.

When an elder dies, their memories are not inherited — they are *lost*. A village that loses its elders loses its history.

Memories surface in two ways: in dialogue, and in behaviour. An NPC whose mother died in a flood is more anxious when rain begins. An NPC who survived a blizzard hoards firewood. These are not scripted — the utility system weights "prepare for [remembered disaster type]" higher when the memory exists.

---

## 4. Settlement systems

### 4.1 The emotional network

The heart of the settlement simulation. Every named NPC is a node, every relationship is an edge, mood flows between connected people the way heat flows through metal.

**Three layers of connection** define edge strength:

1. **Family** — parents, children, siblings, partners. 2–7 connections per NPC. Strongest contagion.
2. **Proximity** — co-workers, neighbours, daily routine. 3–12 connections, determined by where they live and what they do.
3. **Village** — everyone else. Cumulative but individually weak.

A family member who is also a co-worker exerts influence through both layers simultaneously. Total influence on any NPC is the weighted sum of connected emotional states.

**Weighted nodes.** Influence is *emergent from the graph*, not from a title mechanic. An NPC with 30 connections has more influence than one with 5. An NPC whose connections are themselves well-connected has disproportionate reach. The system produces leaders, healers, and anchors without naming them — the social graph *is* the governance.

When a high-connection NPC dies, the network destabilises: their stabilising pull vanishes, the village's aggregate mood drops not only from the loss but from losing the buffer. Compound, fully emergent.

**Contextual asymmetry.** Contagion rate depends on aggregate state:

- **After catastrophe** (aggregate mood < -0.3): negative contagion is amplified, positive is dampened. Fear spreads faster than comfort. A downward spiral the village must actively resist through coping.
- **Normal times** (-0.3 to +0.3): symmetric.
- **Good times** (> +0.3): positive amplified, negative dampened. Joy is infectious.

This asymmetry is what makes the system feel *human* rather than mathematical. In real communities, fear spreads faster than hope after a disaster, and laughter is more contagious at a party than in a hospital.

### 4.2 Coping and joy

**Coping** is what happens between the blow and the recovery — the central visible activity of the settlement simulation. Two kinds, both emergent from the action catalogue:

- **Material coping**: repairing structures, salvaging resources, tending the injured, securing against the next threat. Pushes physical metrics back toward viability.
- **Emotional coping**: gathering, mourning, storytelling, small acts of normality. Pushes mood back toward neutral. **Begins only when basic material needs are secured** — a village that is hungry does not tell stories, it survives.

**The player's role in coping.** The player influences individuals, not the village. They can bring materials (accelerating one person's recovery), sit with the grieving (a presence in the proximity layer), or be known (multi-layer influence built over previous visits). A stranger who brings timber is appreciated. A known friend who brings timber *and* sits with the family *and* attends the evening gathering exerts influence across all three layers.

The player cannot fix a village. The player can help the people in it fix themselves, a little faster, by being present and useful.

**Joy** is the rarest and most important output. Pillar II made manifest. Implemented as `CatalystEvent` in `crates/anvil_sim/src/system/joy.rs`. Two simultaneous conditions trigger it:

1. **Sufficient collective mood** — a critical mass (~60–70%) of the settlement's NPCs have individual mood above +0.3.
2. **A trigger event** — Birth, Harvest, Return (someone presumed lost comes back), Construction complete, Season turn.

If condition 1 is met but no trigger fires, the village is content but does not celebrate. If a trigger occurs but condition 1 is not met, the event is noted but produces no celebration — a birth in a starving village is not a feast, it is another mouth to feed. Joy remains an *event* rather than a *texture*: it requires both soil (collective mood) and seed (trigger).

Each `CatalystEvent` carries an optional `linked_history` field pointing at the catastrophe it answers. This is the **memory narrative** that prevents repetition: a feast after a flood is not the same as a feast after an earthquake. The storyteller mentions the water, toasts the fields that survived, remembers who was lost. Without the link, every feast is generic; with it, every feast is the end of a specific chapter.

The `magnitude` of a celebration scales with contrast — depth of the valley equals height of the relief. A village that recovered from -0.6 to +0.4 produces a *larger* celebration than one that recovered from -0.1 to +0.4. Emergent; no special tuning.

**A celebration is not a cutscene.** It is an emergent behavioural state in which NPCs shift utility priorities: gathering intensifies, food is shared, music plays, stories are told, then rest. Mood returns to a stable positive baseline (~+0.2). Lasts naturally until daily priorities reassert.

### 4.3 The economy

Four resource pools per settlement. Communal — they belong to the village, not individuals. Player and every NPC draw from and contribute to the same pools.

| Pool | Range | At zero |
|---|---|---|
| Food | 0.0–1.0 (normalised to settlement size) | Starvation begins; NPC behaviour fractures along the substrate (generous ration; selfish hoard; fearful flee; courageous range further at risk). |
| Water | 0.0–1.0 | Dehydration. Faster than starvation (2–3 game-days to incapacitation); Fetch Water dominates all other actions. |
| Materials | 0.0–1.0 (timber/stone/cloth/tools aggregated) | Construction and repair halt; damage cannot be restored; vulnerability accumulates. |
| Structural Integrity | 0.0–1.0 (across all settlement structures) | NPCs exposed to weather; temperature-related deaths; the settlement may be functionally abandoned. |

**Production rates are derived, never stored.** No `food_production_rate` field persists. Each tick: number of NPCs farming × their skill × environmental modifiers (season, weather, soil) = food produced this tick. This is what makes drought and flood feel different. A flood hits the *store* (food washes away) while production capacity remains intact — the village can regrow. A drought hits the *rate* (nothing grows) while existing stores remain — the village slowly starves unless it changes strategy.

**Performance**: production is computed only for NPCs currently performing production actions. NPCs doing other things contribute zero. O(producing-NPCs), not O(total-population).

**The player and the economy.** The player is subject to the same four pools. There is no "Take Food" button. Access is social, not mechanical:

1. **Social access** — known to the village (Layer 1 or 2 connections), receives a share. Stranger receives nothing.
2. **Taking** — physically take from stores without permission. The game does not prevent it. NPCs *notice*. Over-taking depletes the pool and triggers reactions through emotional and social systems — colder interactions, less sharing, less warning about approaching threats.
3. **Independent production** — hunt, gather, fish, craft alone. Resources outside the communal pool. Can be given (adds to pool, builds connection) or kept (neutral, the village does not know).

**No numbers are shown.** The player reads resource state through expression: market stalls thin out, NPCs mention food more often in conversation, the baker's output decreases, communal meals shrink visibly. During scarcity, NPCs argue about shares, children cry, mood darkens, specific NPCs hoard visibly. Debug tools may expose numbers; the game never does.

### 4.4 Target selection

Many actions require a target. The same social graph that drives contagion drives target selection.

1. **Family first** (Layer 1) — always eligible regardless of aggregate mood. A mother feeds her child before her neighbour.
2. **Proximity second** (Layer 2) — eligible when the cooperation modifier is above a threshold. In a healthy village, easily met. In a starving low-mood village, the threshold rises and NPCs become more selective.
3. **Village third** (Layer 3) — eligible only in good times or moments of collective purpose.

Within a layer, the target is chosen by need: Share Food → hungriest connected NPC; Heal → most injured; Build/Repair → most damaged structure (no social layer); Warn Others → connected NPC with lowest Safety satisfaction; Gather Socially → largest existing group of connected NPCs.

**The player is treated identically.** A node in the social graph. Family priority if Layer 1 connections exist. Proximity if Layer 2. Stranger if Layer 3 only — receives nothing unless the village is in a generous state, and desperate NPCs may target the player for theft.

This is Principle 1 at its most concrete: **the player receives help because they are socially integrated, not because they are the player**.

Implementation: `crates/anvil_sim/src/targeting.rs`. Performance-bounded — iterates over the NPC's connections (3–30 edges), not the entire population.

---

## 5. Gameplay

### 5.1 The normal day

When no catastrophe is active and resources are stable, NPCs live a daily rhythm. This is the *baseline* against which crisis, coping, and joy are measured. If the baseline is flat, crises feel scripted. If the baseline is alive, crises feel like disruptions to real lives.

A morning in a healthy village: doors open at dawn. Adults walk toward the fields, the well, the workshop. Movement is purposeful but unhurried. By midday, the pace shifts — some still work, others gather at the well or market. Children run past. The baker pulls bread from an oven. At dusk, the village contracts; smoke rises from chimneys, families eat together. At night, silence and a few lights.

A normal day in an unhealthy village — after a catastrophe, with low food — has the same time structure, but different actions. Fewer farmers (the fields are damaged), more NPCs at the ruins of buildings (repair), fewer children running (subdued). The market is thin. Conversations are quieter, shorter.

A bigger village is busier: 15 people at their best are quiet; 150 at midday hum. Emergent — the system does not script "busy" vs. "quiet"; the difference comes from the number of actors in the same space.

### 5.2 Precursor interrupts

When precursor signals begin, the normal day distorts gradually — not a hard switch, a shift in utility weights.

Environmental signs appear (sky darkens, river rises). NPCs with relevant memory notice first; their anxiety rises. Through Layer 2/3 contagion, the unease propagates. An elder begins a Warn Others action. Children on lookout report animal behaviour through family connections. Material-preparation actions (stockpiling, securing structures, gathering water) gain utility. The village rhythm changes — fewer farmers, more builders, more people carrying supplies.

The player sees the shift before understanding its cause, if they are paying attention. No scripted "enter preparation mode" event fires.

### 5.3 The death-and-time model

When the player dies and reloads (§1.5), the world has continued. Concretely:

- The simulation has been ticking. Catastrophes have fired or not. NPC actions have completed. Skills have advanced. Births and deaths may have occurred.
- The save file contains `Runtime` state, world hash, RNG state, tick count, full system snapshots [planned for sims beyond physics — see [`ANVIL_AUDIT`](ANVIL_AUDIT.md) CRIT-04]. On load, the runtime restores to the saved tick.
- The "lost time" between save and load is felt by the player as social cost: relationships have decayed, opportunities have passed, the merchant who was waiting for salt has moved on.

The time-recovery skill [planned] reverses some of this drift for a personal cost. It is not magic in the heroic sense; one diegetic skill among many, learnable from a teacher.

### 5.4 The threat-composition rule

Combat is calibrated *underneath* environmental threat (Pillar I). Concretely: every combat encounter inherits the environmental state at the moment it begins.

- Fighting in a storm: degraded weapon condition, reduced visibility, increased injury risk, footing lost on wet ground.
- Fighting during a wildfire: smoke damage to lungs, falling embers, escape routes blocked.
- Fighting in a blizzard: cold-related stamina drain, frostbite on exposed limbs.

A well-equipped player who would beat a bandit in clear weather is not the same player in a downpour. This rule is what keeps Pillar I intact when the player gets stronger: combat does not become a refuge from the environment, because the environment refuses to step out of the room.

[planned] Combat itself — its specific mechanics, weapons, and AI — is open work. See §7.

### 5.5 Performance architecture: Social LOD

The continent has variable density (Principle 6). The same principle applies *within* a settlement.

| Tier | Where | Cost |
|---|---|---|
| **Tier 1** | NPCs within the player's perception range | Full evaluation every 30 ticks staggered. Full contagion. Spatial actions. Visual/auditory expression. |
| **Tier 2** | Same settlement, outside perception range | 1/10 the rate. Settlement-level aggregate contagion. Actions resolved abstractly. |
| **Tier 3** | Settlements the player has not visited recently | Statistical model. No individual evaluation. |

Tier transitions are handled by the streaming system (`anvil_streaming`). When the player approaches a Tier-3 settlement, it "unfolds" into individuals — each NPC's mood, needs, and current action are derived from the aggregate such that the sum of individuals matches what the aggregate was generating. The village does not "pop" into existence; it was always there, and the player is seeing it in detail for the first time.

A continent with 50 settlements averaging 80 NPCs (~4,000 NPCs) costs roughly: 200 Tier-1 + 300 Tier-2 + 3,500 Tier-3. The effective per-tick cost is ~7 full evaluations + ~3 simplified evaluations + ~0.5 aggregate calculations. **Constraint**: Social LOD is infrastructure, not a compromise — it mirrors human social perception. Not an optimisation hack to be removed when hardware improves.

### 5.6 The first hour and substrate definition

The player has a Substrate, like any NPC. Three axes, the same as everyone. Not a character creation screen with sliders.

**For the Ashveil demo specifically** (see [`ANVIL_DEMO`](ANVIL_DEMO.md) and the 2026-05-10 entry in [`ANVIL_DECISIONS`](ANVIL_DECISIONS.md)), the substrate is **seeded from the world seed**: random across seeds, deterministic per seed, persistent across saves and loads. The viewer is the ninth villager in Ashveil and inherits a substrate they did not choose. The substrate is never displayed — no UI, no endgame reveal, no debug menu in the shipping build. The viewer learns who they are by living in the body: by noticing the hand tremor when they stop sprinting, by noticing how easily fear surfaces, by noticing whether NPCs are drawn to them or wary. *Two viewers playing the same seed inhabit the same body and learn it differently. Two viewers playing different seeds become different selves.*

**For the eventual game**, the substrate emerges from a *short sequence of choices* during the first hour — situations that force the player to act, and the actions define the axes. Approach the stranger or avoid them? (Courage.) Share your last food or keep it? (Generosity.) Stay calm when the sky darkens or seek shelter immediately? (Stability.) The choice-driven model is the design destination; the seed-driven model in the demo is the simpler implementation that delivers the same load-bearing claim — *who you are emerges through living, not through a menu*.

In both modes, the axes are never shown as numbers. NPCs perceive the player through their substrate: a courageous player is treated differently by a fearful NPC than a fearful player is. The substrate influences which NPCs are drawn to the player, which avoid them, and what kind of village the player fits into best.

---

## 6. Authoring

### 6.1 Deterministic compilation

Game content — regions, NPCs, settlements, named events — is compiled deterministically from authored source. The pipeline:

1. Designer (or LLM-assisted authoring) produces a plan (`*.plan` files, JSON-shaped).
2. `anvil_assembly::compile_plan` walks the plan, resolves `ArchetypeTag` references against `AssetCatalogue`, generates terrain meshes, places NPCs, validates.
3. Output is a `WorldAuthored` artifact: the deterministic world state at game start.
4. Same plan + same toolchain = byte-identical `WorldAuthored`. Verified by determinism gate.

This means the same game world can be reconstructed from the same plan years later, on different hardware, identical to the original. Critical for replays, automated tests, and shipping.

### 6.2 The semantic firewall

Forgeborn uses LLM assistance for authoring. The dependency firewall (`scripts/check_firewall.sh`, philosophy §1) ensures **no LLM code reaches a deterministic crate**. Authoring happens at build time, in tools that produce semantic data; the simulation crates consume that data and never invoke an LLM.

This separation is what makes the simulation deterministic at all. An LLM is non-deterministic by nature; a simulation that called one would lose every guarantee in [`ANVIL_DETERMINISM`](ANVIL_DETERMINISM.md). The build-time/run-time split is sacred.

### 6.3 Validation contract

Every authored content type has a `validate()` returning [`ValidationErrors`](ANVIL_PHILOSOPHY.md#2-multi-error-validation), collecting all problems in one pass. A designer who submits a broken plan gets every error in one report, not the first one.

Concretely (from `anvil_world` and `anvil_assets`): `WorldAuthored::validate()` checks region uniqueness, person ID uniqueness, family references, mood ranges, archetype tag resolution, structural coherence — across roughly 47 invariants. The Ashveil demo currently passes 47/47.

### 6.4 The build-time LLM loop

The author writes a description of an NPC family. The LLM produces a structured plan: substrate values, skill profiles, memories, family connections. The plan validates. If validation fails, the errors are returned to the LLM as structured feedback (codes + fields + hints), and the LLM iterates. When validation passes, the plan is committed. The simulation never sees the LLM.

This loop turns the LLM into a designer's productivity multiplier without compromising determinism. The LLM is constrained by the validator: any content it produces that violates an invariant is rejected with structured feedback, so the LLM learns the rules of the game world over a session and produces increasingly clean output.

---

## 7. Open questions

This document covers the simulation systems that are designed, implemented, or partially implemented. The following remain open:

- **Combat mechanics.** Pillar I is established; combat is calibrated under environmental threat; the threat-composition rule is explicit. The combat system itself — weapons, AI, encounter tuning, integration with skill domains — is unwritten. A future GDD section will define it. Tracked in [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md) §"Future design work."
- **Continental economy.** Trade between settlements: how resources move across the continent, how merchant routes form, how regional shortages and surpluses propagate. The local economy (§4.3) is implemented; the inter-settlement layer is not.
- **Save metadata and world drift.** §1.5 defines the policy (the world continues during save/load), but the mechanics of what specifically drifts (weather, NPC ages, sprint progression) and how the player perceives the gap on reload need definition. Linked to [`ANVIL_AUDIT`](ANVIL_AUDIT.md) CRIT-04 (full sim snapshot).
- **The continuous-lives mechanic.** When the player dies and is "replaced," the rules for who steps in and how the social graph reattaches need explicit design. The system today supports player-as-NPC; the *transfer* on death is unwritten.
- **The time-recovery skill.** Mechanics from §1.5 / §5.3.
- **Specific biome designs.** The continent's geography — which regions flood, which burn, which quake — is conceptual but not enumerated. The catastrophe system supports any biome; the world authoring needs concrete regional definitions.
- **First-hour player experience.** §5.6 sketches the substrate-defining beats but does not specify the encounters. A first-hour design pass is open work.

These are tracked as design entries in [`ANVIL_ROADMAP`](ANVIL_ROADMAP.md). Each becomes a future GDD section, written one at a time, measured against the seven principles and the system constraints established here.

---

## Appendix — Vocabulary alignment

Terms used in this document map 1:1 to types in `crates/anvil_sim`:

| GDD term | Code type | Location |
|---|---|---|
| Substrate | `Substrate` | `soul.rs` |
| Emotional State | `EmotionalState` (wraps `EmotionalAxes`) | `soul.rs`, `soul/axes.rs` |
| Need | `Need` (enum) | `needs.rs` |
| Action | `Action` | `actions/catalogue.rs` |
| Skill domain | `SkillDomain` (enum) | `skill/domain.rs` |
| Affordance | `AffordanceId` | `skill/affordance.rs` |
| Catastrophe | `CatastropheEvent`, `PrecursorSignal` | `catastrophe/event.rs`, `catastrophe/signal.rs` |
| Joy event | `CatalystEvent` | `system/joy.rs` |
| Settlement | `Settlement` | `settlement/` |
| Person | `Person` | `settlement/person.rs` |

Earlier doc versions used "soul" and "the layered soul" as interchangeable with "substrate"; this version drops the dual term. The architecture is still the layered soul; Layer 1 of it is the Substrate, and "Substrate" is what the code calls it.
