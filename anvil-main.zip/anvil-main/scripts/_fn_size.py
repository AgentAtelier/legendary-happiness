#!/usr/bin/env python3
"""Report production functions over a size threshold."""
import re, sys
from pathlib import Path

def find_long_fns(path, threshold):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
    except Exception: return []
    in_cfg_test = False
    cfg_test_depth = -1
    depth = 0
    fn_stack = []
    out = []
    fn_re = re.compile(r'\s*(?:pub(?:\([^)]*\))? )?(?:async )?(?:unsafe )?(?:const )?fn\s+(\w+)')
    for i, line in enumerate(lines, 1):
        s = line.strip()
        if '#[cfg(test)]' in s:
            in_cfg_test = True; cfg_test_depth = depth
        m = fn_re.match(line)
        if m and not in_cfg_test and '{' in line:
            fn_stack.append((i, depth, m.group(1)))
        prev = depth
        for ch in line:
            if ch == '{': depth += 1
            elif ch == '}':
                depth -= 1
                if fn_stack and depth <= fn_stack[-1][1]:
                    s_, _, n = fn_stack.pop()
                    if i - s_ + 1 > threshold:
                        out.append((str(path), n, s_, i, i - s_ + 1))
        if in_cfg_test and depth <= cfg_test_depth and prev > depth:
            in_cfg_test = False; cfg_test_depth = -1
    return out

def main():
    threshold = int(sys.argv[1]) if len(sys.argv) > 1 else 50
    rows = []
    for crate in sorted(Path('crates').iterdir()):
        if not crate.is_dir(): continue
        for f in crate.rglob('*.rs'):
            if 'target' in f.parts or 'tests' in f.parts: continue
            rows.extend(find_long_fns(f, threshold))
    rows.sort(key=lambda r: -r[4])
    print(f"Functions > {threshold} prod lines: {len(rows)}\n")
    print(f"{'Lines':>6}  {'Function':<40}  File")
    print('-' * 100)
    for path, name, s, e, l in rows[:50]:
        print(f"{l:>6}  {name:<40}  {path}:{s}")

if __name__ == '__main__':
    main()
