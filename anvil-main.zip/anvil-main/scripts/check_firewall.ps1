#!/usr/bin/env pwsh
# PowerShell version of the firewall check script for Windows
# Checks that deterministic crates don't depend on banned crates

$ErrorActionPreference = "Stop"

$DETERMINISTIC = @("anvil_core", "anvil_assets", "anvil_assets_pipeline", "anvil_world", "anvil_sim", "anvil_ai", "anvil_physics", "anvil_runtime")
$BANNED = @("bevy", "bevy_app", "bevy_ecs", "bevy_render", "bevy_pbr", "bevy_internal", \
            "tokio", "reqwest", "hyper", "actix", "async-std", "smol", \
            "openai", "async-openai", "langchain-rs", "candle-core")

$bad = 0

foreach ($crate in $DETERMINISTIC) {
    # Check if the crate exists in the workspace
    try {
        $metadataResult = cargo metadata --format-version 1 --no-deps -p $crate 2>$null
        if (-not $metadataResult) {
            Write-Host "SKIP: $crate does not exist in workspace"
            continue
        }
    } catch {
        Write-Host "SKIP: $crate does not exist in workspace"
        continue
    }
    
    # Get dependencies for this crate using cargo tree
    try {
        $treeOutput = cargo tree --prefix none --no-dedupe -p $crate -e normal,build 2>$null
        if (-not $treeOutput) {
            Write-Host "WARNING: Could not get dependencies for $crate"
            continue
        }
        
        # Parse the tree output - each line has the package name as the first word
        $deps = $treeOutput -split "`n" | ForEach-Object { 
            $line = $_.Trim()
            if ($line -ne "") {
                ($line -split "\s+")[0]
            }
        } | Select-Object -Unique
        
        foreach ($ban in $BANNED) {
            if ($deps -contains $ban) {
                Write-Host "FAIL: $crate transitively depends on banned crate $ban"
                $bad = 1
            }
        }
    } catch {
        Write-Host "WARNING: Error checking dependencies for $crate : $_"
    }
}

if ($bad -ne 0) {
    Write-Host "FIREWALL BREACH: deterministic crates depend on forbidden crates"
    exit 1
}

Write-Host "OK: dependency firewall holds"
