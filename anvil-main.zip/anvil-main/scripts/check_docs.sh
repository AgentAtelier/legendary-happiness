#!/usr/bin/env bash
#
# scripts/check_docs.sh — Documentation drift detector.
#
# This script verifies the doc set conforms to the contract specified in
# docs/ANVIL_DOC_SYSTEM.md. It is the CI gate. Exit 0 if the doc set is
# clean, exit 1 if drift is detected.
#
# Run from repo root:
#   bash scripts/check_docs.sh
#
# Required tools: bash, python3, find, grep, awk.
#
# The Python helper (parse_frontmatter.py) is generated inline and uses only
# the standard library; no pip install needed.

set -euo pipefail

# Locate repo root (assumes script is run from repo root or its location).
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DOCS_DIR="${REPO_ROOT}/docs"

if [ ! -d "${DOCS_DIR}" ]; then
    echo "FAIL: docs/ directory not found at ${DOCS_DIR}"
    exit 1
fi

# ---------------------------------------------------------------------------
# Python helper: parse YAML frontmatter from a markdown file.
# ---------------------------------------------------------------------------
PARSER_PY=$(mktemp /tmp/parse_frontmatter.XXXXXX.py)
trap "rm -f '${PARSER_PY}'" EXIT

cat > "${PARSER_PY}" << 'PYEOF'
"""Parse YAML frontmatter from a single markdown file.

Output one line per field: KEY=VALUE (lists as comma-separated).
Exits 1 if frontmatter is missing or malformed.
"""
import sys
import re

REQUIRED = {"id", "title", "status", "audience", "last_reviewed",
            "supersedes", "tags", "related_docs", "owner", "version",
            "gate_scripts", "code_paths"}
VALID_STATUS = {"draft", "active", "archived", "deprecated"}
VALID_AUDIENCE = {"developer", "agent", "designer", "contributor", "external"}
VALID_TAGS = {"meta", "constitution", "process", "architecture", "gameplay",
              "determinism", "assets", "audit", "historical", "agent",
              "runtime", "simulation", "world", "presentation"}

def fail(msg):
    print(f"FAIL ({sys.argv[1]}): {msg}", file=sys.stderr)
    sys.exit(1)

def parse_value(s):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return []
        return [x.strip() for x in inner.split(",")]
    return s

def main():
    path = sys.argv[1]
    with open(path) as f:
        text = f.read()

    if not text.startswith("---\n"):
        fail("missing frontmatter (file must start with `---`)")

    parts = text.split("---\n", 2)
    if len(parts) < 3:
        fail("malformed frontmatter (must be enclosed in `---` lines)")

    fm = parts[1]
    fields = {}
    for line in fm.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            fail(f"malformed line: '{line}'")
        key, value = line.split(":", 1)
        fields[key.strip()] = parse_value(value)

    missing = REQUIRED - set(fields.keys())
    if missing:
        fail(f"missing required fields: {sorted(missing)}")

    if fields["status"] not in VALID_STATUS:
        fail(f"invalid status '{fields['status']}' (must be one of {sorted(VALID_STATUS)})")

    audience = fields["audience"] if isinstance(fields["audience"], list) else [fields["audience"]]
    for a in audience:
        if a not in VALID_AUDIENCE:
            fail(f"invalid audience entry '{a}' (must be from {sorted(VALID_AUDIENCE)})")

    tags = fields["tags"] if isinstance(fields["tags"], list) else [fields["tags"]]
    for t in tags:
        if t and t not in VALID_TAGS:
            fail(f"invalid tag '{t}' (must be from {sorted(VALID_TAGS)})")

    # Date format check.
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(fields["last_reviewed"])):
        fail(f"last_reviewed not in ISO date format: '{fields['last_reviewed']}'")

    # Print machine-readable output for the bash caller.
    for key in REQUIRED:
        v = fields[key]
        if isinstance(v, list):
            print(f"{key}={','.join(v)}")
        else:
            print(f"{key}={v}")

if __name__ == "__main__":
    main()
PYEOF

# ---------------------------------------------------------------------------
# Walk all .md files under docs/, parse frontmatter, collect ids and metadata.
# ---------------------------------------------------------------------------

declare -A IDS_SEEN          # id -> filepath
declare -A FILE_FIELDS       # filepath -> raw frontmatter fields (newline-joined)
declare -A FILE_RELATED      # filepath -> related_docs csv
declare -A FILE_SUPERSEDES   # filepath -> supersedes csv
declare -A FILE_STATUS       # filepath -> status
declare -A FILE_LAST_REV     # filepath -> last_reviewed date
declare -A FILE_GATES        # filepath -> gate_scripts csv
declare -A FILE_PATHS        # filepath -> code_paths csv

ALL_IDS=""
ANY_FAIL=0

# Find all .md files. Skip INDEX.md (it's generated) and CREDITS.txt.
mapfile -t MD_FILES < <(find "${DOCS_DIR}" -type f -name '*.md' ! -name 'INDEX.md' | sort)

if [ "${#MD_FILES[@]}" -eq 0 ]; then
    echo "FAIL: no .md files found under ${DOCS_DIR}"
    exit 1
fi

for f in "${MD_FILES[@]}"; do
    if ! parsed=$(python3 "${PARSER_PY}" "$f" 2>&1); then
        echo "$parsed"
        ANY_FAIL=1
        continue
    fi
    # Extract fields.
    while IFS='=' read -r key value; do
        case "$key" in
            id) FILE_ID="$value" ;;
            status) FILE_STATUS["$f"]="$value" ;;
            last_reviewed) FILE_LAST_REV["$f"]="$value" ;;
            related_docs) FILE_RELATED["$f"]="$value" ;;
            supersedes) FILE_SUPERSEDES["$f"]="$value" ;;
            gate_scripts) FILE_GATES["$f"]="$value" ;;
            code_paths) FILE_PATHS["$f"]="$value" ;;
        esac
    done <<< "$parsed"

    # Uniqueness of id.
    if [ -n "${IDS_SEEN[$FILE_ID]:-}" ]; then
        echo "FAIL: id '${FILE_ID}' appears in both ${IDS_SEEN[$FILE_ID]} and $f"
        ANY_FAIL=1
    else
        IDS_SEEN[$FILE_ID]="$f"
        ALL_IDS="${ALL_IDS} ${FILE_ID}"
    fi
done

# ---------------------------------------------------------------------------
# Cross-reference integrity: every id mentioned in related_docs or supersedes
# must resolve to a known id.
# ---------------------------------------------------------------------------

check_id_list() {
    local file="$1" field_name="$2" csv="$3"
    if [ -z "$csv" ]; then return; fi
    IFS=',' read -ra refs <<< "$csv"
    for ref in "${refs[@]}"; do
        ref=$(echo "$ref" | xargs)  # trim
        if [ -z "$ref" ]; then continue; fi
        if [ -z "${IDS_SEEN[$ref]:-}" ]; then
            echo "FAIL: $file references unknown id '$ref' in $field_name"
            ANY_FAIL=1
        fi
    done
}

for f in "${!FILE_RELATED[@]}"; do
    check_id_list "$f" "related_docs" "${FILE_RELATED[$f]}"
done

for f in "${!FILE_SUPERSEDES[@]}"; do
    check_id_list "$f" "supersedes" "${FILE_SUPERSEDES[$f]}"
done

# ---------------------------------------------------------------------------
# last_reviewed not in the future.
# ---------------------------------------------------------------------------

TODAY=$(date +%Y-%m-%d)
for f in "${!FILE_LAST_REV[@]}"; do
    rev="${FILE_LAST_REV[$f]}"
    if [[ "$rev" > "$TODAY" ]]; then
        echo "FAIL: $f has last_reviewed in the future: $rev (today: $TODAY)"
        ANY_FAIL=1
    fi
done

# ---------------------------------------------------------------------------
# Active docs older than 180 days (warn) or 365 (fail).
# ---------------------------------------------------------------------------

if command -v date >/dev/null 2>&1; then
    THRESHOLD_WARN=$(date -d "180 days ago" +%Y-%m-%d 2>/dev/null || date -v-180d +%Y-%m-%d 2>/dev/null || echo "")
    THRESHOLD_FAIL=$(date -d "365 days ago" +%Y-%m-%d 2>/dev/null || date -v-365d +%Y-%m-%d 2>/dev/null || echo "")

    if [ -n "$THRESHOLD_WARN" ]; then
        for f in "${!FILE_STATUS[@]}"; do
            if [ "${FILE_STATUS[$f]}" = "active" ]; then
                rev="${FILE_LAST_REV[$f]}"
                if [[ "$rev" < "$THRESHOLD_FAIL" ]]; then
                    echo "FAIL: $f is active but last_reviewed is older than 365 days: $rev"
                    ANY_FAIL=1
                elif [[ "$rev" < "$THRESHOLD_WARN" ]]; then
                    echo "WARN: $f is active but last_reviewed is older than 180 days: $rev"
                fi
            fi
        done
    fi
fi

# ---------------------------------------------------------------------------
# gate_scripts: every listed script must exist and be executable.
# ---------------------------------------------------------------------------

for f in "${!FILE_GATES[@]}"; do
    csv="${FILE_GATES[$f]}"
    if [ -z "$csv" ]; then continue; fi
    IFS=',' read -ra scripts <<< "$csv"
    for s in "${scripts[@]}"; do
        s=$(echo "$s" | xargs)
        if [ -z "$s" ]; then continue; fi
        path="${REPO_ROOT}/$s"
        if [ ! -f "$path" ]; then
            echo "FAIL: $f lists gate_script '$s' but file does not exist"
            ANY_FAIL=1
        fi
    done
done

# ---------------------------------------------------------------------------
# code_paths: every listed path must exist.
# ---------------------------------------------------------------------------

for f in "${!FILE_PATHS[@]}"; do
    csv="${FILE_PATHS[$f]}"
    if [ -z "$csv" ]; then continue; fi
    IFS=',' read -ra paths <<< "$csv"
    for p in "${paths[@]}"; do
        p=$(echo "$p" | xargs)
        if [ -z "$p" ]; then continue; fi
        full="${REPO_ROOT}/$p"
        if [ ! -e "$full" ]; then
            echo "FAIL: $f lists code_path '$p' but it does not exist"
            ANY_FAIL=1
        fi
    done
done

# ---------------------------------------------------------------------------
# sessions/ — files older than 30 days warn, older than 90 fail.
# ---------------------------------------------------------------------------

SESSIONS_DIR="${DOCS_DIR}/sessions"
if [ -d "$SESSIONS_DIR" ]; then
    while IFS= read -r f; do
        # Get file mtime as days-ago.
        if command -v stat >/dev/null 2>&1; then
            mtime_epoch=$(stat -c %Y "$f" 2>/dev/null || stat -f %m "$f" 2>/dev/null || echo 0)
            now_epoch=$(date +%s)
            days_old=$(( (now_epoch - mtime_epoch) / 86400 ))
            if [ "$days_old" -gt 90 ]; then
                echo "FAIL: $f in sessions/ is $days_old days old (limit 90)"
                ANY_FAIL=1
            elif [ "$days_old" -gt 30 ]; then
                echo "WARN: $f in sessions/ is $days_old days old (limit 30 for warn)"
            fi
        fi
    done < <(find "$SESSIONS_DIR" -type f -name '*.md')
fi

# ---------------------------------------------------------------------------
# INDEX.md sync: regenerate to /tmp and diff.
# ---------------------------------------------------------------------------

INDEX_FILE="${DOCS_DIR}/INDEX.md"
if [ ! -f "$INDEX_FILE" ]; then
    echo "FAIL: docs/INDEX.md does not exist (run scripts/build_index.sh)"
    ANY_FAIL=1
else
    TMP_INDEX=$(mktemp /tmp/INDEX.XXXXXX.md)
    if bash "${REPO_ROOT}/scripts/build_index.sh" --output "$TMP_INDEX" >/dev/null 2>&1; then
        if ! diff -q "$INDEX_FILE" "$TMP_INDEX" >/dev/null 2>&1; then
            echo "FAIL: docs/INDEX.md is out of date — run scripts/build_index.sh"
            ANY_FAIL=1
        fi
    fi
    rm -f "$TMP_INDEX"
fi

# ---------------------------------------------------------------------------
# Final result.
# ---------------------------------------------------------------------------

if [ "$ANY_FAIL" -eq 0 ]; then
    echo "OK: documentation set is clean (${#MD_FILES[@]} docs checked)"
    exit 0
else
    echo
    echo "Documentation drift detected. See messages above."
    echo "See docs/ANVIL_DOC_SYSTEM.md for the contract."
    exit 1
fi
