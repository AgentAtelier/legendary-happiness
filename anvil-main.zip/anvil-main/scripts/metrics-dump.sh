#!/usr/bin/env bash
set -euo pipefail

OUT="${1:-metrics-dump-$(date +%Y%m%d-%H%M).txt}"
exec > "$OUT"

echo "=== Anvil Project Metrics Dump ==="
echo "Date: $(date)"
echo "Commit: $(git rev-parse --short HEAD 2>/dev/null || echo unknown)"
echo

echo "=== Lines of Code per Crate ==="
for c in crates/*/; do
  n=$(basename "$c")
  prod=$(find "$c/src" -name '*.rs' 2>/dev/null \
    | xargs awk '/^#\[cfg\(test\)\]/{exit} {n=NR} END{print n+0}' 2>/dev/null \
    | awk '{s+=$1} END{print s}')
  echo "$n: ${prod:-0} lines"
done | sort -t: -k2 -n -r

echo
echo "=== Production Panic-Shaped Calls (excluding cfg(test)) ==="
python3 scripts/_panic_audit.py

echo
echo "=== File Size Violations (>500 prod lines) ==="
violations=0
for f in $(find crates/*/src -name '*.rs' -not -path '*/tests/*'); do
  prod=$(awk '/^#\[cfg\(test\)\]/{exit} {n=NR} END{print n+0}' "$f")
  if [ "$prod" -gt 500 ]; then
    echo "$prod $f"
    violations=$((violations+1))
  fi
done | sort -rn
echo "(total: $violations)"

echo
echo "=== Function Size Violations (>50 prod lines) ==="
python3 scripts/_fn_size.py 50

echo
echo "=== TODO/FIXME/HACK/XXX ==="
count=$(grep -rn "TODO\|FIXME\|HACK\|XXX" crates/*/src --include='*.rs' \
  | grep -v "//.*//" | wc -l)
echo "Marker count: $count"
echo "(see metrics-dump-todos.txt for details)"
grep -rn "TODO\|FIXME\|HACK\|XXX" crates/*/src --include='*.rs' \
  > metrics-dump-todos.txt 2>/dev/null || true

echo
echo "=== Self-Check ==="
for section in "Lines of Code" "Production Panic" "File Size" "Function Size" "TODO"; do
  if ! grep -q "$section" "$OUT"; then
    echo "FAIL: section '$section' missing from dump"
    exit 1
  fi
done
echo "OK: dump is non-empty in every section"
