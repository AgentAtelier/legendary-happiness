#!/usr/bin/env bash
#
# scripts/build_index.sh — Generate docs/INDEX.md from frontmatter.
#
# Walks every .md file under docs/ (excluding INDEX.md), parses YAML
# frontmatter, and writes a structured INDEX.md sorted by status.
#
# Usage:
#   bash scripts/build_index.sh                  # writes docs/INDEX.md
#   bash scripts/build_index.sh --output PATH    # writes to PATH instead
#
# Used by scripts/check_docs.sh to verify INDEX is in sync.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DOCS_DIR="${REPO_ROOT}/docs"
OUTPUT="${DOCS_DIR}/INDEX.md"

# Parse --output flag.
if [ "${1:-}" = "--output" ] && [ -n "${2:-}" ]; then
    OUTPUT="$2"
fi

if [ ! -d "${DOCS_DIR}" ]; then
    echo "FAIL: docs/ directory not found"
    exit 1
fi

# ---------------------------------------------------------------------------
# Python helper: read frontmatter + first H1 from a file, output as TSV.
# ---------------------------------------------------------------------------
PARSER_PY=$(mktemp /tmp/index_parse.XXXXXX.py)
trap "rm -f '${PARSER_PY}'" EXIT

cat > "${PARSER_PY}" << 'PYEOF'
import sys
import re
import os

def parse_value(s):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        if not inner:
            return ""
        return ", ".join(x.strip() for x in inner.split(","))
    return s

def main():
    docs_dir = sys.argv[1]
    rows = []
    for root, _, files in os.walk(docs_dir):
        for name in files:
            if not name.endswith(".md") or name == "INDEX.md":
                continue
            path = os.path.join(root, name)
            rel = os.path.relpath(path, docs_dir)
            try:
                with open(path) as f:
                    text = f.read()
            except Exception as e:
                print(f"# error reading {path}: {e}", file=sys.stderr)
                continue
            if not text.startswith("---\n"):
                continue
            parts = text.split("---\n", 2)
            if len(parts) < 3:
                continue
            fm = parts[1]
            fields = {}
            for line in fm.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or ":" not in line:
                    continue
                k, v = line.split(":", 1)
                fields[k.strip()] = parse_value(v)

            req = ["id", "title", "status", "audience", "tags",
                   "last_reviewed", "version", "owner"]
            if not all(k in fields for k in req):
                continue

            row = "\t".join([
                fields.get("status", ""),
                fields.get("id", ""),
                fields.get("title", ""),
                rel,
                fields.get("audience", ""),
                fields.get("tags", ""),
                fields.get("last_reviewed", ""),
                fields.get("version", ""),
                fields.get("owner", ""),
            ])
            rows.append(row)

    # Status sort order: active, draft, deprecated, archived.
    status_order = {"active": 0, "draft": 1, "deprecated": 2, "archived": 3}
    rows.sort(key=lambda r: (status_order.get(r.split("\t")[0], 9), r.split("\t")[1]))

    for r in rows:
        print(r)

if __name__ == "__main__":
    main()
PYEOF

ROWS=$(python3 "${PARSER_PY}" "${DOCS_DIR}")

# ---------------------------------------------------------------------------
# Generate INDEX.md.
# ---------------------------------------------------------------------------

GEN_DATE=$(date +%Y-%m-%d)

{
cat << EOF
<!--
GENERATED FILE — DO NOT EDIT BY HAND.
Regenerate with: bash scripts/build_index.sh
Last generated: ${GEN_DATE}
-->

# Documentation Index

This file is auto-generated from the frontmatter of every doc in this directory. See [ANVIL_DOC_SYSTEM](ANVIL_DOC_SYSTEM.md) for the schema and how the index is built.

For a CLI agent: this is the entry point. Read this first; then open the most relevant doc by status, audience, and tag.

EOF

# ---- Active docs ----
echo "## Active"
echo
echo "Canonical, current. These are the docs you should rely on."
echo
echo "| ID | Title | File | Audience | Tags | Last reviewed | Version |"
echo "|----|-------|------|----------|------|---------------|---------|"
echo "$ROWS" | while IFS=$'\t' read -r status id title rel audience tags lastrev version owner; do
    if [ "$status" = "active" ]; then
        echo "| \`$id\` | $title | [$rel]($rel) | $audience | $tags | $lastrev | $version |"
    fi
done

# ---- Draft docs ----
draft_count=$(echo "$ROWS" | awk -F'\t' '$1 == "draft"' | wc -l)
if [ "$draft_count" -gt 0 ]; then
    echo
    echo "## Draft"
    echo
    echo "Provisional. The content is real but not yet canonical. Treat as informative, not binding."
    echo
    echo "| ID | Title | File | Tags | Last reviewed |"
    echo "|----|-------|------|------|---------------|"
    echo "$ROWS" | while IFS=$'\t' read -r status id title rel audience tags lastrev version owner; do
        if [ "$status" = "draft" ]; then
            echo "| \`$id\` | $title | [$rel]($rel) | $tags | $lastrev |"
        fi
    done
fi

# ---- Deprecated docs ----
dep_count=$(echo "$ROWS" | awk -F'\t' '$1 == "deprecated"' | wc -l)
if [ "$dep_count" -gt 0 ]; then
    echo
    echo "## Deprecated"
    echo
    echo "Replacement pending. Read for context only. Resolves to active or archived within 90 days of deprecation date."
    echo
    echo "| ID | Title | File | Last reviewed |"
    echo "|----|-------|------|---------------|"
    echo "$ROWS" | while IFS=$'\t' read -r status id title rel audience tags lastrev version owner; do
        if [ "$status" = "deprecated" ]; then
            echo "| \`$id\` | $title | [$rel]($rel) | $lastrev |"
        fi
    done
fi

# ---- Archived docs (compact list) ----
arch_count=$(echo "$ROWS" | awk -F'\t' '$1 == "archived"' | wc -l)
if [ "$arch_count" -gt 0 ]; then
    echo
    echo "## Archived"
    echo
    echo "Frozen. Reference only — these capture decisions, audits, and design states from earlier in the project."
    echo
    echo "$ROWS" | while IFS=$'\t' read -r status id title rel audience tags lastrev version owner; do
        if [ "$status" = "archived" ]; then
            echo "- [\`$id\`]($rel) — $title"
        fi
    done
fi

cat << EOF

---

## How to use this index

**As a developer:** open by topic. The "active" table has every canonical doc. Tags are searchable; filter on \`tag:assets\`, \`tag:gameplay\`, etc.

**As a CLI agent:** read this file first. Filter by \`audience: agent\`, then by tag relevant to the task. If you cannot find what you need, the answer is *not* to invent — say "the doc set does not cover this" and ask.

**As a contributor:** read \`ANVIL_CONTRIBUTING.md\`. It links to the docs that govern your work area.

EOF

} > "${OUTPUT}"

echo "Wrote ${OUTPUT}"
