#!/usr/bin/env bash
set -euo pipefail

# check_error_codes.sh
# Verifies that all error codes used in the codebase are registered in ERROR_CODES.md

# Get all error codes declared in ERROR_CODES.md (E000-E999)
# Match lines starting with | E### | and extract the code
declared=$(grep -oE '\| E[0-9]{3} \|' ERROR_CODES.md | tr -d ' |' | sort -u)

# Get all error codes used in Rust source files as string literals ("E000")
# Exclude test modules by filtering out files in tests/ directories
# Extract just the E### code from the match
used=$(find crates/*/src -name '*.rs' -type f ! -path '*/tests/*' -exec grep -hoE '"E[0-9]{3}"' {} \; 2>/dev/null | tr -d '"' | sort -u)

# Find codes used in code but not declared in ERROR_CODES.md
missing=$(comm -23 <(echo "$used") <(echo "$declared"))

if [ -n "$missing" ]; then
    echo "FAIL: Error codes used in code but not registered in ERROR_CODES.md:"
    echo "$missing"
    exit 1
fi

# Find codes declared in ERROR_CODES.md but not used in code
unused=$(comm -23 <(echo "$declared") <(echo "$used"))

if [ -n "$unused" ]; then
    echo "WARN: Error codes declared in ERROR_CODES.md but not used in code:"
    echo "$unused"
fi

echo "OK: All error codes are registered in ERROR_CODES.md"
