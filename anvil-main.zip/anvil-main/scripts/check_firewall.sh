#!/usr/bin/env bash
# Cross-platform firewall check script
# Checks that deterministic crates don't depend on banned crates

set -euo pipefail

# Check if we're on Windows (where bash might not be available)
# GitHub Actions Windows runners have bash via Git Bash
# If this fails, the caller should use the PowerShell version

DETERMINISTIC=(anvil_core anvil_assets anvil_assets_pipeline anvil_world anvil_sim anvil_ai anvil_physics anvil_runtime anvil_assembly)
BANNED=(bevy bevy_app bevy_ecs bevy_render bevy_pbr bevy_internal \
        tokio reqwest hyper actix async-std smol \
        openai async-openai langchain-rs candle-core)

bad=0
for crate in "${DETERMINISTIC[@]}"; do
    # Check if the crate exists in the workspace
    if ! cargo metadata --format-version 1 --no-deps -p "$crate" > /dev/null 2>&1; then
        # Crate doesn't exist yet (e.g., anvil_ai, anvil_physics not yet created)
        # Skip it - this is expected during early development
        echo "SKIP: $crate does not exist in workspace"
        continue
    fi
    
    # Get dependencies for this crate
    # Use cargo tree to get the full dependency graph
    # Filter to get just the package names (first field of each line)
    deps=$(cargo tree --prefix none --no-dedupe -p "$crate" -e normal,build \
           2>/dev/null | sed 's/^ *//' | cut -d' ' -f1 | sort -u || echo "")
    
    for ban in "${BANNED[@]}"; do
        if echo "$deps" | grep -qE "^${ban}$"; then
            echo "FAIL: $crate transitively depends on banned crate $ban"
            bad=1
        fi
    done
done

if [ "$bad" -ne 0 ]; then
    echo "FIREWALL BREACH: deterministic crates depend on forbidden crates"
    exit 1
fi
echo "OK: dependency firewall holds"
