#!/usr/bin/env bash
set -euo pipefail

OUT="$PWD/assets/downloads"
mkdir -p "$OUT/"{quaternius,kenney,fonts,textures}

echo "========================================="
echo " Forgeborn CC0 Asset Downloader"
echo " Assets land in: $OUT"
echo "========================================="

# -------- Quaternius 3D Models (CC0) --------
echo ""
echo "=== Quaternius ==="

declare -A Q=(
  [ultimate_humanoid]="https://quaternius.com/assets/downloads/UltimateHumanoid.zip"
  [ultimate_characters]="https://quaternius.com/assets/downloads/UltimateCharacters.zip"
  [medieval_village]="https://quaternius.com/assets/downloads/MedievalVillage.zip"
  [ultimate_furniture]="https://quaternius.com/assets/downloads/UltimateFurniture.zip"
  [ultimate_tools]="https://quaternius.com/assets/downloads/UltimateTools.zip"
  [ultimate_rocks]="https://quaternius.com/assets/downloads/UltimateRocks.zip"
  [ultimate_nature]="https://quaternius.com/assets/downloads/UltimateNature.zip"
)

for name in "${!Q[@]}"; do
  url="${Q[$name]}"
  file="$OUT/quaternius/${name}.zip"
  echo "  $name..."
  if curl -fL -o "$file" "$url"; then
    echo "    OK"
  else
    echo "    FAILED — download manually: ${Q[$name]}"
  fi
done

# -------- Kenney Packs (CC0) --------
echo ""
echo "=== Kenney ==="

KENNEY=(
  "https://kenney.nl/content/3-assets/19-particle-pack/kenney_particle-pack.zip"
  "https://kenney.nl/content/3-assets/57-ui-audio/kenney_ui-audio.zip"
  "https://kenney.nl/content/3-assets/69-ui-pack-rpg/kenney_ui-pack-rpg.zip"
)

for url in "${KENNEY[@]}"; do
  name=$(basename "$url")
  file="$OUT/kenney/$name"
  echo "  $name..."
  if curl -fL -o "$file" "$url"; then
    echo "    OK"
  else
    echo "    FAILED — download manually: $url"
  fi
done

# -------- Google Fonts (OFL) --------
echo ""
echo "=== Fonts ==="

FONTS=(
  "https://github.com/google/fonts/raw/main/ofl/crimsonpro/static/CrimsonPro-Regular.ttf"
  "https://github.com/google/fonts/raw/main/ofl/crimsonpro/static/CrimsonPro-Bold.ttf"
  "https://github.com/JetBrains/JetBrainsMono/raw/master/fonts/ttf/JetBrainsMono-Regular.ttf"
  "https://github.com/google/fonts/raw/main/ofl/caveat/static/Caveat-Regular.ttf"
)

for url in "${FONTS[@]}"; do
  name=$(basename "$url")
  file="$OUT/fonts/$name"
  echo "  $name..."
  if curl -fL -o "$file" "$url"; then
    echo "    OK"
  else
    echo "    FAILED — download manually: $url"
  fi
done

# -------- AmbientCG Textures (CC0) --------
echo ""
echo "=== AmbientCG Textures ==="

# Each entry: "name:ID"
TEXTURES=(
  "Grass:Grass001"
  "Ground:Dirt005"
  "Mud:Mud003"
  "Rock:Rock023"
  "Sand:Sand002"
  "Snow:Snow005"
  "Wood:Wood049"
  "Bricks:Bricks059"
  "Roof:Roofing003"
  "Cobblestone:PavingStones065"
)

for entry in "${TEXTURES[@]}"; do
  name="${entry%%:*}"
  id="${entry##*:}"
  file="$OUT/textures/${name}_1K-PNG.zip"
  url="https://ambientcg.com/get?file=${id}_1K-PNG.zip"
  echo "  $name ($id)..."
  if curl -fL -o "$file" "$url"; then
    echo "    OK"
  else
    echo "    FAILED — download manually: https://ambientcg.com/view?id=$id"
  fi
done

echo ""
echo "========================================="
echo " Automated downloads complete."
echo " Files are in: $OUT"
echo "========================================="
