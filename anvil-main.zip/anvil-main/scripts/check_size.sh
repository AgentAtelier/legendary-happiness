#!/usr/bin/env bash
set -euo pipefail
HARD=500
WARN=400

bad=0
while IFS= read -r f; do
    test_start=$(awk '/^#\[cfg\(test\)\]/{print NR; exit}' "$f")
    if [ -n "$test_start" ]; then
        prod=$((test_start - 1))
    else
        prod=$(wc -l < "$f")
    fi
    if [ "$prod" -gt "$HARD" ]; then
        echo "FAIL: $f has $prod prod lines (limit $HARD)"
        bad=1
    elif [ "$prod" -gt "$WARN" ]; then
        echo "WARN: $f has $prod prod lines (warning $WARN)"
    fi
done < <(find crates/*/src -name '*.rs')

[ "$bad" -eq 0 ]
