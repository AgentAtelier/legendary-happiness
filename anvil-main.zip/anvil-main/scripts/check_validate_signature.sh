#!/usr/bin/env bash
set -euo pipefail

violations=$(grep -rEn "^\s*(pub )?(fn|pub fn) validate\(.*\) ->" \
                crates/*/src --include='*.rs' | \
             grep -v "ValidationErrors" | \
             grep -v "^[^:]*:[0-9]*:\s*//" | \
             # Acknowledge PipelineManifest exception and external pipeline stages
             grep -v "external_" | \
             grep -v "pipeline\.rs" || true)

if [ -n "$violations" ]; then
    echo "FAIL: validators must return ValidationErrors. Offending lines:"
    echo "$violations"
    exit 1
fi
echo "OK: all validate() functions return ValidationErrors"
