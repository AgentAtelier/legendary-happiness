#!/usr/bin/env pwsh
# PowerShell version of check_size.sh
# Checks that Rust source files don't exceed line limits

$ErrorActionPreference = "Stop"

$HARD = 500
$WARN = 400

$bad = 0

# Find all Rust source files in crates
$rustFiles = Get-ChildItem -Path crates -Recurse -Filter "*.rs" -File

foreach ($file in $rustFiles) {
    $path = $file.FullName
    
    # Read the file content
    $content = Get-Content -Path $path -Raw
    $lines = $content -split "`n"
    
    # Find the start of test code (#[cfg(test)])
    $testStartLine = 0
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match "^#\[cfg\(test\)\]") {
            $testStartLine = $i + 1
            break
        }
    }
    
    # Calculate production lines
    if ($testStartLine -gt 0) {
        $prod = $testStartLine - 1
    } else {
        $prod = $lines.Count
    }
    
    if ($prod -gt $HARD) {
        Write-Host "FAIL: $path has $prod prod lines (limit $HARD)"
        $bad = 1
    } elseif ($prod -gt $WARN) {
        Write-Host "WARN: $path has $prod prod lines (warning $WARN)"
    }
}

exit $bad
