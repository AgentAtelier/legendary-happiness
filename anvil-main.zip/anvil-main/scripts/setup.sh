#!/usr/bin/env bash
set -euo pipefail

echo "=== Anvil Development Environment Setup ==="

# Install Rust toolchain
if ! command -v rustup &> /dev/null; then
    echo "Installing rustup..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi

# Install the exact toolchain from rust-toolchain.toml
TOOLCHAIN_DIR="$(pwd)"
if [ -f "$TOOLCHAIN_DIR/rust-toolchain.toml" ]; then
    TOOLCHAIN=$(grep channel "$TOOLCHAIN_DIR/rust-toolchain.toml" | cut -d'"' -f2)
    echo "Installing Rust toolchain: $TOOLCHAIN"
    rustup toolchain install "$TOOLCHAIN"
    rustup default "$TOOLCHAIN"
    rustup component add clippy rustfmt
else
    echo "WARNING: rust-toolchain.toml not found, skipping toolchain install"
fi

# Install system dependencies
if command -v apt-get &> /dev/null; then
    echo "Installing Ubuntu dependencies..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq cmake pkg-config libssl-dev libasound2-dev libudev-dev
elif command -v brew &> /dev/null; then
    echo "Installing macOS dependencies..."
    brew install cmake pkg-config openssl
else
    echo "WARNING: Unsupported OS. Install cmake and pkg-config manually."
fi

# Verify
 echo "Verifying installation..."
cargo check --workspace 2>&1 | tail -5

echo ""
echo "=== Setup complete! ==="
echo "Next steps:"
echo "  cargo run -p anvil_demo    # Launch the diagnostic instrument"
echo "  cargo test --workspace     # Run all tests"
echo "  ./tests/phase3_gate.sh    # Run the Phase 3 gate"
