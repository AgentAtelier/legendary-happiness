#!/usr/bin/env bash
set -euo pipefail
# Usage: ./scripts/bisect_determinism.sh <good_commit> <bad_commit>
# Automates git bisect to find the commit that broke determinism.

GOOD=${1:-""}
BAD=${2:-""}

if [ -z "$GOOD" ] || [ -z "$BAD" ]; then
    echo "Usage: $0 <good_commit> <bad_commit>"
    echo "Example: $0 abc123 def456"
    exit 1
fi

echo "=== Determinism Bisect ==="
echo "Good: $GOOD"
echo "Bad:  $BAD"

# Ensure we're in the repo root
cd "$(git rev-parse --show-toplevel)"

echo "Starting git bisect..."
git bisect start
git bisect bad "$BAD"
git bisect good "$GOOD"

echo "Running bisect with Phase 3 gate..."
git bisect run ./tests/phase3_gate.sh 2>/dev/null

RESULT=$?
git bisect reset

if [ $RESULT -eq 0 ]; then
    echo "=== Bisect complete ==="
    BAD_COMMIT=$(git rev-parse HEAD)
    echo "First bad commit: $BAD_COMMIT"
else
    echo "=== Bisect failed or was interrupted ==="
    exit $RESULT
fi
