#!/usr/bin/env python3
"""Count production panic-shaped calls per crate."""
import re
from pathlib import Path

PANIC_RE = re.compile(r"\.unwrap\(\)|\.expect\(|panic!|todo!|unreachable!")
DOC_OR_LINE_COMMENT = re.compile(r"^\s*(///|//!|//)")

def is_test_file(path):
    parts = path.parts
    return ('tests' in parts or 'benches' in parts or 'examples' in parts
            or 'fuzz' in parts or path.name == 'build.rs')

def classify(path):
    with open(path, encoding='utf-8', errors='replace') as f:
        lines = f.readlines()
    in_cfg_test = False
    cfg_test_brace_depth = -1
    brace_depth = 0
    prod = test = doc = 0
    for i, line in enumerate(lines, 1):
        if '#[cfg(test)]' in line.strip() or '#[cfg(any(test' in line.strip():
            in_cfg_test = True
            cfg_test_brace_depth = brace_depth
        prev = brace_depth
        for ch in line:
            if ch == '{': brace_depth += 1
            elif ch == '}': brace_depth -= 1
        if in_cfg_test and brace_depth <= cfg_test_brace_depth and prev > brace_depth:
            in_cfg_test = False
            cfg_test_brace_depth = -1
        if PANIC_RE.search(line):
            if DOC_OR_LINE_COMMENT.match(line): doc += 1; continue
            if in_cfg_test: test += 1; continue
            prod += 1
    return prod, test

def main():
    print(f"{'Crate':<25} {'LoC':>8} {'ProdPanic':>10} {'/kLoC':>8}")
    print('-' * 55)
    grand = 0
    for crate in sorted(Path('crates').iterdir()):
        if not crate.is_dir(): continue
        prod = test = lines_total = 0
        for f in crate.rglob('*.rs'):
            if 'target' in f.parts: continue
            with open(f, encoding='utf-8', errors='replace') as fp:
                lines_total += sum(1 for _ in fp)
            if is_test_file(f): continue
            p, t = classify(f)
            prod += p; test += t
        density = (prod * 1000.0 / lines_total) if lines_total else 0
        grand += prod
        print(f"{crate.name:<25} {lines_total:>8} {prod:>10} {density:>8.2f}")
    print('-' * 55)
    print(f"{'TOTAL':<25} {'':>8} {grand:>10}")

if __name__ == '__main__':
    main()
