#!/usr/bin/env bash
set -euo pipefail

DEBT_FILE="PLACEHOLDER_DEBT.md"
TODAY="$(date -I)"

if [ ! -f "$DEBT_FILE" ]; then
    echo "FAIL: $DEBT_FILE not found" >&2
    exit 1
fi

overdue=()
while IFS= read -r line; do
    # Match review date in entries: "**Review date (no later than):** YYYY-MM-DD."
    if echo "$line" | grep -qE '\*\*Review date \(no later than\):\*\* [0-9]{4}-[0-9]{2}-[0-9]{2}'; then
        date_str="$(echo "$line" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}')"
        if [[ "$date_str" < "$TODAY" ]]; then
            # find the PD-ID above this line
            pd_line="$(grep -B20 "$line" "$DEBT_FILE" | grep -E '^### PD-[0-9]+' | tail -1)"
            pd_id="$(echo "$pd_line" | grep -oE 'PD-[0-9]+')"
            overdue+=("${pd_id:-unknown} (review date $date_str)")
        fi
    fi
done < "$DEBT_FILE"

if [ ${#overdue[@]} -gt 0 ]; then
    echo "FAIL: overdue placeholder reviews:" >&2
    for entry in "${overdue[@]}"; do
        echo "  $entry" >&2
    done
    exit 1
fi

echo "OK: no overdue placeholder reviews"
