#!/usr/bin/env bash
set -euo pipefail

# check_schema_migration.sh
# CI gate: verify that any save format version bump has a corresponding migration.

# Find the save format version constant in format.rs
FORMAT_FILE="crates/anvil_runtime/src/snapshot/format.rs"
MIGRATION_FILE="crates/anvil_runtime/src/snapshot/migration.rs"

if [ ! -f "$FORMAT_FILE" ]; then
    echo "FAIL: Save format file not found: $FORMAT_FILE"
    exit 1
fi

if [ ! -f "$MIGRATION_FILE" ]; then
    echo "FAIL: Migration file not found: $MIGRATION_FILE"
    exit 1
fi

# Get the current SAVE_FORMAT_VERSION
CURRENT_VERSION=$(grep '^\s*pub const SAVE_FORMAT_VERSION:' "$FORMAT_FILE" | sed 's/.*=\s*//;s/[^0-9]//g')

if [ -z "$CURRENT_VERSION" ]; then
    echo "FAIL: Could not find SAVE_FORMAT_VERSION in $FORMAT_FILE"
    exit 1
fi

echo "Current save format version: $CURRENT_VERSION"

# Get the previous version constant (SAVE_FORMAT_VERSION_V6 for v7, etc.)
PREV_VERSION=$(grep '^\s*pub const SAVE_FORMAT_VERSION_V[0-9]*:' "$FORMAT_FILE" | sed 's/.*=\s*//;s/[^0-9]//g' | sort -n | tail -1)

if [ -z "$PREV_VERSION" ]; then
    echo "WARN: No previous version constant found in $FORMAT_FILE"
else
    echo "Previous save format version: $PREV_VERSION"
fi

# Check that the version constant changed in git
# We compare against the previous commit (HEAD~1)
if [ "$(git rev-parse --abbrev-ref HEAD)" = "HEAD" ]; then
    # Detached HEAD, compare against parent
    PREV_COMMIT="HEAD~1"
else
    PREV_COMMIT="HEAD~1"
fi

# Get the version from the previous commit
if git show "$PREV_COMMIT:$FORMAT_FILE" > /dev/null 2>&1; then
    PREV_VERSION_IN_GIT=$(git show "$PREV_COMMIT:$FORMAT_FILE" | grep '^\s*pub const SAVE_FORMAT_VERSION:' | sed 's/.*=\s*//;s/[^0-9]//g')
    
    if [ -n "$PREV_VERSION_IN_GIT" ] && [ "$CURRENT_VERSION" != "$PREV_VERSION_IN_GIT" ]; then
        echo "Save format version changed from $PREV_VERSION_IN_GIT to $CURRENT_VERSION"
        
        # The new version is CURRENT_VERSION, the old is PREV_VERSION_IN_GIT
        # We need to check for upgrade_v{PREV_VERSION_IN_GIT}_to_v{CURRENT_VERSION} or migrate_v{PREV_VERSION_IN_GIT}_to_v{CURRENT_VERSION}
        MIGRATION_FUNC="upgrade_v${PREV_VERSION_IN_GIT}_to_v${CURRENT_VERSION}"
        
        # Check if the migration function exists
        if ! grep -q "$MIGRATION_FUNC" "$MIGRATION_FILE"; then
            # Try alternate naming
            MIGRATION_FUNC="migrate_v${PREV_VERSION_IN_GIT}_to_v${CURRENT_VERSION}"
            if ! grep -q "$MIGRATION_FUNC" "$MIGRATION_FILE"; then
                echo "FAIL: Version bumped to $CURRENT_VERSION but migration function not found in $MIGRATION_FILE (tried upgrade_v${PREV_VERSION_IN_GIT}_to_v${CURRENT_VERSION} and migrate_v${PREV_VERSION_IN_GIT}_to_v${CURRENT_VERSION})"
                exit 1
            fi
        fi
        
        echo "OK: Migration function $MIGRATION_FUNC found"
        
        # Check if there's a test that exercises the migration
        # Look for tests that use the old version, the migration function, or parse_and_upgrade_save
        if ! grep -rq "$MIGRATION_FUNC\|SAVE_FORMAT_VERSION_V${PREV_VERSION_IN_GIT}\|parse_and_upgrade_save" crates/anvil_runtime/tests/ crates/anvil_sim/tests/ 2>/dev/null; then
            echo "WARN: No test found that exercises migration from v$PREV_VERSION_IN_GIT to v$CURRENT_VERSION"
        else
            echo "OK: Test found for migration"
        fi
    fi
else
    echo "OK: No previous commit to compare against, or format file didn't exist in previous commit"
fi

echo "OK: Schema migration check passed"
