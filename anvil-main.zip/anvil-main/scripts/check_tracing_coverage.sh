#!/usr/bin/env bash
set -euo pipefail

# Check that every tracing::error! call in the codebase includes an error_code field
# referencing an entry in ERROR_CODES.md

echo "=== Checking tracing::error! coverage ==="

# Find all files with tracing::error! calls
ERROR_FILES=$(grep -rl "tracing::error!" crates/ --include="*.rs" || true)

if [ -z "$ERROR_FILES" ]; then
    echo "No tracing::error! calls found - this may be intentional if no error paths exist yet"
    exit 0
fi

# Count total error calls across all files
TOTAL=$(grep -rh "tracing::error!" crates/ --include="*.rs" | grep -c "tracing::error!" || echo "0")
echo "Found $TOTAL tracing::error! calls"

# Check each file for error_code presence
FAILED=0
for file in $ERROR_FILES; do
    # Check if file contains tracing::error! without error_code in the same block
    # This is a simple check - look for tracing::error! lines that don't have error_code nearby
    if grep -A 5 "tracing::error!" "$file" | grep -q "error_code"; then
        echo "  $file: OK (has error_code)"
    else
        echo "  $file: MISSING error_code field"
        FAILED=1
    fi
done

if [ "$FAILED" -ne 0 ]; then
    echo ""
    echo "ERROR: Some tracing::error! calls are missing error_code field"
    exit 1
fi

echo "All tracing::error! calls include error_code field"

# Also verify that tracing is being used for significant events
echo ""
echo "=== Checking tracing usage for key events ==="

# Check for SimSystem::tick instrumentation
TICK_INSTRUMENTED=$(grep -r "#\[tracing::instrument" crates/anvil_sim/src/system/ --include="*.rs" | grep -c "tick" || echo "0")
if [ "$TICK_INSTRUMENTED" -lt "4" ]; then
    echo "WARNING: Expected at least 4 SimSystem::tick functions to be instrumented, found $TICK_INSTRUMENTED"
    # Don't fail, just warn for now
fi

# Check for catastrophe tracing
if ! grep -r "catastrophe_triggered" crates/ --include="*.rs" -q; then
    echo "WARNING: No catastrophe_triggered tracing found"
fi

# Check for catalyst tracing
if ! grep -r "catalyst_triggered" crates/ --include="*.rs" -q; then
    echo "WARNING: No catalyst_triggered tracing found"
fi

echo ""
echo "=== Tracing coverage check passed ==="
exit 0
