#!/usr/bin/env bash
# scripts/audit_coverage.sh
#
# Verifies that every .rs file in a Forge snapshot is mentioned at
# least once in the Forge Harvest Journal (Parts 1 and 2). Exits
# non-zero if any file is left silent.
#
# Usage:
#   scripts/audit_coverage.sh <path-to-forge-snapshot> <path-to-journal-part1> <path-to-journal-part2>
#
# Example:
#   scripts/audit_coverage.sh ../forge-analysis docs/FORGE_HARVEST_JOURNAL_PART1.md docs/FORGE_HARVEST_JOURNAL_PART2.md

set -euo pipefail

if [ "$#" -lt 3 ]; then
    echo "Usage: $0 <forge-snapshot-dir> <journal-part1> <journal-part2>" >&2
    exit 2
fi

FORGE_DIR="$1"
JOURNAL_PART1="$2"
JOURNAL_PART2="$3"

if [ ! -d "$FORGE_DIR" ]; then
    echo "FAIL: Forge snapshot directory '$FORGE_DIR' does not exist" >&2
    exit 1
fi

for f in "$JOURNAL_PART1" "$JOURNAL_PART2"; do
    if [ ! -f "$f" ]; then
        echo "FAIL: Journal file '$f' does not exist" >&2
        exit 1
    fi
done

# Collect every unique .rs file from the Forge snapshot, excluding:
#   - test directories (we deliberately don't cover individual test files)
#   - fuzz targets
#   - the duplicated forge_bevy/src/src/ tree (an artefact of snapshot cleaning)
mapfile -t files < <(
    find "$FORGE_DIR/crates" -name '*.rs' \
        -not -path '*/fuzz/*' \
        -not -path '*forge_bevy/src/src/*' \
        -not -path '*/tests/*' | \
    sort -u
)

# Concatenate journal parts for searching.
JOURNAL_TEXT="$(cat "$JOURNAL_PART1" "$JOURNAL_PART2")"

missing=()
for path in "${files[@]}"; do
    # Convert absolute path to a relative form likely to appear in the journal.
    rel="${path#$FORGE_DIR/}"
    base="$(basename "$path")"

    # The journal might mention the file via either:
    #   - its full relative path: crates/forge_sim/src/weather.rs
    #   - its short form: forge_sim/src/weather.rs
    #   - just its basename in a section heading: weather.rs
    # We treat any of these as coverage. Be permissive on purpose —
    # the journal is for humans, not for parsers.
    if ! grep -q -F "$rel" <<< "$JOURNAL_TEXT" \
       && ! grep -q -F "${rel#crates/}" <<< "$JOURNAL_TEXT" \
       && ! grep -q -F "$base" <<< "$JOURNAL_TEXT"; then
        missing+=("$rel")
    fi
done

if [ ${#missing[@]} -gt 0 ]; then
    echo "FAIL: ${#missing[@]} Forge file(s) not mentioned in the journal:" >&2
    for m in "${missing[@]}"; do
        echo "  $m" >&2
    done
    exit 1
fi

echo "OK: all ${#files[@]} Forge .rs files covered in journal."
